# Brand profiles

One folder per template. `active.json` names the default. Create a profile with `tools/brand_import.py`; do not write one by hand.

`brand.json` fields:
- `template` and `sha256`: the template file and its pinned hash.
- `headline_marker`: the sample headline text, or `@ph:<type>:<idx>` when the headline is identified by its placeholder.
- `roles`:
  - `cover`, `closing`: the first and last template slides.
  - `diagram_base`: the title-only slide that diagram slides are measured against.
  - `flow`, `flow_table`, `flow_boxes`: the step-flow slide, or `null` when the template has none.
- `fonts`:
  - `heading`, `body`, `body_medium`, `body_bold`: the template's fonts.
  - `installed_check`: the fonts bootstrap looks for.
  - `oldstyle_digits`: fonts whose digits must stay out of number cells.
- `theme`: the theme colours. `palette`: brand colours, tints, neutrals and RAG status colours.
- `logo`: the brand logo file. `metrics`: fonts measured as a bundled font when no font file was given.

Optional files beside `brand.json`:
- `metrics.json`: font metrics measured from the font files.
- `CATALOG.md`: what each slide holds.
