---
id: pp-gv-portfolio
domain: Programs and Projects
l1: Govern
l2: Portfolio review
summary: All projects on a page: health by project, investment by theme, capacity, and the decisions to start, stop or re-plan.
systems: Portfolio management, Finance system
tags: portfolio, PMO, portfolio review, investment, prioritisation, health
workbook: status
order: 305
---
# Portfolio review

## The portfolio in four numbers
Layout: four numbers
- Projects: 18 active
- Investment: $42M this year
- On track: 72% of projects green
- Benefits: $15M a year when delivered
> Notes: illustrative figures.

## Health by project
| Project | Sponsor | Status | Budget | Schedule | Next milestone |
|---|---|---|---|---|---|
| Store replenishment | Supply chain | Green | On budget | On time | Pilot in May |
| Guest profile | Marketing | Amber | 5% over | On time | Build complete |
| Finance close | Finance | Green | On budget | On time | Go-live in June |
| DC automation | Supply chain | Red | 12% over | 2 months late | Re-plan approval |
| Store pickup | Stores | Green | Under budget | On time | Rollout wave 2 |

## Investment by theme
Layout: donut
- Guest experience: 38% of spend
- Supply chain: 30% of spend
- Stores: 18% of spend
- Finance and back office: 14% of spend

## Capacity against demand
Layout: bullet
- Business analysts: 22 of 18
- Developers: 46 of 40
- Testers: 25 of 20
> Notes: illustrative - people asked for against people available.

## Decisions for the portfolio board
| Decision | Why | Recommendation |
|---|---|---|
| Re-plan DC automation | Two months late, 12% over | Approve new baseline with a phased rollout |
| Start loyalty analytics | Capacity frees up in Q3 | Start in July |
| Pause store kiosk refresh | Low benefit, competes for testers | Pause until Q1 |

## The decision
- Decision: Approve the three changes above
- Ask: Release two testers from the paused project
- Next step: Updated portfolio plan next month
