---
id: pp-cl-lessons
domain: Programs and Projects
l1: Close and Review
l2: Lessons learned
summary: A blameless look back: what went well, what did not, lessons by theme, root causes and the actions that carry them forward.
systems: Lessons log, Collaboration site
tags: lessons learned, retrospective, post-implementation review, continuous improvement, look back
workbook: lessons
order: 501
---
# Lessons learned

## Looking back
### Went well
- Business owners in every design decision
- Three data trial loads: a clean cutover
- Daily stand-ups kept issues small
### Did not go well
- Interfaces started late
- Testers hired late
- Training too close to go-live for stores
### Do differently
- Build interfaces first
- Hire testers at design sign-off
- Train stores four weeks before

## Lessons by theme
| Theme | What happened | Lesson | Apply it to |
|---|---|---|---|
| Planning | Interfaces on the critical path started late | Start the riskiest build first | Every project with integration |
| People | Testers joined two weeks into testing | Staff testing at design sign-off | All delivery plans |
| Change | Stores trained one week before go-live | Train three to four weeks ahead | Store rollouts |
| Data | Three trial loads caught every error | Keep three trial loads as standard | All migrations |

## Why it happened
Layout: process converge
- Plan: build order set by team availability
- Contracts: partner started after design sign-off
- Estimates: interface effort under-estimated
- Result: Interfaces three weeks late - testing compressed

## Actions that carry the lessons forward
| Action | Owner | Due | Status |
|---|---|---|---|
| Add risk-first sequencing to the plan template | PMO lead | Next quarter | Open |
| Add testers to the resource plan at design | PMO lead | Next quarter | Open |
| Update the store training standard | Change lead | Next month | Open |

## How we share what we learned
Layout: process cycle
- Capture: in the last two weeks
- Agree: lessons and owners
- Share: with the PMO and new projects
- Apply: in the next plan
