---
id: pp-cl-qbr
domain: Programs and Projects
l1: Close and Review
l2: Quarterly business review
summary: The quarter in review: results against plan, the scorecard, what worked and what did not, next quarter's priorities and asks.
systems: Reporting, Finance system
tags: QBR, quarterly business review, business review, quarter, results, scorecard, priorities
workbook: status
order: 503
---
# Quarterly business review

## The quarter in four numbers
Layout: four numbers
- Sales: $412M (+4.1%)
- Margin: 38.6% (+0.4 pts)
- Fill rate: 96% (+2 pts)
- Projects delivered: 6 of 7
> Notes: illustrative figures.

## Scorecard
Layout: scorecard
### Growth
- Comparable sales: 3.1% | 4.0% | 4.1% | green
- New members: 1.1M | 1.2M | 1.0M | amber
### Operations
- Fill rate: 94% | 95% | 96% | green
- Cost per order: $6.10 | $5.80 | $6.30 | red
> Notes: illustrative figures - each line is last quarter | target | this quarter | status.

## What worked and what did not
### Worked
- Promotions drove traffic in key weeks
- Store pickup grew 18%
### Did not work
- Member sign-ups behind target
- Cost per order rose with shipping rates
### What we change
- New sign-up offer in the app
- Carrier mix review

## Results against plan
Layout: bullet
- Sales: 412 of 405
- Margin: 38.6 of 38.5
- New members: 1.0 of 1.2
> Notes: $ millions, %, millions - illustrative.

## Priorities for next quarter
Layout: cards
- Members: lift sign-ups with the app offer
- Cost: carrier mix and packaging
- Holiday: stock and staffing ready by week 44

## Risks and asks
| Risk or ask | Impact | Owner | Need |
|---|---|---|---|
| Shipping rates rise again | Margin -0.2 pts | Supply chain | Approve carrier tender |
| Holiday staffing | Service in peak weeks | Store operations | Approve seasonal hiring plan |

## The decisions
- Decision: Approve the carrier tender and the seasonal hiring plan
- Ask: Marketing support for the member offer
- Next step: Mid-quarter check-in in six weeks
