---
id: pp-in-charter
domain: Programs and Projects
l1: Initiate
l2: Project charter
summary: Why the project exists, what it will deliver, by when, for how much, who decides - the page the sponsor signs.
systems: Project plan, Collaboration site
tags: charter, project initiation, scope, objectives, sponsor, mandate
workbook: raid
order: 101
---
# Project charter

## Why we are doing this
### The problem
- What is broken or missing today
- Who feels it and how much it costs
### The opportunity
- What changes when it is fixed
- Why now
### If we do nothing
- The cost of waiting
- The risk we keep

## Objectives and how we measure them
| Objective | Measure | Target | By when |
|---|---|---|---|
| Faster service for guests | Order cycle time | Under 2 hours | Q4 2027 |
| Lower cost to serve | Cost per order | Down 15% | Q2 2028 |
| Fewer manual steps | Hand-offs per order | From 9 to 4 | Q4 2027 |
> Notes: illustrative objectives - every objective needs one measure, one number and one date.

## Scope
### In scope
- Processes, sites and teams included
- Systems that change
- Data that moves
### Out of scope
- What we will not change now
- Related work run by others

## Milestones
Layout: timeline quarters
- Mobilise: Jan 2027 – Feb 2027 (Project)
- Design: Mar 2027 – May 2027 (Project)
- Build and test: Jun 2027 – Oct 2027 (Project)
- Go-live: Nov 9, 2027 (Project)
- Hypercare and close: Nov 2027 – Jan 2028 (Project)
> Notes: example dates; replace them with the baseline plan.

## The project in four numbers
Layout: four numbers
- Budget: $4.8M over 14 months
- Team: 22 people at peak
- Duration: 14 months to close
- Benefit: $3.1M a year from year two
> Notes: illustrative figures - replace with the approved business case.

## Who decides
Layout: pyramid
- Sponsor: owns the outcome and the budget
- Steering committee: decides on scope, time and cost
- Project manager: runs the plan, the team and the risks
- Workstream leads: deliver and report

## Top risks and assumptions
| Risk | Likelihood | Impact | Mitigation | Owner |
|---|---|---|---|---|
| Key business users not available | Medium | High | Backfill agreed before design | Sponsor |
| Data not ready for migration | High | High | Cleansing starts in mobilise | Data lead |
| Peak season freezes changes | Medium | Medium | Go-live before the freeze | Project manager |

## The decision we ask for
- Decision: Approve the charter, the budget and the team
- Ask: Name the business owner for each workstream
- Next step: Kick-off in two weeks
