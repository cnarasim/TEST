---
id: pp-pl-raci
domain: Programs and Projects
l1: Plan
l2: RACI and governance
summary: How the project is governed: the forums, who is responsible, accountable, consulted and informed, decision rights and escalation.
systems: Collaboration site, RAID log
tags: RACI, governance, roles, responsibilities, decision rights, escalation, forums
workbook: raci
order: 202
---
# RACI and governance

## How the project is governed
Layout: pyramid
- Executive sponsor: the outcome and the money
- Steering committee: scope, time, cost and risk decisions
- Project board: weekly plan, risks and changes within tolerance
- Workstreams: deliver, test and report

## Our forums
Layout: process list
- Steering committee: decides scope, budget and go-live (Sponsor chairs · monthly)
- Project board: decides the plan, risks and changes in tolerance (Project manager chairs · weekly)
- Design authority: decides design and standards (Solution architect chairs · weekly)
- Workstream meeting: clears tasks and blockers (Workstream lead chairs · daily or weekly)

## Who does what
| Activity | Sponsor | Steering committee | Project manager | Workstream lead | Business owner |
|---|---|---|---|---|---|
| Business case | A | R | C | I | C |
| Plan baseline | I | A | R | C | C |
| Process design | I | I | C | R | A |
| Major changes | C | A | R | C | C |
| Acceptance | I | I | C | R | A |
| Go-live | C | A | R | C | C |
> Notes: R does the work, A owns the outcome (one per activity), C is asked before, I is told after.

## What each letter means
Layout: matrix
- Responsible: does the work
- Accountable: owns the result - one person per activity
- Consulted: asked before the decision
- Informed: told after the decision

## Decision rights and tolerances
| Decision | Project board up to | Steering committee above |
|---|---|---|
| Schedule change | Two weeks on a milestone | More than two weeks |
| Budget change | 5% of a workstream budget | More than 5% |
| Scope change | No change to an objective | Any change to an objective |

## How we escalate
Layout: swimlane handoffs
- Workstream lead: Raises the issue with options
- Project manager: Assesses the impact
- Project manager: Within the board's tolerance?
- Project manager: If yes, decides at the weekly board
- Steering committee: If no, decides at the next meeting
- Project manager: Logs it and tells teams
