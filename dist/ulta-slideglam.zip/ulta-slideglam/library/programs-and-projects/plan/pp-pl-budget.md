---
id: pp-pl-budget
domain: Programs and Projects
l1: Plan
l2: Budget and resource plan
summary: The budget by category with committed, actual and forecast spend, the team the plan needs, and how contingency is used.
systems: Finance system, Project plan, Resource plan
tags: budget, cost, forecast, resources, capacity, contingency, spend
workbook: budget
order: 203
---
# Budget and resource plan

## The budget in four numbers
Layout: four numbers
- Budget: $4.8M approved
- Spent: $1.9M to date
- Forecast: $4.9M at completion
- Contingency: $0.4M left
> Notes: illustrative figures - replace with the finance system's numbers.

## Budget by category
| Category | Budget | Committed | Actual | Forecast | Variance |
|---|---|---|---|---|---|
| Internal team | $1,600,000 | $1,600,000 | $700,000 | $1,650,000 | -$50,000 |
| Partners and contractors | $1,800,000 | $1,500,000 | $800,000 | $1,850,000 | -$50,000 |
| Software and subscriptions | $700,000 | $700,000 | $300,000 | $700,000 | $0 |
| Hardware | $300,000 | $200,000 | $100,000 | $280,000 | $20,000 |
| Contingency | $400,000 | $0 | $0 | $400,000 | $0 |
> Notes: variance is budget minus forecast - negative means over budget.

## Spend against plan
Layout: bullet
- Internal team: 700 of 1600
- Partners: 800 of 1800
- Software: 300 of 700
- Hardware: 100 of 300

## The team the plan needs
| Role | Needed | Filled | Gap | Needed by |
|---|---|---|---|---|
| Business analysts | 4 | 3 | 1 | Mar 2027 |
| Solution developers | 6 | 4 | 2 | Jun 2027 |
| Testers | 5 | 2 | 3 | Aug 2027 |
| Trainers | 3 | 0 | 3 | Sep 2027 |

## How we use contingency
Layout: process numbered
- Identify: a risk turns into cost
- Estimate: the cost and the options
- Approve: board within tolerance, steering above
- Record: drawdown logged against the risk

## The decision we ask for
- Decision: Release $120K of contingency for test automation
- Ask: Approve two contract testers from August
- Next step: Updated forecast at the next steering committee
