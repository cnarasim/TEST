---
id: pp-pl-plan-on-a-page
domain: Programs and Projects
l1: Plan
l2: Integrated plan on a page
summary: Phases, workstreams, milestones and the critical path on one page, with the assumptions behind the dates.
systems: Project plan, Work management tool
tags: plan, integrated plan, milestones, critical path, schedule, timeline, gantt
workbook: status
order: 201
---
# Integrated plan on a page

## Five phases
Layout: process phases
- Mobilise: team; plan; tools (Jan - Feb)
- Design: process; solution; data (Mar - May)
- Build: configure; integrate; migrate (Jun - Aug)
- Test: system; integration; acceptance (Aug - Oct)
- Deploy: cutover; go-live; hypercare (Nov - Jan)

## Plan by workstream
Layout: gantt
- Process design: Mar 2027 – May 2027 (Business)
- Solution build: Jun 2027 – Aug 2027 (Technology)
- Data migration: May 2027 – Oct 2027 (Data)
- Testing: Aug 2027 – Oct 2027 (Business)
- Training: Sep 2027 – Nov 2027 (Change)
- Go-live: Nov 9, 2027 (Project)
> Notes: example dates; "(Team)" names the workstream, a single date is a milestone.

## Key milestones
| Milestone | Baseline | Forecast | Status |
|---|---|---|---|
| Design signed off | May 28, 2027 | May 28, 2027 | On track |
| Build complete | Aug 27, 2027 | Sep 10, 2027 | At risk |
| User acceptance passed | Oct 15, 2027 | Oct 22, 2027 | At risk |
| Go / no-go | Nov 1, 2027 | Nov 1, 2027 | On track |
| Go-live | Nov 9, 2027 | Nov 9, 2027 | On track |

## The critical path
Layout: process converge
- Design sign-off: process and data decisions
- Build complete: every interface working
- Data ready: third trial load clean
- Result: User acceptance on time - the go-live date holds

## What the dates assume
| Assumption | If it fails | Check by | Owner |
|---|---|---|---|
| Business users at 50% in design | Design slips two weeks | Mar 1, 2027 | Sponsor |
| Test environment ready in July | Testing compresses | Jul 1, 2027 | Technology lead |
| No change freeze before November | Go-live moves to January | Jun 1, 2027 | Project manager |
