---
id: st-dc-decision-brief
domain: Strategy
l1: Decisions
l2: Decision brief and options
summary: A one-decision brief: the situation, options compared, the recommendation and next steps.
systems: 
tags: decision, options, recommendation, steering, brief
order: 302
---
# Decision brief

## The situation
### Today
- Online orders ship only from the DC
- Store stock cannot save an online sale
### Proposed
- Ship from store in 300 stores
- Pickup in every store by peak

## Options compared
| Option | Benefit | Cost | Risk |
|---|---|---|---|
| Keep DC only | None | None | Lost sales grow |
| Pickup only | Faster service | Low | Store labour at peak |
| Pickup and ship from store | Most sales saved | Medium | Store stock accuracy |

## Why we recommend it
Layout: cards
- Guests: Faster delivery and more choice
- Sales: Fewer lost online orders
- Stock: Store inventory works harder

## Next steps
Layout: process numbered
- Decide: approval this month
- Pilot: 20 stores for eight weeks
- Measure: fill rate and cost per order
- Scale: 300 stores before peak
