---
id: st-dc-risks
domain: Strategy
l1: Decisions
l2: Risks and mitigations
summary: The top risks with likelihood, impact, mitigation and owner, and the decisions the risks need.
systems: 
tags: risk register, mitigation, RAID, governance
order: 304
---
# Risks and mitigations

## Top risks
| Risk | Likelihood | Impact | Mitigation | Owner |
|---|---|---|---|---|
| Data migration quality | High | High | Clean-up starts now, three mock loads | Data lead |
| Key users not available | Medium | High | Backfill and ring-fenced time | Business leads |
| Peak season freeze | High | Medium | No go-lives October to January | Programme director |
| Integration delays | Medium | Medium | Interface-first build plan | Integration lead |
| Change fatigue in stores | Medium | Medium | Store champions and short training | Store operations |

## Risk response by quadrant
Layout: matrix
- Act now: high likelihood, high impact
- Prepare: low likelihood, high impact
- Watch: high likelihood, low impact
- Accept: low likelihood, low impact

## Decisions the risks need
- Decision: Approve backfill for key users from next month
- Ask: Confirm the peak-season change freeze
