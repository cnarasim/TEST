---
id: st-dc-swot
domain: Strategy
l1: Decisions
l2: SWOT analysis
summary: Strengths, weaknesses, opportunities and threats on a 2×2, with the so-what for the strategy.
systems: 
tags: SWOT, analysis, strategy, competition
order: 303
---
# SWOT analysis

## Where we stand
Layout: matrix
- Strengths: loyal members and a broad brand range
- Weaknesses: manual planning and slow price changes
- Opportunities: services, same-day delivery and new categories
- Threats: new competitors online and in mass retail

## So what for the strategy
### Build on
- Use member data to personalise every visit
- Grow services that bring guests back
### Fix
- Automate planning and pricing
- Make store stock visible online
