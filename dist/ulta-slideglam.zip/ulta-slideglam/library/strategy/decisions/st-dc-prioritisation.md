---
id: st-dc-prioritisation
domain: Strategy
l1: Decisions
l2: Prioritisation (value vs effort)
summary: Initiatives placed on a 2×2 of value against effort, a ranked backlog and what we stop.
systems: 
tags: prioritisation, 2x2, value effort, backlog, portfolio
order: 301
---
# Prioritisation

## Value against effort
Layout: matrix
- Quick wins: high value, low effort - do now
- Big bets: high value, high effort - plan and fund
- Fill-ins: low value, low effort - when there is capacity
- Money pits: low value, high effort - stop

## The ranked backlog
| Rank | Initiative | Value | Effort | Decision |
|---|---|---|---|---|
| 1 | Automatic replenishment | High | Medium | Fund now |
| 2 | App pickup redesign | High | Low | Fund now |
| 3 | DC automation | High | High | Plan for next year |
| 4 | Store task app | Medium | Low | When capacity allows |
| 5 | Legacy report rebuild | Low | High | Stop |

## What we stop
- Decision: Stop the legacy report rebuild and move the team to replenishment
- Ask: Agree the ranking at the next steering committee
