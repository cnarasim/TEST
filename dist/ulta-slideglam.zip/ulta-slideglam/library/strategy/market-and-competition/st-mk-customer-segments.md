---
id: st-mk-customer-segments
domain: Strategy
l1: Market and Competition
l2: Customer segments and personas
summary: Who the guests are: segments by size and value, a persona for each, what they need from us, and which segments to prioritise.
systems: Customer data platform, Survey tool
tags: customer segments, segmentation, personas, target customer, guests, strategy
order: 404
---
# Customer segments and personas

## Segments by share of sales
Layout: donut
- Beauty enthusiasts: 38% of sales
- Routine replenishers: 27% of sales
- Gift and occasion shoppers: 15% of sales
- Value seekers: 20% of sales
> Notes: illustrative shares.

## Who they are
| Segment | Who | What they want | How we serve them |
|---|---|---|---|
| Beauty enthusiasts | Try new things monthly | Newness, expertise, events | Launches, services, community |
| Routine replenishers | Buy the same products | Convenience, rewards | Reorder, pickup, points |
| Gift and occasion | A few big moments | Ideas, gift sets | Gift guides, sets, wrapping |
| Value seekers | Price-led | Deals, value sizes | Value tiers, member offers |

## Value against growth
Layout: matrix
- Grow: high value, growing - beauty enthusiasts
- Protect: high value, steady - routine replenishers
- Convert: lower value, growing - value seekers
- Activate: lower value, seasonal - gift and occasion

## Where we focus
- Decision: Grow enthusiasts and protect replenishers first
- Ask: Marketing plans by segment from next quarter
- Next step: Track segment share every month
