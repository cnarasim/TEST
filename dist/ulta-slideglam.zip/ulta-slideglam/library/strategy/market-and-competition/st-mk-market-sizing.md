---
id: st-mk-market-sizing
domain: Strategy
l1: Market and Competition
l2: Market sizing (TAM, SAM, SOM)
summary: How big the opportunity is: total, serviceable and obtainable market, the assumptions behind each number and the growth over time.
systems: 
tags: market sizing, tam sam som, addressable market, opportunity size, market share, strategy
order: 403
---
# Market sizing

## Three circles of the market
Layout: rings
- Total market: 100%
- Serviceable market: 42%
- Obtainable in five years: 9%

## The numbers
Layout: four numbers
- Total market: $95B a year
- Serviceable: $40B where we sell
- Obtainable: $8.5B in five years
- Growth: 6% a year
> Notes: illustrative figures - every number needs its source and date.

## How we got there
| Step | Assumption | Source | Confidence |
|---|---|---|---|
| Total market | All beauty spend in the country | Industry reports | High |
| Serviceable | Categories and channels we sell in | Our category map | High |
| Obtainable | Share we can win with current plans | Our share trend, plans | Medium |
| Growth | Market growth for the next five years | Industry forecast | Medium |

## Where the growth comes from
Layout: bubbles
- Skincare: 34
- Cosmetics: 28
- Haircare: 18
- Fragrance: 12
- Wellness: 8
> Notes: share of growth by category, illustrative.

## So what
- Decision: Focus growth plans on skincare and wellness
- Ask: Insights team refreshes the sizing yearly
- Next step: Use the obtainable market in the plan
