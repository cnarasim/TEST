---
id: st-tr-roadmap
domain: Strategy
l1: Transformation
l2: Transformation roadmap
summary: A multi-workstream roadmap by quarter, the waves of delivery and the decisions each gate needs.
systems: Programme management
tags: roadmap, transformation, programme, waves, gates, ERP
order: 201
---
# Transformation roadmap

## The programme by quarter
Layout: timeline quarters
- Discovery and design: Jan 2027 – Mar 2027 (Programme)
- Build and test: Apr 2027 – Sep 2027 (Technology)
- Pilot in 20 stores: Oct 2027 – Dec 2027 (Stores)
- Rollout wave 1: Jan 2028 – Mar 2028 (Stores)
- Go-live for all stores: Apr 3, 2028 (Programme)
> Notes: example dates; keep one line per deliverable with its team in brackets.

## Delivery in four waves
Layout: process phases
- Prepare: scope; team; business case (Q1 2027)
- Explore: fit-to-standard; design; data (Q2 2027)
- Realise: build; test; train (Q3 2027)
- Deploy: cutover; go-live; hypercare (Q4 2027)

## Gates and decisions
| Gate | Decision | Evidence | Decision maker |
|---|---|---|---|
| Design complete | Freeze scope and design | Signed fit-to-standard | Steering committee |
| Ready to test | Start integration testing | Build complete, unit tests passed | Programme director |
| Ready for pilot | Go live in pilot stores | Test exit, trained users | Steering committee |
| Ready to roll out | Start rollout waves | Pilot KPIs met | Executive sponsor |

## Risks to the timeline
| Risk | Impact | Mitigation | Owner |
|---|---|---|---|
| Data quality | Late cutover | Data clean-up starts in Explore | Data lead |
| Key-user time | Slower testing | Backfill for key users | Business leads |
| Peak season freeze | Rollout gap | No go-lives in Q4 | Programme director |
