---
id: st-tr-now-next-later
domain: Strategy
l1: Transformation
l2: Now, next, later
summary: What we are doing now, next and later: a simple roadmap for leaders, with what each horizon delivers.
systems: 
tags: now next later, horizons, roadmap, portfolio, backlog
order: 202
---
# Now, next, later

## Our roadmap in three horizons
Layout: timeline now-next-later
- Guest profile in the app: Oct 2026 – Dec 2026 (Digital)
- Store pickup slots: Nov 2026 – Jan 2027 (Stores)
- Automatic store replenishment: Jan 2027 – Apr 2027 (Supply chain)
- New services booking: Feb 2027 – May 2027 (Services)
- DC automation phase 1: Jul 2027 – Dec 2027 (Supply chain)
- Same-day delivery in new markets: Sep 2027 – Dec 2027 (Digital)
> Notes: the horizons follow today's date; items move left as they are funded and staffed.

## What each horizon delivers
### Now
- Funded, staffed and in delivery
- Outcomes this quarter
### Next
- Funded, starting next quarter
- Design and readiness under way
### Later
- Ideas worth funding next year
- Business cases in progress
