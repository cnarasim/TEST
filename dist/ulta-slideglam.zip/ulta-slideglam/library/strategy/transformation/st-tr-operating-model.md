---
id: st-tr-operating-model
domain: Strategy
l1: Transformation
l2: Target operating model
summary: The operating model on a page: the guest at the centre, the capabilities around it, roles and governance.
systems: 
tags: operating model, TOM, capabilities, governance, RACI, organisation
order: 204
---
# Target operating model

## The model on a page
Layout: hub
- Guest: The centre of every decision
- Merchandising: Range, price and promotions
- Supply chain: Stock in the right place
- Stores: Service and fulfilment
- Digital: App, site and data
- Finance: Planning, control and reporting
- Technology: One platform, one data model

## Capabilities we need
| Capability | Today | Target | Owner |
|---|---|---|---|
| Demand planning | Spreadsheets per category | One statistical forecast | Supply chain |
| Pricing | Manual price changes | Rules and one price everywhere | Merchandising |
| Fulfilment | DC only | DC, store and pickup | Stores and digital |
| Close and reporting | Ten-day close | Five-day close | Finance |

## Who decides what
| Decision | Responsible | Accountable | Consulted |
|---|---|---|---|
| Range and listing | Category manager | Chief merchant | Space planning |
| Price changes | Pricing analyst | Merchant | Finance |
| Stock targets | Replenishment | Supply chain lead | Merchandising |
| Technology changes | Product owner | CIO | Architecture board |

## Governance rhythm
Layout: process cycle
- Plan: quarterly priorities
- Decide: monthly steering
- Deliver: two-week sprints
- Review: KPIs every week
