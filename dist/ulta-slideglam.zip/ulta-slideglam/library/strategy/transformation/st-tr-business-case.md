---
id: st-tr-business-case
domain: Strategy
l1: Transformation
l2: Business case
summary: The investment case: value in big numbers, benefits by driver, costs, payback and the decision asked for.
systems: 
tags: business case, ROI, payback, NPV, investment, benefits
order: 203
---
# Business case

## The case in four numbers
Layout: four numbers
- Investment: $12.0M over two years
- Annual benefit: $5.5M from year three
- Payback: 2.8 years from go-live
- Net present value: $9.4M over five years
> Notes: illustrative figures - replace every number with your own model before sharing.

## Where the value comes from
| Benefit | Driver | Annual value | Confidence |
|---|---|---|---|
| Lower stock | Automatic replenishment | [value] | High |
| More sales | Fewer out-of-stocks | [value] | Medium |
| Lower labour | Scan-based receiving | [value] | High |
| Lower freight | Fuller trucks | [value] | Medium |

## Costs and timing
| Cost | Year 1 | Year 2 | Run cost per year |
|---|---|---|---|
| Software and cloud | [cost] | [cost] | [cost] |
| Implementation partner | [cost] | [cost] | - |
| Internal team | [cost] | [cost] | [cost] |
| Change and training | [cost] | [cost] | - |

## Options considered
### Do nothing
- No investment, no benefit
- Manual work grows with volume
### Recommended
- Phased rollout over two years
- Benefits start in the pilot

## The decision
- Decision: Approve the investment and the phased plan
- Ask: Release the year-one budget
- Next step: Mobilise the team next month
