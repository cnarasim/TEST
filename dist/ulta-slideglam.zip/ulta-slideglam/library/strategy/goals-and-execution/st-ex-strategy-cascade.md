---
id: st-ex-strategy-cascade
domain: Strategy
l1: Goals and Execution
l2: Strategy cascade
summary: From the company strategy to every team: the cascade of goals, how each team contributes, the alignment check and the review rhythm.
systems: Goal tracking
tags: strategy cascade, alignment, goal cascade, hoshin, objectives, team goals, strategy
order: 603
---
# Strategy cascade

## From strategy to every team
Layout: pyramid
- Company: vision and three strategic priorities
- Functions: objectives that deliver the priorities
- Teams: key results each team owns
- People: personal goals linked to the team's

## How each function contributes
| Priority | Stores | Digital | Supply chain | People |
|---|---|---|---|---|
| Guest first | Service standards | One profile | On-time pickup | Service training |
| Winning assortment | Space by cluster | Content and reviews | In stock | Category experts |
| Stores as hubs | Pickup and services | Pickup slots | Ship from store | New roles |

## The alignment check
Layout: process numbered
- Draft: functions draft objectives
- Link: each objective names its priority
- Check: gaps and overlaps reviewed together
- Commit: leaders sign the cascade

## The rhythm
Layout: process cycle
- Plan: annual cascade
- Track: monthly results
- Review: quarterly priorities
- Adjust: re-cascade where needed
