---
id: st-ex-balanced-scorecard
domain: Strategy
l1: Goals and Execution
l2: Balanced scorecard
summary: Strategy measured four ways - financial, guest, internal process, learning and growth - with targets, actuals and the links between them.
systems: Reporting, Finance system
tags: balanced scorecard, scorecard, kpis, performance management, strategy map, measures
workbook: scorecard
order: 602
---
# Balanced scorecard

## Four perspectives
Layout: matrix
- Financial: grow sales and margin
- Guest: be the first choice for beauty
- Internal process: fast, reliable fulfilment
- Learning and growth: skilled, engaged teams

## The scorecard
| Measure | Perspective | Target | Actual | Status |
|---|---|---|---|---|
| Comparable sales growth | Financial | 4.0% | 4.1% | Met |
| Operating margin | Financial | 14.0% | 13.6% | Below |
| Guest satisfaction | Guest | 85% | 86% | Met |
| Order fill rate | Internal process | 97% | 95% | Below |
| Associate engagement | Learning and growth | 80% | 78% | Below |
> Notes: illustrative figures.

## How the perspectives connect
Layout: pyramid
- Financial: results follow from guests
- Guest: guests follow from great service
- Internal process: service follows from processes
- Learning and growth: processes follow from people

## Where we act
- Decision: Fill rate and engagement are next quarter's focus
- Ask: Supply chain and people teams own a plan each
- Next step: Review the scorecard monthly
