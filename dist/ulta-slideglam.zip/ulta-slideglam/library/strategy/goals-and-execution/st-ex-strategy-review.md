---
id: st-ex-strategy-review
domain: Strategy
l1: Goals and Execution
l2: Quarterly strategy review
summary: Is the strategy working: results against goals, what changed outside, what we learned, the priorities to keep or change, and decisions.
systems: Reporting
tags: strategy review, quarterly review, strategy refresh, priorities, performance review, strategy
order: 605
---
# Quarterly strategy review

## Results against goals
Layout: scorecard
### Growth
- Comparable sales: 3.6% | 4.0% | 4.1% | green
- Member spend: $290 | $310 | $298 | amber
### Experience
- Guest satisfaction: 84% | 85% | 86% | green
- Pickup in 2 hours: 80% | 90% | 84% | amber
> Notes: illustrative - each line is last quarter | target | this quarter | status.

## What changed outside
Layout: cards
- Guests: more value seeking in two categories
- Competitors: faster delivery from online players
- Costs: shipping rates up 6%

## What we learned
### Working
- Pickup is now the favourite way to shop online
- Services bring guests back
### Not yet
- Member spend lags in value categories
- Fill rate holds back pickup speed

## Priorities: keep, change, stop
| Priority | Call | Why |
|---|---|---|
| Same-day from stores | Keep | Ahead of plan |
| Value tier | Change | Bring forward one quarter |
| Kiosk refresh | Stop | Low guest use |

## Decisions
- Decision: Bring the value tier forward and stop the kiosk refresh
- Ask: Fill-rate plan from supply chain in four weeks
- Next step: Next review in one quarter
