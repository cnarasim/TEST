---
id: st-ex-initiative-portfolio
domain: Strategy
l1: Goals and Execution
l2: Strategic initiatives portfolio
summary: The handful of initiatives that deliver the strategy: what each is, its owner, timing, value and status, and the trade-offs between them.
systems: Portfolio management
tags: strategic initiatives, initiatives, must win battles, portfolio, transformation, strategy execution
workbook: status
order: 604
---
# Strategic initiatives portfolio

## Initiatives on a page
| Initiative | Owner | Value | Status |
|---|---|---|---|
| Same-day from stores | Supply chain | $40M | Green |
| One guest profile | Digital | $25M | Amber |
| Services academy | People | $10M | Green |
| Value tier | Merchandising | $15M | Amber |
| Store format pilot | Stores | Option | Green |

## When they land
Layout: gantt
- Same-day from stores: Jan 2027 – Sep 2027 (Supply chain)
- One guest profile: Feb 2027 – Dec 2027 (Digital)
- Services academy: Mar 2027 – Aug 2027 (People)
- Value tier: Apr 2027 – Oct 2027 (Merchandising)
- Format pilot opens: Nov 1, 2027 (Stores)

## Value against effort
Layout: matrix
- Quick wins: high value, low effort - services academy
- Big bets: high value, high effort - same-day, guest profile
- Fill-ins: lower value, low effort - value tier
- Question marks: lower value, high effort - none this year

## Trade-offs
- Decision: Guest profile keeps priority over the value tier for data people
- Ask: One leader owns each initiative end to end
- Next step: Monthly initiative review with the leadership team
