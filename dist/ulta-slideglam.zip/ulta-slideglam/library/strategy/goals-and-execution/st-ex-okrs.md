---
id: st-ex-okrs
domain: Strategy
l1: Goals and Execution
l2: OKRs (objectives and key results)
summary: Objectives and measurable key results for the quarter: what we aim for, how we measure it, progress so far and the initiatives behind it.
systems: Goal tracking
tags: okr, okrs, objectives and key results, goals, key results, quarterly goals, strategy
workbook: scorecard
order: 601
---
# OKRs

## Our objectives this quarter
Layout: cards
- Guests: make pickup the easiest way to shop
- Growth: win more of our members' beauty spend
- Team: build the skills for the new model

## Key results
| Key result | Target | Actual | Status |
|---|---|---|---|
| Pickup orders ready in 2 hours | 90% | 84% | Below |
| Pickup share of online orders | 45% | 46% | Met |
| Member spend per year | $310 | $298 | Below |
| Associates certified | 80% | 82% | Met |
> Notes: illustrative - each key result is a number with a target, scored monthly.

## Progress to target
Layout: rings
- Pickup ready in 2 hours: 93%
- Member spend: 96%
- Associates certified: 100%

## Initiatives behind each objective
| Objective | Initiative | Owner |
|---|---|---|
| Pickup | Pickup slots and live status | Digital |
| Growth | Routine-based member offers | Marketing |
| Team | New service academy | People |
