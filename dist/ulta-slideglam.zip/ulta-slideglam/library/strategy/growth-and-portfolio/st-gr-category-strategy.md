---
id: st-gr-category-strategy
domain: Strategy
l1: Growth and Portfolio
l2: Category strategy
summary: The plan for one category: its role, guest and market insights, the assortment, price, promotion and space levers, and the targets.
systems: Merchandise planning, Reporting
tags: category strategy, category management, category role, assortment, merchandising, retail strategy
order: 504
---
# Category strategy

## The category's role
Layout: matrix
- Destination: guests come for it - lead on range and expertise
- Routine: bought regularly - be easy and reliable
- Seasonal: moments in the year - win the peaks
- Convenience: add-on purchase - make it easy to grab

## What guests and the market tell us
### Guests
- Want routines, not single products
- Read reviews before buying
### Market
- Growing 7% a year
- New brands win online first
### Us
- Strong in prestige, gaps in value
- Online share below market

## The levers
| Lever | Today | Next year |
|---|---|---|
| Assortment | 1,200 items | 1,100 items, 80 new brands |
| Price | Prestige-led | Add a value tier |
| Promotion | Event-led | Member offers by routine |
| Space | Same in every store | By store cluster |

## Targets
Layout: kpi cards
- Category sales: $1.2B (+7%)
- Online share: 32% (+5 pts)
- New brand sales: 12% (+4 pts)
> Notes: illustrative targets.
