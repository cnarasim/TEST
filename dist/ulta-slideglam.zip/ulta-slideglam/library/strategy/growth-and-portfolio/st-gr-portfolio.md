---
id: st-gr-portfolio
domain: Strategy
l1: Growth and Portfolio
l2: Investment portfolio review
summary: Where the money goes: the portfolio by value and risk, by theme, the invest / hold / exit calls and the rebalancing decision.
systems: Portfolio management, Finance system
tags: portfolio, investment portfolio, capital allocation, invest hold exit, rebalancing, strategy
order: 503
---
# Investment portfolio review

## The portfolio by value and risk
Layout: matrix
- Invest: high value, low risk - accelerate
- Bet carefully: high value, high risk - stage the funding
- Hold: lower value, low risk - keep efficient
- Exit: lower value, high risk - stop and release the money

## Investment by theme
Layout: treemap
- Guest experience: 38
- Supply chain: 30
- Stores: 18
- Back office: 14
> Notes: $ millions this year, illustrative.

## Invest, hold or exit
| Initiative | Value | Risk | Call |
|---|---|---|---|
| Same-day delivery | High | Medium | Invest |
| DC automation | High | High | Bet carefully |
| Store kiosk refresh | Low | Low | Hold |
| Legacy marketplace | Low | High | Exit |

## Rebalancing
- Decision: Move $4M from exits to same-day delivery
- Ask: Stage DC automation funding by milestone
- Next step: Portfolio review every quarter
