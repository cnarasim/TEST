---
id: st-gr-three-horizons
domain: Strategy
l1: Growth and Portfolio
l2: Three horizons
summary: Balancing today and tomorrow: defend and extend the core, build emerging businesses, create future options - and how we fund each.
systems: 
tags: three horizons, horizons, innovation portfolio, core, emerging, future, strategy
order: 502
---
# Three horizons

## Three horizons on one timeline
Layout: timeline vertical
- Horizon 1 - Core: Jan 2027 – Dec 2027 (Defend and extend today's business)
- Horizon 2 - Emerging: Jan 2027 – Dec 2028 (Build businesses that are starting to grow)
- Horizon 3 - Future: Jan 2028 – Dec 2030 (Create options for the long term)

## What sits in each horizon
| Horizon | Initiatives | Measure of success | Share of investment |
|---|---|---|---|
| Core | Stores, loyalty, replenishment | Sales, margin | 70% |
| Emerging | Services, wellness, retail media | Growth rate | 20% |
| Future | New formats, new markets | Options proven | 10% |

## How we fund the horizons
Layout: donut
- Core: 70% of investment
- Emerging: 20% of investment
- Future: 10% of investment

## How we manage each
### Core
- Annual budgets, efficiency targets
### Emerging
- Stage funding against growth milestones
### Future
- Small bets, fast learning, kill quickly
