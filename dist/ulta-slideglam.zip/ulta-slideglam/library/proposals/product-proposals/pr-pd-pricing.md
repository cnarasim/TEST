---
id: pr-pd-pricing
domain: Proposals
l1: Product Proposals
l2: Pricing proposal
summary: A change to prices or price structure: why, the options, the impact on volume, sales and margin, guest and competitor reaction, and the decision.
systems: Pricing engine, Reporting
tags: pricing proposal, price change, price increase, price architecture, margin, elasticity, proposal
order: 104
---
# Pricing proposal

## Why change the price
### Cost
- Supplier costs up 6%
### Market
- Competitors moved 3% to 5%
### Guests
- Value perception strong in this category

## The options
| Option | What changes | Volume | Sales | Margin |
|---|---|---|---|---|
| Hold | No change | +0% | +0% | -1.8 pts |
| Targeted | +4% on top 50 items | -1% | +2.5% | +0.4 pts |
| Across the board | +5% on all items | -3% | +1.8% | +0.9 pts |
> Notes: illustrative - from the elasticity model, before promotions.

## Impact of the recommended option
Layout: kpi cards
- Sales: +2.5% (+$6M)
- Margin: +0.4 pts
- Volume: -1% (within plan)
> Notes: illustrative.

## How guests and competitors may react
Layout: matrix
- Guests notice: top items - keep member prices
- Guests do not notice: long tail - no action
- Competitors follow: likely in two categories - monitor weekly
- Competitors hold: risk on key items - price match list ready

## The ask
- Decision: Targeted increase on the top 50 items from March 1
- Ask: Keep member prices on the top 10 for one quarter
- Next step: Weekly sales and share read for eight weeks
