---
id: pr-pc-a3
domain: Proposals
l1: Process Proposals
l2: A3 problem solving
summary: One problem on one page, the A3 way: background, current condition, goal, root cause, countermeasures, plan and follow-up.
systems: 
tags: a3, problem solving, lean, root cause, countermeasures, pdca, proposal
workbook: actions
order: 204
---
# A3 problem solving

## Background and current condition
### Background
- Online orders picked in stores
### Current condition
- 14% of pickup orders not ready on time
### Why it matters
- Guests wait, satisfaction drops 20 points

## The goal
Layout: kpi cards
- Orders ready on time: 95% (from 86%)
- Guest wait: 2 minutes (from 9)
- Stores: 10 in the pilot (then all)
> Notes: illustrative targets - due by the end of next quarter.

## Root cause
Layout: process converge
- People: picking competes with the till at peaks
- Process: no priority for orders close to due
- Stock: system stock wrong on 3% of items
- Result: Orders picked late or short at busy hours

## Countermeasures
| Cause | Countermeasure | Owner |
|---|---|---|
| Picking at peaks | A picking hour blocked in every schedule | Store operations |
| No priority | Orders sorted by due time on the handheld | Digital |
| Stock wrong | Daily count of top 200 pickup items | Inventory |

## Plan and follow-up
| Action | Owner | Due | Status |
|---|---|---|---|
| Picking hour in schedules | Store operations | Week 2 | Open |
| Due-time sort released | Digital | Week 4 | Open |
| Daily counts started | Inventory | Week 1 | Open |
| Check results | Project lead | Week 8 | Open |

## Plan, do, check, act
Layout: process cycle
- Plan: countermeasures agreed
- Do: pilot in ten stores
- Check: on-time rate weekly
- Act: standardise or adjust
