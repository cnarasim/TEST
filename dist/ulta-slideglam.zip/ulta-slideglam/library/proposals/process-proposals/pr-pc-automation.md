---
id: pr-pc-automation
domain: Proposals
l1: Process Proposals
l2: Automation proposal
summary: Automating manual work: which tasks, the automation approach, volumes and savings, controls, the business case and the rollout.
systems: Workflow tool, Automation platform, ERP
tags: automation, rpa, automate, manual work, efficiency, bots, proposal
workbook: budget
order: 202
---
# Automation proposal

## The manual work today
| Task | Volume a month | Minutes each | Hours a month |
|---|---|---|---|
| Vendor invoice keying | 18,000 | 4 | 1,200 |
| Price change uploads | 2,500 | 6 | 250 |
| Store transfer requests | 6,000 | 3 | 300 |

## How we automate it
Layout: process io
- Input: Invoices, price files, transfer requests
- Input: Business rules agreed with each team
- Build: Read, check and post automatically
- Output: Exceptions only go to people
- Output: Every step logged for audit

## The savings
Layout: four numbers
- Hours saved: 1,450 a month
- Cost saved: $520K a year
- Payback: 9 months
- Accuracy: 99.5% straight through
> Notes: illustrative figures.

## Controls stay in place
| Control | How it works with automation |
|---|---|
| Approval limits | Rules route anything above the limit to a person |
| Segregation of duties | The automation cannot approve its own work |
| Audit trail | Every action logged with time and rule |

## Rollout
Layout: timeline quarters
- Invoices: Jan 2027 – Mar 2027 (Finance)
- Price changes: Apr 2027 – May 2027 (Merchandising)
- Transfers: Jun 2027 – Aug 2027 (Supply chain)

## The ask
- Decision: Automate the three tasks in this order
- Ask: $380K one-off and one automation lead
- Next step: Start with invoices in January
