---
id: pr-pc-dmaic
domain: Proposals
l1: Process Proposals
l2: Improvement project (DMAIC)
summary: A structured improvement project: define, measure, analyse, improve and control - with the problem, data, causes, solutions and the control plan.
systems: Reporting, Process documentation
tags: dmaic, six sigma, lean six sigma, improvement project, process improvement, control plan, proposal
workbook: actions
order: 205
---
# Improvement project (DMAIC)

## Five phases
Layout: process phases
- Define: problem; scope; goal (Weeks 1-2)
- Measure: baseline; data (Weeks 3-5)
- Analyse: root causes (Weeks 6-8)
- Improve: solutions; pilot (Weeks 9-12)
- Control: standard; monitor (Weeks 13-14)

## Define
### Problem
- Invoice exceptions take 6 days to clear
### Scope
- Vendor invoices with a price or quantity difference
### Goal
- Clear 90% within 2 days

## Measure
Layout: kpi cards
- Exceptions: 4,200 a month
- Days to clear: 6.1 on average
- Share over 5 days: 48%
> Notes: illustrative baseline.

## Analyse: the main causes
Layout: ranking
- Price not updated: 41
- Partial deliveries: 27
- Wrong unit of measure: 18
- Duplicate invoices: 9
> Notes: share of exceptions by cause, %.

## Improve
| Cause | Solution | Expected effect |
|---|---|---|
| Price not updated | Vendor price updates before the order | -35% exceptions |
| Partial deliveries | Match at line level | -20% exceptions |
| Unit of measure | One unit agreed per item | -15% exceptions |

## Control plan
| Measure | Target | How often | Owner |
|---|---|---|---|
| Exceptions a month | Under 1,500 | Weekly | AP lead |
| Days to clear | Under 2 | Weekly | AP lead |
| Price updates on time | 98% | Monthly | Merchandising |
