---
id: pr-fp-partnership
domain: Proposals
l1: Funding and Partnerships
l2: Partnership proposal
summary: Proposing a partnership: the shared opportunity, what each side brings and gets, the model, governance, terms to agree and next steps.
systems: 
tags: partnership, partner proposal, alliance, collaboration, joint venture, brand partner, proposal
order: 302
---
# Partnership proposal

## The shared opportunity
Layout: four numbers
- Joint guests: 12M in common
- Opportunity: $60M a year in new sales
- Time to launch: 6 months
- Term: 3 years to start
> Notes: illustrative figures.

## What each side brings and gets
### We bring
- Stores, members, services
### They bring
- Products, content, community
### We both get
- New guests, more visits, shared data insights

## How it works
Layout: process chevrons
- Agree: scope and terms
- Build: offer and content
- Launch: stores and online
- Grow: shared plan each quarter

## Governance
| Forum | Who | How often | Decides |
|---|---|---|---|
| Executive sponsors | One leader each side | Quarterly | Direction, renewal |
| Joint team | Leads from both sides | Monthly | Plan, results, issues |
| Working teams | Marketing, merchandising, data | Weekly | Delivery |

## Terms to agree
| Term | Our position | Status |
|---|---|---|
| Exclusivity | Category exclusive for 12 months | Open |
| Data sharing | Aggregated insights only | Agreed |
| Funding | Shared marketing 50/50 | Open |

## Next steps
- Decision: Proceed to term sheet
- Ask: Legal and finance join the next meeting
- Next step: Signed term sheet in six weeks
