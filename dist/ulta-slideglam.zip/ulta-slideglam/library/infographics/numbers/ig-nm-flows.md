---
id: ig-nm-flows
domain: Infographics
l1: Numbers
l2: Flows of volume (sankey)
summary: How volume flows from source to destination: orders by channel to fulfilment path.
systems: 
tags: sankey, flow, volume, channel mix, fulfilment mix
order: 106
---
# Flows of volume

## How online orders are fulfilled
Layout: sankey
- App → Ship from DC: 120
- App → Pickup in store: 80
- Site → Ship from DC: 210
- Site → Ship from store: 60
- Site → Pickup in store: 90
> Notes: illustrative figures. "A → B: value" lines under "Layout: sankey" become a sankey.
