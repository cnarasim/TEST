---
id: ig-nm-ranking
domain: Infographics
l1: Numbers
l2: Ranking and comparison
summary: Items ranked by size as a lollipop, bullet charts against target, and bubbles for relative size.
systems: 
tags: ranking, lollipop, bullet chart, bubbles, league table
order: 105
---
# Ranking and comparison

## Regions by pickup orders
Layout: ranking
- Southeast: 48200
- Midwest: 41500
- West: 39800
- Northeast: 33100
- Southwest: 27600
> Notes: illustrative figures.

## Stores against target
Layout: bullet
- Store 101: 96 of 100
- Store 214: 88 of 100
- Store 330: 104 of 100
- Store 412: 79 of 100

## Category size
Layout: bubbles
- Cosmetics: 42
- Skincare: 21
- Haircare: 17
- Fragrance: 13
