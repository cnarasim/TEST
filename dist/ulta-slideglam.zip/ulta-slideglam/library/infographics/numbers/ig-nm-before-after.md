---
id: ig-nm-before-after
domain: Infographics
l1: Numbers
l2: Before and after
summary: A before / after dumbbell by channel and a slope for the change over time.
systems: 
tags: before after, dumbbell, slope, improvement, change
order: 103
---
# Before and after

## Fill rate by channel
- ulta.com: 88% → 96%
- Stores: 84% → 91%
- App: 79% → 93%
- B2B: 70% → 82%
> Notes: illustrative figures. A list of "Label: before → after" becomes a dumbbell chart with its takeaway in the headline.

## Inventory accuracy by DC
Layout: slope
- North DC: 91% to 98%
- South DC: 88% to 97%
- West DC: 93% to 96%
