---
id: ig-nm-scorecard
domain: Infographics
l1: Numbers
l2: KPI scorecard
summary: A grouped KPI scorecard with prior, target, actual and status on the template scorecard slide.
systems: 
tags: scorecard, KPI, RAG, status, monthly review
order: 102
---
# KPI scorecard

## Monthly scorecard
Layout: scorecard
### Sales
- Comparable sales: 3.1% | 4.0% | 4.4% | green
- Conversion: 30.2% | 31.0% | 31.5% | green
### Service
- Fill rate: 92% | 95% | 96% | green
- Pickup time: 2.6 h | 2.0 h | 2.1 h | amber
### Cost
- Cost per order: $6.10 | $5.80 | $6.30 | red
> Notes: illustrative figures - each line is prior | target | actual | status.
