---
id: ig-nm-big-numbers
domain: Infographics
l1: Numbers
l2: Big numbers and KPI cards
summary: Four big numbers on the template, three KPI cards with change, progress rings for targets.
systems: 
tags: big numbers, KPI cards, rings, headline numbers, results
order: 101
---
# Results at a glance

## The quarter in four numbers
Layout: four numbers
- Net sales: $4.6M in pickup orders
- Conversion: 31.5% of app visits
- Pickup time: 2.1 hours from order to ready
- Members: 1.2M active in the programme
> Notes: illustrative figures - replace them with your own.

## Three KPIs that moved
Layout: kpi cards
- Fill rate: 96% (+8 pts)
- Order cycle time: 2.1 hours (-0.6 h)
- Cancellations: 1.6% (+0.2 pts)

## Progress to target
Layout: rings
- Stores live: 82%
- Associates trained: 74%
- Lockers installed: 45%
