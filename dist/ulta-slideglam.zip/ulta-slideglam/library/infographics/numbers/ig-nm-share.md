---
id: ig-nm-share
domain: Infographics
l1: Numbers
l2: Share of the total
summary: Shares that add to 100% on the template donut, a treemap for many parts and a waffle for one share.
systems: 
tags: donut, share, mix, treemap, waffle, percent
order: 104
---
# Share of the total

## Where pickup orders come from
- Stores: 62% of pickup orders
- Ulta.com: 27% of pickup orders
- App: 11% of pickup orders
> Notes: illustrative figures. Shares that add up to 100% become the template donut.

## Sales by category
Layout: treemap
- Cosmetics: 42
- Skincare: 21
- Haircare: 17
- Fragrance: 13
- Services: 7

## Members who shop in two channels
Layout: waffle
- Omnichannel members: 38%
