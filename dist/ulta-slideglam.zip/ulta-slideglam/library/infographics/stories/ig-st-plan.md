---
id: ig-st-plan
domain: Infographics
l1: Stories
l2: Plan on a page (Gantt and status)
summary: A Gantt by team with milestones, and a status roadmap with owners and RAG.
systems: 
tags: gantt, plan, timeline, status, milestones, project plan
order: 204
---
# Plan on a page

## Delivery plan by team
Layout: gantt
- Store readiness: Jan 2027 – Mar 2027 (Stores)
- App pickup flow: Feb 2027 – Apr 2027 (Digital)
- Lockers in 300 stores: Apr 2027 – Jul 2027 (Stores)
- Member default: May 2027 – Aug 2027 (Digital)
- Go-live for members: Sep 1, 2027 (Digital)
> Notes: example dates; "(Team)" names the workstream, a single date is a milestone.

## Status by deliverable
Layout: timeline status-roadmap
- Pilot store selection: Jan 2027 – Feb 2027 (Store ops) done
- Associate training: Mar 2027 – Apr 2027 (Store ops) on track
- Demand model tuning: Feb 2027 – May 2027 (Supply chain) at risk
- Shelf-label hardware: Apr 2027 – Jun 2027 (Stores IT) late
