---
id: ig-st-shapes
domain: Infographics
l1: Stories
l2: Pyramid, cycle, hub and hexagons
summary: The Studio's drawn infographics: a pyramid that builds, a cycle that repeats, a hub and a honeycomb.
systems: 
tags: pyramid, cycle, hub, hexagons, honeycomb, shapes
order: 203
---
# Shapes that tell the story

## Capabilities build on each other
Layout: pyramid
- Insight: decisions from data
- Automation: rules do the routine
- Process: one standard way
- Data: clean and shared

## The improvement loop
Layout: cycle
- Measure: KPIs every week
- Analyse: find the cause
- Improve: change the process
- Control: keep the gain

## One platform, many teams
Layout: hub
- ERP: the core
- Merchandising: range and price
- Supply chain: stock and flow
- Stores: service and sales
- Finance: plan and report

## Six principles
Layout: hexagons
- Guest first: every decision
- Simple: fewer steps
- Standard: best practice first
- Data: one version
- Secure: by design
- Measured: KPIs on every change
