---
id: ig-st-map
domain: Infographics
l1: Stories
l2: Store and DC map
summary: Pins on the template US map for regions, DCs or pilot stores, each with its one-line story.
systems: 
tags: map, US map, regions, stores, DCs, locations
order: 202
---
# Where it happens

## Regions leading the rollout
- Seattle, WA: 120 stores, same-day in 2 hours
- Dallas, TX: largest region, 140 stores
- Chicago, IL: new distribution centre opens in May
- Orlando, FL: pickup orders up 18%
> Notes: illustrative content. One to four "City, ST: text" lines become pins on the template map.
