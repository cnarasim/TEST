---
id: ig-st-funnel
domain: Infographics
l1: Stories
l2: Funnel and conversion
summary: The template funnel for stages that narrow and a pipeline with the share that moves on at each stage.
systems: 
tags: funnel, conversion, pipeline, stages
order: 201
---
# Funnel and conversion

## From visit to repeat purchase
Layout: template funnel
- Visit the app or site
- Add to bag
- Check out
- Buy again within 90 days

## Conversion at each stage
Layout: process pipeline
- Visits: 1.2M (38%)
- Bags: 456K (41%)
- Orders: 187K (34%)
- Repeat buyers: 64K
> Notes: illustrative figures - each stage shows its volume and the share that moves on.
