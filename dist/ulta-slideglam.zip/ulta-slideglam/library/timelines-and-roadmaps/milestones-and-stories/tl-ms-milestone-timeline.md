---
id: tl-ms-milestone-timeline
domain: Timelines and Roadmaps
l1: Milestones and Stories
l2: Milestone timeline
summary: The milestones of a programme as a story: what was achieved, what comes next, and the moments that changed the plan.
systems: Project plan
tags: milestones, milestone timeline, achievements, key dates, progress story, timeline
order: 301
---
# Milestone timeline

## Milestones so far
Layout: timeline template-milestones
- Programme approved: Jan 15, 2027 (Leadership)
- Pilot stores live: Apr 30, 2027 (Stores)
- First region live: Jul 31, 2027 (Stores)
- All regions live: Oct 31, 2027 (Stores)

## The story so far
Layout: timeline storyline
- We started: Jan 15, 2027 (Approved with a pilot first)
- We learned: Apr 30, 2027 (Pilot showed a simpler flow works)
- We scaled: Jul 31, 2027 (First region in eight weeks)
- We finished: Oct 31, 2027 (Every store, on budget)

## Results at each milestone
Layout: kpi cards
- Pickup time: 2.1 hours (from 5 hours)
- Stores live: 1,350 (of 1,350)
- Guest rating: 4.6 of 5 (+0.4)
> Notes: illustrative figures.

## What comes next
Layout: timeline now-next-later
- Same-day delivery: Jan 2028 – Mar 2028 (Digital)
- Lockers in top stores: Feb 2028 – May 2028 (Stores)
- Returns at pickup: Jun 2028 – Sep 2028 (Stores)
