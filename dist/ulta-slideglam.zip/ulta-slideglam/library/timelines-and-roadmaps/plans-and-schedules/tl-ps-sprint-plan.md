---
id: tl-ps-sprint-plan
domain: Timelines and Roadmaps
l1: Plans and Schedules
l2: Sprint and release plan
summary: Sprints and releases for an agile team: the sprint timeline, what each sprint delivers, release dates and the team rhythm.
systems: Work management tool, Product backlog
tags: sprint plan, release plan, agile, scrum, iterations, releases, timeline
order: 202
---
# Sprint and release plan

## Sprints at a glance
Layout: timeline sprints
- Sprint 1: Jan 4, 2027 – Jan 15, 2027 (Search)
- Sprint 2: Jan 18, 2027 – Jan 29, 2027 (Search)
- Sprint 3: Feb 1, 2027 – Feb 12, 2027 (Lists)
- Sprint 4: Feb 15, 2027 – Feb 26, 2027 (Lists)
- Release 1: Mar 1, 2027 (Search and lists)

## What each sprint delivers
| Sprint | Goal | Key stories | Demo |
|---|---|---|---|
| Sprint 1 | Search understands typos | Typo tolerance, synonyms | Jan 15 |
| Sprint 2 | Filters that help | Shade and skin type filters | Jan 29 |
| Sprint 3 | Save for later | Lists, add from search | Feb 12 |
| Sprint 4 | Share and reorder | Share a list, reorder | Feb 26 |

## Release calendar
Layout: timeline calendar
- Release 1: Mar 1, 2027 (Search and lists)
- Release 2: Apr 12, 2027 (Reorder)
- Release 3: May 24, 2027 (Pickup slots)
- Holiday freeze: Nov 15, 2027 (All)

## The team rhythm
Layout: process cycle
- Plan: sprint goal and stories
- Build: daily stand-up
- Review: demo to stakeholders
- Improve: retrospective
