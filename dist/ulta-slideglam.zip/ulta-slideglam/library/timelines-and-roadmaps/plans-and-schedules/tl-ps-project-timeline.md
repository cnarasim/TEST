---
id: tl-ps-project-timeline
domain: Timelines and Roadmaps
l1: Plans and Schedules
l2: Project timeline
summary: The project on one timeline: phases, the template Gantt, workstream lanes, key dates and the countdown to go-live.
systems: Project plan
tags: project timeline, gantt, schedule, phases, plan, countdown, timeline
workbook: status
order: 201
---
# Project timeline

## Phases
Layout: timeline phases
- Mobilise: Jan 2027 – Feb 2027 (Project)
- Design: Mar 2027 – May 2027 (Project)
- Build: Jun 2027 – Aug 2027 (Project)
- Test: Aug 2027 – Oct 2027 (Project)
- Deploy: Nov 2027 – Dec 2027 (Project)

## The plan
Layout: timeline template-gantt
- Process design: Mar 2027 – May 2027 (Business)
- Solution build: Jun 2027 – Aug 2027 (Technology)
- Data migration: May 2027 – Oct 2027 (Data)
- Testing: Aug 2027 – Oct 2027 (Business)
- Training: Sep 2027 – Nov 2027 (Change)

## Key dates
| Milestone | Baseline | Forecast | Status |
|---|---|---|---|
| Design signed off | May 28, 2027 | May 28, 2027 | On track |
| Build complete | Aug 27, 2027 | Sep 10, 2027 | At risk |
| Go / no-go | Nov 1, 2027 | Nov 1, 2027 | On track |
| Go-live | Nov 9, 2027 | Nov 9, 2027 | On track |

## Countdown to go-live
Layout: timeline countdown
- Final trial load: Oct 15, 2027 (Data)
- Dress rehearsal: Oct 22, 2027 (Project)
- Go / no-go: Nov 1, 2027 (Steering)
- Go-live: Nov 9, 2027 (Project)
