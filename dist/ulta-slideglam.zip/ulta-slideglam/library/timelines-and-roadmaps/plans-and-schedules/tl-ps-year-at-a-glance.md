---
id: tl-ps-year-at-a-glance
domain: Timelines and Roadmaps
l1: Plans and Schedules
l2: Year at a glance
summary: The business calendar for the year: key events, seasons and peaks, planning cycles, change freezes and the quarterly rhythm.
systems: Planning calendar
tags: year at a glance, calendar, annual plan, key dates, events, peak season, timeline
order: 204
---
# Year at a glance

## Key dates
Layout: timeline calendar
- Spring launch: Mar 1, 2027 (Merchandising)
- Member event: May 6, 2027 (Marketing)
- Mid-year review: Jul 15, 2027 (Leadership)
- Holiday set: Oct 1, 2027 (Stores)
- Change freeze: Nov 15, 2027 (Technology)
- Year-end close: Jan 31, 2028 (Finance)

## Seasons and peaks
Layout: timeline quarters
- Spring: Feb 2027 – Apr 2027 (Peak)
- Summer: May 2027 – Jul 2027 (Steady)
- Back to school: Aug 2027 – Sep 2027 (Steady)
- Holiday: Oct 2027 – Dec 2027 (Peak)

## Planning cycles
| Cycle | When | Who | Output |
|---|---|---|---|
| Annual plan | Sep - Nov | Leadership, finance | Budget and targets |
| Quarterly review | Each quarter, week 3 | Leadership | Priorities re-set |
| Monthly business review | Each month, week 2 | Function heads | Actions and forecast |

## Quiet periods
- Change freeze: Nov 15 to Jan 10 - no system changes
- Store freeze: holiday weeks - no store resets
- Close weeks: first week of every quarter - finance focus
