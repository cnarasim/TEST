---
id: tl-ps-launch-countdown
domain: Timelines and Roadmaps
l1: Plans and Schedules
l2: Launch countdown
summary: The weeks before a launch: the countdown, what must be ready by when, owners, the launch-day run sheet and the go decision.
systems: Launch plan, Project plan
tags: launch, countdown, go live, launch plan, readiness, run sheet, timeline
workbook: actions
order: 203
---
# Launch countdown

## Counting down
Layout: timeline countdown
- Content final: Apr 24, 2027 (Marketing)
- Stock in DCs: May 1, 2027 (Supply chain)
- Stores set: May 12, 2027 (Stores)
- Launch: May 15, 2027 (All)

## Ready by when
| Item | Owner | Due | Status |
|---|---|---|---|
| Campaign creative approved | Marketing | Week -4 | Done |
| Product content online | Digital | Week -2 | On track |
| Stock in every DC | Supply chain | Week -2 | On track |
| Fixtures set in stores | Stores | Week -1 | At risk |
| Associates briefed | Store operations | Week -1 | On track |

## Launch day
Layout: timeline storyline
- Site goes live: May 15, 2027 (6:00 Digital)
- Stores open with the launch: May 15, 2027 (9:00 Stores)
- First results call: May 15, 2027 (13:00 All)
- Day-one report: May 15, 2027 (18:00 Insights)

## The go decision
- Decision: Launch on May 15 if stock is in every DC by May 1
- Ask: Stores confirm fixtures by May 12
- Next step: Daily stand-up from week -2
