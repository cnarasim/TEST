---
id: tl-rm-status-roadmap
domain: Timelines and Roadmaps
l1: Roadmaps
l2: Roadmap status review
summary: Where every roadmap item stands: done, on track, at risk or late, what moved since last time, and the calls to make.
systems: Roadmap tool, Project plan
tags: roadmap status, status review, progress, on track, at risk, timeline, RAG
workbook: status
order: 104
---
# Roadmap status review

## Status by item
Layout: timeline status-roadmap
- Smarter search: Jan 2027 – Mar 2027 (Digital) done
- Pickup slots: Feb 2027 – May 2027 (Stores) on track
- Store replenishment: Jan 2027 – Jun 2027 (Supply chain) at risk
- Member challenges: Mar 2027 – Jun 2027 (Marketing) late

## The roadmap in four numbers
Layout: four numbers
- Items: 24 on the roadmap
- On track: 17 of 24
- At risk: 5 items
- Late: 2 items
> Notes: illustrative figures.

## What moved since last review
| Item | Was | Now | Why |
|---|---|---|---|
| Store replenishment | Q2 | Q3 | Data quality in two regions |
| Member challenges | Q2 | Q3 | Rules engine delivery |
| Saved lists | Q3 | Q2 | Re-used search work |

## Calls to make
- Decision: Accept the new date for store replenishment
- Ask: One more data engineer for two months
- Next step: Re-baseline at the next portfolio review
