---
id: ea-cs-tco
domain: Enterprise Architecture
l1: Compare and Select
l2: Total cost of ownership comparison
summary: Every cost of each option over three to five years: one-time, run and hidden costs, compared on the same scope.
systems: Financial planning
tags: TCO, total cost of ownership, cost comparison, run cost, licence, subscription
order: 205
---
# Total cost of ownership comparison

## What goes into the cost
Layout: process io
- Input: Licences or subscriptions
- Input: Implementation and integration
- Input: Infrastructure and hosting
- Input: Internal team and support
- Build: Three-year cost of each option
- Output: Cost per user per year
- Output: Payback against the benefits

## Costs by option over three years
| Cost element | Option A | Option B | Option C |
|---|---|---|---|
| Licences or subscriptions | [cost] | [cost] | [cost] |
| Implementation | [cost] | [cost] | [cost] |
| Integration | [cost] | [cost] | [cost] |
| Infrastructure and hosting | [cost] | [cost] | [cost] |
| Internal team | [cost] | [cost] | [cost] |
| Support and upgrades | [cost] | [cost] | [cost] |
| Three-year total | [total] | [total] | [total] |

## Costs people forget
### One-time
- Data migration and cleansing
- Training and change management
### Run
- Upgrades and regression testing
- Second-line support and monitoring
### Hidden
- Parallel running and decommissioning
- Exit and data return at the end

## How the options differ
### Option A
- Higher subscription, lower build cost
- Upgrades included
### Option B
- Lower subscription, more integration work
- Upgrades tested by us

## The decision
- Decision: Compare options on the same scope and five-year horizon
- Ask: Finance validates the cost model
- Next step: Add the total cost to the evaluation scorecard
