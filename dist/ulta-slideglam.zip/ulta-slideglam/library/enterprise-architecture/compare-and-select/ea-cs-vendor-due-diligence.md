---
id: ea-cs-vendor-due-diligence
domain: Enterprise Architecture
l1: Compare and Select
l2: Vendor due diligence and RFP evaluation
summary: From market scan to contract: the RFP stages, what we check about each supplier, the evaluation flow and the shortlist.
systems: Procurement, Supplier risk
tags: RFP, RFI, vendor selection, due diligence, supplier risk, procurement
workbook: scoring
order: 202
---
# Vendor due diligence and RFP evaluation

## From market scan to contract
Layout: process pipeline
- Market scan: 12 (50%)
- RFP responses: 6 (50%)
- Demos: 3 (67%)
- Proof of concept: 2
> Notes: illustrative counts - each stage shows the suppliers in it and the share that moves on.

## The evaluation, team by team
Layout: swimlane handoffs
- Procurement: Issues the RFP
- Suppliers: Respond and demonstrate
- Evaluation team: Scores the responses
- Evaluation team: Shortlist clear?
- Evaluation team: If yes, run the proof of concept
- Evaluation team: If no, clarify and score again
- Procurement: Negotiates the contract

## What we check about every supplier
| Area | What we check | Evidence |
|---|---|---|
| Financial health | Revenue, profitability, funding | Annual reports, credit check |
| Product roadmap | Investment in the product we buy | Roadmap briefing |
| References | Customers like us, at our scale | Reference calls |
| Support model | Hours, languages, escalation | Support terms |
| Security assurance | Independent audits, incident history | Audit reports |
| Contract terms | Price protection, service credits | Draft contract |
| Exit | Data return, transition help | Exit clause |

## The RFP in four stages
Layout: process phases
- Prepare: requirements; criteria; long list (Weeks 1-3)
- Tender: RFP issued; questions answered (Weeks 4-7)
- Evaluate: scoring; demos; references (Weeks 8-10)
- Select: proof of concept; negotiation; award (Weeks 11-16)

## The decision
- Decision: Approve the shortlist of two suppliers
- Ask: Release the proof of concept budget
- Next step: Contract award in week 16
