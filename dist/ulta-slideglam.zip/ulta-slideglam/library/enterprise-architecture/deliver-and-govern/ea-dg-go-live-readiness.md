---
id: ea-dg-go-live-readiness
domain: Enterprise Architecture
l1: Deliver and Govern
l2: Go-live readiness
summary: Whether a solution is ready to go live: the readiness criteria by area, the go / no-go flow and the cutover steps.
systems: Programme management, Service management
tags: go-live, readiness, cutover, go no-go, hypercare, release
order: 501
---
# Go-live readiness

## Readiness by area
| Area | Criterion | Owner | Status |
|---|---|---|---|
| Testing | All critical tests passed, no open severity-one defects | Test lead | [status] |
| Data | Final load reconciled and signed off | Data lead | [status] |
| People | Users trained, support team ready | Change lead | [status] |
| Operations | Monitoring, runbooks, support model in place | Service owner | [status] |
| Security | Access set up, residual risk accepted | Security lead | [status] |
| Business | Process owners sign off, fallback agreed | Business lead | [status] |

## The go / no-go decision
Layout: swimlane handoffs
- Programme manager: Collects the readiness evidence
- Area leads: Confirm their criteria
- Steering committee: Every criterion met?
- Steering committee: If yes, go
- Steering committee: If no, delay or go with conditions
- Cutover team: Runs the cutover plan

## Cutover in five steps
Layout: process chevrons
- Freeze: changes stop
- Load: final data
- Verify: reconcile and smoke test
- Switch: users and interfaces
- Support: hypercare starts

## After go-live
### Hypercare
- Extra support for four weeks
- Daily defect review
### Stabilise
- Handover to run support
- Lessons captured
