---
id: ea-rd-raid-log
domain: Enterprise Architecture
l1: Review and Decide
l2: Risks, assumptions, issues and dependencies (RAID)
summary: The RAID log for a programme or a solution decision: the four categories, the top items with owners, and the weekly rhythm.
systems: Programme management
tags: RAID, risks, assumptions, issues, dependencies, programme governance
workbook: raid
order: 304
---
# Risks, assumptions, issues and dependencies

## Four things we track
Layout: matrix
- Risks: what might happen - owned, with a mitigation
- Assumptions: what we believe is true - checked by a date
- Issues: what has happened - owned, with an action
- Dependencies: what we need from others - agreed dates

## Top risks
| Risk | Likelihood | Impact | Mitigation | Owner |
|---|---|---|---|---|
| Key users not available for testing | Medium | High | Backfill agreed with managers | Business lead |
| Data quality delays migration | High | High | Cleansing starts now, three trial loads | Data lead |
| Supplier release slips | Medium | Medium | Contract milestone with credits | Vendor manager |

## Assumptions and dependencies
| Item | Type | What it means | Check by | Owner |
|---|---|---|---|---|
| Single sign-on available | Assumption | Identity team supports the new app | Design sign-off | Security lead |
| Integration platform capacity | Dependency | New interfaces fit the current licence | Build start | Integration lead |
| Finance close calendar | Dependency | No go-live in close week | Plan baseline | Programme manager |

## The weekly rhythm
Layout: process cycle
- Identify: new items from every team
- Assess: likelihood, impact, urgency
- Act: owners and dates
- Review: weekly with the programme board
