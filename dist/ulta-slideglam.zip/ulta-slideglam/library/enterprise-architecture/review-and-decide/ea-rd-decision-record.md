---
id: ea-rd-decision-record
domain: Enterprise Architecture
l1: Review and Decide
l2: Architecture decision record
summary: One architecture decision on the record: context, the options weighed, the decision, its trade-offs and when to revisit it.
systems: Architecture repository
tags: ADR, architecture decision record, decision log, trade-offs, design decision
order: 303
---
# Architecture decision record

## The decision at a glance
### Context
- What forced a decision now
- The constraints that apply
### Decision
- What we decided, in one sentence
- Who decided and when
### Consequences
- What becomes easier
- What becomes harder

## Options we weighed
| Option | For | Against | Outcome |
|---|---|---|---|
| Events through the integration platform | Real time, decoupled | New skills for the team | Chosen |
| Direct API calls between systems | Simple to start | Tight coupling, retries in every system | Rejected |
| Nightly batch files | Familiar | Data a day old | Rejected |

## Trade-offs we accept
### Risks
- Event schemas must be governed
- More moving parts to monitor
### Mitigations
- A schema registry with owners
- Event monitoring on the central dashboard

## The record
| Field | Value |
|---|---|
| Status | Accepted |
| Date | [date] |
| Decided by | Architecture board |
| Owner | Integration lead |
| Revisit | When event volume doubles, or in 12 months |
