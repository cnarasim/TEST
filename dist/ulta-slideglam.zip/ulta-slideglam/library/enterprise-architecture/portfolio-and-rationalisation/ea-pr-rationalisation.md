---
id: ea-pr-rationalisation
domain: Enterprise Architecture
l1: Portfolio and Rationalisation
l2: Application rationalisation (TIME)
summary: Every application scored on business value and technical health, then tolerate, invest, migrate or eliminate, with the plan.
systems: Application portfolio
tags: rationalisation, TIME model, portfolio, application portfolio management, retire, consolidate
order: 401
---
# Application rationalisation

## Tolerate, invest, migrate or eliminate
Layout: matrix
- Tolerate: low business value, good technical health - keep as is
- Invest: high business value, good technical health - grow it
- Migrate: high business value, poor technical health - move to a modern platform
- Eliminate: low business value, poor technical health - retire it

## The portfolio scored
| Application | Business value | Technical health | Decision | Next step |
|---|---|---|---|---|
| Application A | High | Good | Invest | Extend to new channels |
| Application B | High | Poor | Migrate | Replace in the next wave |
| Application C | Low | Good | Tolerate | No new features |
| Application D | Low | Poor | Eliminate | Retire by year end |
| Application E | Medium | Medium | Tolerate | Review next year |

## Five steps through the portfolio
Layout: process chevrons
- Inventory: every application and owner
- Score: value and health
- Classify: tolerate, invest, migrate, eliminate
- Plan: waves and savings
- Act: retire and consolidate

## How we score
### Business value
- Processes and users it supports
- Revenue or risk it carries
### Technical health
- Supportability and age
- Security and integration fit
### Cost
- Licences, infrastructure, support
- Overlap with other applications

## KPIs for the portfolio
| KPI | What it measures | Data source |
|---|---|---|
| Applications retired | Applications switched off this year | Portfolio inventory |
| Run cost saved | Annual cost removed | Contracts and invoices |
| Overlap | Capabilities served by more than one application | Capability map |
| Unsupported versions | Applications past supplier support | Portfolio inventory |
