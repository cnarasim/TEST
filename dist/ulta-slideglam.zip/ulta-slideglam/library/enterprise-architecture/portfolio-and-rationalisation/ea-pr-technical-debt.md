---
id: ea-pr-technical-debt
domain: Enterprise Architecture
l1: Portfolio and Rationalisation
l2: Technical debt assessment
summary: Where the technical debt is, what it costs the business, which to fix first, and the rhythm that stops it growing.
systems: Application portfolio, Engineering backlog
tags: technical debt, modernisation, legacy, remediation, prioritisation
order: 402
---
# Technical debt assessment

## Where the debt is
| Area | The debt | Business impact | Effort to fix | Priority |
|---|---|---|---|---|
| Versions | Platforms past supplier support | Security exposure | Medium | High |
| Custom code | Modifications that block upgrades | Slow change, costly upgrades | High | High |
| Integrations | Point-to-point files | Failures and manual fixes | Medium | Medium |
| Data | Duplicate master data | Wrong prices and reports | Medium | High |
| Documentation | Undocumented interfaces | Key-person risk | Low | Medium |

## What to fix first
Layout: matrix
- Fix now: high impact, low effort
- Plan: high impact, high effort
- Bundle: low impact, low effort - with other work
- Accept: low impact, high effort - record it

## The debt cycle
Layout: process cycle
- Find: debt in every review
- Size: impact and effort
- Prioritise: with the product owner
- Fix: a share of every release
- Prevent: standards and reviews

## Today and target
### Today
- Debt found when something breaks
- No capacity set aside to fix it
### Target
- A debt register with owners
- A fixed share of every release for debt
