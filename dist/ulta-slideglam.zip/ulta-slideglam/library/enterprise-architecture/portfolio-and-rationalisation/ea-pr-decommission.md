---
id: ea-pr-decommission
domain: Enterprise Architecture
l1: Portfolio and Rationalisation
l2: Application decommission and sunset
summary: Switching an application off safely: data archived under retention rules, users and interfaces moved, contracts stopped.
systems: Application portfolio, Archive
tags: decommission, sunset, retire, archive, data retention, switch off
order: 404
---
# Application decommission and sunset

## Five steps to switch it off
Layout: process chevrons
- Decide: date and owner
- Archive: data under retention rules
- Move: users and interfaces
- Switch off: access, then servers
- Stop: licences and contracts

## Who does what
Layout: swimlane handoffs
- Application owner: Confirms the retirement date
- Data owner: Archives records under retention rules
- Integration team: Moves or removes every interface
- Integration team: All interfaces moved?
- Integration team: If yes, switch off access
- Integration team: If no, extend parallel running
- Finance: Stops licences and contracts

## The checklist
| Item | Owner | Status |
|---|---|---|
| Users moved to the new application | Business lead | [status] |
| Data archived and readable | Data owner | [status] |
| Interfaces moved or removed | Integration lead | [status] |
| Reports rebuilt or retired | Reporting lead | [status] |
| Access and accounts removed | Security | [status] |
| Licences and contracts ended | Vendor manager | [status] |

## What retiring it saves
| Saving | What it measures | Data source |
|---|---|---|
| Run cost | Licences, hosting, support removed | Contracts and invoices |
| Risk | Unsupported software removed | Portfolio inventory |
| Effort | Support tickets that stop | Service desk |
