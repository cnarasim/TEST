"""Review ANY deck (yours, a colleague's, a vendor's) without rebuilding it: a score and a fix list.

    python tools/review_deck.py Deck.pptx [--out /mnt/data/out/Deck-review.md] [--as-of 2026-10-10]

Checks (each finding names the slide and the fix):
  Story      headline is a topic ("Q3 results") instead of a message ("Q3 revenue beat plan by 4%");
             two slides with the same headline; more than ~70 words or 7 bullets on a slide; no headline at all
  Numbers    a slide with figures but no source in its notes; the same measure with different values on two slides
             ("revenue $4.6M" vs "revenue $4.8M"); a percentage over 100% outside growth wording
  Dates      dates already in the past for words like due/by/launch/go-live/deadline
  Words      the same term written two ways (e-mail/email, go-live/golive, Wi-Fi/WiFi, case variants of an acronym)
  Brand      more than 3 fonts; colours outside the active brand's family; text under 9 pt
  Compliance accessibility (alt text, table headers) and sensitive data (secrets block, contact details review)
Score: 100 minus 10 per blocking finding, 3 per fix, 1 per suggestion (minimum 0). Read-only: the deck is not changed.
"""
import argparse, collections, datetime, re, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
VERB = re.compile(r"(?i)\b(is|are|was|were|will|won't|can|cannot|must|should|need|needs|has|have|had|beat|beats|missed|misses|"
                  r"grew|grows|fell|falls|rose|rises|cut|cuts|saves?|saved|drives?|drove|reduces?|reduced|improves?|improved|"
                  r"increases?|increased|decreases?|decreased|doubles?|doubled|delivers?|delivered|lands?|landed|stays?|stayed|"
                  r"leads?|led|takes?|took|makes?|made|gives?|gave|keeps?|kept|launch(?:es|ed)?|ships?|shipped|moves?|moved|"
                  r"recover(?:s|ed)?|lag(?:s|ged)?|trail(?:s|ed)?|ahead|behind|on track|off track|at risk|up|down)\b")
MEASURE = re.compile(r"(?i)\b([a-z][a-z /&-]{2,30}?)\s*(?:of|at|:|=|is|was|reached|hit)?\s*([$€£]\d[\d,]*(?:\.\d+)?\s?(?:[KMB]\b|million|billion)?|\d[\d,]*(?:\.\d+)?\s?(?:%|[KMB]\b|million|billion))")
DATE = re.compile(r"(?i)\b(due|by|launch(?:es)?|go[- ]?live|deadline|target date|cut-?over|start(?:s)?|ends?)\b[^.\n]{0,25}?"
                  r"\b(\d{1,2}/\d{1,2}(?:/\d{2,4})?|\d{4}-\d{2}-\d{2}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.? \d{1,2}(?:,? \d{4})?)")
VARIANTS = [("e-mail", "email"), ("go-live", "golive"), ("go-live", "go live"), ("wi-fi", "wifi"), ("log-in", "login"),
            ("set-up", "setup"), ("roll-out", "rollout"), ("check-in", "checkin"), ("on-boarding", "onboarding"),
            ("data base", "database"), ("web site", "website"), ("e-commerce", "ecommerce")]
FOOTER = re.compile(r"\|\s*(proprietary|confidential|internal|public|restricted)", re.I)


def slide_texts(s):
    """(headline, text blocks, table cell texts)."""
    title = None
    blocks, cells = [], []
    for sh in s.shapes:
        if not sh.has_text_frame or not sh.text_frame.text.strip():
            if getattr(sh, "has_table", False) and sh.has_table:
                cells += [c.text for r in sh.table.rows for c in r.cells if c.text.strip()]
            continue
        t = sh.text_frame.text.strip()
        if FOOTER.search(t) or re.fullmatch(r"\d{1,3}", t):
            continue
        if title is None and (sh.is_placeholder or (sh.top is not None and sh.top < 1_400_000)):
            title = t.split("\n")[0]
        else:
            blocks.append(t)
    return title, blocks, cells


def parse_date(s, today):
    s = s.strip().rstrip(".")
    for fmt in ("%m/%d/%Y", "%m/%d/%y", "%Y-%m-%d", "%b %d, %Y", "%B %d, %Y", "%b %d %Y", "%B %d %Y"):
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except ValueError:
            pass
    for fmt in ("%m/%d", "%b %d", "%B %d"):
        try:
            d = datetime.datetime.strptime(s, fmt).date().replace(year=today.year)
            return d
        except ValueError:
            pass
    return None


def review(path, today):
    from pptx import Presentation
    import brand as B
    prs = Presentation(str(path))
    b = B.current()
    F = []                               # (severity, slide, area, message)
    titles = collections.defaultdict(list)
    measures = collections.defaultdict(dict)
    words_all = []
    fonts, small, offbrand = collections.Counter(), 0, set()
    for i, s in enumerate(prs.slides, 1):
        title, blocks, cells = slide_texts(s)
        notes = s.notes_slide.notes_text_frame.text if s.has_notes_slide else ""
        prose = "\n".join(blocks)
        body = "\n".join(blocks + cells)
        words = len(prose.split())
        words_all.append(body + "\n" + (title or ""))
        if i == 1:
            pass
        elif not title and len(body.split()) > 6:            # a closing / divider slide needs no headline
            F.append(("fix", i, "Story", "no headline: add one sentence that states the slide's message"))
        elif title:
            titles[title.lower()].append(i)
            if len(title.split()) <= 4 and not VERB.search(title) and not re.search(r"\d", title):
                F.append(("suggest", i, "Story", f"'{title}' is a topic; write the message (e.g. '{title} is on track, 2 risks need a decision')"))
        bullets = sum(1 for ln in prose.splitlines() if ln.strip())
        if words > 70 or bullets > 7:
            F.append(("fix", i, "Story", f"{words} words / {bullets} lines: split the slide or move detail to notes"))
        nums = re.findall(r"[$€£]?\d[\d,.]*\s?(?:%|[KMB]\b|million|billion)", body + " " + (title or ""))
        if nums and i > 1 and not re.search(r"(?i)\bsource|data:|from\b", notes):
            F.append(("fix", i, "Numbers", f"figures ({', '.join(nums[:3])}) without a source: add 'Source: ...' to the notes"))
        for m in MEASURE.finditer(body + "\n" + (title or "")):
            name = re.sub(r"\s+", " ", m.group(1).strip().lower())
            if len(name.split()) <= 4 and not re.search(r"\b(the|and|for|with|to|in|on|by)$", name):
                measures[name].setdefault(m.group(2).replace(" ", ""), set()).add(i)
        for m in re.finditer(r"(\d{3,}(?:\.\d+)?)\s?%", body + (title or "")):
            ctx = (body + (title or ""))[max(0, m.start() - 40):m.start()].lower()
            if not re.search(r"grow|growth|increase|up|of target|vs|yoy|year", ctx):
                F.append(("fix", i, "Numbers", f"{m.group(0)}: a share above 100% - check the figure"))
        for m in DATE.finditer(body + "\n" + (title or "")):
            d = parse_date(m.group(2), today)
            if d and d < today:
                F.append(("fix", i, "Dates", f"'{m.group(0).strip()}' is in the past (today {today:%m/%d/%Y}): update or mark done"))
        for sh in s.shapes:
            el = sh._element
            for lat in el.iter(A + "latin"):
                if lat.get("typeface") and not lat.get("typeface").startswith("+"):
                    fonts[lat.get("typeface")] += 1
            for r in el.iter(A + "rPr"):
                if r.get("sz") and int(r.get("sz")) < 900 and (r.getparent().findtext(A + "t") or "").strip():
                    small += 1
            for c in el.iter(A + "srgbClr"):
                if not B.in_family(c.get("val"), b):
                    offbrand.add(c.get("val").upper())
    for t, sl in titles.items():
        if len(sl) > 1:
            F.append(("fix", sl[1], "Story", f"same headline as slide {sl[0]}: '{t[:50]}' - each slide needs its own message"))
    for name, vals in measures.items():
        slides_ = set().union(*vals.values()) if vals else set()
        if len(vals) > 1 and len(slides_) > 1:
            where = "; ".join(f"{v} on slide {', '.join(map(str, sorted(s_)))}" for v, s_ in vals.items())
            F.append(("fix", min(min(s_) for s_ in vals.values()), "Numbers", f"'{name}' has different values: {where} - make them agree or say why"))
    text = "\n".join(words_all).lower()
    for a_, b_ in VARIANTS:
        if re.search(rf"\b{re.escape(a_)}\b", text) and re.search(rf"\b{re.escape(b_)}\b", text):
            F.append(("suggest", 0, "Words", f"'{a_}' and '{b_}' both used: pick one"))
    acr = collections.defaultdict(set)
    for w in re.findall(r"\b[A-Za-z]{2,6}\b", "\n".join(words_all)):
        if sum(ch.isupper() for ch in w) >= 2:
            acr[w.lower()].add(w)
    for k, v in acr.items():
        if len(v) > 1:
            F.append(("suggest", 0, "Words", f"acronym written {len(v)} ways: {', '.join(sorted(v))}"))
    if len(fonts) > 3:
        F.append(("fix", 0, "Brand", f"{len(fonts)} fonts used ({', '.join(f for f, _ in fonts.most_common(6))}): keep to the template's 2-3"))
    if offbrand:
        F.append(("fix", 0, "Brand", f"{len(offbrand)} colour(s) outside the {b.name} family: {', '.join(sorted(offbrand)[:8])}"))
    if small:
        F.append(("suggest", 0, "Brand", f"{small} text run(s) under 9 pt: hard to read on screen"))
    import a11y, compliance
    af, ar = a11y.check(path, b)
    F += [("fix", 0, "Accessibility", x) for x in af[:10]]
    for x in compliance.scan([path]):
        F.append(("block" if x["severity"] == "BLOCK" else "suggest", 0, "Sensitive data",
                  f"{x['where']}: {x['kind']} '{x['match']}'" + (" - remove before sharing" if x["severity"] == "BLOCK" else " - keep only if intended")))
    score = max(0, 100 - sum({"block": 10, "fix": 3, "suggest": 1}[f[0]] for f in F))
    return score, F, len(prs.slides)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck"); ap.add_argument("--out"); ap.add_argument("--as-of")
    a = ap.parse_args()
    today = datetime.date.fromisoformat(a.as_of) if a.as_of else datetime.date.today()
    score, F, n = review(Path(a.deck), today)
    order = {"block": 0, "fix": 1, "suggest": 2}
    F.sort(key=lambda f: (order[f[0]], f[1], f[2]))
    counts = collections.Counter(f[0] for f in F)
    lines = [f"# Review of {Path(a.deck).name}: {score}/100", "",
             f"{n} slides | {counts['block']} blocking, {counts['fix']} to fix, {counts['suggest']} suggestions", "",
             "| # | Severity | Slide | Area | Finding and fix |", "|---|---|---|---|---|"]
    lines += [f"| {k} | {sev} | {sl or 'deck'} | {area} | {msg} |" for k, (sev, sl, area, msg) in enumerate(F, 1)]
    md = "\n".join(lines)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(md)
    print(f"REVIEW {score}/100 | {counts['block']} blocking, {counts['fix']} to fix, {counts['suggest']} suggestions"
          + (f" | report {a.out}" if a.out else ""))
    for sev, sl, area, msg in F[:12]:
        print(f"  {sev:7} slide {sl or '-':>3} {area}: {msg}")
    if len(F) > 12:
        print(f"  ... {len(F) - 12} more in the report")


if __name__ == "__main__":
    main()
