"""Plain punctuation in every deliverable: no em dashes (and no spaced en dashes) in what people read.

    python tools/plain.py Deck.pptx Notes.docx page.html ...     # rewrites the files in place, prints what changed
    import plain; plain.text("Returns <em dash> down 18%")  -> "Returns - down 18%"
    import plain; plain.clean(path)                  -> number of dashes replaced (0 = nothing to do)

A dash between words becomes " - ", a dash standing alone (an empty cell) becomes "-". Ranges keep their en dash
("Mon<en dash>Fri", "2<en dash>6"). Office files: only the text people read (slides, notes, charts, document body, headers, footers,
sheets, embedded chart data, title) - never the template's masters, layouts, themes or styles. Text files (HTML,
SVG, draw.io, Markdown, JSON, CSV, e-mail text) are rewritten whole.
"""
import io, re, sys, zipfile
from pathlib import Path

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))   # run on its own (python -I too): its sibling modules
try:                                   # tools/atomic.py: pictures stored as they are (the kit loads this file on its own)
    from atomic import ZipOut as _Zip
except ImportError:
    _Zip = zipfile.ZipFile

EM, EN = "\u2014", "\u2013"
_ENT = re.compile(r"&#(?:8212|x2014|X2014);|&mdash;")
_RUN = re.compile(r"[ \t]*\u2014+(?![\u2014>])[ \t]*")      # an em-dash arrow (A \u2014\u2014> B) is kept
_SPACED_EN = re.compile(r"[ \t]+\u2013[ \t]+")
_ARROW = re.compile(r"\u2014+>")                       # an em-dash arrow becomes the plain arrow the parsers also read


def _arrows(s):
    return _ARROW.sub(lambda m: "-" * (len(m.group(0)) - 1) + ">", s)
_NODE = re.compile(r"(<(?:a:t|w:t|c:v|t|v)(?:\s[^>]*)?>)([^<]*)(</(?:a:t|w:t|c:v|t|v)>)")
OFFICE_PARTS = re.compile(r"(ppt/(slides|notesSlides|charts|diagrams)/[^/]+\.xml"
                          r"|word/(document|header\d*|footer\d*|footnotes|endnotes|comments)\.xml"
                          r"|xl/(sharedStrings|worksheets/[^/]+|charts/[^/]+)\.xml|docProps/core\.xml)$")
TEXT_SUFFIXES = {".html", ".htm", ".svg", ".drawio", ".md", ".txt", ".json", ".csv", ".eml"}
OFFICE_SUFFIXES = {".pptx", ".docx", ".xlsx"}


def text(s):
    """One piece of text: em dashes and spaced en dashes become plain hyphens."""
    if not s or (EM not in s and f" {EN} " not in s and "&#8212;" not in s and "&#x2014;" not in s.lower()
                 and "&mdash;" not in s):
        return s
    s = _arrows(_ENT.sub(EM, s))
    if not s.replace(EM, "").strip():
        return "-"                                     # an empty value shown as a dash
    s = _RUN.sub(" - ", s)
    s = _SPACED_EN.sub(" - ", s)
    if s.startswith(" - "):
        s = "- " + s[3:]
    if s.endswith(" - "):
        s = s[:-3] + " -"
    return s


PATH_KEYS = {"image", "images", "path", "file", "files", "src", "out", "logo", "icon", "picture", "screenshot", "href",
             "url", "template", "font", "fonts"}


def deep(obj, key=None):
    """Every string in a storyboard / spec / guide (dicts, lists): text() on each, except file paths and links."""
    if isinstance(obj, str):
        return obj if key in PATH_KEYS else text(obj)
    if isinstance(obj, list):
        return [deep(v, key) for v in obj]
    if isinstance(obj, dict):
        return {k: deep(v, k if isinstance(k, str) else key) for k, v in obj.items()}
    return obj


def markdown(s):
    """Content written as Markdown: line by line; a line that is only a dash is dropped (a lone "-" would start a list)."""
    if not s or (EM not in s and f" {EN} " not in s and "&#8212;" not in s and "&mdash;" not in s):
        return s
    return "\n".join("" if l.strip() and not l.replace(EM, "").strip() else _text_file(l) for l in s.split("\n"))


def _xml(x):
    """XML text: each text node as a whole (so a lone dash stays "-"), then any dash left in an attribute (alt text)."""
    x = _NODE.sub(lambda m: m.group(1) + text(m.group(2)) + m.group(3), x)
    return _SPACED_EN.sub(" - ", _ENT.sub("-", x.replace(EM, "-")))


markup = _xml                                           # SVG / draw.io / Office XML text, as a string


def _count(s):
    return s.count(EM) + len(_ENT.findall(s)) + len(_SPACED_EN.findall(s))


def _office_bytes(data):
    """A .pptx/.docx/.xlsx as bytes -> (cleaned bytes, dashes replaced). Embedded workbooks (chart data) too."""
    zin = zipfile.ZipFile(io.BytesIO(data))
    out, n = io.BytesIO(), 0
    with _Zip(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for info in zin.infolist():
            b = zin.read(info.filename)
            if OFFICE_PARTS.search(info.filename):
                s = b.decode("utf-8")
                k = _count(s)
                if k:
                    b, n = _xml(s).encode("utf-8"), n + k
            elif info.filename.startswith(("ppt/embeddings/", "word/embeddings/")) and info.filename.endswith(".xlsx"):
                b2, k = _office_bytes(b)
                if k:
                    b, n = b2, n + k
            zout.writestr(info, b)
    return (out.getvalue(), n) if n else (data, 0)


def clean(path):
    """Rewrite one deliverable in place; returns how many dashes were replaced (0 leaves the file untouched)."""
    p = Path(path)
    if not p.is_file():
        return 0
    suf = p.suffix.lower()
    if suf in OFFICE_SUFFIXES:
        data, n = _office_bytes(p.read_bytes())
        if n:
            import atomic
            with atomic.replacing(p) as t:
                t.write_bytes(data)
        return n
    if suf in TEXT_SUFFIXES:
        s = p.read_text(encoding="utf-8", errors="surrogateescape")
        before = _count(s)
        if before:
            s = _xml(s) if suf in (".svg", ".drawio") else _html(s) if suf in (".html", ".htm") else _text_file(s)
            p.write_text(s, encoding="utf-8", errors="surrogateescape")
            return before - _count(s)
        return 0
    return 0


def _text_file(s):
    """Markdown, JSON, CSV, e-mail, page text: a dash alone in a cell or value becomes "-", between words " - "."""
    s = _arrows(_ENT.sub(EM, s))
    s = re.sub(r'(>|"|\||,)[ \t]*\u2014+[ \t]*(<|"|\||,|$)', lambda m: m.group(1) + "-" + m.group(2), s, flags=re.M)
    return _SPACED_EN.sub(" - ", _RUN.sub(" - ", s))


_BLOCK = re.compile(r"(<(script|style)\b[^>]*>)(.*?)(</\2>)", re.S | re.I)


def _code(s):
    """Script or style code: only a dash shown as a value (an em dash in quotes) or spaced between words. A dash touching other
    characters is left alone - it may sit inside a regular expression's character class."""
    s = re.sub(r"([\"'`>])\u2014+([\"'`<])", r"\1-\2", s)
    return re.sub(r"[ \t]+\u2014+(?![\u2014>])[ \t]*|[ \t]*\u2014+(?![\u2014>])[ \t]+", " - ", s)


def _html(s):
    """A page: its text and JSON data blocks in full, its script and style code carefully."""
    s = _ENT.sub(EM, s)
    out, last = [], 0
    for m in _BLOCK.finditer(s):
        out.append(_text_file(s[last:m.start()]))
        body = m.group(3)
        out.append(m.group(1) + (_text_file(body) if "json" in m.group(1).lower() else _code(body)) + m.group(4))
        last = m.end()
    out.append(_text_file(s[last:]))
    return "".join(out)


def clean_all(paths):
    """Clean every deliverable in paths; returns {name: dashes replaced} for the files that changed."""
    done = {}
    for p in paths:
        n = clean(p)
        if n:
            done[Path(p).name] = n
    return done


def remaining(path):
    """Dashes a reader would still see (used by the selftest): what clean() would replace, 0 for a clean file."""
    p = Path(path)
    suf = p.suffix.lower()
    if suf in OFFICE_SUFFIXES:
        z = zipfile.ZipFile(p)
        return sum(_count(z.read(n).decode("utf-8", "ignore")) for n in z.namelist() if OFFICE_PARTS.search(n))
    if suf in TEXT_SUFFIXES:
        s = p.read_text(encoding="utf-8", errors="ignore")
        after = _xml(s) if suf in (".svg", ".drawio") else _html(s) if suf in (".html", ".htm") else _text_file(s)
        return _count(s) - _count(after)
    return 0


if __name__ == "__main__":
    for name, n in clean_all(sys.argv[1:]).items():
        print(f"{name}: {n} dash(es) replaced")
