"""How each slide tells its story, so two slides in a row never tell theirs the same way unless one continues the other.

    python tools/storyline.py storyboard.json      # each slide's way, and the neighbours that share one (exit 1)

build_deck.py checks every storyboard with it (design_lint): two content slides in a row that tell their story the same
way read as one point made twice, so the build stops and names the ways the second slide could tell it instead (a
converted deck gets the same as advice). The ways:
  points     a set of points: cards, pillars, focus areas, scope columns, tiles, a list, two text boxes, a honeycomb
  sequence   steps in order: a flow, a process flow (chevrons, arrow, cycle ...), a funnel, a chevron or sequence diagram,
             stairs; a retail DC flow, cross-dock or document flow
  roles      who does what: a swimlane in any style (lanes, hand-offs, a service blueprint, a RACI matrix ...)
  time       a timeline: a gantt, a roadmap, milestones, the three-horizon journey, every timeline style, process phases
  numbers    big numbers: KPI cards, quad numbers, headline metrics, KPI cards with sparklines, rings, a gauge, a bento
  scorecard  KPIs against target: the two scorecards, a bullet chart
  trend      change over time: a line or area chart, columns over periods, a trend line, a streamgraph
  rank       items ranked by size: bars, columns by item, a lollipop, radial bars, a bubble pack, a polar rose
  share      shares of a whole: a donut or pie, 100% bars, stacked bars, a waffle, a treemap, a sunburst, a sankey
  compare    a side-by-side comparison: paired columns, a dumbbell, a slope, a butterfly, a radar, the fulfilment paths
  structure  how the parts fit: a system diagram (hub, tree, layers ...), a pyramid, a target, a venn, a vision house, an
             OGSM, a supply chain network, inputs coming together or a source branching out
  matrix     a 2x2: a quadrant or a matrix graphic
  table      rows of detail: the hypothesis, results, action and opportunity tables, a data table, an interface matrix
  map        a map;  people  the team;  summary  At a glance, recap and today;  picture  a photo
Covers, agendas, dividers, statements, closings and library slides tell no story of their own: they end a run.

A slide continues the one before (and may tell its story the same way) when it says so: "(cont.)", "(continued)",
"(2/3)" or "(2)" in its headline, or "continues": true in the storyboard, each only with the same subject (the same
labels, table header or data, or shared headline words); a numbered list that carries on the numbering. A deck that
shows one kind on purpose (every diagram or timeline style) is a catalogue:
"gallery": true.
"""
import json, re, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))                     # its sibling modules, also under python -I

WORDS = {"points": "a set of points", "sequence": "steps in order", "roles": "who does what", "time": "a timeline",
         "numbers": "big numbers", "scorecard": "KPIs against target", "trend": "a trend over time",
         "rank": "items ranked by size", "share": "shares of a whole", "compare": "a side-by-side comparison",
         "structure": "how the parts fit together", "matrix": "a 2x2 matrix", "table": "a table", "map": "a map",
         "people": "the people", "summary": "a summary", "picture": "a picture"}
SOURCES = {6: "points", 7: "points", 43: "points", 46: "points", 47: "points", 42: "compare", 45: "summary", 8: "share",
           9: "numbers", 13: "numbers", 49: "numbers", 21: "scorecard", 50: "scorecard", 10: "table", 11: "table",
           12: "table", 14: "table", 15: "time", 16: "time", 17: "time", 18: "time", 19: "time", 20: "sequence",
           26: "sequence", 22: "map", 24: "structure", 25: "structure", 48: "people"}      # the Ulta template's layouts
INFOGRAPHICS = {"donut": "share", "results": "table", "quad": "numbers", "journey": "time", "scorecard": "scorecard",
                "map": "map", "priorities": "structure", "ogsm": "structure", "funnel": "sequence"}
MODERN = {"kpi": "numbers", "bento": "numbers", "ring": "numbers", "gauge": "numbers", "bullet": "scorecard",
          "lollipop": "rank", "radialbar": "rank", "bubbles": "rank", "rose": "rank", "dumbbell": "compare",
          "slope": "compare", "butterfly": "compare", "radar": "compare", "waffle": "share", "stack100": "share",
          "treemap": "share", "sunburst": "share", "sankey": "share", "trend": "trend", "stream": "trend",
          "usmap": "map", "pointmap": "map", "gantt": "time", "swimlane": "roles"}
CHARTS = {"line": "trend", "area": "trend", "pie": "share", "doughnut": "share", "stacked100": "share"}
                                                # bars and columns over periods: a trend, else rank (stacked: share)
GRAPHICS = {"funnel": "sequence", "stairs": "sequence", "cycle": "sequence", "pyramid": "structure", "target": "structure",
            "venn": "structure", "milestones": "time", "timeline": "time", "roadmap": "time", "quadrant": "matrix",
            "matrix": "matrix", "honeycomb": "points"}
DIAGRAMS = {"chevron": "sequence", "sequence": "sequence", "stairs": "sequence", "funnel": "sequence", "milestones": "time",
            "quadrant": "matrix", "matrix": "table", "honeycomb": "points"}   # every other style shows a structure
PROCESS = {"phases": "time", "converge": "structure", "diverge": "structure"}   # every other process flow: steps in order
RETAIL = {"network": "structure", "fulfilment": "compare", "dc-flow": "sequence", "cross-dock": "sequence",
          "document-flow": "sequence"}
PROCESS_FORMS = {"chevrons": "a chevron flow", "arrow": "a process arrow", "numbered": "numbered steps", "cycle": "a cycle",
                 "snake": "a two-row process", "vertical": "a vertical process", "phases": "process phases",
                 "pipeline": "a pipeline", "io": "inputs and outputs", "converge": "inputs coming together",
                 "diverge": "a source branching out"}
RETAIL_FORMS = {"network": "a supply chain network", "fulfilment": "the fulfilment paths", "dc-flow": "a DC flow",
                "cross-dock": "a cross-dock flow", "document-flow": "a document flow"}
FORMS = {6: "two text boxes", 7: "cards", 8: "a donut", 9: "KPI cards", 10: "the hypothesis table", 11: "the results table",
         12: "the action table", 13: "four big numbers", 14: "the opportunity grid", 15: "a gantt", 16: "a roadmap",
         17: "an event timeline", 18: "the journey", 19: "a callout roadmap", 20: "a flow", 21: "a scorecard", 22: "a map",
         24: "the vision house", 25: "an OGSM", 26: "a funnel", 42: "paired columns", 43: "pillars", 45: "recap and today",
         46: "focus areas", 47: "scope columns", 48: "the team", 49: "headline metrics", 50: "a period scorecard"}
MODERN_FORMS = {"kpi": "KPI cards", "bento": "a bento grid", "ring": "progress rings", "gauge": "a gauge",
                "bullet": "a bullet chart", "stack100": "100% bars", "trend": "a trend line", "radialbar": "radial bars",
                "radar": "a radar", "bubbles": "a bubble pack", "rose": "a polar rose", "usmap": "a US map",
                "pointmap": "a location map", "stream": "a streamgraph"}
CHART_FORMS = {"stacked": "stacked columns", "stacked_bar": "stacked bars", "stacked100": "100% columns",
               "doughnut": "a donut chart", "area": "an area chart"}
PERIOD = re.compile(r"(?i)^(?:(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?(?:[ -]*'?\d{2,4})?|"
                    r"q[1-4](?:[ -]*'?(?:fy)?\s*\d{2,4})?|(?:fy|h[12])\s*'?\d{2,4}|(?:w|wk|week)\s*\d{1,2}(?:\s*\d{4})?|"
                    r"(?:19|20)\d\d(?:-\d\d(?:-\d\d)?)?|\d{1,2}/\d{1,2}(?:/\d{2,4})?|(?:p|period|day|month)\s*\d{1,3})$")
PERIOD_NAME = re.compile(r"(?i)\b(?:month|week|wk|quarter|qtr|year|yr|fy|date|day|period|time|hour|season)s?\b")
FLOWS = re.compile(r"^\s*(.+?)\s*(?:→|->|⇒)\s*(.+?)\s*(?::.*)?$")
MARK = re.compile(r"(?i)(?:\s*[(\[]\s*(?:cont(?:inued|'d|’d|d)?\.?|\d{1,2}\s*(?:/|of)\s*\d{1,2}|[2-9]|part\s+\d{1,2}(?:\s+of\s+\d{1,2})?)"
                  r"\s*[)\]]|\s*[-–:,]\s*(?:continued|cont(?:'d|’d|\.)|part\s+\d{1,2}(?:\s+of\s+\d{1,2})?))\s*$")
LEAD = re.compile(r"(?i)^\s*(?:continued|cont(?:'d|’d|\.))\s*[:\-–]\s*")
STOP = set("about after again also been being both does each even every from have having into just more most much only "
           "other over same some such than that their them then there these they this those through under until very "
           "what when where which while will with would your ours slide slides".split())
SKIP = {"headline", "title", "subtitle", "notes", "summary", "decision", "source", "style", "format", "unit", "colour",
        "color", "status", "classification", "owner", "continues", "numbered", "start", "plain", "mode", "_k", "_glance"}
_K = {}


def consts():
    """The brand's display slides (no story of their own) and whether the Ulta layouts are in use."""
    if not _K:
        import brand as B
        b = B.current()
        layouts = False
        try:
            import full_template as FT
            layouts = bool(b.get("layouts"))
            shown = FT.display_sources() if layouts else set()
        except Exception:
            shown = set()
        _K.update(ulta=b.name == "ulta",
                  display={b.role("cover", 1), b.role("closing", 33), 32, 33, 5, 2} | shown, layouts=layouts)
    return _K


def resolved(src):
    if isinstance(src, str) and consts()["layouts"]:
        import full_template as FT
        return FT.resolve(src)
    return src


def periodic(labels):
    """Labels that are periods (Jan, Q3 2026, W12, 2025, 2026-03-01): a run over time."""
    xs = [str(x).strip()[:10] if re.match(r"\d{4}-\d\d-\d\d", str(x)) else str(x).strip() for x in labels if str(x).strip()]
    return len(xs) >= 2 and sum(bool(PERIOD.match(x)) for x in xs) >= 0.8 * len(xs)


def head_rows(path, sheet=None, n=13):
    """The first n rows of a .csv / .xlsx table (a 200,000-row workbook is never read whole to tell a trend)."""
    import data_slides as DS
    p = DS.resolve(path)
    if p.suffix.lower() in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook
        wb = load_workbook(str(p), data_only=True, read_only=True)
        try:
            ws = wb[sheet] if sheet else wb.worksheets[0]
            rows = [["" if v is None else v for v in r] for r in ws.iter_rows(max_row=n, values_only=True)]
        finally:
            wb.close()
    else:
        import csv
        with open(p, encoding="utf-8-sig", errors="replace", newline="") as f:
            head = [line for _, line in zip(range(n), f)]
        rows = list(csv.reader(head, csv.Sniffer().sniff("".join(head)[:4096], delimiters=",;\t|")))
    return [r for r in rows if any(str(c).strip() for c in r)]


_SEEN = {}


def over_time(chart):
    """A column chart whose categories run over periods (months, quarters, weeks, years, dates): a trend."""
    if PERIOD_NAME.search(str(chart.get("x") or "")):
        return True
    key = (str(chart.get("data")), str(chart.get("sheet")), str(chart.get("x")))
    if key not in _SEEN:
        try:
            import data_slides as DS
            rows = head_rows(chart["data"], chart.get("sheet"))
            xi = DS.col(rows[0], chart.get("x", 0))
            _SEEN[key] = periodic([r[xi] for r in rows[1:] if xi < len(r)])
        except (Exception, SystemExit):            # (an unreadable file is the build's own error to report)
            _SEEN[key] = False
    return _SEEN[key]


def edges(d):
    """A diagram's flows as (from, to) pairs: "A → B: what" lines or {"flows": [{source, target}]}."""
    if isinstance(d, dict):
        return [(str(f.get("source")), str(f.get("target"))) for f in d.get("flows") or [] if isinstance(f, dict)]
    lines = d.splitlines() if isinstance(d, str) else [str(x) for x in d or [] if isinstance(x, str)]
    return [(m.group(1).lower(), m.group(2).lower()) for m in (FLOWS.match(l) for l in lines) if m]


def chain(d):
    """Flows that run one after another (A → B, B → C, C → D): steps in order, not a structure."""
    e = edges(d)
    outs, ins = [a for a, _ in e], [b for _, b in e]
    return (len(e) >= 2 and len(set(outs)) == len(e) and len(set(ins)) == len(e)
            and len(set(outs) | set(ins)) == len(e) + 1)


def device_of(spec):
    """How the slide tells its story (a key of WORDS), or None for a slide that tells none of its own."""
    if not isinstance(spec, dict):
        return None
    if spec.get("_glance"):
        return "summary"
    if spec.get("picture"):
        return "picture"
    if spec.get("library"):
        return None
    chart = spec.get("chart")
    if isinstance(chart, dict):
        t = str(chart.get("type") or "column")
        if t in ("line", "area", "pie", "doughnut", "stacked100"):
            return CHARTS[t]
        return "trend" if over_time(chart) else "rank" if t in ("bar", "column") else "share"
    if spec.get("modern"):
        m = str(spec["modern"])
        items = spec.get("items") if isinstance(spec.get("items"), list) else []
        if m in ("lollipop", "radialbar", "bubbles", "rose") and periodic([it[0] for it in items if isinstance(it, (list, tuple)) and it]):
            return "trend"                             # (twelve months as wedges or lollipops: still a run over time)
        return MODERN.get(m)
    if spec.get("graphic"):
        return GRAPHICS.get(str(spec["graphic"]))
    if spec.get("diagram"):
        style = str(spec.get("style") or "auto")
        return DIAGRAMS.get(style) or ("sequence" if style == "auto" and chain(spec["diagram"]) else "structure")
    if spec.get("timeline") is not None:
        return "time"
    if spec.get("swimlane") is not None:
        return "roles"
    if spec.get("process") is not None:
        return PROCESS.get(family_style(spec, "process"), "sequence")
    if spec.get("retail") is not None:
        full = expanded(spec)
        if isinstance(full.get("retail"), str):        # (an unknown starter: the build names it)
            return None
        return device_of(full) if full is not spec else RETAIL.get(family_style(full, "retail"), "sequence")
    way = next((w for key, w in INFOGRAPHICS.items() if spec.get(key) is not None), None)
    if way:
        return way
    K = consts()
    src = resolved(spec.get("source"))
    if src in K["display"]:
        return None
    if spec.get("bullets") is not None:
        return "points"
    if K["ulta"] and src in SOURCES:
        return SOURCES[src]
    if spec.get("table") is not None or spec.get("from"):
        return "table"
    return None


def expanded(spec):
    """A retail starter named by the slide ({"retail": "procure-to-pay"}): its full slide (tools/retail.py)."""
    if isinstance(spec.get("retail"), str):
        import retail as RT
        return RT.expand(spec)
    return spec


def family_style(spec, fam):
    """The style a process flow or retail diagram is drawn in: its own, else the one its data picks."""
    if spec.get("style"):
        return str(spec["style"])
    try:
        import importlib
        return str(importlib.import_module({"process": "flows", "retail": "retail"}[fam]).auto_style(spec[fam]))
    except Exception:
        return ""


def form_of(spec):
    """The slide's form in a few words, for messages: 'cards', 'a lollipop chart', 'a chevron diagram' ..."""
    if not isinstance(spec, dict):
        return "a slide"
    if spec.get("_glance"):
        return "At a glance"
    if spec.get("picture"):
        return "a picture"
    if isinstance(spec.get("chart"), dict):
        t = str(spec["chart"].get("type") or "column")
        return CHART_FORMS.get(t, f"a {t} chart")
    if spec.get("modern"):
        m = str(spec["modern"])
        return MODERN_FORMS.get(m, f"a {m}" + ("" if m in ("gantt", "swimlane", "sankey", "treemap", "sunburst", "waffle")
                                               else " chart"))
    if spec.get("graphic"):
        return f"a {spec['graphic']} graphic"
    if spec.get("diagram"):
        return f"a {spec.get('style') or 'system'} diagram"
    for fam in ("timeline", "swimlane"):
        if spec.get(fam) is not None:
            return f"a {spec.get('style') + ' ' if spec.get('style') else ''}{fam}"
    if spec.get("process") is not None:
        return PROCESS_FORMS.get(family_style(spec, "process"), "a process flow")
    if spec.get("retail") is not None:
        full = expanded(spec)
        if isinstance(full.get("retail"), str):
            return "a retail starter"
        return form_of(full) if full is not spec else RETAIL_FORMS.get(family_style(full, "retail"), "a retail diagram")
    key = next((k for k in INFOGRAPHICS if spec.get(k) is not None), None)
    if key:
        return {"quad": "four big numbers", "ogsm": "an OGSM", "priorities": "the vision house", "journey": "the journey",
                "results": "the results table", "scorecard": "a scorecard"}.get(key, f"a {key}")
    if spec.get("bullets") is not None:
        return "a bulleted list" if spec.get("plain") else "numbered tiles"
    src = resolved(spec.get("source"))
    return FORMS.get(src) or ("a table" if spec.get("table") is not None or spec.get("from") else "a slide")


def headline(spec):
    return " ".join(str(spec.get("headline") or spec.get("title") or "").split())


def marked(spec):
    """'(cont.)', '(continued)', '(2/3)', '- part 2' ... in the headline: the slide says it carries on."""
    h = headline(spec)
    return bool(MARK.search(h) or LEAD.match(h))


def claims(spec):
    return isinstance(spec, dict) and (marked(spec) or spec.get("continues") is True)


def stem(spec):
    """The headline's words that carry its subject (the continuation mark left out)."""
    out = set()
    for w in re.findall(r"[a-z][a-z'’-]{3,}", LEAD.sub("", MARK.sub("", headline(spec))).lower()):
        w = w.rstrip("'’")
        if w in STOP:
            continue
        out.add((w[:-1] if len(w) > 4 and w.endswith("s") else w)[:6])
    return out


def labels(spec):
    """The short names a slide shows (items, columns, nodes, rows, series, its data file): its subject."""
    out = set()

    def add(s):
        s = " ".join(str(s or "").split()).lower().strip(" .:;,")
        if s and len(s.split()) <= 6 and not re.fullmatch(r"[\d\s.,%$+()/-]*", s):
            out.add(s)

    def walk(v):
        if isinstance(v, str):
            parts = v.split(":", 1) if ":" in v and len(v.split(":", 1)[0].split()) <= 4 else [v]
            add(parts[0])
            for line in v.split("\n")[1:2]:
                add(line)
        elif isinstance(v, dict):
            for k, x in v.items():
                if k not in SKIP:
                    walk(x)
        elif isinstance(v, (list, tuple)):
            for x in v:
                walk(x)
    if spec.get("diagram"):
        for a, b in edges(spec["diagram"]):
            add(a), add(b)
    walk({k: v for k, v in spec.items() if k not in SKIP and k != "diagram"})
    return out


def same_subject(prev, cur):
    a, b = labels(prev), labels(cur)
    shared = a & b
    return (len(shared) >= 2 and len(shared) >= 0.4 * min(len(a), len(b))) or len(stem(prev) & stem(cur)) >= 2


def continues(prev, cur):
    """cur carries on prev, so it may tell its story the same way: it says so (a mark in its headline, or "continues":
    true) and shares prev's subject; a numbered list that carries on prev's numbering."""
    if not (isinstance(prev, dict) and isinstance(cur, dict)):
        return False
    if isinstance(prev.get("bullets"), list) and isinstance(cur.get("bullets"), list) and cur.get("numbered") \
            and isinstance(cur.get("start"), int) and cur["start"] == int(prev.get("start") or 1) + len(prev["bullets"]):
        return True
    if marked(cur):                                 # the audience sees the mark: one shared word or the same form will do
        return same_subject(prev, cur) or bool(stem(prev) & stem(cur)) or form_of(prev) == form_of(cur)
    return cur.get("continues") is True and same_subject(prev, cur)


# Other ways to tell what a slide of each way holds: (way, how, look). Never one a neighbour already tells its story with.
OTHER = {
    "points": [("sequence", "a flow (20: 3-6 steps, a 1-3 word label and 2-6 words each) if the points happen in order", "process"),
               ("table", "a table if every point has the same details (owner, date, status)", "table"),
               ("numbers", "big numbers (headline-metrics) if each point has a figure", "numbers"),
               ("time", "a timeline if the points have dates", None),
               ("structure", "a diagram if the points depend on each other", None),
               ("compare", "paired columns (42) if they set one side against another", "columns")],
    "sequence": [("time", "a timeline if the steps have dates", None),
                 ("roles", "a swimlane if the steps pass between teams", None),
                 ("table", "a table of step, owner and output", "table"),
                 ("structure", "a diagram of who hands what to whom", None),
                 ("points", "numbered tiles of what each step delivers", "tiles")],
    "time": [("table", "the action table (12): what, detail, when and who", "table"),
             ("sequence", "a flow of the phases, the dates in the notes", "process"),
             ("numbers", "big numbers: days to launch, milestones done", "numbers"),
             ("points", "tiles: what each phase delivers", "tiles")],
    "numbers": [("trend", "a trend line of the number that moved", None),
                ("compare", "a dumbbell or slope chart of before and after", None),
                ("rank", "a ranked chart (lollipop) of the figures", None),
                ("points", "tiles that say what the numbers mean", "tiles")],
    "scorecard": [("numbers", "big numbers for the two or three KPIs that matter", "numbers"),
                  ("trend", "a trend line of the KPI that moved", None),
                  ("rank", "a ranked chart of the gaps to target", None)],
    "trend": [("numbers", "big numbers: the latest value and the change", "numbers"),
              ("compare", "a slope chart of the start and the end", None),
              ("rank", "a ranked chart of the change by item", None),
              ("share", "the mix behind the trend (100% bars)", None)],
    "rank": [("share", "a donut or treemap if the items add up to a whole", None),
             ("numbers", "big numbers for the top two or three", "numbers"),
             ("trend", "a trend line if the values run over time", None),
             ("compare", "a dumbbell of before and after", None)],
    "share": [("rank", "a ranked chart (lollipop or bars)", None),
              ("numbers", "big numbers for the largest parts", "numbers"),
              ("trend", "how the mix changes over time (stacked columns by period)", None)],
    "compare": [("numbers", "big numbers with a context line (+5 pts, 91% to 96%)", "numbers"),
                ("rank", "a ranked chart of the change", None),
                ("table", "a table: item, before, after", "table"),
                ("points", "tiles", "tiles")],
    "structure": [("sequence", "a flow if the parts run in order", "process"),
                  ("table", "a table of part, owner and role", "table"),
                  ("points", "tiles, one per part", "tiles"),
                  ("matrix", "a 2x2 if the parts sort on two axes", None)],
    "matrix": [("table", "a table", "table"), ("rank", "a ranked chart", None), ("points", "tiles, one per quadrant", "tiles")],
    "table": [("points", "cards or tiles with the key rows", "tiles"),
              ("numbers", "big numbers if the rows carry figures", "numbers"),
              ("time", "a timeline if the rows have dates", None),
              ("rank", "a chart if the rows share one measure", None)],
    "map": [("rank", "a ranked chart of the regions", None), ("numbers", "big numbers for the leading regions", "numbers"),
            ("table", "a table", "table")],
    "roles": [("sequence", "a flow of the steps alone, the teams in the notes", "process"),
              ("table", "a table of activity, team and output", "table"), ("points", "tiles: what each team does", "tiles")],
    "people": [("roles", "a RACI (swimlane, style matrix)", None), ("points", "tiles: who does what", "tiles")],
    "summary": [(None, 'one summary only: drop "glance" or the recap slide', None)],
    "picture": [("points", "tiles that call out what the picture shows", "tiles"),
                ("numbers", "big numbers beside the story the picture tells", "numbers")],
}
MERGE = {"numbers": "both sets of numbers on one slide", "scorecard": "one scorecard", "trend": "one chart with both series",
         "rank": "one chart with both series", "share": "one chart of both", "table": "one table",
         "time": "one timeline", "picture": "both pictures on one slide", "points": "one slide of the points that matter"}
SUGGESTED = {"the risk table": "table", "the action table": "table", "a diagram": "structure", "a donut": "share",
             "big numbers with a context line": "numbers", "a dumbbell": "compare", "a timeline": "time",
             "big numbers": "numbers", "a chart": "rank", "a flow": "sequence", "a process flow in two rows": "sequence",
             "numbered tiles": "points"}                  # deck_expert.suggest's pictures and the way each tells a story


def retail_fit(spec):
    """The retail form a slide's content calls for (SKILL.md rule 10: a supply chain or a retail process is shown as a
    retail diagram first; tools/retail.py fit), or None. retail.py loads only for a slide with items to read: points,
    a flow, a process flow or a diagram."""
    if not isinstance(spec, dict) or spec.get("retail") is not None or spec.get("retail_first") is False or \
            not any(spec.get(k) for k in ("bullets", "steps", "process", "diagram")):
        return None
    import retail as RT
    return RT.fit(spec)


def fit_way(f):
    """The way the form a retail_fit() names tells its story."""
    if f.get("spec"):
        return device_of(f["spec"])
    import retail as RT
    return device_of(RT.expand({"retail": f["form"]})) if f["form"] in RT.STARTERS else RETAIL.get(f["form"], "sequence")


def fit_form(f):
    """The form a retail_fit() names, in a few words: 'a document flow', 'the procure to pay starter' ..."""
    if f.get("spec"):
        return form_of(f["spec"]) + (" with retail pictograms" if f["form"] == "process" else "")
    return RETAIL_FORMS.get(f["form"]) or f"the {f['form'].replace('-', ' ')} starter"


def advice(spec, ways=(), looks=()):
    """Up to three other ways to tell this slide's story, none of them a way (or look) of the slides around it - first
    a retail diagram when the slide's content is a supply chain or a retail process, then the picture its content asks
    for (dates a timeline, figures big numbers, steps a flow ...)."""
    way, opts, said = device_of(spec), [], set()
    f = retail_fit(spec)
    if f and fit_way(f) not in set(ways) | {way}:
        opts.append(f"{fit_form(f)} ({f['why']}: {f['shape']})")
        said.add(fit_way(f))
    try:
        import deck_expert as DX
        sg = DX.suggest(spec, 0, DX.consts())
        if sg and SUGGESTED.get(sg[1]) not in set(ways) | {way}:
            opts.append(f"{sg[1]} ({sg[0]}: {sg[2]})")
            said.add(SUGGESTED.get(sg[1]))
    except Exception:
        pass
    opts += [how for w, how, lk in OTHER.get(way, []) if w not in ways and w not in said and (lk is None or lk not in looks)]
    opts = list(dict.fromkeys(opts))[:2] + ([MERGE[way] + " (merge the two)"] if way in MERGE else [])
    return ("either " + ", or ".join(opts) if len(opts) > 1 else opts[0] if opts
            else "another way (python tools/build_deck.py inventory)")


def spread(items, way=None, before=None, strict=False):
    """The items in an order where no two in a row tell their story one way (nor the first the way `before` does),
    keeping the given order wherever it can. With strict, None when no order can; else as few pairs as it can."""
    import collections
    way = way or device_of
    ways = [way(x) for x in items]
    left, out, last = list(range(len(items))), [], before

    def can(rest, last):                           # the rest can follow a slide told `last`: no way fills more than
        n = len(rest)                              # every other place (one less when the first place is barred to it)
        return all(c <= (n // 2 if w == last else (n + 1) // 2)
                   for w, c in collections.Counter(ways[i] for i in rest if ways[i]).items())
    while left:
        i = next((i for i in left if (ways[i] is None or ways[i] != last) and can([j for j in left if j != i], ways[i])), None)
        if i is None:
            if strict:
                return None
            i = next((i for i in left if ways[i] is None or ways[i] != last), left[0])
        out.append(i)
        left.remove(i)
        last = ways[i]
    return [items[i] for i in out]


def choose(cands, n, before=None, way=None):
    """n of the candidates (best first) laid out so that no two in a row tell their story one way: the best n, the
    lowest of the most repeated way swapped for the next best told another way until they can be."""
    import collections
    way = way or device_of
    out, rest = list(cands[:n]), list(cands[n:])
    while out and spread(out, way, before, strict=True) is None:
        top = collections.Counter(w for w in map(way, out) if w).most_common(1)[0][0]
        k = next((k for k, x in enumerate(rest) if way(x) != top), None)
        if k is None:
            break
        out[max(i for i, x in enumerate(out) if way(x) == top)] = rest.pop(k)
    return spread(out, way, before)


def clashes(slides, gallery=False):
    """[(k, way)] for each slide k (1-based) that tells its story the way slide k-1 does and does not continue it."""
    if gallery:
        return []
    ways = [device_of(s) for s in slides]
    return [(k + 1, ways[k]) for k in range(1, len(slides))
            if ways[k] and ways[k] == ways[k - 1] and not continues(slides[k - 1], slides[k])]


def message(slides, k, way, looks=()):
    """The build's line for slides k-1 and k (1-based) telling their story one way."""
    prev, cur = slides[k - 2], slides[k - 1]
    around = [device_of(slides[i]) for i in (k - 2, k) if 0 <= i < len(slides)]
    a, b = form_of(prev), form_of(cur)
    said = (f" - it is marked as carrying on slide {k - 1}, but shares neither its subject nor its form"
            if claims(cur) else "")
    return (f"slides {k - 1} and {k} tell their story the same way (both {WORDS[way]}: "
            f"{a + ', then ' + b if a != b else 'two of ' + a.removeprefix('a ').removeprefix('the ')}) - two slides in "
            f"a row told one way read as one point made twice{said}. Tell slide {k}'s story another way: "
            f"{advice(cur, around, looks)}; or put a slide told another way between them; if slide {k} carries on "
            f"slide {k - 1}, say so: \"(cont.)\" or \"(2/2)\" in its headline")


def main():
    import argparse
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("storyboard")
    a = ap.parse_args()
    story = json.loads(Path(a.storyboard).read_text(encoding="utf-8"))
    import data_slides as DS
    DS.BASE.append(Path(a.storyboard).resolve().parent)
    slides = [s for s in story.get("slides") or [] if isinstance(s, dict)]
    for k, s in enumerate(slides, 1):
        way = device_of(s)
        print(f"slide {k}: {way + ' (' + form_of(s) + ')' if way else '-'}"
              + (" | continues the slide before" if k > 1 and way and continues(slides[k - 2], s) else ""))
    found = clashes(slides, bool(story.get("gallery")))
    for k, way in found:
        print("CLASH " + message(slides, k, way))
    shown = [w for w in (device_of(s) for s in slides) if w]
    print(f"{len(set(shown))} ways of telling over {len(shown)} content slides"
          + (" | a catalogue (\"gallery\"): one kind on purpose" if story.get("gallery") else "")
          + (f" | {len(found)} pair(s) told the same way" if found else " | no two slides in a row told the same way"))
    return 1 if found else 0


if __name__ == "__main__":
    sys.exit(main())
