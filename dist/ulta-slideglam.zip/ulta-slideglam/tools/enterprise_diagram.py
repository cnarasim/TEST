"""Architecture diagrams to the ULTA Enterprise Diagram Standards v0.7.0 (brands/ulta/diagram_standard.json).

    python tools/enterprise_diagram.py arch.json --out /mnt/data/out/<Name>
        -> <Name>.drawio (editable, the standard's own format), <Name>.svg, <Name>.png, <Name>.pdf,
           <Name>.html (interactive: hover a system or a Flow Legend row to trace its flows; Export PDF)

The model only describes zones, systems and numbered flows. This tool does the standard's layout and routing:
zone columns with sized gutters, port stagger (shapes grow to keep 20 px between anchors), fan-out lane nesting,
reverse flows on the bottom return ring, full corner lists on every connector, badges by the Rule 9 candidate
scan, then the Step 8b geometry audit (A1-A10). Nothing is written when the audit finds a violation.
Every file ends with the 28 Step 13 checks (+ text fit and sensitive data) as ULTA Standards Match.

arch.json:
{"title": "AI Enterprise · Merch · PIM Category Attribute Enrichment",      ("ULTA Beauty - " is added)
 "subtitle": "Enterprise-wide C2 Container View · Target state (Gate 1 concept)",
 "gate": 1, "created": "2026-10-12",                                         (Last Modified = today)
 "zones": [{"id": "sor", "name": "Internal Core SoR - Item Master", "kind": "core"},
           {"id": "saas", "name": "Enrichment Content Sources (SaaS)", "kind": "saas", "above": "darwin"}, ...],
 "systems": [{"id": "pim", "name": "PIM (Riversand)", "sub": "Item master · category attributes", "zone": "sor",
              "state": "modified", "shape": "rect|cylinder|diamond", "row": 0, "kdd": "KDD-002"}, ...],
 "flows": [{"step": "1.0", "from": "vendor", "to": "pim", "type": "sync|async|optional|rejection",
            "desc": "Brands submit item and category attributes"}, ...],
 "kdd": [{"id": "KDD-001", "title": "Controlled generation", "text": "..."}],
 "evidence": [{"title": "Reuse before build", "text": "..."}]}
zone kind: dmz | saas | core | downstream.  state: existing | modified | new | retire | future.
row 0 = the zone's main line (left to right in list order); row 1, 2 = supporting systems placed under the system
they connect to. A zone with "above": "<zone id>" sits over that zone, its systems over the ones they feed.
"""
import argparse, datetime, html, json, math, os, re, sys
import xml.etree.ElementTree as ET
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
sys.path.insert(0, str(TOOLS))
STD = json.loads((ROOT / "brands" / "ulta" / "diagram_standard.json").read_text(encoding="utf-8"))
G = STD["geometry"]
SEP, CLR = G["lane_sep"], G["shape_clearance"]
HEAD = 24

# ---------------------------------------------------------------- text measuring (Helvetica AFM widths, /1000 em)
_W = dict(zip(" !\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~",
              [278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278] + [556] * 10 +
              [278, 278, 584, 584, 584, 556, 1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722,
               778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, 333, 556, 556, 500,
               556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500,
               500, 500, 334, 260, 334, 584]))
_W.update({"·": 278, "—": 1000, "–": 556, "→": 1000, "×": 584, "…": 1000, "’": 222, "“": 333, "”": 333})


def tw(s, size, bold=False):
    return sum(_W.get(c, 600) for c in s) * size / 1000 * (1.08 if bold else 1.0)


def split_long(word, size, width, bold=False):
    """A token wider than the box (API_SALES_ORDER_SRV) breaks after _ / . - or, failing that, by characters."""
    if tw(word, size, bold) <= width:
        return [word]
    parts, cur = [], ""
    for ch in word:
        if cur and tw(cur + ch, size, bold) > width:
            cut = max(cur.rfind(c) for c in "_/.-")
            if cut > 0:
                parts.append(cur[:cut + 1]); cur = cur[cut + 1:]
            else:
                parts.append(cur); cur = ""
        cur += ch
    return parts + ([cur] if cur else [])


def wrap(s, size, width, bold=False):
    out, cur = [], ""
    words = [p for w in str(s or "").split() for p in split_long(w, size, width, bold)]
    for word in words:
        t = (cur + " " + word).strip()
        if tw(t, size, bold) <= width or not cur:
            cur = t
        else:
            out.append(cur); cur = word
    if cur:
        out.append(cur)
    return out


def esc(s):
    return html.escape(str(s), quote=True)


# ---------------------------------------------------------------- model
class Node:
    def __init__(self, d, i):
        self.id, self.i = str(d["id"]), i
        self.name, self.sub = str(d.get("name") or d["id"]), str(d.get("sub") or d.get("desc") or "")
        self.note = str(d.get("note") or "")
        self.kdd = d.get("kdd") or []
        self.kdd = [self.kdd] if isinstance(self.kdd, str) else list(self.kdd)
        self.zone, self.state = str(d.get("zone") or ""), str(d.get("state") or "existing").lower()
        self.shape = str(d.get("shape") or "rect").lower()
        self.row = int(d.get("row") or 0)
        self.placed_by_user = d.get("row") is not None or d.get("col") is not None
        self.col, self.span = d.get("col"), int(d.get("span") or 1)
        sh = STD["shapes"].get(self.shape, STD["shapes"]["rect"])
        self.mw, self.mh = sh["w"], sh["h"]                 # standard size; grows for text or port demand
        self.x = self.y = 0.0
        self.w, self.h = self.mw, self.mh

    @property
    def cx(self): return self.x + self.w / 2

    @property
    def cy(self): return self.y + self.h / 2

    def rect(self, pad=0): return (self.x - pad, self.y - pad, self.x + self.w + pad, self.y + self.h + pad)

    def lines(self):
        wdt = self.w * 0.62 if self.shape == "diamond" else self.w - 12
        name = wrap(self.name, 10, wdt, True)
        sub = wrap(self.sub, 9, wdt)
        note = wrap(" · ".join(self.kdd + ([self.note] if self.note else [])), 8, wdt)
        return name, sub, note

    def text_h(self):
        n, s, t = self.lines()
        return len(n) * 12.5 + len(s) * 11 + len(t) * 10 + 14 + (15 if self.shape == "cylinder" else 0)


class Zone:
    def __init__(self, d, i):
        self.id, self.i, self.name = str(d["id"]), i, str(d.get("name") or d["id"])
        k = str(d.get("kind") or "saas").lower()
        self.kind = STD["zone_aliases"].get(k, k)
        self.above, self.below = d.get("above"), d.get("below")
        self.nodes = []
        self.x = self.y = self.w = self.h = 0.0

    def rect(self): return (self.x, self.y, self.x + self.w, self.y + self.h)


class Edge:
    def __init__(self, d, i):
        self.i, self.step = i, str(d.get("step") or "")
        self.src, self.tgt = str(d.get("from") or d.get("source")), str(d.get("to") or d.get("target"))
        t = str(d.get("type") or "sync").lower()
        self.kind = {"api": "sync", "odata": "sync", "batch": "async", "event": "async", "conditional": "optional",
                     "rollback": "rejection", "exception": "rejection"}.get(t, t)
        self.desc = str(d.get("desc") or d.get("description") or "")
        self.pts, self.plan, self.sides, self.badge, self.reverse = [], None, None, None, False


# ---------------------------------------------------------------- geometry helpers
def seg_list(pts):
    return [(pts[k], pts[k + 1]) for k in range(len(pts) - 1)]


def seg_hits_rect(a, b, r):
    """True when the axis-aligned segment a-b enters the open rectangle r."""
    x1, y1, x2, y2 = r
    if a[1] == b[1]:
        lo, hi = sorted((a[0], b[0]))
        return y1 < a[1] < y2 and lo < x2 and hi > x1
    lo, hi = sorted((a[1], b[1]))
    return x1 < a[0] < x2 and lo < y2 and hi > y1


def rects_touch(r, s, pad=0):
    return r[0] - pad < s[2] and r[2] + pad > s[0] and r[1] - pad < s[3] and r[3] + pad > s[1]


def horiz(s): return abs(s[0][1] - s[1][1]) < 1e-6


def overlap(a1, a2, b1, b2):
    lo1, hi1 = sorted((a1, a2)); lo2, hi2 = sorted((b1, b2))
    return min(hi1, hi2) - max(lo1, lo2)


def crosses(s, t):
    """Interior crossing of a horizontal and a vertical segment."""
    if horiz(s) == horiz(t):
        return False
    h, v = (s, t) if horiz(s) else (t, s)
    y, x = h[0][1], v[0][0]
    hx = sorted((h[0][0], h[1][0])); vy = sorted((v[0][1], v[1][1]))
    return hx[0] + 1 < x < hx[1] - 1 and vy[0] + 1 < y < vy[1] - 1


def length(pts): return sum(abs(a[0] - b[0]) + abs(a[1] - b[1]) for a, b in seg_list(pts))


def point_at(pts, f):
    tot, goal = length(pts), length(pts) * f
    for a, b in seg_list(pts):
        L = abs(a[0] - b[0]) + abs(a[1] - b[1])
        if goal <= L and L:
            t = goal / L
            return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)
        goal -= L
    return pts[-1]


def simplify(pts):
    out = []
    for p in pts:
        p = (round(p[0], 1), round(p[1], 1))
        if out and p == out[-1]:
            continue
        if len(out) >= 2 and ((out[-2][0] == out[-1][0] == p[0]) or (out[-2][1] == out[-1][1] == p[1])):
            out[-1] = p
            continue
        out.append(p)
    return out


# ---------------------------------------------------------------- the diagram
class Diagram:
    def __init__(self, d):
        self.d = d
        self.zones = [Zone(z, i) for i, z in enumerate(d.get("zones") or [])]
        self.zmap = {z.id: z for z in self.zones}
        self.nodes = [Node(n, i) for i, n in enumerate(d.get("systems") or d.get("nodes") or [])]
        self.nmap = {n.id: n for n in self.nodes}
        self.edges = [Edge(e, i) for i, e in enumerate(d.get("flows") or [])]
        self.problems = []                                   # input problems (FAIL lines)
        for n in self.nodes:
            if n.zone in self.zmap:
                self.zmap[n.zone].nodes.append(n)
        self.extra = {"col": 0, "gutter": 0, "row": 0, "inset": 0, "vgap": 0}
        self.grow = {}                                       # node id -> (min w, min h) from port demand

    # ---- layout ------------------------------------------------------------
    def grid(self):
        """(row, col, span) of every system inside its zone."""
        nb = {}
        for e in self.edges:
            nb.setdefault(e.src, []).append(e.tgt); nb.setdefault(e.tgt, []).append(e.src)
        hosts = {z.id: self.zmap[z.above or z.below].id for z in self.zones if (z.above or z.below) in self.zmap}
        for z in self.zones:
            if z.id in hosts or not z.nodes or any(n.placed_by_user for n in z.nodes):
                continue
            self.auto_grid(z)                               # no rows given: lay the zone out from its own flows
        for z in self.zones:
            if z.id in hosts:
                continue
            if z.nodes and not any(n.placed_by_user for n in z.nodes):
                continue
            taken, nxt = set(), 0
            for n in sorted(z.nodes, key=lambda n: (n.row, n.i)):
                if n.row == 0:
                    n.col = n.col if n.col is not None else nxt
                    nxt = n.col + 1
                    taken |= {(0, n.col + k) for k in range(n.span)}
            for r in sorted({n.row for n in z.nodes if n.row > 0}):
                rown = [m for m in sorted(z.nodes, key=lambda m: m.i) if m.row == r]
                cross_row = lambda m: any(o in self.nmap and self.nmap[o].zone == z.id and self.nmap[o].row != r for o in nb.get(m.id, []))
                for n in sorted(rown, key=lambda m: (not cross_row(m), m.i)):
                    if n.col is None:
                        cols = sorted({self.nmap[o].col for o in nb.get(n.id, []) if o in self.nmap and self.nmap[o].zone == z.id
                                       and self.nmap[o].row != r and self.nmap[o].col is not None})
                        if len(cols) > 1 and n.span == 1 and n.shape == "rect":
                            n.span, n.col = cols[-1] - cols[0] + 1, cols[0]
                        else:
                            same = [self.nmap[o] for o in nb.get(n.id, []) if o in self.nmap and self.nmap[o].zone == z.id
                                    and self.nmap[o].row == r and self.nmap[o].col is not None]
                            n.col = cols[0] if cols else ((same[0].col - 1 if any(e.src == n.id and e.tgt == same[0].id for e in self.edges)
                                                           else same[0].col + 1) if same else 0)
                        n.col = max(0, n.col)
                    want = n.col
                    for dc in (0, -1, 1, -2, 2, 3, 4, 5, 6, 7, 8):
                        c = want + dc
                        if c >= 0 and not any((r, c + k) in taken for k in range(n.span)):
                            n.col = c
                            break
                    else:
                        while any((r, n.col + k) in taken for k in range(n.span)):
                            n.col += 1
                    taken |= {(r, n.col + k) for k in range(n.span)}
                    nxt = max(nxt, n.col + n.span)
        for z in self.zones:                                 # zones over/under a host: columns of what they feed
            if z.id not in hosts:
                continue
            host = self.zmap[hosts[z.id]]
            used = set()
            for n in sorted(z.nodes, key=lambda m: m.i):
                cols = [self.nmap[o].col for o in nb.get(n.id, []) if o in self.nmap and self.nmap[o].zone == host.id]
                c = n.col if n.col is not None else (cols[0] if cols else (max(used) + 1 if used else 0))
                while c in used:
                    c += 1
                n.col, n.row = c, 0
                used.add(c)
        # left-most columns start at 0 per zone
        for z in self.zones:
            if z.nodes and z.id not in hosts:
                m = min(n.col for n in z.nodes)
                for n in z.nodes:
                    n.col -= m

    def auto_grid(self, z):
        """Columns = dependency depth along the zone's own flows (left to right); systems at the same depth stack in rows,
        ordered by where their neighbours sit. A zone with no flows inside it becomes one column (at most 4 high)."""
        ids = {n.id for n in z.nodes}
        inner = [(e.src, e.tgt) for e in self.edges if e.src in ids and e.tgt in ids]
        order = {n.id: n.i for n in z.nodes}
        depth = {n.id: 0 for n in z.nodes}
        for _ in range(len(ids)):                           # longest path, back edges (by list order) ignored
            ch = False
            for a, b in inner:
                if order[a] < order[b] and depth[b] < depth[a] + 1:
                    depth[b] = depth[a] + 1; ch = True
            if not ch:
                break
        if not inner:
            per = max(1, math.ceil(len(z.nodes) / 4))
            rows = math.ceil(len(z.nodes) / per)
            for k, n in enumerate(sorted(z.nodes, key=lambda m: m.i)):
                n.col, n.row = k // rows, k % rows
            return
        cols = {}
        for n in sorted(z.nodes, key=lambda m: m.i):
            cols.setdefault(depth[n.id], []).append(n)
        pos = {}
        for c in sorted(cols):
            lst = cols[c]
            def bary(n):                                     # mean row of in-zone neighbours already placed
                rs = [pos[o] for a, b in inner for o in ((a,) if b == n.id else (b,) if a == n.id else ()) if o in pos]
                return (sum(rs) / len(rs)) if rs else 99 + n.i
            lst.sort(key=bary)
            used = set()
            for n in lst:
                want = bary(n)
                r = int(round(want)) if want < 99 else 0
                while r in used:
                    r += 1
                used.add(r)
                n.col, n.row = c, r
                pos[n.id] = r
        for n in z.nodes:
            n.span = 1

    def size_nodes(self):
        for n in self.nodes:
            gw, gh = self.grow.get(n.id, (0, 0))
            n.w = max(n.mw, gw)
            n.h = n.mh
            if n.shape == "diamond":
                n.w = n.h = max(n.mw, gw, gh, 80)
                for _ in range(12):
                    if n.text_h() + 30 > n.h * 0.8 or len(n.lines()[0]) > 3:
                        n.w = n.h = n.h + 10
                continue
            n.h = max(n.mh, gh, math.ceil(n.text_h() / 5) * 5)

    def layout(self):
        self.size_nodes()
        CG, RG = 60 + self.extra["col"], 40 + self.extra["row"]
        INS = G["inset"] + self.extra["inset"]
        hosts = {z.id: (z.above or z.below) for z in self.zones if (z.above or z.below) in self.zmap}
        main = [z for z in self.zones if z.id not in hosts]
        # column widths per zone (span-1 systems), shared by zones stacked over it
        self.colw = {}
        for z in main:
            members = z.nodes + [n for s in self.zones if hosts.get(s.id) == z.id for n in s.nodes]
            ncol = max([n.col + n.span for n in members] or [1])
            cw = [140.0] * ncol
            for n in members:
                if n.span == 1:
                    cw[n.col] = max(cw[n.col], n.w)
            self.colw[z.id] = cw
        nrow = max([n.row for z in main for n in z.nodes] or [0]) + 1
        rowh = [60.0] * nrow
        for z in main:
            for n in z.nodes:
                rowh[n.row] = max(rowh[n.row], n.h if n.span == 1 or n.shape != "rect" else 60)
        x = 50.0
        top = 0.0
        zh = HEAD + INS + sum(rowh) + RG * (nrow - 1) + INS
        for k, z in enumerate(main):
            cw = self.colw[z.id]
            z.x, z.y = x, top
            z.w = INS * 2 + sum(cw) + CG * (len(cw) - 1)
            pad = max(0.0, (tw(z.name, 12, True) + 48 - z.w) / 2)   # a title never runs past its zone
            z.w += 2 * pad
            z.h = zh
            colx = [z.x + INS + pad + sum(cw[:c]) + CG * c for c in range(len(cw))]
            z.colx = colx
            for n in z.nodes:
                if n.span > 1 and n.shape == "rect":
                    n.w = colx[n.col + n.span - 1] + cw[n.col + n.span - 1] - colx[n.col]
                    n.x = colx[n.col]
                else:
                    n.x = colx[n.col] + (cw[n.col] - n.w) / 2
                ry = z.y + HEAD + INS + sum(rowh[:n.row]) + RG * n.row
                n.y = ry + (rowh[n.row] - n.h) / 2
            gut = max(G["lane_sep"] * (self.fan.get(z.id, 3) + 1) + 40, 140) + self.extra["gutter"]
            x = z.x + z.w + gut
        for z in self.zones:                                  # stacked zones
            if z.id not in hosts:
                continue
            host = self.zmap[hosts[z.id]]
            cw, colx = self.colw[host.id], host.colx
            h = max([n.h for n in z.nodes] or [60])
            cols = [n.col for n in z.nodes] or [0]
            z.x = colx[min(cols)] - INS
            z.w = colx[max(cols)] + cw[max(cols)] + INS - z.x
            need = tw(z.name, 12, True) + 48
            if z.w < need:
                z.x -= (need - z.w) / 2; z.w = need
            z.h = HEAD + INS + h + INS
            n_cross = sum(1 for e in self.edges if {self.nmap[e.src].zone, self.nmap[e.tgt].zone} == {z.id, host.id})
            vg = max(100, G["lane_sep"] * (n_cross + 1) + 40) + self.extra["vgap"]
            z.y = host.y - vg - z.h if z.above else host.y + host.h + vg
            for n in z.nodes:
                n.x = colx[n.col] + (cw[n.col] - n.w) / 2
                n.y = z.y + HEAD + INS + (h - n.h) / 2

    # ---- routing -----------------------------------------------------------
    def classify(self, e):
        s, t = self.nmap[e.src], self.nmap[e.tgt]
        xo = overlap(s.x, s.x + s.w, t.x, t.x + t.w)
        below = t.y >= s.y + s.h
        if xo > 10:                                           # same column: straight down / up
            return (["VD", "VU"] if below else ["VU", "VD"]) + ["BRING", "TRING"]
        stacked = self.zmap[s.zone] is not self.zmap[t.zone] and any(
            self.zmap[z].above or self.zmap[z].below for z in (s.zone, t.zone))
        if t.x >= s.x + s.w:                                  # forward
            band = overlap(s.y, s.y + s.h, t.y, t.y + t.h) > 10
            clear = band and not any(m.id not in (s.id, t.id) and m.x > s.x + s.w and m.x + m.w < t.x and
                                     overlap(m.y, m.y + m.h, min(s.cy, t.cy) - 30, max(s.cy, t.cy) + 30) > 0 for m in self.nodes)
            if clear:
                return ["H", "RT", "RB", "TRING", "BRING", "TRING2", "BRING2"]
            if stacked:
                v = ["VD", "RT", "BL"] if below else ["VU", "RB", "TL"]
                return v + ["H", "TRING", "BRING", "TRING2", "BRING2"]
            if not band:                                      # staggered fan-out: exit right, lane in the gutter, enter left
                return ["H"] + (["RT", "BL", "VD"] if below else ["RB", "TL", "VU"]) + ["TRING", "BRING", "TRING2", "BRING2"]
            return ["TRING", "BRING", "H", "RT", "RB", "TRING2", "BRING2"]
        if s.zone == t.zone and s.row != t.row:              # up-left / down-left inside one zone
            return (["TR", "LB"] if not below else ["BR", "LT"]) + (["VU"] if not below else ["VD"]) + ["RING", "RINGGAP", "RINGB"]
        e.reverse = True
        if stacked:
            return (["VD"] if below else ["VU"]) + ["RING", "RINGGAP", "RINGB", "RRING", "RRINGGAP", "RRINGB"]
        return ["RING", "RINGGAP", "RINGB", "RRING", "RRINGGAP", "RRINGB"]

    SIDES = {"H": ("R", "L"), "VD": ("B", "T"), "VU": ("T", "B"), "RT": ("R", "T"), "RB": ("R", "B"), "BL": ("B", "L"),
             "TL": ("T", "L"), "TRING": ("T", "T"), "BRING": ("B", "B"), "RING": ("B", "L"), "RINGB": ("B", "B"),
             "RINGGAP": ("B", "L"), "RRING": ("R", "L"), "RRINGB": ("R", "B"), "RRINGGAP": ("R", "L"),
             "TR": ("T", "R"), "TRING2": ("T", "T"), "BRING2": ("B", "B"), "LB": ("L", "B"), "BR": ("B", "R"), "LT": ("L", "T")}

    def sides_of(self, plan):
        return (plan[2], plan[3]) if plan.startswith("M:") else self.SIDES[plan]

    def maze_plans(self, e):
        """Last resort for any flow: a shortest orthogonal path through the free channels, tried from the most natural
        pair of faces first."""
        s, t = self.nmap[e.src], self.nmap[e.tgt]
        h = "RL" if t.cx >= s.cx else "LR"
        v = "BT" if t.cy >= s.cy else "TB"
        combos = [h, v, h[0] + v[1], v[0] + h[1], "BB", "TT", "RR", "LL"]
        seen = []
        for c in combos:
            if c not in seen:
                seen.append(c)
        return ["M:" + c for c in seen[:5]]

    def maze(self, e, s, t, P, Q, es, en):
        """Dijkstra over a sparse grid of candidate lane coordinates (shape edges ± clearance, mid-gaps, ring lanes).
        Hard rules are the same as every other plan; crossings cost, bends cost."""
        import heapq
        D = {"L": (-1, 0), "R": (1, 0), "T": (0, -1), "B": (0, 1)}
        st = 18
        P1 = (P[0] + D[es][0] * st, P[1] + D[es][1] * st)
        Q1 = (Q[0] + D[en][0] * st, Q[1] + D[en][1] * st)
        top = min(z.y for z in self.zones) - G["ring_gap"]
        bot = max(z.y + z.h for z in self.zones) + G["ring_gap"]
        xs, ys = {P1[0], Q1[0]}, {P1[1], Q1[1]}
        for m in self.nodes:
            xs |= {m.x - CLR - 6, m.x + m.w + CLR + 6, m.x - CLR - 26, m.x + m.w + CLR + 26}
            ys |= {m.y - CLR - 6, m.y + m.h + CLR + 6, m.y - CLR - 26, m.y + m.h + CLR + 26}
        for z in self.zones:
            xs |= {z.x - 20, z.x + 20, z.x + z.w - 20, z.x + z.w + 20, z.x - 40, z.x + z.w + 40}
            ys |= {z.y + HEAD + 18, z.y + z.h - 20, z.y + z.h + 20}
        ys |= {top - SEP * k for k in range(6)} | {bot + SEP * k for k in range(6)}
        xs = sorted(round(x, 1) for x in xs); ys = sorted(round(y, 1) for y in ys)
        HS, VS = [], []                                  # placed connectors, split by direction (fast checks)
        for o in self._placed:
            for a_, b_ in seg_list(o.pts):
                if a_[1] == b_[1]:
                    HS.append((a_[1], min(a_[0], b_[0]), max(a_[0], b_[0])))
                else:
                    VS.append((a_[0], min(a_[1], b_[1]), max(a_[1], b_[1])))
        rects = [r for _, r in self.obstacles(e)] + [s.rect(-1), t.rect(-1)] + list(self._titles) + list(self.reserved)
        bands = [(z.x, z.y - 8, z.x + z.w, z.y + HEAD + 8) for z in self.zones]
        zh = [(zb[0][1], min(zb[0][0], zb[1][0]), max(zb[0][0], zb[1][0])) for zb in self._borders if zb[0][1] == zb[1][1]]
        zv = [(zb[0][0], min(zb[0][1], zb[1][1]), max(zb[0][1], zb[1][1])) for zb in self._borders if zb[0][0] == zb[1][0]]

        def seg_ok(a, b):
            if a[1] == b[1]:                                 # horizontal
                y, x1, x2 = a[1], min(a[0], b[0]), max(a[0], b[0])
                for r in rects:
                    if r[1] < y < r[3] and x1 < r[2] and x2 > r[0]:
                        return False, 0
                for r in bands:
                    if r[1] < y < r[3] and x1 < r[2] and x2 > r[0]:
                        return False, 0
                for yy, u1, u2 in zh:
                    if abs(y - yy) < 10 and min(x2, u2) - max(x1, u1) > 0:
                        return False, 0
                for yy, u1, u2 in HS:
                    if abs(y - yy) < SEP and min(x2, u2) - max(x1, u1) > 0:
                        return False, 0
                cr = sum(1 for xx, v1, v2 in VS if x1 + 1 < xx < x2 - 1 and v1 + 1 < y < v2 - 1)
                return True, cr
            x, y1, y2 = a[0], min(a[1], b[1]), max(a[1], b[1])
            for r in rects:
                if r[0] < x < r[2] and y1 < r[3] and y2 > r[1]:
                    return False, 0
            for xx, u1, u2 in zv:
                if abs(x - xx) < 10 and min(y2, u2) - max(y1, u1) > 0:
                    return False, 0
            for xx, u1, u2 in VS:
                if abs(x - xx) < SEP and min(y2, u2) - max(y1, u1) > 0:
                    return False, 0
            cr = sum(1 for yy, h1, h2 in HS if y1 + 1 < yy < y2 - 1 and h1 + 1 < x < h2 - 1)
            return True, cr

        if not seg_ok(P, P1)[0] or not seg_ok(Q1, Q)[0]:
            return []
        xi = {x: i for i, x in enumerate(xs)}; yi = {y: j for j, y in enumerate(ys)}
        start, goal = (xi[P1[0]], yi[P1[1]]), (xi[Q1[0]], yi[Q1[1]])
        dist = {(start, es): 0}
        prev = {}
        pq = [(0, start, es)]
        cache = {}
        best = None
        while pq:
            c, node, d = heapq.heappop(pq)
            if c > dist.get((node, d), 1e18):
                continue
            if node == goal:
                if D[d] == (-D[en][0], -D[en][1]) or (node == goal and (xs[node[0]], ys[node[1]]) == Q1 and d == {"L": "R", "R": "L", "T": "B", "B": "T"}[en]):
                    best = (node, d); break
                # arriving the wrong way: allow one more bend into the entry stub
                need = {"L": "R", "R": "L", "T": "B", "B": "T"}[en]
                k = ((node, need))
                if dist.get(k, 1e18) > c + 30:
                    dist[k] = c + 30; prev[k] = (node, d); heapq.heappush(pq, (c + 30, node, need))
                continue
            i, j = node
            for nd, (dx, dy) in D.items():
                if (dx, dy) == (-D[d][0], -D[d][1]):
                    continue
                ni, nj = i + dx, j + dy
                if not (0 <= ni < len(xs) and 0 <= nj < len(ys)):
                    continue
                a, b = (xs[i], ys[j]), (xs[ni], ys[nj])
                key = (a, b)
                if key not in cache:
                    cache[key] = seg_ok(a, b)
                ok, cr = cache[key]
                if not ok:
                    continue
                nc = c + abs(a[0] - b[0]) + abs(a[1] - b[1]) + (40 if nd != d else 0) + cr * 900
                k = ((ni, nj), nd)
                if nc < dist.get(k, 1e18):
                    dist[k] = nc; prev[k] = (node, d); heapq.heappush(pq, (nc, (ni, nj), nd))
        if not best:
            return []
        path, k = [], best
        while k in prev:
            path.append((xs[k[0][0]], ys[k[0][1]]))
            k = prev[k]
        path.append(P1)
        path = [P] + path[::-1] + [Q]
        return [path]

    def anchors(self):
        """Port stagger (Rule 3): N edges on one face get (i+1)/(N+1); the order follows the far end (Rule 4)."""
        face = {}
        for e in self.edges:
            es, en = self.sides_of(e.plan)
            face.setdefault((e.src, es), []).append((e, "s"))
            face.setdefault((e.tgt, en), []).append((e, "t"))
        need = {}
        self.anchor = {}
        self.face_n = {k: len(v) for k, v in face.items()}
        for (nid, side), lst in face.items():
            n = self.nmap[nid]
            other = lambda it: self.nmap[it[0].tgt if it[1] == "s" else it[0].src]
            if side in "LR":
                lst.sort(key=lambda it: (other(it).cy, other(it).cx if side == "R" else -other(it).cx))
            else:                                             # Rule 4 nesting for a fan leaving a top/bottom face:
                def tb_key(it):                               # the deepest turn takes the inside anchor
                    o = other(it)
                    right = o.cx > n.cx
                    depth = o.cy if side == "B" else -o.cy
                    return (round(o.cx / 40), -depth if right else depth)
                lst.sort(key=tb_key)
            N = len(lst)
            flen = n.h if side in "LR" else n.w
            if n.shape == "diamond" and N > 1:
                flen = flen / 2                                       # only the middle half of a diamond face is outline
            if flen / (N + 1) < SEP:
                need[nid] = need.get(nid, (0, 0))
                req = SEP * (N + 1) * (2 if n.shape == "diamond" else 1)
                need[nid] = (max(need[nid][0], req), need[nid][1]) if side in "TB" else (need[nid][0], max(need[nid][1], req))
            fr = []
            for i, (e, end) in enumerate(lst):
                f = (i + 1) / (N + 1)
                if n.shape == "diamond" and N > 1:
                    f = 0.25 + f / 2
                fr.append(f)
            if n.shape != "diamond" and N >= 1:              # line anchors up with the far system where spacing allows,
                wants = []                                    # so connectors run straight; the rest share the gaps
                for it in lst:
                    o = other(it)
                    w = ((o.cy - n.y) if side in "LR" else (o.cx - n.x))
                    wants.append(w if 10 <= w <= flen - 10 else None)
                fr = face_layout(wants, flen, fr)
            for (e, end), f in zip(lst, fr):
                self.anchor[(e.i, end)] = (side, f)
        return need

    def port(self, n, side, f):
        if side == "L": p = (n.x, n.y + n.h * f)
        elif side == "R": p = (n.x + n.w, n.y + n.h * f)
        elif side == "T": p = (n.x + n.w * f, n.y)
        else: p = (n.x + n.w * f, n.y + n.h)
        if n.shape == "diamond":                                  # slide the anchor onto the diamond's outline
            if side in "LR":
                k = 1 - abs(p[1] - n.cy) / (n.h / 2)
                p = (n.cx + (n.w / 2) * k * (1 if side == "R" else -1), p[1])
            else:
                k = 1 - abs(p[0] - n.cx) / (n.w / 2)
                p = (p[0], n.cy + (n.h / 2) * k * (1 if side == "B" else -1))
        return (round(p[0], 1), round(p[1], 1))

    def free_frac(self, n, side):
        """A provisional anchor on a face this edge was not planned for: the middle, or beside the anchors there."""
        used = sorted(f for (i, end), (sd, f) in self.anchor.items()
                      if sd == side and (self.edges[i].src if end == "s" else self.edges[i].tgt) == n.id)
        flen0 = n.h if side in "LR" else n.w
        for o in getattr(self, "_placed", []) or []:       # where placed connectors actually meet this face
            for p_, nid in ((o.pts[0], o.src), (o.pts[-1], o.tgt)):
                if nid == n.id and self.face_of(n, p_) == side:
                    used.append(((p_[1] - n.y) if side in "LR" else (p_[0] - n.x)) / flen0)
        flen = n.h if side in "LR" else n.w
        for f in (0.5, 0.25, 0.75, 0.15, 0.85):
            if all(abs(f - u) * flen >= SEP for u in used):
                return f
        return 0.5

    @staticmethod
    def face_of(n, p):
        if abs(p[0] - n.x) < 0.6: return "L"
        if abs(p[0] - (n.x + n.w)) < 0.6: return "R"
        if abs(p[1] - n.y) < 0.6: return "T"
        if abs(p[1] - (n.y + n.h)) < 0.6: return "B"
        return "?"

    def obstacles(self, e):
        k = (e.src, e.tgt)
        if k not in self._obst:
            self._obst[k] = [(m, m.rect(CLR)) for m in self.nodes if m.id not in k]
        return self._obst[k]

    def zone_borders(self):
        out = []
        for z in self.zones:
            x1, y1, x2, y2 = z.rect()
            out += [((x1, y1), (x1, y2)), ((x2, y1), (x2, y2)), ((x1, y1), (x2, y1)), ((x1, y2), (x2, y2))]
        return out

    def ok_path(self, e, pts, placed):
        """Hard rules for one candidate path; returns (ok, crossings)."""
        segs = seg_list(pts)
        if any(a[0] != b[0] and a[1] != b[1] for a, b in segs):
            return False, 0
        s, t = self.nmap[e.src], self.nmap[e.tgt]
        for k, (a, b) in enumerate(segs):
            key = (e.i, a, b, k == 0, k == len(segs) - 1, k == 1, k == len(segs) - 2)
            hit = self._segok.get(key)
            if hit is None:
                hit = self._static_ok(e, s, t, segs, k, a, b)
                self._segok[key] = hit
            if not hit:
                return False, 0
        return self._dynamic_ok(e, pts, segs, placed)

    def _static_ok(self, e, s, t, segs, k, a, b):
        if True:
            for m, r in self.obstacles(e):
                if seg_hits_rect(a, b, r):
                    return False
            for own, ends in ((s, k == 0), (t, k == len(segs) - 1)):
                if not ends and seg_hits_rect(a, b, own.rect(-1)):
                    return False
                if not ends and seg_hits_rect(a, b, own.rect(CLR)) and len(segs) > 1:
                    # middle legs keep the clearance from their own shapes too
                    if not (k == 1 and own is s) and not (k == len(segs) - 2 and own is t):
                        return False
            if ends_wrong(k, segs, s, t, a, b):
                return False
            for r in self.reserved:
                if seg_hits_rect(a, b, r):
                    return False
            for r in self._titles:                             # never through a zone title
                if seg_hits_rect(a, b, r):
                    return False
            if horiz((a, b)) and any(seg_hits_rect(a, b, (z.x, z.y - 8, z.x + z.w, z.y + HEAD + 8)) for z in self.zones):
                return False                                # never along a zone header band
            for zb in self._borders:                           # a lane may not ride along a zone border
                if horiz((a, b)) != horiz(zb):
                    continue
                fixed = abs(a[1] - zb[0][1]) if horiz((a, b)) else abs(a[0] - zb[0][0])
                span = overlap(a[0], b[0], zb[0][0], zb[1][0]) if horiz((a, b)) else overlap(a[1], b[1], zb[0][1], zb[1][1])
                if fixed < 10 and span > 0:
                    return False
        return True

    def _index(self, placed):
        """Placed connectors split into horizontal / vertical runs plus their end points (rebuilt when they change)."""
        key = tuple((o.i, id(o.pts)) for o in placed)
        if getattr(self, "_idx_key", None) != key:
            HS, VS, ends = [], [], []
            for o in placed:
                for a_, b_ in seg_list(o.pts):
                    if a_[1] == b_[1]:
                        HS.append((o.i, a_[1], min(a_[0], b_[0]), max(a_[0], b_[0])))
                    else:
                        VS.append((o.i, a_[0], min(a_[1], b_[1]), max(a_[1], b_[1])))
                ends += [(o.i, o.pts[0], o.src), (o.i, o.pts[-1], o.tgt)]
            self._idx_key, self._idx = key, (HS, VS, ends)
        return self._idx

    def _dynamic_ok(self, e, pts, segs, placed):
        HS, VS, ends = self._index(placed)
        mine = ((pts[0], e.src), (pts[-1], e.tgt))
        for oi, p_, nid in ends:
            if oi == e.i:
                continue
            for q, mid in mine:
                if p_ == q:
                    return False, 0                            # A7 shared anchor point
                if nid == mid and (abs(p_[0] - q[0]) < 0.5 or abs(p_[1] - q[1]) < 0.5) and \
                        0 < abs(p_[0] - q[0]) + abs(p_[1] - q[1]) < SEP:
                    return False, 0                            # Rule 3: anchors on one face >= 20 px apart
        cross = 0
        for a, b in segs:
            if a[1] == b[1]:
                y, x1, x2 = a[1], min(a[0], b[0]), max(a[0], b[0])
                for oi, yy, u1, u2 in HS:
                    if oi != e.i:
                        span = min(x2, u2) - max(x1, u1)
                        fx = abs(y - yy)
                        if (span > 0 and fx < SEP) or (fx < 1 and span > -40):
                            return False, 0                    # A2/A4, Rule 6
                for oi, xx, v1, v2 in VS:
                    if oi != e.i and x1 + 1 < xx < x2 - 1 and v1 + 1 < y < v2 - 1:
                        cross += 1
            else:
                x, y1, y2 = a[0], min(a[1], b[1]), max(a[1], b[1])
                for oi, xx, u1, u2 in VS:
                    if oi != e.i:
                        span = min(y2, u2) - max(y1, u1)
                        fx = abs(x - xx)
                        if (span > 0 and fx < SEP) or (fx < 1 and span > -40):
                            return False, 0                    # A3/A4, Rule 6
                for oi, yy, h1, h2 in HS:
                    if oi != e.i and y1 + 1 < yy < y2 - 1 and h1 + 1 < x < h2 - 1:
                        cross += 1
        return True, cross

    def candidates(self, e, plan, alt=False):
        s, t = self.nmap[e.src], self.nmap[e.tgt]
        es, en = self.sides_of(plan)
        a_s, a_t = self.anchor.get((e.i, "s")), self.anchor.get((e.i, "t"))
        P = self.port(s, *a_s) if a_s and a_s[0] == es else self.port(s, es, self.free_frac(s, es))
        Q = self.port(t, *a_t) if a_t and a_t[0] == en else self.port(t, en, self.free_frac(t, en))
        if not alt:
            yield from self._cands(e, plan, s, t, P, Q)
            return
        for P2, Q2 in list(self.port_options(e, s, t, es, en, P, Q))[1:]:
            yield from self._cands(e, plan, s, t, P2, Q2)

    def port_options(self, e, s, t, es, en, P, Q):
        """The planned anchors first; a face this edge has to itself may slide its anchor (around a zone title)."""
        yield P, Q
        alt = lambda n, side, cur: [self.port(n, side, f) for f in (0.65, 0.35, 0.75, 0.25, 0.8, 0.2)
                                    if self.face_n.get((n.id, side), 0) <= 1 and n.shape != "diamond"] if True else []
        for P2 in alt(s, es, P):                             # both ends slid together keep a straight line
            if es in "TB" and en in "TB" and t.x + 10 <= P2[0] <= t.x + t.w - 10 and self.face_n.get((t.id, en), 0) <= 1:
                yield P2, self.port(t, en, (P2[0] - t.x) / t.w)
            if es in "LR" and en in "LR" and t.y + 10 <= P2[1] <= t.y + t.h - 10 and self.face_n.get((t.id, en), 0) <= 1:
                yield P2, self.port(t, en, (P2[1] - t.y) / t.h)
        for P2 in alt(s, es, P):
            yield P2, Q
        for Q2 in alt(t, en, Q):
            yield P, Q2

    def _cands(self, e, plan, s, t, P, Q):
        st = 16                                                  # minimum lead-out / lead-in stub
        out = []
        if plan.startswith("M:"):
            return self.maze(e, s, t, P, Q, plan[2], plan[3])
        if plan == "H":
            if Q[0] - P[0] < 2 * st:
                return []
            if P[1] == Q[1]:
                return [[P, Q]]
            xs = frange(Q[0] - st, P[0] + st, -5)                   # outermost lane (nearest the target) first
            return [[P, (x, P[1]), (x, Q[1]), Q] for x in xs]
        if plan in ("VD", "VU"):
            if (plan == "VD" and Q[1] - P[1] < 2 * st) or (plan == "VU" and P[1] - Q[1] < 2 * st):
                return []
            if P[0] == Q[0]:
                return [[P, Q]]
            ys = frange(Q[1] - st, P[1] + st, -5) if plan == "VD" else frange(Q[1] + st, P[1] - st, 5)
            if self.zmap[s.zone] is not self.zmap[t.zone]:   # between two zones: jog in the gap, not inside a zone
                inside = lambda y: any(z.y - 10 <= y <= z.y + z.h + 10 for z in (self.zmap[s.zone], self.zmap[t.zone]))
                ys = sorted(ys, key=lambda y: (inside(y), abs(y - (P[1] + Q[1]) / 2)))
            return [[P, (P[0], y), (Q[0], y), Q] for y in ys]
        if plan in ("RT", "RB"):
            if Q[0] - P[0] < st or (plan == "RT" and Q[1] - P[1] < st) or (plan == "RB" and P[1] - Q[1] < st):
                return []
            return [[P, (Q[0], P[1]), Q]]
        if plan in ("BL", "TL"):
            if Q[0] - P[0] < st or (plan == "BL" and Q[1] - P[1] < st) or (plan == "TL" and P[1] - Q[1] < st):
                return []
            return [[P, (P[0], Q[1]), Q]]
        if plan in ("TR", "BR"):
            if P[0] - Q[0] < st or (plan == "TR" and P[1] - Q[1] < st) or (plan == "BR" and Q[1] - P[1] < st):
                return []
            return [[P, (P[0], Q[1]), Q]]
        if plan in ("LB", "LT"):
            if P[0] - Q[0] < st or (plan == "LB" and P[1] - Q[1] < st) or (plan == "LT" and Q[1] - P[1] < st):
                return []
            return [[P, (Q[0], P[1]), Q]]
        top = min(z.y for z in self.zones) - G["ring_gap"]
        bot = max(z.y + z.h for z in self.zones) + G["ring_gap"]
        if plan == "TRING":
            return [[P, (P[0], top - SEP * k), (Q[0], top - SEP * k), Q] for k in range(12)]
        if plan in ("TRING2", "BRING2"):                         # step sideways under the zone header first
            sg = -1 if plan == "TRING2" else 1
            ring = (lambda k: top - SEP * k) if plan == "TRING2" else (lambda k: bot + SEP * k)
            dirx = 1 if Q[0] >= P[0] else -1
            xs = frange(P[0] + dirx * 30, P[0] + dirx * 300, dirx * 10)
            zs = self.zmap[s.zone]                               # prefer a rise in the gutter outside the zone
            xs = sorted(xs, key=lambda x: (zs.x - 20 < x < zs.x + zs.w + 20, abs(x - P[0])))
            return [[P, (P[0], P[1] + sg * 20), (x, P[1] + sg * 20), (x, ring(k)), (Q[0], ring(k)), Q]
                    for k in range(10) for x in xs]
        if plan in ("BRING", "RINGB"):
            return [[P, (P[0], bot + SEP * k), (Q[0], bot + SEP * k), Q] for k in range(12)]
        if plan.startswith("RR"):                                # leave by the right side, then down to the ring
            lead = [(P, (x, P[1])) for x in frange(P[0] + st, P[0] + 140, 10)]
        else:
            lead = [(P,)]
        if plan in ("RING", "RINGGAP", "RRING", "RRINGGAP"):
            zt = self.zmap[t.zone]
            if plan.endswith("GAP"):                             # up the gap left of the target
                xs = frange(Q[0] - st, zt.x + 10, -10)
            else:                                                # left margin riser inside the target zone
                xs = frange(zt.x + 10, t.x - CLR, 10)
            return [[*ld, (ld[-1][0], bot + SEP * k), (x, bot + SEP * k), (x, Q[1]), Q]
                    for k in range(12) for ld in lead for x in xs]
        if plan == "RRINGB":
            return [[*ld, (ld[-1][0], bot + SEP * k), (Q[0], bot + SEP * k), Q] for k in range(12) for ld in lead]
        return out

    def route(self):
        PRI = {"sync": 0, "async": 2, "optional": 3, "rejection": 4}
        # Rule 8 priority; inside a class the shortest travel goes first and so takes the inner lane (Rule 4 nesting)
        travel = lambda e: abs(self.nmap[e.tgt].cx - self.nmap[e.src].cx) if (e.reverse or "RING" in (e.plan or "")) \
            else abs(self.nmap[e.tgt].cy - self.nmap[e.src].cy)
        order = sorted(self.edges, key=lambda e: (4 if e.reverse else PRI.get(e.kind, 1) if e.kind != "sync" else 0,
                                                  travel(e), e.i))
        placed, failed = [], []
        self._titles = [(x1 - 4, y1 - 2, x2 + 4, y2 + 2) for x1, y1, x2, y2 in self.zone_titles()]
        self._borders = self.zone_borders()
        self._obst = {}
        self._segok = {}
        self._placed = placed
        import time
        for e in order:
            if time.time() > getattr(self, "deadline", 1e18):
                self.timed_out = True
                failed.append(e)
                continue
            best = None
            std = [p for p in e.plans if not p.startswith("M:")]
            mz = [p for p in e.plans if p.startswith("M:")]
            for alt, plans in ((False, std), (True, std), (False, mz)):   # the standard's routes first; maze last
                clean_rank = None
                for rank, plan in enumerate(plans):
                    if clean_rank is not None and rank > clean_rank + 1:
                        break
                    for pts in self.candidates(e, plan, alt):
                        pts = simplify(pts)
                        ok, cross = self.ok_path(e, pts, placed)
                        if not ok:
                            continue
                        cost = len(pts) * 40 + length(pts) * 0.2 + cross * 900 + rank * 60
                        if best is None or cost < best[0]:
                            best = (cost, plan, pts)
                        if cross == 0:
                            clean_rank = rank if clean_rank is None else clean_rank
                            break                                # first clean lane of a plan is its nested lane
                if best and (alt or len(best[2]) == 2 or plans is mz):
                    break                                        # a bent route still lets slid anchors try a straight one
            if best:
                e.plan, e.pts = best[1], best[2]
                placed.append(e)
            else:
                failed.append(e)
        if not failed:
            self.repair(placed)
        return failed

    def n_cross(self, e, others):
        return sum(1 for o in others if o is not e for a in seg_list(e.pts) for b in seg_list(o.pts) if crosses(a, b))

    def repair(self, placed):
        """Rip-up and re-route: every connector that crosses another is routed again with all others fixed (any plan,
        any anchor the face allows); the new path is kept only when it crosses less (Rule 10)."""
        import time
        for _ in range(2):
            if time.time() > getattr(self, "deadline", 1e18):
                return
            improved = False
            for e in sorted(placed, key=lambda e: -self.n_cross(e, placed)):
                now = self.n_cross(e, placed)
                if not now:
                    continue
                others = [o for o in placed if o is not e]
                best = None
                for alt in (False, True):
                    for rank, plan in enumerate([p for p in e.plans if not p.startswith("M:")]):
                        if e.reverse and "RING" not in plan and plan not in ("VD", "VU"):
                            continue
                        for pts in self.candidates(e, plan, alt):
                            pts = simplify(pts)
                            ok, cross = self.ok_path(e, pts, others)
                            if ok and cross < now and (best is None or (cross, len(pts)) < best[:2]):
                                best = (cross, len(pts), plan, pts)
                if best:
                    e.plan, e.pts = best[2], best[3]
                    improved = True
            if not improved:
                break

    def solve(self):
        self.grid()
        self.fan, self.vfan = {}, {}
        for e in self.edges:
            e.plans = None
        best = None
        widen = 0
        seen_sigs = set()
        import time
        self.deadline = time.time() + float(os.environ.get("ULTA_DIAGRAM_BUDGET", "75"))
        self.timed_out = False
        for attempt in range(30):
            if time.time() > self.deadline:
                self.timed_out = True
                break
            self.layout()
            self.reserved = []
            for e in self.edges:
                if e.plans is None:
                    e.plans = self.classify(e)
                    e.plans += [m for m in self.maze_plans(e) if m not in e.plans]
                    e.plan = e.plans[0]
                    e.pref = list(e.plans)
            need = self.anchors()
            if need and any(self.grow.get(k, (0, 0)) != v for k, v in need.items()):
                for k, v in need.items():
                    g = self.grow.get(k, (0, 0))
                    self.grow[k] = (max(g[0], v[0]), max(g[1], v[1]))
                continue
            failed = self.route()
            changed = False
            for e in self.edges:                                 # sides follow the plan the router took
                if e.pts and e.plan != e.plans[0]:
                    cls = [p for p in e.plans if not p.startswith("M:")]
                    mz = [p for p in e.plans if p.startswith("M:")]
                    if e.plan.startswith("M:"):                  # a maze route never outranks the standard's own routes
                        mz = [e.plan] + [p for p in mz if p != e.plan]
                    else:
                        cls = [e.plan] + [p for p in cls if p != e.plan]
                    e.plans = cls + mz
                    changed = True
            if best is None or len(failed) < best[0]:
                best = (len(failed), dict(self.extra), dict(self.grow), {e.i: list(e.plans) for e in self.edges})
            sig = tuple(e.plan for e in self.edges)
            if not failed and (not changed or sig in seen_sigs):
                break                                            # settled, or cycling between equal-quality routes
            seen_sigs.add(sig)
            if failed:
                for e in failed:                                 # rotate its plans; widen the layout (at most 3 times)
                    pl = [p for p in e.plans if not p.startswith("M:")]
                    e.plans = pl[1:] + pl[:1] + [p for p in e.plans if p.startswith("M:")]
                if attempt % 3 == 2 and widen < 3:
                    widen += 1
                    for k in ("col", "gutter", "row", "inset", "vgap"):
                        self.extra[k] += 20
        if not self.timed_out and any(not e.pts for e in self.edges) and best and best[0] < sum(1 for e in self.edges if not e.pts):
            self.extra, self.grow = best[1], best[2]             # fall back to the best attempt seen
            for e in self.edges:
                e.plans = best[3][e.i]; e.plan = e.plans[0]; e.pts = []
            self.layout(); self.anchors(); self.route()
        self.failed = [e for e in self.edges if not e.pts]

    # ---- badges (Rule 9) ---------------------------------------------------
    def badges(self):
        """Rule 9 candidate scan, plus: a badge sits on a straight run of its own line (never on a corner or the
        arrowhead), and clear of zone borders, zone titles, shapes, other lines and other badges."""
        placed = []
        bw, bh = G["badge_w"], G["badge_h"]
        titles = self.zone_titles()
        borders = self.zone_borders()
        for e in sorted(self.edges, key=lambda e: e.i):
            e.badge = None
            if not e.pts:
                continue
            bw_e = max(bw, tw(e.step, 9, True) + 10)
            fine = [round(x / 100, 2) for x in range(8, 93, 2)]
            for f in list(G["badge_fractions"]) + fine:
                cx, cy = point_at(e.pts, f)
                if not self.on_run(e.pts, (cx, cy), bw_e, bh):
                    continue
                r = (cx - bw_e / 2, cy - bh / 2, cx + bw_e / 2, cy + bh / 2)
                if any(rects_touch(r, m.rect(), 2) for m in self.nodes):
                    continue
                if any(rects_touch(r, q, 2) for q in self.reserved):
                    continue
                if any(seg_hits_rect(a, b, (r[0] - 1, r[1] - 1, r[2] + 1, r[3] + 1)) for o in self.edges if o is not e and o.pts
                       for a, b in seg_list(o.pts)):
                    continue
                if any(rects_touch(r, p, 6) for p in placed):
                    continue
                if any(rects_touch(r, z, 2) for z in titles):
                    continue
                if any(seg_hits_rect(a, b, (r[0] - 3, r[1] - 3, r[2] + 3, r[3] + 3)) for a, b in borders):
                    continue
                e.badge, e.badge_f = r, f
                placed.append(r)
                break

    @staticmethod
    def on_run(pts, p, bw, bh):
        """p lies on one straight segment with room for the badge before the corner and before the arrowhead."""
        segs = seg_list(pts)
        for k, (a, b) in enumerate(segs):
            if horiz((a, b)) and abs(p[1] - a[1]) < 0.5 and min(a[0], b[0]) - 0.5 <= p[0] <= max(a[0], b[0]) + 0.5:
                d1, d2, need = abs(p[0] - a[0]), abs(p[0] - b[0]), bw / 2 + 4
            elif not horiz((a, b)) and abs(p[0] - a[0]) < 0.5 and min(a[1], b[1]) - 0.5 <= p[1] <= max(a[1], b[1]) + 0.5:
                d1, d2, need = abs(p[1] - a[1]), abs(p[1] - b[1]), bh / 2 + 4
            else:
                continue
            end = need + (10 if k == len(segs) - 1 else 0)     # keep the arrowhead visible
            if d1 >= need and d2 >= end:
                return True
        return False

    def zone_titles(self):
        out = []
        for z in self.zones:
            w = tw(z.name, 12, True)
            cx = z.x + z.w / 2
            out.append((cx - w / 2 - 4, z.y, cx + w / 2 + 4, z.y + HEAD))
        return out

    # ---- audit (Step 8b) ---------------------------------------------------
    def audit(self):
        v = []
        es = [e for e in self.edges if e.pts]
        for e in self.edges:
            if not e.pts:
                v.append(("A1", f"{e.step}: no compliant route found"))
        for e in es:
            if any(a[0] != b[0] and a[1] != b[1] for a, b in seg_list(e.pts)):
                v.append(("A1", f"{e.step}: non-orthogonal hop"))
            for a, b in seg_list(e.pts):
                for m in self.nodes:
                    if m.id in (e.src, e.tgt):
                        continue
                    if seg_hits_rect(a, b, m.rect(CLR)):
                        v.append(("A5", f"{e.step}: passes within {CLR}px of {m.name}"))
                for r in self.reserved:
                    if seg_hits_rect(a, b, r):
                        v.append(("A6", f"{e.step}: enters a reserved block"))
        cross = 0
        for i, e in enumerate(es):
            for o in es[i + 1:]:
                if {e.pts[0], e.pts[-1]} & {o.pts[0], o.pts[-1]}:
                    v.append(("A7", f"{e.step} and {o.step} share an anchor point"))
                for p1, n1 in ((e.pts[0], e.src), (e.pts[-1], e.tgt)):
                    for p2, n2 in ((o.pts[0], o.src), (o.pts[-1], o.tgt)):
                        nd = self.nmap[n1]
                        if n1 == n2 and self.face_of(nd, p1) == self.face_of(nd, p2) != "?" and \
                                0 < abs(p1[0] - p2[0]) + abs(p1[1] - p2[1]) < SEP:
                            v.append(("A7", f"{e.step} and {o.step} meet {nd.name} less than {SEP}px apart"))
                for a in seg_list(e.pts):
                    for b in seg_list(o.pts):
                        if horiz(a) == horiz(b):
                            fixed = abs(a[0][1] - b[0][1]) if horiz(a) else abs(a[0][0] - b[0][0])
                            span = overlap(a[0][0], a[1][0], b[0][0], b[1][0]) if horiz(a) else overlap(a[0][1], a[1][1], b[0][1], b[1][1])
                            if span > 0 and fixed == 0:
                                v.append(("A2" if horiz(a) else "A3", f"{e.step} and {o.step} share a segment"))
                            elif span > 0 and fixed < SEP:
                                v.append(("A4", f"{e.step} and {o.step} run {fixed:.0f}px apart (min {SEP})"))
                        elif crosses(a, b):
                            cross += 1
        steps = [e.step for e in self.edges]
        for s in sorted({s for s in steps if steps.count(s) > 1}):
            v.append(("A8", f"badge {s} is used twice"))
        for e in es:
            if not e.badge:
                v.append(("A9", f"{e.step}: no collision-free badge position"))
        v += self.legibility()
        self.crossings = cross
        return v

    def legibility(self):
        """A11: every piece of text stays readable - no line through a zone title, no text past its box, no badge
        on another badge, a shape or a zone border."""
        v = []
        titles = self.zone_titles()
        for z, r in zip(self.zones, titles):
            if r[2] - r[0] > z.w:
                v.append(("A11", f"zone title '{z.name[:30]}' is wider than its zone"))
            for e in self.edges:
                if e.pts and any(seg_hits_rect(a, b, r) for a, b in seg_list(e.pts)):
                    v.append(("A11", f"{e.step} runs through the zone title '{z.name[:30]}'"))
        for n in self.nodes:
            name, sub, note = n.lines()
            inner = n.w * 0.62 if n.shape == "diamond" else n.w - 8
            for ln, size, bold in [(x, 10, True) for x in name] + [(x, 9, False) for x in sub] + [(x, 8, False) for x in note]:
                if tw(ln, size, bold) > inner + 0.5:
                    v.append(("A11", f"text '{ln[:24]}' runs past the box of {n.name[:30]}"))
            if n.text_h() > n.h + 0.5 and n.shape != "diamond":
                v.append(("A11", f"text of {n.name[:30]} is taller than its box"))
        bs = [e.badge for e in self.edges if e.badge]
        for i, a in enumerate(bs):
            for b in bs[i + 1:]:
                if rects_touch(a, b, 2):
                    v.append(("A11", "two badges overlap"))
            if any(rects_touch(a, m.rect(), 0) for m in self.nodes):
                v.append(("A11", "a badge covers a shape"))
        return v


def face_layout(wants, flen, default):
    """Anchor fractions for one face: items with a wanted position (in line with the far system) keep it; the others
    are spread evenly between them, in order; every gap stays >= SEP. Snaps that cannot fit are dropped one by one."""
    snap = [w for w in wants]
    for _ in range(len(wants) + 1):
        pos = [None] * len(wants)
        fixed = [(i, w) for i, w in enumerate(snap) if w is not None]
        bounds = [(-1, 0.0)] + fixed + [(len(wants), float(flen))]
        for (i0, p0), (i1, p1) in zip(bounds, bounds[1:]):
            if i0 >= 0:
                pos[i0] = p0
            m = i1 - i0 - 1
            for k in range(m):
                pos[i0 + 1 + k] = p0 + (p1 - p0) * (k + 1) / (m + 1)
        gaps = [pos[0]] + [b - a for a, b in zip(pos, pos[1:])] + [flen - pos[-1]]
        inner = [b - a for a, b in zip(pos, pos[1:])]
        if all(g >= SEP for g in inner) and all(p >= 10 and p <= flen - 10 for p in pos):
            return [p / flen for p in pos]
        cand = [i for i, w in enumerate(snap) if w is not None]
        if not cand:
            break
        bad = min(cand, key=lambda i: min([abs(pos[i] - pos[j]) for j in range(len(pos)) if j != i] or [flen]))
        snap[bad] = None
    return default


def frange(a, b, step):
    out, x = [], a
    if step > 0:
        while x <= b + 1e-6:
            out.append(round(x, 1)); x += step
    else:
        while x >= b - 1e-6:
            out.append(round(x, 1)); x += step
    return out


def ends_wrong(k, segs, s, t, a, b):
    """The first leg must leave its shape outward and the last must arrive from outside."""
    if (k == 0 and s.shape == "diamond") or (k == len(segs) - 1 and t.shape == "diamond"):
        return False
    if k == 0 and seg_hits_rect(a, b, s.rect(-1)):
        return True
    if k == len(segs) - 1 and seg_hits_rect(a, b, t.rect(-1)):
        return True
    return False


# ---------------------------------------------------------------- page furniture (title, legends)
def kdd_lines(d, width):
    """[(bold lead, text lines)] for the Key Design Decisions & Review Evidence panel, two columns."""
    left = [(f"{k.get('id', '')} {k.get('title', '')}".strip() + ":", str(k.get("text") or "")) for k in d.get("kdd") or []]
    right = [(str(k.get("title") or "") + ":", str(k.get("text") or "")) for k in d.get("evidence") or []]
    return left, right


class Page:
    """Positions of the furniture around the routed diagram (all reserved no-go blocks)."""

    def __init__(self, dg, d):
        self.dg, self.d = dg, d
        bx = [n.rect() for n in dg.nodes] + [z.rect() for z in dg.zones]
        bx += [(min(q[0] for q in e.pts), min(q[1] for q in e.pts), max(q[0] for q in e.pts), max(q[1] for q in e.pts))
               for e in dg.edges if e.pts]
        self.cx1 = min(b[0] for b in bx); self.cy1 = min(b[1] for b in bx)
        self.cx2 = max(b[2] for b in bx); self.cy2 = max(b[3] for b in bx)


def shift(dg, dx, dy):
    for n in dg.nodes:
        n.x += dx; n.y += dy
    for z in dg.zones:
        z.x += dx; z.y += dy
        if hasattr(z, "colx"):
            z.colx = [c + dx for c in z.colx]
    for e in dg.edges:
        e.pts = [(round(p[0] + dx, 1), round(p[1] + dy, 1)) for p in e.pts]
        if e.badge:
            e.badge = (e.badge[0] + dx, e.badge[1] + dy, e.badge[2] + dx, e.badge[3] + dy)


def furniture(dg, d):
    """Move the routed diagram under the title block, then place the State legend, KDD panel and Flow Legend."""
    pg = Page(dg, d)
    dx = 50 - min(pg.cx1, 50) if pg.cx1 < 50 else 0
    dy = 110 - pg.cy1
    shift(dg, dx, dy)
    pg = Page(dg, d)
    W = max(pg.cx2 + 50, 1400)
    F = {"W": W}
    title_w = max(tw(d["_title"], 18, True), tw(d["_subtitle"], 10), 400) + 20
    F["title_block"] = (50, 15, 50 + title_w, 84)
    ly = pg.cy2 + G["legend_gap"]
    # State & connector legend (left) and KDD panel (right), same height
    sw = max(640, 30 + sum(60 + tw(s["label"], 10) for s in STD["states"].values()),
             30 + sum(76 + tw(c["legend"], 10) for c in STD["connectors"].values()))
    left, right = kdd_lines(d, 0)
    kx = 50 + sw + 30
    kw = W - 50 - kx
    colw = (kw - 40) / 2 if right else kw - 24
    L = [(lead, wrap(lead + " " + txt, 10, colw)) for lead, txt in left]
    R = [(lead, wrap(lead + " " + txt, 10, colw)) for lead, txt in right]
    kh = HEAD + 14 + max(sum(len(x[1]) for x in L), sum(len(x[1]) for x in R), 1) * 13 + 16
    sh = max(150, kh)
    F["state"] = (50, ly, sw, sh)
    F["kdd"] = (kx, ly, kw, sh, L, R, colw) if (L or R) else None
    if not F["kdd"]:
        F["state"] = (50, ly, sw, sh)
    fy = ly + sh + G["legend_gap"]
    rows = sorted(dg.edges, key=lambda e: step_key(e.step))
    two = len(rows) > 12
    cols = [rows[:math.ceil(len(rows) / 2)], rows[math.ceil(len(rows) / 2):]] if two else [rows]
    tw_ = (W - 100 - 30 - (20 if two else 0)) / len(cols)
    widths = [45, 230, tw_ - 45 - 230 - 100, 100]
    tables = []
    for c, rs in enumerate(cols):
        rr = []
        for e in rs:
            st, tg = dg.nmap.get(e.src), dg.nmap.get(e.tgt)
            sname = f"{st.name if st else e.src} → {tg.name if tg else e.tgt}"
            a = wrap(sname, 10, widths[1] - 16)
            b = wrap(e.desc, 10, widths[2] - 16)
            rr.append((e, a, b, max(len(a), len(b)) * 13 + 10))
        tables.append(rr)
    th = max(sum(r[3] for r in t) for t in tables) + 26 + 14
    F["flow"] = (50, fy, W - 100, 28 + th, tables, widths, tw_)
    F["H"] = fy + 28 + th + 40
    dg.reserved = [F["title_block"], (50, ly, sw, ly + sh), (50, fy, W - 50, fy + 28 + th)]
    if F["kdd"]:
        dg.reserved.append((kx, ly, kx + kw, ly + sh))
    return F


def step_key(s):
    try:
        a, b = str(s).split(".")
        return (int(a), int(b))
    except Exception:
        return (999, 999)


# ---------------------------------------------------------------- SVG
def svg(dg, d, F, interactive=False):
    W, H = F["W"], F["H"]
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W:.0f}" height="{H:.0f}" viewBox="0 0 {W:.0f} {H:.0f}" '
         f'font-family="{STD["font"]}">', '<rect width="100%" height="100%" fill="#FFFFFF"/>', "<defs>"]
    for k, c in STD["connectors"].items():
        if c["end"] == "open":
            o.append(f'<marker id="m-{k}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                     f'<path d="M1,1 L9,5 L1,9" fill="none" stroke="#{c["stroke"]}" stroke-width="1.6"/></marker>')
        else:
            o.append(f'<marker id="m-{k}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">'
                     f'<path d="M0,0 L10,5 L0,10 z" fill="#{c["stroke"]}"/></marker>')
    o.append("</defs>")
    # title block
    o.append(f'<text x="54" y="36" font-size="18" font-weight="bold" fill="#E85D04">{esc(d["_title"])}</text>')
    o.append(f'<text x="54" y="61" font-size="10" fill="#737373">{esc(d["_subtitle"])}</text>')
    o.append(f'<text x="54" y="79" font-size="9" font-style="italic" fill="#999999">{esc(d["_dates"])}</text>')
    # zones
    for z in dg.zones:
        zs = STD["zones"].get(z.kind, STD["zones"]["saas"])
        o.append(f'<g class="zone"><rect x="{z.x}" y="{z.y}" width="{z.w}" height="{z.h}" fill="none" stroke="#{zs["stroke"]}" '
                 f'stroke-width="{zs["width"]}"/><line x1="{z.x}" y1="{z.y + HEAD}" x2="{z.x + z.w}" y2="{z.y + HEAD}" '
                 f'stroke="#{zs["stroke"]}" stroke-width="{zs["width"]}"/>'
                 f'<text x="{z.x + z.w / 2}" y="{z.y + 16.5}" text-anchor="middle" font-size="12" font-weight="bold" fill="#303030">'
                 f'{esc(z.name)}</text></g>')
    # edges (with line hops over earlier edges)
    drawn = []
    for e in sorted(dg.edges, key=lambda e: e.i):
        if not e.pts:
            continue
        c = STD["connectors"].get(e.kind, STD["connectors"]["sync"])
        dpath = hop_path(e.pts, drawn)
        dash = f' stroke-dasharray="{c["dash"]}"' if c["dash"] else ""
        st = dg.nmap[e.src].name; tg = dg.nmap[e.tgt].name
        o.append(f'<g class="flow" data-step="{esc(e.step)}" data-from="{esc(e.src)}" data-to="{esc(e.tgt)}">'
                 f'<title>{esc(e.step)} {esc(st)} → {esc(tg)}: {esc(e.desc)}</title>'
                 f'<path d="{dpath}" fill="none" stroke="#{c["stroke"]}" stroke-width="{c["width"]}"{dash} '
                 f'stroke-linejoin="round" marker-end="url(#m-{e.kind})"/>')
        if e.badge:
            x1, y1, x2, y2 = e.badge
            o.append(f'<rect x="{x1:.1f}" y="{y1:.1f}" width="{x2 - x1:.1f}" height="{y2 - y1:.1f}" fill="#FFFFFF" '
                     f'stroke="#{c["stroke"]}" stroke-width="1"/><text x="{(x1 + x2) / 2:.1f}" y="{(y1 + y2) / 2 + 3.2:.1f}" '
                     f'text-anchor="middle" font-size="9" font-weight="bold" fill="#303030">{esc(e.step)}</text>')
        o.append("</g>")
        drawn.append(e)
    # systems
    for n in dg.nodes:
        s = STD["states"].get(n.state, STD["states"]["existing"])
        dash = ' stroke-dasharray="6 4"' if s["dash"] else ""
        o.append(f'<g class="node" data-id="{esc(n.id)}"><title>{esc(n.name)} - {esc(s["label"])}</title>')
        if n.shape == "diamond":
            o.append(f'<polygon points="{n.cx},{n.y} {n.x + n.w},{n.cy} {n.cx},{n.y + n.h} {n.x},{n.cy}" fill="#{s["fill"]}" '
                     f'stroke="#{s["stroke"]}" stroke-width="2"{dash}/>')
        elif n.shape == "cylinder":
            e_ = 7.5
            o.append(f'<path d="M{n.x},{n.y + e_} A{n.w / 2},{e_} 0 0 1 {n.x + n.w},{n.y + e_} V{n.y + n.h - e_} '
                     f'A{n.w / 2},{e_} 0 0 1 {n.x},{n.y + n.h - e_} Z" fill="#{s["fill"]}" stroke="#{s["stroke"]}" stroke-width="2"{dash}/>'
                     f'<path d="M{n.x},{n.y + e_} A{n.w / 2},{e_} 0 0 0 {n.x + n.w},{n.y + e_}" fill="none" stroke="#{s["stroke"]}" stroke-width="2"/>')
        else:
            r = min(n.w, n.h) * 0.08
            o.append(f'<rect x="{n.x}" y="{n.y}" width="{n.w}" height="{n.h}" rx="{r:.1f}" fill="#{s["fill"]}" '
                     f'stroke="#{s["stroke"]}" stroke-width="2"{dash}/>')
        name, sub, note = n.lines()
        hh = len(name) * 12.5 + len(sub) * 11 + len(note) * 10
        y = n.cy - hh / 2 + 9.5 + (7 if n.shape == "cylinder" else 0)
        for ln in name:
            o.append(f'<text x="{n.cx}" y="{y:.1f}" text-anchor="middle" font-size="10" font-weight="bold" fill="#{s["text"]}">{esc(ln)}</text>')
            y += 12.5
        for ln in sub:
            o.append(f'<text x="{n.cx}" y="{y - 1:.1f}" text-anchor="middle" font-size="9" fill="#737373">{esc(ln)}</text>')
            y += 11
        for ln in note:
            o.append(f'<text x="{n.cx}" y="{y - 1:.1f}" text-anchor="middle" font-size="8" font-style="italic" fill="#737373">{esc(ln)}</text>')
            y += 10
        o.append("</g>")
    o += legends_svg(dg, d, F)
    o.append("</svg>")
    return "\n".join(o)


def hop_path(pts, drawn):
    """SVG path with a small arc where a horizontal leg crosses an earlier connector (jumpStyle=arc)."""
    others = [s for o in drawn for s in seg_list(o.pts) if not horiz(s)]
    hs = [s for o in drawn for s in seg_list(o.pts) if horiz(s)]
    d = f"M{pts[0][0]},{pts[0][1]}"
    for a, b in seg_list(pts):
        if horiz((a, b)):
            xs = sorted({s[0][0] for s in others if crosses((a, b), s)}, reverse=b[0] < a[0])
            sgn = 1 if b[0] > a[0] else -1
            for x in xs:
                d += f" L{x - 4 * sgn},{a[1]} A4,4 0 0 {1 if sgn > 0 else 0} {x + 4 * sgn},{a[1]}"
        else:
            ys = sorted({s[0][1] for s in hs if crosses((a, b), s)}, reverse=b[1] < a[1])
            sgn = 1 if b[1] > a[1] else -1
            for y in ys:
                d += f" L{a[0]},{y - 4 * sgn} A4,4 0 0 {0 if sgn > 0 else 1} {a[0]},{y + 4 * sgn}"
        d += f" L{b[0]},{b[1]}"
    return d


def legends_svg(dg, d, F):
    o = []
    x, y, w, h = F["state"]
    o.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="none" stroke="#737373" stroke-width="1.5"/>'
             f'<line x1="{x}" y1="{y + HEAD}" x2="{x + w}" y2="{y + HEAD}" stroke="#737373" stroke-width="1.5"/>'
             f'<text x="{x + w / 2}" y="{y + 16.5}" text-anchor="middle" font-size="12" font-weight="bold" fill="#303030">System State &amp; Connector Legend</text>')
    cx = x + 20
    for k, s in STD["states"].items():
        dash = ' stroke-dasharray="4 3"' if s["dash"] else ""
        o.append(f'<rect x="{cx}" y="{y + 46}" width="30" height="15" rx="2" fill="#{s["fill"]}" stroke="#{s["stroke"]}" stroke-width="2"{dash}/>'
                 f'<text x="{cx + 38}" y="{y + 57}" font-size="10" fill="#303030">{esc(s["label"])}</text>')
        cx += 38 + tw(s["label"], 10) + 22
    cx = x + 20
    for k, c in STD["connectors"].items():
        dash = f' stroke-dasharray="{c["dash"]}"' if c["dash"] else ""
        o.append(f'<line x1="{cx}" y1="{y + 92}" x2="{cx + 40}" y2="{y + 92}" stroke="#{c["stroke"]}" stroke-width="{c["width"]}"{dash} '
                 f'marker-end="url(#m-{k})"/><text x="{cx + 50}" y="{y + 95.5}" font-size="10" fill="#303030">{esc(c["legend"])}</text>')
        cx += 50 + tw(c["legend"], 10) + 26
    o.append(f'<text x="{x + w / 2}" y="{y + h - 12}" text-anchor="middle" font-size="8" font-style="italic" fill="#999999">'
             f'{esc(STD["name"])} v{STD["version"]} · {esc(d["_dates"])}</text>')
    if F["kdd"]:
        kx, ky, kw, kh, L, R, colw = F["kdd"]
        o.append(f'<rect x="{kx}" y="{ky}" width="{kw}" height="{kh}" fill="none" stroke="#737373" stroke-width="1.5"/>'
                 f'<line x1="{kx}" y1="{ky + HEAD}" x2="{kx + kw}" y2="{ky + HEAD}" stroke="#737373" stroke-width="1.5"/>'
                 f'<text x="{kx + kw / 2}" y="{ky + 16.5}" text-anchor="middle" font-size="12" font-weight="bold" fill="#303030">'
                 f'Key Design Decisions &amp; Review Evidence</text>')
        for c, items in enumerate((L, R)):
            yy = ky + HEAD + 20
            xx = kx + 12 + c * (colw + 16)
            for lead, lines in items:
                for j, ln in enumerate(lines):
                    if j == 0 and ln.startswith(lead):
                        o.append(f'<text x="{xx}" y="{yy}" font-size="10" fill="#303030"><tspan font-weight="bold">{esc(lead)}</tspan>'
                                 f'{esc(ln[len(lead):])}</text>')
                    else:
                        o.append(f'<text x="{xx}" y="{yy}" font-size="10" fill="#303030">{esc(ln)}</text>')
                    yy += 13
    fx, fy, fw, fh, tables, widths, tw_ = F["flow"]
    o.append(f'<rect x="{fx}" y="{fy}" width="{fw}" height="{fh}" fill="#FAFAFA" stroke="#737373" stroke-width="1.5"/>'
             f'<line x1="{fx}" y1="{fy + 28}" x2="{fx + fw}" y2="{fy + 28}" stroke="#737373" stroke-width="1.5"/>'
             f'<text x="{fx + fw / 2}" y="{fy + 19}" text-anchor="middle" font-size="13" font-weight="bold" fill="#303030">Flow Legend</text>')
    for c, rows in enumerate(tables):
        tx = fx + 15 + c * (tw_ + 20)
        ty = fy + 28 + 12
        o.append(f'<rect x="{tx}" y="{ty}" width="{tw_}" height="24" fill="#F5F5F5"/>'
                 f'<line x1="{tx}" y1="{ty + 24}" x2="{tx + tw_}" y2="{ty + 24}" stroke="#737373" stroke-width="2"/>')
        hx = tx
        for head, wd in zip(("Step", "Source → Target", "Description", "Type"), widths):
            o.append(f'<text x="{hx + 8}" y="{ty + 16}" font-size="10" font-weight="bold" fill="#303030">{esc(head)}</text>')
            hx += wd
        ry = ty + 24
        for e, a, b, rh in rows:
            c_ = STD["connectors"].get(e.kind, STD["connectors"]["sync"])
            zebra = "#FFFFFF" if rows.index((e, a, b, rh)) % 2 == 0 else "#FAFAFA"
            o.append(f'<g class="row" data-step="{esc(e.step)}"><rect x="{tx}" y="{ry}" width="{tw_}" height="{rh}" fill="{zebra}"/>')
            o.append(f'<text x="{tx + 8}" y="{ry + 15}" font-size="10" font-weight="bold" fill="#303030">{esc(e.step)}</text>')
            for j, ln in enumerate(a):
                o.append(f'<text x="{tx + widths[0] + 8}" y="{ry + 15 + 13 * j}" font-size="10" fill="#303030">{esc(ln)}</text>')
            for j, ln in enumerate(b):
                o.append(f'<text x="{tx + widths[0] + widths[1] + 8}" y="{ry + 15 + 13 * j}" font-size="10" fill="#303030">{esc(ln)}</text>')
            o.append(f'<text x="{tx + widths[0] + widths[1] + widths[2] + 8}" y="{ry + 15}" font-size="10" font-weight="bold" '
                     f'fill="#{c_["text"]}">{esc(c_["label"])}</text>')
            o.append(f'<line x1="{tx}" y1="{ry + rh}" x2="{tx + tw_}" y2="{ry + rh}" stroke="#F5F5F5" stroke-width="1"/></g>')
            ry += rh
    return o


# ---------------------------------------------------------------- draw.io
def drawio(dg, d, F):
    mx = ET.Element("mxfile", host="ULTA Presentation Central", version="0.7.0")
    dia = ET.SubElement(mx, "diagram", id="c2", name=d["_title"][:60])
    m = ET.SubElement(dia, "mxGraphModel", dx="1400", dy="900", grid="1", gridSize="10", guides="1", tooltips="1",
                      connect="1", arrows="1", fold="1", page="1", pageScale="1", pageWidth=str(int(F["W"])),
                      pageHeight=str(int(F["H"])), math="0", shadow="0")
    root = ET.SubElement(m, "root")
    ET.SubElement(root, "mxCell", id="0")
    ET.SubElement(root, "mxCell", id="1", parent="0")

    def cell(id_, value, style, x, y, w, h, parent="1", vertex=True):
        c = ET.SubElement(root, "mxCell", id=id_, value=value, style=style, parent=parent, vertex="1")
        ET.SubElement(c, "mxGeometry", x=f"{x:.1f}", y=f"{y:.1f}", width=f"{w:.1f}", height=f"{h:.1f}", **{"as": "geometry"})
        return c

    cell("title", d["_title"], STD["title"]["style"], 50, 15, F["title_block"][2] - 50, 30)
    cell("subtitle", d["_subtitle"], STD["subtitle"]["style"], 50, 48, F["title_block"][2] - 50, 18)
    cell("dates", d["_dates"], STD["dates"]["style"], 50, 66, F["title_block"][2] - 50, 18)
    for z in dg.zones:
        zs = STD["zones"].get(z.kind, STD["zones"]["saas"])
        cell("z-" + z.id, z.name, zs["style"] + "container=0;collapsible=0;", z.x, z.y, z.w, z.h)
    for n in dg.nodes:
        s = STD["states"].get(n.state, STD["states"]["existing"])
        extra = STD["shapes"].get(n.shape, STD["shapes"]["rect"])["extra"]
        sub = n.sub + ("<br><i>" + " · ".join(n.kdd + ([n.note] if n.note else [])) + "</i>" if (n.kdd or n.note) else "")
        val = f'{n.name}<br><span style="font-weight:normal;font-size:9px;color:#737373;">{sub}</span>' if sub else n.name
        cell(n.id, val, s["style"] + extra, n.x, n.y, n.w, n.h)
    for e in sorted(dg.edges, key=lambda e: e.i):
        if not e.pts:
            continue
        c = STD["connectors"][e.kind]
        s, t = dg.nmap[e.src], dg.nmap[e.tgt]
        P, Q = e.pts[0], e.pts[-1]
        anc = (f"exitX={(P[0] - s.x) / s.w:.4f};exitY={(P[1] - s.y) / s.h:.4f};exitDx=0;exitDy=0;exitPerimeter=0;"
               f"entryX={(Q[0] - t.x) / t.w:.4f};entryY={(Q[1] - t.y) / t.h:.4f};entryDx=0;entryDy=0;entryPerimeter=0;")
        ec = ET.SubElement(root, "mxCell", id=f"e{e.i + 1}", value=e.step, style=c["style"] + anc, edge="1", parent="1",
                           source=e.src, target=e.tgt)
        f = getattr(e, "badge_f", 0.5)
        g = ET.SubElement(ec, "mxGeometry", relative="1", x=f"{2 * f - 1:.2f}", y="0", **{"as": "geometry"})
        ET.SubElement(g, "mxPoint", x=f"{P[0]}", y=f"{P[1]}", **{"as": "sourcePoint"})
        ET.SubElement(g, "mxPoint", x=f"{Q[0]}", y=f"{Q[1]}", **{"as": "targetPoint"})
        arr = ET.SubElement(g, "Array", **{"as": "points"})
        for p in e.pts[1:-1]:
            ET.SubElement(arr, "mxPoint", x=f"{p[0]}", y=f"{p[1]}")
    # state & connector legend
    x, y, w, h = F["state"]
    cell("legend-state", "System State &amp; Connector Legend".replace("&amp;", "&"), STD["state_legend"]["style"], x, y, w, h)
    cx = x + 20
    for k, s in STD["states"].items():
        cell(f"sw-{k}", "", f"rounded=1;whiteSpace=wrap;html=1;fillColor=#{s['fill']};strokeColor=#{s['stroke']};strokeWidth=2;"
             + ("dashed=1;" if s["dash"] else ""), cx, y + 46, 30, 15)
        cell(f"swl-{k}", s["label"], "text;html=1;align=left;verticalAlign=middle;fontSize=10;fontColor=#303030;", cx + 34, y + 44, tw(s["label"], 10) + 12, 19)
        cx += 38 + tw(s["label"], 10) + 22
    cx = x + 20
    for k, c in STD["connectors"].items():
        st = re.sub(r"labelBorderColor=[^;]+;", "", c["style"])
        ec = ET.SubElement(root, "mxCell", id=f"cl-{k}", value="", style=st, edge="1", parent="1")
        g = ET.SubElement(ec, "mxGeometry", relative="1", **{"as": "geometry"})
        ET.SubElement(g, "mxPoint", x=f"{cx}", y=f"{y + 92}", **{"as": "sourcePoint"})
        ET.SubElement(g, "mxPoint", x=f"{cx + 40}", y=f"{y + 92}", **{"as": "targetPoint"})
        cell(f"cll-{k}", c["legend"], "text;html=1;align=left;verticalAlign=middle;fontSize=10;fontColor=#303030;", cx + 46, y + 82, tw(c["legend"], 10) + 12, 20)
        cx += 50 + tw(c["legend"], 10) + 26
    cell("std-ver", f'{STD["name"]} v{STD["version"]} · {d["_dates"]}',
         "text;html=1;align=center;verticalAlign=middle;fontSize=8;fontStyle=2;fontColor=#999999;", x, y + h - 22, w, 16)
    if F["kdd"]:
        kx, ky, kw, kh, L, R, colw = F["kdd"]
        cell("legend-kdd", "Key Design Decisions & Review Evidence", STD["state_legend"]["style"], kx, ky, kw, kh)
        for c, items in enumerate((L, R)):
            if items:
                body = "<br>".join(f"<b>{html.escape(lead)}</b>{html.escape(' '.join(lines)[len(lead):])}" for lead, lines in items)
                cell(f"kdd-{c}", body, "text;html=1;align=left;verticalAlign=top;whiteSpace=wrap;fontSize=10;fontColor=#303030;spacingLeft=4;",
                     kx + 8 + c * (colw + 16), ky + HEAD + 6, colw + 4, kh - HEAD - 10)
    fx, fy, fw, fh, tables, widths, tw_ = F["flow"]
    cell("legend-flow", "Flow Legend", STD["flow_legend"]["style"], fx, fy, fw, fh)
    for c, rows in enumerate(tables):
        t = ("<table style='border-collapse:collapse;width:100%;font-family:Arial,sans-serif;font-size:10px;'>"
             "<tr style='background:#F5F5F5;font-weight:bold;border-bottom:2px solid #737373;'>"
             f"<td style='padding:6px 12px;width:{widths[0]}px;'>Step</td><td style='padding:6px 12px;width:{widths[1]}px;'>Source → Target</td>"
             f"<td style='padding:6px 12px;'>Description</td><td style='padding:6px 12px;width:{widths[3]}px;'>Type</td></tr>")
        for e, a, b, rh in rows:
            k = STD["connectors"][e.kind]
            t += ("<tr style='border-bottom:1px solid #F5F5F5;'>"
                  f"<td style='padding:5px 12px;font-weight:bold;'>{html.escape(e.step)}</td>"
                  f"<td style='padding:5px 12px;'>{html.escape(' '.join(a))}</td>"
                  f"<td style='padding:5px 12px;'>{html.escape(' '.join(b))}</td>"
                  f"<td style='padding:5px 12px;color:#{k['text']};font-weight:bold;'>{k['label']}</td></tr>")
        t += "</table>"
        cell(f"flow-table-{c + 1}", t, STD["flow_legend"]["cell"], fx + 15 + c * (tw_ + 20), fy + 28 + 4, tw_, fh - 36)
    ET.indent(mx)
    return ET.tostring(mx, encoding="unicode")


# ---------------------------------------------------------------- HTML viewer
def page_html(svg_text, d):
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{esc(d['_title'])}</title><style>
body{{margin:0;background:#FAFAFA;font-family:Helvetica,Arial,sans-serif;color:#303030}}
.bar{{position:sticky;top:0;z-index:5;background:#fff;border-bottom:1px solid #999999;padding:8px 16px;display:flex;gap:12px;align-items:center;font-size:13px}}
.bar input{{padding:5px 8px;border:1px solid #999999;border-radius:4px;width:220px}}
.bar button{{border:1px solid #999999;background:#fff;border-radius:4px;padding:5px 10px;cursor:pointer}}
.wrap{{padding:16px;overflow:auto}} .wrap svg{{background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.15);max-width:100%;height:auto}}
.wrap.full svg{{max-width:none}}
svg .dim{{opacity:.15}} svg .hot path{{stroke-width:4}} svg .row{{cursor:pointer}} svg .node{{cursor:pointer}}
svg .row.hot rect{{fill:#FDFBF0}}
@media print{{.bar{{display:none}} .wrap{{padding:0}} .wrap svg{{box-shadow:none;max-width:100%}}}}
</style></head><body><div class="bar"><b>{esc(d['_title'])}</b><input id="q" placeholder="Find a system or step…">
<button id="fit">Actual size</button><span style="color:#737373">Hover a system or a Flow Legend row to trace it</span></div>
<div class="wrap" id="wrap">{svg_text}</div><script>
const svg=document.querySelector('#wrap svg'),flows=[...svg.querySelectorAll('.flow')],nodes=[...svg.querySelectorAll('.node')],rows=[...svg.querySelectorAll('.row')];
function show(fs,ns){{flows.forEach(f=>{{f.classList.toggle('dim',!fs.has(f));f.classList.toggle('hot',fs.has(f)&&fs.size<flows.length)}});
nodes.forEach(n=>n.classList.toggle('dim',!ns.has(n.dataset.id)));rows.forEach(r=>r.classList.toggle('hot',[...fs].some(f=>f.dataset.step===r.dataset.step)&&fs.size<flows.length))}}
function all(){{show(new Set(flows),new Set(nodes.map(n=>n.dataset.id)))}}
nodes.forEach(n=>{{n.onmouseenter=()=>{{const fs=new Set(flows.filter(f=>f.dataset.from===n.dataset.id||f.dataset.to===n.dataset.id));
const ns=new Set([n.dataset.id]);fs.forEach(f=>{{ns.add(f.dataset.from);ns.add(f.dataset.to)}});show(fs,ns)}};n.onmouseleave=all}});
rows.forEach(r=>{{r.onmouseenter=()=>{{const fs=new Set(flows.filter(f=>f.dataset.step===r.dataset.step));const ns=new Set();
fs.forEach(f=>{{ns.add(f.dataset.from);ns.add(f.dataset.to)}});show(fs,ns)}};r.onmouseleave=all}});
document.getElementById('q').oninput=e=>{{const q=e.target.value.toLowerCase().trim();if(!q)return all();
const ns=new Set(nodes.filter(n=>n.textContent.toLowerCase().includes(q)).map(n=>n.dataset.id));
const fs=new Set(flows.filter(f=>f.dataset.step===q||ns.has(f.dataset.from)||ns.has(f.dataset.to)));
fs.forEach(f=>{{ns.add(f.dataset.from);ns.add(f.dataset.to)}});show(fs,ns)}};
document.getElementById('fit').onclick=e=>{{const w=document.getElementById('wrap');w.classList.toggle('full');e.target.textContent=w.classList.contains('full')?'Fit to window':'Actual size'}};
</script></body></html>"""


# ---------------------------------------------------------------- checks (Step 13) + extras
def checks(dg, d, viol, xml_text, svg_text):
    rows = []
    add = lambda n, name, ok, why="": rows.append((n, name, ok, why))
    valid_states = set(STD["states"])
    bad_state = [n.name for n in dg.nodes if n.state not in valid_states]
    add(1, "State styles exact", not bad_state, f"unknown state for {', '.join(bad_state[:3])} (use {', '.join(STD['states'])})")
    bad_kind = [e.step for e in dg.edges if e.kind not in STD["connectors"]]
    add(2, "Connector badge styles exact", not bad_kind, f"unknown flow type on {', '.join(bad_kind[:4])} (use {', '.join(STD['connectors'])})")
    add(3, "Badges are numbers only", all(re.fullmatch(r"\d{1,2}\.\d{1,2}", e.step) for e in dg.edges),
        "badges must be numbers like 1.0, 2.1 - put the words in desc")
    steps = [e.step for e in dg.edges]
    add(4, "Unique badge numbers", len(steps) == len(set(steps)), "a badge number is used twice")
    ks = sorted(step_key(s) for s in steps)
    seq = all(k[0] < 999 for k in ks) and ks and ks[0][0] == 1 and all(
        (b[0] == a[0] and b[1] == a[1] + 1) or (b[0] == a[0] + 1 and b[1] == 0) for a, b in zip(ks, ks[1:])) and ks[0][1] == 0
    add(5, "Chronological numbering", bool(seq), "numbers must run 1.0, 1.1 … 2.0, 2.1 … with no gaps")
    add(6, "Title block present", bool(d.get("title")), "title missing")
    add(7, "Date metadata present", True)
    okdate = all(re.fullmatch(r"\d{4}-\d{2}-\d{2}", x) for x in (d["_created"], d["_modified"]))
    add(8, "Date format YYYY-MM-DD", okdate, "dates must be YYYY-MM-DD")
    add(9, "Zone / gutter / ring layout", not any(v[0] in ("A5",) for v in viol), "a shape sits in a routing lane")
    nozone = [n.name for n in dg.nodes if n.zone not in dg.zmap]
    badz = [z.name for z in dg.zones if z.kind not in STD["zones"]]
    add(10, "Boundary containers used", not nozone and not badz,
        (f"no zone for {', '.join(nozone[:3])}" if nozone else f"zone kind not in the standard: {', '.join(badz[:3])} (use dmz, saas, core, downstream)"))
    add(11, "Orthogonal routing", all("edgeStyle=orthogonalEdgeStyle" in STD["connectors"][e.kind]["style"] for e in dg.edges if e.kind in STD["connectors"]))
    code = lambda *c: [v[1] for v in viol if v[0] in c]
    add(12, "Full corner lists declared (A1)", not code("A1"), "; ".join(code("A1"))[:160])
    add(13, "No shared connector segments (A2, A3)", not code("A2", "A3"), "; ".join(code("A2", "A3"))[:160])
    add(14, "Lane separation >= 20px (A4)", not code("A4"), "; ".join(code("A4"))[:160])
    add(15, "Port stagger >= 20px, no shared anchors (A7)", not code("A7"), "; ".join(code("A7"))[:160])
    add(16, "Shape clearance >= 15px (A5)", not code("A5"), "; ".join(code("A5"))[:160])
    add(17, "Reserved blocks clear (A6)", not code("A6"), "; ".join(code("A6"))[:160])
    add(18, "Fan-out lane nesting", "REVIEW" if dg.crossings else True, f"{dg.crossings} crossing(s), each drawn with a line hop")
    add(19, "Badge positions computed and clear (A9)", not code("A9"), "; ".join(code("A9"))[:160])
    ring_y = max(z.y + z.h for z in dg.zones) + G["ring_gap"] - 1
    on_ring = lambda e: any(horiz(sg) and sg[0][1] >= ring_y for sg in seg_list(e.pts))
    rev_bad = [e.step for e in dg.edges if e.reverse and e.pts and e.plan not in ("VD", "VU") and not on_ring(e)]
    add(20, "Reverse flows on the outer ring", not rev_bad, f"{', '.join(rev_bad)} not on the return ring")
    add(21, "Flow Legend present", True)
    add(22, "Flow Legend complete", all(e.desc.strip() for e in dg.edges),
        "flows without a description: " + ", ".join(e.step for e in dg.edges if not e.desc.strip())[:120])
    add(23, "Flow Legend type colours", True)
    add(24, "System State Legend present (swatches, no hex)", not re.search(r">#?[0-9A-Fa-f]{6}<", svg_text))
    add(25, "No double-escaping", "&amp;lt;" not in xml_text and "&amp;gt;" not in xml_text, "double-escaped HTML in a cell")
    add(26, "Line hops used correctly", True)
    try:
        r = ET.fromstring(xml_text)
        ids = {c.get("id") for c in r.iter("mxCell")}
        okx = all((c.get("source") in ids and c.get("target") in ids) for c in r.iter("mxCell") if c.get("source"))
    except ET.ParseError:
        okx = False
    add(27, "XML well-formed, ids resolve", okx, "the .drawio does not parse")
    add(28, "Audit returned zero violations", not viol, f"{len(viol)} violation(s)")
    add(29, "Legibility: no text overlap (A11)", not code("A11"), "; ".join(code("A11"))[:160])
    return rows


def text_fit(dg):
    out = []
    for n in dg.nodes:
        name, sub, note = n.lines()
        if len(name) > 3:
            out.append(f"FAIL system '{n.name[:40]}' name needs {len(name)} lines in a {n.w:.0f}px box - shorten it (3 lines max)")
        if len(sub) > 4:
            out.append(f"FAIL system '{n.name[:40]}' sub-label needs {len(sub)} lines - shorten it (4 lines max)")
    for e in dg.edges:
        if len(e.desc) > 180:
            out.append(f"FAIL flow {e.step} description is {len(e.desc)} characters - shorten it (180 max)")
    return out


def validate_input(dg):
    out = []
    for e in dg.edges:
        for end in (e.src, e.tgt):
            if end not in dg.nmap:
                out.append(f"FAIL flow {e.step}: unknown system id '{end}'")
        if e.src == e.tgt:
            out.append(f"FAIL flow {e.step}: a flow from a system to itself is not drawn")
    for n in dg.nodes:
        if n.zone not in dg.zmap:
            out.append(f"FAIL system '{n.name}': zone '{n.zone}' is not in zones")
    return out


def normalise(d):
    """Accept the kit's arch.json too (ulta-kit diagram / build_drawio.py): zones[].title, nodes[].label,
    state keep|changed, flows[].badge/source/target/kind opt|reject, zone kind down."""
    d = dict(d)
    st = {"keep": "existing", "changed": "modified", "change": "modified"}
    kd = {"opt": "optional", "reject": "rejection"}
    zk = {"down": "downstream"}
    d["zones"] = [dict(z, name=z.get("name") or z.get("title") or z.get("id"),
                       kind=zk.get(str(z.get("kind", "")).lower(), z.get("kind"))) for z in d.get("zones") or []]
    d["systems"] = [dict(n, name=n.get("name") or n.get("label") or n.get("id"),
                         state=st.get(str(n.get("state", "")).lower(), n.get("state")))
                    for n in (d.get("systems") or d.get("nodes") or [])]
    d["flows"] = [dict(f, step=f.get("step") or f.get("badge"), type=kd.get(str(f.get("type") or f.get("kind") or "sync").lower(),
                                                                             f.get("type") or f.get("kind")))
                  for f in d.get("flows") or []]
    t = str(d.get("title") or "")
    if t.startswith(("ULTA Beauty \u2014 ", "ULTA Beauty - ")):
        d["title"] = t
    return d


def print_pdf(png, pdf):
    """Whole diagram on one landscape page (Letter, or 11 × 17 when large), 300 dpi, printable margin."""
    from PIL import Image
    im = Image.open(png).convert("RGB")
    w, h = im.size
    big = w > 3300 or h > 2550
    pw, ph = (17, 11) if big else (11, 8.5)
    if h > w:
        pw, ph = ph, pw
    W, H, m = int(pw * 300), int(ph * 300), int(0.33 * 300)
    k = min((W - 2 * m) / w, (H - 2 * m) / h)
    im2 = im.resize((max(1, int(w * k)), max(1, int(h * k))), Image.LANCZOS)
    page = Image.new("RGB", (W, H), "white")
    page.paste(im2, ((W - im2.width) // 2, (H - im2.height) // 2))
    page.save(pdf, "PDF", resolution=300.0)


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input"); ap.add_argument("--out", required=True)
    a = ap.parse_args()
    raw = Path(a.input).read_text(encoding="utf-8")
    import plain                                         # plain punctuation: no em dashes in what a reader sees
    d = plain.deep(json.loads(raw))
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    dx = out.with_suffix(".drawio")
    today = datetime.date.today().isoformat()
    created = str(d.get("created") or "")
    if dx.exists():                                           # re-generation keeps the original Created date
        m = re.search(r"Created: (\d{4}-\d{2}-\d{2})", dx.read_text(encoding="utf-8", errors="ignore"))
        created = m.group(1) if m else created
    d["_created"], d["_modified"] = created or today, str(d.get("modified") or today)
    t = str(d.get("title") or "Architecture")
    d["_title"] = t if t.startswith("ULTA Beauty") else "ULTA Beauty - " + t
    gate = d.get("gate")
    d["_subtitle"] = str(d.get("subtitle") or (f"C2 Container View · Gate {gate}" if gate else "C2 Container View"))
    d["_dates"] = f"Created: {d['_created']}  |  Last Modified: {d['_modified']}"

    d = normalise(d)
    dg = Diagram(d)
    probs = validate_input(dg)
    if probs:
        print("NEEDS CORRECTION | the input does not describe a drawable diagram (nothing written)")
        for p in probs[:12]:
            print("  " + p)
        return
    dg.reserved = []
    dg.solve()
    F = furniture(dg, d)
    dg.badges()
    viol = dg.audit()
    fit = text_fit(dg)
    s_txt = svg(dg, d, F)
    x_txt = drawio(dg, d, F)
    rows = checks(dg, d, viol, x_txt, s_txt)
    import compliance
    files = []
    if viol:
        print(f"NEEDS CORRECTION | geometry audit: {len(dg.edges)} connectors, {dg.crossings} crossing(s), "
              f"{len(viol)} violation(s) - nothing written (Step 8b)")
        for v in viol[:10]:
            print(f"  FAIL {v[0]} {v[1]}")
        if getattr(dg, "timed_out", False):
            print("  The layout did not settle within the time budget - this view has too many crossing flows for one page.")
        print("  Fix: fewer flows on one system, put supporting systems on row 1, or split the view (C2 → two C3 views).")
    else:
        x_txt, s_txt = plain.markup(x_txt), plain.markup(s_txt)
        dx.write_text(x_txt, encoding="utf-8")
        sv = out.with_suffix(".svg"); sv.write_text(s_txt, encoding="utf-8")
        hp = out.with_suffix(".html"); hp.write_text(page_html(s_txt, d), encoding="utf-8"); plain.clean(hp)
        import htmlpdf
        htmlpdf.ensure(hp)
        files = [dx, sv, hp]
        png, pdf = out.with_suffix(".png"), out.with_suffix(".pdf")
        try:
            import resvg_py
            png.write_bytes(bytes(resvg_py.svg_to_bytes(svg_string=s_txt, zoom=2, background="#FFFFFF")))
        except Exception:
            import lo; lo.convert(sv, out.parent, "png", timeout=180)
        if png.exists():
            try:
                print_pdf(png, pdf)
            except Exception:
                pass
        files += [p for p in (png, pdf) if p.exists()]
    scanned = compliance.scan([f for f in files if f.suffix in (".drawio", ".svg")]) if files else []
    blk = [x for x in scanned if x["severity"] == "BLOCK"]
    rev = [x for x in scanned if x["severity"] == "REVIEW"]
    rows.append((30, "Text fit (nothing cut)", not fit, fit[0][5:] if fit else ""))
    rows.append((31, "Sensitive data", not blk, "secret or personal data found"))
    import brand_colours as _BCOL                         # zero deviation from the diagram standard's colours
    _off = [x for f in files if f.suffix in (".drawio", ".svg", ".html") for x in _BCOL.summary(f, 3)]
    rows.append((32, "Colours (the standard's palette only)", not _off, "; ".join(_off[:3])))
    status = "NEEDS CORRECTION" if (viol or fit or blk or any(r[2] is False for r in rows)) else "READY"
    if not viol:
        print(f"{status} | audit: {len(dg.edges)} connectors, {dg.crossings} discrete crossing(s), 0 violation(s) | "
              f"{STD['name']} v{STD['version']}")
    print(f"{'#':>3}  {'check':<46}result")
    for n, name, ok, why in rows:
        res = "PASS" if ok is True else ("REVIEW" if ok == "REVIEW" else "FAIL")
        print(f"{n:>3}  {name:<46}{res}{'  - ' + why if res != 'PASS' and why else ''}")
    for f_ in fit[:6]:
        print("  " + f_)
    for x in blk[:5]:
        print(f"  BLOCK {x.get('kind', '')}: {x.get('masked', '')}")
    for x in rev[:5]:
        print(f"  REVIEW {x.get('kind', '')}: {x.get('masked', '')}")
    if not d.get("kdd"):
        print("  REVIEW no Key Design Decisions given - reviewers expect KDD-001 … (Step 10)")
    if files:
        print("FILES (attach every one): " + " · ".join(str(p) for p in files))
    import tokens as TK
    import checks as _CK                                  # the evidence the RESULT line's score is computed from
    if files:
        _CK.record(dx, [(name, "PASS" if ok is True else "REVIEW" if ok == "REVIEW" else "FAIL", "" if ok is True else why,
                         ok == "REVIEW") for n, name, ok, why in rows], status)
        std = _CK.summary(dx).replace(" checks", f" checks, {STD['name']} v{STD['version']}", 1)
    else:
        std = "ULTA Standards Match: not validated (nothing written: the layout failed its geometry audit)"
    print(TK.report_page([Path(__file__)], raw, status, "architecture", std=std))


if __name__ == "__main__":
    main()
