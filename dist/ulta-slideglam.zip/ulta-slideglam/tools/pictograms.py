"""Retail pictograms drawn natively, in the template's own icon style (template slides 28-31): line drawings in one
colour with rounded line ends and corners, the line about 1/15 of the size. Each pictogram is one PowerPoint shape (a
freeform, editable point by point) coloured from the theme like any shape: white on a coloured circle, or a template
colour on a white card. Nothing is a picture file - trucks, DCs, stores and invoices are drawn like the chevrons.

    import pictograms as PG
    PG.draw(C, "truck", cx, cy, size, colour="ACCENT_2", bg=ND.WHITE)     # magenta on a white card
    PG.draw(C, "dc", cx, cy, size, colour=ND.WHITE, bg="ACCENT_2")        # white on a magenta circle
    PG.pick("Trucks leave the DC every night")  -> "truck"
    PG.icon(C, name, cx, cy, size, colour, bg)  # a pictogram, or one of the template's own icons by its name

Pictograms (NAMES): vehicles truck, van, ship, plane; places dc, store, vendor, home, office; goods carton, pallet,
rack, forklift, cart, returns, gift; documents invoice, po, ledger, receipt-roll; money bank, card, cash, coin, price,
percent, calculator, scales; signs check, clock, web, scan, globe. The template's own icons (bag, person, team,
calendar, mobile, gears, bar-chart ...) are used where they fit: pick() looks at both, the pictograms first for supply
chain, order and finance words.
"""
import re
import sys
from pathlib import Path

from lxml import etree
from pptx.enum.shapes import MSO_SHAPE
from pptx.oxml import parse_xml
from pptx.util import Emu

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I
import native_draw as ND

A = ND.A
U = 100                                      # path units per drawing unit (the drawings are on a 100 x 100 grid)
STROKE = 0.062                               # the line, as a share of the size (the template's icons: 1.6 of 24)


# ============================================================================================ path language
class _Path:
    """One sub-path on the 100 x 100 grid. mode: 'line' (the outline only), 'solid' (the outline, filled with the
    ground colour so it hides what is behind it: wheels in front of a truck), 'mask' (ground colour, no outline)."""

    def __init__(self, mode="line"):
        self.mode, self.ops = mode, []

    def M(self, x, y):
        self.ops.append(f'<a:moveTo>{_pt(x, y)}</a:moveTo>')
        return self

    def L(self, *pts):
        for x, y in pts:
            self.ops.append(f'<a:lnTo>{_pt(x, y)}</a:lnTo>')
        return self

    def A(self, r, start, sweep, ry=None):
        """An arc from the current point, which sits at `start` degrees on a circle of radius r (0 = right, 90 = down),
        sweeping `sweep` degrees (positive = clockwise on the slide)."""
        self.ops.append(f'<a:arcTo wR="{round(r * U)}" hR="{round((ry or r) * U)}" stAng="{round(start * 60000)}" '
                        f'swAng="{round(sweep * 60000)}"/>')
        return self

    def C(self, x1, y1, x2, y2, x, y):
        self.ops.append(f'<a:cubicBezTo>{_pt(x1, y1)}{_pt(x2, y2)}{_pt(x, y)}</a:cubicBezTo>')
        return self

    def Z(self):
        self.ops.append('<a:close/>')
        return self

    def xml(self):
        fill = ' fill="none"' if self.mode == "line" else ""
        stroke = ' stroke="0"' if self.mode == "mask" else ""
        return f'<a:path w="{100 * U}" h="{100 * U}"{fill}{stroke}>{"".join(self.ops)}</a:path>'


def _pt(x, y):
    return f'<a:pt x="{round(x * U)}" y="{round(y * U)}"/>'


def poly(mode, *pts, closed=True):
    p = _Path(mode).M(*pts[0]).L(*pts[1:])
    return p.Z() if closed else p


def line(*pts):
    return poly("line", *pts, closed=False)


def rect(mode, x0, y0, x1, y1, r=0.0):
    if not r:
        return poly(mode, (x0, y0), (x1, y0), (x1, y1), (x0, y1))
    p = _Path(mode).M(x0 + r, y0).L((x1 - r, y0)).A(r, 270, 90).L((x1, y1 - r)).A(r, 0, 90)
    return p.L((x0 + r, y1)).A(r, 90, 90).L((x0, y0 + r)).A(r, 180, 90).Z()


def circle(mode, cx, cy, r):
    p = _Path(mode).M(cx + r, cy)
    for a in (0, 90, 180, 270):
        p.A(r, a, 90)
    return p.Z()


def dot(cx, cy):
    """A small round mark (a circle the line fills)."""
    return circle("line", cx, cy, 0.6)


# ============================================================================================ the drawings
def _truck():
    return [rect("solid", 6, 24, 62, 70, 3),
            poly("solid", (62, 38), (80, 38), (93, 54), (93, 70), (62, 70)),
            poly("line", (68, 45), (78, 45), (85, 54), (68, 54)),
            circle("solid", 24, 74, 8.5), circle("solid", 77, 74, 8.5)]


def _van():
    return [poly("solid", (8, 30), (60, 30), (78, 46), (92, 50), (92, 70), (8, 70)),
            poly("line", (62, 37), (74, 48), (62, 48)),
            line((40, 34), (40, 66)),
            circle("solid", 26, 72, 8.5), circle("solid", 74, 72, 8.5)]


def _ship():
    return [rect("solid", 64, 22, 80, 56, 2),
            line((68, 31), (76, 31)),
            rect("solid", 14, 42, 33, 56), rect("solid", 33, 42, 52, 56), rect("solid", 22, 28, 41, 42),
            poly("solid", (4, 56), (96, 56), (86, 78), (14, 78)),
            line((10, 90), (24, 86), (38, 90), (52, 86), (66, 90), (80, 86), (90, 90))]


def _plane():
    return [poly("solid", (50, 6), (56, 14), (56, 38), (92, 58), (92, 66), (56, 56), (56, 78), (68, 88), (68, 94),
                 (50, 89), (32, 94), (32, 88), (44, 78), (44, 56), (8, 66), (8, 58), (44, 38), (44, 14))]


def _dc():
    return [poly("solid", (6, 40), (50, 15), (94, 40), (94, 86), (6, 86)),
            rect("line", 20, 56, 44, 86), rect("line", 56, 56, 80, 86),
            line((20, 71), (44, 71)), line((56, 71), (80, 71))]


def _store():
    scallops = _Path("solid").M(10, 20).L((90, 20), (95, 38))
    for c in (84, 61, 39, 16):                               # the awning's edge, right to left
        scallops.A(11, 0, 180)
    scallops.L((10, 20)).Z()
    return [rect("solid", 13, 34, 87, 88),
            scallops,
            rect("line", 42, 62, 58, 88), rect("line", 21, 60, 33, 74), rect("line", 67, 60, 79, 74)]


def _vendor():
    return [rect("solid", 14, 12, 26, 50),
            poly("solid", (8, 88), (8, 48), (36, 32), (36, 48), (64, 32), (64, 48), (92, 32), (92, 88)),
            rect("line", 20, 62, 32, 74), rect("line", 44, 62, 56, 74), rect("line", 68, 62, 80, 88)]


def _home():
    return [rect("solid", 66, 16, 76, 44),
            poly("solid", (50, 12), (92, 50), (80, 50), (80, 88), (20, 88), (20, 50), (8, 50)),
            rect("line", 42, 62, 58, 88)]


def _office():
    return [rect("solid", 22, 8, 78, 90, 2),
            line((34, 24), (44, 24)), line((56, 24), (66, 24)),
            line((34, 40), (44, 40)), line((56, 40), (66, 40)),
            line((34, 56), (44, 56)), line((56, 56), (66, 56)),
            rect("line", 43, 72, 57, 90)]


def _carton():
    return [poly("solid", (50, 10), (90, 30), (90, 72), (50, 92), (10, 72), (10, 30)),
            line((10, 30), (50, 50), (90, 30)), line((50, 50), (50, 92)),
            line((30, 20), (70, 40), (70, 56))]


def _pallet():
    return [rect("solid", 33, 18, 67, 45, 2), rect("solid", 14, 45, 49, 72, 2), rect("solid", 51, 45, 86, 72, 2),
            line((44, 18), (44, 28)), line((25, 45), (25, 55)), line((62, 45), (62, 55)),
            rect("solid", 8, 72, 92, 80), line((14, 80), (14, 89)), line((50, 80), (50, 89)), line((86, 80), (86, 89))]


def _forklift():
    return [line((72, 10), (72, 84)), line((72, 84), (96, 84)),
            rect("solid", 76, 52, 96, 76, 2),
            poly("solid", (10, 50), (30, 50), (38, 26), (60, 26), (60, 76), (10, 76)),
            line((38, 50), (60, 50)),
            circle("solid", 24, 80, 9), circle("solid", 52, 80, 9)]


def _cart():
    return [line((4, 16), (16, 16), (28, 66), (84, 66)),
            poly("line", (21, 30), (94, 30), (86, 56), (26, 56)),
            circle("line", 34, 80, 6), circle("line", 76, 80, 6)]


def _returns():
    return [rect("solid", 8, 46, 48, 86, 2), line((8, 58), (48, 58)), line((28, 46), (28, 58)),
            _Path("line").M(56, 30).L((72, 30)).A(17, 270, 180).L((60, 64)),
            line((44, 30), (56, 30)), line((52, 20), (42, 30), (52, 40))]


def _invoice():
    return [poly("solid", (18, 8), (62, 8), (82, 28), (82, 92), (18, 92)),
            line((62, 8), (62, 28), (82, 28)),
            line((30, 44), (70, 44)), line((30, 58), (70, 58)), line((30, 72), (54, 72))]


def _po():
    return [rect("solid", 16, 14, 84, 92, 5),
            rect("solid", 34, 7, 66, 22, 4),
            line((28, 46), (34, 52), (44, 40)), line((52, 46), (72, 46)),
            line((28, 70), (34, 76), (44, 64)), line((52, 70), (72, 70))]


def _ledger():
    return [rect("solid", 16, 8, 84, 92, 4), line((30, 8), (30, 92)),
            line((42, 30), (72, 30)), line((42, 46), (72, 46)), line((42, 62), (64, 62))]


def _receipt_roll():
    return [poly("solid", (20, 8), (80, 8), (80, 92), (70, 86), (60, 92), (50, 86), (40, 92), (30, 86), (20, 92)),
            line((32, 28), (68, 28)), line((32, 44), (68, 44)), line((32, 60), (56, 60))]


def _bank():
    return [poly("solid", (8, 34), (50, 10), (92, 34)),
            line((22, 44), (22, 72)), line((40, 44), (40, 72)), line((60, 44), (60, 72)), line((78, 44), (78, 72)),
            rect("line", 10, 80, 90, 90, 1)]


def _card():
    return [rect("solid", 6, 20, 94, 80, 8), line((6, 38), (94, 38)), line((18, 64), (42, 64)), line((50, 64), (58, 64))]


def _cash():
    return [rect("solid", 6, 26, 94, 74, 4), circle("line", 50, 50, 12), dot(20, 50), dot(80, 50)]


def _dollar(cx, cy, s):
    """A dollar sign centred on cx, cy, s tall."""
    h = s / 2
    w = s * 0.3
    return [_Path("line").M(cx + w, cy - h * 0.62).C(cx + w * 0.6, cy - h * 0.86, cx - w, cy - h * 0.84, cx - w,
                                                      cy - h * 0.38)
            .C(cx - w, cy + h * 0.02, cx + w, cy - h * 0.06, cx + w, cy + h * 0.38)
            .C(cx + w, cy + h * 0.86, cx - w * 0.6, cy + h * 0.86, cx - w, cy + h * 0.62),
            line((cx, cy - h), (cx, cy + h))]


def _coin():
    return [circle("solid", 50, 50, 40)] + _dollar(50, 50, 52)


def _check():
    return [circle("solid", 50, 50, 40), line((32, 51), (45, 64), (69, 38))]


def _clock():
    return [circle("solid", 50, 50, 40), line((50, 26), (50, 50), (66, 60))]


def _web():
    return [rect("solid", 6, 14, 94, 86, 6), line((6, 32), (94, 32)), dot(17, 23), dot(27, 23),
            line((30, 46), (36, 46), (42, 72), (68, 72)), poly("line", (40, 54), (74, 54), (70, 66), (42, 66))]


def _scan():
    return [rect("solid", 10, 20, 90, 80, 6),
            line((24, 34), (24, 66)), line((34, 34), (34, 66)), line((42, 34), (42, 66)), line((54, 34), (54, 66)),
            line((62, 34), (62, 66)), line((76, 34), (76, 66))]


def _price():
    return [poly("solid", (10, 18), (48, 18), (90, 60), (60, 90), (18, 48)), circle("line", 32, 40, 6)]


def _percent():
    return [circle("solid", 50, 50, 40), circle("line", 37, 36, 7), circle("line", 63, 64, 7), line((34, 68), (66, 32))]


def _globe():
    return [circle("solid", 50, 50, 40), _Path("line").M(50, 10).A(18, 270, 180, 40).A(18, 90, 180, 40),
            line((12, 38), (88, 38)), line((12, 62), (88, 62))]


def _rack():
    return [line((12, 8), (12, 92)), line((88, 8), (88, 92)), line((12, 36), (88, 36)), line((12, 66), (88, 66)),
            rect("line", 22, 16, 44, 36, 2), rect("line", 52, 46, 78, 66, 2), rect("line", 22, 76, 40, 92, 2),
            rect("line", 48, 76, 66, 92, 2)]


def _calculator():
    return [rect("solid", 18, 6, 82, 94, 6), rect("line", 30, 18, 70, 36, 2),
            dot(34, 52), dot(50, 52), dot(66, 52), dot(34, 66), dot(50, 66), dot(66, 66), dot(34, 80), dot(50, 80),
            dot(66, 80)]


def _scales():
    return [line((50, 12), (50, 86)), line((30, 86), (70, 86)), line((14, 26), (86, 26)),
            line((14, 26), (4, 54)), line((14, 26), (24, 54)), line((86, 26), (76, 54)), line((86, 26), (96, 54)),
            _Path("line").M(4, 54).A(10, 180, -180), _Path("line").M(76, 54).A(10, 180, -180)]


def _gift():
    return [rect("solid", 14, 44, 86, 90, 2), rect("solid", 8, 30, 92, 44, 2), line((50, 30), (50, 90)),
            _Path("line").M(50, 30).C(36, 30, 24, 22, 32, 12).C(40, 6, 48, 18, 50, 30),
            _Path("line").M(50, 30).C(64, 30, 76, 22, 68, 12).C(60, 6, 52, 18, 50, 30)]


DRAWINGS = {"truck": _truck, "van": _van, "ship": _ship, "plane": _plane, "dc": _dc, "store": _store, "vendor": _vendor,
            "home": _home, "office": _office, "carton": _carton, "pallet": _pallet, "forklift": _forklift,
            "cart": _cart, "returns": _returns, "invoice": _invoice, "po": _po, "ledger": _ledger,
            "receipt-roll": _receipt_roll, "bank": _bank, "card": _card, "cash": _cash, "coin": _coin,
            "check": _check, "clock": _clock, "web": _web, "scan": _scan, "price": _price, "percent": _percent,
            "globe": _globe, "rack": _rack, "calculator": _calculator, "scales": _scales, "gift": _gift}
NAMES = list(DRAWINGS)


# ============================================================================================ picking
WORDS = {                                    # words (and word pairs, joined by '-') that call for each pictogram
    "truck": "truck trucks trucking freight transport transportation carrier carriers linehaul line-haul ltl ftl "
             "load loads loading load-plan shipment shipments dispatch fleet lane lanes outbound inbound transit drayage "
             "ship "
             "ships shipped shipping deliver delivers delivery deliveries store-delivery",
    "van": "van vans last-mile courier same-day doorstep home-delivery parcel-carrier deliver delivers delivered "
           "delivery",
    "ship": "ocean vessel vessels container containers port ports import imports overseas sea",
    "plane": "air airfreight air-freight flight flights expedite expedited",
    "dc": "dc dcs distribution distribution-center distribution-centre warehouse warehouses fulfillment fulfilment "
          "fc fcs depot crossdock cross-dock ship-from-dc",
    "store": "store stores shop shops boutique branch ship-from-store pick-up pickup bopis curbside",
    "vendor": "vendor vendors supplier suppliers manufacturer manufacturers factory factories brand-partner production "
              "source sourcing",
    "home": "home homes house household residence doorstep",
    "office": "headquarters hq corporate office offices support-center",
    "carton": "carton cartons box boxes case cases package packages pack packed packing parcel parcels",
    "pallet": "pallet pallets goods-receipt goods-received receiving receive received stock inventory stage staged "
              "staging",
    "rack": "storage store-in rack racks racking shelving slot slotting bin bins replenish replenishment",
    "forklift": "forklift putaway put-away unload unloading handling dock docks yard",
    "cart": "cart carts basket checkout order orders ordering ordered sales-order ecommerce e-commerce online-order buy",
    "returns": "return returns returned refund refunds exchange exchanges reverse rtv return-to-vendor",
    "gift": "gift gifts gift-card gift-cards gwp sample samples reward rewards",
    "invoice": "invoice invoices invoiced bill billing bills statement statements",
    "po": "po pos purchase-order purchase-orders requisition requisitions checklist sign-off",
    "ledger": "ledger journal journals gl general-ledger posting post posted accounting books record subledger "
              "sub-ledger close month-end period-end",
    "receipt-roll": "receipt receipts transaction transactions sale register till pos-sale",
    "bank": "bank banks treasury settlement settle settled remittance",
    "card": "card cards tender credit debit authorization authorize authorise authorisation",
    "cash": "cash payment payments pay paid payout payable payables disbursement",
    "coin": "revenue cost costs dollars money funds cash-application receivable receivables",
    "price": "price prices pricing price-change markdown markdowns retail-price",
    "percent": "promotion promotions promo promos discount discounts percent coupon coupons margin",
    "calculator": "accrual accruals calculate calculation tax taxes estimate estimates",
    "scales": "reconcile reconciled reconciliation reconciliations audit audits three-way variance variances",
    "check": "match matched matching verify verified validate validated approve approved approval complete "
             "completed done confirm confirmed",
    "clock": "time timing lead-time cutoff cut-off sla hours wait",
    "web": "web website site digital online ulta-com",
    "scan": "scan scanned scanning barcode barcodes label labels labeling sku skus pick picked picking",
    "globe": "global international country countries world cross-border",
}
TEMPLATE_WORDS = {                           # retail words for the template's own icons (template slides 28-31)
    "person": "guest guests customer customers shopper shoppers member members",
    "team": "team teams associate associates staff people crew",
    "calendar": "calendar date dates weekly monthly schedule scheduled appointment appointments",
    "bar-chart": "report reports reporting results analysis analyze forecast forecasts demand kpi kpis metrics",
    "trend-up": "growth grow increase trend comp",
    "mobile": "app apps mobile phone text sms",
    "gears": "system systems process automate automated automation configure configuration setup set-up",
    "megaphone": "campaign campaigns marketing launch announce advertising ad ads",
    "laptop-analytics": "dashboard dashboards analytics",
    "shelf": "shelf shelves planogram planograms assortment fixture fixtures",
    "location": "location locations region regions zone zones market markets",
    "pencil": "requisition requisitions request requests draft drafts write edit",
    "search": "search find inspect inspection review",
    "warning": "exception exceptions issue issues risk risks alert alerts shortage shortages",
    "target": "target targets goal goals",
    "compliance": "compliance policy policies control controls sox",
    "document-alert": "dispute disputes discrepancy discrepancies chargeback chargebacks deduction deductions",
    "email": "email emails notification notifications",
    "lipstick": "beauty cosmetics makeup",
    "salon": "salon services stylist hair",
    "milestones": "milestone milestones roadmap",
    "shuffle": "sort sorted sorting sortation flow-through",
    "lock": "secure security fraud",
    "speed": "fast faster speed express",
}
_INDEX = {}
for _n, _w in list(WORDS.items()) + list(TEMPLATE_WORDS.items()):
    for _k in _w.split():
        _INDEX.setdefault(_k, []).append(_n)


def _words(text):
    out = []
    for w in re.split(r"[^a-z0-9]+", str(text or "").lower().replace(".com", "-com")):
        if w and w not in _INDEX:                                # plurals and -es / -ed forms find their word
            w = next((c for c in (w[:-1], w[:-2], w[:-1] + "e") if len(c) > 2 and c in _INDEX and
                      w[-1] in "sd"), w)
        if w:
            out.append(w)
    return out


TITLE, LAST, TEXT = 10, 3, 2                 # a title word outweighs any description: 'Stores' is a store


def scores(title, text=""):
    """{pictogram: score} for an item: a word of its title counts TITLE (its last word - the invoice of 'Vendor
    invoice' - LAST more), a word of its text TEXT; a word pair (purchase order) counts half again and uses up its
    two words."""
    sc = {}
    for part, weight in ((title, TITLE), (text, TEXT)):
        w = _words(part)
        last = len(w) - 1 if weight == TITLE else -1
        done = set()
        for k in range(len(w) - 1):
            for n in _INDEX.get(f"{w[k]}-{w[k + 1]}", ()):
                sc[n] = sc.get(n, 0) + weight * 1.5 + (LAST if k + 1 == last else 0)
                done.update((k, k + 1))
        for k, t in enumerate(w):
            if k not in done:
                for n in _INDEX.get(t, ()):
                    sc[n] = sc.get(n, 0) + weight + (LAST if k == last else 0)
    return sc


def ranked(text, title=""):
    """The pictograms (and template icons) the words call for, best first."""
    return [n for n, _ in sorted(scores(title, text).items(), key=lambda kv: -kv[1])]


_KB = None


def _kit_builder():
    """Presentation Central's own build_from_storyboard (the template's icons), loaded from its own path under its own name. The
    Studio has a build_from_storyboard of its own (another icon library): imported by name, whichever one a process loaded first
    answered here - in the Studio's server, the Studio's, so an icon was picked from one library and checked against the other."""
    global _KB
    if _KB is None:
        import importlib.util
        spec = importlib.util.spec_from_file_location("central_kit_build_from_storyboard", str(KIT / "build_from_storyboard.py"))
        m = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(m)
        _KB = m
    return _KB


def _template_pick(text):
    try:
        return _kit_builder().pick_icon(text)
    except Exception:
        return None


GENERIC = ("gears", "check", "target", "milestones", "idea", "list", "layers", "puzzle")


def assign(items, avoid=()):
    """Icons for items [(title, text, icon or '')]: the given ones kept; then, strongest match first, each item the
    pictogram its title names (a different one for each where the titles allow, the same one where two titles name
    it: two DCs are two warehouses); then the best fit for the rest by their text; then a repeat of an item's best
    fit, the template's own pick, a generic icon."""
    out = [(it[2] or None) for it in items]
    used = set(avoid) | {x for x in out if x}
    sc = [scores(it[0], it[1]) if not out[k] else {} for k, it in enumerate(items)]
    order = sorted(((v, k, n) for k, d in enumerate(sc) for n, v in d.items()), key=lambda c: (-c[0], c[1]))
    for floor in (TITLE, 0):                                     # the titles first, then the texts
        for v, k, n in order:
            if v >= floor and out[k] is None and n not in used:
                out[k] = n
                used.add(n)
        if floor:
            for k, d in enumerate(sc):                           # a title that names a used one: the same picture
                if out[k] is None and d and max(d.values()) >= TITLE:
                    out[k] = max(d, key=d.get)
    for k, it in enumerate(items):
        if out[k] is None:
            alt = _template_pick(f"{it[0]} {it[1]}")
            out[k] = (max(sc[k], key=sc[k].get) if sc[k] else None) or (alt if alt and alt not in used else None) \
                or next((g for g in GENERIC if g not in used), GENERIC[0])
            used.add(out[k])
    return out


def pick(text, avoid=(), title=""):
    """The pictogram (or the template's own icon) that fits the words best, one not in `avoid` where the words allow."""
    return assign([(title, text, "")], avoid)[0]


# ============================================================================================ drawing
def shape(sl, name, x, y, size, colour, bg, width=None):
    """The pictogram `name` as one freeform shape at x, y (EMU), size x size: lines in `colour`, the parts that hide
    what is behind them filled with `bg` (the colour it sits on). width: the line in pt (default: STROKE of the size)."""
    paths = DRAWINGS[name]()
    sh = sl.shapes.add_shape(MSO_SHAPE.RECTANGLE, Emu(int(x)), Emu(int(y)), Emu(int(size)), Emu(int(size)))
    ND._set_fill(sh.fill, bg)
    ND._line(sh, colour, width or max(0.9, size / 12700 * STROKE))
    ND.no_effects(sh)
    sppr = sh._element.spPr
    geom = etree.fromstring(f'<a:custGeom xmlns:a="{A[1:-1]}"><a:avLst/><a:gdLst/><a:ahLst/><a:cxnLst/>'
                            '<a:rect l="0" t="0" r="r" b="b"/><a:pathLst>' + "".join(p.xml() for p in paths) +
                            '</a:pathLst></a:custGeom>')
    prst = sppr.find(A + "prstGeom")
    prst.addprevious(geom)
    sppr.remove(prst)
    ln = sppr.find(A + "ln")
    ln.set("cap", "rnd")                                         # rounded ends and corners, like the template's icons
    for old in ln.findall(A + "round") + ln.findall(A + "miter") + ln.findall(A + "bevel"):
        ln.remove(old)
    join = etree.SubElement(ln, A + "round")
    for tag in ("headEnd", "tailEnd", "extLst"):                 # schema order: fill, dash, join, ends
        nxt = ln.find(A + tag)
        if nxt is not None:
            nxt.addprevious(join)
            break
    sh.name = f"pictogram {name}"
    return sh


def draw(C, name, cx, cy, size, colour=ND.WHITE, bg="ACCENT_2", width=None):
    """The pictogram centred on cx, cy on a canvas (tools/timelines._Canvas): one shape added to its group."""
    return C.add(shape(C.sl, name, cx - size / 2, cy - size / 2, size, colour, bg, width))


def _template_icons():
    """The template's own icons (template slides 28-31), by name; empty when the icon library is missing."""
    global _CAT
    if _CAT is None:
        try:
            import json
            _CAT = {c["name"]: c for c in json.loads((KIT / "icons" / "icons.json").read_text(encoding="utf-8"))["icons"]}
        except (OSError, ValueError, KeyError):
            _CAT = {}
    return _CAT


_CAT = None
KIT = Path(__file__).resolve().parent.parent / "modules" / "ultabranddeliverables" / "scripts" / "kit"


def known(name):
    return name in DRAWINGS or name in _template_icons()


def icon(C, name, cx, cy, size, colour=ND.WHITE, bg="ACCENT_2"):
    """A pictogram, or the template's own icon of that name (white on a coloured circle, else in its own colour),
    centred on cx, cy; None when neither exists."""
    if name in DRAWINGS:
        return draw(C, name, cx, cy, size, colour, bg)
    if name not in _template_icons():
        return None
    try:
        B = _kit_builder()
        c = _template_icons()[name]
        s = size * 0.86                                          # the template's icons fill their box: a little smaller
        w, h = (s, s * c["h_in"] / c["w_in"]) if c["w_in"] >= c["h_in"] else (s * c["w_in"] / c["h_in"], s)
        white = colour == ND.WHITE
        rid = B.svg_part(C.sl, name, white=white, color=None if white else ND.hexof(colour))
        ids = [int(e.get("id")) for e in C.sl._element.iter() if e.tag.endswith("}cNvPr") and e.get("id", "").isdigit()]
        el = parse_xml(B._PIC_XML.format(id=max(ids + [1]) + 1, name=name, rid=rid, x=int(cx - w / 2),
                                         y=int(cy - h / 2), cx=int(w), cy=int(h)))   # python-pptx's own element types
        C.sl.shapes._spTree.append(el)
    except Exception:                                            # never break the build over an icon
        return None
    pic = C.sl.shapes[-1]
    pic.name = f"icon {name}"
    return C.add(pic)


if __name__ == "__main__":
    print(__doc__)
    print("Pictograms:", ", ".join(NAMES))
    print("Template icons:", ", ".join(sorted(_template_icons())))
