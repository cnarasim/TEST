"""Typography standard from the template's own "Formatting guidelines" slide (slide 3), applied and checked on every
deck:  Headlines 36 pt · Highlighted text 24 pt (display face) · Sub-headline Circular Bold 18 pt · Body Circular
Regular 12 pt. The display face is Chronicle Deck Semibold in the guideline; the template's slides use Playfair Display
Black as its stand-in (Chronicle cannot be embedded), and so does this tool (brand.json "typography" can change it).

Roles on content slides:
  headline   the slide title (display face, top of the slide)
  highlight  other display-face text: column headers, big numbers
  subhead    the bold lead line of a card / cell, table header rows
  body       everything else
Not resized (fonts still mapped): cover, agenda, divider and closing slides (display layouts); diagram, graphic and
library slides (engine-drawn, sized to fit their shapes); footer / page-number chrome; process step number badges.
Template components (brand.json typography.component_slides: cards, big numbers, action table, grid, flow) keep the
sizes the template designed for them - the headline still takes the standard, and a run that had to
shrink well below its designed size is reported (shorten the text).

    python tools/typeset.py deck.pptx [--check]
"""
import json, re, sys, zipfile
from pathlib import Path
from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import brand as _B   # noqa: E402

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
EMU_IN = 914400
import full_template as _FT   # noqa: E402
DISPLAY_SOURCES = {1, 2, 5, 32, 33} | _FT.display_sources()   # cover, agenda, divider, statement, closing


def spec(b=None):
    b = b or _B.current()
    t = b.get("typography") or {}
    face = t.get("display_font") or b.font("heading")
    return {"headline": (face, t.get("headline", 36), None),
            "highlight": (face, t.get("highlight", 24), None),
            "subhead": (t.get("subhead_font") or b.font("body_bold"), t.get("subhead", 18), True),
            "body": (t.get("body_font") or b.font("body"), t.get("body", 12), False),
            "statement": (t.get("body_font") or b.font("body"), t.get("statement", 20), False)}   # a one-sentence box (slide 6)


def is_chrome(text, sp):
    if re.search(r"proprietary|confidential|internal use", text, re.I):
        return True
    ph = sp.find(f".//{P}ph")
    return ph is not None and ph.get("type") in ("sldNum", "ftr", "dt")


def frames(tree):
    """(shape element, txBody, is_table_header_row, top_emu, width_emu) for every text frame on the slide."""
    for sp in tree.iter(P + "sp"):
        tb = sp.find(f"{P}txBody")
        if tb is None:
            continue
        off = sp.find(f"{P}spPr/{A}xfrm/{A}off"); ext = sp.find(f"{P}spPr/{A}xfrm/{A}ext")
        top = int(off.get("y")) if off is not None else 0
        wid = int(ext.get("cx")) if ext is not None else 0
        yield sp, tb, False, top, wid
    for gf in tree.iter(P + "graphicFrame"):
        off = gf.find(f"{P}xfrm/{A}off")
        top = int(off.get("y")) if off is not None else 0
        for ri, tr in enumerate(gf.iter(A + "tr")):
            for tc in tr.findall(A + "tc"):
                tb = tc.find(A + "txBody")
                if tb is not None:
                    yield gf, tb, ri == 0, top, 0


def run_font(r):
    rpr = r.find(A + "rPr")
    lat = rpr.find(A + "latin") if rpr is not None else None
    return (lat.get("typeface") if lat is not None else None), rpr


SUMMARY_SHAPES = ("modern summary", "ULTA summary", "ULTA decision")   # the summary layer: its own sizes, on every slide


def roles(tree, b, sp_spec):
    """[(run element, role)] for one content slide."""
    face = sp_spec["headline"][0]
    out = []
    for sp, tb, header_row, top, wid in frames(tree):
        name = (sp.find(f".//{P}cNvPr").get("name") or "") if sp.find(f".//{P}cNvPr") is not None else ""
        paras = [p for p in tb.findall(A + "p") if "".join(t.text or "" for t in p.iter(A + "t")).strip()]
        text = " ".join("".join(t.text or "" for t in p.iter(A + "t")) for p in paras)
        if not paras or is_chrome(text, sp) or re.match(r"Step \d+ number", name) or name in SUMMARY_SHAPES:
            continue                                   # (the takeaway line keeps its 16 pt, the decision bar its 14 pt)
        is_ph = sp.tag == P + "sp" and sp.find(f".//{P}nvPr/{P}ph") is not None
        title_ph = is_ph and top < int(1.6 * EMU_IN) and len(paras) <= 2       # the slide title placeholder
        for pi, p in enumerate(paras):
            for r in p.findall(A + "r"):
                if not (r.findtext(A + "t") or "").strip():
                    continue
                f, rpr = run_font(r)
                bold = rpr is not None and rpr.get("b") == "1"
                display = bool(f) and ("Playfair" in f or "Chronicle" in f or f == "+mj-lt")
                if name.startswith("Highlight "):
                    role = "statement"
                elif (display or (title_ph and not f)) and top < int(1.6 * EMU_IN) and not header_row and sp.tag == P + "sp":
                    role = "headline"                      # (a table cell is never the headline: slide 9's big numbers)
                elif display:
                    role = "highlight"
                elif header_row or (pi == 0 and len(paras) > 1 and (bold or (f or "").endswith(("Bold", "Medium")))) \
                        or (pi == 0 and len(paras) == 1 and (f or "").endswith(("Bold", "Medium")) and len(text) <= 40):
                    role = "subhead"
                else:
                    role = "body"
                out.append((r, role))
    return out


def set_run(r, face, size, bold):
    rpr = r.find(A + "rPr")
    if rpr is None:
        rpr = etree.Element(A + "rPr"); r.insert(0, rpr)
    if size is not None:
        rpr.set("sz", str(int(size * 100)))
    if bold is not None:
        rpr.set("b", "1" if bold else "0")
    lat = rpr.find(A + "latin")
    if lat is None:
        lat = etree.SubElement(rpr, A + "latin")
        order = [A + t for t in ("ln", "noFill", "solidFill", "gradFill", "blipFill", "pattFill", "grpFill", "effectLst",
                                 "effectDag", "highlight", "uLnTx", "uLn", "uFillTx", "uFill")]
        last = max((i for i, ch in enumerate(rpr) if ch.tag in order), default=-1)
        rpr.remove(lat); rpr.insert(last + 1, lat)
    lat.set("typeface", face)


def map_font(f, sp_spec):
    """Approved families only: display face, Circular Bold, Circular Regular."""
    face, bold_face, body_face = sp_spec["headline"][0], sp_spec["subhead"][0], sp_spec["body"][0]
    if not f or f in ("+mn-lt", "Calibri", "Arial", "Calibri Light"):
        return body_face
    if f == "+mj-lt" or "Playfair" in f or "Chronicle" in f:
        return face
    if f.endswith("Medium") or f.endswith("Bold") or f.endswith("Black"):
        return bold_face
    return body_face if f.startswith("Circular") else body_face


def headline_fits(text, width_emu, pt, face, b, share=1.0):
    M = _B.metrics_for(b)
    ems = _B.width_of(text, face, M) or len(text) * 0.55
    return ems * pt * 12700 <= share * (width_emu - 2 * 91440)


_ROOM = {}


def headline_room(b=None):
    """Width (EMU) a content-slide headline gets: the template's headline box widened to the slide margins, the way
    build_deck lays out chart, table and diagram slides."""
    b = b or _B.current()
    if b.name not in _ROOM:
        from pptx import Presentation
        prs = Presentation(str(b.template))
        sl = prs.slides[b.role("diagram_base", 6) - 1]
        h = next((s for s in sl.shapes if s.has_text_frame and b.is_headline(s._element)), None)
        _ROOM[b.name] = prs.slide_width - 2 * (h.left if h is not None and h.left is not None else 558105)
    return _ROOM[b.name]


SAFE_SHARE = 0.93          # the deck check fails a one-line headline past 95% of its box; metrics vs render differ a little


def fits_headline(text, b=None):
    """True when a headline sets on one line at the standard size with the deck check's safety margin - for tools that
    write their own headlines (a headline at 98% of its box fails the check as too tight)."""
    b = b or _B.current()
    s = spec(b)
    return headline_fits(text, headline_room(b), s["headline"][1], s["headline"][0], b, SAFE_SHARE)


_DESIGNED = {}


def designed_sizes(src, b=None):
    """{role: smallest size (pt)} the template itself gives each role on template slide src (body, subhead, highlight)."""
    b = b or _B.current()
    if (b.name, src) not in _DESIGNED:
        out = {}
        try:
            z = zipfile.ZipFile(b.template)
            import a11y as _A
            part = _A.slide_parts(z)[src - 1]
            tree = etree.fromstring(z.read(part)).find(f".//{P}cSld/{P}spTree")
            for r, role in roles(tree, b, spec(b)):
                rpr = r.find(A + "rPr")
                if rpr is not None and rpr.get("sz"):
                    out[role] = min(out.get(role, 99), int(rpr.get("sz")) / 100)
        except Exception:
            pass
        _DESIGNED[(b.name, src)] = out
    return _DESIGNED[(b.name, src)]


def component_sources(b=None):
    b = b or _B.current()
    out = set((b.get("typography") or {}).get("component_slides") or [])
    return out | _FT.component_sources() if b.get("layouts") else out


def apply(path, sources=None, exempt=(), keep=(), component=()):
    """Set every run to its role's face and size. sources: template source per slide (display slides keep sizes);
    exempt: engine-drawn slide numbers (fonts mapped, sizes kept); keep: template infographic slides - the headline
    gets the standard, every other run keeps the template slide's own size (fonts mapped); component: template
    component slides - like keep, plus body sentences in regular weight and a report when a run had to shrink well
    below the size the template designed for it. Returns problems."""
    b = _B.current()
    sp_spec = spec(b)
    z = zipfile.ZipFile(path)
    items = {n: z.read(n) for n in z.namelist()}
    infos = {n: z.getinfo(n) for n in z.namelist()}
    z.close()
    import a11y as _A
    parts = _A.slide_parts(zipfile.ZipFile(path))
    problems = []
    for i, part in enumerate(parts, 1):
        x = etree.fromstring(items[part])
        tree = x.find(f".//{P}cSld/{P}spTree")
        src = (sources or {}).get(i)
        if i in exempt or src in DISPLAY_SOURCES:
            swap = sp_spec["headline"][0] != b.font("heading")      # display font changed in brand.json (e.g. Chronicle)
            for r in tree.iter(A + "r"):
                f, rpr = run_font(r)
                if not (r.findtext(A + "t") or "").strip():
                    continue
                if f and map_font(f, sp_spec) != f:
                    set_run(r, map_font(f, sp_spec), None, None)
                elif not f and swap:                                 # titles inheriting the template's display face
                    set_run(r, sp_spec["headline"][0], None, None)
        else:
            designed = designed_sizes(src, b) if i in component else {}
            for r, role in roles(tree, b, sp_spec):
                face, size, bold = sp_spec[role]
                f, rpr = run_font(r)
                if i in component and role not in ("headline", "statement"):   # the template's component type scale
                    if f and map_font(f, sp_spec) != f:
                        set_run(r, map_font(f, sp_spec), None, None)
                    old = int(rpr.get("sz")) / 100 if rpr is not None and rpr.get("sz") else None
                    want = designed.get(role)              # (weights come from set_text: leads bold, sentences regular)
                    if old and want and old < max(9, want * 0.8) - 0.1:
                        problems.append(f"slide {i}: '{(r.findtext(A + 't') or '')[:30]}' had to shrink to {old:g} pt - the "
                                        f"template sets it at {want:g} pt: shorten it")
                    continue
                if i in keep and role != "headline":       # the template infographic's own type stays as designed
                    if f and map_font(f, sp_spec) != f:
                        set_run(r, map_font(f, sp_spec), None, None)
                    continue
                old = int(rpr.get("sz")) / 100 if rpr is not None and rpr.get("sz") else None
                if role == "body" and old and old < size - 0.4:
                    problems.append(f"slide {i}: '{(r.findtext(A + 't') or '')[:30]}' had to shrink to {old:g} pt to fit - at "
                                    f"the standard {size} pt it is too long for its box: shorten it")
                set_run(r, face, size, bold)
            for sp in tree.iter(P + "sp"):            # the headline stays on one line at 36 pt
                ext = sp.find(f"{P}spPr/{A}xfrm/{A}ext")
                runs = [r for r in sp.iter(A + "r") if (r.findtext(A + "t") or "").strip()]
                if runs and ext is not None and any((run_font(r)[0] or "") == sp_spec["headline"][0] and
                                                    run_font(r)[1].get("sz") == str(sp_spec["headline"][1] * 100) for r in runs):
                    text = "".join(r.findtext(A + "t") or "" for r in runs)
                    if not headline_fits(text, int(ext.get("cx")), sp_spec["headline"][1], sp_spec["headline"][0], b):
                        problems.append(f"slide {i}: headline '{text[:40]}' does not fit one line at the standard "
                                        f"{sp_spec['headline'][1]} pt - shorten it")
        items[part] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
    # theme fonts are left as the template has them (the structure check compares them); every run that would
    # inherit Calibri gets an explicit standard font above, and charts name Circular explicitly
    import atomic
    with atomic.zip_out(path) as w:
        for n, d in items.items():
            w.writestr(infos[n], d)
    side = Path(str(path) + ".ulta.json")
    try:
        meta = json.loads(side.read_text()) if side.exists() else {}
        meta["typeset"] = {"sources": {str(k): v for k, v in (sources or {}).items()},
                           "exempt": sorted(set(exempt) | set(keep) | set(component)), "component": sorted(set(component))}
        side.write_text(json.dumps(meta))
    except Exception:
        pass
    return sorted(set(problems))


def check(path):
    """FAIL lines for runs off the standard (validate_deck.py): unapproved font families anywhere, wrong sizes on
    content slides."""
    b = _B.current()
    sp_spec = spec(b)
    allowed = {v[0] for v in sp_spec.values()}
    side = Path(str(path) + ".ulta.json")
    meta = json.loads(side.read_text()).get("typeset", {}) if side.exists() else {}
    sources = {int(k): v for k, v in (meta.get("sources") or {}).items()}
    exempt = set(meta.get("exempt") or [])
    import a11y as _A
    z = zipfile.ZipFile(path)
    fails, fam_bad, size_bad = [], {}, {}
    for i, part in enumerate(_A.slide_parts(z), 1):
        tree = etree.fromstring(z.read(part)).find(f".//{P}cSld/{P}spTree")
        for sp, tb, *_ in frames(tree):
            name = (sp.find(f".//{P}cNvPr").get("name") or "") if sp.find(f".//{P}cNvPr") is not None else ""
            text = "".join(t.text or "" for t in tb.iter(A + "t"))
            if is_chrome(text, sp) or re.match(r"Step \d+ number", name):
                continue
            for r in tb.iter(A + "r"):
                if not (r.findtext(A + "t") or "").strip():
                    continue
                f, _ = run_font(r)
                if f and f not in allowed and not f.startswith("+"):
                    fam_bad.setdefault(i, set()).add(f)
        if i in exempt or sources.get(i) in DISPLAY_SOURCES or not meta:
            continue
        for r, role in roles(tree, b, sp_spec):
            face, size, bold = sp_spec[role]
            f, rpr = run_font(r)
            sz = int(rpr.get("sz")) / 100 if rpr is not None and rpr.get("sz") else None
            if sz != size or f != face:
                size_bad.setdefault(i, []).append(f"{role} '{(r.findtext(A + 't') or '')[:20]}' {f or 'inherited'} {sz} pt")
    for i, fs in sorted(fam_bad.items()):
        fails.append(f"slide {i}: font(s) outside the standard: {', '.join(sorted(fs))}")
    for i, xs in sorted(size_bad.items()):
        fails.append(f"slide {i}: {len(xs)} run(s) off the type scale, e.g. {xs[0]}")
    return fails


if __name__ == "__main__":
    p = sys.argv[1]
    if "--check" in sys.argv:
        f = check(p)
        print("\n".join("FAIL  " + x for x in f) or "typography: PASS")
    else:
        for x in apply(p):
            print("FAIL  " + x)
