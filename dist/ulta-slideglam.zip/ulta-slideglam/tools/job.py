"""A long build as a tracked job: one of this skill's own tools, run in this same sandbox, with its progress reported.

    python tools/job.py start <name> --wait 45 -- python tools/build_deck.py build story.json --out /mnt/data/out/Deck.pptx
    python tools/job.py wait <name> [--max 45]

It runs only the skill's own tools (python tools/<tool>.py ...); any other command is refused. `start` returns at
once; with --wait it watches the job as `wait` does, so a build that ends in time prints its output in the same cell
and a longer one can never run into the cell's time limit. `wait` watches for up to --max seconds, then prints DONE
with the exit code and the tool's output, or RUNNING with how long it has been going - call `wait` again in the next
cell until DONE. A job is stopped after 30 minutes (STOPPED). Logs live in /mnt/data/out/.jobs/<name>.log (or
./out/.jobs outside the sandbox).
"""
import argparse, json, os, re, subprocess, sys, time
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
JOBS = (Path("/mnt/data/out") if Path("/mnt/data").exists() else Path.cwd() / "out") / ".jobs"
LIMIT = 1800                                             # seconds a job may run before it is stopped
NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,39}")


def own_tool(cmd):
    """[this Python, the tool, its arguments] when cmd runs one of this skill's tools; None for anything else."""
    if len(cmd) < 2 or not (cmd[0] == sys.executable or re.fullmatch(r"python(3(\.\d+)*)?", Path(cmd[0]).name)):
        return None
    for base in (Path.cwd(), TOOLS.parent):
        p = (base / cmd[1]).resolve()
        if p.parent == TOOLS and p.suffix == ".py" and p.is_file() and p != Path(__file__).resolve():
            return [sys.executable, str(p)] + cmd[2:]
    return None


def note(meta, **kv):
    """Adds kv to the job's record, written whole so `wait` never reads half of it."""
    m = json.loads(meta.read_text()) if meta.exists() else {}
    m.update(kv)
    part = meta.with_suffix(".part")
    part.write_text(json.dumps(m))
    os.replace(part, meta)


def start(name, cmd, quiet=False):
    JOBS.mkdir(parents=True, exist_ok=True)
    meta = JOBS / f"{name}.json"
    if meta.exists():
        m = json.loads(meta.read_text())
        if "exit" not in m and alive(m.get("pid")):
            print(f"BUSY job {name} is still running - job.py wait {name}, do not start it again")   # (the cell shows stdout)
            sys.exit(1)
        meta.unlink()
    note(meta, started=time.time(), cmd=cmd)
    p = subprocess.Popen([sys.executable, str(Path(__file__).resolve()), "run", name, "--", *cmd],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    note(meta, pid=p.pid)
    if not quiet:
        print(f"STARTED {name} (pid {p.pid}) - now run: job.py wait {name}")


def run(name, cmd):
    """The job itself: the tool, its output in the log, its exit code in the record; stopped after LIMIT seconds."""
    with open(JOBS / f"{name}.log", "w") as fh:
        try:
            code = subprocess.run(cmd, stdout=fh, stderr=subprocess.STDOUT, timeout=LIMIT).returncode
        except subprocess.TimeoutExpired:
            code = f"stopped after {LIMIT // 60} minutes"
    note(JOBS / f"{name}.json", exit=code, ended=time.time())


def alive(pid):
    if not pid:
        return False
    try:
        done, _ = os.waitpid(pid, os.WNOHANG)            # reaps it if it is our child
        if done:
            return False
    except ChildProcessError:
        pass
    try:
        os.kill(pid, 0)
        return Path(f"/proc/{pid}/status").exists() and "zombie" not in Path(f"/proc/{pid}/status").read_text()
    except OSError:
        return False


def wait(name, most):
    log, meta = JOBS / f"{name}.log", JOBS / f"{name}.json"
    if not meta.exists():
        sys.exit(f"no job named {name}")
    m, end = json.loads(meta.read_text()), time.time() + most
    while time.time() < end and "exit" not in m and alive(m.get("pid")):
        time.sleep(0.25)
        m = json.loads(meta.read_text())
    out = log.read_text(errors="replace").strip() if log.exists() else ""
    took = f"{m.get('ended', time.time()) - m['started']:.0f}s"
    if isinstance(m.get("exit"), int):
        print(f"DONE {name} in {took} (exit code {m['exit']})")
    elif "exit" in m:
        print(f"STOPPED {name}: {m['exit']} - nothing was finished; make the build smaller (fewer slides or rows) and start it again")
    elif alive(m.get("pid")):
        print(f"RUNNING {name} for {took} - run job.py wait {name} again")
        return
    else:
        print(f"STOPPED {name} after {took}: the job ended without finishing (the sandbox stopped it) - start it again")
    print(out)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for verb in ("start", "run"):
        s = sub.add_parser(verb); s.add_argument("name"); s.add_argument("rest", nargs=argparse.REMAINDER)
        if verb == "start":
            s.add_argument("--wait", type=int, default=0, help="watch the job for up to this many seconds, as wait does")
    w = sub.add_parser("wait"); w.add_argument("name"); w.add_argument("--max", type=int, default=45)
    a = ap.parse_args()
    if not NAME.fullmatch(a.name):
        sys.exit(f"job names are letters, digits, - and _ (at most 40): {a.name!r} is refused")
    if a.cmd == "wait":
        return wait(a.name, a.max)
    rest = a.rest
    if a.cmd == "start" and rest[:1] == ["--wait"] and len(rest) > 1 and rest[1].isdigit():   # --wait after the name
        a.wait, rest = int(rest[1]), rest[2:]
    cmd = own_tool(rest[1:] if rest[:1] == ["--"] else rest)
    if not cmd:
        sys.exit("job.py runs only this skill's own tools: job.py start <name> -- python tools/<tool>.py ... - nothing was started")
    if a.cmd == "run":
        return run(a.name, cmd)
    start(a.name, cmd, quiet=a.wait > 0)
    if a.wait > 0:
        wait(a.name, a.wait)


if __name__ == "__main__":
    main()
