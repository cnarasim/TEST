# Office Open XML schemas

ISO/IEC 29500-4:2016 (transitional) and the Markup Compatibility schema, as published with the standard
(ECMA-376). `tools/ooxml_check.py` validates the parts this skill writes against them, so a file that opens in
LibreOffice or a preview but that PowerPoint or Word would repair or reject is caught before delivery.
