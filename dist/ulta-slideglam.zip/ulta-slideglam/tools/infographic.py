"""Infographics: see the templates, see the themes, or make your own.

    python tools/infographic.py show   [--format onepager|slide|square] [--theme ulta] --out /mnt/data/out/templates.png
        one picture of every template drawn with its sample content, numbered, plus a one-line list
    python tools/infographic.py themes [--template free|status|...] [--format onepager] --out /mnt/data/out/themes.png
        the same template in all seven themes (all on the Ulta palette, different moods)
    python tools/infographic.py ask status [--format onepager] --out /mnt/data/out/preview.png
        the template's picture + its fields as questions, for when the user has not given the facts yet
    python tools/infographic.py blocks
        the blocks for "make your own" and what each one takes
    python tools/infographic.py make spec.json --out /mnt/data/out/<Name> [--frame] [--look light|gradient|flat]
        build from your own blocks (a slide is the slide alone; --frame adds the template's cover and closing): {"title","subtitle","format","theme","blocks":[{"type":"stats","title":..,"items":[..]}]}
        then the same brand, accessibility, sensitive-data and stamp steps as every one-pager
    python tools/infographic.py ways spec.json --out /mnt/data/out/<Name>-ways [--look light|gradient|flat]
        the same content told other ways - its journey as stairs, arrows, a pyramid, a curve, rings, steps or a timeline; its points as
        tiles or around a hub; a house - one 16:9 slide each in one deck, a numbered picture of them all, and each way's spec to make
    python tools/infographic.py make /mnt/data/<Name>.html --out /mnt/data/out/<Name>
        a page the user changed in the browser (Edit, Save): the PowerPoint, PNG, PDF and a fresh page from its words
A template is filled from text with tools/onepager.py (content-template first); "make your own" needs no text format at all.
Pictures (a story told around the team's own screenshots, mock-ups and product photos): a template's picture line
"![caption](/mnt/data/<file>.png)", or a picture block's "src" - a file the user uploaded, never a web address.
"""
import argparse, json, os, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
SCRIPTS = ROOT / "modules" / "ultabranddeliverables" / "scripts"
KIT = SCRIPTS / "kit"
GALLERY = ROOT / "modules" / "ultabranddeliverables" / "references" / "gallery"
SHEETS = GALLERY / "sheets"          # pre-drawn: themes-<format>.png (free-form); template sheets are put together from the
                                     # gallery's own picture of each template (infographic-templates), no rendering
for p in (KIT, KIT / "infographic", KIT / "diagram", TOOLS):
    sys.path.insert(0, str(p))

FORMATS = ("onepager", "slide", "square")
GROUPS = {"status": "Status reports", "process": "Process & product", "knowledge": "Knowledge", "plans": "Plans & decisions",
          "pictures": "Stories with pictures"}
GROUP_Q = {"status": "a weekly or project status report", "process": "a process, product or change notice",
           "knowledge": "a knowledge cheat sheet", "plans": "a plan or decision (charter, decision brief, KPI scorecard, incident review)",
           "pictures": "a story told with your pictures - screenshots, mock-ups or product photos (budget proposal with a UI concept, "
                       "product introduction, status update with screenshots)"}

# "Make your own" blocks (the shelf): what each block is for and the keys of one item.
BLOCKS = [
    ("stats", "Big numbers", "2-4 numbers to remember", ["value", "label"], 4),
    ("steps", "Steps", "a process, in order", ["title", "text"], 6),
    ("timeline", "Timeline", "dates and what happens", ["when", "title", "text"], 7),
    ("list", "Points", "short points, each with a pictogram", ["title", "text"], 9),
    ("bars", "Bar chart", "compare amounts; unit %, $K or a word", ["label", "value"], 8),
    ("donut", "Rings", "1-3 percentages", ["value", "label"], 3),
    ("status", "Status strip", "facts; rag Green/Amber/Red shows On track/At risk/Off track", ["label", "value", "rag"], 5),
    ("compare", "Before & after", "two sides: left/right {title, items}", None, None),
    ("table", "Table", "cols + rows", None, 10),
    ("quote", "Quote", "text + by", None, None),
    ("takeaway", "Message", "the one thing to remember (text)", None, None),
    ("image", "Picture", "one uploaded picture: a UI screen, a mock-up or a photo", None, None),
    ("feature", "Picture & points", "a picture beside its points (a UI concept and what it does)", ["title", "text"], 6),
    ("gallery", "Pictures", "2-4 uploaded pictures side by side, a caption each", ["src", "caption"], 4),
    ("band", "Value band", "2-5 short points in one coloured strip (the value)", ["title"], 5),
    ("flow", "Today & tomorrow", "how the work changes: two lanes of short steps", None, None),
    # v139: other ways to tell a story (stages: "when" is a short label such as "Stage 1" or "Q3")
    ("stairs", "Climbing steps", "a journey that climbs, each stage a step higher", ["when", "title", "text"], 5),
    ("chevrons", "Arrows", "a journey in arrows, each stage pointing to the next", ["when", "title", "text"], 5),
    ("pyramid", "Pyramid", "layers that build up, the first at the base", ["when", "title", "text"], 5),
    ("curve", "Rising curve", "stages as dots on a curve that rises", ["when", "title", "text"], 5),
    ("rings", "Widening rings", "each stage a wider circle around the last", ["when", "title", "text"], 4),
    ("hub", "Hub", "one idea at the centre, its parts around it", ["title", "text"], 8),
    ("house", "House", "a vision on pillars: the roof, a pillar per part, the foundation", ["title", "text"], 6),
    ("cards", "Tiles", "points as cards, each with a pictogram", ["title", "text"], 9),
]
LOOKS = ("light", "gradient", "flat")   # the Ulta theme: a light orange lead (default), a deep orange run, or flat as the printed one-pagers
PICTURE_KEYS = ("src", "caption", "alt", "frame", "fit", "side")   # what a picture block keeps besides its items
BLOCK = {b[0]: b for b in BLOCKS}
MAX_BLOCKS = 8


def kit():
    import info as IG, templates as TP
    return IG, TP


def themes():
    import themes as TH
    return [(k, TH.THEMES[k]["label"], TH.THEMES[k]["note"]) for k in TH.ORDER]


# ------------------------------------------------------------------------------------------------ pictures

def thumb(spec, scale):
    """PNG bytes of the first page of an infographic spec, or None when no SVG renderer is installed."""
    IG, _ = kit()
    import plain                                         # plain punctuation in every picture shown to the user
    d = plain.deep(IG.layout(spec))
    svg = IG.page_svgs(d)[0]
    try:
        return IG._raster().png_bytes(svg, scale, background="#FFFFFF")
    except Exception:
        return None


def sheet(cards, out, cols, title, tw=360):
    """Numbered contact sheet: cards = [(label, png bytes or path)]."""
    from PIL import Image, ImageDraw, ImageFont
    import io
    ims = [Image.open(io.BytesIO(c) if isinstance(c, (bytes, bytearray)) else c).convert("RGB") for _, c in cards]
    ims = [im.resize((tw, int(im.height * tw / im.width))) for im in ims]
    th = max(im.height for im in ims)
    pad, lab, head = 18, 34, 60
    rows = (len(ims) + cols - 1) // cols
    W = cols * (tw + pad) + pad
    H = head + rows * (th + lab + pad) + pad
    sh = Image.new("RGB", (W, H), "#FFF5F3")
    dr = ImageDraw.Draw(sh)

    def font(sz, bold=False):
        for f in (("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"), "Arial.ttf"):
            try:
                return ImageFont.truetype(f, sz)
            except Exception:
                continue
        return ImageFont.load_default()
    dr.rectangle([0, 0, W, 8], fill="#E8275A")
    dr.text((pad, 20), title, fill="#5D0F43", font=font(24, True))
    for k, ((label, _), im) in enumerate(zip(cards, ims)):
        x = pad + (k % cols) * (tw + pad)
        y = head + (k // cols) * (th + lab + pad)
        f16 = font(16, True)
        while len(label) > 8 and dr.textlength(label, font=f16) > tw:     # one line, within its card
            label = label[:-2].rstrip(" —-") + "…"
        dr.text((x, y + 6), label, fill="#404040", font=f16)
        sh.paste(im, (x, y + lab))
        dr.rectangle([x - 1, y + lab - 1, x + tw, y + lab + im.height], outline="#D9D9D9")
    out.parent.mkdir(parents=True, exist_ok=True)
    sh.save(out)                                    # a picture for the chat: optimize would take about 1 s more for 1% fewer bytes
    return out


def static_picture(tid, fmt, idx):
    """The gallery's own picture of a template (Ulta theme): design sheets are put together from these, no renderer needed."""
    d = GALLERY / "infographic-templates"
    for name in (f"{idx:02d}-{tid}-{fmt}.png", f"{idx:02d}-{tid}-{fmt}-1.png"):
        if (d / name).exists():
            return d / name
    return None


def ready_sheet(name, out):
    """Copy a pre-drawn sheet (instant; no renderer needed). Returns the path or None."""
    import shutil
    src = SHEETS / name
    if not src.exists():
        return None
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, out)
    return out


def cmd_start(_a):
    IG, TP = kit()
    cat = TP.catalogue()
    print("ASK the user (one short message): What is the one-pager for?")
    for k, (g, label) in enumerate(GROUP_Q.items(), 1):
        n = sum(1 for c in cat if c.get("group") == GROUPS[g])
        print(f"  {k}. {label[0].upper() + label[1:]} - {n} design{'s' if n > 1 else ''}   (then: infographic.py show --group {g})")
    print(f"  {len(GROUP_Q) + 1}. Something else - make your own from blocks   (then: infographic.py blocks)")
    print("If the request already says which (\"weekly status\"), skip this and show that group's designs.")


def cmd_show(a):
    if a.format == "square":
        print("note: templates come as a one-pager or a slide; square is for free-form and make-your-own - showing one-pagers")
        a.format = "onepager"
    IG, TP = kit()
    full = [c for c in TP.catalogue() if c["id"] != "auto"]
    index = {c["id"]: i for i, c in enumerate(full, 1)}                 # gallery picture numbers
    cat = [c for c in full if not a.group or c.get("group") == GROUPS[a.group]]
    import brand as _B
    own = a.theme == "ulta" and _B.current().name == "ulta"             # the gallery's own picture of each template: no rendering
    cards, missing = [], 0
    for k, c in enumerate(cat, 1):
        tid = c["id"]
        png = static_picture(tid, a.format, index[tid]) if own else None
        if png is None:
            spec = IG.sample_spec(a.format, a.theme) if tid == "free" else TP.sample_spec(tid, a.format, a.theme)
            png = thumb(spec, 0.42 if a.format != "slide" else 0.34) or (static_picture(tid, a.format, index[tid]) if a.theme == "ulta" else None)
        if png is None:
            missing += 1
        else:
            cards.append((f"{k}. {c['name']}", png))
    if not cards:
        print(f"note: pictures need resvg-py; the gallery folder has every template: {GALLERY}")
    else:
        few = len(cards) <= 4
        sheet(cards, Path(a.out), len(cards) if few else (4 if a.format != "slide" else 3),
              (f"{GROUPS[a.group]} - pick a design" if a.group else "Infographic templates")
              + f" ({a.format}, sample content)", tw=440 if few and a.format != "slide" else 360)
    print(f"PICTURE {a.out}  ({len(cat)} design{'s' if len(cat) > 1 else ''})")
    for k, c in enumerate(cat, 1):
        print(f"{k:>2}. {c['id']:<13} {c['name']} - {c.get('blurb', '')}")
    print("Attach the picture and ask which number. Then: infographic.py ask <id> (the questions), build only when answered.")


def cmd_themes(a):
    IG, TP = kit()
    import brand as _B
    if a.template == "free" and _B.current().name == "ulta" and ready_sheet(f"themes-{a.format}.png", a.out):
        print(f"PICTURE {a.out}")
        for k, label, note in themes():
            print(f"  {k:<9} {note}")
        return
    cards = []
    for k, label, note in themes():
        spec = IG.sample_spec(a.format, k) if a.template == "free" else TP.sample_spec(a.template, a.format, k)
        png = thumb(spec, 0.34)
        if png:
            cards.append((label, png))
    if cards:
        out = sheet(cards, Path(a.out), 4, f"Themes - {a.template} {a.format} (all on the Ulta palette)")
        print(f"PICTURE {out}")
    elif a.template == "free" and ready_sheet(f"themes-{a.format}.png", a.out):
        print(f"PICTURE {a.out}")
    else:
        print("note: theme pictures need resvg-py; describe the themes instead:")
    for k, label, note in themes():
        print(f"  {k:<9} {note}")


def cmd_blocks(_a):
    print(f"Make your own: 1 shape ({' / '.join(FORMATS)}), 2 theme ({', '.join(k for k, _, _ in themes())}), "
          f"3 blocks (up to {MAX_BLOCKS}), in order:")
    for k, name, tip, keys, mx in BLOCKS:
        shape = (f"items: [{{{', '.join(keys)}}}] (max {mx})" if keys else
                 {"compare": 'left: {title, items:[..]}, right: {title, items:[..]}',
                  "table": "cols: [..], items: [[..], ..] (max 10 rows)",
                  "quote": "text, by", "takeaway": "text",
                  "image": "src (an uploaded file), caption, frame auto|browser|phone|plain, fit contain|cover",
                  "flow": 'lanes: [{title, tone: before|after, items: ["step", ..]}] (2 lanes, up to 6 steps)'}[k])
        if k == "feature":
            shape = "src, caption, " + shape + ", side left|right"
        elif k == "band":
            shape = "label, " + shape
        elif k == "hub":
            shape = "center (a few words), " + shape
        elif k == "house":
            shape = "roof (the vision), " + shape + ", base (the foundation)"
        print(f"  {k:<9} {name:<14} {tip:<44} {shape}")
    print('spec.json: {"title":"..","subtitle":"..","format":"onepager","theme":"ulta","blocks":[{"type":"stats","title":"..","items":[{"value":"42%","label":".."}]}]}')
    print('A picture is a file the user uploaded ("src": "/mnt/data/screen.png"); the caption also describes it for screen readers.')
    print('Any block: "icon" on an item names its pictogram (else its words pick one); "half": true on two blocks in a row puts them side by side.')
    print('Ulta look: "look": "light" (default: a light orange lead with dark words), "gradient" (deep orange into raspberry, white words) or "flat".')


# ------------------------------------------------------------------------------------------------ ask for the inputs

def content_template(tid):
    import subprocess
    r = subprocess.run([sys.executable, "-I", str(SCRIPTS / "ulta.py"), "content-template", tid], capture_output=True, text=True)
    if r.returncode:
        raise SystemExit(f"no template {tid!r}: see infographic.py show")
    return r.stdout


def short(s, n=70):
    return s if len(s) <= n else s[:n].rsplit(" ", 1)[0] + "…"


def questions(tid):
    """The template's fields as short questions (a form), from its own content template."""
    import re
    md = content_template(tid).splitlines()
    qs, sec, kind, cols, hint, subs, pics = [], None, None, None, "", [], []

    def flush():
        if sec and pics:
            n = len(pics)
            qs.append(f"{sec} - upload {'a picture' if n == 1 else f'{n} pictures'} (a screenshot, mock-up or product photo) with a caption"
                      f"{'' if n == 1 else ' each'}, e.g. \"{short(pics[0])}\"" + (f"; and its points, one per line, e.g. \"{short(hint)}\"" if kind == "list" else ""))
        elif sec:
            if subs:
                qs.append(f"{sec} - {' and '.join(subs)}, a few points each")
            elif kind == "table":
                qs.append(f"{sec} - one per line: {' | '.join(cols)}")
            elif kind == "list":
                qs.append(f"{sec} - one per line, e.g. \"{short(hint)}\"")
            else:
                qs.append(f"{sec} - {('one or two sentences, e.g. ' + chr(34) + short(hint) + chr(34)) if hint else 'a few words'}")
    for l in md:
        if l.startswith("# "):
            qs.append(f"Title - e.g. \"{l[2:].strip()}\"")
        elif l.startswith("## "):
            flush(); sec, kind, cols, hint, subs, pics = l[3:].strip(), "text", None, "", [], []
        elif sec and re.match(r"^!\[([^\]]*)\]\(", l.strip()):
            pics.append(re.match(r"^!\[([^\]]*)\]", l.strip()).group(1) or "what it shows")
        elif l.startswith("### ") and sec:
            subs.append(l[4:].strip())
        elif sec is None and ":" in l and l.strip():
            k, v = l.split(":", 1)
            qs.append(f"{k.strip()} - e.g. {v.strip()}")
        elif sec is None and l.strip():                  # the line under the title
            qs.append(f"In one line, what it is - e.g. \"{short(l.strip())}\"")
        elif sec and l.startswith("|") and not re.match(r"^\|[-| ]+\|$", l):
            if cols is None:
                kind, cols = "table", [c.strip() for c in l.strip("|").split("|")]
        elif sec and re.match(r"^\s*(?:[-*]|\d+\.)\s+", l):
            if kind != "table":
                kind = "list"; hint = hint or re.sub(r"^\s*(?:[-*]|\d+\.)\s+", "", l).strip()
        elif sec and l.strip() and kind == "text":
            hint = hint or l.strip()
    flush()
    return qs


def cmd_ask(a):
    IG, TP = kit()
    cat = [c for c in TP.catalogue() if c["id"] != "auto"]
    idx = next((i for i, c in enumerate(cat, 1) if c["id"] == a.template), None)
    if idx is None:
        sys.exit(f"unknown template {a.template!r}; one of {', '.join(c['id'] for c in cat)}")
    pic = static_picture(a.template, a.format, idx)
    if pic:
        import shutil
        Path(a.out).parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(pic, a.out)
        print(f"PICTURE {a.out}  (what the {cat[idx - 1]['name']} looks like, with sample content)")
    print(f"ASK the user (one message, numbered; they can also paste notes or upload a file instead):")
    for k, q in enumerate(questions(a.template), 1):
        print(f"  {k}. {q}")
    print("Then write their answers into the content template (ulta.py content-template "
          f"{a.template} > c.md, replace EVERY sample line; unknown = \"-\") and run onepager.py. Never build with the sample.")
    if "![" in content_template(a.template):
        print("A picture line takes the file the user uploaded: ![their caption](/mnt/data/<file>.png). No picture for it: remove the line. "
              "Never keep a sample: picture, and never search for, generate or draw a picture yourself.")


# ------------------------------------------------------------------------------------------------ make your own

def normalise(spec):
    """A "make your own" spec -> the kit's free-form spec; rows given as lists are mapped to the block's keys."""
    fmt = spec.get("format") if spec.get("format") in FORMATS else "onepager"
    out = {"title": str(spec.get("title") or "My infographic").strip(), "subtitle": str(spec.get("subtitle") or "").strip(),
           "format": fmt, "theme": spec.get("theme") or "ulta", "template": "free", "blocks": []}
    if spec.get("look") in LOOKS:
        out["look"] = spec["look"]
    for k in ("kicker", "source"):
        if spec.get(k):
            out[k] = spec[k]
    problems = []
    for n, b in enumerate(spec.get("blocks") or [], 1):
        t = b.get("type") or b.get("k")
        if t not in BLOCK:
            problems.append(f"block {n}: unknown type {t!r} - one of {', '.join(BLOCK)}"); continue
        o = {"type": t, "title": str(b.get("title") or "").strip()}
        keys, mx = BLOCK[t][3], BLOCK[t][4]
        if t == "table":
            o["cols"] = [str(c).strip() or "—" for c in b.get("cols") or []]
            o["items"] = [[str(c) for c in r] for r in (b.get("items") or b.get("rows") or []) if any(str(c).strip() for c in r)][:mx]
            o["icons"] = False
            if not o["cols"] or not o["items"]:
                problems.append(f"block {n} (table): needs cols and rows"); continue
        elif t == "compare":
            for side in ("left", "right"):
                s = b.get(side) or {}
                o[side] = {"title": str(s.get("title") or ("Before" if side == "left" else "After")),
                           "items": [str(x) for x in s.get("items") or [] if str(x).strip()]}
            if not (o["left"]["items"] or o["right"]["items"]):
                problems.append(f"block {n} (compare): both sides empty"); continue
        elif t in ("image", "feature"):
            o.update({k: str(b[k]).strip() for k in PICTURE_KEYS if b.get(k) and isinstance(b[k], (str, int, float))})
            if not o.get("src"):
                problems.append(f"block {n} ({t}): no picture - src is a file the user uploaded"); continue
            if t == "feature":
                o["items"] = [{k: str(it.get(k, "")).strip() for k in keys} for it in
                              ([dict(zip(keys, x)) if isinstance(x, (list, tuple)) else x for x in b.get("items") or []])
                              if isinstance(it, dict) and any(str(it.get(k, "")).strip() for k in keys)][:mx]
        elif t == "flow":
            o["lanes"] = []
            for ln in (b.get("lanes") or [])[:2]:
                if not isinstance(ln, dict):
                    continue
                its = [{"title": str(x.get("title") if isinstance(x, dict) else x).strip()} for x in ln.get("items") or []]
                its = [x for x in its if x["title"]][:6]
                if its:
                    o["lanes"].append({"title": str(ln.get("title") or "").strip(), "items": its,
                                       "tone": ln.get("tone") if ln.get("tone") in ("before", "after") else ""})
            if not o["lanes"]:
                problems.append(f"block {n} (flow): no steps - lanes: [{{title, items: [..]}}]"); continue
        elif t in ("quote", "takeaway"):
            o["text"] = str(b.get("text") or "").strip()
            if t == "quote":
                o["by"] = str(b.get("by") or "").strip()
            else:
                o["icon"] = "target"
            if not o["text"]:
                problems.append(f"block {n} ({t}): no text"); continue
        else:
            items = []
            for it in b.get("items") or b.get("rows") or []:
                if isinstance(it, (list, tuple)):
                    it = {k: str(v) for k, v in zip(keys, it)}
                icon = str(it.get("icon") or "").strip()            # a pictogram the item names (the kit keeps it when it has one)
                it = {k: str(it.get(k, "")).strip() for k in keys}
                if any(it.values()):
                    items.append(it | ({"icon": icon} if icon else {}))
            if t in ("bars", "donut"):
                import re
                items = [x for x in items if re.search(r"\d", x.get("value", ""))]
            if t == "bars" and b.get("unit"):
                u = str(b["unit"]).strip()
                if u[:1].isalpha():                       # a word unit goes in the heading ("Sales (stores)"), not glued to the number
                    o["title"] = (o["title"] + f" ({u})").strip()
                else:
                    o["unit"] = u
            if t == "status":
                for it in items:
                    if it.get("rag") and it.get("value"):
                        problems.append(f"block {n} (status): '{it['label']}' has a colour, so it shows the status word, not '{it['value']}'")
            if len(items) > mx:
                problems.append(f"block {n} ({t}): {len(items)} items, kept {mx}")
                items = items[:mx]
            if not items:
                problems.append(f"block {n} ({t}): no items"); continue
            o["items"] = items
            if t == "band":
                o["label"] = str(b.get("label") or o.pop("title", "") or "").strip()
            if t == "hub":
                o["center"] = str(b.get("center") or "").strip()
            if t == "house":
                o.update({k: str(b[k]).strip() for k in ("roof", "base", "icon") if b.get(k)})
            if t == "gallery":
                o.update({k: str(b[k]).strip() for k in ("fit",) if b.get(k)})
        if b.get("half") is True:
            o["half"] = True                                 # shares its row with the next block marked half
        out["blocks"].append(o)
    if len(out["blocks"]) > MAX_BLOCKS:
        problems.append(f"{len(out['blocks'])} blocks: a page holds {MAX_BLOCKS}; the rest were left out")
        out["blocks"] = out["blocks"][:MAX_BLOCKS]
    if isinstance(spec.get("images"), dict) and spec["images"]:
        out["images"] = spec["images"]                   # pictures already inside the content: checked again before use
    return out, problems


def build_files(spec, base, frame=False):
    """The kit's own build from a laid-out spec (as `ulta.py infographic` does after reading text). A 16:9 slide is the slide alone;
    frame adds the template's cover and closing slides (on request: a one-pager is one slide)."""
    IG, _ = kit()
    d = IG.layout(spec)
    files, warnings = [], list(d.get("warnings") or [])
    svgs = IG.page_svgs(d)
    open(base + ".svg", "w", encoding="utf-8").write(svgs[0]); files.append(base + ".svg")
    for i, s in enumerate(svgs[1:], 2):
        open(f"{base}-{i}.svg", "w", encoding="utf-8").write(s)
    try:
        import ulta_conform                          # the page's engine recolours its edits as the files are recoloured
        palette = ulta_conform.page_palette()
    except Exception:
        palette = None
    open(base + ".html", "w", encoding="utf-8").write(IG.to_html(d, spec, palette)); files.append(base + ".html")
    import htmlpdf
    htmlpdf.frame(base + ".html")                        # in the chat's preview frame, say so if saving is blocked
    open(base + "-content.md", "w", encoding="utf-8").write(IG.to_markdown(d))
    if d["spec"]["format"] == "slide":
        import subprocess
        tpl_dir = KIT / "templates"
        man = json.load(open(tpl_dir / "manifest.json"))
        tpl = man.get("default") or "STANDARD33"
        roles = (man["templates"].get(tpl) or {}).get("roles") or {}
        import atomic
        sp = os.path.join(atomic.scratch(), "spec.json")
        json.dump(IG.to_spec(d, tpl, frame, roles.get("two_col", 6), roles.get("cover", 1), roles.get("closing", 32)),
                  open(sp, "w", encoding="utf-8"), ensure_ascii=False)
        r = subprocess.run([sys.executable, str(KIT / "build_from_storyboard.py"), sp, "--templates", str(tpl_dir),
                            "--out", base + ".pptx"], capture_output=True, text=True)
        if not os.path.exists(base + ".pptx"):
            raise SystemExit("slide build failed: " + (r.stdout + r.stderr)[-400:])
    else:
        import build_from_storyboard as B
        warnings += B.info_pptx(d, base + ".pptx") or []
    files.insert(0, base + ".pptx")
    readable = IG.readable_report(d)
    try:
        IG.to_png(svgs[0], base + ".png", 2.0)
        IG.to_pdf_pages(svgs, base + ".pdf", d["spec"]["format"])
    except Exception:
        pass                                           # onepager.finish falls back to LibreOffice and says so
    return files, warnings, 1 + len(d.get("pages") or []), readable


def from_page(path):
    """(spec, drawn design) inside an infographic page the skill made - with the words the user changed in the browser."""
    import re
    m = re.search(r'<script id="data" type="application/json">(.*?)</script>', Path(path).read_text(encoding="utf-8"), re.S)
    try:
        data = json.loads(m.group(1)) if m else {}
        d = data["design"]
    except (ValueError, KeyError, TypeError):
        data, d = {}, None
    if not d or not isinstance(d.get("spec"), dict):
        sys.exit(f"{Path(path).name}: not an infographic page made by this skill (no page data inside)")
    src = data.get("src") if isinstance(data.get("src"), dict) else d["spec"]   # the content as edited in the page (every block, as typed)
    return src, d


def _texts(d):
    return [e.get("t") for pg in [d] + list(d.get("pages") or []) for e in pg.get("els") or []
            if e.get("k") == "text" and str(e.get("t") or "").strip()]


def cmd_make(a):
    import plain                                         # plain punctuation: no em dashes in what a reader sees
    page = a.spec.lower().endswith((".html", ".htm"))
    if page:                                             # its spec is already laid out: rebuilt as it is
        raw, drawn = from_page(a.spec)
        spec, problems = plain.deep(raw), []
        for k, v in (("format", a.format), ("theme", a.theme), ("look", a.look)):
            if v:
                spec[k] = v
    else:
        raw = plain.deep(json.loads(Path(a.spec).read_text(encoding="utf-8")))
        if a.format:
            raw["format"] = a.format
        if a.theme:
            raw["theme"] = a.theme
        if a.look:
            raw["look"] = a.look
        spec, problems = normalise(raw)
    if not spec["blocks"]:
        sys.exit("no usable blocks: " + "; ".join(problems))
    base = str(Path(a.out).with_suffix("")) if a.out.endswith(".pptx") else a.out
    Path(base).parent.mkdir(parents=True, exist_ok=True)
    import pictures                                      # each picture read, checked and drawn again without its metadata
    folder = str(Path(a.spec).resolve().parent)
    problems += ["warning: " + w for w in pictures.vet(spec)]
    pictures.resolve(spec, folder)
    Path(base + "-spec.json").write_text(json.dumps(spec, indent=1, ensure_ascii=False), encoding="utf-8")
    smp = pictures.samples(spec)
    problems += ["warning: " + w for w in pictures.take_in(spec, folder)]
    import io, contextlib
    from ulta_text import cut_problems
    err = io.StringIO()
    with contextlib.redirect_stderr(err):                # the engine reports text it had to cut with '…'
        files, warnings, pages, (n_t, low_t) = build_files(spec, base, a.frame)
    import onepager
    row = pictures.check_row(*pictures.tally(spec), smp)
    hard = [f"warning: hard to read: '{t[:40]}' #{c} on #{u} = {r}:1 (needs {nd}:1)" for t, c, u, r, nd in low_t[:3]]
    line, extra = onepager.finish(Path(base), files, False, f"own infographic ({len(spec['blocks'])} blocks)",
                                  a.classification, a.owner, [("warning: " + plain.text(w)) for w in warnings] + cut_problems(err.getvalue()) + hard,
                                  [row, onepager.text_row(n_t, len(low_t))])
    said = [line + f" | {spec['format']}, {spec['theme']}, {len(spec['blocks'])} blocks, {pages} page(s)"]
    if page:                                             # an edit the page's source could not carry is named, never lost silently
        IG, _ = kit()
        now = set(_texts(IG.layout(spec)))
        lost = [t for t in dict.fromkeys(_texts(drawn)) if t not in now and plain.text(t) not in now]
        problems += [f"warning: only in the edited page, not in the rebuilt files: '{t[:60]}' - make the change again in the new page"
                     for t in lost[:6]]
    said += ["  " + x for x in problems + extra[:12]]
    print("\n".join(said))
    import tokens as TK
    wrote = json.dumps(spec, ensure_ascii=False) if page else Path(a.spec).read_text(encoding="utf-8")
    print(TK.report(base + ".pptx", wrote, "\n".join(said), "own infographic"))
    sys.exit(0 if line.startswith("READY") else 1)


# ------------------------------------------------------------------------------------------------ other ways to tell it (v139)

JOURNEY = ("stairs", "chevrons", "pyramid", "curve", "rings", "steps", "timeline")
POINTS = ("list", "cards", "hub")
WAY_NAMES = {"stairs": "Climbing steps", "chevrons": "Arrows", "pyramid": "Pyramid", "curve": "Rising curve", "rings": "Widening rings",
             "steps": "Numbered steps", "timeline": "Timeline", "cards": "Tiles", "hub": "Hub", "house": "House on pillars"}


def ways(spec):
    """[(label, spec)]: the same content told other ways, nothing added or left out - its journey (2-5 stages) as each journey shape, its
    points as tiles or around a hub, and with points (up to 6) and a message a house: the subtitle its roof, the points its pillars, the
    message its foundation."""
    bl = spec["blocks"]; out = [("As given", spec)]
    j = next((i for i, b in enumerate(bl) if b["type"] in JOURNEY and 2 <= len(b.get("items") or []) <= 5), None)
    p = next((i for i, b in enumerate(bl) if b["type"] in POINTS and 2 <= len(b.get("items") or []) <= 8), None)
    m = next((i for i, b in enumerate(bl) if b["type"] == "takeaway"), None)

    def swap(i, t, extra=None):
        new = [dict(b) for b in bl]; b = dict(new[i], type=t, **(extra or {}))
        if t == "steps":                                 # steps have no label: a stage's "when" leads its name
            b["items"] = [dict(it, title=(it["when"] + ": " if it.get("when") else "") + it.get("title", "")) for it in b["items"]]
        if t in ("pyramid", "rings") and p is not None and abs(p - i) == 1:
            b["half"] = True; new[p] = dict(new[p], half=True)
        new[i] = b
        return dict(spec, blocks=new)
    if j is not None:
        out += [(WAY_NAMES[t], swap(j, t)) for t in JOURNEY if t != bl[j]["type"]]
    if p is not None:
        out += [(WAY_NAMES[t], swap(p, t, {"center": (bl[p].get("title") or spec["title"])[:60]} if t == "hub" else None)) for t in ("cards", "hub")
                if t != bl[p]["type"]]
        if m is not None and len(bl[p]["items"]) <= 6:
            house = {"type": "house", "title": "", "roof": spec.get("subtitle") or "", "base": bl[m]["text"], "items": bl[p]["items"]}
            rest = [dict(b, type="chevrons") if i == j else b for i, b in enumerate(bl) if i not in (p, m)]
            out.append((WAY_NAMES["house"], dict(spec, subtitle="", blocks=rest + [house])))
    return out


def ways_deck(designs, base, title):
    """The ways as one deck: the template's cover, then each way on the template's content slide (native shapes)."""
    import subprocess, atomic
    IG, _ = kit()
    man = json.load(open(KIT / "templates" / "manifest.json")); tpl = man.get("default") or "STANDARD33"
    roles = (man["templates"].get(tpl) or {}).get("roles") or {}
    slides = [{"source": roles.get("cover", 1), "kind": "cover", "fills": {"title": title}, "notes": f"The same content told {len(designs)} ways, one slide each."}]
    for n, (label, d) in enumerate(designs, 1):
        slides.append({"source": roles.get("two_col", 6), "fills": {"title": d["spec"]["title"], "text1": [""], "text2": [""]}, "hide": ["text1", "text2"],
                       "info": d, "info_svg": IG.to_svg(d, chrome=False), "sec": f"Way {n}: {label}",
                       "notes": "\n".join(x for x in (f"Way {n}: {label}.", d["spec"].get("subtitle")) if x)})
    sp = Path(atomic.scratch()) / "ways-deck.json"
    sp.write_text(json.dumps({"template": tpl, "title": title, "slides": slides, "warnings": []}, ensure_ascii=False), encoding="utf-8")
    r = subprocess.run([sys.executable, str(KIT / "build_from_storyboard.py"), str(sp), "--templates", str(KIT / "templates"), "--out", f"{base}.pptx"],
                       capture_output=True, text=True)
    if not Path(f"{base}.pptx").exists():
        raise SystemExit("ways deck failed: " + (r.stdout + r.stderr)[-400:])


def cmd_ways(a):
    """The same content told other ways, one 16:9 slide each in one deck, with a numbered picture of them all (asked for: "a deck with
    all these options"). Each way's spec is saved beside it: `make <out>-<n>.json` builds the one the user picks on its own."""
    import plain, io, contextlib, onepager
    from ulta_text import cut_problems
    raw = plain.deep(json.loads(Path(a.spec).read_text(encoding="utf-8")))
    raw.update({k: v for k, v in (("theme", a.theme), ("look", a.look)) if v})
    spec, problems = normalise(raw)
    if not spec["blocks"]:
        sys.exit("no usable blocks: " + "; ".join(problems))
    base = Path(str(Path(a.out).with_suffix("")) if a.out.endswith(".pptx") else a.out); base.parent.mkdir(parents=True, exist_ok=True)
    IG, _ = kit(); vs = ways(dict(spec, format="slide")); designs, err = [], io.StringIO()
    with contextlib.redirect_stderr(err):
        for n, (label, sp) in enumerate(vs, 1):
            Path(f"{base}-{n}.json").write_text(json.dumps(dict(sp, format=spec["format"]), indent=1, ensure_ascii=False), encoding="utf-8")
            designs.append((label, plain.deep(IG.layout(sp))))
    ways_deck(designs, base, spec["title"])
    try:
        sheet([(f"{n}. {label}", IG._raster().png_bytes(IG.page_svgs(d)[0], 0.4, background="#FFFFFF")) for n, (label, d) in enumerate(designs, 1)],
              Path(f"{base}-ways.png"), 3, f"{spec['title']} - {len(vs)} ways")
        pic = f"PICTURE {base}-ways.png  (every way, numbered as the deck's slides 2-{len(vs) + 1})"
    except Exception:
        pic = "no picture renderer here: the deck's PDF shows the ways"
    line, extra = onepager.finish(base, [f"{base}.pptx"], False, f"infographic ways ({len(vs)} slides)", a.classification, a.owner,
                                  cut_problems(err.getvalue()) + ["note: " + p for p in problems])
    print(line); print(pic)
    for n, (label, _) in enumerate(vs, 1):
        print(f"  {n:>2}. {label:<17} make {base}-{n}.json --out <Name>   (on its own, any format)")
    print("\n".join("  " + x for x in extra[:10]))
    import tokens as TK
    print(TK.report(f"{base}.pptx", Path(a.spec).read_text(encoding="utf-8"), line, "own infographic"))
    sys.exit(0 if line.startswith("READY") else 1)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("start")
    s = sub.add_parser("show"); s.add_argument("--format", default="onepager", choices=FORMATS)
    s.add_argument("--group", choices=list(GROUPS))
    s.add_argument("--theme", default="ulta"); s.add_argument("--out", default="/mnt/data/out/infographic-templates.png")
    t = sub.add_parser("themes"); t.add_argument("--template", default="free"); t.add_argument("--format", default="onepager", choices=FORMATS)
    t.add_argument("--out", default="/mnt/data/out/infographic-themes.png")
    sub.add_parser("blocks")
    q = sub.add_parser("ask"); q.add_argument("template"); q.add_argument("--format", default="onepager", choices=("onepager", "slide"))
    q.add_argument("--out", default="/mnt/data/out/template-preview.png")
    m = sub.add_parser("make"); m.add_argument("spec"); m.add_argument("--out", required=True)
    m.add_argument("--format", choices=FORMATS); m.add_argument("--theme"); m.add_argument("--look", choices=LOOKS)
    m.add_argument("--frame", action="store_true", help="16:9: add the template's cover and closing slides (asked for only)")
    m.add_argument("--classification"); m.add_argument("--owner")
    wy = sub.add_parser("ways"); wy.add_argument("spec"); wy.add_argument("--out", required=True)
    wy.add_argument("--theme"); wy.add_argument("--look", choices=LOOKS); wy.add_argument("--classification"); wy.add_argument("--owner")
    a = ap.parse_args()
    {"start": cmd_start, "show": cmd_show, "themes": cmd_themes, "blocks": cmd_blocks, "make": cmd_make, "ask": cmd_ask, "ways": cmd_ways}[a.cmd](a)


if __name__ == "__main__":
    main()
