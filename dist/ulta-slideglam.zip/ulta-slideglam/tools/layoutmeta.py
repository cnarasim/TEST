"""The build record (<deck>.ulta.json: which slides are diagrams, re-laid-out flows, shortened lists, approved library
slides) kept inside the .pptx too, so a deck that was downloaded and uploaded again is checked the same way.

    save(path)     after a build / edit: sidecar -> custom property "UltaLayout"
    restore(path)  before a check / fix / edit: no sidecar -> rebuilt from the property
"""
import json
from pathlib import Path

import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I
import docprops as DP   # noqa: E402

PROP = "UltaLayout"
KEYS = ("diagram_slides", "flow_slides", "list_slides", "library_slides", "infographic_slides", "drawn_slides",
        "trimmed_slides", "schema_version", "source_mapping", "reference_sha256", "slide_revisions")


def side(path):
    return Path(str(path) + ".ulta.json")


def save(path):
    s = side(path)
    if not s.exists():
        return
    meta = json.loads(s.read_text() or "{}")
    keep = {k: meta[k] for k in KEYS if meta.get(k)}
    DP.write_props(path, custom={PROP: json.dumps(keep, separators=(",", ":"))})


def restore(path):
    s = side(path)
    if s.exists():
        return False
    try:
        raw = DP.read_props(path)[1].get(PROP)
    except Exception:
        return False
    if not raw:
        return False
    s.write_text(raw)
    return True
