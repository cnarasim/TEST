"""Make kit diagram output follow the Ulta template standard.

    python tools/ulta_conform.py Name.pptx [Name.drawio] [Name.svg] [--keep-sizes]   (fixed in place)
    Diagrams: no flag. Infographic one-pagers: --keep-sizes (dense layouts; colour fix only).

- Colours: every colour outside the Ulta palette (brand colour wheel, template tints, neutrals; RAG
  status colours kept) is replaced by the perceptually nearest Ulta colour. Blues/greens go to berry or
  neutral. No generic blues, Office defaults or off-brand tints survive.
- Text: PowerPoint text below 9 pt is raised to 9 pt, the template's smallest body size.
- Titles: the style name the kit appends in --all-styles decks (" - Ulta bands") is removed.
Prints what changed and exits 1 if anything off-standard is left.
"""
import re, sys, zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I

ROOT = Path(__file__).resolve().parent.parent
REF = ROOT / "modules" / "ultabranddeliverables" / "scripts" / "kit" / "templates" / "Ulta Beauty PPT Standard.pptx"
THEME = {"000000", "FFFFFF", "E8275A", "EE6C37", "5D0F43", "E9341C", "FAD3DB", "E4C8DB"}
MIN_SZ = 900
TEXT = (".drawio", ".svg", ".html")         # the text formats fixed and checked; pictures and PDFs are left as they are
STYLE_SUFFIX = re.compile(r"\s+[—-]\s+(Ulta bands|Outline|Pastel|Icon cards|Midnight|Numbered flows|Layer cake|Hub & spoke|"
                          r"Hub &amp; spoke|Chevron pipeline|Bubbles|Sequence|Interface matrix|Zones|Technical shapes|Radial|"
                          r"Fan-out tree|Cloud reference|Cloud)(?=<)")


# The Ulta palette: the brand colour wheel on template slide 3 plus the colours the template's content
# slides actually use (orange/magenta/berry shades, cream and peach tints, neutrals). Office default theme
# colours that only sit in the file's internals (ED7D31, FFC000 gold, A5A5A5, 954F72 ...) are NOT brand.
BRAND = ["E9341C", "E8275A", "DE7445", "5D0F43", "EE6C37", "F26923", "E0531B", "F24C26", "FF7826", "FF893F",
         "C10060", "DB0058"]
TINTS = ["FFF5F3", "FDE1D2", "F9E3DE", "FFE8EE", "FAD3DB", "E4C8DB", "F3EDEB", "F8F5F5", "F2F2F2"]
NEUTRALS = ["000000", "404040", "D9D9D9", "FFFFFF"]
STATUS = ["00B050", "0BA03E", "FFC000", "FF0000"]          # RAG only (template slides 11, 21): kept, never a mapping target


def _slide_colours():
    """Colours the template's own slides use (e.g. E8275B on the big-numbers cards): a slide copied from the template
    must keep them, or the structure check sees a changed slide after every edit."""
    try:
        z = zipfile.ZipFile(REF)
        return sorted({c.upper() for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)
                       for c in re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', z.read(n).decode("utf-8", "ignore"))})
    except Exception:
        return []


def template_palette():
    """The exact Ulta palette - zero deviation (tools/brand_colours.py): the colour wheel on template slide 3, the
    theme colours of both slide masters, the shades / tints / neutrals the template's slides use. No near-twins."""
    try:
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import brand_colours as _BC
        p = _BC.palette()
        return sorted(p["allowed"] - p["status"])
    except Exception:
        return BRAND + TINTS + NEUTRALS


def _rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def _lab(h):
    def lin(c):
        c /= 255
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(v) for v in _rgb(h))
    x, y, z = (r * .4124 + g * .3576 + b * .1805) / .9505, r * .2126 + g * .7152 + b * .0722, (r * .0193 + g * .1192 + b * .9505) / 1.089
    f = lambda t: t ** (1 / 3) if t > 0.008856 else 7.787 * t + 16 / 116
    return 116 * f(y) - 16, 500 * (f(x) - f(y)), 200 * (f(y) - f(z))


class Mapper:
    def __init__(self, keep_template=False):
        """keep_template: also keep the colours the template's own slides carry (a full deck whose slides were copied
        from the template, e.g. slide 9's E8275B); generated drawings use the exact palette only."""
        self.allowed = template_palette()
        self.labs = {c: _lab(c) for c in self.allowed}
        self.keep = set(self.allowed) | set(STATUS) | (set(_slide_colours()) if keep_template else set())
        self.cache, self.changed = {}, {}

    def __call__(self, h):
        h = h.upper()
        if h in self.keep:
            return h
        if h not in self.cache:
            L = _lab(h)
            r, g, b = _rgb(h)
            pool = self.labs
            sat = max(r, g, b) - min(r, g, b)
            light = min(r, g, b) > 200
            if sat >= 40 and g > r and g >= b and not light:          # RAG green stays a status green
                self.cache[h] = "00B050"; self.changed[h] = "00B050"; return "00B050"
            if sat >= 60 and r > 200 and 140 <= g <= 215 and b < 120 and not light:   # RAG amber
                self.cache[h] = "FFC000"; self.changed[h] = "FFC000"; return "FFC000"
            if sat >= 25 and (b > r or g > r):   # other off-brand hue (e.g. cloud blue): berry or neutral
                pool = {c: v for c, v in self.labs.items() if c in ("5D0F43", "E8275A", "000000", "404040", "FFFFFF", "F8F5F5")}
            self.cache[h] = min(pool, key=lambda c: sum((a - b) ** 2 for a, b in zip(pool[c], L)))
        self.changed[h] = self.cache[h]
        return self.cache[h]

    def deco(self, h):
        """A decorative colour (a gradient stop): the nearest palette colour, never a status colour - status colours
        mark status only, so a gold or green in a gradient never becomes RAG amber or green."""
        h = h.upper()
        if h in self.keep and h not in STATUS:
            return h
        L = _lab(h)
        r, g, b = _rgb(h)
        pool = {c: v for c, v in self.labs.items() if c not in STATUS}
        if max(r, g, b) - min(r, g, b) >= 25 and (b > r or g > r):    # an off-brand hue: berry or neutral
            pool = {c: v for c, v in pool.items() if c in ("5D0F43", "E8275A", "000000", "404040", "FFFFFF", "F8F5F5")}
        c = min(pool, key=lambda k: sum((a - b_) ** 2 for a, b_ in zip(pool[k], L)))
        if c != h:
            self.changed[h] = c
        return c

    def text(self, h):
        """A text colour: the nearest palette colour, never a status colour (the template: never red / green font)."""
        h = h.upper()
        if h in self.keep and h not in STATUS:
            return h
        L = _lab(h)
        c = min(self.labs, key=lambda k: sum((a - b) ** 2 for a, b in zip(self.labs[k], L)))
        if c != h:
            self.changed[h] = c
        return c


def fix_pptx(path, m, keep_sizes=False):
    z = zipfile.ZipFile(path)
    items = {n: z.read(n) for n in z.namelist()}
    infos = {n: z.getinfo(n) for n in z.namelist()}
    raised = titles = 0
    for n in list(items):
        if n.startswith("ppt/charts/chart") and n.endswith(".xml"):         # chart fills and lines: colour only
            items[n] = re.sub(r'srgbClr val="([0-9A-Fa-f]{6})"', lambda mo: f'srgbClr val="{m(mo.group(1))}"',
                              items[n].decode("utf8")).encode("utf8")
            continue
        if not (n.startswith("ppt/slides/slide") and n.endswith(".xml")):
            continue
        x = items[n].decode("utf8")
        def runfix(mo):                                   # text runs (not status dots): never a status colour
            body = mo.group(0)
            if re.search(r"<a:t>\s*[●■▲▼◆•]\s*</a:t>", x[mo.end():mo.end() + 200]):
                return body
            return re.sub(r'srgbClr val="([0-9A-Fa-f]{6})"', lambda mm: f'srgbClr val="{m.text(mm.group(1))}"', body)
        x = re.sub(r"<a:rPr\b[^>]*>.*?</a:rPr>", runfix, x, flags=re.S)
        x = re.sub(r"<a:gsLst>.*?</a:gsLst>", lambda mo: re.sub(r'srgbClr val="([0-9A-Fa-f]{6})"',   # gradients: decoration
                   lambda mm: f'srgbClr val="{m.deco(mm.group(1))}"', mo.group(0)), x, flags=re.S)
        x = re.sub(r'srgbClr val="([0-9A-Fa-f]{6})"', lambda mo: f'srgbClr val="{m(mo.group(1))}"', x)
        def up(mo):
            nonlocal raised
            v = int(mo.group(1))
            if v < MIN_SZ and not keep_sizes:
                raised += 1
                return f' sz="{MIN_SZ}"'
            return mo.group(0)
        x = re.sub(r'\ssz="(\d+)"', up, x)
        x, k = STYLE_SUFFIX.subn("", x)
        titles += k
        items[n] = x.encode("utf8")
    import atomic
    with atomic.zip_out(path) as w:
        for n, d in items.items():
            w.writestr(infos[n], d)
    return raised, titles


NAMED = {"red": "FF0000", "green": "008000", "blue": "0000FF", "orange": "FFA500", "yellow": "FFFF00", "purple": "800080",
         "pink": "FFC0CB", "navy": "000080", "teal": "008080", "gray": "808080", "grey": "808080", "silver": "C0C0C0",
         "gold": "FFD700", "crimson": "DC143C", "tomato": "FF6347", "coral": "FF7F50", "salmon": "FA8072",
         "lightgray": "D3D3D3", "lightgrey": "D3D3D3", "darkgray": "A9A9A9", "darkgrey": "A9A9A9", "whitesmoke": "F5F5F5",
         "gainsboro": "DCDCDC", "dimgray": "696969", "dimgrey": "696969", "magenta": "FF00FF", "cyan": "00FFFF"}


def page_palette():
    """The colour rules a page's own engine applies after every edit (kit/editor/engine-core.js Conform), as this tool applies them
    to the files: the palette, the colours kept as they are, the status colours, named CSS colours and - another brand active -
    each palette colour's colour in that brand."""
    m = Mapper()
    out = {"allowed": list(m.labs), "keep": sorted(m.keep), "status": list(STATUS), "named": dict(NAMED), "recolour": None}
    try:
        import brand as _B
        if _B.active_name() != _B.SOURCE:
            cmap = _B.ColourMap(_B.Brand(_B.SOURCE), _B.Brand(_B.active_name()))
            out["recolour"] = {c: cmap(c) for c in out["keep"]}
    except Exception:
        pass                               # the Ulta palette alone
    return out


def fix_text(path, m):
    """Every colour literal in SVG / HTML / draw.io / CSS text: #RRGGBB, #RGB, rgb(a)(), JSON-quoted hex (the kit's
    embedded page spec) and named CSS colours in colour properties."""
    s = Path(path).read_text(encoding="utf8")
    # text colours first (CSS color:, SVG <text fill>, the kit spec's "color"): never a status colour
    s = re.sub(r"((?<![\w-])color\s*:\s*)#([0-9A-Fa-f]{6})\b", lambda mo: mo.group(1) + "#" + m.text(mo.group(2)), s)
    s = re.sub(r"(<text\b[^>]*\bfill=\")#([0-9A-Fa-f]{6})", lambda mo: mo.group(1) + "#" + m.text(mo.group(2)), s)
    s = re.sub(r'("color"\s*:\s*")([0-9A-Fa-f]{6})(")', lambda mo: mo.group(1) + m.text(mo.group(2)) + mo.group(3), s)
    # gradients are decoration (CSS *-gradient(), SVG <stop stop-color>): never a status colour
    s = re.sub(r"(?i)(?:linear|radial|conic)-gradient\([^;{}]*?\)(?=\s*[;,\"'}]|\s*$)", lambda mo: re.sub(
        r"#([0-9A-Fa-f]{6})\b", lambda mm: "#" + m.deco(mm.group(1)), mo.group(0)), s)
    s = re.sub(r"(?i)(stop-color\s*[:=]\s*[\"']?)#([0-9A-Fa-f]{6})\b", lambda mo: mo.group(1) + "#" + m.deco(mo.group(2)), s)
    s = re.sub(r"#([0-9A-Fa-f]{6})\b", lambda mo: "#" + m(mo.group(1)), s)
    s = re.sub(r"#([0-9A-Fa-f]{3})\b(?![0-9A-Fa-f])", lambda mo: "#" + m("".join(c * 2 for c in mo.group(1))), s)
    s = re.sub(r"(?i)rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)",
               lambda mo: "#" + m("%02X%02X%02X" % tuple(int(v) for v in mo.groups())), s)
    def rgba(mo):
        c = m("%02X%02X%02X" % tuple(int(v) for v in mo.groups()[:3]))
        return "rgba(%d,%d,%d,%s)" % (int(c[:2], 16), int(c[2:4], 16), int(c[4:], 16), mo.group(4))
    s = re.sub(r"(?i)rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)", rgba, s)
    s = re.sub(r'("(?:[a-z_]*(?:colou?r|fill|stroke|ink|accent|line|bg|tint|band|edge|text)[a-z_]*)"\s*:\s*")([0-9A-Fa-f]{6})(")',
               lambda mo: mo.group(1) + m(mo.group(2)) + mo.group(3), s, flags=re.I)
    code = [mo.span(2) for mo in re.finditer(r"<script\b([^>]*)>(.*?)</script>", s, re.S | re.I)
            if (re.findall(r"\btype\s*=\s*[\"']?([^\"'\s>]+)", mo.group(1), re.I) or ["module"])[0].lower()
            in ("module", "text/javascript", "application/javascript")]

    def named(mo):
        h = NAMED.get(mo.group(3).lower())
        if not h or (not mo.group(2) and any(a <= mo.start(3) < b for a, b in code)):
            return mo.group(0)             # in a page's script a bare name is a variable ({fill: GOLD}), not a colour
        return mo.group(1) + mo.group(2) + "#" + m(h)
    s = re.sub(r"(?i)((?:^|[;{\s\"'])(?:color|fill|stroke|background(?:-color)?|border(?:-[a-z]+)?-color|stop-color)\s*[:=]\s*)"
               r"([\"']?)([a-z]+)\b", named, s)
    Path(path).write_text(s, encoding="utf8")


def check(paths, m):
    left = set()
    for p in paths:
        if p.suffix == ".pptx":
            z = zipfile.ZipFile(p)
            for n in z.namelist():
                if (n.startswith("ppt/slides/slide") or n.startswith("ppt/charts/chart")) and n.endswith(".xml"):
                    left.update(c.upper() for c in re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', z.read(n).decode()))
        elif p.suffix in TEXT:
            left.update(c.upper() for c in re.findall(r"#([0-9A-Fa-f]{6})\b", p.read_text(encoding="utf8")))
    return sorted(c for c in left if c not in m.keep)


def main():
    keep = "--keep-sizes" in sys.argv
    paths = [Path(a) for a in sys.argv[1:] if not a.startswith("--")]
    if not paths:
        sys.exit(__doc__)
    m = Mapper(keep_template="--keep-template" in sys.argv)
    raised = titles = 0
    for p in paths:
        if p.suffix == ".pptx":
            r, t = fix_pptx(p, m, keep); raised += r; titles += t
        elif p.suffix in TEXT:
            fix_text(p, m)
    left = check(paths, m)
    print(f"ulta_conform: {len(m.changed)} off-palette colour(s) mapped to template colours, "
          f"{raised} text run(s) raised to 9 pt, {titles} style suffix(es) removed from titles")
    for a, b in sorted(m.changed.items()):
        print(f"  #{a} -> #{b}")
    try:                                   # the brand template's Purview sensitivity label travels with kit output
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import brand as _B0, compliance as _C0
        import sections as _S0
        for p in paths:
            if p.suffix == ".pptx":
                _S0.normalize(p)               # kit files carry the template's sample sections
                lab = _C0.inherit_label(p, _B0.current().template)
                if lab:
                    print(f"sensitivity label '{lab}' inherited from the brand template")
    except Exception as e:                 # never block the colour fix on label metadata
        print(f"sensitivity label: not inherited ({e})")
    try:                                   # active brand is not Ulta: move the result onto that brand's template
        sys.path.insert(0, str(Path(__file__).resolve().parent))
        import brand as _B, rebrand as _R
        if _B.active_name() != _B.SOURCE and "--no-rebrand" not in sys.argv:
            n, notes = _R.rebrand([str(p) for p in paths])
            print(f"rebrand: {n} colour(s) mapped to brand '{_B.active_name()}' (template, theme, fonts, logo)")
            for x in notes:
                print("  " + x)
            probs = _R.audit([str(p) for p in paths])
            for f, m in probs:
                print(f"  brand check: {f}: {m}")
            print("BRAND CHECK: " + ("PASS" if not probs else f"FAIL ({len(probs)})"))
            if probs:
                left = left or ["brand check"]
    except SystemExit as e:
        print(f"rebrand: FAILED - {e}"); left = left or ["rebrand"]
    print("RESULT: " + ("PASS - only template colours remain" if not left else f"FAIL - still off-palette: {left}"))
    sys.exit(1 if left else 0)


if __name__ == "__main__":
    try:
        main()
    except Exception as e:                 # callers read the printed lines: a check that stopped is never a pass
        print(f"RESULT: FAIL - the brand check stopped: {type(e).__name__}: {e}")
        sys.exit(1)
