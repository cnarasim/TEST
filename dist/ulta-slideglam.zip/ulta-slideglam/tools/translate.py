"""Translate a finished deck without rebuilding it: text goes into the existing shapes, autofit re-fits it.

    python tools/translate.py prepare Deck.pptx --lang es        -> Deck-es.json  {"<slot id>": "current text", ...}
    (replace each value with its translation; keep numbers, names, product names and codes as they are)
    python tools/translate.py apply Deck.pptx Deck-es.json --lang es   -> Deck-es.pptx, re-fitted, checked, stamped
Translated text is often 20-30% longer: autofit shrinks it within the template's floors and lists anything that would
need shortening. Proofing language is set on every translated run so PowerPoint spell-checks it in the new language.
"""
import argparse, json, sys, zipfile
from pathlib import Path

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import edit_deck   # noqa: E402

LANGS = {"es": "es-ES", "fr": "fr-FR", "de": "de-DE", "pt": "pt-BR", "it": "it-IT", "nl": "nl-NL", "ja": "ja-JP",
         "zh": "zh-CN", "ko": "ko-KR", "hi": "hi-IN", "en": "en-US", "pl": "pl-PL", "sv": "sv-SE"}
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"


def prepare(deck, lang):
    out = Path(deck).with_name(Path(deck).stem + f"-{lang}.json")
    out.write_text(json.dumps(edit_deck.texts(Path(deck)), ensure_ascii=False, indent=0))
    return out


def set_lang(path, code):
    z = zipfile.ZipFile(path)
    items = {n: z.read(n) for n in z.namelist()}; infos = {n: z.getinfo(n) for n in z.namelist()}
    z.close()
    for n in items:
        if n.startswith("ppt/slides/slide") and n.endswith(".xml"):
            x = etree.fromstring(items[n])
            for tag in ("rPr", "endParaRPr"):
                for r in x.iter(A + tag):
                    r.set("lang", code)
            items[n] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
    import atomic
    with atomic.zip_out(path) as w:
        for n, d in items.items():
            w.writestr(infos[n], d)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("prepare"); p.add_argument("deck"); p.add_argument("--lang", required=True)
    q = sub.add_parser("apply"); q.add_argument("deck"); q.add_argument("texts"); q.add_argument("--lang", required=True)
    a = ap.parse_args()
    if a.cmd == "prepare":
        print(f"TEXTS {prepare(a.deck, a.lang)}: replace each value with its translation, then run translate.py apply")
        return
    deck = Path(a.deck)
    out = deck.with_name(deck.stem + f"-{a.lang}.pptx")        # written only when translated and checked
    code = edit_deck.apply(deck, [], out, action=f"translated to {a.lang}",
                           text=json.loads(Path(a.texts).read_text()),
                           before_check=lambda p: set_lang(p, LANGS.get(a.lang, a.lang)))
    sys.exit(code)


if __name__ == "__main__":
    main()
