"""Owner-approved headline exception: full-width, one-line headlines.

    python tools/fit_headlines.py <deck.pptx> --mapping 1,2,12,... [--out fixed.pptx]

For every slide whose source template slide has a headline placeholder ("Insert headline"):
  1. widen the headline box to the full content width (same left edge, symmetric right margin),
  2. measure with the bundled Circular/Playfair metrics (ulta_pptx_fit.py),
  3. if it still needs 2+ lines, step the headline font down 36 -> 34 -> 32 -> 30 -> 28 pt,
  4. anything still over one line at 28 pt is reported: SHORTEN THE WORDING (exit 1).
Only the headline box changes. Everything else stays under the strict template contract.
The cover (slide 1), agenda and divider slides are not touched.
"""
import argparse, json, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path
from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

ROOT = Path(__file__).resolve().parent.parent
FIT = ROOT / "tools" / "fit_runner.py"
sys.path.insert(0, str(ROOT / "tools"))
import brand as _B   # noqa: E402
REF = _B.current().template
BRAND = _B.current()
NS = {"p": "http://schemas.openxmlformats.org/presentationml/2006/main",
      "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
SIZES = [3600, 3400, 3200, 3000, 2800]          # template size first; 28 pt is the floor
MIN_SZ = SIZES[-1]
MAX_FILL = 0.95                                  # keep 5% slack: real kerning/renderers vary


def slide_parts(z):
    pres = etree.fromstring(z.read("ppt/presentation.xml"))
    rels = etree.fromstring(z.read("ppt/_rels/presentation.xml.rels"))
    tgt = {r.get("Id"): r.get("Target") for r in rels}
    cx = int(pres.find("p:sldSz", NS).get("cx"))
    parts = []
    for s in pres.find("p:sldIdLst", NS):
        t = tgt[s.get("{%s}id" % NS["r"])]
        parts.append(t.lstrip("/") if t.startswith("/") else "ppt/" + t)
    return parts, cx


def text_of(el):
    return "".join(t.text or "" for t in el.iter("{%s}t" % NS["a"]))


def headline_index(ref_slide):
    """spTree child index (= fit-report region key) and cNvPr name of the template headline."""
    for k, sp in enumerate(ref_slide.find(".//p:cSld/p:spTree", NS)):
        if BRAND.is_headline(sp):
            nv = sp.find(".//p:cNvPr", NS)
            return k, (nv.get("name") if nv is not None else None)
    return None, None


def headline_shapes(deck, mapping):
    """[(slide_no, part, name)] for candidate slides whose source slide carries a headline."""
    z, rz = zipfile.ZipFile(deck), zipfile.ZipFile(REF)
    parts, _ = slide_parts(z)
    rparts, _ = slide_parts(rz)
    out = []
    for i, (part, src) in enumerate(zip(parts, mapping), 1):
        _, name = headline_index(etree.fromstring(rz.read(rparts[src - 1])))
        if name:
            out.append((i, part, name))
    return out


def find_shape(slide, name):
    for k, sp in enumerate(slide.find(".//p:cSld/p:spTree", NS)):
        nv = sp.find(".//p:cNvPr", NS)
        if nv is not None and nv.get("name") == name and text_of(sp).strip():
            return k, sp
    return None, None


def rewrite(deck, out, edits):
    """edits: {slide_no: {name: size_or_None}}. Widen each listed headline to the content width
    (inherited layout geometry is materialised first) and set its size when given."""
    from pptx import Presentation
    from pptx.util import Emu
    prs = Presentation(str(deck))
    W = prs.slide_width
    for i, slide in enumerate(prs.slides, 1):
        for name, size in edits.get(i, {}).items():
            sh = next((x for x in slide.shapes if x.name == name and x.has_text_frame
                       and x.text_frame.text.strip()), None)
            if sh is None:
                continue
            l, t, w, h = sh.left, sh.top, sh.width, sh.height      # inherited values when no xfrm
            sh.left, sh.top, sh.height = Emu(l), Emu(t), Emu(h)
            sh.width = Emu(max(w, W - 2 * l))
            if size:
                for para in sh.text_frame.paragraphs:
                    for r in para.runs:
                        r.font.size = Emu(size * 127)               # sz is 1/100 pt; 1 pt = 12700 EMU
    import atomic
    atomic.save(prs, out)


def widen_layouts(deck):
    """The deck's own layouts get the full-width headline its content slides already carry, so PowerPoint's Reset,
    re-applying the layout, a new slide made from the layout or a slide added by code keep the one-line headline
    (the template's layout box is 5.8 in: a 34-character headline would wrap into the content). A slide that uses
    such a layout without its own headline size first gets the size it shows now written onto it, so nothing on
    screen moves. Returns the number of layouts widened."""
    from pptx import Presentation
    from pptx.util import Emu
    prs = Presentation(str(deck))
    W, tol = prs.slide_width, Emu(int(0.05 * 914400))
    xfrm = "{%s}spPr/{%s}xfrm" % (NS["p"], NS["a"])
    wide = {}                                        # layout part -> {placeholder idx: layout placeholder}
    for slide in prs.slides:
        for sh in slide.shapes:
            if not (sh.is_placeholder and sh.has_text_frame and sh._element.find(xfrm) is not None):
                continue
            try:
                lp = slide.slide_layout.placeholders.get(idx=sh.placeholder_format.idx)
            except Exception:
                lp = None
            if lp is None or None in (lp.left, lp.top, lp.width, lp.height) or lp.top > Emu(914400):
                continue
            room = W - 2 * lp.left
            if lp.width < 0.6 * room and sh.width >= 0.9 * room and abs(sh.left - lp.left) <= tol and abs(sh.top - lp.top) <= tol:
                wide.setdefault(slide.slide_layout.part, {})[sh.placeholder_format.idx] = lp
    if not wide:
        return 0
    for slide in prs.slides:                         # keep what every other slide on these layouts shows today
        for idx in wide.get(slide.slide_layout.part, {}):
            sh = next((x for x in slide.placeholders if x.placeholder_format.idx == idx), None)
            if sh is not None and sh._element.find(xfrm) is None:
                l, t, w, h = sh.left, sh.top, sh.width, sh.height
                sh.left, sh.top, sh.width, sh.height = Emu(l), Emu(t), Emu(w), Emu(h)
    for phs in wide.values():
        for lp in phs.values():
            l, t, h = lp.left, lp.top, lp.height
            lp.left, lp.top, lp.height = Emu(l), Emu(t), Emu(h)
            lp.width = Emu(W - 2 * l)
    import atomic
    atomic.save(prs, deck)
    return sum(len(v) for v in wide.values())


def measure(deck, mapping, shapes):
    """{slide_no: lineCount} for the headline regions, from the bundled metrics."""
    with tempfile.TemporaryDirectory() as d:
        rep = Path(d) / "fit.json"
        subprocess.run([sys.executable, str(FIT), str(REF), str(deck), "--mapping",
                        ",".join(map(str, mapping)), "--report", str(rep)], capture_output=True, cwd=FIT.parent.parent)
        data = json.loads(rep.read_text())
    z = zipfile.ZipFile(deck)
    parts, _ = slide_parts(z)                     # re-read: python-pptx renumbers parts on save
    out = {}
    for i, _part, name in shapes:
        k, sp = find_shape(etree.fromstring(z.read(parts[i - 1])), name)
        txt = text_of(sp).strip() if sp is not None else ""
        regs = data["slides"][i - 1]["regions"]
        hit = next((r for r in regs if txt and r.get("text", "").strip() == txt), None)
        if hit is not None:
            n = hit.get("lineCount") or 1
            widest = max((ln["rect"][2] for ln in hit.get("lines") or []), default=0)
            if n == 1 and widest > MAX_FILL * (hit.get("innerWidthPt") or 1):
                n = 1.5                                  # fits, but too tight: treat as over
            out[i] = (n, txt)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck")
    ap.add_argument("--mapping", required=True)
    ap.add_argument("--out")
    a = ap.parse_args()
    mapping = [int(m) for m in a.mapping.split(",")]
    src = Path(a.deck).resolve()
    out = Path(a.out).resolve() if a.out else src.with_name(src.stem + "-headlines.pptx")
    shapes = [s for s in headline_shapes(src, mapping) if mapping[s[0] - 1] != 1]
    sizes = {i: None for i, _, _ in shapes}                    # None = keep template size
    import atomic
    work = atomic.scratch() / "work.pptx"
    for step, sz in enumerate(SIZES):
        edits = {}
        for i, part, name in shapes:
            edits.setdefault(i, {})[name] = sizes[i]
        rewrite(src, work, edits)
        lines = measure(work, mapping, shapes)
        over = [i for i, (n, _) in lines.items() if n > 1]
        if not over or step == len(SIZES) - 1:
            break
        for i in over:
            sizes[i] = SIZES[step + 1]
    shutil.copyfile(work, out)
    bad = 0
    print(f"{'slide':>5}  {'size':>6}  lines  headline")
    for i, (n, txt) in sorted(lines.items()):
        sz = (sizes[i] or 3600) / 100
        flag = "" if n == 1 else ("  <- fills >95% of the width at 28 pt: shorten the wording" if n == 1.5 else "  <- STILL WRAPS at 28 pt: shorten the wording")
        bad += n > 1
        print(f"{i:>5}  {sz:>5.0f}pt  {('1*' if n == 1.5 else str(int(n))):>5}  {txt[:70]}{flag}")
    print(f"\nwrote {out}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
