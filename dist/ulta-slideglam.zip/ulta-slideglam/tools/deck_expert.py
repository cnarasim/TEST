"""Expert review of a storyboard: the story, the right picture for each slide, the context a reader needs.

    python tools/deck_expert.py storyboard.json [--source brief.docx|.pdf|.pptx|.md|.txt]

What a presentation expert looks at before a deck goes out, read from the storyboard. build_deck.py prints it after
every build as one EXPERT REVIEW line and up to eight EXPERT lines; it never blocks a build and never changes a slide.
  Story    the answer up front (an At a glance slide or the headline numbers right after the agenda); the ask at the
           end of a deck that needs a decision (an action table, a decision bar); chapters in a long deck; no run of
           three text slides
  Retail   a supply chain or a retail process shown another way (points, a plain flow): its retail diagram first - a
           supply chain network, a DC flow, a document flow, the fulfilment paths, a process flow with its pictograms
           or a retail starter (tools/retail.py fit; the build sets the slides whose items fit as they are)
  Picture  a text slide (tiles, cards, columns, a table, text boxes) whose content has a better picture: figures ->
           big numbers or a chart; dates -> a timeline; steps -> a flow; shares of a whole -> a donut; before and
           after -> big numbers with a context line or a dumbbell; risks with mitigations -> the risk table (10);
           owners with dates -> the action table (12); systems with flows -> a diagram
  Context  slides whose figures carry no takeaway line ("summary"); notes asking for a decision the slide does not
           show ("decision")
  Ways     how many ways of telling the story the deck uses (storyline.py); a better picture is never the way a slide
           beside it already tells its story
  Source   with --source (or "source_doc" in the storyboard): the figures of the source document that reached the
           slides, only the speaker notes, or nothing
Each EXPERT line names the slide, what it sees and the storyboard shape that shows it better.
"""
import json, re, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))

UNIT = r"(?:%|pts?\b|points?\b|bps\b|x\b|bn\b|billion\b|million\b|thousand\b|[KMB]\b|days?\b|weeks?\b|hours?\b|hrs?\b)"
FIG = re.compile(r"(?<![\w.$])(?:[$€£] ?\d[\d,]*(?:\.\d+)?(?: ?(?:[KMB]\b|bn\b|million\b|billion\b))?|[+-]?\d[\d,]*(?:\.\d+)? ?"
                 + UNIT + ")", re.I)
MONTH = r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?"
DATED = re.compile(rf"(?i)\b{MONTH} (?:\d{{1,2}},? )?(?:20\d\d|'\d\d)\b|\b{MONTH} \d{{1,2}}\b|\bq[1-4] ?(?:fy)?'?(?:20)?\d\d\b|"
                   r"\b(?:fy|h[12]) ?'?(?:20)?\d\d\b|\b20\d\d-\d\d(?:-\d\d)?\b|\b20\d\d\b")
FROMTO = re.compile(r"(?i)([$€£]?\d[\d,.]*\s?" + UNIT + r"?)\s+(?:to|→|->)\s+([$€£]?\d[\d,.]*\s?" + UNIT + "?)")
RANGE = re.compile(r"(?<![\w.-])(\d{1,3}(?:\.\d+)?)\s?[-\u2013]\s?(\d{1,3}(?:\.\d+)?\s?" + UNIT + ")")   # "7-9 pts"
RISKY = re.compile(r"(?i)\brisks?\b|\bmitigat|\bthreats?\b")
OWNERS = re.compile(r"(?i)\b(?:leads?|owners?|teams?|managers?|directors?|steering|committee|board|sponsors?|pmo|ops|vp|"
                    r"cfo|cio|cto|ceo)\b")
ARROW = re.compile(r"\s(?:→|->|⇒)\s")
SEQ_HEAD = re.compile(r"(?i)\b(?:steps?|process|journey|pipeline|phases?|stages?|waves?|life ?cycle|how .+ works|cycle)\b")
SEQ_ITEM = re.compile(r"(?i)^(?:step|phase|stage|wave|sprint|week|month|day|q[1-4]|\d{1,2}[.):])\b|^(?:first|then|next|finally)\b")
DECIDE = re.compile(r"(?i)\b(?:decide|decision|approve|approval|sign[- ]?off|endorse|funding|green[- ]?light)\b")
NEXT = re.compile(r"(?i)\b(?:next steps?|decisions?|the ask|asks?|approve|actions?|recommend\w*|way forward)\b")
OPENER = re.compile(r"(?i)^(?:at a glance|executive summary|summary|in brief|the deck in brief|key messages|overview)\b")
SENIOR = re.compile(r"(?i)\b(?:steering|leadership|executive|board|exec|c-suite|senior)\b")
VISUAL_KEYS = ("chart", "modern", "diagram", "graphic", "picture", "timeline", "swimlane", "process", "retail", "library",
               "donut", "results", "quad", "journey", "scorecard", "map", "priorities", "ogsm", "funnel")
NUMBER_SOURCES = (9, 13, 49)
DESIGNED = (7, 10, 11, 12, 14, 42, 43, 47, 50)
DESIGNED_NAMES = ("three-cards", "hypothesis-action", "results", "action-register", "opportunity-grid", "paired-columns",
                  "four-pillars", "objectives-scope", "period-scorecard")
INFOGRAPHIC_KEYS = ("donut", "results", "quad", "journey", "scorecard", "map", "priorities", "ogsm", "funnel")
META = {"notes", "source", "style", "mode", "unit", "format", "data", "from", "id", "after", "kind", "at", "_k", "plain",
        "numbered", "start", "library", "picture", "max", "today", "x_label", "y_label", "colour", "color", "status",
        "group", "lane", "label_pos", "source_doc", "classification", "owner", "converted"}


def consts():
    """The deck's slide groups (cover, divider, agenda, other display slides, the flow) from build_deck."""
    import build_deck as BD
    FT = BD.FT
    names = FT.names() if BD.LAYOUTS else {}
    div = {5} | (set(FT.kind("divider")) if BD.LAYOUTS else set())
    ag = {2} | {names.get(n) for n in ("agenda-list", "agenda-gradient")} - {None}
    return {"covers": set(BD.COVERS), "dividers": div, "agendas": ag, "display": set(BD.DISPLAY), "flow": BD.FLOW,
            "metrics": {names.get("headline-metrics"), 9, 13} - {None}, "names": names}


def strings(v, skip=META, unit=""):
    """Every string a reader sees in a slide spec (numbers in data lists too, with the unit the chart prints beside
    them), never the notes or file paths."""
    if isinstance(v, str):
        if v.strip():
            yield v
    elif isinstance(v, (int, float)) and not isinstance(v, bool):
        yield f"{v:g}{unit}"
    elif isinstance(v, (list, tuple)):
        for x in v:
            yield from strings(x, skip, unit)
    elif isinstance(v, dict):
        u = v.get("unit") if isinstance(v.get("unit"), str) and v.get("unit") in ("%", "x", "pts", "bps") else unit
        for k, x in v.items():
            if k not in skip:
                yield from strings(x, skip, u)


def kind(spec, K):
    src = spec.get("source")
    if src in K["covers"]:
        return "cover"
    if src in K["dividers"]:
        return "divider"
    if src in K["agendas"]:
        return "agenda"
    if src in K["display"]:
        return "display"
    if any(spec.get(k) is not None for k in VISUAL_KEYS) or src in NUMBER_SOURCES or src in K["metrics"] or src == K["flow"]:
        return "picture"
    if spec.get("steps"):
        return "picture"
    if spec.get("bullets") is not None and not spec.get("plain") or src in DESIGNED or isinstance(src, str) and src in DESIGNED_NAMES:
        return "layout"                                # tiles, cards, columns, the template's tables: designed, not a wall
    return "text"


def items_of(spec):
    """A text slide's items, one string each: tiles, cards, column points, table rows, text boxes."""
    out = []
    b = spec.get("bullets")
    if isinstance(b, list):
        for x in b:
            if isinstance(x, dict):
                out.append(" ".join(str(x.get(k) or "") for k in ("lead", "text")).strip())
            elif isinstance(x, (list, tuple)):
                out.append(" ".join(str(y) for y in x if y))
            elif str(x or "").strip():
                out.append(str(x).strip())
        return [o for o in out if o]
    t = spec.get("table")
    rows = t.get("rows") if isinstance(t, dict) else t if isinstance(t, list) else None
    if isinstance(rows, list):
        rows = [r for r in rows if isinstance(r, (list, tuple))]
        body = rows[1:] if len(rows) > 1 else rows
        src = spec.get("source")
        if src in (7, 42, 43, 47) or isinstance(src, str) and src in ("three-cards", "paired-columns", "four-pillars", "objectives-scope"):
            for r in body:                              # cards and columns: one item a cell (its title and line)
                for c in r:
                    if str(c or "").strip():
                        out += [" ".join(str(c).split())] if "\n\n" in str(c) or src == 7 else [l.strip() for l in str(c).split("\n") if l.strip()]
        else:
            for r in body:                              # a table: one item a row
                cells = [str(c).strip() for c in r if str(c or "").strip()]
                if cells:
                    out.append(" | ".join(cells))
        return out
    txt = spec.get("text")
    if isinstance(txt, list):
        return [" ".join(str(x).split()) for x in txt if str(x or "").strip()]
    return out


def norm_fig(f):
    """'$1.20B' and '1.2 billion' alike: (value, unit)."""
    f = f.lower().replace(",", "").replace(" ", "")
    unit = re.sub(r"^[$€£+-]*[\d.]+", "", f)
    num = re.search(r"[\d.]+", f)
    if not num:
        return None
    try:
        v = float(num.group(0))
    except ValueError:
        return None
    unit = {"bn": "b", "billion": "b", "million": "m", "thousand": "k", "point": "pts", "points": "pts", "pt": "pts",
            "day": "days", "week": "weeks", "hour": "hours", "hrs": "hours", "hr": "hours"}.get(unit, unit)
    return (round(v, 3), unit)


def figures(texts):
    out = []
    for t in texts:
        for m in FIG.findall(t):
            n = norm_fig(m)
            if n and not (n[1] == "" and n[0] <= 10):
                out.append(n)
        for a_, b_ in FROMTO.findall(t) + RANGE.findall(t):   # "21 to 10 days", "7-9 pts": the first shares the unit
            na, nb = norm_fig(a_), norm_fig(b_)
            if na and nb and not na[1] and nb[1]:
                out.append((na[0], nb[1]))
    return out


def form_of(spec):
    src = spec.get("source")
    if spec.get("bullets") is not None:
        return "a plain list" if spec.get("plain") else "tiles"
    if src == 7 or src == "three-cards":
        return "cards"
    if src in (42, 43, 47) or src in ("paired-columns", "four-pillars", "objectives-scope"):
        return "columns"
    if spec.get("table") is not None:
        return "a table"
    return "text boxes"


def suggest(spec, k, K):
    """The better picture for a text slide, or None: (what it sees, the picture, its storyboard keys)."""
    its = items_of(spec)
    n = len(its)
    src = spec.get("source")
    if n < 2 or src in (10, 11, 12, 14) or src in ("hypothesis-action", "results", "action-register", "opportunity-grid"):
        return None                                     # risks, results, actions, a grid: the template's own picture of them
    head = str(spec.get("headline") or "")
    form = form_of(spec)
    figs = [FIG.findall(t) for t in its]
    with_fig = sum(1 for f in figs if f)
    dated = sum(1 for t in its if DATED.search(t))
    pairs = sum(1 for t in its if FROMTO.search(t))
    words = [len(t.split()) for t in its]
    if (RISKY.search(head) or sum(bool(RISKY.search(t)) for t in its) >= 2) and 2 <= n <= 6:
        return (f"{n} risks in {form}", "the risk table", '"source": 10, rows ["<risk>", null, "<mitigation>"]')
    if sum(1 for t in its if OWNERS.search(t) and DATED.search(t)) >= 2:
        return (f"actions with owners and dates in {form}", "the action table",
                '"source": 12, rows ["<action>", "<detail>", "<Nov 2026 / owner>"] (1-4)')
    if sum(1 for t in its if ARROW.search(t)) >= 2:
        return (f"system flows typed in {form}", "a diagram", '"diagram": ["A \u2192 B: what flows", ...] (guides/deck-layouts.md styles)')
    pcts = []
    for t in its:
        p_ = re.findall(r"(\d+(?:\.\d+)?) ?%", t)
        pcts.append(float(p_[0]) if len(p_) == 1 else None)
    if n >= 3 and None not in pcts and 95 <= sum(pcts) <= 105:
        return (f"{n} shares of a whole in {form}", "a donut", '"donut": {"items": [["<part>", <percent>], ...], "unit": "%"} '
                '(up to 5; more: "modern": "treemap")')
    if pairs >= 2 and n <= 4:
        return (f"before-and-after figures in {form}", "big numbers with a context line",
                '"source": "headline-metrics", cells "+5 pts\\n<label>\\n91% to 96%"')
    if pairs >= 3:
        return (f"before-and-after figures in {form}", "a dumbbell", '"modern": "dumbbell", "items": [["<item>", <before>, <after>], ...]')
    if dated >= 3 and dated >= n - 1:
        return (f"{dated} dated items in {form}", "a timeline", '"timeline": {"items": [{"name": "<item>", "date": "2026-11-30"}, ...]}, '
                '"style": "milestones" (start and end dates draw bars)')
    if with_fig >= 3 and with_fig >= n - 1 and max(words) <= 18:
        if n <= 4:
            return (f"{with_fig} figures in {form}", "big numbers", '"source": "headline-metrics", cells "96%\\n<3-6 word label>\\n<context>" (2-4)')
        return (f"{with_fig} figures in {form}", "a chart", '"modern": "lollipop", "items": [["<item>", <value>], ...] (one unit)')
    if (SEQ_HEAD.search(head) or sum(bool(SEQ_ITEM.match(t)) for t in its) >= 2) and K["flow"] and src != K["flow"]:
        if 3 <= n <= 6:
            return (f"{n} steps in order in {form}", "a flow", '"source": 20, "steps": [{"label": "<1-3 words>", "text": "<2-6 words>"}, ...]')
        if n > 6:
            return (f"{n} steps in {form}", "a process flow in two rows",
                    '"process": {"steps": ["<1-3 words>: <one line>", ...]}, "style": "snake" (up to 10 steps)')
    if spec.get("plain"):
        return ("a plain list", "numbered tiles", 'drop "plain" (2-6 points, "Lead: detail")')
    return None


def review(story, slides, K=None, source=None):
    """EXPERT lines for a built storyboard: [summary line, up to six findings]."""
    K = K or consts()
    slides = [s for s in slides if isinstance(s, dict)]
    kinds = [kind(s, K) for s in slides]
    content = [i for i, kd in enumerate(kinds) if kd in ("picture", "layout", "text")]
    pics = [i for i in content if kinds[i] == "picture"]
    lines, ups = [], []
    import storyline as SL
    ways = [SL.device_of(s) for s in slides]
    retail = []                                         # Retail first: a supply chain or a retail process shown another
    for i in content if not story.get("gallery") and story.get("retail_first") is not False else ():
        f = SL.retail_fit(slides[i])                    # way (the build sets the slides whose items fit as they are)
        if f:
            ups.append(i)
            near = next((j + 1 for j in (i - 1, i + 1) if 0 <= j < len(slides) and ways[j] == SL.fit_way(f)), None)
            retail.append(f"retail: slide {i + 1}: {f['why']}, shown as {SL.form_of(slides[i])} - {SL.fit_form(f)} "
                          f"first: {f['shape']}" + (f" (then move it away from slide {near}, told that way)" if near else ""))
    for i in content:                                   # Picture: the better form for each text slide
        if kinds[i] in ("text", "layout") and i not in ups:
            sg = suggest(slides[i], i + 1, K)
            if sg and SL.SUGGESTED.get(sg[1]) in {ways[j] for j in (i - 1, i + 1) if 0 <= j < len(slides)}:
                sg = None                               # (the way a slide beside it tells its story: never twice in a row)
            if sg:
                ups.append(i)
                lines.append(f"slide {i + 1}: {sg[0]} - {sg[1]}: {sg[2]}")
    story_issues = []
    said = " ".join(list(strings({k: v for k, v in story.items() if k != "slides"}))
                    + [str(s.get(f) or "") for s in slides for f in ("headline", "title", "summary", "notes", "decision")])
    decide = bool(DECIDE.search(said))
    if len(content) >= 6:                               # Story: the answer first, the ask last, chapters
        first = content[:3]
        summary = any(OPENER.match(str(slides[i].get("headline") or "")) for i in first) or bool(story.get("glance"))
        numbers = any(kinds[i] == "picture" and (slides[i].get("source") in K["metrics"] or slides[i].get("quad") is not None
                                                 or slides[i].get("scorecard") is not None) for i in first)
        asked = any(slides[i].get("decision") for i in first)
        if decide and not (summary or asked):           # a deck that asks for a decision says so on its first pages
            story_issues.append("open with the answer and the ask: right after the agenda, an At a glance slide "
                                "(\"glance\": 3-5 \"Lead: detail\" points, the decisions needed among them)")
        elif not (summary or numbers):
            story_issues.append("open with the answer: right after the agenda, an At a glance slide (\"glance\": 3-5 "
                                "\"Lead: detail\" points) or the headline numbers (headline-metrics)")
    if decide and len(content) >= 4:
        last = content[-3:]
        ask = any(s.get("decision") for s in slides) or any(slides[i].get("source") in (12, "action-register")
                                                           or NEXT.search(str(slides[i].get("headline") or "")) for i in last)
        if not ask:
            story_issues.append("end with the ask: an action table (12: what, detail, when / who) and a \"decision\": "
                                "\"Decision: ...\" bar on the slide that needs it")
    if len(content) >= 12 and not any(kd == "divider" for kd in kinds):
        story_issues.append(f"{len(content)} content slides and no chapters: add 2-4 section dividers (divider-photo or "
                            "divider-berry, a 1-4 word \"title\")")
    if len(content) >= 8 and not any(kd == "agenda" for kd in kinds):
        story_issues.append("no agenda: add one after the cover (agenda-list, up to 5 items)")
    run = []
    for i in content:                                   # no three slides of plain text in a row
        run = run + [i] if kinds[i] == "text" else []
        if len(run) == 3:
            if run[1] not in ups:
                story_issues.append(f"slides {run[0] + 1}, {run[1] + 1} and {run[2] + 1} are all text: make slide {run[1] + 1} "
                                    "a picture (a chart, big numbers, a timeline or a diagram of the same facts)")
            run = []
    lines = [f"story: {x}" for x in story_issues] + retail + lines
    bare = []                                           # Context: figures without a takeaway line, asks off the slide
    for i in content:
        s = slides[i]
        if s.get("summary") or s.get("chart") or s.get("modern") or any(s.get(k_) is not None for k_ in INFOGRAPHIC_KEYS) \
                or OPENER.match(str(s.get("headline") or "")) or s.get("_glance"):
            continue                                    # (a chart computes its takeaway; the template's infographics have no
                                                        # room; the At a glance slide is the deck's takeaway itself)
        if len(figures(strings(s))) >= 3:
            bare.append(i + 1)
    if bare:
        lines.append(f"context: slide{'s' if len(bare) > 1 else ''} {', '.join(map(str, bare[:6]))} show figures without a "
                     "takeaway line - add \"summary\": what they mean, in the slide's own numbers (24 words)")
    for i in content:
        s = slides[i]
        if not s.get("decision") and DECIDE.search(str(s.get("notes") or "")) and not DECIDE.search(" ".join(strings(s))):
            lines.append(f"context: slide {i + 1}'s notes ask for a decision the slide does not show - add \"decision\": "
                         "\"Decision: ...\"")
            break
    src_line = source_coverage(source, slides) if source else None
    if src_line:
        lines.append(src_line)
    try:
        gaps = section_coverage(source, slides) if source else []
    except Exception:
        gaps = []
    for title, on, nt in gaps[:2]:                      # a whole part of the source that never reached a slide
        lines.append(f"source: the part \"{title[:40]}\" is {'only in the notes' if nt >= 0.5 else 'not in the deck'} "
                     "- give it a slide of its own or a takeaway line on the slide it belongs to")
    if SENIOR.search(said) and len(content) >= 10 and not any(s.get("source") in (34, 35, "cover-photo", "cover-collage")
                                                              for s in slides):
        lines.append("polish: a photo cover (cover-photo or cover-collage) and photo dividers give a leadership deck its "
                     "finish")
    photo = {K["names"].get(n): n for n in PHOTOS} if K.get("names") else {}
    seen = {}                                           # one photo on two slides reads as a repeat
    for i, s in enumerate(slides):
        name = s.get("source") if s.get("source") in PHOTOS else photo.get(s.get("source"))
        if name:
            seen.setdefault(SAME_PHOTO.get(name, name), []).append((i + 1, name))
    twice = next((u for u in seen.values() if len(u) > 1), None)
    if twice:
        lines.append(f"polish: slides {twice[0][0]} and {twice[1][0]} show the same photo ({twice[1][1]}) - use "
                     f"{PHOTOS[twice[1][1]]} for one of them")
    takeaways = sum(1 for i in content if slides[i].get("summary") or slides[i].get("_glance"))   # (At a glance is one)
    pct = round(100 * len(pics) / len(content)) if content else 0
    srcs = re.match(r"source: (\d+) of (\d+) figures", src_line or "")
    head = (f"EXPERT REVIEW: story {'ok' if not story_issues else str(len(story_issues)) + ' to fix'} | pictures on "
            f"{len(pics)} of {len(content)} content slides ({pct}%) | takeaway lines on {takeaways} of {len(content)} | "
            f"{len(ups)} slide(s) with a better picture"
            + f" | {len({ways[i] for i in content if ways[i]})} ways of telling the story"
            + (f" | source figures on the slides {srcs.group(1)} of {srcs.group(2)}" if srcs else "")
            + (f" | {len(gaps)} part(s) of the source off the slides" if gaps else ""))
    return [head] + [f"EXPERT {l}" for l in lines[:8]] + ([f"EXPERT ... {len(lines) - 8} more: python tools/deck_expert.py "
                                                           "<storyboard>"] if len(lines) > 8 else [])


SHARE_CHARTS = ("treemap", "waffle", "stack100", "sunburst")


def shares(spec):
    """What a share chart prints beside its parts: each value as a percent of the total ("38%")."""
    if spec.get("modern") not in SHARE_CHARTS or not isinstance(spec.get("items"), list):
        return []
    vals = [it[1] for it in spec["items"] if isinstance(it, (list, tuple)) and len(it) > 1 and isinstance(it[1], (int, float))]
    tot = sum(vals)
    return [f"{round(100 * v / tot):g}%" for v in vals] if tot > 0 else []


SMALL_PT, SMALL_WORDS = 10, 25                         # more than 25 words under 10 pt on one slide do not read in a room
SCORECARD_KPIS = 8                                     # the template's scorecard sets its rows small by design: 8 KPIs read
PHOTOS = {"divider-photo": "divider-makeup or divider-berry", "divider-makeup": "divider-photo or divider-berry",
          "cover-photo": "cover-collage", "cover-collage": "cover-photo", "cover-texture": "cover-photo",
          "big-note": "photo-quote", "big-note-close": "photo-quote", "photo-quote": "big-note"}   # photo layout: another one
SAME_PHOTO = {"big-note-close": "big-note"}            # the same picture, a closer crop


def small_text(deck, slides=()):
    """EXPERT lines for a built deck: slides that set many words in small type (a dense scorecard, a long flow legend),
    each with the fix for its kind of slide."""
    import zipfile
    from lxml import etree
    A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    import a11y
    out = []
    with zipfile.ZipFile(str(deck)) as z:
        for k, part in enumerate(a11y.slide_parts(z), 1):
            x = etree.fromstring(z.read(part))
            n = 0
            for r in x.iter(A + "r"):
                t = r.findtext(A + "t") or ""
                rpr = r.find(A + "rPr")
                if rpr is not None and rpr.get("sz") and int(rpr.get("sz")) < SMALL_PT * 100 and "|" not in t:
                    n += len(re.findall(r"\w+", t))
            spec = slides[k - 1] if k - 1 < len(slides) and isinstance(slides[k - 1], dict) else {}
            card = spec.get("scorecard") if isinstance(spec.get("scorecard"), dict) else None
            if card is not None and sum(len(g.get("kpis") or []) for g in card.get("groups") or []
                                        if isinstance(g, dict)) <= SCORECARD_KPIS:
                continue                                # (its own advice: 6-8 KPIs, the rest in the notes)
            if n > SMALL_WORDS:
                fix = ("show 6-8 KPIs, the rest in the notes" if spec.get("scorecard") is not None else
                       "shorter flow labels (1-3 words), or a style that labels the lines itself (zones, cake)" if spec.get("diagram") else
                       "fewer items or shorter names, the detail in the notes" if spec.get("timeline") or spec.get("swimlane")
                       or spec.get("process") or spec.get("retail") else
                       "fewer items or shorter labels, the detail in the notes")
                out.append(f"slide {k}: {n} words under {SMALL_PT} pt do not read in a room - {fix}")
    return out


def read_sections(path):
    """The source document as [(section title, its text)] - Markdown headings, or doc_outline's sections."""
    p = Path(path)
    if p.suffix.lower() in (".md", ".txt", ".csv"):
        out, title, buf = [], "", []
        for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
            m = re.match(r"#{1,4}\s+(.+)", line)
            if m:
                out.append((title, "\n".join(buf))); title, buf = m.group(1).strip(), []
            else:
                buf.append(line)
        return [x for x in out + [(title, "\n".join(buf))] if x[1].strip()]
    import doc_outline as DO
    return [(str(s_.get("title") or ""), " ".join(s_.get("text") or []) if isinstance(s_.get("text"), list) else str(s_.get("text") or ""))
            for s_ in DO.load(p)]


def read_source(path):
    return "\n".join(t for _, t in read_sections(path))


STOP = set("about after again against among being below between both could does doing during each every first from "
           "further have having into itself more most other ourselves over same should some such than that their them "
           "then there these they this those through under until very what when where which while whose will with would "
           "your today plan plans week weeks month year".split())


def section_coverage(path, slides):
    """Source sections whose distinctive words reach the slides less than 40% (each: title, share on the slides, in notes)."""
    secs = [(t, x) for t, x in read_sections(path) if t and len(x.split()) >= 25]
    if len(secs) < 3:
        return []
    words = lambda x: [w[:7] for w in re.findall(r"[a-z][a-z-]{4,}", x.lower()) if w not in STOP]
    import collections
    doc = collections.Counter(w for _, x in secs for w in set(words(x)))
    canvas = " ".join(t for s in slides for t in strings(s)).lower()
    notes = " ".join(str(s.get("notes") or "") for s in slides).lower()
    found = lambda w, txt: re.search(r"\b" + re.escape(w), txt) is not None
    cfig = set(figures([t for s in slides for t in strings(s)] + [t for s in slides for t in shares(s)]))
    out = []
    for title, x in secs:
        figs = set(figures([x]))
        if len(figs) >= 2:                              # a section with figures: its figures decide
            if len(figs & cfig) / len(figs) >= 0.5:
                continue
        c = collections.Counter(words(x))
        key = [w for w, n in sorted(c.items(), key=lambda kv: (-kv[1] / doc[kv[0]], -kv[1]))
               if doc[w] <= max(1, len(secs) // 3)][:8]   # words this section owns
        if len(key) < 4:
            continue
        on = sum(found(w, canvas) for w in key) / len(key)
        nt = sum(found(w, notes) and not found(w, canvas) for w in key) / len(key)
        if on < 0.3 and (len(figs) < 2 or len(figs & cfig) / len(figs) < 0.5):
            out.append((title, on, nt))
    return out


def source_coverage(path, slides):
    """'source: 41 of 52 figures on the slides, 7 only in the notes, 4 nowhere (...)', or None."""
    try:
        text = read_source(path)
    except Exception as e:
        return f"source: could not read {Path(str(path)).name} ({type(e).__name__})"
    want = list(dict.fromkeys(figures([text])))
    if not want:
        return None
    canvas = set(figures([t for s in slides for t in strings(s)] + [t for s in slides for t in shares(s)]))
    notes = set(figures(str(s.get("notes") or "") for s in slides))
    on = [f for f in want if f in canvas]
    nt = [f for f in want if f not in canvas and f in notes]
    miss = [f for f in want if f not in canvas and f not in notes]
    show = lambda f: (f"{f[0]:g}" + ("" if f[1] in ("%", "x", "k", "m", "b") else " ") + f[1]).strip()
    return (f"source: {len(on)} of {len(want)} figures in the source are on the slides, {len(nt)} only in the notes"
            + (f" ({', '.join(show(f) for f in nt[:6])})" if nt else "") + f", {len(miss)} nowhere"
            + (f" ({', '.join(show(f) for f in miss[:6])})" if miss else "") +
            (" - put the ones that carry the story on a slide: a takeaway line, a context line under a big number, a "
             "callout" if nt or miss else ""))


def main():
    import argparse
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("storyboard")
    ap.add_argument("--source", help="the document the deck was written from (.docx, .pdf, .pptx, .md, .txt)")
    a = ap.parse_args()
    story = json.loads(Path(a.storyboard).read_text(encoding="utf-8"))
    import build_deck as BD                             # number the slides as the build does: layout names resolved,
    slides = [dict(s) for s in story.get("slides") or [] if isinstance(s, dict)]   # the At a glance slide in place
    for s in slides:
        if isinstance(s.get("source"), str) and BD.LAYOUTS:
            r = BD.FT.resolve(s["source"])
            s["source"] = r if isinstance(r, int) else s["source"]
    slides, _ = BD.glance(story, slides)
    for line in review(story, slides, source=a.source or story.get("source_doc")):
        print(line)


if __name__ == "__main__":
    main()
