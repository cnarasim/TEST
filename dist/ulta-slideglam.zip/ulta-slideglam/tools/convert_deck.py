"""A non-branded deck (.pptx) or a slide PDF -> the same content rebuilt on the approved template.

    python tools/convert_deck.py Their-Deck.pptx|.pdf --out /mnt/data/out/<Name>.pptx [--build]

Reads every slide (title, bullets with levels, tables, charts with their data, pictures, speaker notes) and writes
<Name>-storyboard.json: each slide mapped to the template (cover, agenda, divider, two boxes, point tiles, a process,
native table, native chart, bullets, picture, closing; a vision with pillars becomes the template's vision house and an
objective / goals / strategies / measures slide its OGSM). Prints one line per slide plus FIX lines for what needs a human or AI decision
(headlines over 60 characters, slides too dense). With --build it also runs build_deck.py on the storyboard.
Nothing is invented: wording, numbers and chart data are copied; only the layout changes.
A portrait PDF is a document, not a deck: use doc_outline.py for it.
"""
import argparse, csv, json, re, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import brand as B   # noqa: E402
from doc_outline import pdf_reader   # noqa: E402

HEADLINE_MAX = 60
AGENDA = re.compile(r"^\s*(agenda|contents|table of contents|overview|topics)\s*$", re.I)
CLOSING = re.compile(r"\b(thank you|thanks|questions\??|q\s*&\s*a|contact us)\b", re.I)
SKIP_PH = ("SLIDE_NUMBER", "FOOTER", "DATE")
CHART = {"LINE": "line", "BAR_C": "bar", "PIE": "pie", "DOUGHNUT": "doughnut", "AREA": "area",
         "COLUMN_STACKED": "stacked", "BAR_STACKED": "stacked_bar"}


# ------------------------------------------------------------------------------------------------ reading a .pptx

def walk(shapes):
    for sh in shapes:
        if sh.shape_type == 6:
            yield from walk(sh.shapes)
        else:
            yield sh


def diagram_flows(slide):
    """Boxes joined by glued connectors -> ["A → B: label", ...] and the texts used. A connector's label is the
    nearest small text shape (not a box) within 0.8 in of its middle."""
    shapes = list(walk(slide.shapes))
    ns = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    box = {sh.shape_id: sh for sh in shapes if sh.has_text_frame and sh.text_frame.text.strip()} if shapes else {}

    def touching(px, py):
        """An unglued connector end -> the text box whose edge it sits on (within 0.15 in), the larger one on a tie.
        Boxes are 0.3 in tall or more; a flow's label or number badge sitting at its end is never an end."""
        best, bd = None, 0.15 * 914400
        for sh in box.values():
            if sh.is_placeholder or (sh.height or 0) < 0.3 * 914400: continue
            l, t = sh.left or 0, sh.top or 0
            dx, dy = max(l - px, 0, px - l - (sh.width or 0)), max(t - py, 0, py - t - (sh.height or 0))
            d = (dx * dx + dy * dy) ** 0.5
            if d < bd or (best is not None and d == bd and (sh.width or 0) * (sh.height or 0) > (best.width or 0) * (best.height or 0)):
                best, bd = sh, d
        return best

    conns = []
    for sh in shapes:
        x = sh._element
        if not x.tag.endswith("cxnSp"): continue
        st, en = x.find(f".//{ns}stCxn"), x.find(f".//{ns}endCxn")
        xf = x.find(f".//{ns}xfrm")
        l, t, w, h = sh.left or 0, sh.top or 0, sh.width or 0, sh.height or 0
        x1, x2 = (l + w, l) if xf is not None and xf.get("flipH") == "1" else (l, l + w)
        y1, y2 = (t + h, t) if xf is not None and xf.get("flipV") == "1" else (t, t + h)
        a = box.get(int(st.get("id"))) if st is not None else touching(x1, y1)    # glue first, else the box it touches
        b = box.get(int(en.get("id"))) if en is not None else touching(x2, y2)
        if a is None or b is None or a is b: continue
        ln = x.find(f".//{ns}ln")
        head = ln.find(f"{ns}headEnd") if ln is not None else None
        tail = ln.find(f"{ns}tailEnd") if ln is not None else None
        arrow = lambda e: e is not None and e.get("type", "none") != "none"
        if arrow(head) and not arrow(tail):
            a, b = b, a                                                            # the arrowhead is on the start: reverse
        mid = ((sh.left or 0) + (sh.width or 0) / 2, (sh.top or 0) + (sh.height or 0) / 2)
        conns.append((a, b, mid))
    if len(conns) < 2: return []
    nodes = {id(c[0]) for c in conns} | {id(c[1]) for c in conns}
    labels = [sh for sh in box.values() if id(sh) not in nodes and not sh.is_placeholder
              and len(sh.text_frame.text.split()) <= 4]
    out, taken = [], set()
    name = lambda sh: " ".join(sh.text_frame.text.split())
    for a, b, (mx, my) in conns:
        best, bd = None, 0.8 * 914400
        for l in labels:
            if id(l) in taken: continue
            d = (((l.left or 0) + (l.width or 0) / 2 - mx) ** 2 + ((l.top or 0) + (l.height or 0) / 2 - my) ** 2) ** 0.5
            if d < bd: best, bd = l, d
        if best is not None: taken.add(id(best))
        lab = name(best) if best is not None else ""
        out.append((f"{name(a)} → {name(b)}" + (f": {lab}" if lab else ""), {name(a), name(b)} | ({lab} if lab else set())))
    return out


def _own(text):
    """A text without the template's placeholder lines (Lorem ipsum, Sub-headline, Text here ...): a deck made on the
    template and never finished must not carry them into the rebuild."""
    import validate_deck as V
    keep = [l for l in str(text or "").split("\n") if not V.is_placeholder(l)]
    while keep and not keep[-1].strip():
        keep.pop()
    while keep and not keep[0].strip():
        keep.pop(0)
    return "\n".join(keep).strip()


def read_pptx(path, media):
    from pptx import Presentation
    prs = Presentation(str(path))
    out = []
    dropped = []
    for i, s in enumerate(prs.slides, 1):
        d = {"n": i, "title": "", "blocks": [], "tables": [], "charts": [], "pictures": [], "notes": ""}
        title_sh = s.shapes.title
        if title_sh is not None and _own(title_sh.text_frame.text):
            d["title"] = " ".join(_own(title_sh.text_frame.text).split())
        texts = []
        for sh in walk(s.shapes):
            if title_sh is not None and sh.shape_id == title_sh.shape_id:
                continue
            if sh.is_placeholder and any(k in str(sh.placeholder_format.type) for k in SKIP_PH):
                continue
            if getattr(sh, "has_table", False) and sh.has_table:
                rows = [[_own(c.text) for c in r.cells] for r in sh.table.rows]
                if any(_own(c.text) != c.text.strip() for r in sh.table.rows for c in r.cells):
                    dropped.append(i)
                rows = [r for r in rows if any(r)]
                if rows:
                    d["tables"].append(rows)
            elif getattr(sh, "has_chart", False) and sh.has_chart:
                d["charts"].append(read_chart(sh.chart, media, i, len(d["charts"])))
            elif sh.shape_type == 13:                                             # picture
                try:
                    img = sh.image
                except Exception:
                    continue
                p = media / f"slide{i}-pic{len(d['pictures']) + 1}.{img.ext}"
                p.write_bytes(img.blob)
                d["pictures"].append({"path": str(p), "area": (sh.width or 0) * (sh.height or 0),
                                      "alt": sh._element.xpath("string(.//p:cNvPr/@descr)")})
            elif sh.has_text_frame and _own(sh.text_frame.text):
                paras = [(p.level, " ".join(p.text.split())) for p in sh.text_frame.paragraphs if _own(p.text)]
                size = max((r.font.size or 0 for p in sh.text_frame.paragraphs for r in p.runs), default=0)
                texts.append((sh.top or 0, sh.left or 0, size, paras, sh.is_placeholder))
        flows, used = diagram_flows(s), set()
        if len(flows) >= 2:                                                       # a drawn diagram: keep it a diagram
            d["flows"] = [f for f, _ in flows]
            used = {u for _, us in flows for u in us}
            texts = [t for t in texts if " ".join(x for _, x in t[3]) not in used]
        texts.sort(key=lambda t: (round(t[0] / 228600), t[1]))
        if not d["title"] and texts:                                             # no title placeholder: a one-line placeholder
            ph = [t for t in texts if t[4] and t[0] < prs.slide_height / 4 and len(t[3]) == 1]   # in the top quarter
            top = min(ph, key=lambda t: t[0]) if ph else max(texts, key=lambda t: (t[2], -t[0]))   # else the biggest text
            if len(top[3]) == 1:
                d["title"] = top[3][0][1]; texts.remove(top)
        d["blocks"] = [t[3] for t in texts]
        d["placed"] = [(t[0], t[1], t[3]) for t in texts]                     # where each box sits: pillars side by side
        if s.has_notes_slide:
            d["notes"] = s.notes_slide.notes_text_frame.text.strip()
        out.append(d)
    for i in sorted(set(dropped)):
        print(f"note: slide {i}: the template's placeholder text (Lorem ipsum, Sub-headline ...) left out - it was never "
              "this deck's own words")
    return out


def read_chart(chart, media, i, k):
    kind = next((v for key, v in CHART.items() if key in str(chart.chart_type)), "column")
    plot = chart.plots[0]
    cats = [str(c) for c in plot.categories]
    series = [(s.name or f"Series {j + 1}", list(s.values)) for j, s in enumerate(plot.series)]
    p = media / f"slide{i}-chart{k + 1}.csv"
    with open(p, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["Category"] + [n for n, _ in series])
        for r, c in enumerate(cats):
            w.writerow([c] + [vals[r] if r < len(vals) else "" for _, vals in series])
    return {"data": str(p), "type": kind, "x": "Category", "y": [n for n, _ in series],
            "title": chart.chart_title.text_frame.text.strip() if chart.has_title and chart.chart_title.has_text_frame else ""}


# ------------------------------------------------------------------------------------------------ reading a slide PDF
def read_pdf(path, media):
    rd = pdf_reader()(str(path))
    pg0 = rd.pages[0].mediabox
    if float(pg0.width) < float(pg0.height):
        raise SystemExit("portrait PDF = a document, not a deck: run tools/doc_outline.py on it and write the storyboard "
                         "(WORKFLOWS.md, 'Deck from a Word/PDF/long document')")
    out = []
    for i, page in enumerate(rd.pages, 1):
        W, H = float(page.mediabox.width), float(page.mediabox.height)
        runs = []

        def vis(text, cm, tm, font, size):
            t = text.strip()
            if t:
                sc = abs(tm[0] * cm[0]) or 1
                runs.append((tm[5] * (cm[3] or 1) + cm[5], (size or 0) * sc, tm[4] * (cm[0] or 1) + cm[4], t))
        page.extract_text(visitor_text=vis)
        rows_ = []                                                    # runs grouped by baseline, top first
        for y, size, x, txt in sorted(runs, key=lambda r: -r[0]):
            ln = next((l for l in rows_ if abs(l[0] - y) <= max(2.0, size * 0.25)), None)
            if ln is None:
                rows_.append([y, size, [(x, txt, size)]])
            else:
                ln[1] = max(ln[1], size); ln[2].append((x, txt, size))
        lines = []                                                    # [y, size, [[x, text, size], ...]]
        for y, size, rs in rows_:
            chunks = []
            for x, txt, sz in sorted(rs):                             # left to right, then merge word runs
                if chunks and x - (chunks[-1][0] + len(chunks[-1][1].rstrip()) * chunks[-1][2] * 0.45) < chunks[-1][2] * 0.6:
                    chunks[-1][1] += " " + txt
                else:
                    chunks.append([x, txt, sz])
            lines.append([y, size, chunks])
        lines = [l for l in lines if not re.fullmatch(r"\d{1,3}", " ".join(c[1] for c in l[2]))]   # page numbers
        d = {"n": i, "title": "", "blocks": [], "tables": [], "charts": [], "pictures": [], "notes": "", "pdf_chart": False}
        if lines:
            big = max(l[1] for l in lines)
            head = [l for l in lines if l[1] >= big * 0.92]
            d["title"] = " ".join(" ".join(c[1] for c in l[2]) for l in head)
            body = [l for l in lines if l not in head]
            table = pdf_table(body)
            nums = [l for l in body if all(re.fullmatch(r"[-+$€£]?[\d.,]+%?", c[1].replace(" ", "")) for c in l[2])]
            if table:
                d["tables"].append(table)
                body = [l for l in body if not getattr(l, "in_table", False) and l not in TABLE_LINES]
            elif body and len(nums) >= max(3, len(body) * 0.4):          # axis labels: a chart drawn as vectors
                d["pdf_chart"] = True
                body = []
            d["blocks"] = pdf_blocks(body, W)
            d["title_y"] = min(l[0] for l in head) - big * 0.4
        d["pictures"] = pdf_pictures(page, media, i)
        if d["pdf_chart"]:
            pic = render_region(path, i, d.get("title_y", H), H, media)
            if pic:
                d["pictures"] = [{"path": pic, "area": 1, "alt": f"Chart from {Path(path).name} page {i} (picture)"}]
        out.append(d)
    return out


TABLE_LINES = []


def pdf_table(body):
    """Three or more consecutive lines with the same number (>= 2) of aligned chunks = a table."""
    TABLE_LINES.clear()
    best = []
    run = []
    for l in body + [None]:
        cols = [round(c[0] / 12) for c in l[2]] if l else None
        if l and len(l[2]) >= 2 and (not run or (len(l[2]) == len(run[0][2]) and
                                                all(abs(a - b) <= 2 for a, b in zip(cols, [round(c[0] / 12) for c in run[0][2]])))):
            run.append(l)
        else:
            if len(run) > len(best):
                best = run
            run = [l] if l and len(l[2]) >= 2 else []
    cells = [c[1].strip() for l in best for c in l[2]]
    prose = sum(1 for l in best[1:] for c in l[2] if c[1].strip()[:1].islower()) > len(best[1:]) * len(best[0][2]) / 2 if best else False
    if any(re.match(r"[•▪◦‣–*]", c) for c in cells) or prose:   # bullets or wrapped sentences side by side: columns, not a table
        best = []
    if len(best) >= 3:
        TABLE_LINES.extend(best)
        return [[c[1] for c in l[2]] for l in best]
    return None


def pdf_blocks(body, W):
    """Body lines -> text blocks: one per column (two columns when the chunks fall into a left and a right group),
    lines merged into bullets; an indented line becomes a sub-bullet."""
    chunks = [(l[0], c[0], c[1]) for l in body for c in l[2]]
    if not chunks:
        return []
    xs = sorted({round(x) for _, x, _ in chunks})
    split = next((xs[k] for k in range(1, len(xs)) if xs[k] - xs[k - 1] > W * 0.25), None)
    groups = [[c for c in chunks if c[1] < split], [c for c in chunks if c[1] >= split]] if split else [chunks]
    blocks = []
    glyph = re.compile(r"^\s*[•▪◦‣\-–*]\s*")
    for g in groups:
        g.sort(key=lambda c: (-round(c[0] / 4), c[1]))
        left = min(x for _, x, _ in g)
        items, mark = [], False                       # (x, text, starts a bullet)
        for y, x, txt in g:
            m = glyph.match(txt)
            if m and not txt[m.end():].strip():
                mark = True; continue                 # a bullet glyph drawn on its own: the next text starts a bullet
            items.append((x, txt[m.end():] if m else txt, bool(m) or mark)); mark = False
        bulleted = any(bl for _, _, bl in items)
        tx = min((x for x, _, _ in items), default=left)
        paras = []
        for x, txt, bl in items:
            lvl = 1 if x - tx > 15 and bl else 0
            cont = paras and not bl and (bulleted or (not re.search(r"[.:!?]$", paras[-1][1]) and txt[:1].islower()))
            if cont:
                paras[-1] = (paras[-1][0], paras[-1][1].rstrip() + " " + txt.strip())   # wrapped line continues the bullet
            elif txt.strip():
                paras.append((lvl, txt.strip()))
        if paras:
            blocks.append(paras)
    return blocks


def pdf_pictures(page, media, i):
    """Images the page actually draws (a PDF can list shared images on every page)."""
    try:
        content = page.get_contents().get_data()
    except Exception:
        return []
    pics = []
    for im in page.images:
        stem = Path(im.name).stem
        if ("/" + stem).encode() not in content or len(im.data) < 15000:
            continue
        p = media / f"page{i}-{stem}{Path(im.name).suffix or '.png'}"
        p.write_bytes(im.data)
        pics.append({"path": str(p), "area": len(im.data), "alt": ""})
    return pics


def render_region(pdf, page_no, top_y, H, media):
    """The part of a page below its title as a PNG (for a chart that is drawn, not stored as data)."""
    png = media / f"page{page_no}-chart.png"
    try:
        import pypdfium2 as pdfium
        img = pdfium.PdfDocument(str(pdf))[page_no - 1].render(scale=2).to_pil()
    except Exception:
        import shutil
        if not shutil.which("pdftoppm"):
            return None
        import atomic
        base = atomic.scratch() / "p"
        subprocess.run(["pdftoppm", "-png", "-r", "144", "-f", str(page_no), "-l", str(page_no), str(pdf), str(base)],
                       capture_output=True)
        found = sorted(base.parent.glob("p*.png"))
        if not found:
            return None
        from PIL import Image
        img = Image.open(found[0])
    w, h = img.size
    y0 = int(h * (1 - top_y / H)) if top_y < H else int(h * 0.15)
    img.crop((0, max(0, y0), w, int(h * 0.94))).save(png)
    return str(png)


# ------------------------------------------------------------------------------------------------ mapping

def words(blocks):
    return sum(len(t.split()) for b in blocks for _, t in b)


def closing_slide(b):
    """The template's closing slide that takes text ("Thank you!"), else the brand's closing role."""
    from pptx import Presentation
    for k, s in enumerate(Presentation(str(b.template)).slides, 1):
        if any(sh.has_text_frame and CLOSING.search(sh.text_frame.text) for sh in s.shapes):
            return k
    return b.role("closing", 32)


NUMBERING = re.compile(r"^\s*\(?\d{1,2}[.):]?\s*$")
TIMING = re.compile(r"^\s*(\d{1,2}[:.]\d{2}\s*(am|pm)?(\s*[-\u2013]\s*\d{1,2}[:.]\d{2}\s*(am|pm)?)?|\d{1,3}\s*(min|mins|minutes|h|hr|hrs))\s*$", re.I)
AGENDA_HEAD = re.compile(r"^\s*(#|no\.?|number|items?|topics?|sections?|agenda|contents|time|timing|duration|owner|"
                         r"presenter|speaker|lead)\s*$", re.I)


def agenda_items(rows):
    """Agenda items from a table ('1 | Business context' rows, with or without a header row): the item text of each
    row, without its number or time - the agenda slide numbers them itself."""
    cells = [[str(v or "").strip() for v in r] for r in rows]
    if len(cells) == 1:                                # one row of topics: each cell is an item
        return [v for v in cells[0] if v and not NUMBERING.match(v) and not TIMING.match(v)]
    if len(cells) > 1 and (all(AGENDA_HEAD.match(v) for v in cells[0] if v) or not any(NUMBERING.match(v) for v in cells[0])
                           and any(NUMBERING.match(v) for r in cells[1:] for v in r)):
        cells = cells[1:]                              # a '# | Topic' header row
    return [next((v for v in r if v and not NUMBERING.match(v) and not TIMING.match(v)), "") for r in cells if any(r)]


def short_point(block):
    """A text box as one point: its single line of up to 15 words, or 'Lead: detail' when a 1-4 word heading line sits
    over one such line (18 words in all at most). None when the box holds more than one point."""
    lines = [t.strip() for _, t in block if t.strip()]
    if len(lines) == 1 and len(lines[0].split()) <= 15:
        return lines[0]
    if (len(lines) == 2 and len(lines[0].split()) <= 4 and not lines[0].endswith((".", "!", "?"))
            and len(lines[0].split()) + len(lines[1].split()) <= 18):
        return f"{lines[0].rstrip(':')}: {lines[1]}"
    return None


LABEL = r"\s*(?:[:\-\u2013]\s*(.*))?$"
VISION = re.compile(r"^\s*(?:our\s+|the\s+|\d{4}\s+)?vision(?:\s+statement)?" + LABEL, re.I)
GOALS = re.compile(r"^\s*(?:our\s+|\d{4}\s+)?goals?" + LABEL, re.I)
KPI_LINE = re.compile(r"^\s*(?:kpis?|measures?|metrics?)" + LABEL, re.I)
OGSM = {"objective": re.compile(r"^\s*objectives?" + LABEL, re.I), "goals": GOALS,
        "strategies": re.compile(r"^\s*strateg(?:y|ies)" + LABEL, re.I),
        "measures": re.compile(r"^\s*(?:measures?|measurements?|kpis?|metrics?)" + LABEL, re.I)}
FIG = re.compile(r"[+\-\u2212]?[$\u20ac\u00a3]?\d[\d,.]*\s?(?:%|[KMB]\b|x\b|pts?\b)?")


def _lines(paras):
    return [t.strip() for _, t in paras if t.strip()]


def _labelled(lines, rx):
    """Items under a label line ('Goals' then one per line, or 'Goals: a; b' on one line); None when not labelled."""
    m = rx.match(lines[0]) if lines else None
    if not m:
        return None
    first = (m.group(1) or "").strip()
    return ([x.strip() for x in re.split(r";\s*", first) if x.strip()] if first else []) + lines[1:]


def vision_house(d):
    """A vision over 3-6 pillars (goals and KPIs if the slide has them): the template's vision house (24). Every part
    comes from the slide's own words - a line led by 'Vision', boxes side by side or a table's columns as the pillars,
    lines led by 'Goals' or 'KPIs'. None when the slide is not one."""
    placed = d.get("placed") or [(0, 0, b) for b in d["blocks"]]
    vision, used, goals = None, set(), []
    for k, (_, _, paras) in enumerate(placed):
        got = _labelled(_lines(paras), VISION)
        if got:
            vision, used = " ".join(got), used | {k}
            break
    if not vision:
        return None
    for k, (_, _, paras) in enumerate(placed):
        got = None if k in used else _labelled(_lines(paras), GOALS)
        if got is not None:
            goals += got
            used.add(k)
    pillars = []
    t = d["tables"][0] if d["tables"] else None
    if t and t[0]:
        lead = not str(t[0][0]).strip() and len(t[0]) > 1     # a first column of row labels
        names = [str(c).strip() for c in t[0][1 if lead else 0:]]
        if 3 <= len(names) <= 6 and all(names) and all(len(x.split()) <= 4 for x in names):
            for c, name in enumerate(names, 1 if lead else 0):
                text, kpis = [], []
                for r in t[1:]:
                    v = str(r[c]).strip() if c < len(r) else ""
                    if v:
                        (kpis if lead and KPI_LINE.match(str(r[0])) else text).append(" ".join(v.split()))
                pillars.append({"name": name, "text": "; ".join(text), "kpis": kpis[:2]})
    if not pillars:                                    # boxes side by side, each led by a 1-4 word name
        rest = sorted(((top, left, paras) for k, (top, left, paras) in enumerate(placed) if k not in used),
                      key=lambda x: (x[0], x[1]))
        rows = []
        for top, left, paras in rest:
            row = next((r for r in rows if abs(r[0][0] - top) <= 320040), None)
            (row.append((top, left, paras)) if row is not None else rows.append([(top, left, paras)]))
        for row in rows:
            heads = [_lines(p) for _, _, p in sorted(row, key=lambda x: x[1])]
            if 3 <= len(row) <= 6 and all(h and len(h[0].split()) <= 4 for h in heads):
                below = next((r for r in rows if r is not row and r[0][0] > row[0][0] and len(r) == len(row)), None)
                extra = [_lines(p) for _, _, p in sorted(below, key=lambda x: x[1])] if below and all(len(h) == 1 for h in heads) else None
                for j, h in enumerate(heads):
                    body = h[1:] + (extra[j] if extra else [])
                    kpis = [x for x in body if KPI_LINE.match(x)]
                    kpis = [(KPI_LINE.match(x).group(1) or "").strip() for x in kpis]
                    text = [x for x in body if not KPI_LINE.match(x)]
                    pillars.append({"name": h[0], "text": " ".join(text), "kpis": [x for x in kpis if x][:2]})
                break
    if not 3 <= len(pillars) <= 6 or len(goals) > 3:
        return None
    for p_ in pillars:
        if not p_["kpis"]:
            p_.pop("kpis")
    return {"vision": vision, "goals": goals, "strategies": pillars}


def ogsm_of(d):
    """Objective, goals, strategies and measures (a table's labelled rows, or boxes led by those words): the template's
    OGSM (25). None when the slide is not one; ('too many', counts) when a part has more than the template's 3."""
    parts = {}
    if d["tables"]:
        for r in d["tables"][0]:
            cells = [str(v).strip() for v in r]
            for key, rx in OGSM.items():
                m = rx.match(cells[0]) if cells and cells[0] else None
                if m and key not in parts:
                    items = ([m.group(1).strip()] if m.group(1) else []) + [x.strip() for c in cells[1:] for x in c.split("\n") if x.strip()]
                    parts[key] = items
                    break
    for paras in d["blocks"]:
        lines = _lines(paras)
        for key, rx in OGSM.items():
            got = None if key in parts else _labelled(lines, rx)
            if got is not None:
                parts[key] = got
                break
    if set(parts) != set(OGSM) or not parts["objective"]:
        return None
    if any(len(parts[k]) > 3 for k in ("goals", "strategies", "measures")) or not all(parts[k] for k in ("goals", "strategies", "measures")):
        return ("too many", {k: len(v) for k, v in parts.items()})

    def strategy(x):
        m = re.match(r"^(.{1,30}?)\s*[:\u2013]\s+(.+)$", x) or re.match(r"^(.{1,30}?)\s+-\s+(.+)$", x)
        if m:
            return {"title": m.group(1).strip(), "text": m.group(2).strip()}
        return {"title": x, "text": ""} if len(x.split()) <= 3 else {"title": "", "text": x}

    def measure(x):
        f = FIG.search(x)
        if not f:
            return {"title": x, "value": "", "text": ""}
        before = re.sub(r"\s*(?:[:\-\u2013]|\b(?:of|at|to|by)\b)\s*$", "", x[:f.start()].strip()).strip()
        return {"title": before, "value": f.group(0).strip(), "text": x[f.end():].strip(" :-\u2013")}
    return {"objective": " ".join(parts["objective"]), "goals": parts["goals"],
            "strategies": [strategy(x) for x in parts["strategies"]], "measures": [measure(x) for x in parts["measures"]]}


def plan(slides, src_name):
    b = B.current()
    cover, agenda, divider, two = (b.role(k, d) for k, d in (("cover", 1), ("agenda", 2), ("divider", 5), ("two_boxes", 6)))
    close = closing_slide(b)
    ulta = b.name == "ulta"                            # the Ulta template's own big-number (9) and card (7) slides
    numbers, cards = b.role("big_numbers", 9 if ulta else None), b.role("cards", 7 if ulta else None)
    FIGURE = re.compile(r"[+\-−]?[$€£]?\d[\d,.]*\s?(?:%|[KMB]|x|hrs?|days|min|sec|pts)?(?:\s+of\s+\d+)?")
    story, report, fixes, section = [], [], [], 0
    n = len(slides)
    for d in slides:
        i, title, blocks = d["n"], d["title"], d["blocks"]
        flat = [p for blk in blocks for p in blk]
        note = "\n".join(x for x in (d["notes"], f"Source: {src_name} slide {i}") if x)
        if i == 1:
            sub = flat[0][1] if flat else None
            story.append({"source": cover, "title": title or (sub or "—"), "subtitle": sub if title else None, "notes": note})
            report.append(f"{i:>2} cover      ← {title[:50]!r}")
            continue
        if i == n and CLOSING.search(title + " " + " ".join(t for _, t in flat)) and not (d["tables"] or d["charts"]):
            story.append({"source": close, "text": [title or "Thank you!"], "notes": note})
            report.append(f"{i:>2} closing    ← {title[:50]!r}")
            continue
        spec = {"headline": title or "—", "notes": note}
        items = [t for _, t in flat] if not d["tables"] else agenda_items(d["tables"][0])
        if AGENDA.match(title) and 2 <= len(items) <= 5 and all(items) and not d["charts"]:
            full = ["   ".join(str(v or "").strip() for v in r) for r in d["tables"][0]] if d["tables"] else []
            story.append({"source": agenda, "text": [title], "table": [[None, t] for t in items],   # times, owners: notes
                          "notes": "\n".join(full) + ("\n" if full else "") + note})
            report.append(f"{i:>2} agenda     ← {len(items)} items" + (" (from a table)" if d["tables"] else ""))
            continue
        if not d["charts"] and not d.get("flows"):    # a vision with pillars, an OGSM: the template's own infographics
            house, og = vision_house(d), ogsm_of(d)
            if isinstance(og, tuple):
                fixes.append(f"slide {i}: an OGSM with {og[1]['goals']} goals, {og[1]['strategies']} strategies and "
                             f"{og[1]['measures']} measures - the template's OGSM holds 1-3 of each; kept as it was")
                og = None
            if house or og:
                story.append({"priorities" if house else "ogsm": house or og, "headline": title or "-", "notes": note})
                if house and len(title or "") > 20:
                    fixes.append(f"slide {i}: the vision house's title sits left of its roof - shorten '{title[:40]}' to a "
                                 "plan name of about 20 characters, such as '2026 Priorities'")
                if og and any(not x["title"] for x in og["strategies"]):
                    fixes.append(f"slide {i}: give each OGSM strategy a 1-2 word title ('Book: online booking everywhere')")
                report.append(f"{i:>2} {'vision house' if house else 'OGSM':<10} ← {title[:50]!r}" +
                              (f" ({len(house['goals'])} goals, {len(house['strategies'])} pillars)" if house else ""))
                continue
        one_row = d["tables"][0][0] if d["tables"] and len(d["tables"][0]) == 1 and not d["charts"] and not d.get("flows") else None
        if d.get("flows"):
            spec["diagram"] = d["flows"]
            kind = f"diagram ({len(d['flows'])} flows)"
            if flat:
                spec["notes"] = "\n".join(t for _, t in flat) + "\n" + note
            if any(":" not in f for f in d["flows"]):
                fixes.append(f"slide {i}: diagram kept native; some arrows had no label - add 1-3 words per arrow if they matter")
        elif d["charts"]:
            ch = d["charts"][0]
            spec["chart"] = {k: v for k, v in ch.items() if v}
            kind = f"chart ({ch['type']}, {len(ch['y'])} series)"
            if len(d["charts"]) > 1 or d["tables"]:
                fixes.append(f"slide {i}: had {len(d['charts'])} chart(s) and {len(d['tables'])} table(s); only the first chart is kept - split it")
            if flat:                                   # points beside the chart: kept in the notes, never dropped
                fixes.append(f"slide {i}: {len(flat)} point(s) beside the chart moved to the notes - put the main one in the "
                             "headline, or give the figures their own big-number slide (9)")
                spec["notes"] = "\n".join(t for _, t in flat) + "\n" + note
                spec["_beside"] = [t for _, t in flat]
        elif one_row is not None:                      # a single row of labels is a sequence or a list, never a table
            labels = [str(v).strip() for v in one_row if str(v or "").strip()]
            if 3 <= len(labels) <= 6 and all(len(x.split()) <= 4 for x in labels):
                spec["diagram"] = [f"{x} → {y}" for x, y in zip(labels, labels[1:])]
                spec["style"] = "chevron"
                kind = f"process ({len(labels)} stages)"
            else:
                spec["bullets"] = [[0, x] for x in labels]
                kind = f"bullets ({len(labels)})"
            if flat:
                spec["notes"] = "\n".join(t for _, t in flat) + "\n" + note
                fixes.append(f"slide {i}: text next to the row of labels moved to the notes")
        elif d["tables"] and numbers and len(d["tables"][0]) == 2 and len(d["tables"][0][0]) == 3 and all(
                len(c.split("\n")) >= 2 and FIGURE.fullmatch(c.split("\n")[0].strip()) for c in d["tables"][0][1]) and not flat:
            rows = d["tables"][0]                       # three headers over "74%\nfaster builds" cells: the big-number slide
            spec.update(source=numbers, table=[rows[0], ["\n".join(x.strip() for x in c.split("\n") if x.strip()) for c in rows[1]]])
            kind = "big numbers (3)"
        elif d["tables"] and cards and len(d["tables"][0]) == 3 and all(len(r) == 3 for r in d["tables"][0]) and all(
                len([x for x in c.split("\n") if x.strip()]) >= 2 for r in d["tables"][0][1:] for c in r) and not flat:
            rows = d["tables"][0]                       # three column titles over "Title\n\nline" cells: the card slide
            spec.update(source=cards, table=[rows[0]] + [["\n\n".join(x.strip() for x in c.split("\n") if x.strip())[:200] for c in r] for r in rows[1:]])
            kind = "cards (3 x 2)"
        elif d["tables"]:
            rows = d["tables"][0]
            if len(rows) > 14:
                fixes.append(f"slide {i}: table has {len(rows)} rows; kept the first 14 - split it or move the rest to an appendix")
                rows = rows[:14]
            spec["table"] = {"rows": rows}
            kind = f"table {len(rows)}x{max(len(r) for r in rows)}"
            if flat:
                fixes.append(f"slide {i}: text next to the table moved to the notes")
                spec["notes"] = "\n".join(t for _, t in flat) + "\n" + note
        elif d.get("pdf_chart") and d["pictures"]:
            spec["picture"] = d["pictures"][0]["path"]; spec["alt"] = d["pictures"][0]["alt"]
            kind = "chart (picture)"
            fixes.append(f"slide {i}: chart kept as a picture - a PDF has no chart data; give the numbers (xlsx/csv) "
                         "to make it a native chart")
        elif d["pictures"] and words(blocks) <= 60:
            pic = max(d["pictures"], key=lambda p: p["area"])
            spec["picture"] = pic["path"]
            spec["alt"] = pic["alt"] or title
            if flat:
                spec["bullets"] = [[lvl, t] for lvl, t in flat]
            kind = "picture" + (f" + {len(flat)} bullets" if flat else "")
        elif not flat and not d["pictures"] or (len(flat) <= 1 and words(blocks) <= 8):
            section += 1
            story.append({"source": divider, "text": [str(section), title or "—"],
                          "notes": "\n".join(t for _, t in flat) + ("\n" if flat else "") + note})
            report.append(f"{i:>2} divider    ← {title[:50]!r}")
            continue
        elif len(blocks) == 2 and all(short_point(blk) for blk in blocks):
            spec["bullets"] = [short_point(blk) for blk in blocks]     # two short points: two tiles, not a line of
            kind = "points (2)"                                         # small print in each of two tall boxes
        elif len(blocks) == 2 and all(len(" ".join(t for _, t in blk)) <= 300 for blk in blocks):
            spec["source"] = two
            spec["text"] = ["\n".join(t for _, t in blk) for blk in blocks]
            kind = "two boxes"
        else:
            spec["bullets"] = [[lvl, t] for lvl, t in flat]
            kind = f"bullets ({len(flat)})"
            if d["pictures"]:
                fixes.append(f"slide {i}: picture dropped (slide is text-heavy) - add it on its own slide if it matters")
        if len(spec["headline"]) > HEADLINE_MAX:
            fixes.append(f"slide {i}: headline is {len(spec['headline'])} characters - rewrite it as one short message (≤45)")
        if spec["headline"] == "—":
            fixes.append(f"slide {i}: no title found - write a headline")
        story.append(spec)
        report.append(f"{i:>2} {kind:<10} ← {title[:50]!r}")
    return story, report, fixes


def source_level(src):
    """The classification a .pptx already carries (its Classification property, else its footer wording), so a
    deck rebuilt on the template keeps it. None when it has none."""
    if Path(src).suffix.lower() != ".pptx":
        return None
    try:
        import compliance, docprops as DP
        _, custom = DP.read_props(src)
        label = (custom.get("Classification") or "").strip().lower()
        level = next((k for k, (lab, _) in compliance.LEVELS.items() if lab.lower() == label), None)
        if level:
            return level
        import zipfile
        z = zipfile.ZipFile(src)
        text = " ".join(z.read(n).decode("utf-8", "ignore") for n in z.namelist()
                        if re.match(r"ppt/slides/slide\d+\.xml$", n))
        for k, (_, phrase) in compliance.LEVELS.items():
            if re.search(r"\|\s*" + re.escape(phrase.replace("&", "&amp;")) + "<", text):
                return k
    except Exception:
        return None
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source"); ap.add_argument("--out", required=True)
    ap.add_argument("--build", action="store_true", help="also build the deck from the storyboard")
    ap.add_argument("--classification")
    a = ap.parse_args()
    src, out = Path(a.source), Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    media = out.parent / (out.stem + "_source"); media.mkdir(exist_ok=True)
    slides = read_pdf(src, media) if src.suffix.lower() == ".pdf" else read_pptx(src, media)
    story, report, fixes = plan(slides, src.name)
    level = a.classification or source_level(src)       # a deck already classified keeps its footer wording
    if level and not a.classification:
        print(f"note: classification '{level}' kept from {src.name}")
    sb = out.with_name(out.stem + "-storyboard.json")
    sb.write_text(json.dumps({"classification": level, "converted": True, "slides": story},   # the source's own
                             indent=1, ensure_ascii=False))          # headlines are kept: label headlines become ADVICE
    print(f"CONVERTED {len(slides)} slides from {src.name} -> {sb}")
    for line in report:
        print("  " + line)
    for f in fixes:
        print("  FIX " + f)
    if a.build:
        r = subprocess.run([sys.executable, str(TOOLS / "build_deck.py"), "build", str(sb), "--out", str(out), "--no-tokens"],
                           capture_output=True, text=True)
        print(r.stdout.strip() or r.stderr.strip()[-600:])
        if out.exists():
            import tokens as TK                              # the model wrote nothing: the converter made the storyboard
            print(TK.report(out, "", "\n".join(report + fixes) + r.stdout, "converted"))
        sys.exit(r.returncode)


if __name__ == "__main__":
    main()
