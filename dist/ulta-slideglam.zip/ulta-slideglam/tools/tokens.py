"""The RESULT line: what is measured, and the efficiency estimate - labelled as one (v140).

Measured  = ULTA Standards Match (the checks recorded for this exact file, tools/checks.py) and the time the tool took
            (its own run, wall clock).
Estimated = efficiency (fewer tokens and credits) versus a modeled baseline - not the chat's real usage: the sandbox cannot see
            the chat's token counts or its billing.
  With the skill  = what the model wrote (storyboard / spec / edit command) + what it read back (the tool's short
                    output) + 60 for the command line.
  Without         = the python-pptx code a model would write to produce the same file, counted from the finished file
                    (every slide, shape, paragraph, table cell, chart point and picture), with no retries, no rendered
                    previews and no fixing rounds - a conservative baseline. For an edit, without = regenerating the deck.
  Credits         = messages x the rate in credits.json (an ASSUMED 10 a message until an admin sets the workspace's
                    rate) + optional per-1M-token rates; 1 message with the skill, the rate card's baseline messages
                    without it (3 for a build: a first try and two fixing rounds).
Tokens are counted as characters / 4. `python tools/tokens.py --explain [file]` prints the method and that file's numbers.
"""
import json, os, re
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I

CHARS_PER_TOKEN = 4


def count(text):
    return max(1, round(len(text or "") / CHARS_PER_TOKEN))


def fewer(used, base):
    """How much smaller used is than base, in whole percent: at most 99, since a build always uses some tokens
    (a dashboard from one command came to 99.7%, which rounded to an impossible 100%)."""
    return min(99, max(0, round(100 * (1 - used / base)))) if base else 0


def _shapes(shapes):
    for sh in shapes:
        if sh.shape_type == 6:
            yield from _shapes(sh.shapes)
        else:
            yield sh


def baseline(pptx):
    """Tokens of hand-written python-pptx code that would build this file."""
    from pptx import Presentation
    prs = Presentation(str(pptx))
    t = 120                                                     # imports, open template, save
    for s in prs.slides:
        t += 45                                                 # add slide, pick layout
        for sh in _shapes(s.shapes):
            t += 40                                             # create + position + size
            if getattr(sh, "has_table", False) and sh.has_table:
                cells = [c for r in sh.table.rows for c in r.cells]
                t += 30 + 14 * len(cells) + sum(count(c.text) for c in cells)
            elif getattr(sh, "has_chart", False) and sh.has_chart:
                pts = sum(len(list(se.values)) for se in sh.chart.plots[0].series)
                t += 160 + 8 * pts
            elif sh.shape_type == 13:
                t += 25
            elif sh.has_text_frame:
                for p in sh.text_frame.paragraphs:
                    if p.text.strip():
                        t += 22 + count(p.text)                 # paragraph, run, font name/size/colour, text
        if s.has_notes_slide and s.notes_slide.notes_text_frame.text.strip():
            t += 15 + count(s.notes_slide.notes_text_frame.text)
    return t


def estimate(pptx, model_wrote="", tool_said="", command_tokens=60):
    used = count(model_wrote) + count(tool_said) + command_tokens
    base = baseline(pptx)
    return {"with_skill": used, "without": base, "saving_pct": fewer(used, base)}


def rates():
    """credits.json at the skill root: the admin's rate card + baseline messages (never guessed)."""
    try:
        return json.loads((Path(__file__).resolve().parent.parent / "credits.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def baseline_msgs(action):
    return int(((rates().get("baseline_messages_without_skill") or {}).get(action)) or 3)


def credits(tokens_in, tokens_out, messages):
    """Credits for this usage from the rate card, or None when no rate is configured."""
    r = rates()
    cpm, ci, co = r.get("credits_per_message"), r.get("credits_per_1m_input_tokens"), r.get("credits_per_1m_output_tokens")
    if cpm is None and ci is None and co is None:
        return None
    return (messages * (cpm or 0)) + tokens_in / 1e6 * (ci or 0) + tokens_out / 1e6 * (co or 0)


CODES = {"built": "b", "edited": "e", "converted": "c", "one-pager": "o", "own infographic": "i", "diagram": "d",
         "translated": "t"}
NAMES = {v: k for k, v in CODES.items()}
PROP = "TokenLog"                                               # in the file itself: travels with downloads and re-uploads


def read_log(pptx):
    """[(code, with, without)] from the file's TokenLog property: "b448/3998,e117/3998"."""
    import docprops as DP
    try:
        raw = DP.read_props(pptx)[1].get(PROP) or ""
        out = []
        for part in raw.split("|")[-1].split(","):
            if part[:1].isalpha() and "/" in part:
                w, wo = part[1:].split("/")
                out.append((part[0], int(w), int(wo)))
        return out
    except Exception:
        return []


def write_log(pptx, log):
    import docprops as DP
    tw, two = sum(x[1] for x in log), sum(x[2] for x in log)
    body = ",".join(f"{c}{w}/{wo}" for c, w, wo in log)
    while len(body) > 200 and "," in body:                      # Office keeps text properties short: drop the oldest turns
        body = body.split(",", 1)[1]
    DP.write_props(pptx, custom={PROP: f"{tw}/{two}|{body}"})
    return tw, two


def standards(path=None, said=""):
    """'ULTA Standards Match 100% (9/9 checks)' - computed only from the checks recorded for this exact file
    (tools/checks.py: <file>.checks.json, bound to the file's content). No current record: 'not validated'."""
    import checks
    return checks.summary(path)


def took():
    """Seconds this tool has run (its process, wall clock): measured. None where the system does not say."""
    try:
        with open("/proc/self/stat") as f:
            start = float(f.read().rsplit(")", 1)[1].split()[19]) / os.sysconf("SC_CLK_TCK")
        with open("/proc/uptime") as f:
            return max(0.0, float(f.read().split()[0]) - start)
    except Exception:
        return None


VERB = {"edited": "edited", "translated": "translated", "converted": "converted"}


def credit_line(prefix, w_tok, wo_tok, w_msg, wo_msg, note="", std="", secs=None, verb="built"):
    """ULTA Standards Match N% (checks) · built in N s · Estimated efficiency versus modeled baseline: x% fewer tokens,
    y% fewer credits (assumed rate) - not billing data. The measured parts first, the estimate labelled as one (v140)."""
    cw, cwo = credits(0, w_tok, w_msg), credits(0, wo_tok, wo_msg)
    tpct = fewer(w_tok, wo_tok)
    if cwo:
        cred = f", {round(100 * max(0, cwo - (cw or 0)) / cwo)}% fewer credits" + (" (assumed rate)" if rates().get("rate_is_assumed", True) else "")
    else:
        cred = " (credits: no rate in credits.json)"
    parts = ([std] if std else []) + ([f"{verb} in {max(1, round(secs))} s"] if secs is not None else [])
    parts.append(f"Estimated efficiency versus modeled baseline: {tpct}% fewer tokens{cred} - not billing data{note}")
    return f"{prefix}: " + " · ".join(parts)


def line(est, note="", std=""):
    return credit_line(f"RESULT this turn ({est['action']})", est["with_skill"], est["without"], 1,
                       baseline_msgs(est["action"]), note, std, est.get("took_s"), VERB.get(est["action"], "built"))


def total_line(log, tw, two, std=""):
    wo_msg = sum(baseline_msgs(NAMES.get(c, "built")) for c, _, _ in log)
    return credit_line(f"RESULT this file so far ({len(log)} turns)", tw, two, len(log), wo_msg, std=std)


def assumptions(action):
    """What the estimate assumes, recorded with it so it can be audited."""
    r = rates()
    return {"method": "estimate: modeled baseline, characters / 4 a token - not the chat's measured usage",
            "chars_per_token": CHARS_PER_TOKEN, "messages_with_skill": 1, "messages_without": baseline_msgs(action),
            "credits_per_message": r.get("credits_per_message"), "rate_is_assumed": bool(r.get("rate_is_assumed", True))}


def record(pptx, est, action):
    """Add the estimate, what it assumes and the measured time to the latest entry of <file>.audit.json."""
    p = Path(str(pptx) + ".audit.json")
    try:
        d = json.loads(p.read_text()) if p.exists() else []
        if isinstance(d, list) and d and isinstance(d[-1], dict):
            d[-1]["token_estimate"] = dict(est, action=action, **assumptions(action))
            p.write_text(json.dumps(d, indent=1))
    except Exception:
        pass


def report(pptx, model_wrote, tool_said, action, note=""):
    """Estimate this turn, add it to the file's own token log, and return the lines to print: this turn, and the
    running total when the file has been through more than one turn (create, then edits)."""
    try:
        est = estimate(pptx, model_wrote, tool_said)
        est["action"] = action; secs = took()
        if secs is not None:
            est["took_s"] = round(secs, 1)
        est["baseline_label"] = ("if the chat rebuilt the whole deck to make the change" if action in ("edited", "translated")
                                 else "writing the file directly")
        record(pptx, est, action)
        log = read_log(pptx) + [(CODES.get(action, "x"), est["with_skill"], est["without"])]
        tw, two = write_log(pptx, log)
        std = standards(pptx, tool_said)
        lines = [line(est, note, std)]
        if len(log) > 1:
            lines.append(total_line(log, tw, two, std))
        return "\n".join(lines)
    except Exception as e:                                      # never block a delivery over an estimate
        return f"STANDARDS & EFFICIENCY estimate unavailable ({e.__class__.__name__})"


def report_page(code_files, model_wrote, tool_said, action, std=None, out=None):
    """RESULT line for a page or document (dashboard, whiteboard, architecture view, Word file): the score from the
    checks recorded for `out`."""
    try:
        base = 120 + sum(count(Path(f).read_text(encoding="utf-8", errors="ignore")) for f in code_files)
        used = count(model_wrote) + count(tool_said) + 60
        return credit_line(f"RESULT this turn ({action})", used, base, 1, baseline_msgs(action),
                           std=std or standards(out), secs=took())
    except Exception as e:
        return f"STANDARDS & EFFICIENCY estimate unavailable ({e.__class__.__name__})"


def explain(path=None):
    """How the RESULT line's figures are made, and this file's own numbers (the latest turn in <file>.audit.json)."""
    r = rates(); a = assumptions("built")
    out = ["How the RESULT line is made",
           "  Measured   ULTA Standards Match: the checks recorded for this exact file (<file>.checks.json) - 100% means every check ran",
           "             and passed. The time: the tool's own run, wall clock.",
           "  Estimated  efficiency versus a modeled baseline (fewer tokens, fewer credits) - not the chat's real usage or billing (the sandbox cannot",
           "             see either).",
           f"    with the skill   what the model wrote (storyboard, spec or edit) + the tool's output it read back + 60, at {CHARS_PER_TOKEN} characters a token",
           "    baseline         the python-pptx code a model would write for the same file, counted from the finished file: 120, + 45 a slide,",
           "                     + 40 a shape, + 22 and its words a paragraph, + 14 and its words a table cell, + 160 and 8 a point a chart,",
           "                     + 25 a picture - no retries, previews or fixing rounds (conservative); an edit's baseline is rebuilding the deck",
           f"    credits          messages x {r.get('credits_per_message')} a message"
           + (" (ASSUMED until an admin sets the workspace's rate in credits.json)" if a["rate_is_assumed"] else " (credits.json)")
           + f"; 1 message with the skill, {a['messages_without']} for a build without it (the rate card's baseline_messages_without_skill)"]
    if path:
        try:
            d = json.loads(Path(str(path) + ".audit.json").read_text())
            e = next(x["token_estimate"] for x in reversed(d) if isinstance(x, dict) and x.get("token_estimate"))
            w, wo, m = e["with_skill"], e["without"], e.get("messages_without", 3)
            cw, cwo = credits(0, w, 1), credits(0, wo, m)
            out.append(f"  This file  {e['action']}: {w:,} tokens with the skill, {wo:,} for the baseline -> {e['saving_pct']}% fewer"
                       + (f"; credits {cw:g} vs {cwo:g} ({m} messages)" if cwo else "") + (f"; took {e['took_s']} s" if e.get("took_s") is not None else ""))
        except Exception:
            out.append("  This file  no estimate recorded for it (built before v140, or not by this skill)")
    out.append("  To measure instead: run the same request with and without the skill and read both from the workspace's usage report;")
    out.append("  then set credits_per_message, rate_is_assumed: false and baseline_messages_without_skill in credits.json.")
    return "\n".join(out)


if __name__ == "__main__":
    if "--explain" in sys.argv:
        rest = [x for x in sys.argv[1:] if x != "--explain"]
        print(explain(rest[0] if rest else None))
    else:
        print(__doc__)
