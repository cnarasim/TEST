"""Chat edits to a finished deck: no rebuild, no slide reading, one short line of output.

  python tools/edit_deck.py find  Deck.pptx "old words"            # IDs of the slots containing them (or --slide 3)
  python tools/edit_deck.py apply Deck.pptx --set "3.12=New text" --set "5.4.r2c1=Done"
  python tools/edit_deck.py apply Deck.pptx --replace "Q3=>Q4"     # every slot containing the old words
  python tools/edit_deck.py apply Deck.pptx --order 1,3,2,5        # reorder; slides left out are deleted

IDs are <slide>.<shape id>[.r<row>c<col>]; "-" empties a slot. Text goes into the existing template shape with
ulta_text.set_text (font/size/colour kept, no new text boxes). Then fix_deck.py re-fits and validates.
"""
import argparse, json, re, subprocess, sys
from pathlib import Path

from pptx import Presentation

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
from ulta_text import set_text  # noqa: E402


def sidecar(p):
    return Path(str(p) + ".ulta.json")


def walk(shapes):
    for sh in shapes:
        if sh.shape_type == 6:                                   # group
            yield from walk(sh.shapes)
        else:
            yield sh


def slots(slide, i):
    """(id, shape name, text_frame) for every text slot on a slide, in z-order."""
    for sh in walk(slide.shapes):
        sid = sh.shape_id
        if getattr(sh, "has_table", False) and sh.has_table:
            for r, row in enumerate(sh.table.rows, 1):
                for c, cell in enumerate(row.cells, 1):
                    if not cell.is_spanned:
                        yield f"{i}.{sid}.r{r}c{c}", label(slide, sh.name, cell.text_frame, f"r{r}c{c}"), cell.text_frame
        elif sh.has_text_frame:
            yield f"{i}.{sid}", label(slide, sh.name, sh.text_frame), sh.text_frame


def label(slide, sh_name, tf, r_c=""):
    """Plain-English slot name (template shape names are Czech/internal)."""
    if r_c:
        return "Table " + r_c
    n = sh_name.lower()
    if tf.text.strip() and tf.text.strip().split("\n")[0] == headline(slide):
        return "Headline"
    for k, v in (("diagram box", "Diagram box"), ("zone title", "Diagram zone"), ("diagram label", "Arrow label"),
                 ("title", "Title"), ("subtitle", "Subtitle")):
        if k in n:
            return v
    return "Text"


def headline(slide):
    for sh in slide.shapes:
        if sh.is_placeholder and sh.has_text_frame and sh.text_frame.text.strip():
            return sh.text_frame.text.strip().split("\n")[0]
    return next((sh.text_frame.text.strip().split("\n")[0] for sh in walk(slide.shapes)
                 if sh.has_text_frame and sh.text_frame.text.strip()), "")


def set_lines(tf, new):
    """Same number of lines as before: change each paragraph's text in place, so every line keeps its own bullet,
    level and style. Otherwise the template's set_text (first paragraph's style)."""
    paras = list(tf.paragraphs)
    lines = new.split("\n")
    if new and len(lines) == len(paras) and all(p.runs for p in paras):
        for p, line in zip(paras, lines):
            if p.text != line:
                runs = p.runs
                runs[0].text = line
                for r in runs[1:]:
                    r._r.getparent().remove(r._r)
        return
    set_text(tf, new)


def texts(deck):
    """{id: text} for every non-empty text slot."""
    prs = Presentation(str(deck))
    return {sid: tf.text.replace("\u00a0", " ") for i, s in enumerate(prs.slides, 1) for sid, _, tf in slots(s, i)
            if tf.text.strip()}                         # (a non-breaking space keeps last words together: match as a space)


def find(deck, query=None, slide=None):
    """Compact lookup: the IDs of slots containing `query` (or every slot of one slide). One line each, text cut at 70."""
    rows = []
    for sid, txt in texts(deck).items():
        if slide is not None and sid.split(".")[0] != str(slide):
            continue
        if query and query.lower() not in txt.lower():
            continue
        rows.append(f"{sid} | {txt.replace(chr(10), ' / ')[:70]}")
    return rows


def apply(deck, sets, out, order_override=None, action=None, before_check=None, replace=None, text=None):
    """sets: ["ID=new text"]; replace: ["old=>new"] (every slot containing old); text: {ID: new} (translation)."""
    import plain                                         # new text in plain punctuation (no em dashes)
    text = {k: plain.text(v) for k, v in dict(text or {}).items()}
    order = dict(order_override or {})
    for s in sets or []:
        k, _, v = s.partition("=")
        text[k.strip()] = plain.text(v.replace("\\n", "\n"))
    if replace:
        cur = texts(deck)
        for r in replace:
            old, _, new = r.partition("=>"); new = plain.text(new)
            for sid, txt in cur.items():
                if old and old in txt:
                    text[sid] = text.get(sid, txt).replace(old, new)
    prs = Presentation(str(deck))
    index = {sid: tf for i, s in enumerate(prs.slides, 1) for sid, _, tf in slots(s, i)}
    done, unknown, changed = 0, [], []
    for sid, val in text.items():
        tf = index.get(sid)
        if tf is None:
            unknown.append(sid); continue
        new = "" if val.strip() == "-" else val
        if new != tf.text.replace("\u00a0", " "):
            set_lines(tf, new); done += 1; changed.append(sid)
    # slide order / deletes
    import layoutmeta; layoutmeta.restore(deck)          # an uploaded deck has no sidecar: use the in-file record
    meta = json.loads(sidecar(deck).read_text()) if sidecar(deck).exists() else {}
    n = len(prs.slides)
    keep = [i for i in range(1, n + 1) if order.get(i, -1) != 0]
    pos = {i: order.get(i) or i for i in keep}
    new_order = sorted(keep, key=lambda i: (pos[i], 0 if i in order else 1, i))
    lst = prs.slides._sldIdLst
    ids = list(lst)
    if new_order != list(range(1, n + 1)):
        for i in range(1, n + 1):
            if i not in keep:
                prs.part.drop_rel(ids[i - 1].rId)
        for el in ids:
            lst.remove(el)
        for i in new_order:
            lst.append(ids[i - 1])
        remap = {old: k for k, old in enumerate(new_order, 1)}
        new_meta = {}
        for key, v in meta.items():
            if key in ("source_mapping", "slide_revisions", "ways") and isinstance(v, dict):   # {"<slide>": ...}
                new_meta[key] = {str(remap[int(i)]): x for i, x in v.items() if int(i) in remap}
            elif key == "typeset" and isinstance(v, dict):
                new_meta[key] = dict(v, sources={str(remap[int(i)]): x for i, x in (v.get("sources") or {}).items()
                                                  if int(i) in remap},
                                     **{k: sorted(remap[i] for i in v.get(k) or [] if i in remap) for k in ("exempt", "component")})
            elif isinstance(v, list) and v and isinstance(v[0], dict):     # [{"slide": n, ...}]
                new_meta[key] = [dict(e, slide=remap[e["slide"]]) for e in v if e.get("slide") in remap]
            elif isinstance(v, list):                     # slide-number lists
                new_meta[key] = sorted(remap[i] for i in v if i in remap)
            elif key == "a11y":                           # keyed by PowerPoint slide id: unaffected by reordering
                new_meta[key] = v
            else:
                new_meta[key] = v
        meta = new_meta
    out = Path(out or deck)
    import slide_package as SP
    before = SP.read(deck) if Path(deck).exists() else {}
    before_slides = [before[p] for p in SP.slides(before)] if before else []
    import atomic, shutil
    in_place = out.resolve() == Path(deck).resolve()
    with atomic.build_lock(out), atomic.staged(out, keep=[deck], fresh=not in_place) as work:   # edited and checked out of
        if Path(str(deck) + ".audit.json").exists():                                          # sight: an edit the time limit
            shutil.copyfile(str(deck) + ".audit.json", str(work) + ".audit.json")              # cuts off leaves the deck as it was
        atomic.save(prs, work)
        import sections
        sections.normalize(work)                   # deleted / moved slides: keep the section list consistent
        import data_slides
        data_slides.fix_chart_files(work)          # a deck from v139 or earlier: chart axis ids PowerPoint reads
        if before_check:
            before_check(work)
        sidecar(work).write_text(json.dumps(meta))
        layoutmeta.save(work)
        what = action or (f"edited: {done} text slot(s)" + ("" if new_order == list(range(1, n + 1)) else f", slides reordered {new_order}"))
        r = subprocess.run([sys.executable, str(TOOLS / "fix_deck.py"), str(work), "--out", str(work), "--action", what, "--verbose"],
                           capture_output=True, text=True)
        held, checked = "NOT WRITTEN" in r.stdout, "STAMP:" in r.stdout
        if not checked:                            # placeholder text left, or the check did not finish: nothing new
            for f in [work, *(Path(str(work) + e) for e in atomic.RECORDS)]:     # where deliverables go
                f.unlink(missing_ok=True)
    lines = r.stdout.replace(str(work.parent), str(out.resolve().parent)).splitlines()
    overall = next((l.split(":", 1)[1].strip() for l in lines if l.startswith("OVERALL")), "validator did not run")
    problems = [l.strip() for l in lines if l.strip().startswith(("FAIL", "STILL TOO LONG", "SHRUNK HARD"))
                or "SHRUNK HARD" in l or re.match(r"\s*\|?\s*FAIL", l)]
    moved = "" if new_order == list(range(1, n + 1)) else f", slides now {len(new_order)} (order {new_order})"
    why = "template placeholder text left" if held else \
        "the check did not finish: " + (r.stderr.strip().splitlines() or ["no output"])[-1][:120]
    said = [f"EDITED {done} text slot(s){moved} | OVERALL: {overall} | FILE: {out}" if checked else
            f"NOT WRITTEN - {why} | {out} " + ("is unchanged" if in_place else "was not written")]
    said += ["  " + p.replace(" and rebuild", "") for p in problems[:8]]
    if unknown:
        said.append(f"  unknown IDs (skipped): {', '.join(unknown[:10])}")
    ways = meta.get("ways") if checked and new_order != list(range(1, n + 1)) and not meta.get("gallery") else None
    if isinstance(ways, dict):                       # moved next to a slide told the same way (a pair that sat together
        import storyline as SL                       # before, in that order, may be one carrying the other on)
        for k in range(1, len(new_order)):
            w = ways.get(str(k))
            if w and w == ways.get(str(k + 1)) and new_order[k] != new_order[k - 1] + 1:
                said.append(f"  NOTE slides {k} and {k + 1} now tell their story the same way (both {SL.WORDS.get(w, w)}) - "
                            f"two in a row read as one point made twice: move one, or show slide {k + 1} another way "
                            "(slide_options.py)")
    print("\n".join(said))
    if not before_check and checked:                         # translation: the model wrote every text, not a short command
        import tokens as TK
        asked = " ".join((sets or []) + (replace or []) + [str(order_override or "")])
        hit = sorted({int(k.split(".")[0]) for k in changed})
        n_now = len(new_order)
        after = SP.read(out)                                 # what really changed, byte for byte, after the repair pass
        moved = [k for k, p in enumerate(SP.slides(after), 1) if k > len(before_slides) or after[p] != before_slides[k - 1]]
        if hit and new_order == list(range(1, n + 1)) and set(moved) <= set(hit):
            note = (f"; only slide{'s' if len(hit) > 1 else ''} {', '.join(map(str, hit))} changed, "
                    f"the other {n_now - len(hit)} untouched")
        elif hit and new_order == list(range(1, n + 1)):
            note = (f"; slides changed: {', '.join(map(str, moved))} (the repair pass also re-fitted "
                    f"{', '.join(str(k) for k in moved if k not in hit)})")
        elif new_order != list(range(1, n + 1)):
            note = "; slides reordered in place, nothing rebuilt"
        else:
            note = ""
        print(TK.report(out, asked + " find " + " ".join(sets or []), "\n".join(said), "edited", note))
    return 0 if r.returncode == 0 else 1


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("find"); f.add_argument("deck"); f.add_argument("query", nargs="?"); f.add_argument("--slide", type=int)
    a = sub.add_parser("apply"); a.add_argument("deck")
    a.add_argument("--set", action="append"); a.add_argument("--replace", action="append"); a.add_argument("--out")
    a.add_argument("--order", help="new slide order, e.g. 1,3,2,5 (slides left out are deleted)")
    x = ap.parse_args()
    if x.cmd == "find":
        rows = find(Path(x.deck), x.query, x.slide)
        print("\n".join(rows[:40]) or "no match")
    else:
        order = None
        if x.order:
            seq = [int(v) for v in x.order.split(",")]
            n = len(Presentation(str(x.deck)).slides)
            order = {i: (seq.index(i) + 1 if i in seq else 0) for i in range(1, n + 1)}
        sys.exit(apply(Path(x.deck), x.set, x.out, order, replace=x.replace))


if __name__ == "__main__":
    main()
