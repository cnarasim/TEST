"""One deck, every audience: executive version, speaker notes, PDF / Word / e-mail exports.

    python tools/audience.py exec   Deck.pptx --out /mnt/data/out/Deck-exec [--keep 1,3,6]
        -> <out>-onepager.pptx  executive one-pager (kit 'exec' layout) from the deck's own headlines and numbers;
                                the generated <out>-onepager.md can be edited and rebuilt with --md
        -> <out>.pptx           (with --keep) the deck reordered: kept slides first in a "Main" section, the rest in
                                an "Appendix" section (PowerPoint sections: collapse the appendix when presenting)
    python tools/audience.py notes  Deck.pptx --minutes 20 [--out Deck-notes.pptx]
        -> talking points and a time budget on every slide (existing notes are kept, below)
    python tools/audience.py export Deck.pptx [--pdf] [--docx] [--email]     (no flag = all three)
        -> Deck.pdf handout, Deck-narrative.docx (headline = heading, text, tables, notes), Deck-email.txt
Every output is scanned for sensitive data; decks are re-stamped.
"""
import argparse, re, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))

NUM = re.compile(r"[$€£]?\d[\d,]*(?:\.\d+)?\s?(?:%|[KMB]\b|million|billion|min|days|hrs)?")
FOOT = re.compile(r"\|\s*(proprietary|confidential|internal|public|restricted)", re.I)


def read_deck(path):
    """[{n, title, lines, table_rows, notes}] with the headline as title."""
    from pptx import Presentation
    import brand as B
    b = B.current()
    out = []
    for i, s in enumerate(Presentation(str(path)).slides, 1):
        title, lines, tables = None, [], []
        shapes = sorted(s.shapes, key=lambda sh: ((sh.top or 0), (sh.left or 0)))
        for sh in shapes:
            if getattr(sh, "has_table", False) and sh.has_table:
                tables.append([[c.text.strip() for c in r.cells] for r in sh.table.rows]); continue
            if getattr(sh, "has_chart", False) and sh.has_chart:
                d = sh._element.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}cNvPr").get("descr")
                lines.append(d or "Chart"); continue
            if not sh.has_text_frame or not sh.text_frame.text.strip():
                continue
            t = sh.text_frame.text.strip()
            if FOOT.search(t) or re.fullmatch(r"\d{1,3}", t):
                continue
            if title is None and (b.is_headline(sh._element) or sh.is_placeholder):
                title = t.replace("\n", " ")
            else:
                lines += [x.strip() for x in t.split("\n") if x.strip()]
        if title is None and lines:
            title = lines.pop(0)
        notes = s.notes_slide.notes_text_frame.text.strip() if s.has_notes_slide else ""
        out.append({"n": i, "title": title or f"Slide {i}", "lines": lines, "tables": tables, "notes": notes})
    return out


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


# ------------------------------------------------------------------------------------------------ executive
UNIT = re.compile(r"[%$€£KMB]|million|billion|min|days|hrs|hours|weeks|\bx\b")
FIG = r"[+\-−]?[$€£]?\d[\d,.]*\s?(?:%|[KMB]|x|hrs|days|min|sec|pts)?(?:\s+of\s+\d+)?"
STATUS = re.compile(r"(?i)^\s*(?:overall\s+)?(?:status|rag)\s*[:\-–]\s*(green|amber|red|on track|at risk|off track)\b|"
                    r"^\s*(on track|at risk|off track)\s*$")
RISKY = re.compile(r"(?i)\b(risks?|issues?|behind|delay(?:ed|s)?|blockers?|at risk|off track|concerns?|challenges?)\b")
NEXT = re.compile(r"(?i)\b(next steps?|recommendations?|actions?|roadmap|plan)\b")


def _clip(t, n):
    t = re.sub(r"\s+", " ", str(t)).strip()
    return t if len(t) <= n else t[:n].rsplit(" ", 1)[0].rstrip(",;:-–") + "…"


def _figures(s):
    """(value, label) pairs a slide states: its headline's figure, big-number tiles ("74%\nfaster builds", the column
    header added when there is one), or a short "74% faster builds" line. Dates and list numbers are not figures."""
    out = []
    def add(v, label):
        v, label = v.strip(), re.sub(r"\s+", " ", label).strip(" ,:;-–")
        if v and label and (UNIT.search(v) or re.fullmatch(r"\d+(?:\s+of\s+\d+)?", v)) and not any(v == o[0] for o in out):
            out.append((v, _clip(label, 60)))
    m = next((m for m in NUM.finditer(s["title"]) if UNIT.search(m.group(0))), None)
    if m:
        add(m.group(0), s["title"][:m.start()] or s["title"][m.end():])
    for t in s["tables"]:
        head = t[0] if len(t) > 1 else []
        for row in t:
            for j, c in enumerate(row):
                parts = [x.strip() for x in str(c).split("\n") if x.strip()]
                if len(parts) >= 2 and re.fullmatch(FIG, parts[0]):
                    h = head[j].strip() if row is not head and j < len(head) and not re.fullmatch(FIG, head[j].strip()) else ""
                    add(parts[0], f"{h} ({parts[1]})" if h and h.lower() not in parts[1].lower() else parts[1])
    for i, ln in enumerate(s["lines"]):
        if re.fullmatch(FIG, ln) and i + 1 < len(s["lines"]):
            add(ln, s["lines"][i + 1])
        m = re.match(rf"({FIG})\s+(.{{3,60}})$", ln)
        if m and UNIT.search(m.group(1)):
            add(m.group(1), m.group(2))
    return out


def _message(s):
    """One line per slide: its headline when it states a message (5+ words), else the headline plus what it lists."""
    t = s["title"].strip()
    if len(t.split()) >= 5:
        return _clip(t, 110)
    heads = []
    for tb in s["tables"]:                          # cards ("Title\n\nline"): every card's title; a plain table: its first column
        cards = any("\n" in c for row in tb[1:] for c in row)
        heads += [c.split("\n")[0].strip() for row in tb[1:] for c in (row if cards else row[:1]) if c.strip()]
    heads = heads or s["lines"]
    heads = [h for h in heads if h and not re.fullmatch(FIG, h) and not re.match(r"(?i)\w+ chart:", h)][:3]
    return _clip(f"{t}: {', '.join(heads)}" if heads else t, 110)


def _points(s, n):
    """A slide's own points: table rows (first two cells) or its text lines."""
    rows = [r for tb in s["tables"] for r in tb[1:]]
    def row(r):
        r = [x.strip() for x in r]
        when = r[-1] if len(r) >= 3 and re.search(r"(?i)\d|q[1-4]|week|month|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec", r[-1]) and len(r[-1]) <= 20 else ""
        return ": ".join(x for x in r[:2] if x) + (f" ({when})" if when else "")
    pts = [row(r) for r in rows] if rows else s["lines"]
    return [_clip(p, 100) for p in pts if p.strip()][:n]


def exec_md(slides):
    """The deck's own facts only: status and decision appear when the deck states them, never inferred from keywords."""
    cover = slides[0]["title"] if slides else "Update"
    body = [s for s in slides[1:] if not re.fullmatch(r"(?i)thank you!?|questions\??|agenda|appendix", s["title"].strip())]
    nums, fig_slides = [], set()
    for s in body:
        f = _figures(s)
        if f and not s["lines"] and all(len(r) <= 4 for tb in s["tables"] for r in tb): fig_slides.add(s["n"])
        for v, label in f:
            if len(nums) < 3 and not any(v == n[0] for n in nums): nums.append((v, label))
    rag = next((m.group(1) or m.group(2) for s in body for ln in [s["title"]] + s["lines"] for m in [STATUS.search(ln)] if m), None)
    rag = {"green": "Green", "on track": "Green", "amber": "Amber", "at risk": "Amber", "red": "Red", "off track": "Red"}.get((rag or "").lower())
    risk_sl = [s for s in body if RISKY.search(s["title"])]
    next_sl = [s for s in body if NEXT.search(s["title"]) and s not in risk_sl]
    risks = [p for s in risk_sl for p in _points(s, 3)][:3]
    steps = [p for s in next_sl for p in _points(s, 4)][:4]
    msgs = [_message(s) for s in body if s not in risk_sl and s not in next_sl and s["n"] not in fig_slides][:4]
    dec = next((ln for s in body for ln in [s["title"]] + s["lines"]
                if re.search(r"(?i)\b(decision needed|decide|approve|approval|sign[- ]?off)\b", ln)), None)
    md = [f"# {cover}"] + ([f"Overall status: {rag}"] if rag else []) + [""]
    if nums:
        md += ["## Key numbers", *[f"- {v}: {label}" for v, label in nums], ""]
    if msgs:
        md += ["## Key messages", *[f"- {m}" for m in msgs], ""]
    if risks:
        md += ["## Challenges", *[f"- {r}" for r in risks], ""]     # not "Risks"/"Issues": those headings make the kit's owner/date table
    if steps:
        md += ["## Next steps", *[f"- {x}" for x in steps], ""]
    if dec:
        md += ["## Decision needed", _clip(dec, 160), ""]
    return "\n".join(md)


def build_onepager(md_path, out, template="exec"):
    kit = TOOLS.parent / "modules" / "ultabranddeliverables" / "scripts" / "ulta.py"
    code, log = run([sys.executable, "-I", str(kit), "infographic", str(md_path), "--template", template, "--out", str(out)])
    if code:
        sys.exit("kit failed: " + log[-400:])
    files = [str(p) for p in (out.with_suffix(".pptx"), out.with_suffix(".svg"), out.with_suffix(".html")) if p.exists()]
    _, conf = run([sys.executable, str(TOOLS / "ulta_conform.py"), *files, "--keep-sizes"])
    run([sys.executable, str(TOOLS / "nativize.py"), files[0]])
    import a11y, compliance, stamp
    a11y.fix(out.with_suffix(".pptx"), flat_all=True)       # the kit draws flat: no theme shadow
    blk = [x for x in compliance.scan(files) if x["severity"] == "BLOCK"]
    import brand_colours
    off = brand_colours.gate(files, conform=False)            # conformed above: zero deviation left?
    res = "NEEDS CORRECTION" if blk or "FAIL" in conf or off else "READY"
    stamp.stamp(out.with_suffix(".pptx"), "executive one-pager", res)
    return res


def cmd_exec(a):
    slides = read_deck(a.deck)
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    if out.suffix.lower() == ".pptx": out = out.with_suffix("")          # "Name.pptx" and "Name" both work
    one = out.with_name(out.name + "-onepager")
    md = Path(a.md) if a.md else one.with_suffix(".md")
    if not a.md:
        md.write_text(exec_md(slides))
    res = build_onepager(md, one)
    print(f"EXEC one-pager {res} | {one.with_suffix('.pptx')} | edit {md} and re-run with --md to change wording")
    if a.keep:
        keep = [int(x) for x in a.keep.split(",")]
        import edit_deck, sections
        order = {n: (keep.index(n) + 1 if n in keep else len(keep) + n) for n in range(1, len(slides) + 1)}
        edit_deck.apply(Path(a.deck), [], out.with_suffix(".pptx"), order, f"executive version: main {keep}, rest in appendix")
        sections.set_sections(out.with_suffix(".pptx"), [("Main", list(range(1, len(keep) + 1))),
                                                         ("Appendix", list(range(len(keep) + 1, len(slides) + 1)))])
        print(f"  deck: {out.with_suffix('.pptx')} - Main = slides 1-{len(keep)}, Appendix = {len(keep) + 1}-{len(slides)}")


# ------------------------------------------------------------------------------------------------ notes
def cmd_notes(a):
    from pptx import Presentation
    slides = read_deck(a.deck)
    weights = [0.3 if i in (0, len(slides) - 1) and len(s["lines"]) < 3 else 1 + len(" ".join(s["lines"]).split()) / 60
               for i, s in enumerate(slides)]
    total = sum(weights)
    prs = Presentation(str(a.deck))
    for s, w, sl in zip(slides, weights, prs.slides):
        mins = a.minutes * w / total
        pts = [s["title"]] + [ln for ln in s["lines"] if len(ln.split()) > 2][:3]
        if s["tables"]:
            pts.append(f"Table: {len(s['tables'][0]) - 1} rows - call out the one that matters")
        talk = [f"Time: about {mins:.1f} min" if mins >= 1 else f"Time: about {int(mins * 60)} sec", "Talking points:"] + [f"- {p}" for p in pts]
        nf = sl.notes_slide.notes_text_frame
        old = nf.text.strip()
        if not old.startswith("Time: about"):
            nf.text = "\n".join(talk) + ("\n\n" + old if old else "")
    out = Path(a.out or a.deck)
    import atomic
    atomic.save(prs, out)
    import plain; plain.clean(out)                       # plain punctuation: no em dashes in what a reader sees
    import stamp
    stamp.stamp(out, f"speaker notes for a {a.minutes:g}-minute slot")
    print(f"NOTES {len(slides)} slides, {a.minutes:g} min | {out} (existing notes kept under the talking points)")


# ------------------------------------------------------------------------------------------------ exports
def cmd_export(a):
    import compliance, docprops
    deck = Path(a.deck)
    want = {k for k in ("pdf", "docx", "email") if getattr(a, k)} or {"pdf", "docx", "email"}
    slides = read_deck(deck)
    _, props = docprops.read_props(deck)
    cls = str(props.get("Classification") or "").strip()
    label = (cls if cls.lower() not in ("", "unset", "none", "unknown") else "") or docprops.purview_label(props) or ""
    body = [s for s in slides[1:] if not re.match(r"(?i)^\s*(thank you|thanks|questions\??)\s*!?\s*$", s["title"])]
    for s in body:                                   # the export reads like prose: no talk-track boilerplate, no box soup
        s["notes"] = "\n".join(l for l in s["notes"].splitlines()
                               if l.strip() and not re.match(r"(?i)^(time: about|talking points:|- table: \d+ rows|takeaway:)", l.strip()))
        if len(s["lines"]) >= 5 and not s["tables"] and all(len(l.split()) <= 3 for l in s["lines"]):
            s["lines"] = [f"Diagram (see slide {s['n']}): " + ", ".join(dict.fromkeys(s["lines"]))[:160]]
    made = []
    if "pdf" in want:
        import shutil
        soff = shutil.which("soffice") or shutil.which("libreoffice")
        if soff:
            import plain; plain.clean(deck)
            import lo; lo.convert(deck, deck.parent, "pdf", timeout=300)
            if deck.with_suffix(".pdf").exists():
                made.append(deck.with_suffix(".pdf"))
        else:
            print("  PDF: no converter here - in PowerPoint use File > Export > PDF")
    if "docx" in want:
        from docx import Document
        from docx.shared import Pt
        doc = Document()
        doc.core_properties.title = slides[0]["title"] if slides else deck.stem
        doc.add_heading(slides[0]["title"] if slides else deck.stem, 0)
        if label:                                    # the header is the Ulta letterhead, so the label goes under the title
            doc.core_properties.category = label
            r = doc.add_paragraph().add_run(f"Classification: {label}"); r.bold = True; r.font.size = Pt(9)
        for s in body:
            doc.add_heading(s["title"], 1)
            for ln in s["lines"]:
                doc.add_paragraph(ln, style="List Bullet")
            for t in s["tables"]:
                tb = doc.add_table(rows=len(t), cols=max(len(r) for r in t)); tb.style = "Table Grid"
                for r_i, r in enumerate(t):
                    for c_i, v in enumerate(r):
                        tb.cell(r_i, c_i).text = v
            if s["notes"]:
                p = doc.add_paragraph(); run_ = p.add_run(s["notes"]); run_.italic = True; run_.font.size = Pt(9)
        import atomic
        p = deck.with_name(deck.stem + "-narrative.docx"); atomic.save(doc, p)
        made.append(p)   # ULTA SlideGlam: PowerPoint only - the Word copy is plain .docx (no Word letterhead tool shipped)       # official Ulta Word template letterhead
    if "email" in want:
        lines = [f"Subject: {slides[0]['title'] if slides else deck.stem}", "",
                 "Hi all,", "", "Key points:", *[f"- {s['title']}" for s in body[:6]]]
        dec = next((ln for s in body for ln in [s["title"]] + s["lines"] if re.search(r"(?i)\b(decide|decision|approve)\b", ln)), None)
        if dec:
            lines += ["", f"Decision needed: {dec}"]
        lines += ["", f"The full deck is attached ({len(slides)} slides)." + (f" Classification: {label}." if label else ""),
                  "", "Thanks,"]
        p = deck.with_name(deck.stem + "-email.txt"); p.write_text("\n".join(lines)); made.append(p)
        import plain; plain.clean(p)
    sens = compliance.scan([str(m) for m in made if m.suffix != ".pdf"])
    print("EXPORT " + " | ".join(str(m) for m in made))
    for x in sens:
        print(f"  {x['severity']} {x['file']} {x['where']}: {x['kind']} '{x['match']}'")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("exec"); e.add_argument("deck"); e.add_argument("--out", required=True)
    e.add_argument("--keep"); e.add_argument("--md")
    n = sub.add_parser("notes"); n.add_argument("deck"); n.add_argument("--minutes", type=float, default=15); n.add_argument("--out")
    x = sub.add_parser("export"); x.add_argument("deck")
    for f in ("pdf", "docx", "email"):
        x.add_argument("--" + f, action="store_true")
    a = ap.parse_args()
    {"exec": cmd_exec, "notes": cmd_notes, "export": cmd_export}[a.cmd](a)


if __name__ == "__main__":
    main()
