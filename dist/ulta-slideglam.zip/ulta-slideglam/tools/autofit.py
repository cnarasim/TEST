"""Auto-fit every text slot so nothing overflows, breaks mid-word or runs into a picture.

    python tools/autofit.py deck.pptx --mapping 1,2,12,... [--out fixed.pptx]

1. Content-slide headlines are widened to the full content width (same left edge and top), and so is the headline
   box of the layouts they use (PowerPoint's Reset or a new slide from the layout keeps the one-line headline).
2. The deck is measured with the bundled Circular / Playfair metrics (ulta_pptx_fit.py) and the
   artwork gate (pptx_artwork_clearance.py). A slot is a problem when:
     - headline: more than 1 line, or wider than 95% of its box
     - cover title: more than 3 lines
     - any other slot: needs more height than its box (and more lines than the template sample)
     - a single word is wider than the slot (it would break mid-word)
     - its text runs into a picture or icon more than the template sample did
3. Only problem slots shrink: headlines 2 pt per step (floor 16 pt), other text 10% per step
   (floor 7 pt). Steps 2-3 repeat until clean (max 12 rounds).
Font family, colour, alignment and every other shape stay exactly as in the template.
Exit 0 = clean; exit 1 = something still does not fit at the floor size (listed).
"""
import argparse, copy, json, subprocess, sys, zipfile
from pathlib import Path

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import validate_deck as V          # noqa: E402  (slide_parts, text_of, REF, VAL, headline_restored_copy)
import fit_headlines as FH         # noqa: E402  (rewrite: widen headline boxes)

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
NS = V.NS
HEAD_FLOOR, BODY_FLOOR, MAX_ROUNDS = 1600, 700, 12


def norm(t):
    return "".join((t or "").split())


def slots(slide_x):
    """[(element, kind)] for every text slot on a slide: shapes (recursing groups) and table cells."""
    out = []
    def walk(tree):
        for sp in tree:
            tag = etree.QName(sp).localname
            if tag == "grpSp":
                walk(sp)
            elif sp.find(".//a:tbl", NS) is not None:
                out.extend((tc, "cell") for tc in sp.iter(A + "tc"))
            elif sp.find(".//p:txBody", NS) is not None:
                out.append((sp, "shape"))
    walk(slide_x.find(".//p:cSld/p:spTree", NS))
    return out


def effective_sizes(deck):
    """{(slide_no, shape name): size in 1/100 pt} for placeholders whose runs inherit their size."""
    from pptx import Presentation
    prs = Presentation(str(deck))
    out = {}
    for i, s in enumerate(prs.slides, 1):
        for sh in s.shapes:
            if not (sh.is_placeholder and sh.has_text_frame):
                continue
            sz = None
            try:
                lp = s.slide_layout.placeholders.get(idx=sh.placeholder_format.idx)
            except Exception:
                lp = None
            for src in (lp,):
                if src is None:
                    continue
                for el in src._element.iter():
                    if el.get("sz") and etree.QName(el).localname in ("rPr", "defRPr", "endParaRPr"):
                        sz = int(el.get("sz")); break
            out[(i, sh.name)] = sz or 1800
    return out


def current_size(el, fallback):
    sizes = [int(r.get("sz")) for r in el.iter(A + "rPr") if r.get("sz")]
    return max(sizes) if sizes else fallback


def set_size(el, size):
    for r in el.iter(A + "r"):
        rpr = r.find(A + "rPr")
        if rpr is None:
            rpr = etree.Element(A + "rPr"); r.insert(0, rpr)
        rpr.set("sz", str(size))
    for e in el.iter(A + "endParaRPr"):
        e.set("sz", str(size))


def headline_names(deck, mapping):
    z, rz = zipfile.ZipFile(deck), zipfile.ZipFile(V.REF)
    rparts, _, _ = V.slide_parts(rz)
    names = {}
    for i, src in enumerate(mapping, 1):
        rx = etree.fromstring(rz.read(rparts[src - 1]))
        for sp in rx.find(".//p:cSld/p:spTree", NS):
            if V.BRAND.is_headline(sp):
                names[i] = sp.find(".//p:cNvPr", NS).get("name")
    return names


def measure(deck, mapping, work):
    """Problems: {(slide, normtext): reason}."""
    m = ",".join(map(str, mapping))
    fit = work / "fit.json"; art = work / "art.json"
    import a11y as _A
    deck = _A.stripped_copy(deck, work / "structure.pptx")     # alt text is metadata, not layout
    subprocess.run([sys.executable, str(TOOLS / "fit_runner.py"), str(V.REF), str(deck), "--mapping", m,
                    "--report", str(fit)], cwd=V.VAL.parent, capture_output=True)
    probs = {}
    try:
        rep = json.loads(fit.read_text())
    except Exception:
        return {("*", "*"): "fit checker did not run"}
    for sl in rep.get("slides") or []:
        i = sl.get("slide"); cover = mapping[i - 1] in V.COVERS; two = mapping[i - 1] in V.TITLE2
        for g in sl.get("regions") or []:
            t = g.get("text") or ""
            if not t.strip():
                continue
            lines, ref = g.get("lineCount") or 1, g.get("referenceLineCount") or 1
            widest = max((ln["rect"][2] for ln in g.get("lines") or []), default=0)
            inner_w, inner_h = g.get("innerWidthPt") or 1, g.get("innerHeightPt") or 1
            key = (i, norm(t))
            if "TOKEN_WIDER_THAN_INNER_REGION" in (g.get("risks") or []) and \
                    "TOKEN_WIDER_THAN_INNER_REGION" not in (g.get("referenceRisks") or []):
                probs[key] = "word wider than its box"
            elif not cover and norm(g.get("referenceText") or "") != norm(t) and (g.get("largestTokenWidthRatio") or 0) > 0.92 and \
                    (g.get("largestTokenWidthRatio") or 0) > 0.92 * 1.0 and len(t.split()) and \
                    "TOKEN_WIDER_THAN_INNER_REGION" not in (g.get("referenceRisks") or []) and \
                    V.MARK not in t:
                probs[key] = f"longest word fills {g['largestTokenWidthRatio']:.0%} of its box (too tight)"
            elif cover and lines > 3:
                probs[key] = f"cover title {lines} lines"
            elif two and lines > 2:
                probs[key] = f"{lines} lines (a divider or big-note line takes 2 at most)"
            elif not cover and not two and g.get("estimatedAdvanceHeightPt", 0) > inner_h + 1 and lines > ref:
                probs[key] = f"{lines} lines in a box for {ref}"
            probs.setdefault(("hl", i, norm(t)), (lines, widest / inner_w))
    hl_checks = {c["check"] for c in (rep.get("structuralFailures") or [])
                 if "xfrm" in c.get("check", "") or "framing" in c.get("check", "")}
    hl_checks |= V.flow_table_waivers(deck, mapping)
    _, ints, _ = V.picture_clearance(deck, mapping, hl_checks)
    for r_ in ints:
        probs[(r_["slide"], norm(r_["text"]))] = "runs into a picture/icon"
    return probs


def autofit(src, mapping, out):
    import atomic
    work = atomic.scratch()
    deck = work / "deck.pptx"
    diag = V.load_diag(src)
    heads = {i: n for i, n in headline_names(src, mapping).items() if i not in diag}
    edits = {i: {name: None} for i, name in heads.items() if mapping[i - 1] not in V.COVERS}
    FH.rewrite(src, deck, edits)                     # widen content-slide headlines (materialises geometry)
    FH.widen_layouts(deck)                           # and their layouts: Reset or a new slide keeps the one-line headline
    if Path(str(src) + ".ulta.json").exists():       # a11y/diagram notes travel with the working copy
        Path(str(deck) + ".ulta.json").write_text(Path(str(src) + ".ulta.json").read_text())
    inherited = effective_sizes(deck)
    changed, stuck = {}, {}
    for rnd in range(MAX_ROUNDS):
        probs = measure(deck, mapping, work)
        z = zipfile.ZipFile(deck)
        parts, _, _ = V.slide_parts(z)
        items = {n: z.read(n) for n in z.namelist()}
        infos = {n: z.getinfo(n) for n in z.namelist()}
        todo = 0
        for i, part in enumerate(parts, 1):
            if i in diag:
                continue
            x = etree.fromstring(items[part])
            dirty = False
            for el, kind in slots(x):
                t = norm(V.text_of(el))
                if not t:
                    continue
                nv = el.find(".//p:cNvPr", NS) if kind == "shape" else None
                name = nv.get("name") if nv is not None else None
                is_head = kind == "shape" and heads.get(i) == name and mapping[i - 1] not in V.COVERS
                reason = probs.get((i, t))
                if is_head:
                    lines, fill = probs.get(("hl", i, t), (1, 0))
                    if lines > 1 or fill > 0.95:
                        reason = f"headline {lines} line(s), {fill:.0%} of width"
                if not reason:
                    continue
                cur = current_size(el, inherited.get((i, name), 1800))
                floor = HEAD_FLOOR if is_head else BODY_FLOOR
                new = cur - 200 if is_head else max(int(cur * 0.9 / 50) * 50, floor)
                if new < floor or new >= cur:
                    stuck[(i, t)] = f"slide {i}: '{V.text_of(el).strip()[:50]}' - {reason} even at {cur / 100:.0f} pt: shorten it"
                    continue
                set_size(el, new); dirty = True; todo += 1
                changed[(i, t)] = (V.text_of(el).strip()[:50], cur if (i, t) not in changed else changed[(i, t)][1], new, reason)
            if dirty:
                items[part] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
        if not todo:                                   # nothing changed this round: the working copy is the result
            break
        import atomic
        with atomic.zip_out(deck) as w:
            for n, data in items.items():
                w.writestr(infos[n], data)
    import atomic
    with atomic.replacing(Path(out)) as t:
        t.write_bytes(deck.read_bytes())
    print(f"autofit: {len(changed)} slot(s) resized in {rnd + 1} round(s)")
    for (i, _), (txt, a, b, why) in sorted(changed.items()):
        hard = "   SHRUNK HARD: shorten this text and rebuild" if b < 0.75 * a else ""
        print(f"  slide {i:>2}: {a / 100:>4.0f} -> {b / 100:>4.1f} pt  {txt!r}  ({why}){hard}")
    for msg in stuck.values():
        print("  STILL TOO LONG " + msg)
    return 1 if stuck else 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck"); ap.add_argument("--mapping", required=True); ap.add_argument("--out")
    a = ap.parse_args()
    mapping = [int(x) for x in a.mapping.split(",")]
    sys.exit(autofit(Path(a.deck).resolve(), mapping, Path(a.out or a.deck).resolve()))


if __name__ == "__main__":
    main()
