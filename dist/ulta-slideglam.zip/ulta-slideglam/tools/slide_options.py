"""Other ways to show one slide of a finished deck: build each alternative, show them side by side with the slide as it
is now, and swap in the one the user picks. Only that slide changes; every other slide stays byte-identical.

  python tools/slide_options.py show    Deck.pptx --slide 5 [--more]              # what the slide holds + ideas; a chart
                                                                                  # slide gets its options written for it
  python tools/slide_options.py preview Deck.pptx --slide 5 --options opts.json --out /mnt/data/out/slide5-options
  python tools/slide_options.py apply   Deck.pptx --session /mnt/data/out/slide5-options --choice B --out /mnt/data/out/Deck-v2.pptx

opts.json: {"options": [{"id": "A", "label": "Four headline metrics", "slide": {...one storyboard slide...}}, ...]}
A chart slide's numbers live in the chart, not in its text: `show` reads them and writes 3 options built from them (ranked
lollipop, sorted bars, share donut, big numbers, sized circles, wedges, columns, a table), `--more` the next 3; preview
refuses an option that leaves out any group or value of the chart (a headline on a photo is not another way to show it).
Each option is one storyboard slide - any layout, template infographic, timeline, swimlane, process flow, retail
diagram, chart or diagram that build_deck.py makes - holding the same content as the slide it replaces: every number on the
option and no new number may appear (list numbering aside); words the slide had must stay. 2-3 options, 4 at most.
preview builds and checks each one, renders it, and writes choices.png (the slide now + each option, lettered).
apply swaps in the chosen option after checking that neither the deck nor the option changed since the preview.
"""
import argparse, json, re, shutil, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import slide_package as SP   # noqa: E402

STOP = set("a an and are as at be by for from has have in is it its of on or our the their to was we were will with "
           "this that these those than then into per vs".split())
SMALL = {str(n) for n in range(1, 11)}                       # list numbering an option may add (1-10)
C_NS = "{http://schemas.openxmlformats.org/drawingml/2006/chart}"
RATE = re.compile(r"(?i)(%|percent|pct|rate|share|ratio)")
SHOWN = re.compile(r"(?<![\w.])([+-]?)[$\u20ac\u00a3]?(\d[\d,]*(?:\.\d+)?)\s*(%|bn|[kmb])?(?![\w])", re.I)
MONTH = r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*"
DATED = re.compile(rf"(?i)^(?:\d{{4}}-\d\d(?:-\d\d)?|\d{{1,2}} {MONTH}(?: \d{{2,4}})?|{MONTH}(?: \d{{1,2}},?)?(?: \d{{2,4}})?"
                   r"|w\d{1,2}(?: \d{4})?|q[1-4](?: \d{4})?|fy ?\d{2,4}|\d{4})$")


def record(deck):
    """The deck's build record (sidecar or the copy inside the file)."""
    import layoutmeta
    layoutmeta.restore(deck)
    side = Path(str(deck) + ".ulta.json")
    try:
        return json.loads(side.read_text())
    except (OSError, ValueError):
        return {}


def source_of(deck, number, rec=None):
    rec = rec if rec is not None else record(deck)
    m = rec.get("source_mapping") or {}
    if str(number) in m:
        return m[str(number)]
    import fix_deck
    mapping, _ = fix_deck.infer_mapping(Path(deck))
    return mapping[number - 1] if number <= len(mapping) else None


def neighbours(rec, number):
    """{slide: way} for the slides on either side, from the deck's build record (storyline.py); empty for a catalogue
    deck or a record without ways."""
    ways = rec.get("ways") or {}
    if rec.get("gallery"):
        return {}
    return {i: ways[str(i)] for i in (number - 1, number + 1) if ways.get(str(i))}


def told_like(nb, way):
    """'slide 4 (items ranked by size)' when a neighbour tells its story `way`, else ''."""
    import storyline as SL
    hit = next((i for i, w in nb.items() if w == way), None)
    return f"slide {hit} ({SL.WORDS.get(way, way)})" if way and hit else ""


def layout_label(src):
    import full_template as FT
    row = next((r for r in FT.collection()["slides"] if r["source"] == src), None)
    if row:
        return f"{src} {row['name']} ({row['use']})"
    return {6: "6 drawn slide (diagram, chart, timeline, swimlane, process flow or retail diagram on the title-only "
               "layout)", 1: "1 cover", 5: "5 numbered divider", 33: "33 closing"}.get(src, str(src))


def facts(info, chrome=()):
    """(numbers, content words) of a slide's visible text; `chrome` = the layout's own label words, not content."""
    toks = SP.words(" ".join(info["text"]))
    nums = [t for t in toks if re.match(r"[+-]?\$?\d", t)]
    wordset = {t for t in toks if not re.match(r"[+-]?\$?\d", t) and len(t) > 2 and t not in STOP and t not in chrome}
    return nums, wordset


def template_words(src):
    """Words the template slide itself prints (labels such as Agenda, Category, Highlights), so a swap away from a
    layout is not taken as dropping them."""
    try:
        import brand
        ref = SP.read(brand.current().template)
        return {t for t in SP.words(" ".join(SP.inspect(ref, int(src))["text"])) if not re.match(r"[+-]?\$?\d", t)}
    except Exception:
        return set()


def chart_series(parts, chart_part):
    """[(series name, [(category, value), ...])] of a native chart, read from the chart's own data."""
    root = SP.xml(parts[chart_part])
    dated = root.find(f".//{C_NS}dateAx") is not None      # a date axis keeps day numbers (46032): read them as dates
    out = []
    for ser in root.iter(C_NS + "ser"):
        name = "".join(v.text or "" for v in ser.iterfind(f"{C_NS}tx//{C_NS}v")) or "Value"
        cats = {int(pt.get("idx")): pt.findtext(f"{C_NS}v") for pt in ser.iterfind(f"{C_NS}cat//{C_NS}pt")}
        if dated:
            import datetime as _dt
            def day(v):
                try:
                    return _dt.date(1899, 12, 30) + _dt.timedelta(days=int(float(v)))
                except (TypeError, ValueError, OverflowError):
                    return None
            ds = {i: day(v) for i, v in cats.items()}
            yrs = len({d.year for d in ds.values() if d})
            cats = {i: (f"{d.day} {d:%b}" + (f" {d:%y}" if yrs > 1 else "") if d else cats[i]) for i, d in ds.items()}
        vals = {}
        for pt in ser.iterfind(f"{C_NS}val//{C_NS}pt"):
            try:
                vals[int(pt.get("idx"))] = float(pt.findtext(f"{C_NS}v"))
            except (TypeError, ValueError):
                pass
        out.append((name, [(cats.get(i, str(i + 1)), v) for i, v in sorted(vals.items())]))
    return out


def shown_numbers(texts):
    """[(value, tolerance, is_percent)] of every number a reader sees: $10.6M = 10,600,000 give or take 50,000."""
    out = []
    for t in texts:
        for m in SHOWN.finditer(str(t)):
            sign, digits, suf = m.groups()
            mult = {"k": 1e3, "m": 1e6, "b": 1e9, "bn": 1e9}.get((suf or "").lower(), 1)
            dec = len(digits.split(".")[1]) if "." in digits else 0
            out.append(((-1 if sign == "-" else 1) * float(digits.replace(",", "")) * mult, 0.5 * 10 ** -dec * mult, suf == "%"))
    return out


def data_check(points, after_texts, after_points):
    """An option of a chart slide keeps every group and every value (as shown, within its rounding)."""
    shown = shown_numbers(after_texts) + [(v, 1e-6 * max(1.0, abs(v)), False) for _, v in after_points]
    seen = " ".join([str(t) for t in after_texts] + [str(c) for c, _ in after_points]).lower()
    gone = [str(c) for c, _ in points if str(c).lower() not in seen]
    lost = [f"{c} {v:,.4g}" for c, v in points
            if not any(abs(x - v) <= tol + 1e-9 or (pct and abs(x - 100 * v) <= tol + 1e-9) for x, tol, pct in shown)]
    probs = []
    if gone:
        probs.append("the chart's groups missing: " + ", ".join(gone[:6]))
    if lost:
        probs.append("the chart's values missing: " + ", ".join(lost[:6]))
    return probs


def show_value(v, unit, d=1):
    """$4.2M; d=2 when the values are close (4.24M and 4.23M would both read 4.2M)."""
    if unit == "%":
        return f"{v:.{d}f}".rstrip("0").rstrip(".") + "%"
    a = abs(v)
    t = (f"{v / 1e9:.{d}f}B" if a >= 1e9 else f"{v / 1e6:.{d}f}M" if a >= 1e6 else f"{v / 1e3:.{d}f}K" if a >= 1e4
         else f"{v:,.0f}" if a >= 100 else f"{v:,.1f}")
    return ("$" if unit == "$" else "") + t


KINDS = ["lollipop", "bar", "doughnut", "kpi", "bubbles", "rose", "column", "table"]


def over_time(pts, now_kind):
    """A trend: the chart is a line or area, or every group is a date, month, week, quarter or year."""
    return now_kind in ("line", "area") or bool(pts) and all(DATED.match(str(c).strip()) for c, _ in pts)


def data_options(headline, series, now_kind, folder, skip=(), summary="", fmt=None, decision="", avoid=()):
    """Up to 3 slides that show the chart's own numbers another way; `skip` = kinds already offered; `summary` = what
    else the slide says (its takeaway line and callouts), kept on every option, as is its decision bar; `avoid` = the
    ways the slides beside it tell their story (storyline.py), never offered. A trend keeps its time order."""
    import storyline as SL
    name, pts = series[0]
    vals = [v for _, v in pts]
    n, positive = len(pts), all(v > 0 for v in vals)
    time = over_time(pts, now_kind)
    if fmt is None:                                    # the chart had no format: whole numbers stay whole, no unit added
        fmt = "#,##0" if all(abs(v) >= 100 or float(v).is_integer() for v in vals) else "#,##0.0"
    unit = "%" if "%" in fmt or RATE.search(name) else "$" if "$" in fmt or "$" in headline else ""
    rate = unit == "%"
    ranked = sorted(pts, key=lambda p: -p[1])
    big = max(abs(v) for v in vals) if vals else 0
    d = 2 if big and (big - min(abs(v) for v in vals)) / big < 0.05 else 1
    folder.mkdir(parents=True, exist_ok=True)
    def csv_of(rows, tag):
        f = folder / f"data-{tag}.csv"
        import csv
        with open(f, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh); w.writerow(["Group", name]); w.writerows([[c, v] for c, v in rows])
        return str(f)
    fit = {"lollipop": 3 <= n <= 10 and len(series) == 1, "bar": True, "doughnut": len(series) == 1 and positive and not rate and n <= 6,
           "kpi": len(series) == 1 and 2 <= n <= 4, "bubbles": len(series) == 1 and positive and not rate and 3 <= n <= 14,
           "rose": len(series) == 1 and positive and not rate and 5 <= n <= 12, "column": n <= 12, "table": n <= 12}
    labels = {"lollipop": "Ranked lollipop - the leader first", "bar": "Bars, largest first", "doughnut": "Share of the total (donut)",
              "kpi": "One big number per group", "bubbles": "Sized circles", "rose": "Polar wedges", "column": "Columns",
              "table": "A table"}
    kinds = KINDS
    if time:                                           # a trend: other ways that keep the time order, never a ranking
        kinds = ["column", "area", "line", "table", "kpi"]
        fit.update(column=n <= 40, area=3 <= n and len(series) == 1, line=3 <= n, table=n <= 12)
        labels.update(column="Columns over time", area="Shaded area over time", line="A line over time", table="A table in time order",
                      kpi="One big number per period")
        ranked = pts
    out = []
    for kind in kinds:
        if kind in skip or kind == now_kind or not fit[kind]:
            continue
        if kind == "lollipop":
            sl = {"modern": "lollipop", "items": [[c, v] for c, v in ranked], "unit": unit}
        elif kind in ("bar", "column", "doughnut", "area", "line"):
            rows = ranked if kind not in ("column", "area", "line") else pts
            sl = {"chart": {"data": csv_of(rows, kind), "type": kind, "x": "Group", "y": [name], "format": fmt}}
        elif kind == "kpi":
            sl = {"modern": "kpi", "items": [{"label": c, "value": show_value(v, unit, d)} for c, v in ranked]}
        elif kind in ("bubbles", "rose"):
            sl = {"modern": kind, "items": [[c, v] for c, v in ranked]}
        else:
            sl = {"table": {"rows": [["", *[nm for nm, _ in series]]] +
                                    [[c] + [show_value(dict(p).get(c, 0), unit, d) for _, p in series] for c, _ in ranked]}}
        sl["headline"] = headline
        if summary:
            sl["summary"] = summary
        if decision:
            sl["decision"] = decision
        if SL.device_of(sl) in avoid:                  # told the way a slide beside it is: two in a row read as one
            continue
        out.append({"kind": kind, "label": labels[kind], "slide": sl})
        if len(out) == 3:
            break
    return [dict(o, id=chr(65 + k)) for k, o in enumerate(out)]


def number_format(parts, chart_part):
    """The chart's own number format (its value axis, else its data): an option shows the numbers the same way, never
    with a unit the chart did not have."""
    root = SP.xml(parts[chart_part])
    ax = root.find(f".//{C_NS}valAx/{C_NS}numFmt")
    code = ax.get("formatCode") if ax is not None else root.findtext(f".//{C_NS}val//{C_NS}formatCode")
    return code if code and code != "General" else None


def now_kind(parts, chart_part):
    root = SP.xml(parts[chart_part])
    for tag, kind in (("barChart", None), ("lineChart", "line"), ("pieChart", "doughnut"), ("doughnutChart", "doughnut")):
        el = root.find(f".//{C_NS}{tag}")
        if el is not None:
            if tag == "barChart":
                d = el.find(f"{C_NS}barDir")
                return "bar" if d is not None and d.get("val") == "bar" else "column"
            return kind
    return None


IDEA_WAYS = {"a chart": "rank", "flow": "sequence", "a timeline style": "time", "a diagram or chart": None,
             "a process flow": "sequence", "a process flow: snake": "sequence", "network": "structure",
             "document-flow": "sequence", "fulfilment": "compare"}


def idea_way(idea):
    """The way an idea tells a story: a layout name's (storyline.SOURCES), a retail starter's or one of IDEA_WAYS."""
    import storyline as SL, full_template as FT, retail as RT
    head = idea.split(" (")[0]
    if head in IDEA_WAYS:
        return IDEA_WAYS[head]
    if head in RT.STARTERS:
        return SL.device_of(RT.expand({"retail": head}))
    src = FT.resolve(head.split()[0])
    key = head.split()[0]
    return SL.INFOGRAPHICS.get(key) or (SL.SOURCES.get(src) if isinstance(src, int) else None)


def ideas(info, now=None, avoid=()):
    """A few layouts that suit what the slide holds (a starting point; the content decides), not the one it has, and
    none told the way a slide beside it is (`avoid`)."""
    nums, _ = facts(info)
    body = info["text"][1:] if len(info["text"]) > 1 else info["text"]
    distinct = list(dict.fromkeys(l.strip() for l in body                       # big numbers standing on their own line
                                  if re.fullmatch(r"[+-]?[$\u20ac\u00a3]?\d[\d.,]*\s*(%|[kmb]|bn|pts?)?", l.strip(), re.I)))
    out = []
    words = " ".join(info["text"]).lower()
    import retail as RT                                 # retail first (SKILL.md rule 10): the starter its words
    cue = next((k for k, rx in RT.CUES.items() if rx.search(words)), None)   # name, then the retail diagrams they
    if not re.search(r"\b(?:risks?|issues?|threats?|mitigat\w*)\b", words):  # call for (risks keep their table)
        out += [f"{cue} (retail starter: {RT.WHAT[cue]})"] if cue else []
        if sum(bool(re.search(rf"\b(?:{p})\b", words)) for p in (r"vendors?|suppliers?", r"stores?|guests?|homes?",
               r"dcs?|distribution cent\w+|warehouses?|fulfil+ment cent\w+", r"trucks?|freight|carriers?")) >= 2:
            out += ["network (retail: vendors, DCs, stores and guests, the trucks on the lanes)"]   # two links
        if re.search(r"\b(invoices?|purchase orders?|goods receipts?|ship notices?|remittance)\b", words):
            out += ["document-flow (retail: the documents of the process in order)"]
        if re.search(r"\b(ship from store|pick ?up in store|same[- ]day|curbside|bopis)\b", words):
            out += ["fulfilment (retail: one order, the ways it reaches the guest)"]
    if re.search(r"\bvision\b|\bpillars?\b|\bpriorities\b", words):
        out += ["priorities (the vision house: vision, goals, pillars, KPIs)"]
    if re.search(r"\bobjectives?\b", words) and re.search(r"\bstrateg", words) and re.search(r"\bmeasures?\b|\bkpis?\b", words):
        out += ["ogsm (objective, goals, strategies, measures)"]
    if len(distinct) in (2, 3):
        out += ["kpi-cards (two or three big numbers)", "headline-metrics (2-4 numbers in a row)"]
    if len(distinct) == 3:
        out += ["three-cards"]
    if len(distinct) == 4:
        out += ["headline-metrics (2-4 numbers in a row)", "quad (four big numbers, template infographic)"]
    if 3 <= len(distinct) <= 8 and (all("%" in t for t in distinct) or all("$" in t for t in distinct)):
        out += ["a chart (the numbers share a unit)"]
    if 3 <= len(body) <= 6 and len(distinct) < 3:
        out += ["flow (steps)", "a process flow (chevrons, numbered, a cycle if it repeats; \"icons\": \"auto\" for "
                "pictograms)", "agenda-list (numbered list)", "a timeline style (if the items are dated)"]
    if 7 <= len(body) <= 10 and len(distinct) < 3:
        out += ["a process flow: snake (a long process in two rows)"]
    if len(body) >= 6:
        out += ["three-cards", "four-pillars", "objectives-scope", "paired-columns"]
    if len(body) <= 2:
        out += ["big-note (one statement on a photo)", "photo-quote (a quote)"]
    import full_template as FT
    skip = next((r["name"] for r in FT.collection()["slides"] if r["source"] == now), None)
    out = [o for o in dict.fromkeys(out) if not (skip and o.startswith(skip)) and idea_way(o) not in avoid]
    return out[:6] or [o for o in ("three-cards", "two-columns", "a diagram or chart") if idea_way(o) not in avoid]


def bar_text(parts, info):
    """The slide's decision bar (shape "ULTA decision"): ('Lead: body' for a storyboard, the line as the slide shows it),
    else None."""
    root = SP.xml(parts[info["part"]])
    for sp in root.iter("{http://schemas.openxmlformats.org/presentationml/2006/main}sp"):
        nv = sp.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}cNvPr")
        if nv is not None and nv.get("name") == "ULTA decision":
            runs = [t.text or "" for t in sp.iter("{http://schemas.openxmlformats.org/drawingml/2006/main}t")]
            if len(runs) >= 2 and runs[0].strip():
                return f"{runs[0].strip()}: {''.join(runs[1:]).strip()}", " ".join("".join(runs).split())
    return None


def show(deck, number, more=False):
    parts = SP.read(deck)
    info = SP.inspect(parts, number)
    rec = record(deck)
    src = source_of(deck, number, rec)
    nums, _ = facts(info)
    kind_now = now_kind(parts, info["charts"][0]) if info["charts"] else None
    print(f"slide {number} of {len(SP.slides(parts))} | now: " + (f"a native {kind_now or ''} chart".replace("  ", " ") if info["charts"] else layout_label(src)))
    import storyline as SL
    nb = neighbours(rec, number)
    if nb:
        print("beside it: " + ", ".join(f"slide {i} tells its story as {SL.WORDS.get(w, w)}" for i, w in sorted(nb.items()))
              + " - options told one of those ways are left out (two slides in a row told one way read as one point "
              "made twice)")
    for t in info["text"][:40]:
        print("  " + t[:110])
    if len(info["text"]) > 40:
        print(f"  ... {len(info['text']) - 40} more lines")
    print("numbers to keep: " + (", ".join(dict.fromkeys(nums)) or "none"))
    if info["notes"]:
        print(f"speaker notes: kept as they are ({len(info['notes'])} line(s))")
    if info["unsupported"]:
        print("CANNOT SWAP AUTOMATICALLY: the slide holds " + ", ".join(info["unsupported"]))
    if info["charts"]:                                   # a chart: its numbers are in the chart - the options come from them
        series = [x for cp in info["charts"] for x in chart_series(parts, cp)]
        if series and series[0][1]:
            for nm, pts in series:
                print(f"chart data ({nm}): " + " · ".join(f"{c} {v:,.0f}" if abs(v) >= 100 else f"{c} {v:,.4g}" for c, v in pts[:12]))
            base = Path(deck).resolve().parent / f"{Path(deck).stem}-slide{number}-options"
            done = set()
            for f in sorted(base.parent.glob(base.name + "*.json")) if more else []:
                done |= {o.get("kind") for o in json.loads(f.read_text()).get("options", [])}
            k = len(list(base.parent.glob(base.name + "*.json"))) if more else 0
            dest = base.parent / (base.name + (f"-{k + 1}" if k else "") + ".json")
            headline = info["text"][0] if info["text"] else ""
            pts_all = [pt for _, p in series for pt in p]
            labels = set(SP.words(" ".join(str(c) for c, _ in pts_all)))
            def chart_label(line):                     # a value or a date the chart prints beside a point
                toks = SP.words(line)
                return len(toks) <= 3 and all(t in labels or any(abs(x - v) <= tol + 1e-9 for x, tol, _ in shown_numbers([t])
                                                                 for _, v in pts_all) for t in toks)
            decision = bar_text(parts, info)           # the decision bar stays a decision bar, not part of the takeaway
            kept, marks = [], []                       # the takeaway and callouts, each a sentence; a callout keeps the
            for t in (x.strip() for x in info["text"][1:] if not (decision and " ".join(x.split()) == decision[1])):
                                                       # date of the point it marks ("Biggest change: 387 (12 Mar)")
                if not t:
                    continue
                if chart_label(t):
                    marks.append(t); continue
                bare = not t.endswith((".", "!", "?"))
                t = t + "." if bare else t
                when = [m for m in marks if DATED.match(m)]
                if len(when) == 1 and len(SP.words(t)) <= 6 and len(" ".join(kept + [t, when[0]]).split()) <= 24:
                    t = t[:-1] + f" ({when[0]})."
                kept.append(t); marks = []
            said = " ".join(kept)
            if len(kept) == 1 and bare and said.endswith(".") and not said.endswith(")."):
                said = said[:-1]                       # one takeaway line reads as the slide shows it
            opts = data_options(headline, series, now_kind(parts, info["charts"][0]), base.parent / (dest.stem + "-data"), done, said,
                                number_format(parts, info["charts"][0]), decision[0] if decision else "", set(nb.values()))
            if not opts:
                print("NO MORE OPTIONS - every way to show this chart's numbers has been offered; the user can pick one of them")
                return
            dest.write_text(json.dumps({"options": opts}, indent=1, ensure_ascii=False), encoding="utf-8")
            print(f"OPTIONS {dest} - " + " · ".join(f"{o['id']}: {o['label']}" for o in opts))
            print(f"Preview them as they are (never sketch options yourself): slide_options.py preview {Path(deck).name} "
                  f"--slide {number} --options {dest} --out <new folder>")
            return
    print("ideas: " + " · ".join(ideas(info, src, set(nb.values()))))
    print("Write 2-3 options (same words and numbers, a different layout) and run: slide_options.py preview")


def content_check(before, after, chrome_before=(), chrome_after=(), points=()):
    """Problems when an option drops or invents content (numbers strictly; words that carry meaning). `points`: the
    chart's own (group, value) pairs - its values and group names are the chart's labels: an option that shows them in
    its text adds nothing new, and one that shows the chart another way does not drop them (data_check covers them)."""
    bn, bw = facts(before, chrome_before)
    an, aw = facts(after, chrome_after)
    probs = []
    in_chart = lambda n: any(abs(x - v) <= tol + 1e-9 or (pct and abs(x - 100 * v) <= tol + 1e-9)
                             for x, tol, pct in shown_numbers([n]) for _, v in points)
    labels = set(SP.words(" ".join(str(c) for c, _ in points)))
    lost = [n for n in dict.fromkeys(bn) if bn.count(n) > an.count(n) and not (points and (in_chart(n) or n in labels))]
    said = bw
    bw = {w_ for w_ in bw if w_ not in labels}
    new = [n for n in dict.fromkeys(an) if an.count(n) > bn.count(n) and n not in SMALL and not (points and in_chart(n))]
    if lost:
        probs.append("numbers missing: " + ", ".join(lost[:8]))
    if new:
        probs.append("numbers that were not on the slide: " + ", ".join(new[:8]))
    gone = sorted(w for w in bw - aw if not any(w in x or x in w for x in aw))   # plural/singular and joins pass
    if gone:
        probs.append("words missing: " + ", ".join(gone[:10]))
    return probs, sorted(aw - said - labels)


def render_png(deck, dest, stem):
    import lo
    dest.mkdir(parents=True, exist_ok=True)
    lo.convert(deck, dest, "pdf", timeout=240)
    pdf = dest / (Path(deck).stem + ".pdf")
    if not pdf.exists() or not shutil.which("pdftoppm"):
        return None
    subprocess.run(["pdftoppm", "-png", "-r", "72", "-singlefile", "-f", "1", "-l", "1", str(pdf), str(dest / stem)],
                   capture_output=True)
    png = dest / f"{stem}.png"
    return png if png.exists() else None


def one_slide_copy(deck, number, dest):
    """The slide as it is now, alone in a copy of the deck (for its picture)."""
    from pptx import Presentation
    prs = Presentation(str(deck))
    lst = prs.slides._sldIdLst
    for k, sid in reversed(list(enumerate(list(lst), 1))):
        if k != number:
            prs.part.drop_rel(sid.rId); lst.remove(sid)
    import atomic
    atomic.save(prs, dest)
    return dest


def sheet(tiles, dest):
    from PIL import Image, ImageDraw, ImageFont
    w, h, pad, head = 720, 405, 24, 46
    cols = 2 if len(tiles) <= 4 else 3
    rows = (len(tiles) + cols - 1) // cols
    img = Image.new("RGB", (pad + cols * (w + pad), pad + rows * (h + head + pad)), (255, 255, 255))
    d = ImageDraw.Draw(img)
    fonts = TOOLS.parent / "fonts"
    try:
        f = ImageFont.truetype(str(fonts / "Inter-Bold.otf"), 22)
    except Exception:
        f = ImageFont.load_default()
    for i, (title, png) in enumerate(tiles):
        x, y = pad + (i % cols) * (w + pad), pad + (i // cols) * (h + head + pad)
        d.text((x, y + 8), title, fill=(0, 0, 0), font=f)
        if png and Path(png).exists():
            im = Image.open(png).convert("RGB"); im.thumbnail((w, h))
            img.paste(im, (x, y + head))
            d.rectangle([x - 1, y + head - 1, x + im.width, y + head + im.height], outline=(217, 217, 217))
        else:
            d.rectangle([x, y + head, x + w, y + head + h], outline=(217, 217, 217))
            d.text((x + 20, y + head + 20), "no preview (renderer not available)", fill=(90, 90, 90), font=f)
    img.save(dest)
    return dest


def deck_settings(deck):
    """(classification level, owner) the deck was built with (its file properties), so every option is built the
    same way: the same footer and the same layouts, which the swap then reuses. (None, None) when unset."""
    try:
        import docprops as DP, compliance
        _, custom = DP.read_props(deck)
    except Exception:
        return None, None
    label = (custom.get("Classification") or "").strip().lower()
    level = next((k for k, (lab, _) in compliance.LEVELS.items() if lab.lower() == label), None)
    return level, (custom.get("Owner") or "").strip() or None


def preview(deck, number, options_file, dest):
    deck, dest = Path(deck).resolve(), Path(dest).resolve()
    if dest.exists() and any(dest.iterdir()):
        raise ValueError("Use a new folder for the options (earlier choices stay reproducible)")
    opts = json.loads(Path(options_file).read_text(encoding="utf-8"))
    choices = opts.get("options") or []
    if not 1 <= len(choices) <= 4:
        raise ValueError("Give 1-4 options (2-3 is best)")
    ids = [str(c.get("id") or chr(65 + k)) for k, c in enumerate(choices)]
    if len(set(ids)) != len(ids) or any(not re.fullmatch(r"[A-Za-z0-9]{1,8}", i) for i in ids):
        raise ValueError("Option ids must be unique letters or numbers")
    base = SP.read(deck)
    before = SP.inspect(base, number)
    points = [pt for cp in before["charts"] for _, pts in chart_series(base, cp) for pt in pts]   # a chart's own numbers
    if before["unsupported"]:
        raise ValueError("Slide holds " + ", ".join(before["unsupported"]) + ": an automatic swap would lose them")
    dest.mkdir(parents=True, exist_ok=True)
    session = {"schema": 1, "deck": str(deck), "deck_sha256": SP.sha(deck), "slide": number, "options": [], "rejected": []}
    level, owner = deck_settings(deck)
    import storyline as SL
    nb = neighbours(record(deck), number)
    src_now = source_of(deck, number)
    chrome_now = template_words(src_now) if src_now else set()
    now_png = render_png(one_slide_copy(deck, number, dest / "now.pptx"), dest / "_now", "now")
    tiles = [(f"Now: slide {number}", now_png)]
    for c, ident in zip(choices, ids):
        folder = dest / ident
        folder.mkdir()
        label = str(c.get("label") or "").strip() or f"Option {ident}"
        spec = c.get("slide")
        if not isinstance(spec, dict):
            session["rejected"].append({"id": ident, "label": label, "why": "no \"slide\" given"}); continue
        spec = dict(spec)
        like = told_like(nb, SL.device_of(spec)) if not SL.marked(spec) else ""
        if like:
            session["rejected"].append({"id": ident, "label": label, "why": f"tells its story the way {like} beside it "
                                        "does - two slides in a row told one way read as one point made twice; pick "
                                        "another way (or mark it \"(cont.)\" if it carries that slide on)"})
            continue
        story = {"slides": [spec]}
        if level:
            story["classification"] = level           # the deck's own footer wording on the option
        if owner:
            story["owner"] = owner
        (folder / "storyboard.json").write_text(json.dumps(story, ensure_ascii=False), encoding="utf-8")
        cand = folder / "option.pptx"
        r = subprocess.run([sys.executable, str(TOOLS / "build_deck.py"), "build", str(folder / "storyboard.json"),
                            "--out", str(cand), "--no-tokens"], capture_output=True, text=True, timeout=420)
        out = r.stdout + r.stderr
        (folder / "build.log").write_text(out)
        status = next((l.split("|")[0].strip() for l in out.splitlines() if re.match(r"(READY|NEEDS CORRECTION|DRAFT)", l)), "")
        if not cand.exists() or status.startswith("NEEDS CORRECTION"):
            fails = [l.strip() for l in out.splitlines() if l.strip().startswith(("FAIL", "STILL TOO LONG"))][:4]
            session["rejected"].append({"id": ident, "label": label, "why": "; ".join(fails) or status or "build failed"})
            continue
        cparts = SP.read(cand)
        after = SP.inspect(cparts, 1)
        rec = json.loads(Path(str(cand) + ".ulta.json").read_text()) if Path(str(cand) + ".ulta.json").exists() else {}
        csrc = (rec.get("source_mapping") or {}).get("1")
        probs, added = content_check(before, after, chrome_now, template_words(csrc) if csrc else set(), points)
        if points:                                       # every group and value of the chart, as shown on the option (said first)
            probs = data_check(points, after["text"], [pt for cp in after["charts"] for _, pts in chart_series(cparts, cp) for pt in pts]) + probs
        if probs:
            session["rejected"].append({"id": ident, "label": label, "why": "; ".join(probs)}); continue
        try:
            SP.replace(base, number, cparts)                 # dry run: the swap works and touches nothing else
        except ValueError as e:
            session["rejected"].append({"id": ident, "label": label, "why": str(e)}); continue
        png = render_png(cand, folder / "_render", "option")
        session["options"].append({"id": ident, "label": label, "deck": str(cand.relative_to(dest)), "sha256": SP.sha(cand),
                                   "preview": str(png.relative_to(dest)) if png else None,
                                   "preview_sha256": SP.sha(png) if png else None, "status": status or "READY",
                                   "added_words": added[:12], "record": rec})
        tiles.append((f"{ident}: {label}", png))
    (dest / "session.json").write_text(json.dumps(session, indent=1, ensure_ascii=False), encoding="utf-8")
    for o in session["options"]:
        extra = f" (adds: {', '.join(o['added_words'][:6])})" if o["added_words"] else ""
        print(f"OPTION {o['id']}: {o['label']} | {o['status']}{extra}")
    for o in session["rejected"]:
        print(f"REJECTED {o['id']}: {o['label']} - {o['why'][:220]}")
    if not session["options"]:
        print("No option passed - fix the rejected ones (same words and numbers) and run preview again into a new folder")
        return 1
    pic = sheet(tiles, dest / "choices.png")
    print(f"PICTURE {pic}")
    print(f"Show the picture and ask which option to use; then: slide_options.py apply {deck.name} --session {dest} "
          f"--choice <id> --out <new deck>")
    return 0


def apply(deck, folder, choice, out, said=""):
    deck, folder, out = Path(deck).resolve(), Path(folder).resolve(), Path(out).resolve()
    session = json.loads((folder / "session.json").read_text(encoding="utf-8"))
    if SP.sha(deck) != session["deck_sha256"]:
        raise ValueError("The deck changed after the preview - run preview again on the latest deck")
    if out == deck or out.exists():
        raise ValueError("Give a new file name for the result (the original stays as it is, for undo)")
    pick = next((o for o in session["options"] if o["id"].lower() == str(choice).lower()), None)
    if pick is None:
        raise ValueError(f"No option {choice!r}; options: {', '.join(o['id'] for o in session['options'])}")
    cand = (folder / pick["deck"]).resolve()
    if folder not in cand.parents or SP.sha(cand) != pick["sha256"]:
        raise ValueError("The option file changed after the preview - run preview again")
    if pick.get("preview") and SP.sha(folder / pick["preview"]) != pick["preview_sha256"]:
        raise ValueError("The option picture changed after the preview - run preview again")
    n = session["slide"]
    base = SP.read(deck)
    parts, receipt = SP.replace(base, n, SP.read(cand))
    level, _ = deck_settings(deck)
    if level:                                          # the slide says what the rest of the deck says (an older
        import compliance                              # preview may have built the option with another footer)
        part = SP.selected(parts, n)
        one = {part: parts[part]}
        if compliance._swap_footer(one, compliance.LEVELS[level][1]):
            parts[part] = one[part]
    import atomic
    with atomic.build_lock(out), atomic.staged(out, keep=[deck]) as stage:   # swapped and checked out of sight: an apply
        SP.write(parts, stage)                                              # the time limit cuts off leaves no unchecked deck
        meta = record(deck)
        crec = pick.get("record") or {}
        for key in ("diagram_slides", "flow_slides", "list_slides", "infographic_slides", "drawn_slides", "trimmed_slides"):
            meta[key] = sorted({i for i in meta.get(key) or [] if i != n} | ({n} if 1 in (crec.get(key) or []) else set()))
        meta["library_slides"] = [e for e in meta.get("library_slides") or [] if e.get("slide") != n] + \
            [dict(e, slide=n) for e in crec.get("library_slides") or [] if e.get("slide") == 1]
        mapping = dict(meta.get("source_mapping") or {})
        if len(mapping) != len(SP.slides(parts)):
            import fix_deck
            inferred, _ = fix_deck.infer_mapping(deck)
            mapping = {str(i): m for i, m in enumerate(inferred, 1)}
        mapping[str(n)] = (crec.get("source_mapping") or {}).get("1", mapping.get(str(n)))
        import a11y as _A                              # per-slide notes of the option move to slide n
        base_sid, cand_sid = SP.slide_ids(base)[n - 1], SP.slide_ids(SP.read(cand))[0]
        notes = dict(meta.get("a11y") or _A.recorded(deck) or {})
        notes.pop(base_sid, None)
        if (crec.get("a11y") or {}).get(cand_sid):
            notes[base_sid] = crec["a11y"][cand_sid]
        meta["a11y"] = notes
        ts, cts = dict(meta.get("typeset") or {}), crec.get("typeset") or {}
        if ts or cts:
            src_map = dict(ts.get("sources") or {})
            src_map[str(n)] = (cts.get("sources") or {}).get("1", mapping[str(n)])
            ts["sources"] = src_map
            for key in ("exempt", "component"):
                ts[key] = sorted({i for i in ts.get(key) or [] if i != n} | ({n} if 1 in (cts.get(key) or []) else set()))
            meta["typeset"] = ts
        if meta.get("ways") or crec.get("ways"):        # the swapped slide's way of telling (storyline.py)
            meta["ways"] = dict(meta.get("ways") or {}, **{str(n): (crec.get("ways") or {}).get("1")})
        meta["source_mapping"], meta["schema_version"] = mapping, 2
        meta.setdefault("slide_revisions", {})[str(n)] = {"from_sha256": session["deck_sha256"], "choice": pick["id"],
                                                         "label": pick["label"], "option_sha256": pick["sha256"]}
        Path(str(stage) + ".ulta.json").write_text(json.dumps(meta))
        import layoutmeta, docprops
        layoutmeta.save(stage)
        docprops.write_props(stage, custom={"A11yAdded": json.dumps(meta["a11y"], separators=(",", ":"))})
        for f in cand.parent.glob(cand.stem + "-slide1.drawio"):    # an editable diagram travels with its slide
            shutil.copyfile(f, stage.with_name(f"{out.stem}-slide{n}.drawio"))
        order = ",".join(str(mapping[str(i)]) for i in range(1, len(mapping) + 1))
        v = subprocess.run([sys.executable, str(TOOLS / "validate_deck.py"), str(stage), "--mapping", order],
                           capture_output=True, text=True, timeout=600)
        checked = v.stdout.replace(str(stage.parent), str(out.parent))
        overall = next((l.split(":", 1)[1].strip() for l in checked.splitlines() if l.startswith("OVERALL")), "not validated")
        fails = [l.strip() for l in checked.splitlines() if l.startswith("FAIL") or re.match(r"\| .* \| FAIL \|", l)][:6]
        import stamp
        stamp.stamp(stage, f"slide {n}: option {pick['id']} ({pick['label']})", overall)
    before, after = SP.read(deck), SP.read(out)
    moved = [p for p in before if re.match(r"ppt/(slides|notesSlides|charts|media)/", p) and p not in
             (receipt["replaced_part"], SP.relpath(receipt["replaced_part"])) and before[p] != after.get(p)]
    total = len(SP.slides(after))
    status = overall.split(" - ")[0]
    said = [f"{status} | slide {n} swapped for option {pick['id']} ({pick['label']}) | {out}",
            (f"  the other {total - 1} slides are byte-identical to {deck.name}; speaker notes kept" if not moved
             else f"  NOTE other parts differ: {', '.join(moved[:4])}")]
    said += ["  " + f for f in fails]
    print("\n".join(said))
    import tokens as TK
    wrote = " ".join(p.read_text(encoding="utf-8") for p in sorted(folder.glob("*/storyboard.json")))
    print(TK.report(out, wrote + f" apply --choice {pick['id']}", "\n".join(said), "edited", f"; only slide {n} changed"))
    return 0 if v.returncode == 0 else 1


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("show"); s.add_argument("deck"); s.add_argument("--slide", type=int, required=True)
    s.add_argument("--more", action="store_true", help="a chart slide: the next 3 options, none offered before")
    p = sub.add_parser("preview"); p.add_argument("deck"); p.add_argument("--slide", type=int, required=True)
    p.add_argument("--options", required=True); p.add_argument("--out", required=True)
    a = sub.add_parser("apply"); a.add_argument("deck"); a.add_argument("--session", required=True)
    a.add_argument("--choice", required=True); a.add_argument("--out", required=True)
    args = ap.parse_args()
    try:
        if args.cmd == "show":
            show(args.deck, args.slide, args.more); code = 0
        elif args.cmd == "preview":
            code = preview(args.deck, args.slide, args.options, args.out)
        else:
            code = apply(args.deck, args.session, args.choice, args.out)
    except (ValueError, KeyError, OSError) as e:
        print(f"BLOCKED: {e}")
        code = 2
    sys.exit(code)


if __name__ == "__main__":
    main()
