"""Recurring report pack (monthly / quarterly business review) from one workbook. Next period: same command, new file.

    python tools/report_pack.py kpis.xlsx --title "Customer Operations MBR" --period "October 2026" \
        --out /mnt/data/out/Ops-MBR [--owner "Name"] [--classification internal] [--tolerance 5]

Workbook (sheet names are case-insensitive; only KPIs is required):
  KPIs     KPI | Actual | Target | Prior | Unit | Better | Owner | Commentary | Group
           Unit: %, $, # or a word (days, hrs). Better: higher (default) or lower. Group (optional): Sales, Service ...
  Trends   Period | <KPI name> | <KPI name> ...            (the KPI cards' sparklines and the Red KPIs' trend slides)
  Actions  Action | Owner | Due [| Detail]                  (with Detail: the template's action table, slide 12)
Numbers read the way the workbook shows them: 31.5, "31.5%" or a cell formatted as a percentage are all 31.5%; a %
KPI whose plain numbers are all between -1 and 1 reads as fractions (0.315 = 31.5%). $: 4.6 is $4.6, 4600000 $4.6M.
Status per KPI: Green = on or better than target; Amber = within --tolerance % (default 5) of target; Red = further
away. Overall = worst KPI.
Builds: 1) a deck: cover; the template's KPI scorecard (slide 21: prior / target / actual, status bars, lowlights and
        highlights written from the numbers); KPI cards with change and sparkline (4 a slide); an annotated trend for
        each Red KPI (worst first, 3 at most) with its commentary; the actions (slide 12 or a table). Every headline
        is written from the numbers and fits one line.
        2) the KPI one-pager (kit kpi template). Both: brand, accessibility, sensitive-data scan, version stamp.
Refine wording with a chat edit (edit_deck.py).
"""
import argparse, json, subprocess, sys
from datetime import date, datetime
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import data_slides as DS   # noqa: E402
import brand as B           # noqa: E402

ORDER = {"Green": 0, "Amber": 1, "Red": 2}
DEEP_DIVES = 3              # Red KPIs that get their own trend slide (all KPIs are on the scorecard and the cards)
CARDS = 4                   # KPI cards per slide


def _cell(c):
    v = c.value
    if v is None:
        return ""
    fmt_ = str(getattr(c, "number_format", "") or "")
    if isinstance(v, (int, float)) and not isinstance(v, bool) and "%" in fmt_:
        return f"{v * 100:.10g}%"                     # a cell formatted as a percentage reads as one (0.315 -> 31.5%)
    return v


def sheets(path):
    p = DS.resolve(path)
    if p.suffix.lower() not in (".xlsx", ".xlsm"):
        return {"kpis": DS.read_table(p)}
    from openpyxl import load_workbook
    wb = load_workbook(str(p), data_only=True, read_only=True)
    out = {}
    for ws in wb.worksheets:
        rows = [[_cell(c) for c in r] for r in ws.iter_rows()]
        rows = [r for r in rows if any(str(c).strip() for c in r)]
        width = max((len(r) for r in rows), default=0)
        out[ws.title.strip().lower()] = [list(r) + [""] * (width - len(r)) for r in rows]
    return out


def records(rows):
    head = [str(h).strip().lower() for h in rows[0]]
    return [{h: r[i] if i < len(r) else "" for i, h in enumerate(head)} for r in rows[1:]]


def _num(v):
    """(value in display units, typed as a percentage)."""
    x, pct = DS.number(v)
    return (x * 100 if (x is not None and pct) else x), pct


def _decimals(vals):
    """Decimals a KPI's numbers need (0-2), the same for all of them so a row reads evenly."""
    d = 0
    for v in vals:
        if v is None or abs(v) >= 100:
            continue
        d = max(d, 0 if abs(v - round(v)) < 1e-9 else 1 if abs(v * 10 - round(v * 10)) < 1e-6 else 2)
    return d


def fmt(v, unit, dec=1):
    if v is None:
        return "—"
    u = str(unit or "").strip()
    a, sign = abs(v), "-" if v < 0 else ""
    if u == "%":
        return f"{v:.{dec}f}%"
    if u == "$":
        s = (f"{a / 1e9:.1f}B" if a >= 1e9 else f"{a / 1e6:.1f}M" if a >= 1e6 else f"{a / 1e3:.0f}K" if a >= 1e4
             else f"{a:,.0f}" if a >= 100 else f"{a:,.{dec}f}")
        return f"{sign}${s}"
    s = f"{v:,.0f}" if a >= 100 else f"{v:,.{dec}f}"
    return s + (f" {u}" if u and u != "#" else "")


def status(actual, target, lower, tol):
    if actual is None or target is None:
        return "—"
    gap = (target - actual) if not lower else (actual - target)      # > 0 = worse than target
    if gap <= 0:
        return "Green"
    return "Amber" if abs(gap) <= abs(target) * tol / 100 else "Red"


def kpi_rows(recs, tol):
    out = []
    for r in recs:
        name = str(r.get("kpi") or r.get("metric") or r.get("measure") or "").strip()
        if not name:
            continue
        unit = str(r.get("unit") or "").strip()
        got = {f: _num(r.get(f)) for f in ("actual", "target", "prior")}
        typed_pct = any(p for _, p in got.values())
        if typed_pct and not unit:
            unit = "%"
        v = {f: x for f, (x, _) in got.items()}
        known = [x for x in v.values() if x is not None]
        frac = unit == "%" and not typed_pct and known and all(abs(x) <= 1 for x in known)
        if frac:                                         # 0.315 typed as a plain number on a % KPI = 31.5%
            v = {f: (x * 100 if x is not None else None) for f, x in v.items()}
        lower = str(r.get("better") or "higher").strip().lower().startswith("low")
        a, t, p = v["actual"], v["target"], v["prior"]
        out.append({"kpi": name, "unit": unit, "actual": a, "target": t, "prior": p, "frac": frac, "lower": lower,
                    "status": status(a, t, lower, tol), "dec": _decimals([a, t, p]),
                    "owner": str(r.get("owner") or "").strip(),
                    "group": str(r.get("group") or r.get("area") or r.get("category") or "").strip(),
                    "comment": str(r.get("commentary") or r.get("comment") or "").strip()})
    return out


def change(k, other):
    """'+0.8 pts' for a % KPI, '+10%' otherwise: the change from `other` to the actual."""
    a = k["actual"]
    if a is None or other is None:
        return None
    if k["unit"] == "%":
        return f"{a - other:+.1f} pts"
    return f"{(a - other) / abs(other) * 100:+.0f}%" if other else None


def moved(k):
    """'down 9%' / 'up 0.8 pts': the change on the prior period in plain words."""
    c = change(k, k["prior"]) or ""
    return ("down " if c.startswith("-") else "up ") + c.lstrip("+-") if c else "flat"


def gap_words(k):
    """'2% ahead of target' / '0.2 pts over target' / 'on target' - the gap in the KPI's own terms."""
    a, t = k["actual"], k["target"]
    if a is None or t is None:
        return None
    d = a - t
    size = f"{abs(d):.1f} pts" if k["unit"] == "%" else (f"{abs(d) / abs(t) * 100:.0f}%" if t else None)
    if size is None or size in ("0.0 pts", "0%"):
        return "on target"
    if k["lower"]:
        return f"{size} {'under' if d < 0 else 'over'} target"
    return f"{size} {'ahead of' if d > 0 else 'behind'} target"


def fits(text):
    import typeset as TS
    return TS.fits_headline(text)


def first_fit(cands, fallback):
    return next((c for c in cands if c and fits(c)), fallback)


def headline(k):
    v = fmt(k["actual"], k["unit"], k["dec"])
    g = gap_words(k)
    cands = ([f"{k['kpi']} {v}, {g}", f"{k['kpi']} at {v}, {g}"] if g and g != "on target" else
             [f"{k['kpi']} on target at {v}"]) + [f"{k['kpi']} at {v}"]
    return first_fit(cands, k["kpi"][:40])


def scorecard_headline(kpis):
    rated = [k for k in kpis if k["status"] != "—"]
    reds = [k["kpi"] for k in rated if k["status"] == "Red"]
    ok, m = len(rated) - len(reds), len(rated)
    if not rated:
        return first_fit([f"{len(kpis)} KPIs this period"], "KPIs this period")
    if not reds:
        greens = sum(1 for k in rated if k["status"] == "Green")
        return first_fit([f"All {m} KPIs on or near target; {greens} ahead" if greens < m else f"All {m} KPIs on or ahead of target",
                          f"All {m} KPIs on or near target"], f"All {m} KPIs on track")
    verb = "needs" if len(reds) == 1 else "need"
    names = " and ".join(reds) if len(reds) <= 2 else f"{len(reds)} KPIs"
    return first_fit([f"{ok} of {m} KPIs on or near target; {names} {verb} attention",
                      f"{ok} of {m} KPIs on track; {names} {verb} attention",
                      f"{ok} of {m} KPIs on track; {len(reds)} {verb} attention",
                      f"{ok} of {m} KPIs on or near target"], f"{ok} of {m} KPIs on track")


def _label(v):
    if isinstance(v, (datetime, date)):
        return f"{v:%b %Y}"
    return str(v).strip()


def trends(sh, kpis):
    """{kpi name: (labels, values in display units)} from the Trends sheet."""
    if "trends" not in sh:
        return {}, None
    tr = sh["trends"]
    header = [str(h).strip() for h in tr[0]]
    out = {}
    for col, name in enumerate(header[1:], 1):
        k = next((x for x in kpis if x["kpi"].lower() == name.lower()), None)
        labels, vals, flagged = [], [], False
        for r in tr[1:]:
            x, pct = _num(r[col]) if col < len(r) else (None, False)
            if x is None:
                continue
            flagged |= pct
            labels.append(_label(r[0])); vals.append(x)
        if k and k["unit"] == "%" and not flagged and vals and all(abs(v) <= 1 for v in vals) and \
                (k["frac"] or (k["actual"] or 0) > 1):
            vals = [v * 100 for v in vals]
        if vals:
            out[k["kpi"] if k else name] = (labels, vals)
    prior_label = None
    lens = [len(v[0]) for v in out.values()]
    if lens and max(lens) >= 2:
        labs = max(out.values(), key=lambda v: len(v[0]))[0]
        prior_label = labs[-2] if len(labs[-2]) <= 10 else None
    return out, prior_label


def axis_format(unit, dec):
    tail = ("." + "0" * dec) if dec else ""
    if unit == "%":
        return f'0{tail}"%"'
    if unit == "$":
        return f"$#,##0{tail}"
    return f"#,##0{tail}"


def _due(v):
    if isinstance(v, (datetime, date)):
        return f"{v:%b} {v.day}"
    s = str(v or "").strip()
    try:
        d = datetime.strptime(s[:10], "%Y-%m-%d")
        return f"{d:%b} {d.day}"
    except ValueError:
        return s


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def build_slides(a, kpis, sh, rule):
    slides = []
    title = f"{a.title} – {a.period}" if a.period and len(f"{a.title} – {a.period}") <= 55 else a.title
    slides.append({"source": B.current().role("cover", 1), "title": title,
                   **({"subtitle": a.period} if a.period and title == a.title else {})})
    series, prior_label = trends(sh, kpis)
    # 1. the template's own KPI scorecard (slide 21) - or a table when there are more KPIs than it holds
    if 1 <= len(kpis) <= 13:
        groups = {}
        for k in kpis:
            groups.setdefault(k["group"] or ("KPIs" if len({x["group"] for x in kpis}) <= 1 else "Other"), []).append(k)
        if len(groups) > 5:
            groups = {"KPIs": kpis}
        low = [f"{k['kpi']} {fmt(k['actual'], k['unit'], k['dec'])}, {gap_words(k)}"
               for k in sorted(kpis, key=lambda k: -ORDER.get(k["status"], -1)) if k["status"] in ("Red", "Amber")][:5]
        high = [f"{k['kpi']} {fmt(k['actual'], k['unit'], k['dec'])}, {gap_words(k)}" for k in kpis if k["status"] == "Green"][:5]
        better = [k for k in kpis if k["prior"] is not None and k["actual"] is not None and
                  (k["actual"] - k["prior"]) * (-1 if k["lower"] else 1) > 0 and k["status"] != "Green"]
        high += [f"{k['kpi']} {moved(k)} on prior" for k in better][:5 - len(high)]
        slides.append({"scorecard": {
            "columns": ["Prior", "Target", "Actual"], "note": "vs target",
            "groups": [{"name": g, "kpis": [[k["kpi"], fmt(k["prior"], k["unit"], k["dec"]),
                                             fmt(k["target"], k["unit"], k["dec"]), fmt(k["actual"], k["unit"], k["dec"]),
                                             k["status"].lower()] for k in ks]} for g, ks in groups.items()],
            "lowlights": low or ["No KPI is behind target"], "highlights": high or ["No KPI is ahead of target yet"]},
            "headline": scorecard_headline(kpis), "notes": rule})
    else:
        table = [["KPI", "Actual", "Target", "vs prior", "Status", "Owner"]] + [
            [k["kpi"], fmt(k["actual"], k["unit"], k["dec"]), fmt(k["target"], k["unit"], k["dec"]),
             change(k, k["prior"]) or "—", k["status"], k["owner"] or "—"] for k in kpis]
        slides.append({"table": {"rows": table}, "headline": scorecard_headline(kpis), "notes": rule})
    # 2. KPI cards: value, change on the prior period, sparkline
    pages = [kpis[i:i + CARDS] for i in range(0, len(kpis), CARDS)]
    if len(pages) > 1 and len(pages[-1]) == 1:                          # never a lone card
        pages[-2], pages[-1] = pages[-2][:-1], pages[-2][-1:] + pages[-1]
    for n_, page in enumerate(pages, 1):
        if len(page) < 2:
            continue
        items = []
        for k in page:
            it = {"label": k["kpi"], "value": fmt(k["actual"], k["unit"], k["dec"]), "good": "down" if k["lower"] else "up"}
            ch = change(k, k["prior"])
            if ch:
                it["delta"], it["vs"] = ch, f"vs {prior_label}" if prior_label else "vs prior"
            if k["kpi"] in series and len(series[k["kpi"]][1]) >= 2:
                it["trend"] = series[k["kpi"]][1]
            items.append(it)
        have = [k for k in page if k["prior"] is not None and k["actual"] is not None]
        up = sum(1 for k in have if (k["actual"] - k["prior"]) * (-1 if k["lower"] else 1) > 0)
        pre = f"KPIs {(n_ - 1) * CARDS + 1}-{(n_ - 1) * CARDS + len(page)}: " if len(pages) > 1 else ""
        hl = first_fit([f"{pre}{up} of {len(have)} KPIs improved on {prior_label}" if prior_label else "",
                        f"{pre}{up} of {len(have)} KPIs improved on the prior period", f"{pre}{up} of {len(have)} improved"],
                       "KPIs at a glance") if have else first_fit([f"{pre}KPIs this period"], "KPIs this period")
        slides.append({"modern": "kpi", "items": items, "headline": hl,
                       "notes": "Change vs the prior period; the line shows the trend. " + rule})
    # 3. an annotated trend for each Red KPI (worst first)
    reds = sorted((k for k in kpis if k["status"] == "Red" and k["kpi"] in series),
                  key=lambda k: -abs((k["actual"] - k["target"]) / (k["target"] or 1)))[:DEEP_DIVES]
    for k in reds:
        labels, vals = series[k["kpi"]]
        note = k["comment"] if len(k["comment"]) <= 90 else k["comment"][:87].rsplit(" ", 1)[0] + "…"
        slides.append({"modern": "trend", "x": labels, "y": vals, "at": len(vals) - 1, "unit": k["unit"] if k["unit"] in ("%", "$") else "",
                       "value": fmt(vals[-1], k["unit"], k["dec"]), "note": note or gap_words(k) or "",
                       "format": axis_format(k["unit"], k["dec"]), "headline": headline(k),
                       "target": k["target"], "target_label": f"Target {fmt(k['target'], k['unit'], k['dec'])}",
                       "notes": (k["comment"] + " " if k["comment"] else "") + rule})
    # 4. the actions: the template's action table (slide 12) when there is a Detail column, else a table
    if "actions" in sh:
        acts = records(sh["actions"])
        rows = [[str(r.get("action") or "").strip(), str(r.get("detail") or r.get("description") or "").strip(),
                 " · ".join(x for x in (_due(r.get("due")), str(r.get("owner") or "").strip()) if x)] for r in acts]
        rows = [r for r in rows if r[0]]
        if rows and all(r[1] for r in rows) and len(rows) <= 4:
            slides.append({"source": 12, "headline": first_fit([f"{len(rows)} actions agreed, owners and dates set",
                                                                 f"{len(rows)} actions agreed"], "Actions"),
                           "table": [None] + [[r[0], r[1], r[2]] for r in rows]})
        elif rows:
            table = [["Action", "Owner", "Due"]] + [[str(r.get("action") or "").strip(), str(r.get("owner") or "").strip() or "—",
                                                     _due(r.get("due")) or "—"] for r in acts if str(r.get("action") or "").strip()][:12]
            slides.append({"table": {"rows": table}, "headline": first_fit([f"{len(table) - 1} actions agreed, owners and dates set",
                                                                             f"{len(table) - 1} actions agreed"], "Actions")})
    return slides


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("workbook"); ap.add_argument("--title", required=True); ap.add_argument("--period", default="")
    ap.add_argument("--out", required=True); ap.add_argument("--owner"); ap.add_argument("--classification")
    ap.add_argument("--tolerance", type=float, default=5.0)
    a = ap.parse_args()
    sh = sheets(a.workbook)
    if "kpis" not in sh:
        sys.exit(f"workbook needs a KPIs sheet; found {list(sh)}")
    kpis = kpi_rows(records(sh["kpis"]), a.tolerance)
    overall = max((k["status"] for k in kpis if k["status"] != "—"), key=ORDER.get, default="—")
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    work = out.parent / (out.name + "_data"); work.mkdir(exist_ok=True)
    rule = (f"Status rule: Green = on/better than target; Amber = within {a.tolerance:g}% of target; Red = further. "
            f"Overall = worst KPI ({overall}). Source: {Path(a.workbook).name}.")
    story = {"classification": a.classification, "owner": a.owner, "slides": build_slides(a, kpis, sh, rule)}
    sp = work / "storyboard.json"; sp.write_text(json.dumps(story, indent=1))
    code, log = run([sys.executable, str(TOOLS / "build_deck.py"), "build", str(sp), "--out", str(out.with_suffix(".pptx")),
                     "--verbose", "--no-tokens"])
    deck_line = next((l for l in log.splitlines() if l.startswith("OVERALL")), "OVERALL: build failed\n" + log[-600:])
    fails = [l for l in log.splitlines() if l.startswith("FAIL")]
    # KPI one-pager (kit)
    top = [k for k in kpis if k["actual"] is not None][:3]
    md = [f"# {a.title} — KPI Scorecard", f"Period: {a.period or '—'}", f"Owner: {a.owner or '—'}",
          f"Overall status: {overall}", "", "## Headline numbers",
          *[f"- {fmt(k['actual'], k['unit'], k['dec'])}: {k['kpi'].lower()}" for k in top], "", "## KPI detail",
          "| KPI | Actual | Target | Trend | Status |", "|---|---|---|---|---|",
          *[f"| {k['kpi']} | {fmt(k['actual'], k['unit'], k['dec'])} | {fmt(k['target'], k['unit'], k['dec'])} | "
            f"{'—' if k['prior'] is None or k['actual'] is None else ('Up' if k['actual'] > k['prior'] else 'Down' if k['actual'] < k['prior'] else 'Flat')} | {k['status']} |"
            for k in kpis], ""]
    com = [k for k in kpis if k["comment"]]
    if com:
        md += ["## Commentary", *[f"- {k['kpi']}: {k['comment']}" for k in com[:4]], ""]
    if "actions" in sh:
        md += ["## Actions", *[f"{i}. {r[0]}: {r[1] if len(r) > 1 else ''} {('by ' + _due(r[2])) if len(r) > 2 and r[2] else ''}".rstrip()
                               for i, r in enumerate(sh["actions"][1:6], 1)], ""]
    mdp = out.with_name(out.name + "-onepager.md"); mdp.write_text("\n".join(md))
    one = out.with_name(out.name + "-onepager")
    kit = TOOLS.parent / "modules" / "ultabranddeliverables" / "scripts" / "ulta.py"
    run([sys.executable, "-I", str(kit), "infographic", str(mdp), "--template", "kpi", "--out", str(one)])
    files = [str(p) for p in (one.with_suffix(".pptx"), one.with_suffix(".svg"), one.with_suffix(".html")) if p.exists()]
    _, conf = run([sys.executable, str(TOOLS / "ulta_conform.py"), *files, "--keep-sizes"])
    run([sys.executable, str(TOOLS / "nativize.py"), str(one.with_suffix(".pptx"))])
    import a11y, brand_colours, compliance, stamp
    a11y.fix(one.with_suffix(".pptx"))
    if a.classification:
        compliance.classify(one.with_suffix(".pptx"), a.classification)
    blk = [x for x in compliance.scan(files) if x["severity"] == "BLOCK"]
    off = brand_colours.gate(files, conform=False)
    res = "NEEDS CORRECTION" if blk or "FAIL" in conf or off else "READY"
    stamp.stamp(one.with_suffix(".pptx"), f"report refresh from {Path(a.workbook).name}", res, a.owner, a.classification)
    print(f"REPORT {overall} | deck {deck_line.split(':', 1)[1].strip().split(' -')[0]} | one-pager {res}")
    print(f"  deck: {out.with_suffix('.pptx')}   one-pager: {one.with_suffix('.pptx')}")
    print(f"  {len(kpis)} KPIs: " + ", ".join(f"{k['kpi']}={k['status']}" for k in kpis))
    for f_ in fails[:8] + off[:4]:
        print("  " + f_)
    if "build failed" in deck_line:
        print(deck_line)


if __name__ == "__main__":
    main()
