"""Brand profiles: everything template-specific (file, hash, colours, fonts, slide roles) lives in brands/<name>/brand.json.

    python tools/brand.py list                 # profiles found + which one is active
    python tools/brand.py use <name>           # make <name> the active brand (all tools follow it)
    python tools/brand.py show                 # the active profile

Profiles are looked up in /mnt/data/brands (created at run time by brand_import.py; writable) and then in the
skill's own brands/ folder. The active choice is ULTA_BRAND, else /mnt/data/brands/active.json, else brands/active.json.
The kit (ulta.py) always draws in the Ulta profile; rebrand.py maps its output onto the active profile.
"""
import json, math, os, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILL_BRANDS = ROOT / "brands"
RUN_BRANDS = Path(os.environ.get("ULTA_BRANDS_DIR", "/mnt/data/brands"))
SOURCE = "ulta"                     # the profile the kit draws in


def dirs():
    return [d for d in (RUN_BRANDS, SKILL_BRANDS) if d.exists()]


def active_name():
    if os.environ.get("ULTA_BRAND"):
        return os.environ["ULTA_BRAND"]
    for d in dirs():
        f = d / "active.json"
        if f.exists():
            return json.loads(f.read_text()).get("brand") or SOURCE
    return SOURCE


def find(name):
    for d in dirs():
        if (d / name / "brand.json").exists():
            return d / name
    raise SystemExit(f"brand profile '{name}' not found in {[str(d) for d in dirs()]} - run brand_import.py first")


class Brand(dict):
    def __init__(self, name=None):
        name = name or active_name()
        self.dir = find(name)
        super().__init__(json.loads((self.dir / "brand.json").read_text()))
        self.name = self["name"]

    @property
    def base_template(self):
        return (self.dir / self["template"]).resolve()

    @property
    def template(self):
        """The reference decks are built from: with "layouts" (Ulta), the template's slides plus the 40-layout
        collection's new ones (tools/full_template.py, checked against its own pin); otherwise the template file."""
        if self.get("layouts"):
            import full_template
            return full_template.combined(self)
        return self.base_template

    @property
    def sha(self):
        return (self.get("layouts") or {}).get("combined_sha256") or self["sha256"]

    def role(self, key, default=None):
        return (self.get("roles") or {}).get(key, default)

    @property
    def marker(self):
        return self.get("headline_marker") or "Insert headline"

    def is_headline(self, el):
        """The template's headline shape: the one holding the sample-headline text, or (marker "@title") the
        title placeholder. `el` is an lxml shape element (python-pptx: shape._element)."""
        if self.marker.startswith("@ph:"):            # "@ph:<type>:<idx>": that placeholder is the headline
            ph = el.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}ph")
            _, typ, idx = self.marker.split(":")
            return ph is not None and (ph.get("type") or "body") == typ and (ph.get("idx") or "") == idx
        return self.marker in "".join(t.text or "" for t in el.iter("{http://schemas.openxmlformats.org/drawingml/2006/main}t"))

    def font(self, key):
        f = self.get("fonts") or {}
        return f.get(key) or f.get("body")

    def palette(self):
        p = self.get("palette") or {}
        return [c.upper() for k in ("brand", "tints", "neutrals") for c in p.get(k, [])]

    def status(self):
        return [c.upper() for c in (self.get("palette") or {}).get("status", ["00B050", "FFC000", "FF0000"])]

    def ui(self, key):
        p = self.get("palette") or {}
        return p.get(key) or {"dark_accent": "404040", "light_tint": "F2F2F2"}[key]


def current():
    return Brand()


# ------------------------------------------------------------------------------------------- fit metrics
def patch_metrics(fit_module, brand=None):
    """Teach the hash-pinned fit checker the active brand's fonts: measured metrics (brands/<n>/metrics.json,
    made by brand_import.py from the font files) or an alias to a bundled font of similar width."""
    b = brand or current()
    fit_module.EXPECTED_TEMPLATE_SHA = b.sha          # the checker pins the reference: pin the brand's template
    M = fit_module.METRICS
    mfile = b.dir / "metrics.json"
    if mfile.exists():
        for k, v in json.loads(mfile.read_text()).items():
            M.setdefault(k, v)
    for name, alias in (b.get("metrics") or {}).items():
        if isinstance(alias, str) and alias in M and name not in M:
            M[name] = M[alias]
    return M


# ------------------------------------------------------------------------------------------ colour maths
def rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def lab(h):
    def lin(c):
        c /= 255
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(v) for v in rgb(h))
    x, y, z = (r * .4124 + g * .3576 + b * .1805) / .9505, r * .2126 + g * .7152 + b * .0722, (r * .0193 + g * .1192 + b * .9505) / 1.089
    f = lambda t: t ** (1 / 3) if t > 0.008856 else 7.787 * t + 16 / 116
    return 116 * f(y) - 16, 500 * (f(x) - f(y)), 200 * (f(y) - f(z))


def hex_from_lab(L, a, b_):
    fy = (L + 16) / 116; fx = fy + a / 500; fz = fy - b_ / 200
    inv = lambda t: t ** 3 if t ** 3 > 0.008856 else (t - 16 / 116) / 7.787
    x, y, z = inv(fx) * .9505, inv(fy), inv(fz) * 1.089
    r = x * 3.2406 + y * -1.5372 + z * -.4986
    g = x * -.9689 + y * 1.8758 + z * .0415
    bl = x * .0557 + y * -.2040 + z * 1.0570
    def enc(c):
        c = max(0.0, min(1.0, c))
        c = 12.92 * c if c <= 0.0031308 else 1.055 * c ** (1 / 2.4) - 0.055
        return int(round(c * 255))
    return "%02X%02X%02X" % (enc(r), enc(g), enc(bl))


def lch(h):
    L, a, b_ = lab(h)
    return L, math.hypot(a, b_), math.degrees(math.atan2(b_, a)) % 360


def from_lch(L, C, H):
    return hex_from_lab(L, C * math.cos(math.radians(H)), C * math.sin(math.radians(H)))


def luminance(h):
    def ch(c):
        c /= 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(v) for v in rgb(h))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = sorted((luminance(a), luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def apca(text, ground):
    """How well words in `text` read on `ground` to the eye (APCA 0.0.98G, the measure of the WCAG 3 drafts): positive for
    words darker than their ground, negative for lighter ones, 0 when they do not read."""
    def y(h):
        r, g, b_ = (v / 255 for v in rgb(h)); v = 0.2126729 * r ** 2.4 + 0.7151522 * g ** 2.4 + 0.0721750 * b_ ** 2.4
        return v + (0.022 - v) ** 1.414 if v < 0.022 else v
    yt, yb = y(text), y(ground)
    if abs(yb - yt) < 0.0005:
        return 0.0
    if yb > yt:
        s = (yb ** 0.56 - yt ** 0.57) * 1.14
        return 0.0 if s < 0.1 else (s - 0.027) * 100
    s = (yb ** 0.65 - yt ** 0.62) * 1.14
    return 0.0 if s > -0.1 else (s + 0.027) * 100


def light_better(ground):
    """Light words read better on `ground` than dark ones: every Ulta brand colour but gold and the tints - the grounds
    people see as dark, where WCAG 2 alone picks black for the oranges, pinks and reds."""
    return abs(apca("FFFFFF", ground)) > abs(apca("000000", ground))


DEEPEN = {"F26923": "DB0058", "EE6C37": "DB0058", "F16A1C": "DB0058", "DE7445": "DB0058", "E0531B": "DB0058", "F14C24": "DB0058",
          "F24C26": "DB0058", "FF7826": "DB0058", "E9341C": "DB0058", "E8275A": "C10060", "EA0B59": "C10060", "8A8C8F": "505152"}
# the deep colour of a hue, where white words reach 4.5:1: raspberry for the oranges and reds, dark raspberry for the pinks


def darken_to(h, against="FFFFFF", ratio=4.5):
    """Same hue and chroma, darker until it reaches the contrast ratio against `against` (for text on light)."""
    L, C, H = lch(h)
    out = h
    while contrast(out, against) < ratio and L > 5:
        L -= 3
        out = from_lch(L, C, H)
    return out


def in_family(h, brand):
    """True for a brand palette colour, a neutral, a status colour, or a tint/shade of a brand theme colour."""
    h = h.upper()
    if h in brand.palette() or h in brand.status():
        return True
    L, C, H = lch(h)
    if C < 10:
        return True
    for v in list((brand.get("theme") or {}).values()) + brand.status():      # theme tints/shades, darkened RAG
        aL, aC, aH = lch(v)
        if aC >= 10 and min(abs(aH - H), 360 - abs(aH - H)) <= 20:
            return True
    return False


SLOTS = ("accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "dk2")


class ColourMap:
    """Maps a colour drawn in the source (Ulta) profile to the same ROLE in the target profile.
    Theme slots map slot-to-slot (accent1 -> accent1 ...). Any other colour takes the nearest source slot and
    keeps its lightness/chroma relation to it, so tints stay tints and shades stay shades. Neutrals keep
    their lightness; RAG status colours are kept."""

    def __init__(self, source, target):
        self.src, self.tgt = source, target
        st, tt = source.get("theme") or {}, target.get("theme") or {}
        self.anchors = []                         # (slot, source hex, target hex) for chromatic slots
        seen = set()
        for s in SLOTS:
            if s in st and s in tt and st[s].upper() not in seen and lch(st[s])[1] > 15:
                seen.add(st[s].upper())
                self.anchors.append((s, st[s].upper(), tt[s].upper()))
        self.keep = set(source.status())
        self.cache, self.changed = {}, {}
        self.identity = source.name == target.name

    def slot_of(self, hex_):
        """Target theme slot when the mapped colour IS a target theme colour (for schemeClr)."""
        for s, sh, th in self.anchors:
            if sh == hex_.upper():
                return s
        return None

    def __call__(self, h):
        h = h.upper()
        if self.identity or h in self.keep:
            return h
        if h in self.cache:
            return self.cache[h]
        L, C, H = lch(h)
        if C < 10 or not self.anchors:             # neutral: same lightness, pure grey
            out = h if h in ("000000", "FFFFFF") else hex_from_lab(L, 0, 0)
        elif min(min(abs(lch(a[1])[2] - H), 360 - abs(lch(a[1])[2] - H)) for a in self.anchors) > 40:
            out = h                                # e.g. a RAG green: not a brand role, keep it
        else:
            def dist(a):
                aL, aC, aH = lch(a[1])
                dh = min(abs(aH - H), 360 - abs(aH - H))
                return (dh / 25) ** 2 + ((aL - L) / 45) ** 2
            slot, sh, th = min(self.anchors, key=dist)
            sL, sC, sH = lch(sh); tL, tC, tH = lch(th)
            if L >= sL:                                   # tint: keep the same share of the way to white
                nL = tL + (L - sL) * (100 - tL) / max(1e-6, 100 - sL)
            else:                                         # shade: same share of the way to black
                nL = tL * L / max(1e-6, sL)
            nC = tC * min(1.6, C / max(1e-6, sC))
            out = th if h == sh else from_lch(nL, nC, tH)
        self.cache[h] = out
        if out != h:
            self.changed[h] = out
        return out


SAMPLE = "The quick brown fox jumps over the lazy dog 0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ status / owner - %"


def text_width(font, M):
    m = M.get(font)
    return sum(m["advances"].get(c, 0.5) for c in SAMPLE) if m else None


def metrics_for(target):
    import fit_runner
    mod = fit_runner.load()
    patch_metrics(mod, target)
    return mod.METRICS


def width_of(text, font, M):
    m = M.get(font)
    return sum(m["advances"].get(c, 0.55) for c in text) if m else None


def font_scales(source, target):
    """{source font: factor <= 1} so text set in the target font takes no more width than it did in the source
    font (kit layouts have fixed boxes). Uses the fit checker's metrics plus the target brand's."""
    import fit_runner
    mod = fit_runner.load()
    patch_metrics(mod, target)
    M = mod.METRICS
    out = {}
    for old, (new, _b) in font_map(source, target).items():
        a, b = text_width(old, M), text_width(new, M)
        out[old] = round(min(1.0, a / b), 3) if a and b else 1.0
    return out


def font_map(source, target):
    """{source font name: (target font name, force bold)} for every font the kit writes."""
    sf, tf = source.get("fonts") or {}, target.get("fonts") or {}
    out = {}
    for key in ("heading", "body", "body_medium", "body_bold"):
        if sf.get(key):
            t = tf.get(key)
            bold = key == "body_bold" and not t
            out[sf[key]] = (t or tf.get("body"), bold)
    for extra in ("Calibri", "Arial"):
        out.setdefault(extra, (tf.get("body"), False))
    return out


def use(name):
    find(name)
    for target in ((RUN_BRANDS,) if RUN_BRANDS.parent.exists() else ()) + (SKILL_BRANDS,):
        try:
            target.mkdir(parents=True, exist_ok=True)
            (target / "active.json").write_text(json.dumps({"brand": name}))
            break
        except OSError:
            continue
    print(f"active brand: {name}")


def main():
    a = sys.argv[1:] or ["show"]
    if a[0] == "list":
        act = active_name()
        for d in dirs():
            for p in sorted(d.glob("*/brand.json")):
                n = p.parent.name
                print(("* " if n == act else "  ") + f"{n:16} {json.loads(p.read_text()).get('label', '')}   ({p.parent})")
    elif a[0] == "use":
        use(a[1])
    else:
        b = current()
        print(json.dumps({"name": b.name, "template": str(b.template), **{k: b[k] for k in ("roles", "fonts", "theme")}}, indent=1))


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))   # run on its own (python -I too): its sibling modules
    main()
