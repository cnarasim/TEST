"""Ulta deck delivery gate. Mandatory before ANY PPTX is shown or offered to the user.

    python tools/validate_deck.py <deck.pptx> --mapping 1,2,12,6

--mapping = the template slide number used for each output slide, in order.

Runs:
  1. ulta_pptx_fit.py         (bundled, unchanged) structural + text-fit vs template
  2. pptx_artwork_clearance.py (bundled, unchanged) picture intrusion vs template
  3. Ulta content gates        slide count, off-slide shapes, leftover sample text,
                               emptied template structure, digits in Playfair cells
  4. Render                    every slide to PNG (LibreOffice, substitute fonts)

Prints a STATUS BLOCK. Exit 0 only when no gate FAILs.
This does not replace pptx_source_pack.py prepare/check (source binding).
"""
import argparse, copy, hashlib, json, re, shutil, subprocess, sys, zipfile
from pathlib import Path
from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
VAL = ROOT / "modules" / "ultapowerpointvalidator" / "scripts"
import brand as _B   # noqa: E402
BRAND = _B.current()
REF = BRAND.template
MARK = BRAND.marker
COVER = BRAND.role("cover", 1)
import full_template as _FT0                           # noqa: E402
COVERS = {COVER} | (_FT0.kind("cover") if BRAND.get("layouts") else set())          # title runs past its frame (3 lines)
TITLE2 = ((_FT0.kind("divider") - {5, 23, 27}) | {_FT0.names()[n] for n in ("big-note", "big-note-close")}) \
    if BRAND.get("layouts") else set()                 # a divider or big-note line: 2 lines at its display size
RATING = re.compile(r"(?i)^\s*(\[[^\]]{1,24}\]|high|medium|low|strong|moderate|weak|none|partial|full|yes|no|n/?a|done|open|closed|on track|at risk|late|green|amber|red|good|fair|poor|planned|in progress|complete|not started|must|should|could|won't|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.? \d{1,2},? \d{4}|\d{4}-\d{2}-\d{2}|q[1-4] \d{4}|[+\-\u2212]?[$€£]?\d[\d,.]*\s?(?:%|[kmb]|h|hrs?|hours?|days?|weeks?|pts?)?)\s*$")   # scale words, placeholders, dates and figures (signed too) are data
STATUS_COLOURS = {"00B050", "0BA03E", "FFC000", "FF0000"}   # the brand's status palette (brand.json)
STATUS_MARKS = set("●○■□▲▼◆◇★►◀▶◄•")   # dot, square, arrow ... (brand_colours.MARKS)
REPEAT_OK = {21} | ({_FT0.names()["period-scorecard"]} if BRAND.get("layouts") else set())   # scorecards: prior = current is fine
FLOW = BRAND.role("flow")
OLDSTYLE = tuple((BRAND.get("fonts") or {}).get("oldstyle_digits") or ())
NS = {"p": "http://schemas.openxmlformats.org/presentationml/2006/main",
      "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
SAMPLE = [r"insert headline", r"text here", r"\bxx\b", r"\bkpi [a-z]\b", r"lorem ipsum",
          r"secondary text", r"primary text", r"mm/dd", r"group \d\b",
          r"bullet point \d", r"\bsub-headline\b", r"channel/ ?environment", r"content/ ?sentiment", r"date/ ?frequency",
          r"purpose/ ?performance", r"\bcategory [ab]\b",           # the grid (14) and card (7) samples
          r"name surname", r"metric description here", r"\bxx[bmk]\b", r"(?<![\w.])x%", r"\bitem [1-5]\b",
          r"divider slide", r"q1/2[23]\u2019"]                          # the 40-layout collection's samples (34-53)
SAMPLE_LINES = {"title", "headline", "sub-headline", "big note", "job title", "photo"}   # whole-line sample labels
SAMPLE_LINE_RX = [r"section \d", r"20\d\d headline", r"chart (title|detail)", r"funnel concept", r"goal [a-c]",
                  r"item [1-9]", r"group [1-9]"]                     # whole-line sample labels (timeline, journey, agenda)


def _plain_text(s):
    """Lower case, no-break and other odd spaces as plain spaces: the builder keeps a slide's last two words together
    with a no-break space ('Item\u00a01'), which a pattern with a plain space would miss."""
    return re.sub(r"[\u00a0\u2007\u202f\u2009]", " ", s or "").lower()


def placeholder_lines(x):
    """[(what, where)] for every bit of template placeholder text still on one slide (lxml slide element): the
    template's sample patterns (Lorem ipsum, Text here, XX%, MM/DD ...) and whole-line sample labels (Headline,
    Sub-headline, Section 1, 2021 headline ...)."""
    out = []
    whole = _plain_text(text_of(x))
    for pat in SAMPLE:
        m = re.search(pat, whole)
        if m:
            out.append((pat, m.group(0)))
    for para in x.iter("{%s}p" % NS["a"]):
        line = _plain_text("".join(t.text or "" for t in para.iter("{%s}t" % NS["a"]))).strip()
        if line in SAMPLE_LINES or any(re.fullmatch(rx, line) for rx in SAMPLE_LINE_RX):
            out.append(("label", line))
    for tr in x.iter("{%s}tr" % NS["a"]):               # the roadmap's header row of 'Month' cells, never filled in
        cells = [_plain_text(text_of(tc)).strip() for tc in tr.findall("{%s}tc" % NS["a"])]
        if sum(c == "month" for c in cells) >= 3:
            out.append(("label", "month"))
    seen, uniq = set(), []
    for w in out:
        if w[1] not in seen:
            seen.add(w[1]); uniq.append(w)
    return uniq


def is_placeholder(text):
    """True for a line that is the template's placeholder text, never a deck's own words."""
    t = _plain_text(text).strip()
    return bool(t) and (any(re.search(p, t) for p in SAMPLE) or t in SAMPLE_LINES
                        or any(re.fullmatch(rx, t) for rx in SAMPLE_LINE_RX))


def hold_back(out, move=True):
    """A deck that still shows template placeholder text is never left where a deliverable goes: it moves, with its
    sidecars and diagram files, to <deck>_validation/<deck>-INCOMPLETE.pptx. Returns (work copy or the deck itself
    when move=False, "slide 4 ('lorem ipsum'); ...") or (None, "") for a clean deck."""
    out = Path(out)
    held = placeholder_slides(out)
    if not held:
        return None, ""
    where = "; ".join(f"slide {k} ({', '.join(repr(w) for w in v[:2])})" for k, v in sorted(held.items()))
    if not move:
        return out, where
    vd = out.parent / (out.stem + "_validation")
    vd.mkdir(parents=True, exist_ok=True)
    work = vd / (out.stem + "-INCOMPLETE.pptx")
    moves = [(out, work)] + [(Path(str(out) + e), Path(str(work) + e)) for e in (".ulta.json", ".checks.json", ".audit.json")]
    moves += [(p, vd / p.name) for p in out.parent.glob(out.stem + "-slide*.drawio")]
    for a, b in moves:
        if a.exists():
            a.replace(b)
    try:                                              # never sent, but clean all the same: no template people inside
        import privacy
        privacy.scrub(work)
    except Exception:
        pass
    return work, where


def placeholder_slides(deck):
    """{slide number: [placeholder texts]} for a deck: what must never be delivered."""
    z = zipfile.ZipFile(deck)
    parts, _, _ = slide_parts(z)
    out = {}
    for i, part in enumerate(parts, 1):
        found = placeholder_lines(etree.fromstring(z.read(part)))
        if found:
            out[i] = [w for _, w in found]
    return out
ANNOT_PREFIX = "{http://schemas.openxmlformats.org/drawingml/2006/main}"


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def slide_parts(z):
    pres = etree.fromstring(z.read("ppt/presentation.xml"))
    rels = etree.fromstring(z.read("ppt/_rels/presentation.xml.rels"))
    tgt = {r.get("Id"): r.get("Target") for r in rels}
    size = pres.find("p:sldSz", NS)
    out = []
    for s in pres.find("p:sldIdLst", NS):
        t = tgt[s.get("{%s}id" % NS["r"])]
        out.append(t.lstrip("/") if t.startswith("/") else "ppt/" + t)
    return out, int(size.get("cx")), int(size.get("cy"))


DIAG = set()          # slide numbers drawn by the kit diagram engine (from <deck>.ulta.json)
INFO = set()          # template infographic slides (filled template slides; their own fidelity gate)
TRIM = set()          # template slides whose cards were trimmed to the content and re-centred (team): no 1:1 shape match
LIST = set()          # slides whose unused list items, columns or rows were dropped (their icons move with them)


def load_diag(deck):
    global DIAG, INFO, TRIM, LIST
    try:
        import layoutmeta; layoutmeta.restore(deck)    # an uploaded deck: its build record is inside the file
    except Exception:
        pass
    try:
        meta_ = json.loads(Path(str(deck) + ".ulta.json").read_text())
        DIAG = set(meta_.get("diagram_slides") or [])
        INFO = set(meta_.get("infographic_slides") or [])
        TRIM = set(meta_.get("trimmed_slides") or [])
        LIST = set(meta_.get("list_slides") or [])
    except Exception:
        DIAG, INFO, TRIM, LIST = set(), set(), set(), set()
    return DIAG


def text_of(el):
    return "".join(t.text or "" for t in el.iter("{%s}t" % NS["a"]))


def shape_facts(x):
    """name -> dict(bottom,right,left,top, empty_ratio, blank_rows) for one slide XML."""
    facts = {}
    tree = x.find(".//p:cSld/p:spTree", NS)
    for k, sp in enumerate(tree):
        nv = sp.find(".//p:cNvPr", NS)
        name = nv.get("name") if nv is not None else f"#{k}"
        xf = next((e for e in (sp.find("p:spPr/a:xfrm", NS), sp.find("p:xfrm", NS),
                               sp.find("p:grpSpPr/a:xfrm", NS)) if e is not None), None)
        off = xf.find("a:off", NS) if xf is not None else None
        ext = xf.find("a:ext", NS) if xf is not None else None
        if off is None or ext is None:
            continue
        x0, y0, w, h = (int(off.get("x")), int(off.get("y")), int(ext.get("cx")), int(ext.get("cy")))
        f = {"left": x0, "top": y0}
        tbl = sp.find(".//a:tbl", NS)
        if tbl is not None:
            h = max(h, sum(int(tr.get("h", 0)) for tr in tbl.findall("a:tr", NS)))
            live = [c for c in tbl.iter("{%s}tc" % NS["a"]) if not c.get("hMerge") and not c.get("vMerge")]
            f["empty_ratio"] = (sum(1 for c in live if not text_of(c).strip()) / len(live)) if live else 0
            f["live"] = len(live)
            f["blank_rows"] = {i for i, tr in enumerate(tbl.findall("a:tr", NS), 1) if not text_of(tr).strip()}
            rows = [tr.findall("a:tc", NS) for tr in tbl.findall("a:tr", NS)]
            ncol = max((len(r) for r in rows), default=0)
            f["empty_cols"] = {c + 1 for c in range(ncol)
                               if all(c >= len(r) or not text_of(r[c]).strip() for r in rows)}
        f["right"], f["bottom"] = x0 + w, y0 + h
        facts.setdefault(name, f)
    return facts


A = "{%s}" % NS["a"]


def run_styles(el):
    """(size, typeface, bullet) for every run with text under el; None = inherited."""
    out = set()
    for para in el.iter(A + "p"):
        ppr = para.find("a:pPr", NS)
        bullet = ppr is not None and ppr.find("a:buChar", NS) is not None
        for r in para.findall("a:r", NS):
            t = r.find("a:t", NS)
            if t is None or not (t.text or "").strip():
                continue
            rpr = r.find("a:rPr", NS)
            if set(t.text.strip()) <= STATUS_MARKS and str(run_colour(rpr)).upper() in STATUS_COLOURS:
                continue                           # a status mark: the brand colours gate checks it (marks only)
            lat = rpr.find("a:latin", NS) if rpr is not None else None
            out.add((rpr.get("sz") if rpr is not None else None,
                     lat.get("typeface") if lat is not None else None, bullet, run_colour(rpr)))
    return out


LIGHT = {"FFFFFF", "bg1", "lt1"}
THEME_LIGHT_FILLS = {"bg1", "lt1", "bg2", "lt2"} | {k for k, v in (BRAND.get("theme") or {}).items()
                                                     if _B.lch(v)[0] > 85}   # the brand theme's pale slots


BODY_MIN_SZ = 700


GROW_CAP_SZ = 2000   # build_deck may enlarge short text: tables up to 16 pt (grow_table), roomy text boxes up to 20 pt (grow_text)


def size_ok(sz, ref_sizes):
    """Template size, inherited, reduced by autofit.py (never below 7 pt), or enlarged up to 16 pt by grow_table."""
    if sz in ref_sizes:
        return True
    explicit = [int(x) for x in ref_sizes if x]
    if sz is None:
        return not explicit
    return int(sz) >= BODY_MIN_SZ and (not explicit or int(sz) <= max(max(explicit), GROW_CAP_SZ))


def run_colour(rpr):
    if rpr is None:
        return None
    sf = rpr.find("a:solidFill", NS)
    if sf is None or not len(sf):
        return None
    return sf[0].get("val")


def is_light_fill(el):
    """True when the cell/shape has no fill of its own or a pale one (text then sits on the slide's
    cream background or a pale band)."""
    pr = el.find("a:tcPr", NS) if el.tag.endswith("}tc") else el.find("p:spPr", NS)
    if pr is None:
        return True
    sf = pr.find("a:solidFill", NS)
    if sf is None or not len(sf):
        return pr.find("a:gradFill", NS) is None and pr.find("a:blipFill", NS) is None
    c = sf[0]; v = c.get("val") or ""
    if c.tag.endswith("srgbClr") and len(v) == 6:
        r, g, b = (int(v[k:k + 2], 16) for k in (0, 2, 4))
        return 0.2126 * r + 0.7152 * g + 0.0722 * b > 200
    return v in THEME_LIGHT_FILLS


def table_cells(sp):
    tbl = sp.find(".//a:tbl", NS)
    if tbl is None:
        return {}
    return {(ri, ci): tc for ri, tr in enumerate(tbl.findall("a:tr", NS), 1)
            for ci, tc in enumerate(tr.findall("a:tc", NS), 1)}


def named_shapes(x):
    out = {}
    for k, sp in enumerate(x.find(".//p:cSld/p:spTree", NS)):
        nv = sp.find(".//p:cNvPr", NS)
        out.setdefault(nv.get("name") if nv is not None else f"#{k}", sp)
    return out


import typeset as _T   # noqa: E402


def std_pairs():
    """(size, font) pairs of the type standard (typeset.py: template slide 3) - allowed wherever the template had
    a different size or weight for that role."""
    import typeset as _T
    return {(str(int(v[1] * 100)), v[0]) for v in _T.spec(BRAND).values()}


def style_and_duplicate_gates(i, x, rx, src):
    fails = []
    cand, ref = named_shapes(x), named_shapes(rx)
    for name, sp in cand.items():
        rsp = ref.get(name)
        cells, rcells = table_cells(sp), (table_cells(rsp) if rsp is not None else {})
        for (ri, ci), tc in cells.items():
            txt = text_of(tc).strip()
            rtc = rcells.get((ri, ci))
            if not txt or rtc is None:
                continue
            if ri == 1 and not text_of(rtc).strip():
                fails.append(f"slide {i}: table '{name}' header cell r1c{ci} is empty in template slide {src} "
                             f"but now holds '{txt[:30]}' -> leave it empty (its text is invisible or clashes)")
            rs, cs = run_styles(rtc), run_styles(tc)
            if i in LIST:                              # a shortened list: the kept cells moved left or up - any template
                rs = rs.union(*(run_styles(c) for (r_, _), c in rcells.items() if r_ == ri))   # cell of that row
            if rs and cs - rs:
                rsz = {t[0] for t in rs}; rfn = {t[1] for t in rs}; rbu = {t[2] for t in rs}; rco = {t[3] for t in rs}
                inherit_white = ri == 1 and rco <= {None}          # header text inherits white from the table style
                std = std_pairs()
                rfn = rfn | {_T.map_font(f, _T.spec(BRAND)) for f in rfn if f} | {_T.spec(BRAND)["headline"][0]}    # Medium -> Bold etc. (the type standard)
                bad = [st for st in cs - rs if (((not size_ok(st[0], rsz) or st[1] not in rfn) and (st[0], st[1]) not in std)
                       or st[2] not in rbu
                       or (st[3] not in rco and not (inherit_white and str(st[3]).upper() in ("FFFFFF", "BG1", "LT1"))
                           and not (i in INFO and str(st[3]).upper() in STATUS_COLOURS)))]
                if bad:
                    fails.append(f"slide {i}: table '{name}' r{ri}c{ci} '{txt[:30]}' uses formatting not in the "
                                 f"template cell (size/font/bullet {sorted(map(str, bad))[:2]} vs {sorted(map(str, rs))[:2]}) "
                                 "-> replace the text inside the existing runs; never add new runs/paragraphs/bullets")
        if not cells and rsp is not None and not BRAND.is_headline(rsp):
            txt = text_of(sp).strip()
            if txt and not text_of(rsp).strip():
                fails.append(f"slide {i}: '{name}' has no text in template slide {src} but now holds "
                             f"'{txt[:30]}' -> put text only in the template's text regions")
            rs, cs = run_styles(rsp), run_styles(sp)
            if txt and rs and cs - rs:
                rsz = {t[0] for t in rs}; rfn = {t[1] for t in rs}; rco = {t[3] for t in rs}
                std = std_pairs()
                rfn = rfn | {_T.map_font(f, _T.spec(BRAND)) for f in rfn if f} | {_T.spec(BRAND)["headline"][0]}
                bad = [st for st in cs - rs if (((not size_ok(st[0], rsz) or st[1] not in rfn) and (st[0], st[1]) not in std)
                       or st[3] not in rco)]
                if bad:
                    fails.append(f"slide {i}: '{name}' '{txt[:30]}' uses formatting not in the template box "
                                 f"(size/font/colour {sorted(map(str, bad))[:2]} vs {sorted(map(str, rs))[:2]}) "
                                 "-> write into the existing run; never add new runs/paragraphs")
        for el in ([tc for tc in cells.values()] if cells else [sp]):
            if not text_of(el).strip():
                continue
            cols = {st[3] for st in run_styles(el)}
            ref_el = rsp if not cells else None
            if ref_el is None and cells:
                key = next((k for k, v in cells.items() if v is el), None)
                ref_el = rcells.get(key) if key else None
            ref_cols = {st[3] for st in run_styles(ref_el)} if ref_el is not None else set()
            if cells and i in LIST and key:
                ref_cols |= {st[3] for (r_, _), c in rcells.items() if r_ == key[0] for st in run_styles(c)}
            if (cols & LIGHT) - ref_cols and is_light_fill(el):
                fails.append(f"slide {i}: '{name}' white text on a light background ('{text_of(el).strip()[:30]}') "
                             "-> invisible; keep the template run colour")
        rows, rrows = {}, {}
        for (ri, ci), tc in cells.items():
            rows.setdefault(ri, []).append(text_of(tc).strip())
        for (ri, ci), tc in rcells.items():
            rrows.setdefault(ri, []).append(text_of(tc).strip())
        for ri, vals in rows.items():
            if i in INFO or src in REPEAT_OK:          # a scorecard row may repeat a value (prior = target)
                break
            seen = [v for v in vals if len(v) >= 3 and not RATING.match(v)]   # a rating grid repeats its scale words
            dup = {v for v in seen if seen.count(v) > 1 and rrows.get(ri, []).count(v) < seen.count(v)}
            if dup:
                fails.append(f"slide {i}: table '{name}' row {ri} repeats {sorted(dup)} in several cells "
                             "-> each cell needs its own content, or use a layout with fewer columns")
    texts = [text_of(sp).strip() for n, sp in cand.items() if sp.find(".//a:tbl", NS) is None]
    rtexts = [text_of(sp).strip() for sp in ref.values()]
    for v in {t for t in texts if len(t) >= 3 and texts.count(t) >= 3}:
        if rtexts.count(v) < texts.count(v):
            fails.append(f"slide {i}: '{v[:30]}' is repeated in {texts.count(v)} boxes "
                         "-> each box needs its own content")
    return fails


def content_gates(deck, mapping):
    fails, warns = [], []
    z, rz = zipfile.ZipFile(deck), zipfile.ZipFile(REF)
    parts, W, H = slide_parts(z)
    rparts, _, _ = slide_parts(rz)
    if len(parts) != len(mapping):
        fails.append(f"slide count {len(parts)} != mapping length {len(mapping)}")
    tol = 12700 * 2
    for i, part in enumerate(parts, 1):
        if i in DIAG:                                  # drawn slides: no template slide to compare, but nothing may
            x = etree.fromstring(z.read(part))         # leave the slide and no sample text may stay
            for name, f in shape_facts(x).items():
                if f["bottom"] > H + tol or f["right"] > W + tol or f["left"] < -tol or f["top"] < -tol:
                    fails.append(f"slide {i}: '{name}' extends beyond the slide edge "
                                 f"(bottom {f['bottom'] / 914400:.2f}in, slide {H / 914400:.2f}in)")
            for pat, what in placeholder_lines(x):
                fails.append(f"slide {i}: leftover template sample text matching '{pat}'" if pat != "label" else
                             f"slide {i}: leftover template sample label '{what.title()}' - give it the slide's own words")
            continue
        x = etree.fromstring(z.read(part))
        src = mapping[i - 1] if i <= len(mapping) else None
        ref = shape_facts(etree.fromstring(rz.read(rparts[src - 1]))) if src else {}
        for name, f in shape_facts(x).items():
            r = ref.get(name, {})
            lim_b, lim_r = max(H, r.get("bottom", 0)), max(W, r.get("right", 0))
            lim_l, lim_t = min(0, r.get("left", 0)), min(0, r.get("top", 0))
            if f["bottom"] > lim_b + tol or f["right"] > lim_r + tol or f["left"] < lim_l - tol or f["top"] < lim_t - tol:
                fails.append(f"slide {i}: '{name}' extends beyond the slide edge "
                             f"(bottom {f['bottom'] / 914400:.2f}in, slide {H / 914400:.2f}in)")
            if "empty_ratio" in f:
                base = r.get("empty_ratio", 0)
                if f["empty_ratio"] > 0.4 and f["empty_ratio"] > base + 0.15:
                    fails.append(f"slide {i}: table '{name}' {round(f['empty_ratio'] * f['live'])}/{f['live']} cells "
                                 f"empty (template slide {src}: {base:.0%}) -> emptied template structure; "
                                 "pick a source slide that fits the content")
                spacer = sorted(r.get("empty_cols", set()) - f.get("empty_cols", set()))
                if spacer:
                    fails.append(f"slide {i}: table '{name}' column(s) {spacer} are an empty spacer/arrow column "
                                 f"in template slide {src} but now hold text -> leave them empty; this layout has "
                                 "fewer content columns, so choose another source slide for more")
                new_blank = sorted(f["blank_rows"] - r.get("blank_rows", set()) - {1})
                if new_blank and not (f["empty_ratio"] > 0.4 and f["empty_ratio"] > base + 0.15):
                    fails.append(f"slide {i}: table '{name}' row(s) {new_blank} left blank "
                                 "-> use the row for real content or choose another source table")
        if src:
            fails += style_and_duplicate_gates(i, x, etree.fromstring(rz.read(rparts[src - 1])), src)
        labels = 0
        for pat, what in placeholder_lines(x):         # sample text, and a label left as the template's word
            if pat != "label":
                fails.append(f"slide {i}: leftover template sample text matching '{pat}'")
            elif not labels:
                labels += 1
                fails.append(f"slide {i}: leftover template sample label '{what.title()}' - give it the slide's own words")
        for tr in x.iter("{%s}tr" % NS["a"]):          # schema order: cells, then extLst - PowerPoint is strict
            kids = [etree.QName(c).localname for c in tr]
            if "extLst" in kids and kids.index("extLst") != len(kids) - 1:
                fails.append(f"slide {i}: a table row has its cells after extLst (invalid order) - PowerPoint drops the "
                             "cell colours and shows the table style instead; rebuild with this skill's build_deck.py")
                break
        cells = ["".join(t.text or "" for t in tc.iter("{%s}t" % NS["a"])).strip() for tc in x.iter("{%s}tc" % NS["a"])]
        if any(re.fullmatch(r"(?i)(sub-?)?headline", c) for c in cells):   # a header cell still says "Headline"
            fails.append(f"slide {i}: a table header still shows the template's sample word 'Headline' - give the header "
                         "row its own words (\"table\": [[\"Orders\", \"Ready time\", …], [ …values… ]])")
        for r in x.iter("{%s}r" % NS["a"]):
            rpr = r.find("a:rPr", NS)
            lat = rpr.find("a:latin", NS) if rpr is not None else None
            t = r.find("a:t", NS)
            if lat is not None and any(f in (lat.get("typeface") or "") for f in OLDSTYLE) and t is not None \
                    and re.search(r"\d", t.text or ""):
                warns.append(f"slide {i}: digits in old-style-figure font run '{t.text}' (old-style figures, "
                             "'01' reads like 'os') -> move codes/dates to a Circular Std cell")
    return fails, warns


HEADLINE_MIN_SZ = 1600
HEADLINE_WAIVABLE = ("framing p:spPr", ".//a:xfrm", "run-style membership")


def headline_exception(deck, mapping, report):
    """Owner-approved exception (fit_headlines.py): the headline box may be widened to the content
    width and its font stepped down to 28 pt, so that it stays on ONE line. Returns
    (waivable structural check ids, fails, info)."""
    ok, fails, info = set(), [], []
    z, rz = zipfile.ZipFile(deck), zipfile.ZipFile(REF)
    parts, W, _ = slide_parts(z)
    rparts, _, _ = slide_parts(rz)
    regions = {sl.get("slide"): sl.get("regions") or [] for sl in report.get("slides") or []}
    for i, part in enumerate(parts, 1):
        if i > len(mapping):
            break
        if i in DIAG:
            ok.add(f"slide{i} ")
            continue
        if i in TRIM:                                  # fewer cards than the template, re-centred: count/position differ
            ok.add(f"slide{i} ")
        rx = etree.fromstring(rz.read(rparts[mapping[i - 1] - 1]))
        rname, rsp = None, None
        for sp in rx.find(".//p:cSld/p:spTree", NS):
            if BRAND.is_headline(sp):
                nv = sp.find(".//p:cNvPr", NS); rname, rsp = (nv.get("name") if nv is not None else None), sp
                break
        if rname is None:
            continue
        x = etree.fromstring(z.read(part))
        for k, sp in enumerate(x.find(".//p:cSld/p:spTree", NS)):
            nv = sp.find(".//p:cNvPr", NS)
            if nv is None or nv.get("name") != rname or not text_of(sp).strip():
                continue
            txt = text_of(sp).strip()
            sizes = [int(r.get("sz")) for r in sp.iter(A + "rPr") if r.get("sz")]
            if sizes and min(sizes) < HEADLINE_MIN_SZ:
                fails.append(f"slide {i}: headline font {min(sizes) / 100:.0f} pt is below the 16 pt floor -> shorten it")
            xf = sp.find("p:spPr/a:xfrm", NS)
            if xf is not None:
                off, ext = xf.find("a:off", NS), xf.find("a:ext", NS)
                if int(off.get("x")) + int(ext.get("cx")) > W + 12700:
                    fails.append(f"slide {i}: headline box runs past the right edge of the slide")
            reg = next((g for g in regions.get(i, []) if g.get("text", "").strip() == txt), None)
            widest = max((ln["rect"][2] for ln in (reg or {}).get("lines") or []), default=0)
            if reg and (reg.get("lineCount") or 1) == 1 and widest > 0.95 * (reg.get("innerWidthPt") or 1):
                fails.append(f"slide {i}: headline fills {widest / reg['innerWidthPt']:.0%} of its box ('{txt[:50]}') "
                             "-> too tight to be safe; run tools/autofit.py or shorten it")
            if reg and (reg.get("lineCount") or 1) > 1:
                fails.append(f"slide {i}: headline needs {reg['lineCount']} lines ('{txt[:50]}') -> run "
                             "tools/autofit.py; if it still wraps at 16 pt, shorten the wording")
            for check in HEADLINE_WAIVABLE:
                ok.add(f"slide{i} object{k} {check}")
                ok.update(f"slide{i} object{k} region{n} source {check}" for n in range(4))
            info.append((i, txt))
            break
    return ok, fails, info


CHROME = {"the ULTA logo": (0.40, 6.62, 1.80, 7.25), "the confidentiality footer": (9.55, 6.85, 12.95, 7.15)}   # inches
import full_template as _FT                           # noqa: E402
NO_CHROME = {1, 2, 5, 23, 27, 32, 33} | _FT.full_bleed_sources()   # covers, dividers, statements, closing: full bleed


def chrome_gate(deck, mapping):
    """Nothing on a content slide may touch the logo or the footer line (the template keeps them clear)."""
    if BRAND.name != "ulta":
        return []
    IN_ = 914400
    out = []
    z = zipfile.ZipFile(deck)
    parts, _, _ = slide_parts(z)
    for i, part in enumerate(parts, 1):
        if i > len(mapping) or mapping[i - 1] in NO_CHROME:
            continue
        x = etree.fromstring(z.read(part))
        for el in x.find(".//p:cSld/p:spTree", NS):
            tag = etree.QName(el).localname
            if tag not in ("sp", "pic", "graphicFrame", "grpSp", "cxnSp"):
                continue
            if el.find(".//p:nvPr/p:ph", NS) is not None and el.find(".//p:nvPr/p:ph", NS).get("type") in ("sldNum", "ftr", "dt"):
                continue
            xf = el.find("p:grpSpPr/a:xfrm", NS) if tag == "grpSp" else el.find("p:xfrm", NS) if tag == "graphicFrame" \
                else el.find("p:spPr/a:xfrm", NS)
            if xf is None or xf.find("a:off", NS) is None:
                continue
            ox, oy = int(xf.find("a:off", NS).get("x")) / IN_, int(xf.find("a:off", NS).get("y")) / IN_
            ex, ey = int(xf.find("a:ext", NS).get("cx")) / IN_, int(xf.find("a:ext", NS).get("cy")) / IN_
            if ex == 0 and ey == 0:
                continue
            name = (el.find(".//p:cNvPr", NS).get("name") or "") if el.find(".//p:cNvPr", NS) is not None else ""
            for what, (a, b, c, d) in CHROME.items():
                if ox < c and ox + ex > a and oy < d and oy + ey > b:
                    out.append(f"slide {i}: '{name[:30]}' runs into {what} (bottom at {oy + ey:.2f} in) - keep content "
                               "above 6.5 in")
    return out


def package_integrity(deck):
    """Problems that make PowerPoint 'repair' a file or show 'The picture can't be displayed'."""
    probs = []
    z = zipfile.ZipFile(deck)
    names = set(z.namelist())
    try:
        ct = etree.fromstring(z.read("[Content_Types].xml"))
    except KeyError:
        return ["[Content_Types].xml missing"]
    CT = "{http://schemas.openxmlformats.org/package/2006/content-types}"
    defaults = {d.get("Extension").lower() for d in ct.findall(CT + "Default")}
    overrides = {o.get("PartName").lstrip("/") for o in ct.findall(CT + "Override")}
    for n in names:
        if n.endswith("/") or n == "[Content_Types].xml":
            continue
        if n not in overrides and n.rsplit(".", 1)[-1].lower() not in defaults:
            probs.append(f"part {n} has no content type")
    for rel_name in [n for n in names if n.endswith(".rels")]:
        base = rel_name.replace("_rels/", "").rsplit(".rels", 1)[0]
        folder = base.rsplit("/", 1)[0] if "/" in base else ""
        rels = etree.fromstring(z.read(rel_name))
        ids = {}
        for r in rels:
            rid = r.get("Id")
            if rid in ids:
                probs.append(f"{rel_name}: duplicate relationship id {rid}")
            ids[rid] = r
            if r.get("TargetMode") == "External":
                continue
            t = r.get("Target")
            tgt = t.lstrip("/") if t.startswith("/") else "/".join(
                [x for x in (folder + "/" + t).split("/") if x])
            parts_ = []
            for seg in tgt.split("/"):
                if seg == "..":
                    parts_ and parts_.pop()
                elif seg != ".":
                    parts_.append(seg)
            tgt = "/".join(parts_)
            if tgt not in names:
                probs.append(f"{rel_name}: {rid} points to missing part {tgt}")
        if base in names and base.endswith(".xml"):
            x = etree.fromstring(z.read(base))
            for node in x.iter():
                for attr, val in node.attrib.items():
                    if attr.startswith("{%s}" % NS["r"]) and val and val not in ids:
                        probs.append(f"{base}: reference {val} has no relationship (broken picture/link)")
    return sorted(set(probs))[:20]


FIT_SHA = "bcc2f9de8e06f722a279100e873d66522be763269340d1eea96f4e2866d17d4e"
PIC_TOL = 0.01
HEAD_PIC_TOL = 12.0   # pt2: a headline's estimated line box (generous leading) grazing an icon below it is not a collision


def approved_change(check, headline_ok=()):
    """Structural differences made on purpose: text size markers (autofit), the widened headline box, and
    slide 20's band table re-aligned to its 4 boxes. Everything else (moved pictures, layout) still blocks."""
    return "membership" in check or check in headline_ok or any(
        p.endswith(" ") and check.startswith(p) for p in headline_ok)


def flow_table_waivers(deck, mapping):
    """'slideN ' prefixes for slide-20 flows re-laid out by build_deck.py (N steps / bands aligned to boxes).
    Their geometry is checked by flow_alignment_gate instead; text, overflow and colour checks still apply."""
    out = set()
    try:
        meta_ = json.loads(Path(str(deck) + ".ulta.json").read_text())
        out |= {f"slide{i} " for i in (meta_.get("flow_slides") or []) + (meta_.get("list_slides") or [])   # rows / columns dropped on purpose
                + (meta_.get("infographic_slides") or [])}      # template infographics: checked by the fidelity gate
    except Exception:
        pass
    z = zipfile.ZipFile(deck)
    parts, _, _ = slide_parts(z)
    for i, part in enumerate(parts, 1):
        if i > len(mapping) or mapping[i - 1] != FLOW:
            continue
        x = etree.fromstring(z.read(part))
        for k, sp in enumerate(x.find(".//p:cSld/p:spTree", NS)):
            tbl = sp.find(".//a:tbl", NS)
            if tbl is not None and len(tbl.findall("a:tblGrid/a:gridCol", NS)) != 5:
                out.add(f"slide{i} ")          # flow re-laid out for N steps: geometry checked by the alignment gate
    return out


def statement_anchor_waivers(deck, mapping):
    """Slide 6 (two boxes): build_deck.py centres a one-sentence statement in its box ("Highlight" shapes). Waived only
    when the vertical anchor is the sole difference in that box's text body properties."""
    out = set()
    if BRAND.name != "ulta":
        return out
    z, rz = zipfile.ZipFile(deck), zipfile.ZipFile(REF)
    parts, _, _ = slide_parts(z)
    rparts, _, _ = slide_parts(rz)
    def bodies(xml):
        x = etree.fromstring(xml); res = []
        for sp in x.find(".//p:cSld/p:spTree", NS):
            bp = sp.find(".//a:bodyPr", NS)
            if bp is None:
                res.append(None); continue
            bp = copy.deepcopy(bp); bp.attrib.pop("anchor", None); res.append(etree.tostring(bp))
        return res
    ref6 = bodies(rz.read(rparts[5]))
    for i, part in enumerate(parts, 1):
        if i <= len(mapping) and mapping[i - 1] == 6:
            xml = z.read(part)
            if b'name="Highlight ' in xml and bodies(xml) == ref6:
                out |= {f"slide{i} object{k} .//a:bodyPr" for k in range(1, 40)}
    return out


def card_anchor_waivers(deck, mapping):
    """Slide 9 (three big numbers): build_deck.py centres number + label in the card. Slide 7 (cards): it gives the
    cells of one row one shared top inset so the sub-headlines line up (align_card_rows). Waived only when the vertical
    anchor (and on slide 7 the top / bottom inset) is the sole difference in the table's cell properties."""
    out = set()
    z, rz = zipfile.ZipFile(deck), zipfile.ZipFile(REF)
    parts, _, _ = slide_parts(z)
    rparts, _, _ = slide_parts(rz)
    def cells(xml, attrs):
        x = etree.fromstring(xml)
        tc = []
        for pr in x.iterfind(".//a:tbl//a:tcPr", NS):
            pr = copy.deepcopy(pr)
            for a in attrs:
                pr.attrib.pop(a, None)
            tc.append(etree.tostring(pr))
        return tc
    for i, part in enumerate(parts, 1):
        src = mapping[i - 1] if i <= len(mapping) else None
        if src in (7, 9) and BRAND.name == "ulta":
            attrs = ("anchor",) if src == 9 else ("anchor", "marT", "marB")
            if cells(z.read(part), attrs) == cells(rz.read(rparts[src - 1]), attrs):
                out |= {f"slide{i} object{k} .//a:tcPr" for k in range(1, 40)}
    return out


def picture_clearance(deck, mapping, headline_ok=()):
    """Same measurement as the bundled pptx_artwork_clearance.py (imports the hash-pinned ulta_pptx_fit.py),
    but it accepts approved size/headline changes instead of refusing. Returns (result, intrusions, note)."""
    mod = VAL / "ulta_pptx_fit.py"
    if hashlib.sha256(mod.read_bytes()).hexdigest() != FIT_SHA:
        return "UNVERIFIED", [], "fit validator hash mismatch"
    sys.path.insert(0, str(VAL))
    import ulta_pptx_fit as fit   # the bundled checker, verified above
    _B.patch_metrics(fit, BRAND)
    src, out = fit.Deck(str(REF)), fit.Deck(str(deck))
    try:
        blocking = [c["check"] for c in fit.structural(src, out, mapping)
                    if not c["passed"] and not approved_change(c["check"], headline_ok)]
        if blocking:
            return "UNVERIFIED", [], f"structure differs from template: {blocking[:3]}"
        risks, unmodelled = [], False
        for i, si in enumerate(mapping, 1):
            if i in DIAG or i in INFO:                 # template infographics move their pins / markers on purpose
                continue
            sr, so, sw = src.regions(si)
            cr, co, cw = out.regions(i)
            unmodelled |= bool(cw or sw)
            before_all = {r["key"]: fit.measure(src, r) for r in sr}
            pics = {o["key"]: o for o in so if o["kind"] == "pic"}
            for r in cr:
                cur, before = fit.measure(out, r), before_all.get(r["key"])
                if before is None:
                    continue
                for ob in co:
                    if ob["kind"] != "pic" or fit.contains(ob["rect"], cur["rectPt"]):
                        continue
                    old = pics.get(ob["key"])
                    if old is not None and old["rect"] != ob["rect"] and i not in LIST:   # a shortened list: icons move with
                        return "FAIL", [], f"picture {ob['key']} on slide {i} was moved"   # their column or row
                    area = sum(fit.overlap(l["rect"], ob["rect"]) for l in cur.get("lines", []))
                    old_area = sum(fit.overlap(l["rect"], old["rect"]) for l in before.get("lines", [])) if old is not None else 0.0   # added: measured
                    tol = HEAD_PIC_TOL if MARK.lower() in (before.get("text") or "").lower() else PIC_TOL
                    if old_area > 0:                   # a label the template spaced under its icon: only a real increase counts
                        tol = max(tol, HEAD_PIC_TOL + 0.05 * old_area)
                    if area > tol and area - old_area > tol:
                        risks.append({"slide": i, "text": cur["text"], "area_pt2": round(area, 2)})
        if risks:
            return "FAIL", risks, f"{len(risks)} text/picture collision(s)"
        return "PASS", [], "0 new text/picture overlaps" + ("; template-native rotated shapes not modelled" if unmodelled else "")
    finally:
        src.z.close(); out.z.close()


def summary_layer_removed(path):
    """In place, for structure-check copies only: take out the summary layer build_deck adds to a slide (the takeaway line
    under the headline, the decision bar above the footer) - additions outside the template's own shapes, as the
    full-width headline is - so the template comparison sees the template's layout."""
    z = zipfile.ZipFile(path)
    items = {n: z.read(n) for n in z.namelist()}
    infos = {n: z.getinfo(n) for n in z.namelist()}
    z.close()
    hit = False
    for n, d in items.items():
        if re.match(r"ppt/slides/slide\d+\.xml$", n) and any(k in d for k in (b"ULTA summary", b"ULTA decision", b"ULTA takeaway", b"ULTA icon ")):
            x = etree.fromstring(d)
            for nv in list(x.iter("{%s}cNvPr" % NS["p"])):
                if nv.get("name") in ("ULTA summary", "ULTA decision", "ULTA takeaway") or (nv.get("name") or "").startswith("ULTA icon "):   # (2b)
                    sp = nv.getparent().getparent()
                    sp.getparent().remove(sp)
            items[n] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
            hit = True
    if hit:
        import atomic
        with atomic.zip_out(path) as w:
            for n, d in items.items():
                w.writestr(infos[n], d)


def layout_headlines_restored(path, mapping=None):
    """In place, for structure-check copies only: the deck's layouts carry the full-width headline box its content
    slides use (fit_headlines.widen_layouts, the owner-approved headline exception); put the template's own box back
    so the template comparison sees the template's layout. Only a placeholder whose box differs in width alone."""
    z, rz = zipfile.ZipFile(path), zipfile.ZipFile(REF)
    items = {n: z.read(n) for n in z.namelist()}
    infos = {n: z.getinfo(n) for n in z.namelist()}
    z.close()
    pat = re.compile(r"ppt/slideLayouts/[^/]+\.xml$")
    def lname(x):
        c = x.find("p:cSld", NS)
        return c.get("name") if c is not None else None
    ref = {}
    for n in rz.namelist():
        if pat.match(n):
            rx = etree.fromstring(rz.read(n))
            ref[n] = rx
            ref.setdefault(("name", lname(rx)), rx)
    def key(sp):
        ph = sp.find(".//p:nvPr/p:ph", NS)
        return None if ph is None else (ph.get("type") or "body", ph.get("idx") or "0")
    changed = 0
    for n in list(items):
        if not pat.match(n):
            continue
        x = etree.fromstring(items[n])
        rx = ref.get(n)
        if rx is None or lname(rx) != lname(x):
            rx = ref.get(("name", lname(x)))
        if rx is None:
            continue
        rsp = {key(sp): sp for sp in rx.iter("{%s}sp" % NS["p"]) if key(sp)}
        dirty = False
        for sp in x.iter("{%s}sp" % NS["p"]):
            r = rsp.get(key(sp))
            xf = sp.find("p:spPr/a:xfrm", NS)
            rxf = r.find("p:spPr/a:xfrm", NS) if r is not None else None
            if xf is None or rxf is None:
                continue
            o, ro = xf.find("a:off", NS), rxf.find("a:off", NS)
            e, re_ = xf.find("a:ext", NS), rxf.find("a:ext", NS)
            if None in (o, ro, e, re_) or (o.attrib, e.get("cy")) != (ro.attrib, re_.get("cy")) or e.get("cx") == re_.get("cx"):
                continue
            sp.find("p:spPr", NS).replace(xf, copy.deepcopy(rxf))
            dirty = True; changed += 1
        if dirty:
            items[n] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
    rlay = {lname(rx): rx for k, rx in ref.items() if isinstance(k, str)}
    order, _, _ = slide_parts(zipfile.ZipFile(path))
    rorder, _, _ = slide_parts(rz)
    for n in list(items):                             # a slide given the box its layout used to lend it (so widening the
        if not re.match(r"ppt/slides/slide\d+\.xml$", n):   # layout did not move it) is the same as inheriting it
            continue
        i = order.index(n) + 1 if n in order else 0
        src = mapping[i - 1] if mapping and 0 < i <= len(mapping) else None
        rslide = etree.fromstring(rz.read(rorder[src - 1])) if src and src <= len(rorder) else None
        owned = {key(sp) for sp in rslide.iter("{%s}sp" % NS["p"]) if key(sp) and sp.find("p:spPr/a:xfrm", NS) is not None} \
            if rslide is not None else set()          # (the template slide's own boxes stay as they are)
        rels = items.get(n.replace("slides/", "slides/_rels/") + ".rels")
        m = re.search(rb'Target="\.\./slideLayouts/([^"]+)"', rels or b"")
        lay = items.get("ppt/slideLayouts/" + m.group(1).decode()) if m else None
        rx = rlay.get(lname(etree.fromstring(lay))) if lay else None
        if rx is None:
            continue
        rsp = {key(sp): sp for sp in rx.iter("{%s}sp" % NS["p"]) if key(sp)}
        x = etree.fromstring(items[n])
        dirty = False
        for sp in x.iter("{%s}sp" % NS["p"]):
            r = rsp.get(key(sp)) if key(sp) else None
            xf = sp.find("p:spPr/a:xfrm", NS)
            rxf = r.find("p:spPr/a:xfrm", NS) if r is not None else None
            if xf is not None and rxf is not None and key(sp) not in owned and \
                    etree.tostring(xf, method="c14n") == etree.tostring(rxf, method="c14n"):
                sp.find("p:spPr", NS).remove(xf)
                dirty = True; changed += 1
        if dirty:
            items[n] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
    if changed:
        import atomic
        with atomic.zip_out(path) as w:
            for n, d in items.items():
                w.writestr(infos[n], d)
    return changed


def headline_restored_copy(deck, mapping, dest):
    """Copy of the deck with every headline shape replaced by the template's own headline shape, so the
    unchanged artwork gate (which refuses any framing change) can check all OTHER text against pictures."""
    z, rz = zipfile.ZipFile(deck), zipfile.ZipFile(REF)
    parts, _, _ = slide_parts(z)
    rparts, _, _ = slide_parts(rz)
    items = {n: z.read(n) for n in z.namelist()}
    for i, part in enumerate(parts, 1):
        if i > len(mapping):
            break
        rx = etree.fromstring(rz.read(rparts[mapping[i - 1] - 1]))
        rsp = next((sp for sp in rx.find(".//p:cSld/p:spTree", NS) if BRAND.is_headline(sp)), None)
        if rsp is None:
            continue
        name = rsp.find(".//p:cNvPr", NS).get("name")
        x = etree.fromstring(items[part])
        tree = x.find(".//p:cSld/p:spTree", NS)
        for sp in list(tree):
            nv = sp.find(".//p:cNvPr", NS)
            if nv is not None and nv.get("name") == name and text_of(sp).strip():
                tree.replace(sp, copy.deepcopy(rsp))
                break
        items[part] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
    import atomic
    with atomic.zip_out(dest) as w:
        for n in z.namelist():
            w.writestr(z.getinfo(n), items[n])
    return dest


def flow_alignment_gate(deck, mapping):
    """Template slide 20 (4-step flow): every step box must sit centred in its own label band."""
    from pptx import Presentation
    fails = []
    prs = Presentation(str(deck))
    for i, s in enumerate(prs.slides, 1):
        if i > len(mapping) or mapping[i - 1] != FLOW or i in DIAG:
            continue
        tbl = next((sh for sh in s.shapes if sh.has_table), None)
        if tbl is None:
            continue
        boxes = sorted(sh.left + sh.width // 2 for sh in s.shapes if sh.has_text_frame and not sh.has_table
                       and sh.text_frame.text.strip() and sh.top > tbl.top and sh.width < tbl.width / 3)
        x, centres = tbl.left, []
        for c in tbl.table.columns:
            centres.append(x + c.width // 2); x += c.width
        labels = [c.text.strip() for c in tbl.table.rows[0].cells]
        if len(centres) != len(boxes):
            fails.append(f"slide {i}: {len(centres)} label bands but {len(boxes)} step boxes -> the bands cannot line up; "
                         f"give exactly {len(boxes)} labels (build_deck.py then re-aligns the bands to the boxes)")
            continue
        off = max(abs(a - b) for a, b in zip(centres, boxes)) / 914400
        if off > 0.15:
            fails.append(f"slide {i}: step boxes are up to {off:.2f} in off-centre from their label bands "
                         f"({labels}) -> rebuild with build_deck.py")
    return fails


def overflow_gate(report_path, mapping=()):
    """Hard FAIL for any text region the fit metrics say needs more lines than its box holds
    (real Circular/Playfair metrics, not the substitute fonts used in the render)."""
    fails = []
    try:
        rep = json.loads(Path(report_path).read_text())
    except Exception:
        return fails
    def walk(o, slide):
        if isinstance(o, dict):
            if "TOKEN_WIDER_THAN_INNER_REGION" in (o.get("risks") or []) and \
                    "TOKEN_WIDER_THAN_INNER_REGION" not in (o.get("referenceRisks") or []):
                words = (o.get("text") or "").split()
                longest = max(words, key=len) if words else ""
                fails.append(f"slide {slide}: a word is wider than its box ('{longest[:30]}' in "
                             f"'{(o.get('text') or '')[:40]}') -> it breaks mid-word; use a shorter word, "
                             "an abbreviation or a roomier slot")
            if "lineCount" in o and "innerHeightPt" in o and "estimatedAdvanceHeightPt" in o:
                lines, ref = o.get("lineCount") or 0, o.get("referenceLineCount") or 1
                cover = slide <= len(mapping) and mapping[slide - 1] in COVERS
                if cover and lines <= 3:
                    return            # cover title is designed to run past its small frame (validator README)
                if slide <= len(mapping) and mapping[slide - 1] in TITLE2 and lines <= 2:
                    return            # a divider or big-note line may wrap once at its display size
                if o["estimatedAdvanceHeightPt"] > o["innerHeightPt"] + 1 and lines > ref:
                    txt = (o.get("text") or "").replace("\n", " ")[:60]
                    fails.append(f"slide {slide}: text needs {lines} lines in a box sized for {ref} "
                                 f"('{txt}') -> shorten it or pick a roomier source slide; never shrink "
                                 "the font by hand (tools/autofit.py resizes it)")
                return
            for v in o.values(): walk(v, slide)
        elif isinstance(o, list):
            for v in o: walk(v, slide)
    for i, sl in enumerate(rep.get("slides") or [], 1):
        if i not in DIAG:
            walk(sl, i)
    return fails


def run(cmd, cwd):
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    return p.returncode, (p.stdout + p.stderr).strip()[-1500:]


def contact_sheet(pngs, dest, cols=3, width=1500):
    """All slide renders on one small image, numbered: the cheap way to look at a whole deck."""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    ims = [Image.open(p).convert("RGB") for p in pngs]
    w = (width - (cols - 1) * 8) // cols
    ims = [im.resize((w, int(im.height * w / im.width))) for im in ims]
    h = max(im.height for im in ims)
    rows_ = (len(ims) + cols - 1) // cols
    sheet = Image.new("RGB", (width, rows_ * (h + 8)), "white")
    draw = ImageDraw.Draw(sheet)
    for k, im in enumerate(ims):
        x, y = (k % cols) * (w + 8), (k // cols) * (h + 8)
        sheet.paste(im, (x, y))
        draw.rectangle([x, y, x + 30, y + 18], fill=(64, 64, 64))
        draw.text((x + 5, y + 3), str(k + 1), fill=(255, 255, 255))
    sheet.save(dest)                                   # (optimize=True took 4x as long for a 0.5% smaller file)
    return dest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck")
    ap.add_argument("--mapping", required=True)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    deck = Path(a.deck).resolve()
    out = Path(a.out or (deck.parent / (deck.stem + "_validation"))).resolve()
    out.mkdir(parents=True, exist_ok=True)
    mapping = [int(m) for m in a.mapping.split(",")]
    rows = []
    load_diag(deck)

    if sha(REF) != BRAND.sha:
        print("FAIL reference template hash mismatch"); sys.exit(1)

    import lo as _LO                                   # the render (PDF, slide pictures) runs while the checks below read
    render = _LO.render_async(deck, out, 96) if _LO.soffice() else None    # the deck: same files, about a third quicker
    import a11y as _A
    sdeck = _A.stripped_copy(deck, out / "_structure_copy.pptx")   # alt text is metadata, not layout
    layout_headlines_restored(sdeck, mapping)         # the full-width headline on the deck's layouts is the approved exception
    summary_layer_removed(sdeck)                       # the takeaway line and decision bar sit above and below the template's shapes
    code, log = run([sys.executable, str(Path(__file__).resolve().parent / "fit_runner.py"), str(REF), str(sdeck),
                     "--mapping", a.mapping, "--report", str(out / "fit-report.json")], VAL.parent)
    detail = ""
    try:
        r = json.loads((out / "fit-report.json").read_text())
        detail = (f"status={r.get('status')} structuralFailures={len(r.get('structuralFailures') or [])} "
                  f"metricRisks={r.get('regionsWithMetricRisks')}")
        sf = r.get("structuralFailures") or []
        hl_ok, hl_fails, hl_rows = headline_exception(deck, mapping, r)
        hl_ok = set(hl_ok) | flow_table_waivers(deck, mapping) | card_anchor_waivers(deck, mapping) | statement_anchor_waivers(deck, mapping)
        hl_ok_all = hl_ok
        size_only = lambda c: "membership" in c       # text-size markers changed by autofit; style gate checks font/colour/bullets
        waived = [f for f in sf if approved_change(f.get("check", ""), hl_ok)]
        sf = [f for f in sf if not approved_change(f.get("check", ""), hl_ok)]
        detail += f" headlineWaived={len(waived)} remainingStructural={len(sf)}"
        if not sf and code == 2 and not r.get("regionsWithMetricRisks"):
            code = 0
    except Exception:
        sf = None
        hl_fails, hl_rows, hl_ok_all = [], [], set()
    if code == 0: v = "PASS"
    elif sf is None: v = "UNVERIFIED"
    elif sf: v = "FAIL"
    else: v = "REVIEW"   # exit 2 with only metric risks: adjudicate each against renders
    rows.append(("Template structure + text fit (ulta_pptx_fit.py)", v, f"exit={code} {detail}"))

    fails_art = []
    art_v, art_ints, art_note = picture_clearance(sdeck, mapping, hl_ok_all)
    try:                                                # a working copy only: it still carries the template's people
        Path(sdeck).unlink()
    except OSError:
        pass
    (out / "picture-clearance.json").write_text(json.dumps({"result": art_v, "note": art_note, "intrusions": art_ints}, indent=1))
    rows.append(("Picture clearance (text vs pictures/icons)", art_v, art_note))
    for r_ in art_ints:
        fails_art.append(f"slide {r_['slide']}: text runs into a picture/icon ('{r_['text'][:40]}') -> tools/autofit.py shrinks it")
    import sections as _S
    pk = package_integrity(deck) + [f"package: {x} -> tools/fix_deck.py repairs it" for x in _S.problems(deck)]
    import ooxml_check                                   # desktop PowerPoint is stricter than LibreOffice or a preview
    pk += [f"would not open clean in PowerPoint (ISO/IEC 29500 schema) - {x}; rebuild with build_deck.py, never edit the file"
           for x in ooxml_check.summary(deck)]
    rows.append(("Package integrity (opens without repair in PowerPoint: ISO/IEC 29500 schema, all pictures resolve)",
                 "FAIL" if pk else "PASS", f"{len(pk)} problem(s)"))
    fails_pkg = pk

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    fails_colour = []
    if BRAND.name == "ulta":                           # every slide and chart: zero deviation from the template's colours
        import brand_colours as BCOL
        off = BCOL.audit_pptx(deck, BCOL.palette(), {i: m for i, m in enumerate(mapping, 1)})
        rows.append(("Brand colours - every slide and chart (zero deviation from the Ulta template palette; status colours "
                     "on marks only)", "FAIL" if off else "PASS",
                     "; ".join(off[:4]) + (f" (+{len(off) - 4} more)" if len(off) > 4 else "") if off else
                     "only template colours" + (f"; generated slides {sorted(DIAG)} included" if DIAG else "")))
        fails_colour = off
    elif DIAG:
        zz = zipfile.ZipFile(deck)
        dparts, _, _ = slide_parts(zz)
        used = {c.upper() for i in DIAG if i <= len(dparts)
                for c in re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', zz.read(dparts[i - 1]).decode())}
        off = sorted(c for c in used if not _B.in_family(c, BRAND))
        rows.append((f"Generated slides {sorted(DIAG)} - diagrams, charts, tables ({BRAND.name} palette)", "FAIL" if off else "PASS",
                     f"off-palette: {off}" if off else f"only {BRAND.name} palette colours (theme-bound where possible)"))
    # native editability: text floating on top of a shape (instead of inside it) and loose line segments
    try:
        import copy as _c
        import nativize as NZ
        from pptx import Presentation as _P
        loose = segs = 0
        ref_slides, native = list(_P(str(REF)).slides), {}
        for k_, sl in enumerate(_P(str(deck)).slides, 1):
            tr = _c.deepcopy(sl.shapes._spTree)
            src_ = mapping[k_ - 1] if k_ <= len(mapping) else None
            if src_ and src_ not in native and src_ <= len(ref_slides):   # the template slide's own floating text
                native[src_] = NZ.merge_text(_c.deepcopy(ref_slides[src_ - 1].shapes._spTree))
            loose += max(0, NZ.merge_text(tr) - (native.get(src_, 0) if k_ not in DIAG else 0))
            m_, n_ = NZ.glue_flows(tr); segs += m_
        rows.append(("Native editability (text inside shapes, glued connectors)", "PASS" if not (loose or segs) else "REVIEW",
                     "all text sits in its own shape" if not (loose or segs) else
                     f"{loose} text box(es) floating on shapes, {segs} unglued flow(s) -> run tools/nativize.py"))
    except Exception as exc:
        rows.append(("Native editability", "UNVERIFIED", str(exc)[:80]))
    fails, warns = content_gates(deck, mapping)
    hl_texts = {t for _, t in hl_rows}
    fails += [f for f in overflow_gate(out / "fit-report.json", mapping) if not any(f"('{t[:60]}')" in f for t in hl_texts)]
    fails += hl_fails
    fails += flow_alignment_gate(deck, mapping)
    fails += chrome_gate(deck, mapping)
    fails += fails_pkg + fails_art + [f"{x} -> use a template colour (tools/brand_colours.py lists them)" for x in fails_colour]
    rows.append(("Ulta content gates (count, edges, overflow, spacer/header cells, formatting, duplicates, sample text, empty structure)",
                 "FAIL" if fails else "PASS", f"{len(fails)} fail, {len(warns)} warn"))

    side_meta = json.loads(Path(str(deck) + ".ulta.json").read_text()) if Path(str(deck) + ".ulta.json").exists() else {}
    if side_meta.get("infographic_slides"):              # every shape is the template slide's own, styled identically
        import template_infographics as _TI
        fid = _TI.fidelity(deck, mapping, side_meta["infographic_slides"])
        rows.append((f"Template infographics {side_meta['infographic_slides']} - only the template's own shapes, styled "
                     "identically", "FAIL" if fid else "PASS", "; ".join(fid[:3]) if fid else
                     "text, positions and status marks changed; nothing else"))
        fails += fid
    if side_meta.get("list_slides"):                     # rows or columns dropped on purpose: the rest is the template's own
        import template_infographics as _TI
        fid = _TI.fidelity(deck, mapping, side_meta["list_slides"])
        rows.append((f"Shortened lists and rows {side_meta['list_slides']} - only the template's own shapes, styled identically",
                     "FAIL" if fid else "PASS", "; ".join(fid[:3]) if fid else "unused items removed; nothing else changed"))
        fails += fid
    if side_meta.get("library_slides"):
        import library as _L
        res = _L.verify(deck, side_meta["library_slides"])
        bad = [f"slide {i}: approved library slide '{k}' was changed -> re-insert it unchanged" for i, k, ok in res if not ok]
        rows.append((f"Approved library slides {[i for i, _, _ in res]}", "FAIL" if bad else "PASS",
                     "changed: " + ", ".join(k for _, k, ok in res if not ok) if bad else "identical to the approved versions"))
        fails += bad
    # enterprise gates: sensitive data (deck + its .drawio files) and accessibility
    import compliance as _CP
    side_files = [deck] + sorted(deck.parent.glob(deck.stem + "-slide*.drawio"))
    sens = _CP.scan(side_files)
    blk = [x for x in sens if x["severity"] == "BLOCK"]
    rows.append(("Sensitive data (secrets, SSN, cards = block; e-mail, phone, IP, hosts = review)",
                 "FAIL" if blk else "REVIEW" if sens else "PASS",
                 f"{len(blk)} blocking, {len(sens) - len(blk)} to review" if sens else "nothing found"))
    fails += [f"{x['where']}: {x['kind']} '{x['match']}' -> remove it (never ship credentials or personal IDs)" for x in blk]
    review_lines = [f"{x['where']}: {x['kind']} '{x['match']}' -> keep only if intended" for x in sens if x["severity"] == "REVIEW"]
    import typeset as _T
    t_fail = _T.check(deck)
    _sp = _T.spec(BRAND)
    rows.append((f"Typography (template slide 3; display face {_sp['headline'][0]}"
                 + ("" if "Chronicle" in _sp['headline'][0] else " as stand-in for Chronicle Deck Semibold")
                 + ": headline 36, highlight 24, sub-headline Circular Bold 18, body Circular Regular 12)",
                 "FAIL" if t_fail else "PASS", f"{len(t_fail)} slide(s) off the standard"))
    fails += t_fail
    a_fail, a_rev = _A.check(deck, BRAND)
    rows.append(("Accessibility (alt text, table headers, contrast, unique titles)",
                 "FAIL" if a_fail else "REVIEW" if a_rev else "PASS",
                 f"{len(a_fail)} fail, {len(a_rev)} to review" + (" -> run tools/a11y.py fix" if a_fail else "")))
    fails += a_fail
    review_lines += a_rev
    drawn = sorted(DIAG - {x.get("slide") for x in side_meta.get("library_slides") or [] if isinstance(x, dict)})
    if drawn:                                            # the slides the tools drew: every word readable on its block
        n_txt, low = _A.drawn_text(deck, set(drawn), BRAND)
        rows.append(("Readable text on drawn slides (4.5:1 on what each text sits on, 3:1 from 18 pt)",
                     "FAIL" if low else "PASS", f"{n_txt} text runs on {len(drawn)} slide(s)"
                     + (f", {len(low)} under the bar -> run tools/a11y.py fix" if low else "")))
        fails += low

    if render:                                         # (a private LibreOffice profile: builds can run side by side)
        render.result()                                # the PDF and every slide's picture, readable one by one
        pdf = out / (deck.stem + ".pdf")
        if pdf.exists() and shutil.which("pdftotext"):
            import look as _L
            l_fail, l_rev = _L.check(pdf)
            rows.append(("Rendered layout (overlapping text, off-slide text, density)", "FAIL" if l_fail else "REVIEW" if l_rev else "PASS",
                         f"{len(l_fail)} fail, {len(l_rev)} to review"))
            fails += l_fail
            review_lines += l_rev
        else:
            rows.append(("Rendered layout (overlapping text, off-slide text, density)", "UNVERIFIED",
                         "the deck could not be rendered or read back here"))
        pngs = sorted(out.glob("slide*.png"), key=lambda p: int(re.sub(r"\D", "", p.stem) or 0))
        sheet = contact_sheet(pngs, out / "contact-sheet.png") if pngs else None
        rows.append(("Render (substitute fonts)", "REVIEW" if pngs else "UNVERIFIED",
                     f"review before delivery: {sheet} (all {len(pngs)} slides in one image); a closer look at one "
                     f"slide: its own render {out}/slide-*.png"))
    else:                                              # v6.33 no LibreOffice: the slides drawn natively (resvg + the template's stand-in fonts)
        native = None
        try:
            sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "studio"))
            import slide_svg as _SV
            native = _SV.deck_pictures(str(deck), str(out))
        except Exception as e:                         # noqa: BLE001
            native = (None, None, None); print(f"native render: {e}"[:200], file=sys.stderr)
        pngs, pages, wide = native or (None, None, None)
        if pages is not None:
            import look as _L
            l_fail, l_rev = _L.check_pages(pages)
            l_fail += [f"slide {n}: '{wd[:30]}' is a word wider than its box - shorten it or give it a roomier slot" for n, wd in (wide or [])]
            rows.append(("Rendered layout (overlapping text, off-slide text, density)", "FAIL" if l_fail else "REVIEW" if l_rev else "PASS",
                         f"{len(l_fail)} fail, {len(l_rev)} to review (drawn by the Studio, no LibreOffice)"))
            fails += l_fail
            review_lines += l_rev
            pngs = [Path(x) for x in pngs]
            sheet = contact_sheet(pngs, out / "contact-sheet.png") if pngs else None
            rows.append(("Render (the template's stand-in fonts)", "REVIEW" if pngs else "UNVERIFIED",
                         f"review before delivery: {sheet} (all {len(pngs)} slides in one image); a closer look at one "
                         f"slide: its own render {out}/slide-*.png"))
        else:
            rows.append(("Rendered layout (overlapping text, off-slide text, density)", "UNVERIFIED", "LibreOffice not available"))
            rows.append(("Render", "UNVERIFIED", "LibreOffice not available"))

    print(f"Deck: {deck.name}  sha256={sha(deck)}  bytes={deck.stat().st_size}")
    print(f"Mapping: {a.mapping}\n")
    print("| Gate | Result | Detail |\n|---|---|---|")
    for g, v, d in rows:
        print(f"| {g} | {v} | {d} |")
    for f in fails: print("FAIL  " + f.replace(chr(10), ' / '))
    for w in warns: print(f"WARN  {w}")
    for r_ in review_lines[:12]: print(f"REVIEW {r_}")
    # REVIEW there = substitute-font preview / metric notes / items to confirm with the user, not defects
    soft = ("Render", "Template structure", "Sensitive data", "Accessibility")
    if any(v == "FAIL" for _, v, _ in rows):
        overall = "NEEDS CORRECTION"
    elif any(v == "UNVERIFIED" or (v == "REVIEW" and not g.startswith(soft)) for g, v, _ in rows):
        overall = "DRAFT - VERIFICATION INCOMPLETE"
    else:
        overall = "READY - all automated checks passed (preview fonts are substitutes; final look in PowerPoint)"
    print(f"\nOVERALL: {overall}")
    import checks                                        # the evidence the RESULT line's score is computed from
    preview = [r for r in rows if r[0].startswith("Render (") or r[0] == "Render"]
    checks.record(deck, [(g, v, d, v == "REVIEW" and g.startswith(soft)) for g, v, d in rows if (g, v, d) not in preview],
                  overall.split(" - ")[0], info=[(g, v, d, True) for g, v, d in preview])
    sys.exit(1 if overall == "NEEDS CORRECTION" else 0)


if __name__ == "__main__":
    main()
