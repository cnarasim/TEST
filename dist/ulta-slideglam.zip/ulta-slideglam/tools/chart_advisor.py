"""Chart my data: read the data, recommend the best charts (with the reason), build them on the template.

    python tools/chart_advisor.py data.xlsx [--sheet Sales] [--top 3]                       recommendations only
    python tools/chart_advisor.py data.xlsx --build /mnt/data/out/<Name>.pptx [--pick 1,3]  + an Ulta deck of them

It looks at the columns - dates, categories (12 or fewer values), numbers, percentages, actual vs target / plan,
before vs after (two years, prior / current), from / to pairs - and scores the 22 modern chart types for this data.
Every headline states a fact computed from the data (the leader, the change, the share); nothing is invented.
Prints one line per recommendation: rank, chart, why, and the storyboard slide it builds.
"""
import argparse, collections, csv, datetime as dt, json, re, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))                     # its sibling modules, also under python -I

TARGET = re.compile(r"(?i)\b(target|plan|planned|goal|budget|forecast|objective)\b")
ACTUAL = re.compile(r"(?i)\b(actual|achieved|result|realised|realized|current)\b")
BEFORE = re.compile(r"(?i)\b(before|prior|last|previous|baseline|old|ly|py)\b")
AFTER = re.compile(r"(?i)\b(after|current|this|new|ty|cy)\b")
YEAR = re.compile(r"(19|20)\d\d")
PCT = re.compile(r"(?i)(%|percent|pct|rate|share|ratio)")
SCORE = re.compile(r"(?i)(score|nps|rating|index|avg|average|mean|satisfaction|csat|rank)")
MONEY = re.compile(r"(?i)(sales|revenue|amount|value|gmv|spend|cost|margin|profit|income|\$|usd|eur)")
AVGLIKE = re.compile(r"(?i)(days|day to|time|lead|age|duration|hours|minutes|price|rate|ratio|per )")
FROM, TO = re.compile(r"(?i)^(from|source|origin|start)$"), re.compile(r"(?i)^(to|target|destination|dest|end)$")
NOT_TARGET = re.compile(r"(?i)(accuracy|bias|error|variance|attainment|vs\b)")   # 'Forecast accuracy %' is a measure, not a target
UNITLIKE = re.compile(r"(?i)\b(units?|qty|quantity|count|orders|lines|items|pieces|cases|transactions)\b")
CURRENCY = (("$", re.compile(r"(?i)(\$|\busd\b|dollars?)")), ("€", re.compile(r"(?i)(€|\beur\b|euros?)")),
            ("£", re.compile(r"(?i)(£|\bgbp\b|pounds?)")))
MULTIPLIER = ((1e9, re.compile(r"(?i)([$€£]\s?(b|bn)\b|\((b|bn)\)|\bbillions?\b)")),
              (1e6, re.compile(r"(?i)([$€£]\s?(m|mm)\b|\((m|mm)\)|\bmillions?\b)")),
              (1e3, re.compile(r"(?i)([$€£]\s?k\b|\(k\)|\(000s?\)|'000|\bthousands?\b)")))
CURS = {}             # column name -> its currency, read from the header (filled by money_units)


def read(path, sheet=None):
    """One table: (head, rows). A workbook without --sheet: the first sheet (see read_all for every sheet)."""
    t = read_all([path], sheet)
    return t[0][1], t[0][2]


def fast_xlsx(path, only=None):
    """[(sheet, rows)] straight from the workbook XML (values as Excel stores them: numbers, text, dates by their cell
    style). None when the file uses something this reader does not cover - the caller then uses openpyxl."""
    import zipfile
    from lxml import etree
    etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
    z = zipfile.ZipFile(path)
    M = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    names = z.namelist()
    shared = []
    if "xl/sharedStrings.xml" in names:
        for _, si in etree.iterparse(z.open("xl/sharedStrings.xml"), tag=M + "si"):
            shared.append("".join(t.text or "" for t in si.iter(M + "t"))); si.clear()
    date_xf = set()
    if "xl/styles.xml" in names:
        st = etree.parse(z.open("xl/styles.xml")).getroot()
        custom = {int(n.get("numFmtId")): n.get("formatCode", "") for n in st.iter(M + "numFmt")}
        def is_date(fid):
            if 14 <= fid <= 22 or 45 <= fid <= 47: return True
            code = re.sub(r'"[^"]*"|\\.|\[[^\]]*\]', "", custom.get(fid, "")).lower()
            if not code: return False
            return any(ch in code for ch in "dy") or ("m" in code and not any(ch in code for ch in "hs0#"))
        xfs = st.find(M + "cellXfs")
        for k, xf in enumerate(xfs if xfs is not None else []):
            if is_date(int(xf.get("numFmtId", 0))): date_xf.add(k)
    wbx = etree.parse(z.open("xl/workbook.xml")).getroot()
    rels = {r.get("Id"): r.get("Target") for r in etree.parse(z.open("xl/_rels/workbook.xml.rels")).getroot()}
    epoch = dt.datetime(1899, 12, 30)
    out = []
    for sh in wbx.iter(M + "sheet"):
        name = sh.get("name")
        if only and name != only: continue
        tgt = rels.get(sh.get(R + "id"), ""); tgt = tgt.lstrip("/")
        part = tgt if tgt.startswith("xl/") else "xl/" + tgt
        if part not in names: return None
        rows = []
        for _, row in etree.iterparse(z.open(part), tag=M + "row"):
            vals = {}
            for c in row.iter(M + "c"):
                ref, t, v = c.get("r", ""), c.get("t"), c.find(M + "v")
                col = 0
                for ch in ref:
                    if ch.isalpha(): col = col * 26 + ord(ch.upper()) - 64
                    else: break
                if t == "s" and v is not None: val = shared[int(v.text)]
                elif t == "inlineStr": val = "".join(x.text or "" for x in c.iter(M + "t"))
                elif t in ("str", "e"): val = v.text if v is not None else None
                elif t == "b": val = bool(int(v.text)) if v is not None else None
                elif v is not None and v.text is not None:
                    x = float(v.text)
                    if int(c.get("s", 0)) in date_xf:
                        val = epoch + dt.timedelta(days=x)
                    else:
                        val = int(x) if x.is_integer() and "." not in v.text and "E" not in v.text else x
                else: val = None
                if col: vals[col] = val
            row.clear()
            if vals:
                rows.append([vals.get(k) for k in range(1, max(vals) + 1)])
        width = max((len(r) for r in rows), default=0)
        out.append((name, [r + [None] * (width - len(r)) for r in rows]))
    return out


def read_all(paths, sheet=None):
    """[(name, head, rows)] - every non-empty sheet of every workbook (or just --sheet), every CSV."""
    out = []
    for path in paths:
        if str(path).lower().endswith(".csv"):
            sheets = [(Path(path).stem, list(csv.reader(open(path, encoding="utf-8-sig"))))]
        else:
            try:
                sheets = fast_xlsx(path, sheet)              # streaming XML: about 4x faster than openpyxl on big files
            except Exception:
                sheets = None
            if sheets is None:
                import openpyxl
                wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
                names = [sheet] if sheet else wb.sheetnames
                sheets = [(n, [list(r) for r in wb[n].iter_rows(values_only=True)]) for n in names]
        for name, rows in sheets:
            rows = [r for r in rows if any(c not in (None, "") for c in r)]
            if len(rows) < 2: continue
            head = [str(h if h is not None else f"Column {i + 1}").strip() for i, h in enumerate(rows[0])]
            out.append((name, head, rows[1:]))
    return out


def join(tables):
    """Header + item tables (sales order header and items, invoice and lines ...) -> one item-level table.
    The key is a column both share where the header side is unique. A header number (freight, header value) is kept on
    the order's first line only, so totals are not counted once per line. Returns (head, rows, info)."""
    norm = lambda h: re.sub(r"[^a-z0-9]", "", h.lower())
    tables = [list(t) for t in tables]; info = {"key": None, "joined": []}
    while len(tables) > 1:
        best = None
        for a in tables:
            for b in tables:
                if a is b: continue
                for i, h in enumerate(a[1]):
                    j = next((k for k, g in enumerate(b[1]) if norm(g) == norm(h)), None)
                    if j is None:                        # differently named key ("Order Number" vs "Sales Order"): by values
                        sa = {r[i] for r in a[2][:3000] if i < len(r) and r[i] not in (None, "")}
                        if not sa or all(isinstance(x, (int, float)) and not float(x).is_integer() for x in list(sa)[:20]): continue
                        best_j, best_o = None, 0
                        for k in range(len(b[1])):
                            sb = {r[k] for r in b[2] if k < len(r)}
                            o = len(sa & sb) / len(sa)
                            if o > best_o: best_j, best_o = k, o
                        if best_o < 0.8: continue
                        j = best_j
                    ka = [r[i] for r in a[2] if i < len(r)]; kb = {r[j] for r in b[2] if j < len(r)}
                    if len(set(map(str, ka))) == len(ka): continue          # a must repeat its key (the item side)
                    if len(kb) != len([r for r in b[2] if j < len(r)]): continue   # b must be unique (the header side)
                    hit = sum(1 for v in ka if v in kb) / max(1, len(ka))
                    if hit >= 0.5 and (best is None or hit > best[0]): best = (hit, a, b, i, j)
        if not best:
            break
        hit, a, b, i, j = best
        hdr = {r[j]: r for r in b[2]}
        keep = [k for k, g in enumerate(b[1]) if k != j and norm(g) not in {norm(x) for x in a[1]}]
        numeric = {k for k in keep if sum(as_num(r[k]) is not None for r in b[2][:200] if k < len(r)) > 0.8 * min(200, len(b[2]))
                   and not any(as_date(r[k]) for r in b[2][:20] if k < len(r) and not isinstance(r[k], (int, float)))}
        seen, rows = set(), []
        for r in a[2]:
            h = hdr.get(r[i]); first = r[i] not in seen; seen.add(r[i])
            rows.append(list(r) + [(h[k] if h and k < len(h) and (k not in numeric or first) else None) for k in keep])
        info["key"] = a[1][i]
        on = f"'{a[1][i]}'" if norm(a[1][i]) == norm(b[1][j]) else f"'{a[1][i]}' = '{b[1][j]}'"
        info["joined"].append(f"{a[0]} ({len(a[2]):,} rows) + {b[0]} ({len(b[2]):,} rows) on {on} - {100 * hit:.0f}% of lines matched")
        tables.remove(a); tables.remove(b); tables.insert(0, (f"{a[0]}+{b[0]}", a[1] + [b[1][k] for k in keep], rows))
    big = max(tables, key=lambda t: len(t[2]))
    if len(tables) > 1:
        info["ignored"] = [f"{t[0]} ({len(t[2]):,} rows)" for t in tables if t is not big]
        info["used"] = big[0]
    return big[1], big[2], info


def as_num(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v or "").strip().replace(",", "").replace("$", "").replace("€", "").replace("£", "")
    pct = s.endswith("%"); s = s.rstrip("%")
    try:
        return float(s)
    except ValueError:
        return None


def as_date(v):
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    return _date_text(str(v or "").strip())


import functools


@functools.lru_cache(maxsize=65536)
def _date_text(s):
    if not s or not any(ch.isdigit() for ch in s) or len(s) > 30:      # "SO500123", "Stores": no strptime round
        return None
    for f in ("%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y", "%b %Y", "%B %Y", "%Y-%m", "%b-%y", "%b %d %Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return dt.datetime.strptime(s, f).date()
        except ValueError:
            pass
    return None


def profile(head, rows):
    cols = []
    for i, h in enumerate(head):
        vals = [r[i] if i < len(r) else None for r in rows]
        filled = [v for v in vals if v not in (None, "")]
        smp = filled[:: max(1, len(filled) // 400)]           # the type from a sample: 30,000 rows stay fast
        nums = [as_num(v) for v in smp]; dates = [as_date(v) for v in smp]
        kind = "text"
        if smp and sum(d is not None for d in dates) >= 0.8 * len(smp) and not all(isinstance(v, (int, float)) for v in smp):
            kind = "date"
        elif smp and sum(n is not None for n in nums) >= 0.8 * len(smp):
            kind = "number"
        uniq = len(set(map(str, filled)))
        c = {"i": i, "name": h, "kind": kind, "uniq": uniq}
        if kind == "number":
            nn = [n for n in (as_num(v) for v in filled) if n is not None]
            c["pct"] = bool(PCT.search(h)) or (nn and max(nn) <= 100 and min(nn) >= 0 and any(str(v).strip().endswith("%") for v in filled))
            c["frac"] = bool(nn and max(nn) <= 1 and min(nn) >= 0 and PCT.search(h))
        cols.append(c)
    return cols


def percent_points(head, rows):
    """A percent column stored as a fraction (Margin % = 0.402, as most exports write it) becomes percent points (40.2), so
    every chart, headline and takeaway shows 40.2% - never 0.4 or 0%."""
    for c in profile(head, rows):
        if c.get("frac"):
            i = c["i"]
            for r in rows:
                v = as_num(r[i]) if i < len(r) else None
                if v is not None:
                    r[i] = round(v * 100, 4)


def money_units(head, rows):
    """'Net sales ($M)' holds millions: its values become dollars and the header 'Net sales', so every chart and sentence
    scales them the same way ($7.5B). The currency in a header ($, EUR) is kept for the column."""
    CURS.clear()
    for i, h in enumerate(head):
        name = str(h or "")
        cur = next((c for c, rx in CURRENCY if rx.search(name)), "")
        mult = next((m for m, rx in MULTIPLIER if rx.search(name)), 1)
        clean = name
        if cur or mult != 1:
            clean = re.sub(r"\s*\((?:[$€£]|usd|eur|gbp)?\s?(?:k|m|mm|b|bn|000s?|'000)?\)", "", clean, flags=re.I)
            clean = re.sub(r"\s*\bin (?:thousands|millions|billions)\b", "", clean, flags=re.I).strip() or name
        if mult != 1:
            for r in rows:
                v = as_num(r[i]) if i < len(r) else None
                if v is not None:
                    r[i] = v * mult
        head[i] = clean
        if cur:
            CURS[clean] = cur


def cur_of(c):
    """The currency to show for a measure: the one its header names, else $ for a money word (sales, revenue, cost)."""
    if not c or c.get("pct"):
        return ""
    if c["name"] in CURS:
        return CURS[c["name"]]
    return "$" if MONEY.search(c["name"]) and not UNITLIKE.search(c["name"]) else ""


def bare(name):
    """'Forecast accuracy %' in a sentence beside 72.8%: 'Forecast accuracy' (the % is on the number already)."""
    return re.sub(r"(?i)\s*(\(%\)|%|\bpct\b|\bpercent(age)?\b)\s*$", "", str(name)).strip() or str(name)


def is_target(c):
    return bool(TARGET.search(c["name"])) and not NOT_TARGET.search(c["name"])


def time_buckets(rows, di):
    """Rows by period: months for a long run of dates, weeks for a short one; data that is already weekly keeps its
    weeks (months of 4 and 5 weeks do not compare). With a row date for nearly every day, a first or last period the
    data covers only partly is left out; otherwise a thin last period is. Returns (series, periods, label, kind)."""
    dated = sorted([r for r in rows if as_date(r[di])], key=lambda r: as_date(r[di]))
    days = sorted({as_date(r[di]) for r in dated})
    series = collections.OrderedDict()
    if not days:
        return series, [], str, "day"
    span = (days[-1] - days[0]).days
    gaps = sorted((b - a).days for a, b in zip(days, days[1:]))
    gap = gaps[len(gaps) // 2] if gaps else 0
    weekly = gap == 7
    if 85 <= gap <= 95:
        kind, bucket = "quarter", (lambda x: x)
    elif 27 <= gap <= 32 or (len(days) <= 24 and len({(x.year, x.month) for x in days}) == len(days) and len(days) > 1
                             and gap >= 27):
        kind, bucket = "month", (lambda x: x.replace(day=1))
    elif weekly and len(days) <= 110:
        kind, bucket = "week", (lambda x: x)
    elif len(days) > 24 and span >= 90:
        kind, bucket = "month", (lambda x: x.replace(day=1))
    elif len(days) > 24:
        kind, bucket = "week", (lambda x: x - dt.timedelta(days=x.weekday()))
    else:
        kind, bucket = "day", (lambda x: x)
    for r in dated:
        series.setdefault(bucket(as_date(r[di])), []).append(r)
    xs = list(series)
    if kind in ("week", "month") and not weekly and gap < 27 and len(xs) > 2:
        if len(days) >= 0.8 * (span + 1):                 # daily data: the ends are whole periods or they go
            end = lambda x: (x + dt.timedelta(days=6) if kind == "week" else
                             (x.replace(day=28) + dt.timedelta(days=4)).replace(day=1) - dt.timedelta(days=1))
            if days[0] > xs[0]:
                series.pop(xs[0])
            if days[-1] < end(xs[-1]):
                series.pop(xs[-1], None)
        elif len(series[xs[-1]]) < 0.4 * (len(dated) / len(xs)):
            series.pop(xs[-1])                            # a part month at the end would look like a crash
        xs = list(series)
    yrs = len({x.year for x in xs}) > 1
    lab = ((lambda x: x.strftime("%b %y") if yrs else x.strftime("%b")) if kind == "month" else
           (lambda x: f"Q{(x.month - 1) // 3 + 1} {x:%y}") if kind == "quarter" else
           (lambda x: f"{x.day} {x:%b}" + (f" {x:%y}" if yrs else "")))
    return series, xs, lab, kind


def scale_spec(sl, cur="", pct=False):
    """A chart's numbers in K, M or B with the currency: 1,602,995,645 reads $1.6B, on the bars and the axis alike."""
    if pct:
        return sl
    t = sl.get("modern")
    pairs = t in ("dumbbell", "slope", "butterfly")
    vals = ([v for it in sl["items"] for v in (it["value"], it["target"])] if t == "bullet" else
            [v for _, v in sl["items"]] if t in ("lollipop", "treemap", "bubbles", "rose") else
            [v for it in sl["items"] for v in it[1:3]] if pairs else
            list(sl["y"]) if t == "trend" else
            [v for se in sl["series"].values() for v in se] if t == "stream" else
            [it[-1] for it in sl["items"]] if t == "sunburst" else
            [it[-1] for it in sl["flows"]] if t == "sankey" else [])
    if not vals:
        return sl
    big = max(abs(float(v)) for v in vals)
    div, suf = (1e9, "B") if big >= 1e9 else (1e6, "M") if big >= 1e6 else (1e3, "K") if big >= 1e4 else (1, "")
    unit = cur + suf
    if not unit:
        return sl
    q = lambda v: round(float(v) / div, 3 if big / div < 10 else 2)
    if t == "bullet":
        for it in sl["items"]:
            it.update(value=q(it["value"]), target=q(it["target"]), max=q(it["max"]), unit=unit)
        return sl
    if t in ("lollipop", "treemap", "bubbles", "rose"):
        sl["items"] = [[k, q(v)] for k, v in sl["items"]]
    elif pairs:
        sl["items"] = [[it[0], q(it[1]), q(it[2])] + list(it[3:]) for it in sl["items"]]
    elif t == "trend":
        sl["y"] = [q(v) for v in sl["y"]]
        dec = ".0" if big / div < 10 else ""
        sl["format"] = (f'"{cur}"' if cur else "") + f"#,##0{dec}" + (f'"{suf}"' if suf else "")
    elif t == "stream":
        sl["series"] = {k: [q(v) for v in se] for k, se in sl["series"].items()}
    elif t == "sunburst":
        sl["items"] = [list(it[:-1]) + [q(it[-1])] for it in sl["items"]]
    elif t == "sankey":
        sl["flows"] = [list(it[:-1]) + [q(it[-1])] for it in sl["flows"]]
    sl["unit"] = unit
    return sl


SMALL_WORDS = {"vs", "and", "or", "of", "to", "by", "per", "the", "a", "an", "in", "on", "for", "at"}


def title_of(stem):
    """A file name as a cover title: 'Synthetic_MFP_Actuals_vs_Plan' reads 'Synthetic MFP Actuals vs Plan'."""
    words = re.sub(r"[_\-]+", " ", stem).split()
    out = []
    for k, w in enumerate(words):
        if w.isupper() and len(w) > 1 or any(ch.isdigit() for ch in w):
            out.append(w)
        elif k and w.lower() in SMALL_WORDS:
            out.append(w.lower())
        else:
            out.append(w[:1].upper() + w[1:])
    return " ".join(out)


def agg(rows, ci, vi, how="sum"):
    d = collections.OrderedDict()
    for r in rows:
        k = r[ci]; v = as_num(r[vi])
        if k in (None, "") or v is None:
            continue
        d.setdefault(str(k), []).append(v)
    return [(k, (sum(v) if how == "sum" else sum(v) / len(v))) for k, v in d.items()]


def avg_of(nm, word="Avg"):
    """v6.35.2 "Avg <measure>", unless the measure already says so ("Average price" stays, not "Avg Average price")."""
    return str(nm) if re.match(r"(?i)\s*(avg|average|mean)\b", str(nm)) else f"{word} {nm}"


def low(s):
    """Lower-case a column name for a sentence, keeping acronyms (NPS, SKU) and years as they are."""
    return " ".join(w if (w.isupper() and len(w) > 1) or any(ch.isdigit() for ch in w) else w.lower() for w in str(s).split())


def plural(s):
    s = low(s)
    return s if s.endswith("s") else s[:-1] + "ies" if s.endswith("y") and s[-2:-1] not in "aeiou" else s + "s"


def nice(v, pct=False, cur=""):
    if pct:                                              # 40.2% and 39.9% stay apart (both would read 40%)
        return f"{v:.1f}".rstrip("0").rstrip(".") + "%"
    a = abs(v)
    s = (f"{a / 1e9:,.1f}B" if a >= 1e9 else f"{a / 1e6:,.1f}M" if a >= 1e6 else f"{a / 1e3:,.1f}K" if a >= 1e4
         else f"{a:,.0f}" if a >= 100 else f"{a:,.1f}")
    return ("-" if v < 0 else "") + cur + s


def takeaway(chart, sp, measure="", cur=""):
    """One sentence from the numbers: what the chart is there to say (shown under the headline, and in the notes)."""
    try:
        u = sp.get("unit") == "%" or any(it.get("unit") == "%" for it in sp.get("items") or [] if isinstance(it, dict))
        f = lambda v: nice(v, u, "" if u else cur)
        m = low(measure) if measure else "the total"
        if chart == "trend":
            x, y = sp["x"], sp["y"]; hi = y.index(max(y)); lo = y.index(min(y))
            ch = (y[-1] - y[0]) / y[0] * 100 if y[0] else 0
            on = lambda t: ("on " if any(ch.isdigit() for ch in str(t).split()[0]) else "in ") + str(t)
            by = (f"{abs(y[-1] - y[0]):.1f}".rstrip("0").rstrip(".") + " points" if u else
                  f"{abs(ch):.1f}%" if abs(ch) < 1 else f"{abs(ch):.0f}%")              # +0.5%, never "0% above"
            end = (f"{x[-1]} is level with {x[0]}" if (abs(y[-1] - y[0]) < 0.05 if u else abs(ch) < 0.05) else
                   f"{x[-1]} is {by} {'above' if y[-1] >= y[0] else 'below'} {x[0]}")
            return f"Peaked at {f(y[hi])} {on(x[hi])}, lowest at {f(y[lo])} {on(x[lo])}; {end}."
        if chart in ("lollipop",):
            it = sorted(sp["items"], key=lambda r: -r[1]); tot = sum(v for _, v in it) or 1
            if len(it) >= 3 and all(v >= 0 for _, v in it) and not u:
                return (f"{it[0][0]} and {it[1][0]} bring {100 * (it[0][1] + it[1][1]) / tot:.0f}% of {m}; "
                        f"{it[-1][0]} is lowest at {f(it[-1][1])}.")
            return f"{it[0][0]} leads at {f(it[0][1])}; {it[-1][0]} trails at {f(it[-1][1])}."
        if chart in ("treemap", "bubbles"):
            it = sorted(sp["items"], key=lambda r: -r[1]); tot = sum(v for _, v in it) or 1
            if len(it) > 3:
                return (f"{it[0][0]} and {it[1][0]} make up {100 * (it[0][1] + it[1][1]) / tot:.0f}% of {m}; "
                        f"the smallest, {it[-1][0]}, is {100 * it[-1][1] / tot:.0f}%.")
            return f"{it[0][0]} is the biggest share at {100 * it[0][1] / tot:.0f}%; {it[-1][0]} the smallest at {100 * it[-1][1] / tot:.0f}%."
        if chart == "stream":
            x, se = sp["x"], sp["series"]; n = max(1, min(3, len(x) // 3))
            tot = lambda sl: sum(sum(v[sl]) for v in se.values()) or 1
            first = {k: 100 * sum(v[:n]) / tot(slice(0, n)) for k, v in se.items()}
            last = {k: 100 * sum(v[-n:]) / tot(slice(len(x) - n, len(x))) for k, v in se.items()}
            top = max(se, key=lambda k: sum(se[k]))
            g = max(se, key=lambda k: abs(last[k] - first[k]))
            if abs(last[g] - first[g]) < 3:
                return f"{top} has the largest share overall; the mix stays steady (every share within 3 points)."
            return (f"{top} has the largest share overall; {g} moved most, from {first[g]:.0f}% to {last[g]:.0f}% "
                    f"of the total ({x[0]} to {x[-1]}).")
        if chart == "sunburst":
            grp = collections.OrderedDict()
            for g_, p_, v in sp["items"]: grp.setdefault(g_, {})[p_] = v
            tot = sum(sum(v.values()) for v in grp.values()) or 1
            g_ = max(grp, key=lambda k: sum(grp[k].values())); gs = sum(grp[g_].values())
            p_ = max(grp[g_], key=grp[g_].get)
            return f"{g_} is {100 * gs / tot:.0f}% of {m}; inside it, {p_} carries {100 * grp[g_][p_] / (gs or 1):.0f}%."
        if chart == "stack100":
            ser, it = sp["series"], sp["items"]
            shares = {s_: [100 * r[1 + j] / (sum(r[1:]) or 1) for r in it] for j, s_ in enumerate(ser)}
            big = max(shares, key=lambda k: sum(shares[k]))
            lo_, hi_ = min(shares[big]), max(shares[big])
            if round(hi_) == round(lo_):
                return f"{big} is {hi_:.0f}% of every group - the mix is the same throughout."
            if hi_ - lo_ <= 6:
                return f"{big} is the largest part in every group ({lo_:.0f}% to {hi_:.0f}%) - the mix barely changes."
            gi = shares[big].index(hi_)
            return f"{big} is the largest part overall, highest in {it[gi][0]} ({hi_:.0f}%) and lowest at {lo_:.0f}%."
        if chart == "kpi":
            it = sp["items"][:3]
            parts = [f"{i_['value']} {low(i_['label'])}" for i_ in it]
            d = next((i_ for i_ in it if i_.get("delta")), None)
            still = d and not any(ch in "123456789" for ch in d["delta"])          # +0.0 pts: it did not move
            return ", ".join(parts) + ((f"; {low(d['label'])} unchanged {d['vs']}." if still else
                                        f"; {low(d['label'])} {d['delta']} {d['vs']}.") if d else ".")
        if chart == "butterfly":
            it = sp["items"]; l = max(it, key=lambda r: r[1]); r_ = max(it, key=lambda r: r[2])
            if l[0] == r_[0]:
                return f"{l[0]} leads on both {low(sp['left'])} and {low(sp['right'])}."
            return f"{l[0]} leads on {low(sp['left'])}, {r_[0]} on {low(sp['right'])}."
        if chart == "bullet":
            it = sp["items"]; gap = min(it, key=lambda r: r["value"] - r["target"])
            beat = sum(1 for r in it if r["value"] >= r["target"])
            if beat == len(it):
                return (f"All {len(it)} are at or above target; the closest to it is {gap['label']} "
                        f"({f(gap['value'])} vs {f(gap['target'])}).")
            return (f"{beat} of {len(it)} are at or above target; furthest below is {gap['label']} "
                    f"({f(gap['value'])} vs {f(gap['target'])}).")
        if chart in ("dumbbell", "slope"):
            it = sp["items"]; d = max(it, key=lambda r: r[2] - r[1]); up = sum(1 for r in it if r[2] >= r[1])
            return f"{up} of {len(it)} went up; the biggest gain is {d[0]} ({f(d[1])} to {f(d[2])})."
        if chart == "radialbar":
            it = sorted(sp["items"], key=lambda r: -r[1])
            return f"{it[0][0]} leads at {nice(it[0][1], True)}; {it[-1][0]} is lowest at {nice(it[-1][1], True)}."
        if chart == "radar":
            se = sp["series"]; ks = list(se)
            if len(ks) >= 2:
                a, b = ks[0], ks[1]; n = sum(1 for x, y in zip(se[a], se[b]) if x >= y)
                return f"{a} is ahead of {b} on {n} of {len(sp['axes'])} measures."
        if chart == "sankey":
            fl = sorted(sp["flows"], key=lambda r: -r[2]); tot = sum(r[2] for r in fl) or 1
            return f"The largest flow is {fl[0][0]} to {fl[0][1]}: {f(fl[0][2])}, {100 * fl[0][2] / tot:.0f}% of the total."
    except Exception:
        return ""
    return ""


def rate_overview(cols, rows, rates):
    """Data with rates only (margin %, fill rate): each one's average, and the highest and lowest group."""
    if not rates:
        return None, [], []
    mean = lambda vs: sum(vs) / len(vs) if vs else 0
    dim = next((c for c in cols if c["kind"] == "text" and 2 <= c["uniq"] <= 12), None)
    pts, tiles, extra = [], [], []
    for k, c in enumerate(rates):
        avg = mean([v for v in (as_num(r[c["i"]]) for r in rows) if v is not None])
        nm = low(bare(c["name"]))
        pts.append(f"{avg_of(nm, 'Average')} {nice(avg, True)}")
        tiles.append({"kind": "big", "label": avg_of(nm, "Average"), "value": nice(avg, True), "note": f"across {len(rows):,} rows"}
                     if k == 0 else {"kind": "kpi", "label": avg_of(nm), "value": nice(avg, True)})
        if dim:
            g = sorted(agg(rows, dim["i"], c["i"], "mean"), key=lambda kv: -kv[1])
            if len(g) >= 2:
                pts.append(f"{g[0][0]} has the highest {nm} ({nice(g[0][1], True)}); {g[-1][0]} the lowest "
                           f"({nice(g[-1][1], True)})")
                if k == 0 and len(g) <= 8:                   # the first rate by group, as the money summary shows its total
                    extra.append({"kind": "bars", "label": f"{avg_of(nm)} by {low(dim['name'])} (%)",
                                  "items": [[x, round(v, 1)] for x, v in reversed(g)]})
                    extra.append({"kind": "note", "text": f"{g[0][0]} has the highest {nm} at {nice(g[0][1], True)}; "
                                                          f"{g[-1][0]} the lowest at {nice(g[-1][1], True)}."})
    first = rates[0]
    return f"{bare(first['name'])} averages {tiles[0]['value']}", pts[:6], (tiles + extra)[:6]


def overview(head, rows, key=None):
    """The value at a glance from the numbers: total, orders and lines, average order, the biggest group in each
    dimension, the peak month, status mix. Returns (headline, points, bento tiles)."""
    cols = profile(head, rows)
    LINENO = re.compile(r"(?i)(item|line|position|pos|posnr|seq|sequence)( ?(no|number|#))?")
    N = [c for c in cols if c["kind"] == "number" and not LINENO.fullmatch(c["name"].strip()) and not is_target(c)]
    adds = [c for c in N if not c.get("pct")]               # a rate is never a total: 1,542 "margin %" means nothing
    money = next((c for c in adds if MONEY.search(c["name"])), None) or next((c for c in adds if not AVGLIKE.search(c["name"])), None)
    if not money:
        return rate_overview(cols, rows, [c for c in N if c.get("pct")][:3])
    ki = next((c["i"] for c in cols if c["name"] == key), None)
    if ki is None:
        ki = next((c["i"] for c in cols if c["kind"] == "text" and c["uniq"] >= 0.95 * len(rows) and len(rows) > 20), None)
    v = lambda r: as_num(r[money["i"]]) or 0
    cur = cur_of(money)
    nice_ = lambda x: nice(x, cur=cur)
    tot = sum(v(r) for r in rows); m = low(money["name"]); pts, tiles = [], []
    orders = len({r[ki] for r in rows}) if ki is not None else None
    if orders and orders < len(rows):
        pts.append(f"{nice_(tot)} {m} across {orders:,} orders and {len(rows):,} lines")
        pts.append(f"Average order {nice_(tot / orders)}, with {len(rows) / orders:.1f} lines per order")
        hero_note = f"across {orders:,} orders and {len(rows):,} lines"
    elif orders:
        pts.append(f"{nice_(tot)} {m} across {orders:,} orders, {nice_(tot / orders)} per order on average")
        hero_note = f"across {orders:,} orders"
    else:
        pts.append(f"{nice_(tot)} {m} across {len(rows):,} rows"); hero_note = f"across {len(rows):,} rows"
    tiles.append({"kind": "big", "label": money["name"], "value": nice_(tot), "note": hero_note})
    if orders:
        tiles.append({"kind": "kpi", "label": "Average order", "value": nice_(tot / orders)})
    status = next((c for c in cols if c["kind"] == "text" and re.search(r"(?i)status|state", c["name"]) and 2 <= c["uniq"] <= 6), None)
    dims = [c for c in cols if c["kind"] == "text" and 2 <= c["uniq"] <= 12 and c is not status][:2]
    bars, lines_ = None, []
    for c in dims:
        g = sorted(agg(rows, c["i"], money["i"]), key=lambda kv: -kv[1])
        if len(g) >= 2:
            pts.append(f"{g[0][0]} brings {100 * g[0][1] / (tot or 1):.0f}% of {m}; {g[-1][0]} the least "
                       f"({100 * g[-1][1] / (tot or 1):.0f}%)")
            lines_.append(f"{g[0][0]} leads {low(c['name'])} with {100 * g[0][1] / (tot or 1):.0f}%")
            if bars is None and len(g) <= 8:
                sc, suf = (1e9, "B") if g[0][1] >= 1e9 else (1e6, "M") if g[0][1] >= 1e7 else (1e3, "K") if g[0][1] >= 1e4 else (1, "")
                bars = {"kind": "bars", "label": f"{money['name']} by {low(c['name'])}" + (f" ({cur}{suf})" if cur or suf else ""),
                        "items": [[k, round(x / sc, 1)] for k, x in reversed(g)]}   # rising: the leader last, highlighted
    d = next((c for c in cols if c["kind"] == "date"), None)
    if d:
        series, xs, lab, kind = time_buckets(rows, d["i"])
        if len(xs) >= 3:
            per = {x: sum(v(r) for r in series[x]) for x in xs}
            hi = max(xs, key=per.get); lo = min(xs, key=per.get)
            pts.append(f"Peak {kind} {lab(hi)} ({nice_(per[hi])}); lowest {lab(lo)} ({nice_(per[lo])})")
            lines_.append(f"peak {kind} {lab(hi)}")
    if status:
        if ki is not None:                               # status is per order, not per line
            first = {}
            for r in rows:
                first.setdefault(r[ki], r[status["i"]])
            cnt = collections.Counter(str(x) for x in first.values() if x not in (None, ""))
        else:
            cnt = collections.Counter(str(r[status["i"]]) for r in rows if r[status["i"]] not in (None, ""))
        n = sum(cnt.values()) or 1
        pts.append(f"{low(status['name']).capitalize()}: " + ", ".join(f"{100 * c / n:.0f}% {low(k)}" for k, c in cnt.most_common(3)))
        top, c0 = cnt.most_common(1)[0]
        tiles.append({"kind": "ring", "label": f"{top} - share of {'orders' if ki is not None else 'rows'}", "value": round(100 * c0 / n)})
    if bars: tiles.append(bars)
    if lines_:
        t_ = "; ".join(lines_[:3]); tiles.append({"kind": "note", "text": t_[0].upper() + t_[1:] + "."})
    return f"{nice_(tot)} {m} at a glance", pts[:6], tiles[:6]


def recommend(head, rows, key=None):
    cols = profile(head, rows)
    D = [c for c in cols if c["kind"] == "date"]
    LINENO = re.compile(r"(?i)(item|line|position|pos|posnr|line item|item no|item number|seq|sequence)( ?(no|number|#))?")
    N = [c for c in cols if c["kind"] == "number" and not LINENO.fullmatch(c["name"].strip())
         and not (c["uniq"] >= 0.95 * len(rows) and re.search(r"(?i)\b(id|no|number|order|#)\b", c["name"]))]
    C = [c for c in cols if c["kind"] == "text" and 2 <= c["uniq"] <= 12]
    for n in N: n["avg"] = bool(AVGLIKE.search(n["name"])) and not MONEY.search(n["name"]) or bool(n.get("pct"))   # averaged, never added up
    # the measure to lead with: money first (net sales, revenue), then any additive measure
    N.sort(key=lambda c: (is_target(c), c["avg"], not MONEY.search(c["name"])))
    IDS = ([c for c in cols if c["name"] == key] if key else
           [c for c in cols if c["kind"] == "text" and c["uniq"] >= 0.95 * len(rows) and len(rows) > 20])
    recs = []
    add = lambda score, chart, why, slide, meas=None: recs.append({"score": score, "chart": chart, "why": why,
                                                                   "slide": dict(slide, modern=chart), "meas": meas})
    measure = next((c for c in N if not is_target(c) and not c["avg"]), N[0] if N else None)
    # ---- time
    if D and N:
        d = D[0]
        # one point per month or week (never per day); weekly data keeps its weeks; part periods at the ends go
        series, xs, lab, kind = time_buckets(rows, d["i"])
        m = measure
        mean = lambda vs: sum(vs) / len(vs) if vs else 0
        ys = [(mean([as_num(r[m["i"]]) for r in series[x] if as_num(r[m["i"]]) is not None]) if m["avg"] else
               sum(as_num(r[m["i"]]) or 0 for r in series[x])) for x in xs]
        if len(xs) >= 3:
            jumps = [abs(ys[i] - ys[i - 1]) for i in range(1, len(ys))]; at = jumps.index(max(jumps)) + 1
            word = "rose" if ys[-1] >= ys[0] else "fell"
            nm, nv = (bare(m['name']) if m.get('pct') else m['name']), (lambda v: nice(v, m.get('pct'), cur_of(m)))
            flat = (abs(ys[-1] - ys[0]) < 0.5 if m.get("pct") else ys[0] and abs(ys[-1] - ys[0]) / abs(ys[0]) < 0.015)
            top = max(range(len(ys)), key=ys.__getitem__)
            add(90, "trend", f"'{d['name']}' is a timeline and '{m['name']}' a measure: a line shows the trend; the biggest move "
                f"({lab(xs[at])}) is called out",
                {"headline": (f"{nm} held near {nv(ys[-1])}; peak {lab(xs[top])} at {nv(ys[top])}" if flat and 0 < top < len(ys) - 1
                              else f"{nm} {word} from {nv(ys[0])} to {nv(ys[-1])}"),       # +0.5% is not a rise worth a headline
                 "x": [lab(x) for x in xs], "dates": [x.isoformat()[:10] for x in xs], "y": [round(v, 2) for v in ys], "at": at,
                 "note": "Biggest change: " + (f"{ys[at] - ys[at - 1]:+.1f} points" if m.get("pct") else
                                               f"{'+' if ys[at] >= ys[at - 1] else ''}{nice(ys[at] - ys[at - 1], False, cur_of(m))}"),
                 "unit": "%" if m.get("pct") else "", **({"format": '0"%"'} if m.get("pct") else {})}, m)
        if C and len(xs) >= 3 and not m["avg"]:               # a mix of parts: only what adds up
            c = C[0]; parts = collections.OrderedDict()
            for x in xs:
                for r in series[x]:
                    if r[c["i"]] not in (None, ""):
                        parts.setdefault(str(r[c["i"]]), collections.Counter())[x] += as_num(r[m["i"]]) or 0
            per = sum(sum(1 for v in parts.values() if v.get(x)) for x in xs) / max(1, len(xs))
            if 2 <= len(parts) <= 6 and per >= 1.5:        # most periods hold several groups, or there is no mix to show
                top = max(parts, key=lambda k: sum(parts[k].values()))
                add(78, "stream", f"'{m['name']}' over time, split by '{c['name']}': layered waves show how the mix shifts",
                    {"headline": f"{top} carries the most {low(m['name'])} over time", "x": [lab(x) for x in xs],
                     "series": {k: [round(v[x], 2) for x in xs] for k, v in parts.items()}}, m)
        totals = ([c for c in N[:4] if not c.get("pct") and not is_target(c)] or
                  [c for c in N[:3] if c.get("pct") and not is_target(c)])      # rates only: each one's average
        if totals and xs:
            items = []
            def card(label, tr, value, pts=False):
                if pts:                                          # a rate moves in points, not in % of itself
                    ch = (f"{tr[-1] - tr[-2]:+.1f}".replace("+0.0", "0.0").replace("-0.0", "0.0") + " pts"
                          if len(tr) > 1 else None)
                else:
                    r_ = (tr[-1] - tr[-2]) / tr[-2] * 100 if len(tr) > 1 and tr[-2] else None
                    ch = None if r_ is None else f"{r_:+.1f}%" if abs(r_) < 1 else f"{r_:+.0f}%"
                items.append({"label": label, "value": value, "trend": [round(v, 2) for v in tr[-12:]],
                              **({"delta": ch, "vs": f"vs {lab(xs[-2])}"} if ch is not None else {})})
            if IDS:                                      # orders: a distinct count (several lines can share one order)
                ki = IDS[0]["i"]
                cnt = [len({r[ki] for r in series[x]}) for x in xs]
                n_ = len({r[ki] for r in rows})                    # the whole file, as on the summary slide
                card(plural(IDS[0]["name"]).capitalize(), cnt, f"{n_:,}" if n_ < 100000 else nice(n_))
            for c in totals[:3 if not IDS else 2]:
                if c["avg"]:
                    vals = lambda rs: [as_num(r[c["i"]]) for r in rs if as_num(r[c["i"]]) is not None]
                    tr = [(sum(vals(series[x])) / len(vals(series[x]))) if vals(series[x]) else 0 for x in xs]
                    allv = vals(rows)
                    card(avg_of(low(bare(c['name']) if c.get('pct') else c['name'])), tr,
                         nice(sum(allv) / len(allv), bool(c.get("pct")), cur_of(c)) if allv else "-", bool(c.get("pct")))
                else:
                    tr = [sum(as_num(r[c["i"]]) or 0 for r in series[x]) for x in xs]
                    card(c["name"], tr, nice(sum(as_num(r[c["i"]]) or 0 for r in rows), cur=cur_of(c)))
            add(72, "kpi", ("a few measures with a timeline: KPI cards give each total, its latest change and a sparkline" if len(xs) > 1
                            else "a few measures: KPI cards give each total"),
                {"headline": "The numbers at a glance", "items": items})
    # ---- categories
    if C and N:
        c = C[0]
        tgt = next((n for n in N if is_target(n)), None)
        same = [n for n in N if n is not tgt and not is_target(n) and tgt and bool(n.get("pct")) == bool(tgt.get("pct"))
                and not NOT_TARGET.search(n["name"])]                  # an actual is the target's own kind of number
        words = lambda n: {w for w in re.findall(r"[a-z]+", n["name"].lower()) if len(w) > 3}
        act = (next((n for n in same if ACTUAL.search(n["name"])), None) or
               next((n for n in same if tgt and words(n) & words(tgt)), None) or (same[0] if same else None))
        if tgt and act:
            how = "mean" if act["avg"] or act.get("pct") else "sum"                # a rate is averaged, never added up
            a, t = dict(agg(rows, c["i"], act["i"], how)), dict(agg(rows, c["i"], tgt["i"], how))
            ks = list(a)[:6]; beat = [k for k in ks if a[k] >= t.get(k, 0)]
            top_ = max(max(a[k], t.get(k, 0)) for k in ks) * 1.1          # one scale for every row
            add(96, "bullet", f"'{act['name']}' vs '{tgt['name']}' per '{c['name']}': a bullet chart shows each against its target",
                {"headline": (f"All {len(ks)} {plural(c['name'])} beat their {low(bare(tgt['name']))}" if len(beat) == len(ks) else
                              f"{len(beat)} of {len(ks)} {plural(c['name'])} beat their {low(bare(tgt['name']))}"),
                 "items": [{"label": k, "value": round(a[k], 2), "target": round(t.get(k, 0), 2),
                            "max": round(top_, 2), **({"unit": "%"} if act.get("pct") else {})} for k in ks]}, act)
        two = [n for n in N if n is not tgt and not n["avg"]][:2]; ba = False
        if len(two) == 2 and not (tgt and act):
            n1, n2 = two
            ba = (BEFORE.search(n1["name"]) and AFTER.search(n2["name"])) or (YEAR.search(n1["name"]) and YEAR.search(n2["name"]))
            A, B = dict(agg(rows, c["i"], n1["i"])), dict(agg(rows, c["i"], n2["i"]))
            ks = list(A)[:8]
            if ba:
                up = [k for k in ks if B.get(k, 0) >= A[k]]
                add(92, "dumbbell", f"'{n1['name']}' → '{n2['name']}' per '{c['name']}': a dumbbell shows each change",
                    {"headline": f"{len(up)} of {len(ks)} {plural(c['name'])} went up", "from": n1["name"], "to": n2["name"],
                     "items": [[k, round(A[k], 2), round(B.get(k, 0), 2)] for k in ks]}, n2)
                best = max(ks, key=lambda k: B.get(k, 0) - A[k])
                add(80, "slope", "two points in time: a slope chart highlights the biggest mover",
                    {"headline": f"{best} moved the most", "from": n1["name"], "to": n2["name"], "highlight": best,
                     "items": [[k, round(A[k], 2), round(B.get(k, 0), 2)] for k in ks[:7]]}, n2)
            else:
                add(70, "butterfly", f"'{n1['name']}' and '{n2['name']}' side by side per '{c['name']}': back-to-back bars",
                    {"headline": f"{n1['name']} vs {n2['name']} by {low(c['name'])}", "left": n1["name"], "right": n2["name"],
                     "items": [[k, round(A[k], 2), round(B.get(k, 0), 2)] for k in ks]}, n1)
        m = measure
        if len(two) == 2 and not (tgt and act) and ba:
            m = two[1]                                   # before -> after: rank on the latest
        additive = m is not None and not SCORE.search(m["name"]) and not m.get("pct") and not m.get("avg")
        if m and not (tgt and m is tgt):
            vals = sorted(agg(rows, c["i"], m["i"], "mean" if m.get("pct") else "sum"), key=lambda kv: -kv[1])
            if m.get("pct") and len(vals) <= 6:
                add(84, "radialbar", f"a percentage per '{c['name']}': race-track rings compare them at a glance",
                    {"headline": f"{vals[0][0]} leads at {nice(vals[0][1], True)}", "items": [[k, round(v, 1)] for k, v in vals]}, m)
            elif not m.get("pct") and additive:
                tot = sum(v for _, v in vals) or 1
                add(86, "lollipop", f"'{m['name']}' per '{c['name']}': a ranked lollipop puts the leader first",
                    {"headline": f"{vals[0][0]} leads {low(m['name'])} with {nice(vals[0][1], cur=cur_of(m))}",
                     "items": [[k, round(v, 2)] for k, v in vals[:10]]}, m)
                if all(v >= 0 for _, v in vals) and len(vals) >= 3:
                    add(76, "treemap", f"parts of a total '{m['name']}': a treemap shows each share",
                        {"headline": f"{vals[0][0]} is {100 * vals[0][1] / tot:.0f}% of {low(m['name'])}",
                         "items": [[k, round(v, 2)] for k, v in vals[:10]]}, m)
                    add(62, "bubbles", "the same shares as sized circles - more visual, less precise",
                        {"headline": f"{vals[0][0]} is the biggest share of {low(m['name'])}", "items": [[k, round(v, 2)] for k, v in vals[:14]]}, m)
            elif not m.get("pct"):                       # a score: rank it, never as shares of a total
                add(84, "lollipop", f"'{m['name']}' per '{c['name']}' is a score: a ranked lollipop compares it",
                    {"headline": f"{vals[0][0]} leads on {m['name']} at {nice(vals[0][1], cur=cur_of(m))}",
                     "items": [[k, round(v, 2)] for k, v in vals[:10]]}, m)
        many = [n for n in N if not n.get("frac")][:8]
        if 3 <= len(many) <= 8 and 1 <= c["uniq"] <= 3:
            add(68, "radar", f"{len(many)} measures for {c['uniq']} {low(c['name'])}: a radar compares their profile",
                {"headline": f"How the {low(c['name'])} compare", "axes": [n["name"] for n in many],
                 "max": max(as_num(r[n["i"]]) or 0 for r in rows for n in many),
                 "series": {k: [round(dict(agg(rows, c["i"], n["i"], "mean")).get(k, 0), 2) for n in many]
                            for k, _ in agg(rows, c["i"], many[0]["i"])}})
    # ---- two categories / flows
    if len(C) >= 2 and N and measure and not measure["avg"] and not measure.get("pct"):   # flows and mixes only of what adds up
        a, b = C[0], C[1]; m = measure
        f_ = next((c for c in cols if FROM.match(c["name"])), None); t_ = next((c for c in cols if TO.match(c["name"])), None)
        if f_ and t_:
            fl = collections.Counter()
            for r in rows:
                fl[(str(r[f_["i"]]), str(r[t_["i"]]))] += as_num(r[m["i"]]) or 0
            add(95, "sankey", f"'{f_['name']}' → '{t_['name']}' with '{m['name']}': a sankey draws the flows",
                {"headline": f"Where {low(m['name'])} flows", "flows": [[k[0], k[1], round(v, 2)] for k, v in fl.most_common(20)]}, m)
        nest = collections.OrderedDict()
        for r in rows:
            if r[a["i"]] not in (None, "") and r[b["i"]] not in (None, ""):
                nest.setdefault(str(r[a["i"]]), collections.Counter())[str(r[b["i"]])] += as_num(r[m["i"]]) or 0
        if a["uniq"] <= 6 and sum(len(v) for v in nest.values()) <= 16:
            tot = sum(sum(v.values()) for v in nest.values()) or 1
            top = max(nest, key=lambda k: sum(nest[k].values()))
            add(74, "sunburst", f"'{m['name']}' by '{a['name']}' and then '{b['name']}': a sunburst shows both levels",
                {"headline": f"{top} is {100 * sum(nest[top].values()) / tot:.0f}% of {low(m['name'])}",
                 "items": [[g, p, round(v, 2)] for g, c_ in nest.items() for p, v in c_.items()]}, m)
        if b["uniq"] <= 4 and a["uniq"] <= 6:
            ser = sorted({p for c_ in nest.values() for p in c_})
            add(72, "stack100", f"the mix of '{b['name']}' inside each '{a['name']}': 100% bars",
                {"headline": f"{b['name']} mix by {low(a['name'])}", "series": ser,
                 "items": [[g] + [round(c_.get(p, 0), 2) for p in ser] for g, c_ in nest.items()]}, m)
    seen, out = set(), []
    for r in sorted(recs, key=lambda r: -r["score"]):
        if r["chart"] not in seen:
            seen.add(r["chart"]); out.append(r)
            cm = r.get("meas") or measure
            t = takeaway(r["chart"], r["slide"], cm["name"] if cm else "", cur_of(cm))
            if t: r["slide"]["summary"] = t
            scale_spec(r["slide"], cur_of(cm), bool(cm and cm.get("pct")))
    return out, cols


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("data", nargs="+", help="one table, or a header and an item table (two files, or two sheets of one workbook)")
    ap.add_argument("--sheet"); ap.add_argument("--top", type=int, default=3)
    ap.add_argument("--build"); ap.add_argument("--pick")
    ap.add_argument("--no-summary", action="store_true", help="leave out the value-at-a-glance slide")
    a = ap.parse_args()
    tables = read_all(a.data, a.sheet)
    if not tables:
        sys.exit("NO DATA - the file has no table with a header row and data")
    head, rows, info = join(tables)
    percent_points(head, rows)
    money_units(head, rows)
    for j in info["joined"]:
        print(f"JOINED {j}")
    if info.get("ignored"):
        print(f"USING {info['used']} only. NOT USED (no column links it to the rest): " + ", ".join(info["ignored"])
              + " - rename the order column so both tables call it the same, or tell me which columns link them")
    recs, cols = recommend(head, rows, info["key"])
    print("COLUMNS: " + " · ".join(f"{c['name']} ({c['kind']}{', %' if c.get('pct') else ''})" for c in cols))
    title, pts, tiles = overview(head, rows, info["key"])
    if pts:
        print("SUMMARY: " + " · ".join(pts))
    if not recs:
        print("NO CHART FITS - the data needs a category or date column and a number column (a table slide may suit it better)")
        sys.exit(1)
    for k, r in enumerate(recs, 1):
        print(f"{k}. {r['chart']:<10} {r['why']}  -> \"{r['slide']['headline']}\"")
        if r["slide"].get("summary"): print(f"   {'':<10} takeaway: {r['slide']['summary']}")
    pick = [int(p) for p in a.pick.split(",")] if a.pick else list(range(1, min(a.top, len(recs)) + 1))
    if a.build:
        out = Path(a.build)
        name = title_of(Path(a.data[0]).stem)
        summary = ([{"modern": "bento", "headline": title, "tiles": tiles,
                     "notes": "Value summary computed from the data:\n- " + "\n- ".join(pts)}]
                   if len(tiles) >= 3 and not a.no_summary else [])
        import storyline as SL                         # no two charts in a row tell their story one way (a ranking
        before = "numbers" if summary else None        # after a ranking): picked ones in another order, the best n
        if a.pick:                                     # varied when none was picked
            charts = SL.spread([recs[p - 1]["slide"] for p in pick if 0 < p <= len(recs)], before=before)
        else:
            charts = SL.choose([r["slide"] for r in recs], a.top, before)
            used = [next(k for k, r in enumerate(recs, 1) if r["slide"] is c) for c in charts]
            if sorted(used) != pick:
                print(f"PICKED {', '.join(map(str, used))} - so that no two charts in a row tell their story the same way")
        sb = {"slides": [{"source": 1, "title": name, "subtitle": "What the data says"}] + summary
              + charts + [{"source": 32, "text": ["Thank you!"]}]}
        sp = out.with_name(out.stem + "-storyboard.json"); out.parent.mkdir(parents=True, exist_ok=True)
        sp.write_text(json.dumps(sb, indent=1, default=str), encoding="utf-8")
        r = subprocess.run([sys.executable, str(TOOLS / "build_deck.py"), "build", str(sp), "--out", str(out)], capture_output=True, text=True)
        lines = [l for l in r.stdout.splitlines() if l.startswith(("READY", "DRAFT", "NEEDS")) or "FAIL" in l or l.startswith("RESULT")]
        print("\n".join(lines[:12]))
        print(f"STORYBOARD {sp} (edit a headline or swap a chart and rebuild with build_deck.py)")


if __name__ == "__main__":
    main()
