"""Repair ANY Ulta deck, however it was built, then validate it.

    python tools/fix_deck.py deck.pptx [--out fixed.pptx]

1. Works out which template slide each slide came from (by its shapes), so no mapping is needed.
   Slides that match no template slide (e.g. diagram slides) are treated as diagram slides.
2. Slide 20 (4-step flow): when 4 labels are given, the label bands are re-aligned to the 4 boxes.
3. autofit.py: headlines widened to full width and fitted to one line; any text that overflows,
   breaks a word or runs into an icon is shrunk.
4. validate_deck.py: prints the status block. Exit 0 = no FAIL.
"""
import argparse, collections, json, shutil, subprocess, sys, zipfile
from pathlib import Path

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import validate_deck as V   # noqa: E402


def names(slide_x):
    c = collections.Counter()
    for sp in slide_x.find(".//p:cSld/p:spTree", V.NS):
        nv = sp.find(".//p:cNvPr", V.NS)
        if nv is not None:
            c[nv.get("name")] += 1
    return c


def infer_mapping(deck):
    z, rz = zipfile.ZipFile(deck), zipfile.ZipFile(V.REF)
    parts, _, _ = V.slide_parts(z)
    rparts, _, _ = V.slide_parts(rz)
    ref = [names(etree.fromstring(rz.read(p))) for p in rparts]
    mapping, diag = [], []
    for i, part in enumerate(parts, 1):
        mine = names(etree.fromstring(z.read(part)))
        def score(r):
            inter = sum((mine & r).values()); union = sum((mine | r).values()) or 1
            return inter / union
        best = max(range(len(ref)), key=lambda k: score(ref[k]))
        if score(ref[best]) < 0.5:
            mapping.append(6); diag.append(i)            # not a template slide: diagram / engine slide
        else:
            mapping.append(best + 1)
    return mapping, diag


def align_flow_slides(deck, mapping):
    """Re-align slide-20 bands to the 4 boxes when only 4 labels are filled."""
    from pptx import Presentation
    import build_deck as BD
    prs = Presentation(str(deck))
    changed = False
    for i, s in enumerate(prs.slides, 1):
        if mapping[i - 1] != V.FLOW:
            continue
        tbl = next((sh for sh in s.shapes if sh.has_table), None)
        if tbl is None or len(tbl.table.columns) != 5:
            continue
        labels = [c.text.strip() for c in tbl.table.rows[0].cells]
        if labels[4] and not labels[4].lower().startswith("thur"):
            print(f"slide {i}: 5 labels for 4 step boxes ({labels}) - cannot be aligned automatically; "
                  "merge two labels or add the step, then rebuild")
            continue
        if BD.align_flow_table(s, tbl, 4):
            changed = True
            print(f"slide {i}: label bands re-aligned to the 4 step boxes")
    if changed:
        import atomic
        atomic.save(prs, deck)


def main():
    import contextlib, io
    verbose = "--verbose" in sys.argv
    if verbose:
        sys.argv.remove("--verbose")
    buf = io.StringIO()
    code = 0
    with contextlib.redirect_stdout(buf):
        try:
            _main()
        except SystemExit as e:
            code = e.code or 0
    log = buf.getvalue()
    out = next((l.split("FILE:", 1)[1].strip() for l in log.splitlines() if l.startswith("FILE:")), None)
    if verbose or not out:
        print(log)
    else:
        import build_deck
        build_deck.summarize(log, out)
    sys.exit(code)


def _main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck"); ap.add_argument("--out"); ap.add_argument("--action", default="checked and fixed")
    a = ap.parse_args()
    src = Path(a.deck).resolve()
    out = Path(a.out).resolve() if a.out else src.with_name(src.stem + "-fixed.pptx")
    import atomic, contextlib, io
    buf = io.StringIO()
    with atomic.build_lock(out), atomic.staged(out, keep=[src], fresh=out != src) as work:   # fixed out of sight, put at out
        if out == src and Path(str(src) + ".audit.json").exists():                          # when done: a fix the time limit
            shutil.copyfile(str(src) + ".audit.json", str(work) + ".audit.json")             # cuts off leaves no unchecked deck
        with contextlib.redirect_stdout(buf):                                               # (in place: its history goes on)
            code = fix(src, work, a.action)
    print(buf.getvalue().replace(str(work.parent), str(out.parent)), end="")
    sys.exit(code)


def fix(src, out, action):
    shutil.copyfile(src, out)
    import sections
    if sections.normalize(out):
        print("sections: removed references to slides that no longer exist")
    import data_slides
    if data_slides.fix_chart_files(out):                  # decks from v139 and earlier: PowerPoint offered to repair them
        print("charts: axis ids renumbered within what PowerPoint reads")
    c = subprocess.run([sys.executable, str(TOOLS / "ulta_conform.py"), str(out), "--keep-sizes", "--no-rebrand", "--keep-template"],
                       capture_output=True, text=True)              # kit / hand-made colours onto the palette
    mapped = next((l for l in c.stdout.splitlines() if l.startswith("ulta_conform:")), "")
    if mapped and not mapped.startswith("ulta_conform: 0 "):
        print("colours: " + mapped.split(":", 1)[1].split(",")[0].strip())
    mapping, diag = infer_mapping(out)
    import layoutmeta; layoutmeta.restore(src)           # an uploaded deck: its build record is inside the file
    old = Path(str(src) + ".ulta.json")
    meta = json.loads(old.read_text()) if old.exists() else {}   # built by build_deck.py: keep its slide lists
    rec = meta.get("source_mapping") or {}
    how = "inferred"
    if len(rec) == len(mapping) and all(str(i) in rec for i in range(1, len(mapping) + 1)):
        mapping, how = [int(rec[str(i)]) for i in range(1, len(mapping) + 1)], "from the build record"
        diag = [i for i in diag if i in set(meta.get("diagram_slides") or [])]
    diag = sorted(set(diag) | set(meta.get("diagram_slides") or []))
    meta["diagram_slides"] = diag
    Path(str(out) + ".ulta.json").write_text(json.dumps(meta))
    layoutmeta.save(out)
    m = ",".join(map(str, mapping))
    print(f"mapping ({how}): {m}" + (f"   diagram/non-template slides: {diag}" if diag else ""))
    if diag:                                             # kit / non-template slides: text into shapes, glued arrows
        subprocess.run([sys.executable, str(TOOLS / "nativize.py"), str(out), "--slides", ",".join(map(str, diag))],
                       capture_output=True, text=True)
    align_flow_slides(out, mapping)
    f = subprocess.run([sys.executable, str(TOOLS / "autofit.py"), str(out), "--mapping", m, "--out", str(out)],
                       capture_output=True, text=True)
    print(f.stdout.strip())
    import a11y, stamp
    print(f"a11y: {a11y.fix(out)} object(s) given alt text / decorative flag / header row")
    import plain; plain.clean(out)                       # plain punctuation, before the preview is drawn
    v = subprocess.run([sys.executable, str(TOOLS / "validate_deck.py"), str(out), "--mapping", m],
                       capture_output=True, text=True)
    print("\n" + v.stdout.strip())
    overall = next((l.split(":", 1)[1].strip() for l in v.stdout.splitlines() if l.startswith("OVERALL")), "not validated")
    held, where = V.hold_back(out)                       # (fixed in place: the deck stays as it was)
    if held:
        print(f"FAIL template placeholder text on {where} - this deck cannot be delivered: those slides never got their "
              "own words. Rebuild them: python tools/convert_deck.py <deck> --out <new>.pptx --build reads the deck's "
              "text and leaves the placeholders out")
        print(f"NOT WRITTEN: {out} | work copy, never to be delivered: {held}")
        print(f"\nFILE: {out}")
        return 1
    ver = stamp.stamp(out, action, overall)
    print(f"STAMP: v{ver}")
    print(f"\nFILE: {out}")
    return 0 if v.returncode == 0 else 1


if __name__ == "__main__":
    main()
