"""One-command Ulta deck builder: storyboard JSON -> template-faithful PPTX -> headline fit -> validation.

  python tools/build_deck.py inventory 12 20            # what each template slide offers (slot names + sample text)
  python tools/build_deck.py build storyboard.json --out /mnt/data/out/Deck.pptx

storyboard.json:
{
  "slides": [
    {"source": 1,  "slots": {"<shape name>": "Title\\nSubtitle"}},
    {"diagram": ["Web portal → API gateway: orders", "API gateway → Order service: validated order"],
     "style": "zones", "headline": "Every order passes the API gateway"},              # architecture slide (kit engine, Ulta palette)
    {"source": 12, "headline": "Code freeze on 15-Nov starts the cutover",
     "slots": {"Table 3": [[null, null, null],                      # null = keep the template text (header labels)
                           ["Freeze changes", "Code freeze for launch", "15-Nov / IT"],
                           ...]},
     "notes": "Sources: ..."}
  ]
}
Rules applied for you: every string goes in with ulta_text.set_text (template font/size/colour kept); each
source slide is duplicated with all its shapes, pictures and relationships; unused template slides are
removed; autofit.py shrinks any slot that would overflow, break a word or hit a picture; then validate_deck.py runs.
A slot you do not fill keeps its template sample text, which the validator FAILs. Fill it, or set it to "" to blank it.
The file is ALWAYS written. Exit 0 = validator found no FAIL; exit 1 = FAILs listed (deliver as DRAFT if not fixable).
"""
import os, argparse, copy, json, re, subprocess, sys, zipfile
from pathlib import Path

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
from pptx import Presentation
from pptx.util import Emu

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
sys.path.insert(0, str(TOOLS))
import brand as _B   # noqa: E402
BRAND = _B.current()
REF = BRAND.template
FLOW = BRAND.role("flow")
FLOW_TABLE = BRAND.role("flow_table")
from ulta_text import set_text  # noqa: E402
import full_template as FT      # noqa: E402  (the 40-layout collection: sources 34-53, names for every layout)
LAYOUTS = bool(BRAND.get("layouts"))
COVERS = {BRAND.role("cover", 1)} | (FT.kind("cover") if LAYOUTS else set())
AGENDAS = {2} | (FT.kind("agenda") if LAYOUTS else set())
NEW_DIVIDERS = (FT.kind("divider") - {5, 23, 27}) if LAYOUTS else set()
DISPLAY = {BRAND.role("cover", 1), BRAND.role("closing", 33), 32, 33, 5, 2} | (FT.display_sources() if LAYOUTS else set())
from pptx.enum.text import MSO_ANCHOR  # noqa: E402
import data_slides as DS        # noqa: E402

R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
SKIP_REL = ("slideLayout", "notesSlide")


def headline_shape(slide):
    return next((s for s in slide.shapes if s.has_text_frame and BRAND.is_headline(s._element)), None)


def slot_map(slide):
    """Unique slot keys: the shape name, plus "#2", "#3" for repeated names (in z-order)."""
    seen, out = {}, {}
    for sh in slide.shapes:
        seen[sh.name] = seen.get(sh.name, 0) + 1
        out[sh.name if seen[sh.name] == 1 else f"{sh.name}#{seen[sh.name]}"] = sh
    return out


def inventory(nums):
    prs = Presentation(str(REF))
    for n in nums:
        s = prs.slides[n - 1]
        print(f"\n=== template slide {n}  (layout: {s.slide_layout.name})")
        h = headline_shape(s)
        if h is not None:
            print(f'  headline -> use "headline": "..."   (shape "{h.name}")')
        for key, sh in slot_map(s).items():
            if h is not None and sh.shape_id == h.shape_id:
                continue
            if sh.has_table:
                t = sh.table
                print(f'  TABLE "{key}"  {len(t.rows)} rows x {len(t.columns)} cols   (give a list of rows; null keeps a cell)')
                for ri, row in enumerate(t.rows):
                    print("     r%-2d " % (ri + 1) + " | ".join((c.text.replace("\n", " / ")[:18] or "·") for c in row.cells))
            elif sh.has_text_frame and sh.text_frame.text.strip():
                print(f'  TEXT  "{key}"  sample: {sh.text_frame.text.replace(chr(10), " / ")[:60]!r}')


FOOTER_TXT = ("|",)


def text_slots(slide):
    """Text shapes a storyboard "text": [...] list fills, in reading order (top to bottom, then left to right):
    everything with text except the headline, tables, footers and slide numbers."""
    h = headline_shape(slide)
    out = []
    for sh in slide.shapes:
        if not sh.has_text_frame or (h is not None and sh.shape_id == h.shape_id):
            continue
        t = sh.text_frame.text.strip()
        if not t or "|" in t or (sh.is_placeholder and "SLIDE_NUMBER" in str(sh.placeholder_format.type)):
            continue
        out.append(sh)
    return sorted(out, key=lambda sh: (round((sh.top or 0) / 228600), sh.left or 0))


def numeric_cols(table_shape):
    """Template columns that only hold item numbers (an agenda's 1-5): they are numbered automatically."""
    t = table_shape.table
    cols = []
    for c in range(len(t.columns)):
        vals = [t.cell(r, c).text.strip() for r in range(len(t.rows))]
        if vals and all(re.fullmatch(r"\d{1,2}", v) for v in vals if v) and sum(1 for v in vals if v) >= 2:
            cols.append(c)
    return cols


# Repeated items on the template's layouts. Fewer than the sample holds: the unused columns or rows go and the rest share
# the space, each keeping its own cell style and icon. layout name -> {table: (axis, fixed leading cols/rows, min, keep height)}
REPEATS = {
    "three-cards": {"Tabulka 13": [("cols", 0, 2, False), ("rows", 1, 1, True)]},
    "kpi-cards": {"Table 3": ("cols", 0, 2, False)},
    "objectives-scope": {"Table 3": ("cols", 0, 2, False)},
    "four-pillars": {"Tabulka 4": ("cols", 1, 2, False)},
    "headline-metrics": {"Tabulka 22": ("cols", 0, 2, False)},
    "paired-columns": {"Table 8": ("rows", 0, 1, True), "Table 4": ("rows", 0, 1, True)},
    "recap-today": {"Table 1": ("rows", 0, 1, True), "Table 21": ("rows", 0, 1, True)},
    "focus-areas": {"Tabulka 9": ("rows", 0, 1, True)},
    "period-scorecard": {"Table 9": ("rows", 2, 1, False)},
    "action-register": {"Table 3": ("rows", 1, 1, False)},
}


def _spread_pick(m, n):
    """n of m repeated template items, both ends kept and the rest spread between: the colour range stays whole."""
    if n >= m:
        return list(range(m))
    if n == 1:
        return [0]
    out = []
    for i in range(n):
        k = round(i * (m - 1) / (n - 1))
        while k in out:
            k += 1
        out.append(k)
    return out


def fit_repeats(slide, sh, value, spec):
    """A shorter list for a layout's repeated columns or rows: drop the unused ones (REPEATS) instead of leaving the
    template's sample text. Returns the value to fill (the given items, in order, on the kept columns or rows)."""
    if not LAYOUTS or not isinstance(value, list):
        return value
    name = {v: k for k, v in FT.names().items()}.get(spec.get("source"))
    rule = (REPEATS.get(name) or {}).get(sh.name)
    if rule is None:
        return value
    for r_ in (rule if isinstance(rule, list) else [rule]):   # columns first, then rows (the card slide fits both)
        value = _fit_one(slide, sh, value, spec, name, r_)
    return value


def _fit_one(slide, sh, value, spec, name, rule):
    """fit_repeats for one rule (axis, fixed leading cols/rows, min, keep height)."""
    axis, fixed, low, keep_h = rule
    A_ = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    tbl = sh._element.find(f".//{A_}tbl")
    t = sh.table
    pics = [p for p in slide.shapes if "PICTURE" in str(p.shape_type)
            and sh.left <= p.left + p.width // 2 <= sh.left + sh.width and sh.top - 0.2 * 914400 <= p.top + p.height // 2 <= sh.top + sh.height]
    filled = lambda v: v is not None and str(v).strip() != ""
    if axis == "cols":
        m = len(t.columns) - fixed
        n = max([c + 1 for r in value if r for c, v in enumerate(r) if filled(v)] or [0]) - fixed
        if n > m:                                      # nothing the user gave is dropped quietly
            PROBLEMS.append(f"slide {spec.get('_k')}: {name} holds {low}-{m} items, got {n} - put the rest on a second "
                            "slide or pick a layout for more")
        if n <= 0 and fixed:
            PROBLEMS.append(f"slide {spec.get('_k')}: {name} takes {low}-{m} items beside its labels, got none - the "
                            "template's sample text would stay")
        if n >= m or n <= 0:
            return value
        if n < low:
            PROBLEMS.append(f"slide {spec.get('_k')}: {name} takes {low}-{m} items, got {n} - use a layout for {n}")
            return value
        keep = list(range(fixed)) + [fixed + k for k in _spread_pick(m, n)]
        widths = [int(c.width) for c in t.columns]
        edges = [int(sh.left) + sum(widths[:k]) for k in range(len(widths) + 1)]
        block = sum(widths[fixed:])
        grid = tbl.find(f"{A_}tblGrid")
        cols = grid.findall(f"{A_}gridCol")
        for k, c in enumerate(cols):
            if k not in keep:
                grid.remove(c)
        for tr in tbl.findall(f"{A_}tr"):
            for k, tc in enumerate(tr.findall(f"{A_}tc")):
                if k not in keep:
                    tr.remove(tc)
        new_w = widths[:fixed] + [block // n] * (n - 1) + [block - block // n * (n - 1)]
        for c, w in zip(grid.findall(f"{A_}gridCol"), new_w):
            c.set("w", str(w))
        new_edges = [int(sh.left) + sum(new_w[:k]) for k in range(len(new_w) + 1)]
        for p in pics:                                 # an icon sits on its column: it goes or moves with it
            cx = p.left + p.width // 2
            k = next((k for k in range(len(widths)) if edges[k] <= cx < edges[k + 1]), None)
            if k is None or k < fixed:
                continue
            if k not in keep:
                p._element.getparent().remove(p._element)
            else:
                j = keep.index(k)
                off = cx - (edges[k] + edges[k + 1]) // 2
                p.left = Emu(int((new_edges[j] + new_edges[j + 1]) // 2 + off - p.width // 2))
        print(f"note: slide {spec.get('_k')}: {name} with {n} of {m} items - the unused {m - n} went, the rest share the width")
        spec["_list_shortened"] = True                 # validate_deck: the rest is proved to be the template's own shapes
        return value
    m = len(t.rows) - fixed
    n = max([i + 1 for i, r in enumerate(value) if r and any(filled(v) for v in r)] or [0]) - fixed
    if n > m:
        PROBLEMS.append(f"slide {spec.get('_k')}: {name} holds {low}-{m} rows in '{sh.name}', got {n} - put the rest on a "
                        "second slide")
    if n <= 0 and fixed:
        PROBLEMS.append(f"slide {spec.get('_k')}: {name} takes {low}-{m} rows under its labels, got none - the template's "
                        "sample text would stay" + (": give a first row of 1-3 word column labels, then 1-2 rows of "
                        "'Sub-headline\\n\\ntext' cards" if name == "three-cards" else ""))
    if n >= m or n <= 0:
        return value
    if n < low:
        PROBLEMS.append(f"slide {spec.get('_k')}: {name} takes {low}-{m} rows, got {n}")
        return value
    heights = [int(r.height) for r in t.rows]
    tops = [int(sh.top) + sum(heights[:k]) for k in range(len(heights) + 1)]
    trs = tbl.findall(f"{A_}tr")
    for tr in trs[fixed + n:]:
        tbl.remove(tr)
    if keep_h:                                         # inside a coloured box: the kept rows share the box's height
        room = sum(heights[fixed:])
        for k in range(n):
            t.rows[fixed + k].height = Emu(room // n if k < n - 1 else room - room // n * (n - 1))
    new_h = [int(r.height) for r in t.rows]
    new_tops = [int(sh.top) + sum(new_h[:k]) for k in range(len(new_h) + 1)]
    sh.height = Emu(sum(new_h))
    for p in pics:                                     # an icon on a row (a tick) goes or moves with it
        cy = p.top + p.height // 2
        k = next((k for k in range(len(heights)) if tops[k] <= cy < tops[k + 1]), None)
        if k is None or k < fixed:
            continue
        if k >= fixed + n:
            p._element.getparent().remove(p._element)
        else:
            off = cy - (tops[k] + tops[k + 1]) // 2
            p.top = Emu(int((new_tops[k] + new_tops[k + 1]) // 2 + off - p.height // 2))
    print(f"note: slide {spec.get('_k')}: {name} with {n} of {m} rows - the unused {m - n} went")
    spec["_list_shortened"] = True
    return value[:fixed + n]


def cards_as_tiles(spec, k):
    """The card slide (7) given one row of cells that each hold a title and, on the next line, a detail, and no column
    labels: the template would take them
    for its labels (shrunk to fit the header band) and keep its two rows of sample cards. 2-6 such cards are set as
    numbered tiles instead, every word kept; a first row of 1-3 word labels keeps the card layout."""
    if not isinstance(spec, dict) or BRAND.name != "ulta" or spec.get("source") != 7 or not isinstance(spec.get("table"), list):
        return spec
    rows = [r for r in spec["table"] if isinstance(r, list) and any(str(v or "").strip() for v in r)]
    cells = [str(v).strip() for v in (rows[0] if rows else []) if str(v or "").strip()]
    if len(rows) != 1 or not 2 <= len(cells) <= 6 or not all("\n" in c for c in cells):
        return spec
    tiles = []
    for c in cells:
        lines = [l.strip() for l in c.split("\n") if l.strip()]
        tiles.append({"lead": lines[0], "text": " ".join(lines[1:])})
    out = {key: v for key, v in spec.items() if key not in ("source", "table", "slots")}
    out["bullets"] = tiles
    print(f"note: slide {k}: {len(tiles)} cards came without column labels - set as numbered tiles (a first row of 1-3 "
          "word labels keeps the card layout)")
    return out


# How a slide reads at a glance. Two slides in a row with one look read as one slide shown twice, whatever their words.
COLUMNS_LOOK = (7, 42, 43, 47)         # a coloured header band over white columns: cards, paired columns, pillars, scope
NUMBERS_LOOK = (9, 13, 49)             # big numbers
TABLES_LOOK = (10, 11, 12, 14, 50)     # rows of the template table
LOOK_WORDS = {"columns": "headed columns", "tiles": "numbered tiles", "numbers": "big numbers", "table": "a table",
              "process": "a process flow", "list": "a bulleted list"}
SEQUENCE = re.compile(r"(?i)\b(life ?cycles?|process|journey|path|pipeline|roadmap|phases?|stages?|steps?|waves?|horizons?|"
                      r"sequence|funnel|from .+ to)\b")
SEQ_NAME = re.compile(r"(?i)^(phase|stage|step|wave|horizon|sprint|week|month|day|q[1-4]|\d{1,2}[.):]?)\b")


def look_of(spec):
    """'columns', 'tiles', 'numbers', 'table', 'process', 'list' or a template infographic's key; None for a slide that is
    its own picture (chart, diagram, graphic, timeline, swimlane, process flow, retail diagram, photo) and for covers,
    agendas, dividers and closings."""
    if BRAND.name != "ulta" or not isinstance(spec, dict) or spec.get("source") in DISPLAY:
        return None
    if any(spec.get(k_) for k_ in ("diagram", "chart", "modern", "graphic", "picture", "library")) or family_of(spec):
        return None
    import template_infographics as TI
    key = TI.key_of(spec)
    if key:
        return "numbers" if key == "quad" else key
    src = spec.get("source")
    if spec.get("bullets") is not None:
        return "list" if spec.get("plain") else "tiles"
    return ("process" if FLOW and src == FLOW else "columns" if src in COLUMNS_LOOK else "numbers" if src in NUMBERS_LOOK
            else "table" if src in TABLES_LOOK or (src is None and spec.get("table") is not None) else None)


def _cell_lines(v):
    return [l.strip() for l in str(v or "").split("\n") if l.strip()]


def column_items(spec):
    """A headed-column slide's words as items: [(name, [[line, ...] per row])]; None when the slide says more than
    names and their lines (row labels, an empty column), so nothing could be lost in another layout."""
    src, t = spec.get("source"), spec.get("table")
    rows = [r for r in t if isinstance(r, list)] if isinstance(t, list) else []
    if src == 43 and rows:                                     # pillars: [None, names], [label?, summaries], [label?, points]
        if any(str(r[0] or "").strip() for r in rows):
            return None
        names = [str(v or "").strip() for v in rows[0][1:]]
        body = [[_cell_lines(r[j]) if j < len(r) else [] for r in rows[1:]] for j in range(1, len(rows[0]))]
    elif src == 7 and len(rows) >= 2 and all("\n" not in str(v or "") for v in rows[0]):
        names = [str(v or "").strip() for v in rows[0]]       # cards: column titles, then 1-2 rows of "Sub\n\ntext" cards
        body = []
        for j in range(len(names)):
            cards = []
            for r in rows[1:]:
                ls = _cell_lines(r[j]) if j < len(r) else []
                if ls:
                    rest = " ".join(ls[1:])
                    cards.append([ls[0] + ((" - " if ":" in ls[0] else ": ") + rest if rest else "")])
            body.append(cards)
    elif src == 47 and len(rows) == 2:                         # scope: headers, then "point\npoint" under each
        names = [str(v or "").strip() for v in rows[0]]
        body = [[_cell_lines(rows[1][j]) if j < len(rows[1]) else []] for j in range(len(names))]
    elif src == 42 and isinstance(spec.get("text"), list) and isinstance(spec.get("slots"), dict):
        names = [str(v or "").strip() for v in spec["text"][:2]]
        sl = spec["slots"]
        body = [[[str((r or [""])[0] or "").strip() for r in (sl.get(key) or []) if str((r or [""])[0] or "").strip()]]
                for key in ("Table 8", "Table 4")]
    else:
        return None
    items = [(n, [g for g in b if g]) for n, b in zip(names, body)]
    if not items or any(not n or not b for n, b in items):
        return None
    return items


def _detail(groups):
    """An item's lines as one line: its points apart by a middle dot (each keeps its own capitals), its rows (a summary,
    the points) as sentences."""
    return ". ".join(" \u00b7 ".join(g) for g in groups)


def _nw(t):
    """Words in t (a dash or a colon is not a word)."""
    return len(re.findall(r"\w[\w'’]*", str(t)))


def relaid(spec, items, prefer):
    """The same items in the first layout of `prefer` ('process', 'tiles') that holds every word within its limits."""
    keep = {k_: v for k_, v in spec.items() if k_ not in ("source", "table", "slots", "text", "style", "bullets", "plain",
                                                          "numbered", "start")}
    import typeset as _TS
    for look in prefer:
        if look == "process" and FLOW and 3 <= len(items) <= 6 and all(len(g) == 1 for _, g in items):
            steps = [{"label": n, "text": _detail(g)} for n, g in items]   # (the flow's headline sets on one line)
            if all(_nw(x["label"]) <= 3 and 2 <= _nw(x["text"]) <= 6 for x in steps) and \
                    _TS.fits_headline(str(spec.get("headline") or "")):
                return dict(keep, source=FLOW, steps=steps), look
        if look == "tiles" and 2 <= len(items) <= 6:
            tiles = [{"lead": n, "text": _detail(g)} for n, g in items]
            words = [_nw(f"{x['lead']} {x['text']}") for x in tiles]
            if max(words) <= 15 and sum(words) <= 80 and all(_nw(x["lead"]) <= 4 for x in tiles):
                return dict(keep, bullets=tiles), look
    return None, None


def point_items(spec):
    """A slide of points as items for another layout: headed columns (column_items), or tiles / a list whose points
    each read "Lead: detail"; None when a point has no lead."""
    if look_of(spec) == "columns":
        return column_items(spec)
    b = spec.get("bullets")
    if not isinstance(b, list) or not b:
        return None
    items = []
    for x in b:
        lead, text = ((x.get("lead"), x.get("text")) if isinstance(x, dict) else
                      str(x).split(": ", 1) if isinstance(x, str) and ": " in str(x) else (None, None))
        if not str(lead or "").strip() or not str(text or "").strip():
            return None
        items.append((str(lead).strip(), [[str(text).strip()]]))
    return items


def clash(a, b):
    """b, right after a, looks like it or tells its story a's way, and does not carry it on."""
    import storyline as SL
    same = (look_of(a) and look_of(a) == look_of(b)) or (SL.device_of(a) and SL.device_of(a) == SL.device_of(b))
    return bool(same) and not SL.continues(a, b)


def retail_first(slides, converted=False, gallery=False):
    """A slide whose content is a supply chain or a retail process is shown as a retail diagram first (SKILL.md rule
    10): items that string vendors, DCs, stores and guests together, a DC's zones or a process's documents in order
    become that retail diagram, the steps of a retail process a process flow with its pictograms - every word kept
    (tools/retail.py fit). Never when the slide would then repeat the slides beside it more than it does now, nor on a
    slide marked "retail_first": false; a converted deck keeps the source deck's layouts, a catalogue shows one kind
    on purpose. What can't be set here, the expert review names."""
    if converted or gallery or BRAND.name != "ulta":
        return slides
    import storyline as SL
    out = list(slides)

    def repeats(k, s):                                 # how many of slide k's neighbours s would repeat
        return (k > 0 and clash(out[k - 1], s)) + (k + 1 < len(out) and clash(s, out[k + 1]))
    for k, s in enumerate(out):
        f = SL.retail_fit(s)
        new = f and f["spec"]
        if not new or repeats(k, new) > repeats(k, s):
            continue
        what = ("its steps get their retail pictograms" if s.get("process") is not None else
                f"set as {SL.fit_form(f)}")
        print(f"note: slide {k + 1}: {what} - {f['why']}: a supply chain or a retail process is shown as a retail "
              "diagram first; every word kept")
        out[k] = new
    return out


def vary_neighbours(slides, converted=False, gallery=False):
    """Two slides in a row that tell their story the same way or look alike (four pillars after a card slide): one of
    them is re-laid when its words fit a layout that neither neighbour has, in way or look - points that run in order
    as a flow, headed columns beside another way as numbered tiles - every word kept. A converted deck keeps the source
    deck's layouts; a catalogue ("gallery") shows one kind on purpose. Returns the slides; what can't move is a
    design_lint problem."""
    if converted or gallery or BRAND.name != "ulta":
        return slides
    import storyline as SL
    out = list(slides)
    for k in range(1, len(out)):
        if not clash(out[k - 1], out[k]):
            continue
        for j in (k, k - 1):                           # the second slide first, then the first one
            items = point_items(out[j]) if SL.device_of(out[j]) == "points" else None
            if not items:
                continue
            seq = bool(SEQUENCE.search(str(out[j].get("headline") or ""))) or sum(bool(SEQ_NAME.match(n)) for n, _ in items) >= 2
            for look in (["process"] if seq else []) + (["tiles"] if look_of(out[j]) == "columns" else []):
                new, _ = relaid(out[j], items, [look])
                if new and not (j > 0 and clash(out[j - 1], new)) and not (j + 1 < len(out) and clash(new, out[j + 1])):
                    other = k - 1 if j == k else k
                    why = ("told its story the same way" if SL.device_of(out[j]) == SL.device_of(out[other]) else "looked the same")
                    print(f"note: slide {j + 1}: set as {LOOK_WORDS[look]} - next to slide {other + 1} "
                          f"({SL.form_of(out[other])}) it {why}, and two slides in a row like that read as one point made "
                          "twice; every word kept")
                    out[j] = new
                    break
            if not clash(out[k - 1], out[k]):
                break
    return out


def number_column(table_shape, rows):
    """Rows for a table whose first column is the template's number column: number it 1..n whatever was given.
    A row one cell short gets its number added; a word put in the number column moves into the text ("Label: text")."""
    cols = numeric_cols(table_shape)
    if cols != [0]:
        return rows
    ncol = len(table_shape.table.columns)
    out, moved = [], False
    for i, r in enumerate(rows):
        if r is None:
            out.append(None); continue
        r = list(r)
        if len(r) == ncol - 1:
            r = [None] + r
        first = "" if r[0] is None else str(r[0]).strip()
        if first and not re.fullmatch(r"\d{1,2}", first):
            rest = [x for x in r[1:] if x not in (None, "")]
            r = [None, f"{first}: {rest[0]}" if rest else first] + r[2:]
            moved = True
        r[0] = str(i + 1)
        out.append(r)
    if moved:
        print("note: the first column is the item number; words put there were moved into the text")
    return out


# What each layout added from the updated template takes in a storyboard (collection.json says what it is for)
TAKES = {
    "cover-collage": '"title" (55 characters)', "cover-photo": '"title" (55 characters)',
    "cover-texture": '"title" (55 characters)', "cover-gradient": '"title" (55 characters)',
    "agenda-gradient": '"table": [[null, "item"], ...1-5]', "agenda-list": '"table": [[null, "item"], ...1-5]',
    "divider-photo": '"title" (1-4 words)', "divider-berry": '"title" (1-4 words)', "divider-makeup": '"title" (1-4 words)',
    "paired-columns": '"text": ["left header", "right header"], "slots": {"Table 8": [["point"], ...1-3], "Table 4": [...1-3]}',
    "four-pillars": '"table": [[null, "Name", ...2-4], [null or "row label", "one-line summary", ...], [null or "row label", "point\\npoint", ...]]',
    "recap-today": '"text": ["Recap\\n(MM/DD)", "Today\'s Focus\\n(MM/DD)"], "slots": {"Table 1": [["done"], ...1-5], "Table 21": [["next"], ...1-3]}',
    "focus-areas": '"slots": {"Tabulka 9": [[null, "area"], ...1-4]}; times and topics: "table": [["Time", "Topics"], ["9:00", "..."], ...]',
    "objectives-scope": '"table": [["Objectives", "Scope", ...2-3], ["point\\npoint", ...]]',
    "team": '"people": [["Name", "Role"], ...1-10]',
    "headline-metrics": '"table": [["$4.6M\\nNet sales", ...2-4]]',
    "period-scorecard": '"table": [[null, "Q1/25", "Q1/26", "Change", "Notes"], [], ["Metric", "x%", "y%", "+z pts", "note"], ...1-7]',
    "big-note": '"title" (one short line)', "big-note-close": '"title" (one short line)',
    "photo-quote": '"text": ["the quote", "who said it"]',
}

# The template infographics in plain words: the key, its template slide, what it shows and the counts it takes
INFOGRAPHIC_MENU = [
    ("priorities", "vision house: a vision, 0-3 goals, 3-6 pillars (strategies) with 0-2 KPIs each - strategy on a page"),
    ("ogsm", "objective, 1-3 goals, 1-3 strategies and 1-3 measures - a plan on a page"),
    ("funnel", "3-4 stages from first touch to result (5-6 stages are drawn as a funnel)"),
    ("quad", "four big numbers with labels (2-3 go on the headline-metrics row)"),
    ("donut", "share of a total: 2-5 parts and 0-2 call-outs"),
    ("journey", "three horizons that grow: then, now, next"),
    ("results", "results, learnings and actions by group (1-5 groups)"),
    ("scorecard", "KPI scorecard with highlights and lowlights (up to 13 KPIs)"),
    ("map", "US map with 1-4 pins"),
]


def compact(nums, menu=True):
    """One line per slide: what a storyboard can fill with the short keys (headline, table, text[]); with menu, the
    updated template's added layouts and the template infographics follow, in plain words."""
    prs = Presentation(str(REF))
    label = ({v: k for k, v in FT.ALIASES.items()} | {v: k for k, v in FT.names().items()}) if LAYOUTS else {}
    print('keys: "headline":"..." | "table":[rows] (null keeps a cell) | "text":["...", ...] in this order | "notes"')
    print('"source" takes the number or the name')
    for n in nums:
        s = prs.slides[n - 1]
        parts = ["headline" if headline_shape(s) is not None else "no headline"]
        for sh in s.shapes:
            if sh.has_table:
                t = sh.table
                if numeric_cols(sh) == [0]:
                    parts.append(f"numbered list of {len(t.rows)}: give \"table\":[[null,\"item\"],...] - numbers are automatic")
                    continue
                parts.append(f"table {len(t.rows)}x{len(t.columns)} [{' | '.join(c.text.strip().replace(chr(10), ' ')[:14] for c in t.rows[0].cells)}]")
        texts = text_slots(s)
        if texts:
            parts.append(f"text x{len(texts)}: " + " / ".join(repr(sh.text_frame.text.strip().replace(chr(10), ' ')[:16]) for sh in texts))
        print(f"{n:>3}  {label.get(n, ''):<18}" + " · ".join(parts))
    if not menu:
        return
    if LAYOUTS:
        print("Added layouts of the updated template (\"source\": the name). Fewer items than the sample: the unused ones "
              "go and the rest share the space:")
        for r in FT.collection()["slides"]:
            if r.get("new"):
                print(f"{r['source']:>3}  {r['name']:<18}{r['use']} · {TAKES.get(r['name'], '')}")
    import template_infographics as TI
    print("Template infographics - give the key, the template's own designed slide is filled (its exact look):")
    for key, what in INFOGRAPHIC_MENU:
        print(f"  {key:<11} {TI.KEYS[key]:>2}  {what}")
    print("  shapes: python tools/template_infographics.py · all of them: build_deck.py infographics --out ...\n"
          "Project timelines {\"timeline\": {...}, \"style\": ...}: build_deck.py timelines --out ... shows every style\n"
          "Cross-functional swimlanes {\"swimlane\": {...}, \"style\": ...}: build_deck.py swimlanes --out ... shows every style\n"
          "Process flows {\"process\": {\"steps\": [...]}, \"style\": ...}: build_deck.py flows --out ... shows every style\n"
          "Retail diagrams {\"retail\": {...}, \"style\": \"network|fulfilment|dc-flow|cross-dock|document-flow\"} or a starter "
          "{\"retail\": \"procure-to-pay\"}: build_deck.py retail --out ... shows every style and starter (python tools/retail.py "
          "starters)")


def duplicate(prs, src):
    new = prs.slides.add_slide(src.slide_layout)
    tree = new.shapes._spTree
    for el in list(tree):
        tree.remove(el)
    for el in src.shapes._spTree:                       # template group frame, byte-for-byte
        if etree.QName(el).localname in ("nvGrpSpPr", "grpSpPr"):
            tree.append(copy.deepcopy(el))
    remap = {}
    for rid, rel in src.part.rels.items():
        if any(k in rel.reltype for k in SKIP_REL):
            continue
        if rel.is_external:
            remap[rid] = new.part.relate_to(rel.target_ref, rel.reltype, is_external=True)
        else:
            remap[rid] = new.part.relate_to(rel.target_part, rel.reltype)
    for el in src.shapes._spTree:
        if etree.QName(el).localname in ("nvGrpSpPr", "grpSpPr"):
            continue
        c = copy.deepcopy(el)
        for node in c.iter():
            for attr in list(node.attrib):
                if attr.startswith("{%s}" % R_NS) and node.attrib[attr] in remap:
                    node.attrib[attr] = remap[node.attrib[attr]]
        tree.append(c)
    src_bg = src._element.find("{%s}cSld/{%s}bg" % (P_NS, P_NS))
    if src_bg is not None:
        new._element.find("{%s}cSld" % P_NS).insert(0, copy.deepcopy(src_bg))
    for k, v in src._element.attrib.items():
        new._element.set(k, v)
    return new


def align_flow_table(slide, table_shape, ncols):
    """Slide 20: the template has 5 label bands but 4 boxes. With 4 labels, rebuild the band table as 4
    columns, each centred on its box (boundaries half-way between boxes; outer edges unchanged)."""
    A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    boxes = sorted((sh.left + sh.width // 2) for sh in slide.shapes
                   if sh.has_text_frame and sh.text_frame.text.strip() and not sh.has_table
                   and sh.top > table_shape.top and sh.width < table_shape.width / 3)
    if len(boxes) != ncols or ncols != 4:
        return False
    tbl = table_shape._element.find(".//" + A + "tbl")
    grid = tbl.find(A + "tblGrid")
    cols = grid.findall(A + "gridCol")
    if len(cols) != 5:
        return False
    left, right = table_shape.left, table_shape.left + sum(int(c.get("w")) for c in cols)
    bounds = [left] + [(boxes[k] + boxes[k + 1]) // 2 for k in range(3)] + [right]
    grid.remove(cols[-1])
    for k, c in enumerate(grid.findall(A + "gridCol")):
        c.set("w", str(bounds[k + 1] - bounds[k]))
    for tr in tbl.findall(A + "tr"):
        tcs = tr.findall(A + "tc")
        tr.remove(tcs[-1])
    return True


def layout_flow(slide, steps):
    """Template slide 20 for N steps (3-6): N label bands of equal width, N boxes each centred in its band,
    with its connector and timeline dot. Box colours cycle through the template's four; band shading
    alternates as in the template. Text goes in with set_text (template formatting)."""
    A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    from pptx.util import Emu
    n = len(steps)
    if not 3 <= n <= 6:
        print(f"warning: slide 20 takes 3-6 steps, got {n}")
        return
    shapes = list(slide.shapes)
    tbl = next(sh for sh in shapes if sh.has_table)
    boxes = sorted((sh for sh in shapes if sh.has_text_frame and not sh.has_table and sh.top > tbl.top
                    and sh.width < tbl.width / 3 and sh.height > Emu(914400)), key=lambda sh: sh.left)
    conns = sorted((sh for sh in shapes if sh.width == 0 and sh.height > 0), key=lambda sh: sh.left)
    dots = sorted((sh for sh in shapes if sh.name.startswith("Ov")), key=lambda sh: sh.left)
    tree = slide.shapes._spTree
    next_id = [max(int(e.get("id")) for e in tree.iter("{http://schemas.openxmlformats.org/presentationml/2006/main}cNvPr")) + 1]

    def clone(src_list, k):
        el = copy.deepcopy(src_list[k % len(src_list)]._element)
        nv = el.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}cNvPr")
        nv.set("id", str(next_id[0])); nv.set("name", f"{nv.get('name')} step{k + 1}"); next_id[0] += 1
        src_list[-1]._element.addnext(el)
        return el

    # table: n columns, equal width, band shading cycling through the template's five
    t = tbl._element.find(".//" + A + "tbl")
    grid = t.find(A + "tblGrid")
    cols = grid.findall(A + "gridCol")
    total = sum(int(c.get("w")) for c in cols)
    rows = t.findall(A + "tr")
    tmpl_cells = [r.findall(A + "tc") for r in rows]
    for c in cols:
        grid.remove(c)
    for r in rows:
        for tc in r.findall(A + "tc"):
            r.remove(tc)
    w = total // n
    for k in range(n):
        gc = copy.deepcopy(cols[k % len(cols)]); gc.set("w", str(w if k < n - 1 else total - w * (n - 1))); grid.append(gc)
        for r, cells in zip(rows, tmpl_cells):
            ext = r.find(A + "extLst")                 # cells go before the row's extLst (schema order) - PowerPoint
            new_tc = copy.deepcopy(cells[k % len(cells)])   # drops the cell fills of a misordered row and paints
            ext.addprevious(new_tc) if ext is not None else r.append(new_tc)   # the band in the table style (orange)
    # boxes / connectors / dots: exactly n of each
    els = {"box": [b._element for b in boxes], "conn": [c._element for c in conns], "dot": [d._element for d in dots]}
    for key, lst in (("box", boxes), ("conn", conns), ("dot", dots)):
        cur = els[key]
        while len(cur) > n:
            tree.remove(cur.pop())
        while len(cur) < n:
            cur.append(clone(lst, len(cur)))
    def xfrm(el):
        return el.find(".//" + A + "xfrm") if el.find(".//" + A + "xfrm") is not None else None
    bw = min(int(xfrm(els["box"][0]).find(A + "ext").get("cx")), w - int(Emu(182880)))     # 0.2 in gutter
    for k in range(n):
        centre = tbl.left + w * k + w // 2
        bx = xfrm(els["box"][k]); bx.find(A + "ext").set("cx", str(bw)); bx.find(A + "off").set("x", str(centre - bw // 2))
        xfrm(els["conn"][k]).find(A + "off").set("x", str(centre))
        dx = xfrm(els["dot"][k]); dx.find(A + "off").set("x", str(centre - int(dx.find(A + "ext").get("cx")) // 2))
    # text
    from pptx.text.text import TextFrame
    from pptx.table import _Cell
    cells = [c for c in rows[0].findall(A + "tc")]
    for k, st in enumerate(steps):
        set_text(_Cell(cells[k], tbl.table).text_frame, st.get("label", ""))
        txBody = els["box"][k].find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}txBody")
        set_text(TextFrame(txBody, None), st.get("text", ""))


def _lines(text, width_emu, size_emu, font, M):
    """Greedy word wrap with the brand's font metrics: how many lines `text` takes at this size."""
    n = 0
    for para in (text or "").split("\n"):
        words, cur = para.split(), ""
        if not words:
            n += 1; continue
        k = 1
        for w in words:
            if (_B.width_of(w, font, M) or len(w) * 0.55) * size_emu > width_emu:
                return 99                                            # any word wider than the box (the first too): PowerPoint splits it
            trial = (cur + " " + w).strip()
            wd = (_B.width_of(trial, font, M) or len(trial) * 0.55) * size_emu
            if cur and wd > width_emu:
                k += 1; cur = w
            else:
                cur = trial
        n += k
    return n


def grow_table(shape, body_cap=16, head_cap=14):
    """Short text in a template table with roomy cells is enlarged (one factor for the body, one for the header row)
    up to a readable cap, never past what every cell can hold. The template's sizes stay the floor."""
    from pptx.util import Pt
    M = _B.metrics_for(BRAND)
    tbl = shape.table
    rows = list(tbl.rows)
    widths = [c.width for c in tbl.columns]

    def cells(ri):
        for ci, c in enumerate(rows[ri].cells):
            if c.is_spanned or not c.text.strip():
                continue
            runs = [r for p in c.text_frame.paragraphs for r in p.runs if r.font.size]
            if runs:
                yield c, ci, runs

    def fits(group, f):
        for ri in group:
            for c, ci, runs in cells(ri):
                size = min(r.font.size for r in runs) * f
                font = runs[0].font.name or BRAND.font("body")
                w = widths[ci] - (c.margin_left or 91440) - (c.margin_right or 91440)
                h = rows[ri].height - (c.margin_top or 45720) - (c.margin_bottom or 45720)
                if _lines(c.text, w, size, font, M) * size * 1.2 > h:
                    return False
        return True

    for group, cap in (([0], head_cap), (list(range(1, len(rows))), body_cap)):
        sizes = [min(r.font.size for r in runs) for ri in group for _, _, runs in cells(ri)]
        if not sizes:
            continue
        base = min(sizes)
        if base >= Pt(cap):
            continue
        f, best = 1.0, 1.0
        while base * f + Pt(0.5) <= Pt(cap):
            f += Pt(0.5) / base
            if not fits(group, f):
                break
            best = f
        if best > 1.0:
            for ri in group:
                for _, _, runs in cells(ri):
                    for r in runs:
                        r.font.size = max(r.font.size, min(int(r.font.size * best), Pt(cap)))   # cap; never shrink


def nodot(s):
    """Ulta style: no full stop at the end of a headline, title, card title or short table entry (one sentence, <= 12
    words). Body sentences keep theirs; "..." and abbreviations like "etc." are left alone."""
    if not isinstance(s, str):
        return s
    t = s.rstrip()
    if (t.endswith(".") and not t.endswith("..") and len(t.split()) <= 12 and ". " not in t[:-1]
            and not re.search(r"\b(etc|e\.g|i\.e|vs|inc|ltd|no)\.$", t, re.I)):
        return t[:-1]
    return s


def nodot_cells(value):
    """nodot on each line of a table value (lists of rows, or a single string)."""
    if isinstance(value, list):
        return [nodot_cells(v) for v in value]
    if isinstance(value, str):
        return "\n".join(nodot(l) for l in value.split("\n"))
    return value


def grow_text(shape, cap_pt=20, fill=0.66):
    """Short body text in a roomy template text box is enlarged (0.5 pt steps, up to cap_pt) while it still uses at
    most `fill` of the box height - so a two-sentence box doesn't sit as small print in a big empty card."""
    from pptx.util import Pt
    runs = [r for p in shape.text_frame.paragraphs for r in p.runs if r.font.size]
    if not runs or not shape.text_frame.text.strip():
        return
    base = min(r.font.size for r in runs)
    if base >= Pt(cap_pt) or max(r.font.size for r in runs) > Pt(cap_pt):
        return                                          # headings and big numbers keep their size
    M = _B.metrics_for(BRAND)
    tf = shape.text_frame
    w = shape.width - Emu_(tf.margin_left) - Emu_(tf.margin_right)
    h = (shape.height - Emu_(tf.margin_top) - Emu_(tf.margin_bottom)) * fill
    font = runs[0].font.name or BRAND.font("body")
    f, best = 1.0, 1.0
    while base * f + Pt(0.5) <= Pt(cap_pt):
        f += Pt(0.5) / base
        if _lines(tf.text, w, base * f, font, M) * base * f * 1.25 > h:
            break
        best = f
    if best > 1.0:
        for r in runs:
            r.font.size = Emu_(int(r.font.size * best) // 6350 * 6350)
        for p in tf.paragraphs:                         # keep the reading rhythm as the text grows
            ls = p.line_spacing
            if ls is None or (isinstance(ls, float) and ls < 1.1):
                p.line_spacing = 1.15
            elif not isinstance(ls, float):             # exact spacing in points (template) grows with the text
                from pptx.util import Emu
                p.line_spacing = Emu(int(ls * best) // 6350 * 6350)


SHORT_BOX_WORDS = 30                                # two-box slide: up to this many words a box = a highlighted statement


def fit_lines(shape, base_pt, max_lines=2, floor_pt=36):
    """A title that would wrap onto more than max_lines lines at its inherited size is set smaller (2 pt steps).
    v6.35.2 (Studio): measured against 94% of the box - room for PowerPoint's own spacing and a synthesized bold, so a word that
    just fits on paper is not split ("replenishmen / t") on screen."""
    from pptx.util import Pt
    M = _B.metrics_for(BRAND)
    font = BRAND.font("heading")
    w = int((shape.width - Emu_(shape.text_frame.margin_left) - Emu_(shape.text_frame.margin_right)) * 0.94)
    size = Pt(base_pt)
    while _lines(shape.text_frame.text, w, size, font, M) > max_lines and size - Pt(2) >= Pt(floor_pt):
        size -= Pt(2)
    if size < Pt(base_pt):
        for p in shape.text_frame.paragraphs:
            for r in p.runs:
                r.font.size = size


def inherited_size(shape, default=60):
    """The point size a placeholder inherits from its layout (first sz found), else default."""
    try:
        idx = shape.placeholder_format.idx
        for ph in shape.part.slide.slide_layout.placeholders:
            if ph.placeholder_format.idx == idx:
                m = re.search(r'sz="(\d+)"', etree.tostring(ph._element).decode())
                if m:
                    return int(m.group(1)) / 100
    except Exception:
        pass
    return default


def explicit_or_inherited(shape):
    sizes = [r.font.size.pt for p in shape.text_frame.paragraphs for r in p.runs if r.font.size]
    return max(sizes) if sizes else inherited_size(shape)


BIG_NUMBER = re.compile(r"^[^A-Za-z]*\d[\d.,]*\s*(%|x|[KMB]|bn|pts?|days?|hrs?|weeks?|min)?\+?$|^[$€£]?\d", re.I)


DIVIDERS = []          # slide numbers of section dividers in this build (auto section numbers)
TRIMMED = []           # slides whose template cards were trimmed to the content (team): own geometry check
_diagram_sigs = []     # (slide, (drawn style, flows)) - two slides with the same picture are caught
PROBLEMS = []          # storyboard problems the template validator cannot see (it only compares with the template)
HEADLINE_MAX = 60


def initials(name):
    words = [w for w in re.findall(r"[^\W\d_][\w'-]*", str(name or "")) if w[0].isalpha()]
    return ((words[0][0] + (words[-1][0] if len(words) > 1 else "")).upper()) if words else ""


def team_fill(slide, spec):
    """The team layout: 10 cards (name, role) under 10 photo circles. Each person gets a card and their initials in
    the circle; 5 or fewer sit in one row centred on the slide, 6-9 keep two rows with the second row centred. Unused
    cards and circles are removed, never left as 'Name Surname'."""
    people = []
    for v in spec.get("people") or []:
        if isinstance(v, dict):
            people.append((str(v.get("name") or ""), str(v.get("role") or v.get("title") or "")))
        elif isinstance(v, (list, tuple)):
            people.append((str(v[0] if v else ""), str(v[1] if len(v) > 1 else "")))
        else:
            name, _, role = str(v).partition(",")
            people.append((name.strip(), role.strip()))
    cards = [sh for sh in slide.shapes if sh.has_text_frame and sh.text_frame.text.startswith("Name Surname")]
    rows = sorted({round(c.top / 91440) for c in cards})
    grid = [sorted((c for c in cards if round(c.top / 91440) == r), key=lambda c: c.left) for r in rows]
    circles = [sh for sh in slide.shapes if sh.has_text_frame and sh.text_frame.text.strip() == "photo"]
    pairs = {c.shape_id: next((o for o in circles if c.left <= o.left + o.width / 2 <= c.left + c.width
                                and c.top <= o.top <= c.top + c.height), None) for c in cards}
    circle_of = lambda card: pairs.get(card.shape_id)
    k = spec.get("_k")
    if not 1 <= len(people) <= sum(len(r) for r in grid):
        PROBLEMS.append(f"slide {k}: the team layout holds 1-{sum(len(r) for r in grid)} people; give "
                        f"\"people\": [[\"Name\", \"Role\"], ...] (got {len(people)})")
        return
    per = len(grid[0])
    use = [people[:per], people[per:]] if len(people) > per else [people]
    if len(use) == 1 and len(grid) > 1:              # one row: centred on the slide, between headline and footer
        top, bottom = grid[0][0].top, grid[-1][0].top + grid[-1][0].height
        dy = (top + bottom) // 2 - (grid[0][0].top + grid[0][0].height // 2)
    else:
        dy = 0
    span = lambda row: (row[0].left, row[-1].left + row[-1].width)
    left0, right0 = span(grid[0])
    for r, row in enumerate(grid):
        who = use[r] if r < len(use) else []
        for c, card in enumerate(row):
            circ = circle_of(card)
            if c >= len(who):
                for sh in (card, circ):
                    if sh is not None:
                        sh._element.getparent().remove(sh._element)
                continue
            name, role = who[c]
            set_text(card.text_frame, f"{nodot(name)}\n{nodot(role)}" if role else nodot(name))
            if circ is not None:
                set_text(circ.text_frame, initials(name))
                from pptx.util import Pt
                for r_ in circ.text_frame.paragraphs[0].runs:   # initials read as a monogram, not a caption
                    r_.font.size = Pt(20)
        if 0 < len(who) < len(row):                    # a short row sits in the middle, spacing unchanged
            kept = row[:len(who)]
            dx = ((left0 + right0) - (kept[0].left + kept[-1].left + kept[-1].width)) // 2
        else:
            dx = 0
        if dx or dy:
            for card in row[:len(who)]:
                circ = circle_of(card)
                for sh in (card, circ):
                    if sh is not None:
                        sh.left, sh.top = sh.left + dx, sh.top + dy
    if len(people) < sum(len(r) for r in grid):
        TRIMMED.append(k)


def icon_label_room(slide, sh, sample):
    """Characters a centred label can take before it runs into the icon the template placed on its left, given the
    template's sample text (its leading spaces are kept in front of the label). None: no icon beside it."""
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    pics = [p for p in slide.shapes if p.shape_type == MSO_SHAPE_TYPE.PICTURE and p.width < 914400
            and sh.left <= p.left and p.left + p.width <= sh.left + sh.width and sh.top <= p.top < sh.top + 914400]
    centre = sh.left + sh.width / 2
    pics = [p for p in pics if p.left + p.width <= centre]
    if not pics:
        return None
    first = next((r.font.size.pt for r in sh.text_frame.paragraphs[0].runs if r.font.size), None)
    em = (first or 18) / 72 * 914400                            # EMU per em at the label's size (first line)
    pad = len(re.match(r"[ \u00a0]*", sample).group(0)) * 0.25 * em      # Circular's space is about a quarter em
    icon_right = max(p.left + p.width for p in pics)
    room = pad + 2 * (centre - icon_right - 0.04 * 914400)      # label start = centre + (pad - label) / 2 >= icon
    return max(0, int(room / (0.55 * em)))                       # average Circular advance: 0.55 em


def column_style(table_shape, ri, ci):
    """For an empty template cell (no run to copy): its column header's text style in regular weight, when that header
    is dark text - an empty timetable then reads in one size and colour. None: keep the cell's own format."""
    A_ = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    cell = table_shape.table.cell(ri, ci)
    if ri == 0 or any((t.text or "").strip() for t in cell._tc.iter(f"{A_}t")):
        return None
    run = table_shape.table.cell(0, ci)._tc.find(f".//{A_}r")
    head = run.find(f"{A_}rPr") if run is not None else None
    if head is None:
        return None
    fill = head.find(f"{A_}solidFill")
    colour = fill[0].get("val", "") if fill is not None and len(fill) else ""
    if colour.upper() in ("", "FFFFFF", "BG1", "LT1"):
        return None
    rpr = copy.deepcopy(head)
    rpr.attrib.pop("b", None)
    ppr = run.getparent().find(f"{A_}pPr")
    return (copy.deepcopy(ppr) if ppr is not None else None, rpr)


def keep_off_photos(slide):
    """A title beside a photo (the collage cover, the make-up divider) wraps before the photo's edge: its paragraphs get
    a right margin that ends 0.15 in short of the photo, so long titles never run onto the pictures."""
    pics = [sh for sh in slide.shapes if etree.QName(sh._element).localname == "pic" and (sh.width or 0) > 3 * 914400]
    for sh in slide.shapes:
        if not sh.has_text_frame or not sh.text_frame.text.strip() or "|" in sh.text_frame.text:
            continue
        for pic in pics:
            if sh.left < pic.left < sh.left + sh.width and pic.top < sh.top + sh.height and sh.top < pic.top + pic.height:
                margin = sh.left + sh.width - pic.left + int(0.15 * 914400)
                for para in sh.text_frame.paragraphs:
                    para._p.get_or_add_pPr().set("marR", str(margin))


def fill(slide, spec):
    head0, slots0 = headline_shape(slide), text_slots(slide)   # before any text changes: detection uses the sample text
    padded = {sh.shape_id: sh for sh in slide.shapes if sh.has_text_frame          # labels spaced clear of an icon
              and re.match(r"[ \u00a0]{2,}\S", sh.text_frame.text) and len(sh.text_frame.text.strip().splitlines()) <= 2}
    padded0 = {k: v.text_frame.text for k, v in padded.items()}
    if LAYOUTS and spec.get("source") == FT.names().get("team") and spec.get("people") is not None:
        team_fill(slide, spec)
    for k in ("headline", "title"):
        if spec.get(k):
            spec[k] = nodot(spec[k])
    if spec.get("table") is not None:
        spec["table"] = nodot_cells(spec["table"])
    if spec.get("steps"):
        spec["steps"] = [dict(s, label=nodot(s.get("label", "")), text=nodot(s.get("text", ""))) for s in spec["steps"]]
    if BRAND.name == "ulta" and spec.get("source") == 9 and isinstance(spec.get("table"), list) and len(spec["table"]) > 1:
        row = spec["table"][1] or []
        words = [v.split("\n")[0] for v in row if isinstance(v, str) and v.strip() and not BIG_NUMBER.match(v.split("\n")[0].strip())]
        if words:
            PROBLEMS.append(f"slide {spec.get('_k')}: slide 9 is for big numbers (78%, $1.2M, 4 of 6); '{words[0][:30]}' is "
                            "words - give a number per card, or use slide 7 (three text cards)")
        bare = [v.strip() for v in row if isinstance(v, str) and v.strip() and "\n" not in v.strip()]
        if bare:
            PROBLEMS.append(f"slide {spec.get('_k')}: '{bare[0][:12]}' has no label - a big number alone leaves the card "
                            "empty: write \"74%\\ntoken savings per deck\" (number, new line, 3-6 word label)")
    if BRAND.name == "ulta" and spec.get("source") == 7 and isinstance(spec.get("table"), list):
        for row in spec["table"][1:]:                  # cards read as a set: one long card shrinks and breaks the rhythm
            for v in row or []:
                if isinstance(v, str) and v.strip():
                    head, _, body = v.partition("\n")
                    if len(head.split()) > 5 or len(body.split()) > 20:
                        PROBLEMS.append(f"slide {spec.get('_k')}: card '{head[:30]}' is too long for a card "
                                        f"({len(head.split())} + {len(body.split())} words; keep 5 + 20) - shorten it so all cards keep one size")
    if FLOW and spec.get("source") == FLOW and spec.get("steps"):
        layout_flow(slide, spec["steps"])
    if spec.get("headline") is not None:
        h = head0
        if h is None:
            print(f"warning: source {spec['source']} has no headline slot; headline ignored")
        else:
            set_text(h.text_frame, spec["headline"])
    divider_num = [sh for sh in slide.shapes if sh.has_text_frame and re.fullmatch(r"\d{1,2}", sh.text_frame.text.strip())]
    if BRAND.name == "ulta" and spec.get("source") == 5 and spec.get("title") is not None and divider_num:
        # divider: the big faded numeral is the section number, the title line is the other text box
        DIVIDERS.append(spec.get("_k"))
        set_text(divider_num[0].text_frame, str(spec.get("number") or len(DIVIDERS)))
        line = next((sh for sh in slide.shapes if sh.has_text_frame and sh.text_frame.text.strip() and sh not in divider_num), None)
        if line is not None:
            set_text(line.text_frame, spec["title"])
        if len(str(spec["title"]).split()) > 4:
            PROBLEMS.append(f"slide {spec.get('_k')}: divider title '{str(spec['title'])[:30]}' - keep a section name to 1-4 words")
        spec = dict(spec, title=None)
    if spec.get("source") in NEW_DIVIDERS and len(str(spec.get("title") or "").split()) > 4:
        PROBLEMS.append(f"slide {spec.get('_k')}: divider title '{str(spec['title'])[:30]}' - keep a section name to 1-4 words")
    if spec.get("title") is not None or spec.get("subtitle") is not None:     # any brand's cover: biggest text = title
        cands = sorted((sh for sh in slide.shapes if sh.has_text_frame and sh.text_frame.text.strip()
                        and "|" not in sh.text_frame.text and not (sh.is_placeholder and "SLIDE_NUMBER" in str(sh.placeholder_format.type))),
                       key=lambda sh: -(sh.width or 0) * (sh.height or 0))
        if spec.get("subtitle") and len(cands) < 2:      # this cover has one text box: the subtitle is not lost silently
            spec["notes"] = "\n".join(x for x in (f"Subtitle: {spec['subtitle']}", spec.get("notes")) if x)
            print(f"warning: slide {spec.get('_k')}: this cover has no subtitle box - '{str(spec['subtitle'])[:40]}' went to the "
                  "speaker notes; put what matters into the title (55 characters)")
        for n_, (val, sh) in enumerate(zip((spec.get("title"), spec.get("subtitle")), cands)):
            if val is not None:
                set_text(sh.text_frame, val)
                if n_ == 0 and sh.is_placeholder:                # the cover title: at most two lines
                    fit_lines(sh, explicit_or_inherited(sh))
    if spec.get("table") is not None:                  # short key: the slide's first table
        tshape = next((sh for sh in slide.shapes if sh.has_table), None)
        if tshape is None:                             # nothing the user gave is dropped quietly
            PROBLEMS.append(f"slide {spec.get('_k')}: this layout has no table, so the \"table\" content has nowhere to go - "
                            f"use the layout's own slots (build_deck.py inventory {spec['source']}) or a layout with a table")
        else:
            spec.setdefault("slots", {})[next(k for k, v in slot_map(slide).items() if v.shape_id == tshape.shape_id)] = spec["table"]
    if spec.get("text") is not None:                   # short key: text slots in reading order
        slots_ = slots0
        vals = spec["text"] if isinstance(spec["text"], list) else [spec["text"]]
        if len(vals) > len(slots_):                    # nothing the user gave is dropped quietly
            PROBLEMS.append(f"slide {spec.get('_k')}: {len(vals) - len(slots_)} of {len(vals)} \"text\" values have no box on this "
                            f"layout ({len(slots_)} text box(es)) - use its own format (build_deck.py inventory {spec['source']}; "
                            "agendas take \"table\": [[null, \"item\"], ...]) or a layout with more boxes")
        for sh, v in zip(slots_, vals):
            if v is not None:
                set_text(sh.text_frame, str(v))
        for sh in slots_[len(vals):]:                  # unfilled slots must not keep sample text
            set_text(sh.text_frame, "")
        # body text stays at the template's 12 pt standard (typeset.py) - no growing; except a short statement in the
        # two tall boxes: at 12 pt it fills a fifth of the box, so it is set as a statement - the body face at 20 pt
        # (typeset.py "statement" role); the display face stays for the headline only
        if spec.get("source") == BRAND.role("diagram_base", 6) and len(slots_) == 2 and all(
                0 < len(str(v or "").split()) <= SHORT_BOX_WORDS for v in vals[:2]) and len(vals) >= 2:
            for sh in slots_:
                sh.name = f"Highlight {sh.name}"          # typeset.py: statement role (body face, 20 pt)
                sh.text_frame.vertical_anchor = MSO_ANCHOR.MIDDLE   # one statement sits in the middle of its tall box
                for p_ in sh.text_frame.paragraphs:
                    p_.line_spacing = 1.1                  # the box's fixed 12 pt spacing would stack 24 pt lines
        if spec.get("source") in COVERS:                    # the cover title (biggest text): at most two lines
            big = max((sh for sh in slots_ if sh.text_frame.text.strip()), key=lambda sh: (sh.width or 0) * (sh.height or 0), default=None)
            if big is not None:
                fit_lines(big, explicit_or_inherited(big))
        empty = sum(1 for v in vals[:len(slots_)] if v is not None and not str(v).strip()) + max(0, len(slots_) - len(vals))
        if empty and spec.get("source") not in (BRAND.get("allow_empty_boxes") or []):
            PROBLEMS.append(f"slide {spec.get('_k')}: {empty} of {len(slots_)} text boxes left empty - an empty box looks "
                            f"unfinished: give one text per box or pick a layout with {len(slots_) - empty} box(es)")
    shapes = slot_map(slide)
    for name, value in (spec.get("slots") or {}).items():
        sh = shapes.get(name)
        if sh is None:
            PROBLEMS.append(f"slide {spec.get('_k')}: the layout has no slot named {name!r}, so its content has nowhere to go "
                            f"(see: build_deck.py inventory {spec['source']})")
            continue
        if sh.has_table and isinstance(value, dict) and value.get("from"):
            rows = DS.table_rows(value)
            room = len(sh.table.rows) - 1
            if len(rows) > room:
                print(f"warning: {value['from']} has {len(rows)} rows; table {name!r} holds {room}. "
                      f"Rows {room + 1}+ were left out - put them on a second slide")
            value = [None] + rows[:room]
        if sh.has_table and isinstance(value, list):
            value = number_column(sh, value)
            value = fit_repeats(slide, sh, value, spec)
            if numeric_cols(sh) == [0] and 0 < len(value) < len(sh.table.rows):   # shorter list: drop unused rows
                trs = sh._element.findall(".//{http://schemas.openxmlformats.org/drawingml/2006/main}tr")
                for tr in trs[len(value):]:
                    tr.getparent().remove(tr)
                print(f"note: list shortened to {len(value)} item(s)")
                spec["_list_shortened"] = True
        if sh.has_table:
            if FLOW and spec["source"] == FLOW and value:
                n = len(value[0] or [])
                if n == 4:
                    align_flow_table(slide, sh, 4)
                else:
                    print(f"warning: slide 20 has 4 step boxes; {n} labels cannot line up with them - give exactly 4 labels")
            row_labels = LAYOUTS and {v_: k_ for k_, v_ in FT.names().items()}.get(spec.get("source")) == "four-pillars"
            for ri, row in enumerate(value or []):
                for ci, v in enumerate(row or []):
                    if v is None and row_labels and ci == 0 and 0 < ri < len(sh.table.rows):
                        v = ""                         # no row label given: not the template's sample 'Category' / 'Insights'
                    if v is None:
                        continue
                    if ri < len(sh.table.rows) and ci < len(sh.table.columns):
                        set_text(sh.table.cell(ri, ci).text_frame, str(v), column_style(sh, ri, ci))
                    else:
                        print(f"warning: {name} has no cell r{ri + 1}c{ci + 1}; ignored (never add rows/columns)")
        elif sh.has_text_frame:
            set_text(sh.text_frame, str(value))
    if BRAND.name == "ulta" and spec.get("source") == 9:          # number + label sit in the middle of the card
        tshape = next((sh for sh in slide.shapes if sh.has_table), None)
        if tshape is not None and len(tshape.table.rows) > 1:
            for c in tshape.table.rows[1].cells:
                c.vertical_anchor = MSO_ANCHOR.MIDDLE
    if LAYOUTS and spec.get("source", 0) > 33 and spec.get("source") in DISPLAY:
        keep_off_photos(slide)
    for sid, sh in padded.items():                    # a label beside a template icon: it must clear the icon
        new = sh.text_frame.text.strip().splitlines()
        if not new or sh.text_frame.text == padded0[sid]:
            continue
        room = icon_label_room(slide, sh, padded0[sid])
        if room is not None and len(new[0].strip()) > room:
            PROBLEMS.append(f"slide {spec.get('_k')}: '{new[0].strip()[:30]}' is too long for the label beside its icon "
                            f"(about {room} characters fit) - shorten it")
    if spec.get("notes"):
        slide.notes_slide.notes_text_frame.text = spec["notes"]


KIT = ROOT / "modules" / "ultabranddeliverables" / "scripts" / "ulta.py"
DIAGRAM_SOURCE = BRAND.role("diagram_base", 6)        # template slide the kit draws diagram slides on (same layout); used as their mapping
FAMILIES = {"timeline": "timelines", "swimlane": "swimlanes", "process": "flows", "retail": "retail"}
                                                       # {"timeline": {...}, "style": "..."} -> tools/timelines.py


def modern_to_family(spec):
    """The plain modern 'swimlane' chart is the swimlane family's 'lanes' style (same data: lanes + steps), drawn
    by tools/swimlanes.py - routed, grouped, glued - so the two never look different."""
    if isinstance(spec, dict) and spec.get("modern") == "swimlane" and spec.get("swimlane") is None:
        data = {k: v for k, v in spec.items() if k in ("lanes", "steps", "phases", "systems", "sipoc")}
        rest = {k: v for k, v in spec.items() if k not in data and k != "modern"}
        return dict(rest, swimlane=data, style=spec.get("style") or "lanes")
    return spec


def family_of(spec):
    """'timeline' / 'swimlane' / 'process' / 'retail' when the slide is one of those families (drawn natively or a
    template slide filled)."""
    return next((k for k in FAMILIES if isinstance(spec, dict) and spec.get(k) is not None), None)


def family_module(fam):
    import importlib
    return importlib.import_module(FAMILIES[fam])


def no_theme_effects(out, ks):
    """Drawn slides: every shape and line gets an explicit empty effect list and no theme effect style, so neither
    PowerPoint nor LibreOffice (ChatGPT's previews) draws the theme's drop shadow under a diagram box, a chart line or a
    connector."""
    if not ks:
        return 0
    import a11y as _A
    A_, P_ = "{http://schemas.openxmlformats.org/drawingml/2006/main}", "{http://schemas.openxmlformats.org/presentationml/2006/main}"
    z = zipfile.ZipFile(out)
    items = {n: z.read(n) for n in z.namelist()}
    infos = {n: z.getinfo(n) for n in z.namelist()}
    parts = _A.slide_parts(z)
    z.close()
    n = 0
    for k in ks:
        if k > len(parts):
            continue
        x = etree.fromstring(items[parts[k - 1]])
        for el in x.iter(P_ + "sp", P_ + "cxnSp"):
            st = el.find(P_ + "style")
            sp = el.find(P_ + "spPr")
            if st is None or sp is None or sp.find(A_ + "effectDag") is not None:
                continue
            ref = st.find(A_ + "effectRef")
            if ref is None or ref.get("idx") == "0":
                continue
            own = sp.find(A_ + "effectLst")
            if own is not None and len(own):               # the shape's own effects stay
                continue
            if own is None:
                eff = etree.Element(A_ + "effectLst")
                nxt = next((sp.find(A_ + t_) for t_ in ("scene3d", "sp3d", "extLst") if sp.find(A_ + t_) is not None), None)
                if nxt is not None:
                    nxt.addprevious(eff)
                else:
                    sp.append(eff)
            ref.set("idx", "0")                            # LibreOffice (ChatGPT's previews) ignores the empty list alone
            n += 1
        items[parts[k - 1]] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
    import atomic
    with atomic.zip_out(out) as w:
        for name_, d in items.items():
            w.writestr(infos[name_], d)
    return n


def finish_before_validate(out, story):
    """Enterprise steps on every built or edited deck: accessibility fixes and the classification label."""
    import a11y, compliance
    print(f"a11y: {a11y.fix(out, BRAND)} object(s) given alt text / decorative flag / header row")
    level = (story or {}).get("classification")
    if level:
        for n in compliance.classify(out, level):
            print(n)


def sidecar(out):
    return Path(str(out) + ".ulta.json")


POINT_GRAPHICS = {"funnel": (3, 6), "pyramid": (3, 6), "stairs": (3, 6), "milestones": (3, 8), "quadrant": (4, 4),
                  "venn": (2, 3), "target": (3, 5), "honeycomb": (3, 7)}
GRAPHICS = ("funnel", "pyramid", "stairs", "milestones", "quadrant", "venn", "target", "honeycomb", "cycle", "timeline",
            "matrix", "roadmap")
_graphic_decks = []


def draw_graphic(spec, work, k):
    """The slow part of a graphic slide (kit drawing, recolour, native shapes), safe to run in a worker thread.
    Returns (pptx path or None, messages, error)."""
    kind, msgs = spec["graphic"], []
    if kind not in GRAPHICS:
        return None, msgs, f"graphic slide {k}: unknown graphic {kind!r}; use one of {', '.join(GRAPHICS)}"
    items = spec.get("items") or []
    if kind in POINT_GRAPHICS:                       # the diagram engine draws these from points (the deck path made tables)
        nodes = []
        for i, it in enumerate(items):
            lab, _, sub = str(it).partition(":")
            nodes.append({"id": f"p{i}", "label": lab.strip(), "sub": sub.strip()})
        src = work / f"graphic{k}.json"
        src.write_text(json.dumps({"title": spec.get("headline") or kind.title(), "nodes": nodes, "flows": []}), encoding="utf-8")
        base = work / f"graphic{k}"
        r = subprocess.run([sys.executable, "-I", str(KIT), "diagram", str(src), "--style", kind,
                            "--title", spec.get("headline") or kind.title(), "--out", str(base)]
                           + (["--room", "72"] if spec.get("decision") else []), capture_output=True, text=True)
        m = re.search(r"style (\w+) · ", r.stdout)
        if not Path(f"{base}.pptx").exists():
            return None, msgs, f"graphic slide {k}: the engine drew nothing ({(r.stdout + r.stderr).strip()[-200:]})"
        if not m or m.group(1) != kind:
            rng = POINT_GRAPHICS[kind]
            return None, msgs, (f"graphic slide {k}: a {kind} needs {rng[0]}-{rng[1]} points (got {len(items)}) - "
                                f"it would be drawn as {m.group(1) if m else 'something else'}; change the points or the graphic")
        subprocess.run([sys.executable, str(TOOLS / "ulta_conform.py"), f"{base}.pptx"], capture_output=True, text=True)
        subprocess.run([sys.executable, str(TOOLS / "nativize.py"), f"{base}.pptx"], capture_output=True, text=True)
        msgs.append(f"  graphic: {len(items)} points drawn as a {kind}")
        return Path(f"{base}.pptx"), msgs, None
    md = work / f"graphic{k}.md"
    md.write_text(f"# Graphic\n\n## {spec.get('headline') or kind.title()}\nLayout: {kind}\n"
                  + "\n".join(f"- {it}" for it in items) + "\n", encoding="utf-8")
    base = work / f"graphic{k}.pptx"
    r = subprocess.run([sys.executable, "-I", str(KIT), "deck", str(md), "--out", str(base)], capture_output=True, text=True)
    msgs += ["  " + line.strip() for line in r.stdout.splitlines() if "drawn as" in line or line.startswith("warning")]
    if not base.exists():
        return None, msgs, f"graphic slide {k}: the kit drew nothing ({(r.stdout + r.stderr).strip()[-200:]})"
    if "drawn as" not in r.stdout:                   # the kit kept a plain table: never ship that under a graphic's name
        return None, msgs, (f"graphic slide {k}: '{kind}' was not drawn (the points became a plain table) - "
                            "check the number of points for this graphic or choose another one")
    subprocess.run([sys.executable, str(TOOLS / "ulta_conform.py"), str(base)], capture_output=True, text=True)
    subprocess.run([sys.executable, str(TOOLS / "nativize.py"), str(base)], capture_output=True, text=True)
    return base, msgs, None


def make_graphic(spec, work, k, pre=None):
    """A point graphic (funnel, pyramid ...) drawn by the kit, recoloured, made native; returns the slide to import."""
    base, msgs, err = pre or draw_graphic(spec, work, k)
    for m in msgs:
        print(m)
    if err:
        raise SystemExit(err)
    d = Presentation(str(base))
    _graphic_decks.append(d)                         # keep it open while its slide is copied
    return d.slides[1] if len(d.slides) > 2 else d.slides[0]     # [cover, graphic, closing]


def draw_diagram(spec, work, k):
    """The slow part of a diagram slide (engine, recolour, native shapes), safe to run in a worker thread.
    Returns (base path, messages, problems, error)."""
    flows, msgs = spec["diagram"], []
    if isinstance(flows, dict):                       # arch JSON: {"nodes":[{id,label,sub}], "flows":[{source,target,label}]}
        src = work / f"flows{k}.json"
        src.write_text(json.dumps(flows), encoding="utf-8")
    else:
        flows_txt = flows if isinstance(flows, str) else "\n".join(flows)
        src = work / f"flows{k}.txt"
        src.write_text(flows_txt, encoding="utf-8")
    base = work / f"diagram{k}"
    cmd = [sys.executable, "-I", str(KIT), "diagram", str(src), "--style", spec.get("style", "auto"),
           "--title", spec.get("headline") or "Architecture", "--out", str(base)] + (["--room", "72"] if spec.get("decision") else [])
    r = subprocess.run(cmd, capture_output=True, text=True)
    msgs.append("  diagram: " + (r.stdout.strip().splitlines() or [r.stderr.strip()[-300:]])[0])
    if not Path(f"{base}.pptx").exists():
        return base, msgs, [], (f"diagram slide {k}: the diagram engine drew nothing ({(r.stdout + r.stderr).strip()[-200:]}). "
                                "Write one flow per line as 'A → B: what' - no brackets in names")
    msgs += ["  " + line.strip() for line in r.stdout.splitlines() if "drawn as" in line or "warning" in line.lower()]
    from ulta_text import cut_problems
    probs = [x[5:] for x in cut_problems(r.stderr, f"slide {k} diagram: ")]
    m = re.search(r"style ([a-z, ]+?) · \d+ systems", r.stdout)
    spec["_drawn_style"] = (m.group(1).strip() if m else spec.get("style", "auto"))
    for line in r.stdout.splitlines():                # a style that does not fit is drawn as another: never a silent swap
        mm = re.search(r'style "(\w+)" needs (.+?) [\u2014-] drawn as (\w+)', line)
        if mm:
            probs.append(f"slide {k}: style '{mm.group(1)}' needs {mm.group(2)}; these flows do not have that shape, so it "
                         f"would be drawn as '{mm.group(3)}' (a different picture under the wrong name) - give flows of that "
                         f"shape (`build_deck.py styles` has one example per style) or choose another style")
    c = subprocess.run([sys.executable, str(TOOLS / "ulta_conform.py"), f"{base}.pptx", f"{base}.svg"],   # the .drawio keeps the diagram standard's state colours
                       capture_output=True, text=True)
    msgs.append("  " + (c.stdout.strip().splitlines() or ["conform: no output"])[-1])
    n = subprocess.run([sys.executable, str(TOOLS / "nativize.py"), f"{base}.pptx"], capture_output=True, text=True)
    msgs.append("  " + (n.stdout.strip().splitlines() or ["nativize: no output"])[-1])
    return base, msgs, probs, None


def make_diagram(spec, work, k, pre=None):
    """Draw an architecture slide with the kit's diagram engine, recolour it to the Ulta palette."""
    base, msgs, probs, err = pre or draw_diagram(spec, work, k)
    for m in msgs:
        print(m)
    PROBLEMS.extend(probs)
    if err:
        raise SystemExit(err)
    return base


def predraw(slides, work):
    """Draw every diagram and graphic slide up front, four at a time: they are separate programs, so a 20-diagram
    deck takes about a quarter of the time. Results are used in slide order, so messages stay in order."""
    from concurrent.futures import ThreadPoolExecutor
    jobs = [(k, s) for k, s in enumerate(slides, 1) if s.get("diagram") or s.get("graphic")]
    if len(jobs) < 2:
        return {}
    with ThreadPoolExecutor(max_workers=min(4, os.cpu_count() or 2)) as ex:
        fut = {k: ex.submit(draw_diagram if s.get("diagram") else draw_graphic, s, work, k) for k, s in jobs}
        return {k: f.result() for k, f in fut.items()}


SUMMARY_WORDS = 24                                     # the takeaway line: one crisp sentence (about 15 words fit one line)
SUMMARY_PT, SUMMARY_TOP, LINE_IN = 16, 0.58, 0.27      # 16 pt grey body type; its top 0.58 in below the headline box's top
HEAD_LINE_EM = 1.27     # v6.37.1 a headline line in PowerPoint: the display face's line (Playfair: 1.41 em) at the template's 90% spacing
HEAD_GAP_IN = 0.03      # air between the headline's descenders and the takeaway line (whose text box has no inset)
CLEAR_IN = 0.08                                        # the air it keeps from the content (nearer its headline than the content)
DECISION_WORDS, DECISION_PT = 24, 14                   # the decision bar: one sentence above the footer
DECISION_TOP, DECISION_H = 5.93, 0.44                  # clear of the logo and footer (the template's content ends at 6.4 in)
DECISION_ROOM = int(0.6 * 914400)                      # what a drawn slide leaves free for it (the bar and its air)
NUM = re.compile(r"\d+(?:[.,]\d+)*")


def _filled(sh):
    sp = sh._element.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}spPr")
    a = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    return sp is not None and any(sp.find(a + k) is not None for k in ("solidFill", "gradFill", "blipFill", "pattFill"))


def _clear_band(slide, top, bottom, head):
    """True when nothing a reader sees - any shape but the headline, the slide number, the footer chrome and empty
    unfilled boxes - reaches into the band between top and bottom (EMU)."""
    for sh in slide.shapes:
        if sh.top is None or sh.height is None or (head is not None and sh._element is head._element):
            continue
        if sh.is_placeholder and any(x in str(sh.placeholder_format.type) for x in ("SLIDE_NUMBER", "FOOTER", "DATE")):
            continue
        if sh.has_text_frame and not sh.text_frame.text.strip() and not _filled(sh):
            continue
        if sh.top < bottom and sh.top + sh.height > top:
            return False
    return True


def _headline_of(slide, spec):
    """The slide's headline once filled: its text is the storyboard's headline (the sample text that marks the template's
    headline is gone by then); else the display-face text at the top of the slide."""
    h = headline_shape(slide)
    if h is not None:
        return h
    key = lambda s: re.sub(r"[^a-z0-9]", "", str(s).lower())
    want = key(spec.get("headline") or "")
    top = [s for s in slide.shapes if s.has_text_frame and s.top is not None and s.top < int(1.6 * 914400)
           and s.text_frame.text.strip()]
    hit = next((s for s in top if want and key(s.text_frame.text) == want), None)
    if hit is None:
        disp = BRAND.font("heading")
        hit = next((s for s in top if any((r.font.name or "") in (disp, "Playfair Display Black") for p_ in s.text_frame.paragraphs
                                          for r in p_.runs)), None)
    return hit


def _new_numbers(text, spec):
    """Numbers in a summary or decision that the slide and its notes do not hold (1-10 may count what the slide shows)."""
    pool = json.dumps({k: v for k, v in spec.items() if k not in ("summary", "decision") and not str(k).startswith("_")},
                      ensure_ascii=False)
    have = {n.replace(",", "") for n in NUM.findall(pool)}
    return [m.group(0) for m in re.finditer(r"\$?(\d+(?:[.,]\d+)*)(?:%|[KMB]\b)?", text)          # as written: $60M, 37%
            if m.group(1).replace(",", "") not in have and not (m.group(1).isdigit() and int(m.group(1)) <= 10)]


def _from_file(o):
    """True when a slide spec reads its content from a file (\"data\": \"/mnt/data/plan.xlsx\", \"from\": \"list.csv\")."""
    if isinstance(o, dict):
        return any((k in ("data", "from") and isinstance(v, str) and v.strip()) or _from_file(v) for k, v in o.items())
    return isinstance(o, list) and any(_from_file(v) for v in o)


def summary_layer(slide, spec, k, W):
    """The slide's crisp summary where a reader looks next - "summary": the takeaway line under the headline; "decision":
    one sentence in a light bar above the footer. Each goes on the slide only where its layout has clear space (a drawn
    slide always has it), else it stays in the speaker notes with a note; both also open the notes. Template type and
    colours only, nothing shrinks to fit; a line too long for its room, or a number the slide does not hold, FAILs."""
    import modern_charts as MC
    IN = 914400
    summ = " ".join(str(spec.get("summary") or "").split())
    dec = " ".join(str(spec.get("decision") or "").split())
    src = spec.get("source")
    head = _headline_of(slide, spec)
    content = not (spec.get("library") or src in COVERS or src in DISPLAY or head is None)
    computed = bool(spec.get("chart") or spec.get("modern") or spec.get("table") and not src or _from_file(spec))
    # (chart takeaways compute from the data; a slide fed from a file holds numbers the storyboard does not)
    said = []
    for what, txt, limit in (("summary", summ, SUMMARY_WORDS), ("decision", dec, DECISION_WORDS)):
        if not txt:
            continue
        if len(txt.split()) > limit:
            PROBLEMS.append(f"slide {k}: {what} is {len(txt.split())} words - one crisp sentence, {limit} words at most")
        if not computed:
            extra = _new_numbers(txt, spec)
            if extra:
                PROBLEMS.append(f"slide {k}: the {what} says {', '.join(extra[:3])}, which the slide and its notes do not - "
                                "use the slide's own numbers (no new facts)")
    if summ:
        said.append(f"Takeaway: {summ}")
        if not content:
            ADVICE.append(f"slide {k}: {'an approved library slide stays as approved' if spec.get('library') else 'this slide takes no summary line'} - the summary is in the speaker notes")
        else:
            ml, mr = Emu_(head.text_frame.margin_left), Emu_(head.text_frame.margin_right)
            x0, w = head.left + ml, W - 2 * head.left - ml - mr    # the content width (a template headline box may be narrower)
            em = (_B.width_of(summ, MC.BODY, _B.metrics_for(BRAND)) or 0.55 * len(summ)) * SUMMARY_PT * 12700
            lines = 1 if em <= 0.97 * w else 2 if em <= 1.94 * w else 3
            top = head.top + int(SUMMARY_TOP * IN)   # ULTA SlideGlam: v141's place (see dev/build_skill.py, 1g)
            low = lambda n_: top + int((n_ * LINE_IN + CLEAR_IN) * IN)
            if lines > 2:
                PROBLEMS.append(f"slide {k}: the summary takes {lines} lines - keep it to one (about {int(0.97 * w / em * len(summ))} characters)")
            elif _clear_band(slide, top, low(lines), head):
                tb = MC.text(slide, x0, top, w, int(lines * LINE_IN * IN) + int(0.04 * IN), summ, SUMMARY_PT, MC.MUTED, MC.BODY,
                             name="ULTA summary")
                head._element.addnext(tb._element)          # read right after the headline
            elif lines == 2 and _clear_band(slide, top, low(1), head):
                PROBLEMS.append(f"slide {k}: the summary needs two lines; this layout has room for one (about "
                                f"{int(0.97 * w / em * len(summ))} characters) - shorten it")
            else:
                ADVICE.append(f"slide {k}: no room under the headline on this layout - the summary is in the speaker notes")
    if dec:
        lead, body = split_lead(dec)
        said.append(f"{lead or 'Decision'}: {body}")
        if not content:
            ADVICE.append(f"slide {k}: this slide takes no decision bar - it is in the speaker notes")
        else:
            top, h = int(DECISION_TOP * IN), int(DECISION_H * IN)
            if _clear_band(slide, top - int(CLEAR_IN * IN), top + h, head):
                x0, x1 = _content_span(slide, head, top, W)
                decision_bar(slide, x0, top, x1 - x0, h, lead or "Decision", body)
            else:
                ADVICE.append(f"slide {k}: no room for the decision bar above the footer on this layout - it is in the speaker notes")
    if said:
        tf = slide.notes_slide.notes_text_frame
        own = re.sub(r"^\s*(takeaway|summary|key message)\s*:\s*", "", tf.text, flags=re.I) if summ else tf.text   # v6.37.1 "Takeaway:" once
        tf.text = "\n".join(said + ([own] if own.strip() else []))


def split_lead(text):
    """'Next step: ...' -> ('Next step', '...'): a 1-3 word lead before a colon names the bar; else ('', text). The body
    starts with a capital (not a word like eCommerce that keeps its own)."""
    m = re.match(r"\s*([^:]{2,24}):\s+(\S.*)$", text)
    lead, body = (m.group(1).strip(), m.group(2).strip()) if m and len(m.group(1).split()) <= 3 else ("", text.strip())
    w = body.split(" ")[0] if body else ""
    if w[:1].islower() and w[1:] == w[1:].lower():
        body = body[0].upper() + body[1:]
    return lead, body


def _content_span(slide, head, bottom, W):
    """Left and right edges of what the slide shows between its headline and `bottom` (a template table or cards may sit
    inside the headline's margins): the decision bar lines up with it. Else the headline's margins."""
    IN = 914400
    xs = [(sh.left, sh.left + sh.width) for sh in slide.shapes
          if sh.left is not None and sh.width and sh.top is not None and sh._element is not head._element
          and sh.name not in ("ULTA summary", "ULTA decision") and sh.top >= head.top + int(0.5 * IN)
          and sh.top + sh.height <= bottom and not (sh.is_placeholder and any(x in str(sh.placeholder_format.type)
                                                                               for x in ("SLIDE_NUMBER", "FOOTER", "DATE")))
          and not (sh.has_text_frame and not sh.text_frame.text.strip() and not _filled(sh))]
    lo, hi = head.left, W - head.left
    if xs:
        a, b = min(x for x, _ in xs), max(x for _, x in xs)
        if b - a >= 0.6 * (hi - lo) and a >= lo - int(0.3 * IN) and b <= hi + int(0.3 * IN):
            return a, b
    return lo, hi


def decision_bar(slide, x, y, w, h, lead, body):
    """One sentence in a light template tint with its lead in plum: flat, editable, read last."""
    import modern_charts as MC
    from pptx.util import Pt
    from pptx.dml.color import RGBColor
    from pptx.enum.text import MSO_ANCHOR
    bar = MC.rect(slide, x, y, w, h, "FFE8EE", radius=int(0.08 * 914400), name="ULTA decision")
    tf = bar.text_frame
    tf.margin_left = tf.margin_right = int(0.18 * 914400)
    tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor, tf.word_wrap = MSO_ANCHOR.MIDDLE, True
    p = tf.paragraphs[0]
    for txt, font, colour in ((lead + "  ", MC.BOLD, "5D0F43"), (body, MC.BODY, MC.MUTED)):
        r = p.add_run()
        r.text = txt
        r.font.size, r.font.name, r.font.bold = Pt(DECISION_PT), font, font == MC.BOLD
        r.font.color.rgb = RGBColor.from_string(colour)
    return bar


def make_chart_slide(prs, base, spec):
    """The brand's title-only slide: headline (full width, fitted to one line), the takeaway line when given, and a
    native chart or table below it."""
    new, box = title_only_slide(prs, base, spec.get("headline") or (spec.get("chart") or {}).get("title") or "",
                                room=DECISION_ROOM if spec.get("decision") else 0)
    notes = spec.get("notes")
    if spec.get("chart"):
        DS.add_chart(new, spec["chart"], box, BRAND)
    elif spec.get("bullets") is not None or spec.get("picture"):
        x, y, w, h = box
        if spec.get("bullets") and spec.get("picture"):            # text left, picture right
            gap = int(0.3 * 914400); tw = int(w * 0.55)
            tbox, pbox = (x, y, tw, h), (x + tw + gap, y, w - tw - gap, h)
        else:
            tbox = pbox = box
        if spec.get("picture"):
            DS.add_picture(new, spec["picture"], pbox, spec.get("alt") or spec.get("headline") or "")
        import modern_charts as MC
        pts = None if spec.get("picture") or spec.get("plain") else MC.as_points(spec.get("bullets"))
        if pts:                                            # 2-6 points: tiles, not a text slide (spec "plain": true keeps a list)
            M = _B.metrics_for(BRAND)
            measure = lambda t, f: _B.width_of(t, f, M) or len(t) * 0.55
            for pr in MC.points(new, box, pts, measure, numbered=spec.get("numbered", True), start=int(spec.get("start") or 1)):
                PROBLEMS.append(f"slide {spec.get('_k')}: {pr}")
            spec["_points"] = True
        elif spec.get("bullets"):
            pt, fits = DS.add_bullets(new, spec["bullets"], tbox, BRAND, _B.metrics_for(BRAND), bool(spec.get("numbered")),
                                     spec.get("start", 1))
            if not fits:
                PROBLEMS.append(f"slide {spec.get('_k')}: {len(spec['bullets'])} bullets do not fit even at 12 pt - "
                                "split the slide or cut the text")
            elif pt < 14:
                print(f"  slide {spec.get('_k')}: bullets set at {pt} pt (dense) - consider splitting")
    else:
        t = spec["table"]
        t = {"rows": t} if isinstance(t, list) else t              # rows written straight in, without {"rows": ...}
        rows = t.get("rows") or ([DS.read_table(t["from"], t.get("sheet"))[0]] + DS.table_rows(t))
        gf = DS.add_table(new, rows, box, BRAND, header=t.get("header", True))
        PROBLEMS.extend(f"slide {spec.get('_k')}: {p}" for p in getattr(gf, "problems", []))
    if notes:
        new.notes_slide.notes_text_frame.text = notes
    return new


def title_only_slide(prs, base, headline, room=0):
    """Copy of the brand's title-only slide with just its headline (fitted) and slide number; returns (slide, box). room:
    EMU left free at the bottom (a decision bar)."""
    from pptx.util import Emu
    new = duplicate(prs, base)
    h = headline_shape(new)
    body = [sh for sh in new.shapes if sh._element is not h._element and sh.top is not None and sh.top > h.top
            and not sh.is_placeholder]
    area = (min(sh.top for sh in body), max(sh.top + sh.height for sh in body)) if body else None   # template content area
    for sh in list(new.shapes):
        keep = sh._element is h._element or (sh.is_placeholder and "SLIDE_NUMBER" in str(sh.placeholder_format.type))
        if not keep:
            sh._element.getparent().remove(sh._element)
    set_text(h.text_frame, headline)
    W, H = prs.slide_width, prs.slide_height
    left, top0, hh = h.left, h.top, h.height          # inherited from the layout: write all four, or PowerPoint gets height 0
    h.left, h.top, h.height = left, top0, hh or Emu(int(1.03 * 914400))
    h.width = W - 2 * left
    fit_one_line(h)
    top = max(area[0] if area else 0, h.top + h.height + Emu(int(0.2 * 914400)))
    bottom = H - Emu(int(1.1 * 914400)) - room        # one frame for every drawn slide, ending where the template's own
                                                       # content does (6.4 in; slide 7's cards end at 6.37): clear of the chrome
    return new, (left, top, W - 2 * left, bottom - top)


def fit_one_line(shape, floor=1600):
    """Shrink a headline 2 pt at a time until it fits one line (bundled/brand font metrics)."""
    from pptx.util import Pt
    M = _B.metrics_for(BRAND)
    font = BRAND.font("heading")
    text = shape.text_frame.text
    runs = [r for p in shape.text_frame.paragraphs for r in p.runs]
    size = next((r.font.size for r in runs if r.font.size), None) or Pt(36)
    inner = shape.width - Emu_(shape.text_frame.margin_left) - Emu_(shape.text_frame.margin_right)
    w = _B.width_of(text, font, M)
    if w is None:
        return
    while w * size > 0.95 * inner and size - Pt(2) >= floor * 127:
        size -= Pt(2)
    for r in runs:
        r.font.size = size


def Emu_(v):
    return int(v if v is not None else 91440)


def plain_headline(slide, spec):
    """A drawn slide's headline set like every other headline: the diagram engine writes its title with 110% line
    spacing and space before, which drops the one line about 0.1 in below where the template's headlines sit - onto the
    takeaway line under it. The paragraph spacing goes; the words, size and font stay."""
    head = _headline_of(slide, spec)
    if head is None:
        return
    A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    for el in list(head.text_frame._txBody.iter(A + "lnSpc", A + "spcBef")):
        el.getparent().remove(el)


def import_slide(prs, src_slide):
    """Copy a slide from another presentation built on the same template: same layout (by name), every shape,
    and every picture re-added under a fresh part name so nothing collides with the template's media."""
    from pptx.opc.package import Part
    layout = next((l for m in prs.slide_masters for l in m.slide_layouts if l.name == src_slide.slide_layout.name),
                  prs.slide_layouts[0])
    new = prs.slides.add_slide(layout)
    tree = new.shapes._spTree
    for el in list(tree):
        tree.remove(el)
    remap = {}
    pkg = new.part.package
    for rid, rel in src_slide.part.rels.items():
        if any(k in rel.reltype for k in SKIP_REL):
            continue
        if rel.is_external:
            remap[rid] = new.part.relate_to(rel.target_ref, rel.reltype, is_external=True); continue
        tp = rel.target_part
        ext = str(tp.partname).rsplit(".", 1)[-1]
        name = pkg.next_partname("/ppt/media/ulta-diagram-%d." + ext)
        remap[rid] = new.part.relate_to(Part(name, tp.content_type, pkg, tp.blob), rel.reltype)
    for el in src_slide.shapes._spTree:
        c = copy.deepcopy(el)
        for node in c.iter():
            for attr in list(node.attrib):
                if attr.startswith("{%s}" % R_NS) and node.attrib[attr] in remap:
                    node.attrib[attr] = remap[node.attrib[attr]]
        tree.append(c)
    return new


def summarize(log, out, verbose=False):
    """The few lines the chat needs (status, problems, files); the full log goes to <deck>_validation/build-log.txt."""
    out = Path(out)
    vd = out.parent / (out.stem + "_validation"); vd.mkdir(parents=True, exist_ok=True)
    (vd / "build-log.txt").write_text(log)
    if verbose:
        print(log); return
    L = log.splitlines()
    overall = next((l.split(":", 1)[1].strip().split(" -")[0] for l in L if l.startswith("OVERALL")), "NOT VALIDATED")
    stamp = next((l.split(":", 1)[1].split("(")[0].strip() for l in L if l.startswith("STAMP")), "")
    extra = sorted(str(p.name) for p in out.parent.glob(out.stem + "-slide*.drawio"))
    held = next((l for l in L if l.startswith("NOT WRITTEN:")), None)
    if held:                                           # nothing to deliver: say so in the status line itself
        print(f"{overall} | NOT WRITTEN - template placeholder text left (see the first FAIL) | "
              f"work copy {held.split('work copy, never to be delivered:', 1)[-1].strip()}")
    else:
        print(f"{overall} | {out} {stamp}" + (f" | {', '.join(extra)}" if extra else ""))
        if (vd / "contact-sheet.png").exists():            # every slide in one picture: show() it in the build's own cell
            print(f"PICTURE {vd / 'contact-sheet.png'}")
    keep = [l.strip() for l in L if l.strip().startswith(("FAIL ", "STILL TOO LONG", "warning", "note:", "ADVICE ")) or "SHRUNK HARD" in l
            or "drawn as" in l or (l.startswith("REVIEW ") and "Render" not in l)]
    first = re.compile(r"(?i)placeholder|sample (text|label|cards)|lorem ipsum|insert headline|repeats .* in several cells|got none")
    keep = sorted(keep, key=lambda l: ("template placeholder text on" not in l, not (l.startswith("FAIL") and first.search(l)),
                                       not l.startswith("FAIL")))
    for l in list(dict.fromkeys(keep))[:12]:
        print("  " + l)
    if len(keep) > 12:
        print(f"  ... {len(keep) - 12} more in {vd / 'build-log.txt'}")
    for l in L:                                        # the expert review: its summary and what would make the deck better
        if l.startswith("EXPERT"):
            print(l if l.startswith("EXPERT REVIEW") else "  " + l)


def build(story_path, out, verbose=False, tokens=True):
    import contextlib, io, atomic
    buf = io.StringIO()
    with atomic.build_lock(out), atomic.staged(out, keep=[story_path]) as work:   # one build of a deck at a time, made out
        with contextlib.redirect_stdout(buf):                                     # of sight: a build the cell's time limit
            code = _build(story_path, work)                                       # cuts off leaves no deck at out, half-made or old
    log = buf.getvalue().replace(str(work.parent), str(Path(out).resolve().parent))
    if verbose or not tokens:
        summarize(log, out, verbose)
        return code
    sbuf = io.StringIO()
    with contextlib.redirect_stdout(sbuf):
        summarize(log, out, verbose)
    said = sbuf.getvalue()
    import tokens as TK
    print(said.rstrip())
    if Path(out).exists():
        print(TK.report(out, Path(story_path).read_text(encoding="utf-8"), said, "built"))
    return code


COLUMN_STYLES = ("auto", "bands", "outline", "pastel", "icons", "midnight", "numbered", "bubbles", "zones", "cloud")


def _strings(v):
    if isinstance(v, str):
        yield v
    elif isinstance(v, (list, tuple)):
        for x in v:
            yield from _strings(x)
    elif isinstance(v, dict):
        for x in v.values():
            yield from _strings(x)


def _w(t):
    return len(str(t or "").split())


def big_number_limits(parts):
    """A big number's cell: the number, a 3-6 word label, and at most one context line of 6 words ("72% to 80%")."""
    if _w(parts[1]) > 6:
        return [f"big number '{parts[0]}' has a {_w(parts[1])}-word label - 3-6 words"]
    if len(parts) > 3:
        return [f"big number '{parts[0]}' has {len(parts)} lines - the number, a 3-6 word label and one context line"]
    if len(parts) == 3 and _w(parts[2]) > 6:
        return [f"big number '{parts[0]}': the context line '{parts[2][:30]}' has {_w(parts[2])} words - 6 at most "
                "(from and to, a target, a period: '72% to 80%')"]
    return []


def cell_limits(spec, src):
    """Word limits per template table (Ulta): what each cell holds at the template's size without becoming a text block.
    Cards (7): column title 1-3 words; card = 1-4 word title + one line of at most 15 words. Big numbers (9, and
    headline-metrics): label at most 6 words, one context line of at most 6. Hypothesis (10): 14 words a cell. Action table (12): what 4, description 14, when/who 5. Grid (14):
    headers 3, cells 8. Any other table: 12 words a cell, 120 in all."""
    t = spec.get("table")
    out = []
    if src == 14 and isinstance(t, list) and (not t or t[0] is None or all(v is None for v in t[0][1:])):
        out.append("the grid's header row is the template's sample (\"Where / Channel/ Environment\" …) - give row 1 as "
                   "[null, \"Title\", …] with your 5 column titles (1-3 words each)")
    if isinstance(t, list) and src in (7, 9, 10, 12, 14):
        for r, row in enumerate(t):
            for c, cell in enumerate(row or []):
                if cell is None or not str(cell).strip():
                    continue
                parts = [x.strip() for x in str(cell).split("\n") if x.strip()]
                if src == 7:
                    if r == 0 and _w(cell) > 3:
                        out.append(f"card column title '{str(cell)[:30]}' has {_w(cell)} words - 1-3 words")
                    elif r > 0 and (_w(parts[0]) > 4 or _w(" ".join(parts[1:])) > 15):
                        out.append(f"card '{parts[0][:30]}' holds {_w(cell)} words - a card is a 1-4 word title + one sentence of "
                                   "6-15 words (two lines); the explanation goes in the speaker notes")
                elif src == 9 and r > 0 and len(parts) > 1:
                    out += big_number_limits(parts)
                elif src == 10 and _w(cell) > 14:
                    out.append(f"'{str(cell)[:35]}…' has {_w(cell)} words - a hypothesis or action is one line of at most 14 words")
                elif src == 12 and r > 0 and _w(cell) > (4, 14, 5)[min(c, 2)]:
                    out.append(f"action table {('what', 'description', 'when / who')[min(c, 2)]} '{str(cell)[:30]}…' has "
                               f"{_w(cell)} words - at most {(4, 14, 5)[min(c, 2)]}; the detail goes in the notes")
                elif src == 14 and _w(cell) > (3 if r == 0 else 8):
                    out.append(f"grid cell '{str(cell)[:30]}…' has {_w(cell)} words - headers 1-3 words, cells at most 8")
    if LAYOUTS and src == FT.names().get("headline-metrics") and isinstance(t, list):
        for row in t:
            for cell in row or []:
                parts = [x.strip() for x in str(cell or "").split("\n") if x.strip()]
                out += big_number_limits(parts) if len(parts) > 1 else []
    rows = t.get("rows") if isinstance(t, dict) else None
    if rows and not src and len(rows) < 2 and (t.get("header", True) if isinstance(t, dict) else True):
        labels = [str(v) for v in rows[0] if v not in (None, "")]
        out.append(f"the table has only its header row ({', '.join(labels[:5])}) and leaves the slide empty - a sequence of "
                   'stages is a process ("diagram": ["A → B", "B → C"], "style": "chevron"), a list is "bullets"; a table '
                   "needs body rows")
    if rows and not src and NAV.match(str(spec.get("headline") or spec.get("title") or "")) and re.match(
            r"(?i)agenda|contents", str(spec.get("headline") or spec.get("title") or "")):
        out.append('an agenda goes on the agenda slide ("source": 2 or "agenda-list", "table": [[null, "item"], ...], up to '
                   "5 items; the numbers are automatic), not in a data table where item 1 becomes a header")
    if rows and not src:
        cells = [str(v) for row in rows for v in row if v is not None]
        longest = max(cells, key=_w, default="")
        if _w(longest) > 12 or sum(map(_w, cells)) > 120:
            out.append(f"table of {len(rows)} rows holds {sum(map(_w, cells))} words (longest cell {_w(longest)}: "
                       f"'{longest[:30]}…') - a slide table takes short cells (at most 12 words, 120 in all): keep 3-5 "
                       "columns of key words, move the explanation to the notes, or split the table")
    seen, uniq = set(), []
    for m in out:
        if m not in seen: seen.add(m); uniq.append(m)
    return uniq[:4]


VERBS = re.compile(r"(?i)\b(is|are|was|were|be|has|have|had|cut|cuts|grow|grows|grew|lead|leads|led|drive|drives|drove|lift|"
                   r"lifts|beat|beats|miss|misses|fall|falls|fell|rise|rises|rose|win|wins|need|needs|must|will|can|should|"
                   r"save|saves|reduce|reduces|increase|increases|improve|improves|close|closes|launch|launches|ship|ships|"
                   r"keep|keeps|stop|stops|start|starts|done|ready|late|ahead|behind|up|down|doubled|halved|on track|at risk)\b")


NAV = re.compile(r"(?i)^(agenda|contents|appendix|back-?up|q\s*&\s*a|questions|thank you|thanks|at a glance|executive summary)\b")


def is_label(headline):
    """A topic label rather than a takeaway: one or two words, or three without a number or a verb ('Order flow').
    Navigation titles (Agenda, Appendix, Q&A, Thank you) are labels by design and pass."""
    w = headline.split()
    if NAV.match(headline.strip()):
        return False
    return len(w) <= 2 or (len(w) == 3 and not re.search(r"\d", headline) and not VERBS.search(headline))


ADVICE = []            # worth a look but not a fault (a converted deck keeps the source deck's own headlines)


def design_lint(slides, converted=False, gallery=False):
    """Storyboard problems that pass every template check but read as a text dump: a process typed as "A → B → C",
    sentences stacked as lines in a box, two boxes holding a sentence or two, one layout for the whole deck, and a
    diagram of a handful of systems drawn as a thin strip. Each says which layout to use instead."""
    if BRAND.name != "ulta":
        return
    two_box = BRAND.role("diagram_base", 6)
    two_box_used = []
    content = []
    for k, spec in enumerate(slides, 1):
        src = spec.get("source")
        hl = " ".join(str(spec.get("headline") or "").split())
        if hl and src not in DISPLAY and not spec.get("priorities") \
                and is_label(hl):                       # (the priorities house keeps the template's short plan-name title)
            if converted:
                ADVICE.append(f"slide {k}: headline '{hl}' (kept from the source deck) is a topic label - a takeaway with "
                              "its number reads stronger; offer to rewrite it from the slide's own content")
            else:
                PROBLEMS.append(f"slide {k}: headline '{hl}' is a topic label - the template's rule: every title states "
                                "the so-what. Write the takeaway with its number (e.g. 'Returns down 18% since self-service')")
        if spec.get("diagram"):
            d = spec["diagram"]
            names, outs = set(), {}
            for ln in (d if isinstance(d, list) else []):
                m = re.match(r"\s*(.+?)\s*(?:→|->)\s*(.+?)\s*(?::|$)", str(ln))
                if m:
                    names.update(m.groups()); outs[m.group(1)] = outs.get(m.group(1), 0) + 1
            if isinstance(d, dict):
                names = {n.get("id") for n in d.get("nodes") or []}
                for f in d.get("flows") or []:
                    outs[f.get("source")] = outs.get(f.get("source"), 0) + 1
            chain = bool(outs) and max(outs.values()) == 1          # nothing fans out: the systems line up in one row
            if len(names) > 8:
                PROBLEMS.append(f"slide {k}: {len(names)} systems on one diagram slide - a slide holds 8 (the least connected "
                                "would be dropped into the notes): group them (e.g. 'Channels' for ulta.com + Stores) or split "
                                "the picture over two slides")
            if 0 < len(names) <= 5 and chain and spec.get("style", "auto") in COLUMN_STYLES:
                PROBLEMS.append(f"slide {k}: {len(names)} systems in the '{spec.get('style', 'auto')}' style draw as one thin strip "
                                "across an empty slide - show the real landscape (channels, users, data stores, downstream systems: "
                                "6-8 systems), or use a style made for a few: chevron (one chain), cake (layers with points), hub")
            content.append(("diagram", k)); continue
        if spec.get("modern"):
            content.append(("diagram", k)); continue      # a chart slide: its own layout by design
        import template_infographics as TI
        if TI.key_of(spec):                               # a template infographic: its own layout by design
            content.append(("diagram", k)); continue
        fam = family_of(spec)
        if fam:                                           # a timeline / swimlane: its own layout; its module checks it
            mod = family_module(fam)
            st = spec.get("style") or mod.auto_style(spec[fam])
            chk = TI.lint(fam, st, spec) if (fam, st) in TI.TEMPLATE_STYLES else mod.lint(dict(spec, style=st))
            PROBLEMS.extend(f"slide {k}: {m_}" for m_ in chk)
            content.append(("diagram", k)); continue
        if src in DISPLAY or spec.get("graphic") or spec.get("library"):
            continue
        import modern_charts as MC
        tiles = spec.get("bullets") is not None and not (spec.get("picture") or spec.get("plain")) and MC.as_points(spec["bullets"])
        key = ("points" if tiles else "bullets" if spec.get("bullets") is not None else "chart" if spec.get("chart") else
               "picture" if spec.get("picture") else src)
        content.append((key, k))
        if spec.get("bullets") is not None and not (spec.get("chart") or spec.get("picture") or spec.get("table")):
            tops = [t for lvl, t in map(DS._item, spec["bullets"]) if not lvl and str(t).strip()]
            bw = sum(len(t.split()) for t in _strings(spec["bullets"]))
            if len(tops) == 1:
                PROBLEMS.append(f"slide {k}: one point is a statement, not a list - make it the headline, or use the two-box "
                                "slide (6) for two statements")
            elif len(tops) > 6:
                PROBLEMS.append(f"slide {k}: {len(tops)} points - a slide shows 2-6 (drawn as tiles): group them under fewer "
                                "points or split the slide; the rest goes in the speaker notes")
            elif bw > 80 or any(len(t.split()) > 18 for t in _strings(spec["bullets"])):
                PROBLEMS.append(f"slide {k}: {bw} words of points - a slide is not a document: 2-6 points written "
                                "\"Lead: detail\" (a 1-3 word lead, at most 15 words in all); the explanation goes in the notes")
            elif not tiles and bw < 40:                  # a plain list ("plain": true) still has to fill the slide
                PROBLEMS.append(f"slide {k}: {len(spec['bullets'])} short bullets ({bw} words) fill a fifth of the slide at the "
                                "12 pt body size - drop \"plain\" so they are drawn as tiles, or use cards (7)")
        if spec.get("steps") and src == FLOW:
            st_ = spec["steps"]
            if sum(1 for x in st_ if not str(x.get("label") or "").strip()):
                PROBLEMS.append(f"slide {k}: flow steps without a label leave the top band empty - give each step a 1-3 word "
                                "label (\"1 Capture\", \"Week 2\", \"Mon 03/02\") and 2-6 words in the box")
            long_ = [x.get("text", "") for x in st_ if len(str(x.get("text") or "").split()) > 6]
            if long_:
                PROBLEMS.append(f"slide {k}: flow box '{str(long_[0])[:35]}…' is a sentence - boxes take 2-6 words "
                                "(all boxes share one size, so one long box shrinks every box); put the detail in the notes")
        if spec.get("steps"):
            continue
        for msg in cell_limits(spec, src):             # a table cell that holds a paragraph is a text dump too
            PROBLEMS.append(f"slide {k}: {msg}")
        texts = [t for t in _strings([spec.get("text"), spec.get("table"), spec.get("bullets"), spec.get("slots")]) if t]
        chain = next((t for t in texts if t.count("→") + t.count("->") >= 2), None)
        if chain:
            PROBLEMS.append(f"slide {k}: '{chain[:45]}…' is a process typed as text - use the flow slide "
                            f'{{"source": {FLOW}, "steps": [{{"label": "…", "text": "…"}}, …]}} (3-6 steps) or a chevron diagram')
        if src == two_box and isinstance(spec.get("text"), list):
            boxes = [str(v or "") for v in spec["text"]]
            for j, b in enumerate(boxes, 1):
                lines = [l for l in b.split("\n") if l.strip()]
                if len(lines) >= 3 and not all(re.match(r"\s*[•\-–*\d]", l) for l in lines):
                    PROBLEMS.append(f"slide {k}: box {j} stacks {len(lines)} separate points as plain lines (no bullets) - a wall of "
                                    'text: use {"bullets": [...]} for points, or cards (slide 7, three titled cards)')
            for j, b in enumerate(boxes, 1):           # one statement a box - not a list written as sentences
                sentences = len([x for x in re.split(r"(?<=[.!?])\s+(?=[A-Z])", b.strip()) if x.strip()])
                items = b.count(",") + len(re.findall(r"\band\b", b))
                if sentences >= 2 or items >= 3:
                    PROBLEMS.append(f"slide {k}: box {j} is a list written as " + (f"{sentences} sentences" if sentences >= 2 else
                                    f"one long sentence ({items + 1} items)") + " - a text dump. Each item is a card: use cards "
                                    "(7: three columns x two rows, \"Verb\\n\\nshort line\" each), or bullets; the two boxes take ONE "
                                    "statement each (6-30 words)")
            two_box_used.append(k)
            if len(two_box_used) == 2:
                PROBLEMS.append(f"deck: the two-box layout (6) is used on slides {two_box_used[0]} and {k} - once a deck at most; "
                                "give the other slide cards (7), big numbers (9), a flow (20) or a chart")
            words = [len(b.split()) for b in boxes]
            if words and (min(words) < 6 or max(words) > SHORT_BOX_WORDS):
                PROBLEMS.append(f"slide {k}: the two text boxes hold {' and '.join(map(str, words))} words - "
                                + ("too little: the tall boxes look empty" if min(words) < 6 else
                                   f"keep each box to 6-{SHORT_BOX_WORDS} words (it is then set as a 20 pt statement that "
                                   "fills the box; longer text stays at 12 pt and leaves the box mostly empty)")
                                + f". Use cards (7: a 1-3 word title + one short line, six cards), big numbers (9) or the flow "
                                f"slide ({FLOW}); the detail goes in the speaker notes")
    import storyline as SL                              # no two slides in a row look alike or tell their story one way
    looks, ways = [look_of(sp) for sp in slides], [SL.device_of(sp) for sp in slides]
    for k in range(1, len(slides) if not gallery else 0):
        if SL.continues(slides[k - 1], slides[k]):
            continue
        near = [i for i in (k - 1, k + 1) if i < len(slides)]
        if looks[k] and looks[k] == looks[k - 1]:
            msg = (f"slides {k} and {k + 1} look alike (both {LOOK_WORDS.get(looks[k], 'the ' + looks[k] + ' slide')}) - two "
                   f"slides in a row in one look read as one slide shown twice. Give slide {k + 1} another layout for its "
                   f"content: {SL.advice(slides[k], [ways[i] for i in near], [looks[i] for i in near])}")
        elif ways[k] and ways[k] == ways[k - 1]:
            msg = SL.message(slides, k + 1, ways[k], [looks[i] for i in near])
        else:
            continue
        (ADVICE if converted else PROBLEMS).append(msg if not converted else msg + " (kept from the source deck)")
    keys = [c[0] for c in content if c[0] != "diagram"]   # a diagram gallery is one kind by design
    content = [c for c in content if c[0] != "diagram"]
    if len(keys) >= 4:
        top = max(set(keys), key=keys.count)
        if keys.count(top) / len(keys) > 0.5 and keys.count(top) >= 3:
            which = [k for key, k in content if key == top]
            PROBLEMS.append(f"deck: {keys.count(top)} of {len(keys)} content slides use the same layout ({top}: slides "
                            f"{', '.join(map(str, which))}) - it reads as a text dump. Give each slide the layout its content needs: "
                            f"cards 7, big numbers 9, action table 12, flow {FLOW}, bullets, a diagram or a chart")
    story_lint(slides)


def _slide_words(spec):
    """The words a slide shows (headline aside), for the repeated-content check."""
    out = []
    def walk(v):
        if isinstance(v, str):
            out.extend(re.findall(r"[a-z0-9%$]+", v.lower()))
        elif isinstance(v, dict):
            for k, x in v.items():
                if k not in ("notes", "source", "style", "data", "picture", "from"):
                    walk(x)
        elif isinstance(v, list):
            for x in v:
                walk(x)
    walk({k: v for k, v in spec.items() if k not in ("headline", "notes", "source", "style", "_k", "title", "subtitle")})
    return set(w for w in out if len(w) > 2)


def story_lint(slides):
    """Advice on the story, never a fault: the agenda names the sections in another order than the dividers, or two
    slides show the same content (a process typed once as a flow and again as a list)."""
    agenda = next((s for s in slides if s.get("source") in AGENDAS and isinstance(s.get("table"), list)), None)
    dividers = [(k, str(s.get("title") or "")) for k, s in enumerate(slides, 1)
                if (s.get("source") == 5 or s.get("source") in NEW_DIVIDERS) and s.get("title")]
    if agenda and len(dividers) >= 2:
        items = [str((r or [None, ""])[-1] or "") for r in agenda["table"] if r and str((r or [None, ""])[-1] or "").strip()]
        def key(s):
            return set(w for w in re.findall(r"[a-z0-9]+", s.lower()) if len(w) > 3)
        order = []
        for k, title in dividers:
            hit = next((i for i, it in enumerate(items) if key(it) & key(title)), None)
            if hit is not None:
                order.append((hit, k, title))
        if len(order) >= 2 and [o[0] for o in order] != sorted(o[0] for o in order):
            ADVICE.append("deck: the dividers run in a different order than the agenda lists the sections (" +
                          ", ".join(f"slide {k} '{t_[:25]}' is agenda item {i + 1}" for i, k, t_ in order) +
                          ") - reorder the agenda or the sections so the two match")
    words = {k: _slide_words(s) for k, s in enumerate(slides, 1) if s.get("source") not in DISPLAY}
    done = set()
    for a in words:
        for b in words:
            if b <= a or (a, b) in done or len(words[a]) < 12 or len(words[b]) < 12:
                continue
            j = len(words[a] & words[b]) / len(words[a] | words[b])
            if j >= 0.6:
                done.add((a, b))
                ADVICE.append(f"slides {a} and {b} show the same content ({int(j * 100)}% of the words) - keep one, or make the "
                              "second slide say something new (the detail can go in the notes)")


def even_flow_boxes(out, ks):
    """Flow slide: every step box at ONE size and weight (the smallest any box needed), never one big bold box beside
    a small plain one - fitting each box on its own made the row look random."""
    prs = Presentation(str(out)); A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    for k in ks:
        sl = prs.slides[k - 1]
        tbl = next((sh for sh in sl.shapes if sh.has_table), None)
        if tbl is None:
            continue
        boxes = [sh for sh in sl.shapes if sh.has_text_frame and not sh.has_table and sh.top > tbl.top
                 and sh.width < tbl.width / 3 and sh.text_frame.text.strip()]
        runs = [r for b in boxes for r in b._element.iter(A + "rPr")]
        sizes = [int(r.get("sz")) for r in runs if r.get("sz")]
        if len(boxes) < 2 or not sizes:
            continue
        model = min((r for r in runs if r.get("sz")), key=lambda r: int(r.get("sz")))   # the smallest box's run, font and all
        for r in runs:
            if r is not model:
                r.getparent().replace(r, copy.deepcopy(model))
    import atomic
    atomic.save(prs, out)


def keep_last_pairs(out, ks):
    """No one-word last line: in every paragraph of 4+ words the last two words are joined by a non-breaking space,
    when the pair takes at most 45% of the line at its size (a narrow box with big type keeps a normal space, so a
    joined pair can never be wider than its box). It changes nothing where the text fits on one line."""
    M = _B.metrics_for(BRAND)
    prs = Presentation(str(out))

    def frames(sl):
        for sh in sl.shapes:
            if sh.has_text_frame and sh.width:
                tf = sh.text_frame
                yield tf, sh.width - (tf.margin_left or 91440) - (tf.margin_right or 91440)
            elif sh.has_table:
                widths = [c.width for c in sh.table.columns]
                for row in sh.table.rows:
                    for ci, c in enumerate(row.cells):
                        if not c.is_spanned:
                            yield c.text_frame, widths[ci] - (c.margin_left or 91440) - (c.margin_right or 91440)
    for k in ks:
        for tf, room in frames(prs.slides[k - 1]):
            for p_ in tf.paragraphs:
                runs = [r for r in p_.runs if r.text]
                text = "".join(r.text for r in runs)
                words = text.split(" ")
                if len([w for w in words if w]) < 4 or not words[-1] or not words[-2] or "\u00a0" in text:
                    continue
                last = next((r for r in reversed(runs) if " " in r.text.rstrip()), None)
                size = (last.font.size if last is not None and last.font.size else None) or next(
                    (r.font.size for r in runs if r.font.size), None)
                if last is None or size is None or last.text.rstrip().rfind(" ") < 0:
                    continue
                font = last.font.name or BRAND.font("body")
                pair = words[-2] + " " + words[-1]
                if (_B.width_of(pair, font, M) or len(pair) * 0.55) * size <= 0.45 * room:
                    i = last.text.rstrip().rfind(" ")
                    last.text = last.text[:i] + "\u00a0" + last.text[i + 1:]
    import atomic
    atomic.save(prs, out)


def align_card_rows(out, ks):
    """Card slide (7): the cells of one row share one top inset, sized by the row's tallest card, so the sub-headlines
    line up across the row and each block still sits in the middle of its card - centring every cell on its own put a
    card with a two-line sentence higher than its neighbours."""
    from pptx.util import Emu
    M = _B.metrics_for(BRAND)
    prs = Presentation(str(out)); A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    for k in ks:
        tshape = next((sh for sh in prs.slides[k - 1].shapes if sh.has_table), None)
        if tshape is None:
            continue
        widths = [c.width for c in tshape.table.columns]
        for row in list(tshape.table.rows)[1:]:
            hs = []
            for ci, c in enumerate(row.cells):
                if c.is_spanned or not c.text.strip():
                    continue
                w, h = widths[ci] - (c.margin_left or 91440) - (c.margin_right or 91440), 0
                for p_ in c.text_frame.paragraphs:
                    run = next((r for r in p_.runs if r.font.size), None)
                    end = p_._p.find(A + "endParaRPr")
                    size = run.font.size if run is not None else (int(end.get("sz")) * 127 if end is not None and end.get("sz") else 152400)
                    txt = "".join(r.text for r in p_.runs)
                    font = (run.font.name if run is not None else None) or BRAND.font("body")
                    h += (_lines(txt, w, size, font, M) if txt.strip() else 1) * size * 1.2
                hs.append((c, h))
            if len(hs) < 2:
                continue
            top = max(45720, int((row.height - max(h for _, h in hs)) / 2))
            for c, _ in hs:
                c.vertical_anchor = MSO_ANCHOR.TOP
                c.margin_top, c.margin_bottom = Emu(top), Emu(45720)
    import atomic
    atomic.save(prs, out)


def glance(story, slides):
    """Pre-read mode ("mode": "read"), or "glance" given: the deck in 2-6 points on an "At a glance" slide after the
    agenda (else after the cover), drawn as numbered tiles. Points: "glance" ("Lead: detail", 15 words each), else the
    headlines of the slides that carry a summary or a decision, else of the content slides spread through the deck.
    Returns (slides, advice)."""
    pts = story.get("glance")
    read = str(story.get("mode") or "present").strip().lower() in ("read", "pre-read", "preread", "reading")
    if not pts and not read:
        return slides, []
    own = re.compile(r"^(at a glance|executive summary|summary|in brief|the deck in brief)\b", re.I)
    if any(isinstance(s, dict) and own.match(" ".join(str(s.get("headline") or s.get("title") or "").split())) for s in slides):
        return slides, []                              # the storyboard has its own summary slide: never a second one
    said = []
    if not pts:
        content = [s for s in slides if isinstance(s, dict) and str(s.get("headline") or "").strip()
                   and s.get("source") not in DISPLAY and not NAV.match(str(s.get("headline")).strip())]
        keyed = [s for s in content if s.get("summary") or s.get("decision")]
        pick = keyed if len(keyed) >= 3 else content
        if len(pick) > 5:
            pick = [pick[round(i * (len(pick) - 1) / 4)] for i in range(5)]
        pts = [re.sub(r":\s+", ", ", " ".join(str(s["headline"]).split()), count=1) for s in pick]   # sentences, one look
        if len(pts) < 2:
            return slides, ["read mode: too few content slides for an At a glance slide - none added"]
        said.append('read mode: the At a glance slide lists headlines - write "glance" (3-5 points, "Lead: detail") '
                    "for sharper points")
    spec = {"bullets": list(pts)[:6], "headline": story.get("glance_headline") or "At a glance", "_glance": True,
            "notes": "The deck in brief: each point is the takeaway of a part that follows."}
    agendas = {2} | ({FT.names().get(n) for n in ("agenda-list", "agenda-gradient")} if LAYOUTS else set())
    at = next((i + 1 for i, s in enumerate(slides) if isinstance(s, dict) and s.get("source") in agendas), None)
    if at is None:
        at = 1 if slides and isinstance(slides[0], dict) and slides[0].get("source") in COVERS else 0
    return slides[:at] + [spec] + slides[at:], said


def _build(story_path, out):
    import plain                                       # plain punctuation: no em dashes in anything a reader sees
    story = plain.deep(json.loads(Path(story_path).read_text()))
    DS.BASE.append(Path(story_path).resolve().parent)
    import template_infographics as TI
    if any(isinstance(s_, dict) and isinstance(s_.get("retail"), str) for s_ in story["slides"]):
        import retail as RT                            # a retail starter's name: its full slide (loaded only when named)
        story["slides"] = [RT.expand(s_) for s_ in story["slides"]]
    story["slides"] = [TI.reroute(s_) for s_ in story["slides"]]   # a count a template slide can't hold: its nearest layout
    unknown = []
    for k_, s_ in enumerate(story["slides"], 1):       # "source": a layout name ("four-pillars") or its number
        if isinstance(s_, dict) and isinstance(s_.get("source"), str):
            r_ = FT.resolve(s_["source"]) if LAYOUTS else s_["source"]
            if isinstance(r_, int):
                s_["source"] = r_
            else:
                unknown.append(f"slide {k_}: unknown layout '{s_['source']}' - see python tools/full_template.py list")
                s_["source"] = DIAGRAM_SOURCE
    story["slides"], glance_advice = glance(story, story["slides"])    # pre-read mode: the deck in brief, after the agenda
    story["slides"] = [cards_as_tiles(s_, k_) for k_, s_ in enumerate(story["slides"], 1)]
    as_is = dict(converted=bool(story.get("converted")), gallery=bool(story.get("gallery")))
    if story.get("retail_first") is not False:                 # a supply chain or a retail process: its retail diagram
        story["slides"] = retail_first(story["slides"], **as_is)
    story["slides"] = vary_neighbours(story["slides"], **as_is)
    slides = [modern_to_family(s) for s in story["slides"]]
    slides = [TI.as_flow(s) if family_of(s) == "timeline" and s.get("style") == "dated-flow" else s for s in slides]
    try:                                               # the presentation expert's read of the finished storyboard (before
        import copy, deck_expert as DX                 # the build changes any spec): story, pictures, context, the source
        expert = DX.review(story, copy.deepcopy(slides), source=story.get("source_doc"))
    except Exception as e:
        expert = [f"EXPERT REVIEW: not run ({type(e).__name__}: {str(e)[:60]})"]
    prs = Presentation(str(REF))
    originals = list(prs.slides)
    n_orig = len(originals)
    import atomic
    work = atomic.scratch()
    out_p = Path(out).resolve()
    diagram_slides, flow_slides, library_slides, list_slides = [], [], [], []
    infographic_slides, drawn_slides = [], []          # template infographic slides filled / family slides drawn
    PROBLEMS.clear()
    PROBLEMS.extend(unknown)
    ADVICE.clear()
    ADVICE.extend(glance_advice)
    if str(story.get("mode") or "").strip().lower() in ("read", "pre-read", "preread", "reading"):
        bare = [k_ for k_, s_ in enumerate(slides, 1) if isinstance(s_, dict) and str(s_.get("headline") or "").strip()
                and s_.get("source") not in DISPLAY and not NAV.match(str(s_.get("headline")).strip()) and not s_.get("summary")]
        if bare:
            ADVICE.append(f"read mode: slide(s) {', '.join(map(str, bare[:12]))} have no summary line - add one (about 15 "
                          "words) so each page reads without a presenter")
    DIVIDERS.clear()
    TRIMMED.clear()
    _diagram_sigs.clear()
    for k_, sp_ in enumerate(slides, 1):              # a flow with unlabeled steps: "Step 1…n" rather than an empty band
        if FLOW and sp_.get("source") == FLOW and isinstance(sp_.get("steps"), list) and \
                any(not str((x or {}).get("label") or "").strip() for x in sp_["steps"]):
            sp_["steps"] = [dict(x, label=str(x.get("label") or "").strip() or f"Step {i}") for i, x in enumerate(sp_["steps"], 1)]
            print(f"note: slide {k_}: flow steps had no labels - labelled Step 1-{len(sp_['steps'])}")
    design_lint(slides, converted=bool(story.get("converted")), gallery=bool(story.get("gallery")))
    import storyline as SL                             # each slide's way of telling, kept in the record (slide_options,
    ways = {str(k_): SL.device_of(s_) for k_, s_ in enumerate(slides, 1)}   # edit_deck: never two in a row told one way)
    pre = predraw(slides, work)
    for k, spec in enumerate(slides, 1):
        spec["_k"] = k
        if spec.get("source") in COVERS and len(str(spec.get("title") or "")) > 55:
            PROBLEMS.append(f"slide {k}: cover title is {len(str(spec['title']))} characters - keep it to 55 (two lines at full size); "
                            "shorten it (a subtitle is shown only where the cover has a subtitle box; otherwise it goes to the notes)")
        hl = str(spec.get("headline") or "")
        if len(hl) > HEADLINE_MAX:
            PROBLEMS.append(f"slide {k}: headline is {len(hl)} characters (limit {HEADLINE_MAX}) - state the message "
                            f"in one short line and move the detail into the slide body")
        if FLOW and spec.get("source") == FLOW and (spec.get("steps") or len(((spec.get("slots") or {}).get(FLOW_TABLE) or [[]])[0] or []) == BRAND.role("flow_boxes", 4)):
            flow_slides.append(k)
        if spec.get("diagram"):
            base = make_diagram(spec, work, k, pre.get(k))
            dprs = Presentation(f"{base}.pptx")
            new = import_slide(prs, dprs.slides[0])
            plain_headline(new, spec)
            if spec.get("notes"):
                new.notes_slide.notes_text_frame.text = spec["notes"]
            spec["source"] = DIAGRAM_SOURCE
            diagram_slides.append(k)
            out_p.parent.mkdir(parents=True, exist_ok=True)
            Path(f"{base}.drawio").replace(out_p.with_name(f"{out_p.stem}-slide{k}.drawio"))
            sig = (spec.get("_drawn_style"), json.dumps(spec["diagram"], sort_keys=True) if isinstance(spec["diagram"], dict)
                   else "\n".join(sorted(spec["diagram"] if isinstance(spec["diagram"], list) else str(spec["diagram"]).splitlines())))
            twin = next((j for j, sg in _diagram_sigs if sg == sig), None)
            if twin:
                PROBLEMS.append(f"slide {k}: draws exactly the same picture as slide {twin} ({sig[0]} style, same flows) - "
                                "change the style or the flows, or drop one of them")
            _diagram_sigs.append((k, sig))
        elif spec.get("graphic"):
            new = import_slide(prs, make_graphic(spec, work, k, pre.get(k)))
            plain_headline(new, spec)
            if spec.get("notes"):
                new.notes_slide.notes_text_frame.text = spec["notes"]
            spec["source"] = DIAGRAM_SOURCE
            diagram_slides.append(k)
        elif spec.get("library"):
            import library as LIB
            new = import_slide(prs, LIB.slide(spec["library"]))
            library_slides.append({"slide": k, "key": spec["library"], "sha256": LIB.slide_hash_of(new)})
            spec["source"] = DIAGRAM_SOURCE
            diagram_slides.append(k)                     # approved as-is: checked by its own hash, not by the template
        elif family_of(spec):
            fam = family_of(spec)
            mod = family_module(fam)
            spec["style"] = spec.get("style") or mod.auto_style(spec[fam])
            import template_infographics as TI
            src = TI.TEMPLATE_STYLES.get((fam, spec["style"]))
            if src:                                      # the template's own slide (15-20), filled: 100% its look
                new = duplicate(prs, originals[src - 1])
                fill(new, {"source": src, "_k": k, "notes": spec.get("notes")})
                PROBLEMS.extend(f"slide {k}: {p_}" for p_ in TI.fill(new, fam, spec["style"], spec))
                spec["source"] = src
                infographic_slides.append(k)
            else:                                        # drawn natively in the template's visual language
                new, box = title_only_slide(prs, originals[DIAGRAM_SOURCE - 1], spec.get("headline") or "",
                                            room=DECISION_ROOM if spec.get("decision") else 0)
                import visual_spec as VS                     # v6.37 the spec stays with the group: the slide editor can redraw it
                try:
                    _el, probs_ = VS.draw(new, box, fam, spec["style"], spec[fam], lint=False,
                                          density="dense" if spec.get("_dense") else spec.get("density"))
                except ValueError as e_:
                    probs_ = [str(e_)]
                PROBLEMS.extend(f"slide {k}: {p_}" for p_ in probs_)
                if spec.get("notes"):
                    new.notes_slide.notes_text_frame.text = spec["notes"]
                spec["source"] = DIAGRAM_SOURCE
                diagram_slides.append(k)
                drawn_slides.append(k)
        elif spec.get("modern"):
            new, box = title_only_slide(prs, originals[DIAGRAM_SOURCE - 1], spec.get("headline") or "",
                                        room=DECISION_ROOM if spec.get("decision") else 0)
            import modern_charts as MC
            notes = spec.get("notes")
            PROBLEMS.extend(f"slide {k}: {p_}" for p_ in MC.draw(new, spec, box))
            if notes:
                new.notes_slide.notes_text_frame.text = notes
            spec["source"] = DIAGRAM_SOURCE
            diagram_slides.append(k)
        elif TI.key_of(spec):                           # a template infographic slide (8, 11, 13, 18, 21, 22, 24-26), filled
            key = TI.key_of(spec)
            src = TI.KEYS[key]
            new = duplicate(prs, originals[src - 1])
            fill(new, {"source": src, "_k": k, "notes": spec.get("notes")})
            PROBLEMS.extend(f"slide {k}: {p_}" for p_ in TI.fill(new, "infographic", key, spec))
            spec["source"] = src
            infographic_slides.append(k)
        elif spec.get("chart") or spec.get("bullets") is not None or spec.get("picture") or (spec.get("table") and not spec.get("source")):
            make_chart_slide(prs, originals[DIAGRAM_SOURCE - 1], spec)
            spec["source"] = DIAGRAM_SOURCE
            diagram_slides.append(k)                     # its own layout: checked like a diagram slide
        else:
            new_slide = duplicate(prs, originals[spec["source"] - 1])
            fill(new_slide, spec)
            import typeset as _TS
            if (spec.get("table") is not None or spec.get("slots")) and spec["source"] not in _TS.component_sources(BRAND):
                for sh in new_slide.shapes:            # (template components keep the sizes the template designed)
                    if sh.has_table:
                        grow_table(sh)
            if spec.pop("_list_shortened", False):
                list_slides.append(k)
        if spec.get("summary") or spec.get("decision"):  # the crisp summary where a reader looks next (or the notes)
            summary_layer(prs.slides[len(prs.slides) - 1], spec, k, prs.slide_width)
    lst = prs.slides._sldIdLst
    for sid in list(lst)[:n_orig]:                     # drop the 33 template originals
        prs.part.drop_rel(sid.rId)
        lst.remove(sid)
    out = Path(out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    import atomic
    atomic.save(prs, out)
    modern = [k for k, s in enumerate(slides, 1) if s.get("modern") or s.get("diagram") or s.get("graphic")]
    if modern:                                         # (diagram styles too: layer cake labelled its tiers with loose boxes)                                         # text on a card or tile goes INSIDE that shape (edits like hand-made)
        subprocess.run([sys.executable, str(TOOLS / "nativize.py"), str(out), "--slides", ",".join(map(str, modern))],
                       capture_output=True, text=True)
    import sections
    sections.set_sections(out, [("Slides", list(range(1, len(slides) + 1)))])   # not the template's sample sections
    sidecar(out).write_text(json.dumps({"diagram_slides": diagram_slides, "flow_slides": flow_slides,
                                        "library_slides": library_slides, "list_slides": list_slides,
                                        "infographic_slides": infographic_slides, "drawn_slides": drawn_slides,
                                        "trimmed_slides": list(TRIMMED), "schema_version": 2,
                                        "source_mapping": {str(i): s["source"] for i, s in enumerate(slides, 1)},
                                        "ways": ways, "gallery": bool(story.get("gallery")),
                                        "reference_sha256": BRAND.sha}))
    import layoutmeta; layoutmeta.save(out)          # the record travels inside the file too
    mapping = ",".join(str(s["source"]) for s in slides)
    if diagram_slides:
        print(f"diagram slides {diagram_slides}: editable .drawio saved next to the deck")
    print(f"built {out.name}: {len(slides)} slides, mapping {mapping}")
    fh = subprocess.run([sys.executable, str(TOOLS / "autofit.py"), str(out), "--mapping", mapping, "--out", str(out)],
                        capture_output=True, text=True)
    print(fh.stdout.strip())
    finish_before_validate(out, story)
    no_theme_effects(out, diagram_slides)              # no theme drop shadows on drawn shapes and lines (PowerPoint shows them)
    import typeset                                     # the template's type scale (slide 3) on every run
    exempt = [k for k, s in enumerate(slides, 1) if s.get("diagram") or s.get("graphic") or s.get("library") or s.get("modern")
              or s.get("_points") or k in drawn_slides]  # point tiles / drawn families carry the template's type themselves
    component = [k for k, s in enumerate(slides, 1) if s.get("source") in typeset.component_sources(BRAND)
                 and k not in exempt and k not in infographic_slides and k not in diagram_slides]   # template components keep their sizes
    PROBLEMS.extend(typeset.apply(out, {k: s.get("source") for k, s in enumerate(slides, 1)}, exempt, keep=infographic_slides,
                                  component=component))
    if flow_slides:
        even_flow_boxes(out, flow_slides)
    cards = [k for k in component if BRAND.name == "ulta" and slides[k - 1].get("source") == 7]
    if cards:
        align_card_rows(out, cards)                    # one sub-headline line per card row
    keep_last_pairs(out, [k for k in range(1, len(slides) + 1) if k not in exempt and k not in infographic_slides
                          and slides[k - 1].get("source") not in typeset.DISPLAY_SOURCES])
    try:                                               # a text box with no height renders above its spot (title in the corner)
        _chk = Presentation(str(out))
        for _n, _sl in enumerate(_chk.slides, 1):
            for _sh in _sl.shapes:
                if _sh.has_text_frame and _sh.text_frame.text.strip() and _sh.height is not None and _sh.height < 914400 * 0.1:
                    PROBLEMS.append(f"slide {_n}: text box '{_sh.text_frame.text[:30]}' has no height - it would sit out of place")
    except Exception:
        pass
    plain.clean_all([out] + sorted(Path(out).parent.glob(Path(out).stem + "-slide*.drawio")))   # before any preview
    v = subprocess.run([sys.executable, str(TOOLS / "validate_deck.py"), str(out), "--mapping", mapping],
                       capture_output=True, text=True)
    if PROBLEMS:                                       # printed first: the summary takes the first OVERALL line
        print("OVERALL: NEEDS CORRECTION - storyboard problems")
        for pr in PROBLEMS:
            print(f"FAIL  {pr}")
    vout = v.stdout.strip()
    if PROBLEMS:                                       # one verdict: the template checks passing does not make it READY
        vout = "\n".join(("Template checks: " + l.split(":", 1)[1].strip().split(" - ")[0].lower() +
                          " - the deck is NOT ready: fix the storyboard problems listed above")
                         if l.startswith("OVERALL") else l for l in vout.splitlines())
    print("\n" + vout + ("\n" + v.stderr.strip() if v.stderr.strip() else ""))
    for ad in ADVICE[:8]:                             # not faults: shown after the verdict so they never read as one
        print(f"ADVICE {ad}")
    try:                                               # what the built deck shows: words too small to read in a room
        import deck_expert as DX
        small = DX.small_text(out, slides)
    except Exception:
        small = []
    if small and expert and expert[0].startswith("EXPERT REVIEW:"):
        expert = [expert[0] + f" | small type on {len(small)} slide(s)"] + expert[1:] + [f"EXPERT {l}" for l in small]
    for line in expert[:10]:                          # never a fault either: what would make the deck better
        print(line)
    overall = next((l.split(":", 1)[1].strip() for l in v.stdout.splitlines() if l.startswith("OVERALL")), "not validated")
    if PROBLEMS:
        overall = "NEEDS CORRECTION - storyboard problems"
    import checks                                      # the builder's own rules join the validator's evidence
    checks.add(out, [("Storyboard rules (takeaway headlines, cards, labels, layouts)", "FAIL" if PROBLEMS else "PASS",
                      "; ".join(PROBLEMS[:3]))], requires="Template validation (validate_deck.py)")
    import validate_deck as _V                         # template placeholder text left: no deck where deliverables go
    held, where = _V.hold_back(out)
    if held:
        print(f"FAIL template placeholder text on {where} - the deck was NOT written: give each of those slides what "
              "its layout takes (python tools/build_deck.py inventory <source>) or drop the slide, then rebuild")
        print(f"NOT WRITTEN: {out} | work copy, never to be delivered: {held}")
        return 1
    import stamp as ST
    ver = ST.stamp(out, "built", overall, story.get("owner"), story.get("classification"))
    print(f"STAMP: v{ver} (file properties + {out.name}.audit.json; check later with tools/stamp.py verify)")
    print(f"\nFILE: {out}")
    return 0 if v.returncode == 0 and fh.returncode == 0 and not PROBLEMS else 1


STYLE_EXAMPLES = {   # flows of the right shape for every diagram style (each one passes the engine's own shape test)
    "_landscape": ["Store POS → Integration hub: sales", "ulta.com → API Gateway: orders", "API Gateway → ERP: orders",
                   "Integration hub → ERP: sales", "ERP → WMS: deliveries", "ERP → Data Lake: actuals"],
    "cake": {"nodes": [{"id": "ch", "label": "Channels", "items": ["ulta.com", "Ulta app", "Stores"]},
                       {"id": "ex", "label": "Experience", "items": ["API gateway", "Search", "Loyalty"]},
                       {"id": "co", "label": "Core services", "items": ["Orders", "Inventory", "Pricing"]},
                       {"id": "da", "label": "Data", "items": ["Data lake", "Reporting"]}],
             "flows": [{"source": "ch", "target": "ex", "label": "requests"}, {"source": "ex", "target": "co", "label": "orders"},
                       {"source": "co", "target": "da", "label": "actuals"}]},
    "hub": ["Store POS → ERP: sales", "ulta.com → ERP: orders", "Vendor EDI → ERP: ASNs",
            "ERP → WMS: deliveries", "ERP → Finance: postings", "ERP → Analytics: actuals"],
    "chevron": ["Order capture → Availability check: order", "Availability check → Supply protection: request", "Supply protection → Delivery: confirmed qty",
                "Delivery → Pick & pack: wave", "Pick & pack → Ship: carton"],
    "sequence": ["ulta.com → API Gateway: place order", "API Gateway → Order Service: create", "Order Service → ERP: stock check",
                 "ERP → Order Service: confirmed qty", "Order Service → ulta.com: confirmation"],
    "matrix": ["Store POS → ERP: sales", "ERP → WMS: deliveries", "WMS → ERP: goods issue",
               "ERP → Data Lake: actuals", "ulta.com → ERP: orders"],
    "tech": ["Store associate → Store App: scan", "Store App → API Gateway: lookup", "API Gateway → Inventory DB: query",
             "Order Service → Kafka queue: events", "API Gateway → Order Service: order"],
    "radial": ["Planning → Merchandising: plan", "Merchandising → Supply Chain: buy", "Supply Chain → Stores: replenish",
               "Stores → eCommerce: inventory", "eCommerce → Planning: demand"],
    "tree": ["Item Master → ulta.com: items", "Item Master → Store POS: prices", "Item Master → WMS: articles",
             "Item Master → Planning: hierarchy", "WMS → Stores: deliveries"],
}
STYLE_ORDER = ["bands", "outline", "pastel", "icons", "midnight", "numbered", "bubbles", "zones", "cloud",
               "cake", "hub", "chevron", "sequence", "matrix", "tech", "radial", "tree"]
GRAPHIC_EXAMPLES = {
    "funnel": ["Visitors: 1.2M a week", "Product views: 480K", "Add to bag: 96K", "Orders: 41K"],
    "pyramid": ["Vision: best-in-class guest experience", "Programs: loyalty, omnichannel", "Platforms: ERP, order management", "Data: one item master"],
    "stairs": ["Pilot: 5 stores", "Region: 120 stores", "Chain: 1,400 stores", "Run: continuous improvement"],
    "milestones": ["Jan: design", "Mar: build", "Jun: test", "Aug: go-live", "Oct: hypercare"],
    "quadrant": ["Quick wins: low effort, high value", "Big bets: high effort, high value", "Fill-ins: low effort, low value", "Avoid: high effort, low value"],
    "venn": ["Guest: what they want", "Business: what pays", "Technology: what we can run"],
    "target": ["Goal: 99% on-shelf", "Measure: weekly OOS rate", "Driver: forecast accuracy"],
    "honeycomb": ["Plan", "Buy", "Move", "Sell", "Serve", "Learn"],
}


def styles_deck(out):
    """One slide per diagram style (17) and per point graphic (8), each with content of the shape it needs, so every
    slide is a different picture. Use for "show me all diagram styles / architecture graphics"."""
    names = {"bands": "Brand bands", "outline": "Outline", "pastel": "Pastel", "icons": "Icons", "midnight": "Midnight",
             "numbered": "Numbered flows", "bubbles": "Bubbles", "zones": "Zones", "cloud": "Cloud guide", "cake": "Layer cake",
             "hub": "Hub and spoke", "chevron": "Chevron pipeline", "sequence": "Sequence", "matrix": "Interface matrix",
             "tech": "Technical view", "radial": "Radial", "tree": "Tree"}
    slides = [{"source": BRAND.role("cover", 1), "title": "Ulta architecture graphics", "subtitle": "Every diagram style and point graphic"}]
    for st in STYLE_ORDER:
        slides.append({"diagram": STYLE_EXAMPLES.get(st, STYLE_EXAMPLES["_landscape"]), "style": st,
                       "headline": f"Order platform in the {names[st]} style",
                       "notes": f"Style '{st}'. Sample flows of the shape this style needs; replace them with your own."})
    for g, items in GRAPHIC_EXAMPLES.items():
        slides.append({"graphic": g, "headline": f"The {g} point graphic with sample content", "items": items})
    slides.append({"source": 32, "text": ["Thank you!"]})
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    sb = Path(out).with_suffix(".storyboard.json")
    sb.write_text(json.dumps({"gallery": True, "slides": slides}, indent=1), encoding="utf-8")
    return build(str(sb), out, False, True)


SAMPLE_DECKS = {"timelines": "timeline", "swimlanes": "swimlane", "flows": "process", "retail": "retail",
                "infographics": "infographic"}


def family_deck(fam, out, only=None):
    """One slide per style of a family (timelines / swimlanes / process flows / retail diagrams), each with content of
    the shape it needs - for "show me the timeline styles" - so the user picks by sight. only: style names to keep (a
    quick look at one style)."""
    import template_infographics as TI
    mod = family_module(fam) if fam in FAMILIES else None
    title = {"timeline": "Ulta project timelines", "swimlane": "Ulta cross-functional swimlanes",
             "process": "Ulta process flows", "retail": "Ulta retail diagrams",
             "infographic": "Ulta template infographics"}[fam]
    samples = TI.sample(fam) + (mod.sample() if mod else [])
    if only:
        samples = [s for s in samples if s.get("style") in only or any(k in only for k in TI.KEYS if s.get(k) is not None)]
        if not samples:
            print(f"no style named {', '.join(only)} - styles: " + ", ".join(list(getattr(mod, "STYLES", {})) + list(TI.KEYS)))
            return 1
    slides = [{"source": BRAND.role("cover", 1), "title": title}] + samples
    slides.append({"source": 32, "text": ["Thank you!"]})
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    sb = Path(out).with_suffix(".storyboard.json")
    sb.write_text(json.dumps({"gallery": True, "slides": slides}, indent=1), encoding="utf-8")
    return build(str(sb), out, False, True)


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    i = sub.add_parser("inventory"); i.add_argument("slides", nargs="*", type=lambda v: FT.resolve(v) if LAYOUTS else int(v))
    i.add_argument("--full", action="store_true", help="every slot name and table cell (default: one line per slide)")
    i.add_argument("--all", action="store_true", help="every template slide (default: the brand's common slides)")
    b = sub.add_parser("build"); b.add_argument("storyboard"); b.add_argument("--out", required=True)
    b.add_argument("--verbose", action="store_true", help="print the full status table instead of the summary")
    b.add_argument("--no-tokens", action="store_true", help="the storyboard was written by a tool, not the model")
    g = sub.add_parser("styles", help="sample deck: every diagram style and point graphic, each a different picture")
    g.add_argument("--out", required=True)
    for fam_, help_ in (("timelines", "sample deck: every project timeline style"), ("swimlanes", "sample deck: every swimlane style"),
                        ("flows", "sample deck: every process flow style"),
                        ("retail", "sample deck: every retail diagram and retail process starter"),
                        ("infographics", "sample deck: every template infographic slide, filled")):
        f_ = sub.add_parser(fam_, help=help_); f_.add_argument("--out", required=True)
        f_.add_argument("--only", help="comma-separated style names (default: every style)")
    a = ap.parse_args()
    if a.cmd == "styles":
        sys.exit(styles_deck(a.out))
    if a.cmd in SAMPLE_DECKS:
        sys.exit(family_deck(SAMPLE_DECKS[a.cmd], a.out, [s.strip() for s in a.only.split(",")] if a.only else None))
    if a.cmd == "inventory":
        nums = a.slides or (None if a.all else BRAND.get("common_slides")) or list(range(1, len(Presentation(str(REF)).slides) + 1))
        inventory(nums) if a.full else compact(nums, menu=not a.slides)
    else:
        sys.exit(build(a.storyboard, a.out, a.verbose, not a.no_tokens))


if __name__ == "__main__":
    main()
