"""Retail diagrams drawn natively in the Ulta template's visual language (tools/native_draw.py) with retail pictograms
(tools/pictograms.py): the supply chain with its trucks and DCs, the ways an online order reaches the guest, the flow
through a DC and the documents an order or a finance process leaves behind. Named starters (STARTERS) give a ready
slide for the common retail processes - supply chain, DC operations, replenishment, order to cash, returns, procure to
pay, three-way match, month-end close and more - in this family or as a process flow with pictograms.

Storyboard slide:   {"retail": {...}, "style": "<style>", "headline": "<takeaway>", "notes": "..."}
                    {"retail": "<starter>", "headline": "<takeaway>"}       a starter, filled with standard steps
Data (a node, path or document: {"title", "text", "icon", "value"} or "Title: text"):
  network           {"nodes": [...], "lanes": [{"mode": "truck|ship|plane|van|none", "label": "..."}],
                     "branch": {"from": <node number or title>, "nodes": [...], "lanes": [...]}}
  fulfilment        {"order": {...}, "router": {...}, "paths": [{"title", "text", "from": "dc", "mode": "truck",
                     "to": "home", "promise": "2-5 days"}]}
  dc-flow           {"inbound": {...}, "zones": [...], "outbound": {...}, "crossdock": "the flow that skips storage"}
  cross-dock        {"sources": [...], "steps": [...], "destinations": [...], "dock": {"title": "Cross-dock"},
                     "note": "No storage: cartons go door to door"}
  document-flow     {"documents": [{"title", "text", "event": "what creates it", "owner": "who or which system"}]}
  icon              a pictogram (truck, dc, store, vendor, home, invoice, po ...) or one of the template's icons;
                    left out, the words pick one (a different one for each node)

Styles (STYLES, gallery order) - when to use them and their limits:
  network           the supply chain: vendors, DCs, stores and guests left to right, each lane with its vehicle
                    and a label; a branch row below for a second path (e-commerce from the DC to the home)
                    - 3-6 nodes, a branch of 1-3
  fulfilment        one online order routed to 2-4 ways of reaching the guest (ship from DC, ship from store, pick up
                    in store, same day): each path a from -> vehicle -> to picture, its name and its promise
  dc-flow           inside a DC: inbound trucks at the doors on the left, 3-6 zones in order (receive, put away,
                    pick, pack, ship), outbound trucks on the right, an optional cross-dock path
  cross-dock        many in, many out, nothing stored: 2-4 sources (vendors, import containers, other DCs) truck in
                    at the inbound doors, the dock's 2-5 steps (receive, sort by store, stage, load), 2-4 store
                    routes truck out from the outbound doors
  document-flow     the documents of a process in order (purchase order, ship notice, goods receipt, invoice,
                    payment): each a paper card under the event that creates it, its owner below - 3-6 documents

    import retail as RT
    spec = RT.expand(spec)                    # a starter name -> its full slide
    problems = RT.lint(spec) + RT.draw(slide, box, spec)
    python tools/retail.py starters           # the starters;  python tools/retail.py starter procure-to-pay
"""
import copy
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # run on its own (python -I too): its sibling modules
import flows as FL
import native_draw as ND
import pictograms as PG
import timelines as TL

IN = ND.IN
_in, _para = TL._in, TL._para

STYLES = {
    "network": "The supply chain: vendors, DCs, stores and guests left to right, each lane with its vehicle (truck, "
               "ship, plane, van) and a label; a branch row below for a second path (3-6 nodes, a branch of 1-3)",
    "fulfilment": "One online order routed to 2-4 ways of reaching the guest, each a from -> vehicle -> to picture "
                  "with its name and promise",
    "dc-flow": "Inside a DC: inbound trucks at the doors, 3-6 zones in order, outbound trucks, an optional cross-dock "
               "path",
    "cross-dock": "Many in, many out, nothing stored: 2-4 sources truck in at the inbound doors, the dock's 2-5 steps "
                  "(receive, sort, stage, load), 2-4 store routes truck out",
    "document-flow": "The documents of a process in order, each a paper card under the event that creates it, its "
                     "owner below (3-6 documents)",
}
LIMITS = {"network": (3, 6), "fulfilment": (2, 4), "dc-flow": (3, 6), "cross-dock": (2, 5), "document-flow": (3, 6)}
DENSE_LIMITS = {"network": (3, 6), "fulfilment": (2, 5), "dc-flow": (3, 7), "cross-dock": (2, 5),
                "document-flow": (3, 7)}
SIDES = (2, 4)                                                  # a cross-dock's sources and destinations
VEHICLES = ("truck", "van", "ship", "plane")


def is_dense(spec):
    return FL.is_dense(spec)


# ============================================================================================ data
def _words(t):
    return len(str(t or "").split())


def _item(v):
    """A node, zone or document from a dict or a 'Title: text' string."""
    s = FL._step(v)
    if isinstance(v, dict):
        for k in ("event", "promise", "from", "to", "mode"):
            s[k] = str(v.get(k) or "").strip()
        s["from"], s["to"], s["mode"] = s["from"].lower(), s["to"].lower(), s["mode"].lower()
    else:
        s.update(event="", promise="", to="", mode="")
        s["from"] = ""
    return s


def _lane(v, nxt=None):
    """A lane: {"mode", "label"}, or a label (its vehicle from its words; a truck when they name none)."""
    if isinstance(v, dict):
        mode = str(v.get("mode") or v.get("vehicle") or "").strip().lower()
        label = str(v.get("label") or v.get("text") or "").strip()
    else:
        label, mode = str(v or "").strip(), ""
    if not mode:                                                # walking in needs no vehicle; the last mile a van
        found = [n for n in PG.ranked(label) if n in VEHICLES]
        to = (nxt or {}).get("icon")
        mode = found[0] if found else ("van" if to == "home" else "none" if to in ("person", "team", "bag") else "truck")
    return {"mode": mode, "label": label}


def _data(data):
    if isinstance(data, list):
        data = {"nodes": data}
    if not isinstance(data, dict):
        return None
    many = lambda k: data.get(k) if isinstance(data.get(k), list) else []
    R = {"nodes": [_item(x) for x in data.get("nodes") or data.get("tiers") or [] if x],
         "zones": [_item(x) for x in data.get("zones") or data.get("steps") or [] if x],
         "sources": [_item(x) for x in data.get("sources") or many("inbound") if x],
         "destinations": [_item(x) for x in data.get("destinations") or many("outbound") if x],
         "documents": [_item(x) for x in data.get("documents") or data.get("docs") or [] if x],
         "paths": [_item(x) for x in data.get("paths") or [] if x]}
    for k in ("order", "router", "inbound", "outbound", "dock"):
        R[k] = _item(data[k]) if isinstance(data.get(k), (dict, str)) and data.get(k) else None
    R["note"] = str(data.get("note") or "").strip()
    cd = data.get("crossdock") or data.get("cross_dock")
    R["crossdock"] = (_item(cd) if isinstance(cd, dict) else {"title": "Cross-dock", "text": str(cd).strip(),
                                                              "icon": ""}) if cd else None
    br = data.get("branch")
    R["branch"] = None
    if isinstance(br, dict) and br.get("nodes"):
        R["branch"] = {"from": br.get("from", 1), "to": br.get("to"), "nodes": [_item(x) for x in br["nodes"] if x],
                       "lanes_raw": br.get("lanes") or []}
    _icons(R)
    lanes = data.get("lanes") or []
    n = len(R["nodes"])
    R["lanes"] = [_lane(lanes[k] if k < len(lanes) else "", R["nodes"][k + 1]) for k in range(max(0, n - 1))]
    R["extra_lanes"] = max(0, len(lanes) - max(0, n - 1))
    if R["branch"]:
        b = R["branch"]
        to = _branch_to(R)
        ends = b["nodes"] + ([R["nodes"][to]] if to is not None else [])   # a branch that rejoins: one lane more
        b["lanes"] = [_lane(b["lanes_raw"][k] if k < len(b["lanes_raw"]) else "", ends[k]) for k in range(len(ends))]
    return R


def _icons(R):
    """Every node, zone, document and path end gets a pictogram: its own, else the one its words call for."""
    groups = [R["nodes"] + (R["branch"]["nodes"] if R["branch"] else []), R["zones"], R["documents"],
              R["sources"] + R["destinations"], [x for x in (R["order"], R["inbound"], R["outbound"]) if x]]
    for items in groups:
        for s, n in zip(items, PG.assign([(s["title"], s["text"], s["icon"]) for s in items])):
            s["icon"] = s["icon"] or n
    if R["router"] and not R["router"]["icon"]:
        R["router"]["icon"] = "gears"
    for p in R["paths"]:                                        # from the DC or a store, to the home or the
        words = f"{p['title']} {p['text']}"                     # guest's bag at the counter (pick up: no vehicle)
        pick_up = re.search(r"(?i)\b(pick ?up|pickup|bopis|curbside|collect)\b", words)
        p["from"] = p["from"] or ("store" if pick_up or re.search(r"(?i)\bstores?\b", words) else "dc")
        p["to"] = p["to"] or ("bag" if pick_up else "home")
        if not p["mode"]:
            found = [n for n in PG.ranked(words) if n in VEHICLES]
            p["mode"] = "none" if pick_up else (found[0] if found else "truck")


def auto_style(data):
    R = _data(data) or {}
    if R.get("paths"):
        return "fulfilment"
    if R.get("sources") or R.get("destinations"):
        return "cross-dock"
    if R.get("zones"):
        return "dc-flow"
    if R.get("documents"):
        return "document-flow"
    return "network"


# ============================================================================================ lint
def lint(spec):
    """Content problems for the slide's style - each says how to fix it."""
    spec = spec or {}
    if isinstance(spec.get("retail"), str):
        return [f"there is no retail starter '{spec['retail']}' - use one of: {', '.join(STARTERS)}"]
    R = _data(spec.get("retail"))
    if R is None:
        return ["\"retail\" needs an object ({\"nodes\": [...]} for a supply chain) or a starter name: "
                + ", ".join(STARTERS)]
    style = spec.get("style") or auto_style(spec.get("retail"))
    if style not in STYLES:
        return [f"retail style '{style}' does not exist - use one of: {', '.join(STYLES)}"]
    P = []
    d = is_dense(spec)
    lo, hi = (DENSE_LIMITS if d else LIMITS)[style]
    grow = (lambda v: round(v * 1.8)) if d else (lambda v: v)
    key = KEYS[style]
    items = R[key]
    if not lo <= len(items) <= hi:
        P.append(f"{len(items)} {key} - the {style} style shows {lo}-{hi}" +
                 (FL.HINT if len(items) > hi and not d else ""))
    if any(not s["title"] for s in items):
        P.append(f"one of the {key} has no title - give each a 1-4 word \"title\"")
    cap = grow({"network": 12, "fulfilment": 12, "dc-flow": 10, "cross-dock": 6, "document-flow": 12}[style])
    long_x = [s for s in items if _words(s["text"]) > cap]
    if long_x:
        P.append(f"'{long_x[0]['title'][:30]}': its text is {_words(long_x[0]['text'])} words - the {style} style "
                 f"gives each {cap} (the detail goes in the speaker notes)" + ("" if d else FL.HINT))
    long_t = [s for s in items if _words(s["title"]) > 4]
    if long_t:
        P.append(f"'{long_t[0]['title'][:40]}' is {_words(long_t[0]['title'])} words - name it in 1-4 words")
    if style == "network":
        if R["extra_lanes"]:
            P.append(f"{len(R['nodes']) - 1 + R['extra_lanes']} lanes for {len(R['nodes'])} nodes - a lane joins two "
                     f"nodes next to each other ({len(R['nodes']) - 1} lanes)")
        if any(_words(l_["label"]) > (8 if d else 5) for l_ in R["lanes"]):
            P.append(f"keep each lane label to {8 if d else 5} words (\"Nightly store trucks\")")
        b = R["branch"]
        if b:
            fr = _branch_from(R)
            if fr is None:
                P.append(f"the branch starts from '{b['from']}' - name one of the nodes (its title or number 1-"
                         f"{len(R['nodes'])})")
            elif b.get("to") not in (None, ""):
                if _branch_to(R) is None:
                    P.append(f"the branch rejoins at '{b['to']}' - name a node to the right of '{b['from']}' (its "
                             f"title or number)")
                elif not 1 <= len(b["nodes"]) <= 2:
                    P.append(f"a branch that rejoins the top row holds 1-2 nodes (it has {len(b['nodes'])})")
            elif not 1 <= len(b["nodes"]) <= len(R["nodes"]) - 1 - fr:
                P.append(f"the branch has {len(b['nodes'])} nodes - from node {fr + 1} there is room for "
                         f"{max(0, len(R['nodes']) - 1 - fr)} (one under each node to its right)")
    if style == "cross-dock":
        for k, what in (("sources", "sources (vendors, import containers, other DCs)"),
                        ("destinations", "destinations (store routes, regions)")):
            if not SIDES[0] <= len(R[k]) <= SIDES[1]:
                P.append(f"{len(R[k])} {k} - a cross-dock shows {SIDES[0]}-{SIDES[1]} {what} (\"{k}\": [...])")
            if any(_words(s["text"]) > grow(6) for s in R[k]):
                P.append(f"keep the text of each of the {k} to {grow(6)} words")
        if _words(R["note"]) > grow(10):
            P.append(f"the note is {_words(R['note'])} words - keep it to {grow(10)}")
    if style == "fulfilment":
        if any(_words(p["promise"]) > 3 for p in R["paths"]):
            P.append("keep each path's promise to 1-3 words (\"2-5 days\", \"Same day\")")
    if style == "document-flow" and any(_words(s["event"]) > (5 if d else 3) for s in R["documents"]):
        P.append(f"keep each document's event to {5 if d else 3} words (\"Vendor ships\")")
    names = [s["icon"] for s in items + R["nodes"] + (R["branch"]["nodes"] if R["branch"] else []) + R["sources"] +
             R["destinations"] if s["icon"]]
    names += [l_["mode"] for l_ in R["lanes"] + (R["branch"]["lanes"] if R["branch"] else []) if l_["mode"] != "none"]
    names += [x for p in R["paths"] for x in (p["from"], p["to"], p["mode"]) if x and x != "none"]
    bad = [n for n in names if not PG.known(n)]
    if bad:
        P.append(f"there is no icon '{bad[0]}' - name a pictogram ({', '.join(PG.NAMES[:12])} ...: python "
                 "tools/pictograms.py lists them) or leave it out (the words pick one)")
    return P


def _node_at(R, f):
    """A top-row node by its number (1-n) or its title; None when there is none."""
    if f is None or f == "":
        return None
    if isinstance(f, int) or (isinstance(f, str) and f.strip().isdigit()):
        k = int(f) - 1
        return k if 0 <= k < len(R["nodes"]) else None
    t = str(f).strip().lower()
    return next((k for k, s in enumerate(R["nodes"]) if s["title"].lower() == t), None)


def _branch_from(R):
    return _node_at(R, R["branch"]["from"])


def _branch_to(R):
    """The node a branch rejoins (a bypass: the cross-dock path beside the DC), right of where it starts; else None."""
    b = R["branch"]
    to, fr = _node_at(R, b.get("to")), _branch_from(R)
    return to if to is not None and fr is not None and to > fr else None


KEYS = {"network": "nodes", "fulfilment": "paths", "dc-flow": "zones", "cross-dock": "zones", "document-flow": "documents"}


# ============================================================================================ drawing helpers
ROAD = 0.15                                                     # a lane's road (inches)


def _disc(C, cx, cy, d, i, icon, fill=None, name="node"):
    f = fill or ND.accent(i)
    sh = C.dot(cx, cy, d, f, name=name)
    PG.icon(C, icon, cx, cy, d * 0.56, colour=ND.WHITE, bg=f)
    return sh


def _road(C, pts, name="lane"):
    """A road through pts (a rose band with a white dashed centre line): the lane trucks drive on."""
    FL._polyline(C, pts, ND.ROSE_TINT, ROAD * 72, name=name)
    ND._line(FL._polyline(C, pts, ND.WHITE, 1.25, name=f"{name} centre line"), ND.WHITE, 1.25, dash="DASH")


def _chip(C, cx, cy, d, mode, name="vehicle"):
    """The lane's vehicle: its pictogram in plum on a white circle sitting on the road."""
    sh = C.dot(cx, cy, d, ND.WHITE, name=name)
    PG.icon(C, mode, cx, cy, d * 0.66, colour=ND.PLUM, bg=ND.WHITE)
    return sh


def _end(C, x, y, angle=0, name="lane end"):
    FL._pointer(C, x, y, _in(0.22), _in(ROAD + 0.2), angle, ND.ROSE_TINT, name=name)


def _label(C, x, y, w, h, parts, what, align="c", anchor="t", name="label"):
    C.text(x, y, w, h, parts, align=align, anchor=anchor, name=name)
    C.check(TL._paras(parts), int(w), int(h), what, ml=0.04, mt=0.02)


def _node_parts(s, tp, xp):
    out = [_para(s["title"], tp, True, ND.INK, False)]
    if s["text"]:
        out.append(_para(s["text"], xp, False, ND.INK, True))
    return out


SIZES = ((14, 12), (12, 12), (12, 10.5))
LARGE = ((18, 14),) + SIZES                                     # a roomy diagram: the template's sub-headline size


def _fit(items, w, room, dense, parts=_node_parts, sizes=SIZES):
    """The largest (title, text) sizes at which every item's label fits w x room; and the tallest need."""
    sizes = sizes if dense else sizes[:-1]
    for tp, xp in sizes:
        needs = [FL._need(parts(s, tp, xp), w, 0.04, 0.02) for s in items]
        if all(n is not None and n <= room for n in needs):
            return (tp, xp), max(needs or [0])
    tp, xp = sizes[-1]
    return (tp, xp), max((FL._need(parts(s, tp, xp), w, 0.04, 0.02) or room) for s in items)


def _value_h(items):
    return _in(0.48) if any(s["value"] for s in items) else 0


def _value(C, x, y, w, s, name):
    v = s["value"]
    if not v:
        return
    pt = next((p_ for p_ in (28, 24, 20) if TL._tw(v, p_, face=ND.DISPLAY) <= w - _in(0.08)), 20)
    if TL._tw(v, pt, face=ND.DISPLAY) > w - _in(0.08):
        C.P.append(f"'{s['title'][:30]}': the number '{v}' is too wide - write it short (600+, 1.2M)")
    t = C.text(x, y, w, _in(0.46), [_para(v, pt, False, ND.PLUM, False)], align="c", anchor="b", name=name)
    C.face(t, v)


def _lane_label(C, cx, y_bottom, w, label, pt, name):
    if not label:
        return
    p = [_para(label, pt, True, ND.PLUM, False)]
    need = FL._need(p, w, 0.04, 0.02) or _in(0.5)
    _label(C, cx - w / 2, y_bottom - need, w, need, p, f"lane '{label[:30]}'", anchor="b", name=name)


# ============================================================================================ network
def _draw_network(C, R):
    bx, by, bw, bh = C.box
    nodes, lanes, br = R["nodes"], R["lanes"], R["branch"]
    n = len(nodes)
    pitch = bw / n
    two = bool(br) and _branch_from(R) is not None
    d = _in({3: 1.15, 4: 1.05, 5: 0.92, 6: 0.82}.get(n, 0.82) * 0.86) if two else \
        _in({3: 1.4, 4: 1.3, 5: 1.08, 6: 0.92}.get(n, 0.92))
    chip = _in(0.5 if n <= 4 or two else 0.46) * (1.0 if two else 1.16)
    lw = pitch - _in(0.22)
    lpt = 10.5 if C.dense else 12
    lane_w = pitch - d - _in(0.16)
    lab_need = max([FL._need([_para(l_["label"], lpt, True)], lane_w, 0.04, 0.02) or 0 for l_ in lanes +
                    (br["lanes"] if two else []) if l_["label"]] or [0])
    above = max(d / 2, chip / 2 + _in(0.06) + lab_need)         # from a row's top to its disc centre
    allnodes = nodes + (br["nodes"] if two else [])
    vh = _value_h(allnodes)
    rows = 2 if two else 1
    room = (bh - rows * (above + d / 2 + _in(0.12) + vh) - (_in(0.12) if two else 0)) / rows
    size, need = _fit(allnodes, lw, room, C.dense, sizes=SIZES if two or n > 5 else LARGE)
    row_h = above + d / 2 + _in(0.12) + vh + need
    y0 = FL._top(C, rows * row_h + (_in(0.12) if two else 0))

    def row(items, ls, yc, xs, cols, name):
        for k in range(len(items) - 1):
            a, b = xs[k] + d / 2 + _in(0.06), xs[k + 1] - d / 2 - _in(0.08)
            _lane_seg(C, a, b, yc, ls[k + 1] if name == "Branch" else ls[k], chip, lpt, f"{name} lane {k + 1}")
        for k, s in enumerate(items):
            _disc(C, xs[k], yc, d, cols[k], s["icon"], name=f"{name} node {k + 1}")
            y = yc + d / 2 + _in(0.12)
            _value(C, xs[k] - lw / 2, y, lw, s, f"{name} node {k + 1} number")
            _label(C, xs[k] - lw / 2, y + vh, lw, need, _node_parts(s, *size), f"node '{s['title'][:30]}'",
                   name=f"{name} node {k + 1} label")
        return xs

    yc1 = y0 + above
    xs = row(nodes, lanes, yc1, [bx + pitch * (c + 0.5) for c in range(n)], list(range(n)), "Node")
    if two:
        fr, to = _branch_from(R), _branch_to(R)
        m = len(br["nodes"])
        yc2 = y0 + row_h + _in(0.12) + above
        if to is None:                                          # under the last nodes, ending where the top row ends
            cols = list(range(n - m, n))
            x2 = [bx + pitch * (c + 0.5) for c in cols]
        else:                                                   # a bypass: between where it leaves and rejoins
            cols = [fr + 1 + j for j in range(m)]
            x2 = [xs[fr] + (xs[to] - xs[fr]) * (j + 1) / (m + 1) for j in range(m)]
        row(br["nodes"], br["lanes"], yc2, x2, cols, "Branch")
        top = yc1 + d / 2 + _in(0.12) + vh + need + _in(0.04)    # under the branching node's words
        x_in = x2[0] - d / 2 - _in(0.08)
        pts = [(xs[fr], top), (xs[fr], yc2), (x_in, yc2)]
        _road(C, pts, name="Branch lane 1")
        _end(C, x_in - _in(0.08), yc2, 0, name="Branch lane 1 end")
        mid = (xs[fr] + x_in) / 2 if x_in - xs[fr] > chip * 1.6 else xs[fr]
        cy_chip = yc2 if mid != xs[fr] else (top + yc2) / 2
        _chip(C, mid, cy_chip, chip, br["lanes"][0]["mode"], name="Branch lane 1 vehicle") \
            if br["lanes"][0]["mode"] != "none" else None
        lab_w = min(x_in - xs[fr] - _in(0.2), lw) if mid != xs[fr] else lw
        _lane_label(C, mid, cy_chip - chip / 2 - _in(0.06), max(lab_w, _in(1.0)), br["lanes"][0]["label"], lpt,
                    "Branch lane 1 label")
        if to is not None:                                      # back up into the node it rejoins, under its words
            lane = br["lanes"][m]
            x_out = x2[-1] + d / 2 + _in(0.06)
            nm = f"Branch lane {m + 1}"
            _road(C, [(x_out, yc2), (xs[to], yc2), (xs[to], top + _in(0.14))], name=nm)
            _end(C, xs[to], top + _in(0.1), -90, name=f"{nm} end")
            mid = (x_out + xs[to]) / 2
            if lane["mode"] != "none":
                _chip(C, mid, yc2, chip, lane["mode"], name=f"{nm} vehicle")
            _lane_label(C, mid, yc2 - (chip / 2 if lane["mode"] != "none" else _in(ROAD / 2)) - _in(0.06),
                        max(min(xs[to] - x_out - _in(0.2), lw), _in(1.0)), lane["label"], lpt, f"{nm} label")


def _lane_seg(C, a, b, yc, lane, chip, lpt, name):
    """A straight lane from x=a to x=b at yc: the road, its end pointer, the vehicle in the middle, its label above."""
    _road(C, [(a, yc), (b - _in(0.12), yc)], name=name)
    _end(C, b - _in(0.1), yc, 0, name=f"{name} end")
    mid = (a + b) / 2
    if lane["mode"] != "none":
        _chip(C, mid, yc, chip, lane["mode"], name=f"{name} vehicle")
    _lane_label(C, mid, yc - (chip / 2 if lane["mode"] != "none" else _in(ROAD / 2)) - _in(0.06),
                max(b - a + _in(0.1), _in(0.9)), lane["label"], lpt, f"{name} label")


# ============================================================================================ fulfilment
def _draw_fulfilment(C, R):
    bx, by, bw, bh = C.box
    paths = R["paths"]
    k = len(paths)
    order = R["order"] or {"title": "Online order", "text": "", "icon": "web", "value": ""}
    router = R["router"] or {"title": "Order routing", "text": "", "icon": "gears", "value": ""}
    ow = _in(1.7)
    d = _in(1.1)
    ocx = bx + ow / 2
    rw, rx = _in(2.3), bx + ow + _in(0.55)
    cx0 = rx + rw + _in(0.62)                                   # the path cards
    cw = bx + bw - cx0
    gap = _in(0.16)
    ch = min(_in(1.15), (bh - gap * (k - 1)) / k)
    tot = k * ch + (k - 1) * gap
    y0 = by + (bh - tot) / 2
    cy = by + bh / 2
    # the order
    osize, oneed = _fit([order], ow, bh / 2 - d / 2, C.dense)
    _disc(C, ocx, cy - oneed / 2 - _in(0.06), d, 0, order["icon"], name="Order")
    oy = cy - oneed / 2 + d / 2 + _in(0.06)
    _label(C, bx, oy, ow, oneed, _node_parts(order, *osize), "the order", name="Order label")
    # the router: magenta, its icon above its words
    rh = min(bh * 0.6, _in(2.4))
    r = FL._focus(C, rx, cy - rh / 2, rw, rh, router, "Order routing")
    _road(C, [(ocx + d / 2 + _in(0.06), cy - oneed / 2 - _in(0.06)), (rx - _in(0.2), cy - oneed / 2 - _in(0.06))],
          name="Order lane")
    _end(C, rx - _in(0.16), cy - oneed / 2 - _in(0.06), 0, name="Order lane end")
    # the paths: from -> vehicle -> to, the name and text, the promise
    pd = min(_in(0.62), ch - _in(0.3))
    pill_w = max([TL._tw(p["promise"], 12, True) + _in(0.36) for p in paths if p["promise"]] or [0])
    pill_w = min(pill_w, _in(1.6))
    flow_w = _in(2.5)
    tx = cx0 + _in(0.2) + flow_w + _in(0.2)
    tw = cx0 + cw - tx - (pill_w + _in(0.3) if pill_w else _in(0.15))
    psize, pneed = _fit(paths, tw, ch - _in(0.16), C.dense)
    for i, p in enumerate(paths):
        y = y0 + i * (ch + gap)
        card = C.rect(cx0, y, cw, ch, ND.WHITE, r=0.08, name=f"Path {i + 1}")
        C.rect(cx0, y, _in(0.08), ch, ND.accent(i), r=None, name=f"Path {i + 1} colour")
        C.add(ND.connect(C.sl, r, card, "right", "left", colour=ND.MUTED, width=1.25, arrow=True, elbow=True,
                         name=f"Path {i + 1} flow"))
        fx, tx_ = cx0 + _in(0.3) + pd / 2, cx0 + _in(0.2) + flow_w - pd / 2
        my = y + ch / 2
        if p["mode"] != "none":
            FL._polyline(C, [(fx + pd / 2, my), (tx_ - pd / 2 - _in(0.04), my)], ND.ROSE_TINT, 5.0,
                         name=f"Path {i + 1} lane")
            _chip(C, (fx + tx_) / 2, my, min(_in(0.44), ch - _in(0.4)), p["mode"], name=f"Path {i + 1} vehicle")
        else:
            FL._polyline(C, [(fx + pd / 2, my), (tx_ - pd / 2 - _in(0.04), my)], ND.ROSE_TINT, 5.0,
                         name=f"Path {i + 1} lane")
        _disc(C, fx, my, pd, i, p["from"], name=f"Path {i + 1} from")
        _disc(C, tx_, my, pd, i, p["to"], fill=ND.PLUM, name=f"Path {i + 1} to")
        _label(C, tx, y + (ch - pneed) / 2, tw, pneed, _node_parts(p, *psize), f"path '{p['title'][:30]}'",
               align="l", name=f"Path {i + 1} words")
        if p["promise"]:
            pl = C.rect(cx0 + cw - pill_w - _in(0.18), my - _in(0.19), pill_w, _in(0.38), "ACCENT_2", r=0.19,
                        name=f"Path {i + 1} promise")
            C.write(pl, [_para(p["promise"], 12, True, ND.WHITE, False)], align="c", anchor="m", ml=0.04, mt=0.0)
            C.check([(p["promise"], 12, True, None)], int(pill_w), _in(0.38), f"promise '{p['promise']}'", ml=0.04,
                    mt=0.0)


# ============================================================================================ dc-flow
def _building(C, x0, x1, y0, yw, wall_h, name):
    """A white building with a low roof (its ridge at y0, its walls from yw, wall_h tall)."""
    fb = C.sl.shapes.build_freeform(int(x0), int(yw), scale=1.0)
    fb.add_line_segments([(int((x0 + x1) / 2), int(y0)), (int(x1), int(yw)), (int(x1), int(yw + wall_h)),
                          (int(x0), int(yw + wall_h))], close=True)
    bld = fb.convert_to_shape()
    ND._set_fill(bld.fill, ND.WHITE)
    ND._line(bld, None)
    ND.no_effects(bld)
    bld.name = name
    return C.add(bld)


def _draw_dc_flow(C, R):
    bx, by, bw, bh = C.box
    zones = R["zones"]
    n = len(zones)
    side = _in(1.75)                                            # the trucks outside the building, each side
    x0, x1 = bx + side, bx + bw - side
    roof = _in(0.55)
    cd = R["crossdock"]
    cd_h = _in(0.62) if cd else 0
    d = _in(0.8 if n <= 5 else 0.7)
    pitch = (x1 - x0 - _in(0.3)) / n
    lw = pitch - _in(0.14)
    room = bh - roof - _in(0.3) - d - _in(0.14) - cd_h - _in(0.2)
    size, need = _fit(zones, lw, room, C.dense)
    wall_h = _in(0.25) + d + _in(0.14) + need + cd_h + _in(0.22)
    y0 = FL._top(C, roof + wall_h)
    yw = y0 + roof                                              # the walls' top
    _building(C, x0, x1, y0, yw, wall_h, "DC building")
    doors = 3 if wall_h > _in(2.4) else 2
    dh, dw = _in(0.42), _in(0.14)
    ys = [yw + wall_h * (k + 1) / (doors + 1) for k in range(doors)]
    for k, yy in enumerate(ys):
        C.rect(x0 - dw / 2, yy - dh / 2, dw, dh, ND.PLUM, r=None, name=f"Inbound door {k + 1}")
        C.rect(x1 - dw / 2, yy - dh / 2, dw, dh, ND.PLUM, r=None, name=f"Outbound door {k + 1}")
    # the zones in order, inside
    zy = yw + _in(0.25) + d / 2
    xs = [x0 + _in(0.15) + pitch * (k + 0.5) for k in range(n)]
    for k in range(n - 1):
        FL._pointer(C, (xs[k] + xs[k + 1]) / 2, zy, _in(0.2), _in(0.3), 0, ND.ROSE_TINT, name=f"Zone {k + 1} to {k + 2}")
    for k, z in enumerate(zones):
        _disc(C, xs[k], zy, d, k, z["icon"], name=f"Zone {k + 1}")
        _label(C, xs[k] - lw / 2, zy + d / 2 + _in(0.12), lw, need, _node_parts(z, *size), f"zone '{z['title'][:30]}'",
               name=f"Zone {k + 1} label")
    if cd:                                                      # cross-dock: straight from the first zone to the last
        cy = yw + wall_h - _in(0.22) - cd_h / 2
        C.add(ND.line(C.sl, int(xs[0]), int(cy), int(xs[-1]), int(cy), colour=ND.PLUM, width=1.5, dash="DASH",
                      tail="triangle", name="Cross-dock path"))
        p = [_para(cd["title"] + (": " if cd["text"] else ""), 12, True, ND.PLUM, False)] + \
            ([_para(cd["text"], 12, False, ND.PLUM, False)] if cd["text"] else [])
        w = min(xs[-1] - xs[0] - _in(0.4), _in(5.2))
        lb = C.rect((xs[0] + xs[-1]) / 2 - w / 2, cy - _in(0.2), w, _in(0.4), ND.WHITE, r=None, name="Cross-dock label")
        C.write(lb, p, align="c", anchor="m", ml=0.06, mt=0.0)
        C.check(TL._paras(p), int(w), _in(0.4), "the cross-dock line", ml=0.06, mt=0.0)
    # the yards outside: trucks arriving on the left, leaving on the right
    yw_ = side - _in(0.28)
    for x, s, nm in ((bx, R["inbound"], "Inbound"), (bx + bw - yw_, R["outbound"], "Outbound")):
        s = s or {"title": nm, "text": "", "icon": "truck", "value": ""}
        C.rect(x, yw, yw_, wall_h, ND.PINK_TINT, r=0.08, name=f"{nm} yard")
        ic = _in(0.9)
        PG.icon(C, s["icon"] if s["icon"] in VEHICLES else "truck", x + yw_ / 2, yw + _in(0.2) + ic / 2, ic,
                colour=ND.PLUM, bg=ND.PINK_TINT)
        ssize, sneed = _fit([s], yw_ - _in(0.12), wall_h - ic - _in(0.5), C.dense)
        _label(C, x + _in(0.06), yw + ic + _in(0.32), yw_ - _in(0.12), sneed, _node_parts(s, *ssize),
               f"'{s['title'][:30]}'", name=f"{nm} label")


# ============================================================================================ cross-dock
def _draw_cross_dock(C, R):
    """Many in, many out, nothing stored: each source's truck reaches an inbound door on the left wall, the doors fan in
    to the dock's first step, the steps run left to right, the last fans out to the outbound doors on the right wall and
    a truck takes each store route away."""
    bx, by, bw, bh = C.box
    src, steps, dst = R["sources"], R["zones"], R["destinations"]
    ni, no, k = len(src), len(dst), len(steps)
    ds, gap_l = _in(0.62), _in(0.1)                             # a side circle, the gap to its words
    lab_w = _in(1.3)
    road = _in(1.32)                                            # room for the truck on each lane
    side = ds + gap_l + lab_w
    x0, x1 = bx + side + road, bx + bw - side - road            # the walls
    roof = _in(0.5)
    dock = R["dock"] or {"title": "Cross-dock", "text": "", "icon": "", "value": ""}
    note_p = [_para(R["note"], 12, True, ND.PLUM, False)] if R["note"] else []
    note_w = x1 - x0 - _in(0.4)
    note_h = min(_in(0.62), FL._need(note_p, note_w, 0.04, 0.02) or _in(0.62)) + _in(0.08) if note_p else 0
    ssize, sneed = _fit(src + dst, lab_w, _in(1.2), C.dense)
    row_h = max(ds, sneed) + _in(0.22)
    fan = _in(0.55)                                             # the room the doors fan in (and out) across
    pitch = (x1 - x0 - 2 * fan) / k
    d = _in(0.74 if k <= 4 else 0.64)
    lw = pitch - _in(0.12)
    size, need = _fit(steps, lw, _in(1.4), C.dense)
    steps_h = d + _in(0.12) + need
    wall_h = min(bh - roof, max(max(ni, no) * row_h, steps_h + _in(0.6)) + note_h + _in(0.16))
    y0 = FL._top(C, roof + wall_h)
    yw = y0 + roof
    _building(C, x0, x1, y0, yw, wall_h, "Cross-dock building")
    tp = [_para(dock["title"], 14, True, ND.PLUM, False)]       # its name in the gable
    gw = min(_in(2.6), (x1 - x0) * 0.4)
    _label(C, (x0 + x1) / 2 - gw / 2, y0 + roof * 0.28, gw, roof * 0.7, tp, "the dock's name", anchor="m",
           name="Cross-dock name")
    inner = wall_h - note_h - _in(0.08)
    cy = yw + (inner - steps_h) / 2 + d / 2                     # the steps, in the middle of the floor
    xs = [x0 + fan + pitch * (j + 0.5) for j in range(k)]
    discs = []
    for j in range(k - 1):
        FL._pointer(C, (xs[j] + xs[j + 1]) / 2, cy, _in(0.2), _in(0.3), 0, ND.ROSE_TINT, name=f"Step {j + 1} to {j + 2}")
    for j, s in enumerate(steps):
        discs.append(_disc(C, xs[j], cy, d, j, s["icon"], name=f"Dock step {j + 1}"))
        _label(C, xs[j] - lw / 2, cy + d / 2 + _in(0.12), lw, need, _node_parts(s, *size),
               f"step '{s['title'][:30]}'", name=f"Dock step {j + 1} label")
    dh, dw = _in(0.42), _in(0.14)
    chip = _in(0.42)

    def doors(items, x_wall, side_name):
        ys = [yw + inner * (j + 0.5) / len(items) for j in range(len(items))]
        return ys, [C.rect(x_wall - dw / 2, y - dh / 2, dw, dh, ND.PLUM, r=None, name=f"{side_name} door {j + 1}")
                    for j, y in enumerate(ys)]

    ys_in, d_in = doors(src, x0, "Inbound")
    ys_out, d_out = doors(dst, x1, "Outbound")
    jin = C.dot(x0 + fan * 0.55, cy, _in(0.16), ND.PLUM, name="Inbound join")
    jout = C.dot(x1 - fan * 0.55, cy, _in(0.16), ND.PLUM, name="Outbound split")
    for j, dr in enumerate(d_in):
        C.add(ND.connect(C.sl, dr, jin, "right", "left", colour=ND.MUTED, width=1.25, arrow=False, elbow=True,
                         name=f"Inbound door {j + 1} flow"))
    C.add(ND.connect(C.sl, jin, discs[0], "right", "left", colour=ND.PLUM, width=1.75, arrow=True, name="Into the dock"))
    C.add(ND.connect(C.sl, discs[-1], jout, "right", "left", colour=ND.PLUM, width=1.75, arrow=False,
                     name="Out of the dock"))
    for j, dr in enumerate(d_out):
        C.add(ND.connect(C.sl, jout, dr, "right", "left", colour=ND.MUTED, width=1.25, arrow=True, elbow=True,
                         name=f"Outbound door {j + 1} flow"))
    # the sources' trucks in, the store routes' trucks out
    for j, (s, y) in enumerate(zip(src, ys_in)):
        cx = bx + ds / 2
        _disc(C, cx, y, ds, j, s["icon"], name=f"Source {j + 1}")
        _label(C, cx + ds / 2 + gap_l, y - sneed / 2, lab_w, sneed, _node_parts(s, *ssize), f"'{s['title'][:30]}'",
               align="l", name=f"Source {j + 1} label")
        a, b = bx + side + _in(0.06), x0 - dw / 2 - _in(0.06)
        _road(C, [(a, y), (b - _in(0.12), y)], name=f"Source {j + 1} lane")
        _end(C, b - _in(0.1), y, 0, name=f"Source {j + 1} lane end")
        _chip(C, (a + b) / 2, y, chip, "truck", name=f"Source {j + 1} truck")
    for j, (s, y) in enumerate(zip(dst, ys_out)):
        cx = bx + bw - side + ds / 2
        _disc(C, cx, y, ds, j, s["icon"], fill=ND.PLUM, name=f"Destination {j + 1}")
        _label(C, cx + ds / 2 + gap_l, y - sneed / 2, lab_w, sneed, _node_parts(s, *ssize), f"'{s['title'][:30]}'",
               align="l", name=f"Destination {j + 1} label")
        a, b = x1 + dw / 2 + _in(0.06), cx - ds / 2 - _in(0.06)
        _road(C, [(a, y), (b - _in(0.12), y)], name=f"Destination {j + 1} lane")
        _end(C, b - _in(0.1), y, 0, name=f"Destination {j + 1} lane end")
        _chip(C, (a + b) / 2, y, chip, "truck", name=f"Destination {j + 1} truck")
    if note_p:                                                  # what makes it a cross-dock, along the floor
        _label(C, x0 + _in(0.2), yw + wall_h - note_h - _in(0.06), note_w, note_h, note_p, "the note", anchor="m",
               name="Cross-dock note")


# ============================================================================================ document-flow
def _draw_document_flow(C, R):
    bx, by, bw, bh = C.box
    docs = R["documents"]
    n = len(docs)
    link = _in(0.5)
    w = (bw - link * (n - 1)) / n
    pill = _in(0.4)
    any_ev = any(s["event"] for s in docs)
    any_own = any(s["owner"] for s in docs)
    own_h = _in(0.5) if any_own else 0
    icon = _in(0.5)
    inner = w - _in(0.24)
    room = bh - (pill + _in(0.14) if any_ev else 0) - own_h - icon - _in(0.5)
    parts = lambda s, tp, xp: [_para(s["title"], tp, True, ND.INK, False)] + \
        ([_para(s["text"], xp, False, ND.INK, True)] if s["text"] else [])
    size, need = _fit(docs, inner, room, C.dense, parts)
    card_h = min(room + icon + _in(0.5), max(need + icon + _in(0.62), _in(2.0)))
    tot = (pill + _in(0.14) if any_ev else 0) + card_h + own_h
    y0 = FL._top(C, tot)
    yc = y0 + (pill + _in(0.14) if any_ev else 0)
    for i, s in enumerate(docs):
        x = bx + i * (w + link)
        if any_ev and s["event"]:
            pl = C.rect(x, y0, w, pill, ND.PLUM, r=pill / IN / 2, name=f"Document {i + 1} event")
            p = [_para(s["event"], 12, True, ND.WHITE, False)]
            C.write(pl, p, align="c", anchor="m", ml=0.08, mt=0.0)
            C.check(TL._paras(p), int(w), int(pill), f"event '{s['event'][:30]}'", ml=0.08, mt=0.0)
        card = ND.shape(C.sl, "FOLDED_CORNER", int(x), int(yc), int(w), int(card_h), fill=ND.WHITE, line=ND.LINE,
                        line_w=0.75, name=f"Document {i + 1}")
        av = card._element.spPr.find(f"{ND.A}prstGeom/{ND.A}avLst")
        if av is not None:                                      # a smaller fold than the preset's (python-pptx lists
            av.append(ND.etree.fromstring(f'<a:gd xmlns:a="{ND.A[1:-1]}" name="adj" fmla="val 11000"/>'))  # no handle)
        C.add(card)
        C.top_rounded(x, yc, w, _in(FL.BAR), ND.accent(i), 0.0, name=f"Document {i + 1} colour")
        PG.icon(C, s["icon"], x + _in(0.12) + icon / 2, yc + _in(0.2) + icon / 2, icon, colour=ND.accent(i),
                bg=ND.WHITE)
        p = parts(s, *size)
        _label(C, x + _in(0.08), yc + _in(0.3) + icon, w - _in(0.16), card_h - icon - _in(0.5), p,
               f"document '{s['title'][:30]}'", align="l", name=f"Document {i + 1} words")
        if s["owner"]:
            op = [_para(s["owner"], 12, False, ND.MUTED, False)]
            _label(C, x, yc + card_h + _in(0.06), w, own_h - _in(0.06), op, f"owner '{s['owner'][:30]}'",
                   name=f"Document {i + 1} owner")
        if i < n - 1:
            FL._link_arrow(C, x + w + _in(0.1), yc + card_h / 2, link - _in(0.2), _in(0.42),
                           name=f"Document {i + 1} to {i + 2}")


DRAW = {"network": _draw_network, "fulfilment": _draw_fulfilment, "dc-flow": _draw_dc_flow,
        "cross-dock": _draw_cross_dock, "document-flow": _draw_document_flow}


def draw(slide, box, spec):
    """Draw the retail diagram into box (x, y, w, h EMU) on a title-only slide; returns problems (empty = fine)."""
    spec = spec or {}
    R = _data(spec.get("retail"))
    style = spec.get("style") or auto_style(spec.get("retail"))
    if R is None or style not in DRAW:
        return [f"retail style '{style}' does not exist - use one of: {', '.join(STYLES)}"] if R is not None else \
            ["\"retail\" needs an object: {\"nodes\": [...]}"]
    key = KEYS[style]
    if not R[key]:
        return [f"retail diagram not drawn: it has no {key}"]
    C = TL._Canvas(slide, tuple(int(v) for v in box))
    C.dense = is_dense(spec)
    frame = C.box
    try:
        DRAW[style](C, R)
    except Exception as e:                                      # never break the build: report and leave the slide
        import traceback
        tb = traceback.extract_tb(e.__traceback__)[-1]
        for sh in C.shapes:
            sh._element.getparent().remove(sh._element)
        return [f"retail style '{style}' could not be drawn ({type(e).__name__}: {str(e)[:60]}, line {tb.lineno}) "
                "- check the counts and words"]
    bx, by, bw, bh = frame
    tol = _in(0.02)
    for sh in C.shapes:
        if sh.left < bx - tol or sh.top < by - tol or sh.left + sh.width > bx + bw + tol or \
                sh.top + sh.height > by + bh + tol:
            C.P.append(f"'{sh.name}' runs outside the content frame - use fewer items or shorter text")
            break
    C.group(f"Retail ({style})")
    return list(dict.fromkeys(C.P))


# ============================================================================================ starters
def _flow(style, steps, headline, notes, **extra):
    return {"process": dict({"icons": "auto", "steps": steps}, **extra), "style": style, "headline": headline,
            "notes": notes}


STARTERS = {
    "supply-chain": {
        "retail": {"nodes": [{"title": "Vendors", "text": "Brand partners make and ship product"},
                             {"title": "DCs", "text": "Receive, store and pick store orders"},
                             {"title": "Stores", "text": "Shelves filled from store deliveries"},
                             {"title": "Guests", "text": "Shop in store or pick up online orders"}],
                   "lanes": [{"mode": "truck", "label": "Inbound freight"}, {"mode": "truck", "label": "Store deliveries"},
                             {"mode": "none", "label": "Shop in store"}],
                   "branch": {"from": "DCs", "nodes": [{"title": "Fulfillment center",
                                                         "text": "Online orders picked and packed"},
                                                        {"title": "Guest's home", "text": "Parcels delivered to the door"}],
                              "lanes": [{"mode": "truck", "label": "Replenishment"},
                                        {"mode": "van", "label": "Parcel carrier"}]}},
        "style": "network", "headline": "One network of DCs serves stores and online guests",
        "notes": "The end-to-end supply chain: the store path on top, the e-commerce path below. Add counts (\"value\": "
                 "the number of DCs or stores) from your own data."},
    "supply-chain-cross-dock": {
        "retail": {"nodes": [{"title": "Vendors", "text": "Brand partners ship to us"},
                             {"title": "DCs", "text": "Stored, then picked by store order"},
                             {"title": "Stores", "text": "Shelves filled from each delivery"},
                             {"title": "Guests", "text": "Buy in store or pick up online orders"}],
                   "lanes": [{"mode": "truck", "label": "Bulk freight"}, {"mode": "truck", "label": "Store deliveries"},
                             {"mode": "none", "label": "In store"}],
                   "branch": {"from": "Vendors", "to": "Stores",
                              "nodes": [{"title": "Cross-dock", "text": "Sorted by store, never stored",
                                         "icon": "shuffle"}],
                              "lanes": [{"mode": "truck", "label": "Cartons labeled by store"},
                                        {"mode": "truck", "label": "Store loads"}]}},
        "style": "network", "headline": "Stocked and flow-through freight take two paths to stores",
        "notes": "The stocked path stores product in the DC and picks it by store order; the flow-through path sorts "
                 "cartons the vendor labeled by store straight onto outbound trucks at the cross-dock. Add each path's "
                 "share of volume and its lead time from your own data."},
    "import-flow": {
        "retail": {"nodes": [{"title": "Vendor", "text": "Goods ready at the factory"},
                             {"title": "Origin port", "icon": "globe", "text": "Containers loaded for export"},
                             {"title": "Destination port", "icon": "location", "text": "Customs cleared on arrival"},
                             {"title": "DC", "text": "Containers unloaded and received"},
                             {"title": "Stores", "text": "Product on the shelf"}],
                   "lanes": [{"mode": "truck", "label": "Origin trucking"}, {"mode": "ship", "label": "Ocean freight"},
                             {"mode": "truck", "label": "Drayage"}, {"mode": "truck", "label": "Store deliveries"}]},
        "style": "network", "headline": "Imported product crosses four lanes to reach a store",
        "notes": "An import moves by truck, ship and truck again before the DC. Add transit times from your own lanes."},
    "dc-operations": {
        "retail": {"inbound": {"title": "Inbound", "text": "Vendor trailers by appointment"},
                   "zones": [{"title": "Receive", "text": "Cartons scanned against the ship notice"},
                             {"title": "Put away", "text": "Pallets moved to storage locations"},
                             {"title": "Pick", "text": "Store and online orders picked by wave"},
                             {"title": "Pack", "text": "Totes and parcels sealed and labeled"},
                             {"title": "Ship", "text": "Loaded by route and carrier"}],
                   "outbound": {"title": "Outbound", "text": "Store trucks and parcel carriers"},
                   "crossdock": "Flow-through cartons skip storage"},
        "style": "dc-flow", "headline": "Five zones turn vendor trailers into store deliveries",
        "notes": "Inside the DC from the inbound doors to the outbound doors; cross-dock skips storage."},
    "cross-dock": {
        "retail": {"sources": [{"title": "Vendors", "text": "Cartons labeled by store"},
                               {"title": "Import containers", "text": "Unloaded on arrival"},
                               {"title": "Other DCs", "text": "Transfers between DCs"}],
                   "steps": [{"title": "Receive", "text": "Scanned at the inbound door", "icon": "scan"},
                             {"title": "Sort", "text": "Routed to its store lane", "icon": "shuffle"},
                             {"title": "Stage", "text": "Store loads built by route"},
                             {"title": "Load", "text": "Loaded by delivery stop"}],
                   "destinations": [{"title": "East stores"}, {"title": "Central stores"}, {"title": "West stores"}],
                   "note": "No storage: inbound door to outbound door"},
        "style": "cross-dock", "headline": "Cartons cross the dock to stores without being stored",
        "notes": "A cross-dock: many sources in, many store routes out, nothing put away. Pre-allocated (flow-through): "
                 "the vendor labels each carton for its store; post-allocated: the DC allocates after receipt. Say which "
                 "one applies, and add the dwell time and volumes from your own data."},
    "store-replenishment": _flow("cycle", [
        {"title": "Forecast", "text": "Demand by store and item"},
        {"title": "Order", "text": "Store orders built from the forecast and stock on hand"},
        {"title": "Pick", "text": "The DC picks store orders by wave"},
        {"title": "Deliver", "text": "Trucks arrive on the store's delivery days"},
        {"title": "Receive", "text": "The store scans the delivery in"},
        {"title": "Shelve", "text": "Product on the shelf for the guest"}],
        "Six steps keep store shelves full", "The replenishment loop repeats on every delivery cycle.",
        center="Store replenishment"),
    "omnichannel-fulfilment": {
        "retail": {"order": {"title": "Online order", "text": "App or website"},
                   "router": {"title": "Order routing", "text": "Best source by stock, distance and cost"},
                   "paths": [{"title": "Ship from DC", "text": "Standard delivery to the home"},
                             {"title": "Ship from store", "text": "Store stock sent by parcel carrier"},
                             {"title": "Buy online, pick up", "text": "Ready at the store counter"},
                             {"title": "Same-day delivery", "text": "Courier from a nearby store", "mode": "van"}]},
        "style": "fulfilment", "headline": "One online order can reach the guest four ways",
        "notes": "Add each path's promise (\"promise\": \"2-5 days\") from your own service levels."},
    "order-to-cash": _flow("arrow", [
        {"title": "Order", "text": "Guest checks out online or in the app", "icon": "cart"},
        {"title": "Authorize", "text": "Payment authorized on the card", "icon": "card"},
        {"title": "Route", "text": "Order sent to the best source", "icon": "dc"},
        {"title": "Pick and pack", "text": "Items picked, packed and labeled", "icon": "carton"},
        {"title": "Ship", "text": "The carrier collects the parcel", "icon": "truck"},
        {"title": "Deliver", "text": "The parcel reaches the guest", "icon": "home"},
        {"title": "Settle", "text": "Payment captured and settled", "icon": "bank"}],
        "Seven steps turn an online order into cash", "Order to cash for an online order, from checkout to settlement."),
    "returns": _flow("snake", [
        {"title": "Start", "text": "Guest starts a return online or in store", "icon": "returns"},
        {"title": "Take back", "text": "A store or the DC receives the item", "icon": "store"},
        {"title": "Refund", "text": "Refund to the original payment", "icon": "card"},
        {"title": "Inspect", "text": "Condition and seal checked", "icon": "search"},
        {"title": "Decide", "text": "Resell, return to vendor or dispose", "icon": "scales"},
        {"title": "Restock", "text": "Resellable items back in stock", "icon": "rack"},
        {"title": "Vendor credit", "text": "Vendor returns claimed against the vendor", "icon": "vendor"}],
        "A return takes seven steps to restock or vendor credit",
        "Reverse logistics: what happens after the guest hands an item back."),
    "procure-to-pay": {
        "retail": {"documents": [
            {"title": "Purchase order", "text": "Items, quantities, cost and dates", "event": "Buyer orders",
             "owner": "Merchandising"},
            {"title": "Ship notice", "text": "What is on the truck, by carton", "event": "Vendor ships", "owner": "Vendor"},
            {"title": "Goods receipt", "text": "What the DC counted in", "event": "DC receives", "owner": "DC receiving"},
            {"title": "Invoice", "text": "What the vendor bills", "event": "Vendor bills", "owner": "Accounts payable"},
            {"title": "Payment", "text": "Paid on terms after the match", "event": "AP pays", "owner": "Treasury"}]},
        "style": "document-flow", "headline": "Five documents take a purchase from order to payment",
        "notes": "Procure to pay as the documents it leaves behind; the payment waits for the three-way match."},
    "three-way-match": _flow("converge", [
        {"title": "Purchase order", "text": "What was ordered, at what cost"},
        {"title": "Goods receipt", "text": "What the DC received"},
        {"title": "Invoice", "text": "What the vendor billed"}],
        "Three documents must agree before a vendor is paid",
        "Quantities and costs must match within tolerance; exceptions go to accounts payable for review.",
        result={"title": "Three-way match", "text": "Paid when all three agree; exceptions reviewed", "icon": "check"}),
    "month-end-close": _flow("phases", [
        {"title": "Pre-close", "when": "Before month end", "items": ["Cut off receipts and shipments",
                                                                     "Review open purchase orders", "Accrue known costs"],
         "outcome": "Clean cut-off"},
        {"title": "Subledgers", "when": "Days 1-2", "items": ["Close payables and receivables", "Value inventory and shrink",
                                                              "Run depreciation"],
         "outcome": "Subledgers closed"},
        {"title": "Reconcile", "when": "Days 3-4", "items": ["Reconcile balance sheet accounts",
                                                             "Clear intercompany balances", "Explain variances"],
         "outcome": "Books balanced"},
        {"title": "Report", "when": "Day 5", "items": ["Consolidate the results", "Review with finance leaders",
                                                       "Issue the flash report"],
         "outcome": "Results reported"}],
        "The month-end close runs in four phases",
        "Set the days to your own close calendar.", icons=False),
    "record-to-report": _flow("chevrons", [
        {"title": "Record", "text": "Store, DC and online transactions post", "icon": "receipt-roll"},
        {"title": "Reconcile", "text": "Subledgers tie to the general ledger", "icon": "scales"},
        {"title": "Close", "text": "Accruals and adjustments booked", "icon": "ledger"},
        {"title": "Consolidate", "text": "Entities and eliminations combined", "icon": "office"},
        {"title": "Report", "text": "Results reported and explained", "icon": "bar-chart"}],
        "Five steps turn transactions into reported results", "Record to report, from posting to reported results."),
    "merchandise-planning": _flow("numbered", [
        {"title": "Financial plan", "text": "Sales, margin and inventory targets", "icon": "coin"},
        {"title": "Assortment", "text": "Which items go to which stores and channels", "icon": "shelf"},
        {"title": "Buy plan", "text": "Quantities and open-to-buy by month", "icon": "calculator"},
        {"title": "Orders", "text": "Purchase orders placed with vendors", "icon": "po"},
        {"title": "Allocate", "text": "First deliveries split across DCs and stores", "icon": "dc"},
        {"title": "In season", "text": "Sell-through, reorders and markdowns", "icon": "price"}],
        "Six planning steps turn targets into product on the shelf",
        "Merchandise planning from the financial plan to in-season management."),
    "vendor-onboarding": _flow("vertical", [
        {"title": "Set up", "text": "Company, tax and bank details reviewed and entered", "owner": "Vendor management",
         "icon": "vendor"},
        {"title": "Compliance", "text": "Product safety and ingredient documents checked", "owner": "Quality",
         "icon": "compliance"},
        {"title": "Connect", "text": "Electronic orders, ship notices and invoices tested", "owner": "Integration team",
         "icon": "network"},
        {"title": "Items", "text": "Items, costs, case packs and labels set up", "owner": "Merchandising",
         "icon": "scan"},
        {"title": "First order", "text": "A first purchase order placed and received", "owner": "Supply chain",
         "icon": "po"}],
        "Five steps make a new vendor ready for a first order", "Vendor onboarding, each step with its owner."),
    "inventory-count": _flow("chevrons", [
        {"title": "Plan", "text": "Count date set and the area frozen", "icon": "calendar"},
        {"title": "Count", "text": "Associates scan every location", "icon": "scan"},
        {"title": "Recount", "text": "Large differences counted again", "icon": "search"},
        {"title": "Reconcile", "text": "Counts compared with system stock", "icon": "scales"},
        {"title": "Post", "text": "Adjustments booked and shrink reported", "icon": "ledger"}],
        "Five steps turn a physical count into accurate stock", "A physical inventory or cycle count, end to end."),
    "markdown": _flow("numbered", [
        {"title": "Decide", "text": "Markdowns chosen from sell-through and stock", "icon": "bar-chart"},
        {"title": "Approve", "text": "Merchandising and finance sign off", "icon": "check"},
        {"title": "Release", "text": "New prices sent to stores and online", "icon": "web"},
        {"title": "Re-ticket", "text": "Stores change labels and signs", "icon": "price"},
        {"title": "Measure", "text": "Sales and margin tracked after the change", "icon": "trend-up"}],
        "Five steps take a markdown from decision to shelf", "A price change or markdown, from decision to results."),
    "inbound-to-dc": _flow("arrow", [
        {"title": "Order", "text": "Purchase order sent to the vendor", "icon": "po"},
        {"title": "Ship notice", "text": "Vendor sends what is on the truck", "icon": "invoice"},
        {"title": "Appointment", "text": "Dock time booked", "icon": "calendar"},
        {"title": "Unload", "text": "Trailer unloaded at the door", "icon": "truck"},
        {"title": "Receive", "text": "Cartons scanned against the notice", "icon": "scan"},
        {"title": "Put away", "text": "Stock moved to storage", "icon": "forklift"}],
        "Six steps bring vendor freight into the DC", "Inbound logistics, from the purchase order to storage."),
}
WHAT = {"supply-chain": "vendors, DCs, stores and guests, with the e-commerce path to the home (network)",
        "supply-chain-cross-dock": "the stocked path through the DC and the flow-through path through a cross-dock, "
                                   "vendors to stores (network)",
        "import-flow": "factory to store by truck, ocean and drayage (network)",
        "dc-operations": "inside the DC: receive, put away, pick, pack, ship, cross-dock (dc-flow)",
        "cross-dock": "inside the cross-dock: sources truck in, receive, sort by store, stage, load, store routes truck "
                      "out (cross-dock)",
        "store-replenishment": "the replenishment loop from forecast to shelf (process cycle)",
        "omnichannel-fulfilment": "one online order, four ways to the guest (fulfilment)",
        "order-to-cash": "an online order from checkout to settlement (process arrow)",
        "returns": "a return from the guest to restock or vendor credit (process snake)",
        "procure-to-pay": "purchase order, ship notice, goods receipt, invoice, payment (document-flow)",
        "three-way-match": "order, receipt and invoice agree before payment (process converge)",
        "month-end-close": "pre-close, subledgers, reconcile, report (process phases)",
        "record-to-report": "from posting to reported results (process chevrons)",
        "merchandise-planning": "financial plan to in-season markdowns (process numbered)",
        "vendor-onboarding": "set up, compliance, connection, items, first order (process vertical)",
        "inventory-count": "a physical count from plan to posted adjustments (process chevrons)",
        "markdown": "a price change from decision to results (process numbered)",
        "inbound-to-dc": "vendor freight from the order to storage (process arrow)"}


def expand(spec):
    """A slide naming a starter ({"retail": "procure-to-pay", "headline": ...}) -> the starter's full slide; the
    slide's own keys (headline, notes, style, density ...) win. Anything else comes back as it is."""
    if not isinstance(spec, dict) or not isinstance(spec.get("retail"), str):
        return spec
    name = spec["retail"].strip().lower().replace(" ", "-").replace("_", "-")
    name = {"omnichannel-fulfillment": "omnichannel-fulfilment", "p2p": "procure-to-pay", "o2c": "order-to-cash",
            "r2r": "record-to-report", "close": "month-end-close", "3-way-match": "three-way-match",
            "crossdock": "cross-dock", "cross-docking": "cross-dock", "flow-through": "cross-dock"}.get(name, name)
    if name not in STARTERS:
        return spec
    out = copy.deepcopy(STARTERS[name])
    out.update({k: v for k, v in spec.items() if k != "retail"})
    return out


# ============================================================================================ retail first
# A slide whose content is a supply chain or a retail process is shown as a retail diagram first (SKILL.md rule 10).
# fit() names the retail form a storyboard slide's words call for: with the slide laid out in it when its own items
# fit (every word kept, the build sets it), else the shape or starter to start from (the expert review says it).
_kinds = lambda *pairs: [(n, re.compile(rf"(?i)\b(?:{p})\b")) for n, p in pairs]
CHAINS = {                                  # what each form strings together, in the order goods, papers or work move
    "network": _kinds(("vendor", r"vendors?|suppliers?|manufacturers?|factor(?:y|ies)|brand partners?|mills?"),
                      ("port", r"(?:origin |destination |import )?ports?|customs|consolidators?"),
                      ("dc", r"r?dcs?|distribution cent(?:er|re)s?|warehouses?|fulfil+ment cent(?:er|re)s?|fcs?|"
                             r"depots?|cross[- ]?docks?|hubs?"),
                      ("store", r"stores?|shops?|salons?|boutiques?"),
                      ("guest", r"guests?|customers?|shoppers?|consumers?|homes?|doorsteps?")),
    "dc-flow": _kinds(("arrive", r"check[- ]?in|arrivals?|yard|dock appointments?|unload(?:ing)?"),
                      ("receive", r"receiv(?:e|ing)|inspect(?:ion)?|quality checks?"),
                      ("store", r"put[- ]?away|storage|reserve|slot(?:ting)?|replenish(?:ment)?"),
                      ("pick", r"pick(?:ing)?|waves?"),
                      ("pack", r"pack(?:ing)?|cartoni[sz]ation|value[- ]added services|vas|kitting"),
                      ("sort", r"sort(?:ing|ation)?|stag(?:e|ing)|consolidat(?:e|ion)"),
                      ("ship", r"ship(?:ping)?|load(?:ing)?|dispatch|manifest(?:ing)?")),
    "document-flow": _kinds(("request", r"requisitions?|purchase requests?|quotes?|rfqs?|contracts?"),
                            ("order", r"purchase orders?|pos?|sales orders?"),
                            ("notice", r"(?:advance )?ship(?:ping|ment)? notices?|asns?|bills? of lading|bols?|"
                                       r"packing (?:slips?|lists?)|delivery notes?"),
                            ("receipt", r"goods receipts?|receiving reports?|grs?|grns?|proofs? of delivery|pods?"),
                            ("invoice", r"invoices?|vendor bills?|credit memos?|debit memos?"),
                            ("payment", r"payments?|remittances?|settlements?")),
}
PATH = re.compile(r"(?i)\b(?:ship(?:ped|s)? (?:from|to) (?:the )?(?:dcs?|stores?|warehouses?|home|vendors?)|"
                  r"(?:buy online,? )?pick[- ]?up(?: in store)?|bopis|curbside|(?:same|next)[- ]day(?: delivery)?|"
                  r"home delivery|drop[- ]?ship|lockers?)\b")       # a way an online order reaches the guest
DC_WORDS = re.compile(r"(?i)\b(?:r?dcs?|distribution cent\w+|warehouses?|fulfil+ment cent\w+|cross[- ]?dock\w*)\b")
ORDERED = re.compile(r"(?i)\b(?:steps?|process|flow|journey|pipeline|phases?|stages?|cycle|loop|life ?cycle|"
                     r"end[- ]to[- ]end|from .+ to|to (?:cash|pay|report|shelf|door|store|home|guest))\b")
MOVES = re.compile(r"(?i)\b(?:ship\w*|deliver\w*|trucks?|freight|transport\w*|moves?|flows?|reach\w*|routes?|"
                   r"replenish\w*|inbound|outbound|lanes?|sends?|arriv\w+|carr(?:y|ies|ier|iers))\b")
CORE = ("truck", "van", "ship", "plane", "dc", "store", "vendor", "home", "carton", "pallet", "rack", "forklift", "cart",
        "returns", "invoice", "po", "ledger", "receipt-roll", "bank", "card", "cash", "price", "scan")
CUES = {                                    # a starter, when the slide's headline names its process
    "supply-chain-cross-dock": r"cross[- ]?dock\w*.{0,60}\b(?:stock|stored|dcs?)\b|(?:stocked|stored).{0,60}"
                               r"\bflow[- ]through",
    "cross-dock": r"cross[- ]?dock\w*|flow[- ]through",
    "import-flow": r"imports?|ocean|containers?|customs|drayage|ports?",
    "omnichannel-fulfilment": r"omni[- ]?channel|ship from store|pick ?up in store|bopis|curbside|same[- ]day",
    "dc-operations": r"inside the (?:dc|warehouse)|dc operations|warehouse operations|put[- ]?away",
    "inbound-to-dc": r"inbound|dock appointments?|vendor freight",
    "store-replenishment": r"replenish\w*",
    "three-way-match": r"(?:three|3)[- ]way match\w*",
    "procure-to-pay": r"procure[- ]to[- ]pay|p2p|purchase orders?",
    "order-to-cash": r"order[- ]to[- ]cash|o2c",
    "returns": r"returns?|refunds?|reverse logistics",
    "month-end-close": r"month[- ]end|period[- ]end|close calendar|the close",
    "record-to-report": r"record[- ]to[- ]report|r2r",
    "merchandise-planning": r"open[- ]to[- ]buy|assortment plan\w*|merchandise plan\w*|buy plans?",
    "vendor-onboarding": r"(?:vendor|supplier) (?:onboarding|set[- ]?up)|onboard\w* (?:new )?(?:vendors?|suppliers?)",
    "inventory-count": r"cycle counts?|physical (?:inventory|counts?)|stock ?takes?",
    "markdown": r"markdowns?|price changes?",
    "supply-chain": r"supply chain|logistics network|(?:dc|distribution) network",
}
CUES = {k: re.compile(rf"(?i)\b(?:{v})\b") for k, v in CUES.items()}
KEEP = {"headline", "title", "subtitle", "notes", "summary", "decision", "density", "continues", "id", "classification",
        "owner", "source_doc"}                  # what a slide re-laid in a retail form keeps as it is
SHAPES = {"network": '"retail": {"nodes": ["<node>: <one line>", ...], "lanes": [{"mode": "truck", "label": "<lane>"}, '
                     '...]}, "style": "network"',
          "dc-flow": '"retail": {"zones": ["<zone>: <one line>", ...]}, "style": "dc-flow"',
          "document-flow": '"retail": {"documents": [{"title": "<document>", "text": "<one line>", "event": "<who does '
                           'what>", "owner": "<team>"}, ...]}, "style": "document-flow"',
          "fulfilment": '"retail": {"paths": ["<path>: <one line>", ...]}, "style": "fulfilment"',
          "process": '"process": {"steps": ["<1-3 words>: <one line>", ...], "icons": "auto"}'}
FLOW_LINE = re.compile(r"^\s*(.+?)\s*(?:→|->|⇒)\s*(.+?)\s*(?::\s*(.*?))?\s*$")


def _slide_items(spec):
    """A slide's items in order, [(title, text)], how they are laid out ('points', 'flow', 'process', 'diagram'; a
    process with more than steps - a centre, a result, owners, values - 'process+') and, for a diagram, the labels of
    its flows; (None, None, None) for anything else. A diagram's items are the nodes of its chain (A -> B, B -> C)."""
    b = spec.get("bullets")
    if isinstance(b, list) and b:
        out = []
        for x in b:
            lead, text = ((x.get("lead"), x.get("text")) if isinstance(x, dict) else
                          str(x).split(": ", 1) if ": " in str(x) else (None, None))
            if not str(lead or "").strip():
                return None, None, None
            out.append((str(lead).strip(), str(text or "").strip()))
        return out, "points", None
    st = spec.get("steps")
    if isinstance(st, list) and st and all(isinstance(x, dict) for x in st):
        return [(str(x.get("label") or "").strip(), str(x.get("text") or "").strip()) for x in st], "flow", None
    if spec.get("process") is not None:
        D = FL._data(spec["process"])
        if not D or not D["steps"]:
            return None, None, None
        rich = any(D.get(k) for k in ("inputs", "outputs", "result", "source", "center")) or \
            any(s[k] for s in D["steps"] for k in ("owner", "value", "rate", "items", "when", "outcome"))
        return [(s["title"], s["text"]) for s in D["steps"]], "process+" if rich else "process", None
    d = spec.get("diagram")
    lines = d.splitlines() if isinstance(d, str) else [x for x in d if isinstance(x, str)] if isinstance(d, list) else []
    m = [FLOW_LINE.match(l) for l in lines if l.strip()]
    if len(m) >= 2 and all(m) and all(m[k].group(2).lower() == m[k + 1].group(1).lower() for k in range(len(m) - 1)):
        return [(x.strip(), "") for x in [m[0].group(1)] + [y.group(2) for y in m]], "diagram", \
            [y.group(3) or "" for y in m]
    return None, None, None


def _chain(items, form):
    """The items as one of the form's chains: each title names one of its kinds (in 1-4 words), in their order, at
    least three kinds; else None."""
    ranks = []
    for t, _ in items:
        r = next((k for k, (_, rx) in enumerate(CHAINS[form]) if rx.search(t)), None) if 1 <= _words(t) <= 4 else None
        if r is None:
            return None
        ranks.append(r)
    return ranks if all(a <= b for a, b in zip(ranks, ranks[1:])) and len(set(ranks)) >= 3 else None


def _pictured(items):
    """The retail pictogram each step's name calls for (None where it names none): 'Ship' a truck, 'Invoice' an
    invoice - a word of its detail alone ('terms loaded') makes no retail step."""
    out = []
    for t, _ in items:
        sc = {n: v for n, v in PG.scores(t).items() if n in CORE}
        out.append(max(sc, key=sc.get) if sc else None)
    return out


def fit(spec):
    """The retail form a slide calls for, or None: {"form": a retail style, "process" or a starter's name, "why": what
    in its words calls for it, "spec": the slide laid out in that form with every word kept (None when its items don't
    fit it as they are), "shape": the storyboard shape to start from}. A slide that is a retail diagram already, says
    "retail_first": false, or shows numbers, a chart, a table or a timeline is left alone."""
    if not isinstance(spec, dict) or spec.get("retail") is not None or spec.get("retail_first") is False:
        return None
    items, how, labels = _slide_items(spec)
    head = " ".join(str(spec.get("headline") or spec.get("title") or "").split())
    said = " ".join([head] + [f"{t} {x}" for t, x in items or []])
    item_keys = {"points": {"bullets", "plain", "numbered", "start", "source"}, "flow": {"steps", "source"},
                 "process": {"process", "style", "source"}, "diagram": {"diagram", "style", "source"}}.get(how, set())
    plain = how != "process+"                                   # (a cycle's centre or a converge's result stays)
    whole = not set(spec) - KEEP - item_keys                    # (nothing on the slide but its items: nothing is lost)
    keep = {k: v for k, v in spec.items() if k in KEEP}

    def made(new, form, why, same=False):                       # same: the slide itself, one key added
        problems = lint(new) if "retail" in new else FL.lint(new)
        return {"form": form, "why": why, "spec": new if (whole or same) and not problems else None,
                "shape": SHAPES[form]}
    if items:
        names = ", ".join(t for t, _ in items)
        lines = [f"{t}: {x}" if x else t for t, x in items]     # "Title: text", read as every step is (flows._step)
        ordered = how in ("flow", "process", "process+", "diagram") or bool(ORDERED.search(head)) or \
            sum(bool(re.match(r"(?i)(?:step|phase|stage|\d{1,2}[.):]?)\b", t)) for t, _ in items) >= 2
        ranks = plain and _chain(items, "network")
        if ranks and (ordered or MOVES.search(said) or len(set(ranks)) >= 4):
            data = {"nodes": lines}
            if labels:
                data["lanes"] = [{"label": l} for l in labels]
            return made(dict(keep, retail=data, style="network"), "network", f"{names} in order")
        ranks = plain and _chain(items, "dc-flow")
        if ranks and (len(set(ranks)) >= 4 or DC_WORDS.search(said)):
            return made(dict(keep, retail={"zones": lines}, style="dc-flow"), "dc-flow",
                        f"a DC's zones in order ({names})")
        if plain and _chain(items, "document-flow"):
            return made(dict(keep, retail={"documents": lines}, style="document-flow"), "document-flow",
                        f"the documents of a process in order ({names})")
        if len(items) >= 2 and how in ("points", "flow", "process") and all(PATH.search(t) for t, _ in items):
            return made(dict(keep, retail={"paths": lines}, style="fulfilment"), "fulfilment",
                        f"the ways an order reaches the guest ({names})")
        hit = [p for p in _pictured(items) if p]
        if ordered and len(items) >= 3 and len(hit) >= max(2, -(-len(items) * 3 // 5)) and len(set(hit)) >= 2:
            why = "steps of a retail process (" + ", ".join(dict.fromkeys(hit)) + ")"
            if how in ("process", "process+"):
                P = spec["process"]
                P = dict(P) if isinstance(P, dict) else {"steps": P}
                style = spec.get("style") or FL.auto_style(P)
                if P.get("icons") is not None or style not in FL.ICON_STYLES:
                    return None                                 # (pictograms already, or the author's choice)
                return made(dict(spec, process=dict(P, icons="auto")), "process", why, same=True)
            if how != "diagram":
                return made(dict(keep, process={"steps": lines, "icons": "auto"},
                                 style="chevrons" if len(items) <= 6 else "snake"), "process", why)
    m = next((m for m in (rx.search(head) for rx in CUES.values()) if m), None)
    if m and how in ("points", "flow", "process", "process+") and (how != "points" or ORDERED.search(head)):
        cue = next(k for k, rx in CUES.items() if rx.search(head))
        return {"form": cue, "why": f'its headline names "{m.group(0)}"', "spec": None,
                "shape": f'"retail": "{cue}" ({WHAT[cue]}; python tools/retail.py starter {cue} prints it to fill with '
                         "the slide's own words)"}
    return None


def sample():
    """One storyboard slide per style (sample content of the shape each needs), then every starter."""
    styles = [
        {"retail": {"nodes": [{"title": "Vendors", "text": "Brand partners in the US and abroad"},
                              {"title": "DCs", "text": "Regional distribution centers"},
                              {"title": "Stores", "text": "Replenished several times a week"},
                              {"title": "Guests", "text": "Shop in store or pick up orders"}],
                    "lanes": [{"mode": "ship", "label": "Ocean and truck inbound"},
                              {"mode": "truck", "label": "Nightly store trucks"}, {"mode": "none", "label": "In store"}]},
         "style": "network", "headline": "Product reaches guests through DCs and stores",
         "notes": "Network: nodes left to right, each lane with its vehicle and label (sample content)."},
        copy.deepcopy(STARTERS["omnichannel-fulfilment"]) | {
            "notes": "Fulfilment: one order routed to the ways it can reach the guest (sample content)."},
        copy.deepcopy(STARTERS["dc-operations"]) | {"notes": "DC flow: inside the DC, door to door (sample content)."},
        copy.deepcopy(STARTERS["cross-dock"]),
        copy.deepcopy(STARTERS["procure-to-pay"]) | {
            "notes": "Document flow: the documents a process leaves behind (sample content)."},
    ]
    return styles + [copy.deepcopy(STARTERS[k]) for k in STARTERS if k not in ("omnichannel-fulfilment",
                                                                                "dc-operations", "cross-dock",
                                                                                "procure-to-pay")]


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "starters":
        print("Retail starters ({\"retail\": \"<name>\", \"headline\": \"<takeaway>\"}; print one with: python "
              "tools/retail.py starter <name>):")
        for k in STARTERS:
            print(f"  {k:<23} {WHAT[k]}")
    elif len(sys.argv) > 2 and sys.argv[1] == "starter":
        s = expand({"retail": sys.argv[2]})
        print(json.dumps(s, indent=1) if not isinstance(s.get("retail"), str) else
              f"no starter '{sys.argv[2]}' - use one of: {', '.join(STARTERS)}")
    else:
        print(__doc__)
