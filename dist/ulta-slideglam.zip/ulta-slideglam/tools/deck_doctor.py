"""Deck doctor: score ANY deck on design as well as story, then rebuild it on the Ulta template the right way.

    python tools/deck_doctor.py Deck.pptx [--out /mnt/data/out/Deck-doctor.md]          scorecard only (read-only)
    python tools/deck_doctor.py Deck.pptx --fix /mnt/data/out/<Name>.pptx               + rebuilt deck

Scorecard = review_deck.py (story, numbers, dates, words, brand, compliance) + design checks per slide:
  wall of text (over 80 words), points stacked as plain lines (no bullets), a process typed as "A -> B -> C",
  numbers trapped in sentences (3+ figures - a chart would show them), tiny text (under 10 pt), fonts that are not
  the brand's, colours outside the brand palette, text boxes floating on shapes, pictures without alt text,
  one layout for most slides. Each slide gets the layout to use instead (cards, flow, modern chart, bullets ...).
--fix: convert_deck.py moves the content onto template slides (nothing invented), then the mechanical upgrades
are made here - an arrow chain becomes the flow slide, stacked lines become bullets - and the deck is built.
What still needs a writer (e.g. sentences that should become six cards, numbers that should become a chart) is
printed as TODO lines: edit those slides in <Name>-storyboard.json and rebuild with build_deck.py.
"""
import argparse, collections, json, re, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
FOOTER = re.compile(r"(?i)\|\s*(proprietary|confidential|internal|public|restricted)|^\s*page \d+")
ARROW = re.compile(r"\s*(?:→|->|⇒|>>)\s*")
FIG = re.compile(r"[$€£]?\d[\d,.]*\s?(?:%|[KMB]\b|pts?\b|million|billion)?")


def brand_sets():
    b = json.loads((TOOLS.parent / "brands" / "ulta" / "brand.json").read_text(encoding="utf-8"))
    pal = set(sum([b["palette"][k] for k in ("brand", "tints", "neutrals", "status")], [])) | set((b.get("theme") or {}).values())
    fonts = {f for f in (b.get("fonts") or {}).values() if isinstance(f, str)} | {"Circular Std", "Playfair Display"}
    try:                                                 # every colour the Ulta template itself uses is on brand
        import zipfile
        tp = TOOLS.parent.parent / "templates" / "Ulta Beauty PPT Standard.pptx"   # the Studio kit
        with zipfile.ZipFile(str(tp)) as z:
            for n_ in z.namelist():
                if n_.startswith("ppt/") and n_.endswith(".xml"):
                    pal |= set(re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', z.read(n_).decode("utf-8", "ignore")))
    except Exception:
        pass
    return {c.upper() for c in pal}, fonts


def scan(path):
    from pptx import Presentation
    from pptx.util import Emu
    prs = Presentation(str(path)); pal, fonts = brand_sets()
    slides, layouts = [], collections.Counter()
    for n, s in enumerate(prs.slides, 1):
        issues, todo = [], []
        texts = [sh for sh in s.shapes if sh.has_text_frame and sh.text_frame.text.strip()
                 and not FOOTER.search(sh.text_frame.text) and not re.fullmatch(r"\d{1,3}", sh.text_frame.text.strip())]
        top_zone = [sh for sh in texts if sh.top is not None and sh.top < prs.slide_height * 0.22]
        size = lambda sh: max([r.font.size.pt for p in sh.text_frame.paragraphs for r in p.runs if r.font.size] or [0])
        head = s.shapes.title if s.shapes.title is not None and s.shapes.title.has_text_frame and s.shapes.title.text_frame.text.strip() \
            else (next((sh for sh in top_zone if sh.is_placeholder), None) or (max(top_zone, key=size) if top_zone else None))
        if head is None:                                # the template's agenda slide sets "Agenda" beside the list, not on top
            head = next((sh for sh in texts if re.fullmatch(r"(?i)agenda|contents|today'?s agenda", sh.text_frame.text.strip())), None)
        title = head.text_frame.text.strip() if head is not None else ""
        boxes = [sh for sh in texts if sh is not head]
        words = sum(len(sh.text_frame.text.split()) for sh in boxes)
        ours = lambda sh: sh.name.lower().startswith(("diagram", "modern", "ulta", "point ", "highlight "))   # built and checked by this skill
        area = prs.slide_width * prs.slide_height
        edge = n in (1, len(prs.slides))                                              # cover and closing: their own rules
        big_empty = [sh for sh in boxes if not edge and not ours(sh) and sh.width and sh.height and sh.width * sh.height > 0.12 * area
                     and len(sh.text_frame.text.split()) < 15]
        if len(big_empty) >= 1 and words < 30:
            issues.append(f"{len(big_empty)} big box(es) mostly empty ({words} words)")
            todo.append("cards (7) or big numbers (9) - or merge with the next slide")
        has_table = any(getattr(sh, "has_table", False) and sh.has_table for sh in s.shapes)
        has_chart = any(getattr(sh, "has_chart", False) and sh.has_chart for sh in s.shapes)
        n_pic = sum(1 for sh in s.shapes if sh.shape_type == 13)
        n_shape = sum(1 for sh in s.shapes if sh.shape_type in (1, 5, 9) and not sh.has_text_frame or (sh.shape_type in (1, 5) and sh.has_text_frame))
        sig = (has_table, has_chart, n_pic > 2, min(len(boxes), 4), n_shape > 6)
        has_visual = any(sh.shape_type in (3, 13) or getattr(sh, "has_chart", False) for sh in s.shapes)   # chart / picture
        if words > 80:
            issues.append(f"wall of text ({words} words)"); todo.append("cut to the message; detail into the notes; cards (7) or bullets")
        for sh in boxes:
            paras = [p for p in sh.text_frame.paragraphs if p.text.strip()]
            ph_bul = sh.is_placeholder and sh.placeholder_format.type is not None and int(sh.placeholder_format.type) in (2, 7)  # body / object: bullets come from the layout
            bul = [p for p in paras if p._p.find(f"{A}pPr/{A}buChar") is not None or p._p.find(f"{A}pPr/{A}buAutoNum") is not None
                   or re.match(r"\s*(?:[•●▪■◦–\-*]|\d{1,2}[.)])\s", p.text)                     # typed "• " / "1. " points
                   or (ph_bul and p._p.find(f"{A}pPr/{A}buNone") is None)]
            if len(paras) >= 3 and not bul:
                issues.append(f"{len(paras)} points stacked as plain lines"); todo.append("bullets, or cards (7) for 3-6 short points")
            t = sh.text_frame.text
            if len(ARROW.split(t)) >= 3:
                issues.append("a process typed as arrows"); todo.append("flow slide (20) or a swimlane / chevron diagram")
            figs = [f for line in t.split("\n") for f in figures(line)]                     # not dates, years or list numbers
            if len(figs) >= 3 and not has_visual:
                issues.append(f"{len(figs)} figures inside sentences"); todo.append("a modern chart: kpi cards, lollipop, bullet or trend")
        small, odd_fonts = set(), set()
        for sh in boxes:
            for p in sh.text_frame.paragraphs:
                for r in p.runs:
                    if r.font.size is not None and r.font.size.pt < 10 and r.text.strip() and not ours(sh):
                        small.add(round(r.font.size.pt, 1))
                    if r.font.name and not any(r.font.name.startswith(f.split()[0]) for f in fonts) and not r.font.name.startswith("+"):
                        odd_fonts.add(r.font.name)
        if small:
            issues.append(f"tiny text ({', '.join(map(str, sorted(small)))} pt)"); todo.append("12 pt body minimum - split or cut")
        if odd_fonts:
            issues.append("fonts off brand: " + ", ".join(sorted(odd_fonts)[:3]))
        cols = {c.upper() for c in re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', s._element.xml)}
        near = lambda c: any(all(abs(int(c[i:i + 2], 16) - int(q[i:i + 2], 16)) <= 2 for i in (0, 2, 4)) for q in pal)
        off = sorted(c for c in cols - pal if not near(c))   # E8275B in the template = E8275A: a 1-step twin is on brand
        if off:
            issues.append(f"{len(off)} colour(s) off the brand palette")
        pics = [sh for sh in s.shapes if sh.shape_type == 13]
        def _alt(p):                                   # a file name or "Picture 3" is not alt text
            d = (p._element.xpath(".//p:cNvPr/@descr") or [""])[0].strip()
            return "" if re.fullmatch(r"(?i)(.*\.(png|jpe?g|gif|bmp|svg|emf|wmf|tiff?|webp)|(picture|image|graphic)\s*\d*|\w*\s*description automatically generated)", d.replace("\n", " ").strip()) else d
        tmpl_logo = lambda p: p.name.startswith("Grafický objekt") or re.fullmatch(r"Shape\s*Description automatically generated",
                                                                                 (p._element.xpath(".//p:cNvPr/@descr") or [""])[0].strip())
        noalt = [p for p in pics if not _alt(p) and not tmpl_logo(p)                 # the Ulta template's own logo: the template's alt text
                 and not any(w in p.name.lower() for w in ("logo", "icon", "ulta"))
                 and not (p.width < Emu(548640) and p.height < Emu(548640))]                      # small icons are decorative
        if noalt:                                       # accessibility applies to cover and closing too
            issues.append(f"{len(noalt)} picture(s) without alt text")
        filled = [sh for sh in s.shapes if not sh.has_text_frame or not sh.text_frame.text.strip()]
        floating = 0
        for sh in [b for b in boxes if not ours(b)]:
            for f in filled:
                if f.shape_type == 1 and f.left is not None and sh.left is not None and f.left <= sh.left and f.top <= sh.top \
                        and f.left + f.width >= sh.left + sh.width and f.top + f.height >= sh.top + sh.height:
                    floating += 1; break
        if floating:
            issues.append(f"{floating} text box(es) floating on shapes (move with the shape: put the text inside)")
        if not title and 1 < n < len(prs.slides):
            issues.append("no headline"); todo.append("a headline that states the message")
        if 1 < n < len(prs.slides):
            layouts[sig] += 1
        slides.append({"n": n, "title": title[:60], "words": words, "issues": issues, "todo": list(dict.fromkeys(todo)), "layout": s.slide_layout.name})
    deck = []
    content = sum(layouts.values())
    if content >= 4:
        sig, cnt = layouts.most_common(1)[0]
        if cnt / content > 0.5 and not sig[0] and not sig[1] and not sig[4]:
            deck.append(f"{cnt} of {content} content slides are the same text-box layout - vary: cards, numbers, flow, charts, diagrams")
    return slides, deck


def report(path, out=None):
    slides, deck = scan(path)
    rv = subprocess.run([sys.executable, str(TOOLS / "review_deck.py"), str(path)] + (["--out", str(out) + ".review.md"] if out else []),
                        capture_output=True, text=True)
    m = re.search(r"(?i)score\D{0,12}(\d{1,3})", rv.stdout)
    story = int(m.group(1)) if m else None
    pen = sum(min(len(s["issues"]), 4) * 7 for s in slides) + 10 * len(deck)
    design = max(0, 100 - pen)
    lines = [f"# Deck doctor - {Path(path).name}", "",
             f"**Design score {design}/100**" + (f" · **Story & compliance score {story}/100** (review_deck)" if story is not None else ""), ""]
    lines += [f"- {d}" for d in deck]
    lines += ["", "| Slide | Headline | Issues | Use instead |", "|---|---|---|---|"]
    for s in slides:
        if s["issues"]:
            lines.append(f"| {s['n']} | {s['title'] or '—'} | {'; '.join(s['issues'])} | {'; '.join(s['todo']) or 'fix as listed'} |")
    ok = [str(s["n"]) for s in slides if not s["issues"]]
    if ok:
        lines += ["", f"No design issues: slides {', '.join(ok)}."]
    if rv.stdout.strip():
        lines += ["", "## Story, numbers, brand and compliance (review_deck)", "", rv.stdout.strip()]
    text = "\n".join(lines)
    if out:
        Path(out).write_text(text, encoding="utf-8")
    return design, story, slides, deck, text


MONTHS = r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?"
DATE = re.compile(rf"\b{MONTHS}\s+\d{{1,2}}\b|\b\d{{1,2}}\s+{MONTHS}|\b\d{{1,2}}/\d{{1,2}}(?:/\d{{2,4}})?\b|\bQ[1-4]\b|\b(?:19|20)\d\d\b")


def figures(t):
    """Numbers a chart could show: not dates, years, quarters or a "1." list number."""
    t = DATE.sub(" ", re.sub(r"^\s*\d{1,2}[.)]\s", " ", str(t)))
    return [m.group(0) for m in FIG.finditer(t) if re.search(r"\d", m.group(0)) and len(m.group(0).strip(" .,")) > 1]


def chain(lines):
    """'A → B' lines that form one chain A → B → C … (3-6 steps) → the steps in order, else None."""
    pairs = [tuple(x.strip() for x in ARROW.split(re.sub(r":.*$", "", l))[:2]) for l in lines if len(ARROW.split(l)) == 2]
    if len(pairs) != len(lines) or not pairs: return None
    nxt = dict(pairs); starts = [a for a, _ in pairs if a not in {b for _, b in pairs}]
    if len(starts) != 1 or len(nxt) != len(pairs): return None
    out = [starts[0]]
    while out[-1] in nxt and len(out) <= 7: out.append(nxt[out[-1]])
    return out if 3 <= len(out) <= 6 and len(out) == len(pairs) + 1 else None


def upgrade(sb):
    """Mechanical upgrades on the converted storyboard; returns (storyboard, TODO lines)."""
    todo = []
    for k, s in enumerate(sb["slides"], 1):
        if str(s.get("source")) == "1":                # the Ulta cover has one text box: title only
            if len(str(s.get("title") or "")) > 55:
                todo.append(f"slide {k}: the cover title is {len(str(s['title']))} characters; the cover holds 55 - shorten it "
                            f"(e.g. drop a spelled-out name); the subtitle goes to the speaker notes")
            continue
        beside = s.pop("_beside", None)
        if beside:
            figs_ = sum(len(figures(t)) for t in beside)
            todo.append(f"slide {k}: {len(beside)} point(s) sat beside the chart (now in the notes)"
                        + (f" with {figs_} figures - give them a big-number slide (9) after this one" if figs_ >= 3 else
                           " - put the main one in the headline"))
        if re.fullmatch(r"(?i)\s*agenda\s*", str(s.get("headline") or "")) and isinstance(s.get("bullets"), list):
            items = [x[1] if isinstance(x, list) else x for x in s["bullets"]]
            if len(items) <= 5:                        # the template's own agenda slide (numbers are automatic)
                s.pop("bullets"); s.pop("headline"); s["source"] = 2; s["table"] = [[None, str(i)] for i in items]
            else:
                todo.append(f"slide {k}: the agenda has {len(items)} items; the template's agenda slide holds 5 - merge two "
                            f"(e.g. the last two) and give it as \"source\": 2, \"table\": [[null, \"Item\"], …]")
            continue
        if isinstance(s.get("diagram"), list):          # boxes and arrows in one line = a process: the flow slide
            steps = chain([str(x) for x in s["diagram"]])
            if steps:
                s.pop("diagram"); s.pop("style", None); s["source"] = 20
                s["steps"] = [{"label": f"Step {i}", "text": t} for i, t in enumerate(steps, 1)]
                continue
        texts = s.get("text") if isinstance(s.get("text"), list) else None
        if texts is None and isinstance(s.get("bullets"), list) and s.get("source") not in (1, 32, 33):
            flat_ = [x[1] if isinstance(x, list) else x for x in s["bullets"]]     # convert_deck hands text over as bullets
            if any(ARROW.search(str(t or "")) for t in flat_):
                joined = " → ".join(str(t) for t in flat_ if t)
                parts = [p.strip(" .") for p in ARROW.split(joined) if p.strip(" .")]
                if 3 <= len(parts) <= 6:
                    s.pop("bullets", None); s["source"] = 20
                    s["steps"] = [{"label": f"Step {i}", "text": p} for i, p in enumerate(parts, 1)]
                    continue
        if texts and s.get("source") not in (1, 32, 33):
            joined = " → ".join(t for t in texts if t)
            parts = [p.strip(" .") for p in ARROW.split(joined.replace("\n", " → ")) if p.strip(" .")]
            if len(parts) >= 3 and any(ARROW.search(t or "") for t in texts) and len(parts) <= 6:
                s.pop("text", None); s["source"] = 20
                s["steps"] = [{"label": f"Step {i}", "text": p} for i, p in enumerate(parts, 1)]
                continue
            lines = [l.strip() for t in texts for l in (t or "").split("\n") if l.strip()]
            if len(lines) >= 3:
                words = sum(len(l.split()) for l in lines)
                s.pop("text", None); s.pop("source", None); s["bullets"] = lines     # 2-6 points are drawn as tiles
        b = s.get("bullets")
        if isinstance(b, list):
            flat = [x[1] if isinstance(x, list) else x for x in b]
            figs = sum(len(figures(t)) for t in flat)
            dated = [t for t in flat if DATE.search(str(t))]
            if len(dated) >= 3:
                todo.append(f"slide {k}: {len(dated)} actions with dates - an action table (12: What | Description | When / Who), "
                            "one row each, the date in the last column")
            if figs >= 3:
                todo.append(f"slide {k}: {figs} figures in the bullets - show them as a modern chart (kpi / lollipop / bullet)")
            words = sum(len(str(t).split()) for t in flat)
            tops = [t for t in b if not (isinstance(t, list) and t and t[0])]
            if len(tops) == 1 and not any(t.startswith(f"slide {k}:") for t in todo):
                todo.append(f"slide {k}: one point is a statement - make it the headline, or merge it into the next slide")
            if len(tops) > 6 or words > 80 or any(len(str(t).split()) > 18 for t in flat):     # the build's own limits
                todo.append(f"slide {k}: too much text - 2-6 points (drawn as tiles), each written \"Lead: detail\" with a 1-3 "
                            "word lead and at most 15 words; split the slide or move the rest into the notes")
        if s.get("picture") and re.fullmatch(r"(?i)(.*\.(png|jpe?g|gif|bmp|svg|emf|wmf|tiff?|webp)|(picture|image|graphic)\s*\d*)?", str(s.get("alt") or "").strip()):
            todo.append(f"slide {k}: the picture has no real alt text (\"{s.get('alt') or ''}\") - write what it shows in \"alt\"")
    return sb, todo


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck"); ap.add_argument("--out"); ap.add_argument("--fix")
    a = ap.parse_args()
    design, story, slides, deck, text = report(a.deck, a.out)
    bad = [s for s in slides if s["issues"]]
    print(f"DESIGN SCORE {design}/100" + (f" · STORY & COMPLIANCE {story}/100" if story is not None else ""))
    for d in deck:
        print("  DECK " + d)
    for s in bad[:12]:
        print(f"  slide {s['n']}: {'; '.join(s['issues'])}" + (f"  ->  {'; '.join(s['todo'])}" if s["todo"] else ""))
    if a.out:
        print(f"REPORT {a.out}")
    if a.fix:
        out = Path(a.fix); out.parent.mkdir(parents=True, exist_ok=True)
        r = subprocess.run([sys.executable, str(TOOLS / "convert_deck.py"), a.deck, "--out", str(out)], capture_output=True, text=True)
        sp = out.with_name(out.stem + "-storyboard.json")
        if not sp.exists():
            print("FIX FAILED - convert_deck.py: " + (r.stdout + r.stderr).strip()[-300:]); sys.exit(1)
        sb, todo = upgrade(json.loads(sp.read_text(encoding="utf-8")))
        for s_ in sb.get("slides", []):                # absolute picture paths: the rebuild command works from any folder
            if isinstance(s_.get("picture"), str) and Path(s_["picture"]).exists():
                s_["picture"] = str(Path(s_["picture"]).resolve())
            ch_ = s_.get("chart")
            if isinstance(ch_, dict) and isinstance(ch_.get("data"), str) and Path(ch_["data"]).exists():
                ch_["data"] = str(Path(ch_["data"]).resolve())
        sp.write_text(json.dumps(sb, indent=1, ensure_ascii=False), encoding="utf-8")
        b = subprocess.run([sys.executable, str(TOOLS / "build_deck.py"), "build", str(sp), "--out", str(out)], capture_output=True, text=True)
        keep = [l for l in b.stdout.splitlines() if l.startswith(("READY", "DRAFT", "NEEDS")) or "FAIL" in l or l.startswith("RESULT")]
        print("\n".join(keep[:14]))
        for t in todo:
            print("  TODO " + t)
        print(f"STORYBOARD {sp} - finish the TODO / FAIL slides there (you write the words), then: build_deck.py build {sp.name} --out {out.name}")


if __name__ == "__main__":
    main()
