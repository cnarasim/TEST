"""Diagram pack: one list of flows -> diagram slide + relationship table slide + draw.io + Excel register, all consistent.
For any flows: systems, teams and hand-offs, approval chains, data feeds.

    python tools/diagram_pack.py flows.txt --title "Order platform" --out /mnt/data/out/Order-Platform [--style zones]
flows.txt, one per line (attributes in [ ] are optional and become table/Excel columns, not diagram text):
    Web portal → API gateway: orders [type=REST API; frequency=real time; owner=Digital team]
    Order service → Billing: invoice request [type=event; frequency=per order; owner=Finance IT]
Outputs: <out>.pptx (diagram + "who sends what" table), <out>-slide1.drawio, <out>-register.xlsx.
"""
import argparse, json, re, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))

LINE = re.compile(r"^\s*(.+?)\s*(?:→|->|=>)\s*(.+?)\s*(?::\s*([^\[]*?))?\s*(?:\[(.*)\])?\s*$")


def parse(text):
    rows, attrs = [], []
    for ln in text.splitlines():
        if not ln.strip() or ln.strip().startswith("#"):
            continue
        m = LINE.match(ln)
        if not m:
            raise SystemExit(f"cannot read flow: {ln!r} (write 'A → B: what [key=value; ...]')")
        a = {}
        for kv in (m.group(4) or "").split(";"):
            if "=" in kv:
                k, v = kv.split("=", 1); a[k.strip().lower()] = v.strip()
                if k.strip().lower() not in attrs:
                    attrs.append(k.strip().lower())
        rows.append({"source": m.group(1).strip(), "target": m.group(2).strip(), "what": (m.group(3) or "").strip(), "attrs": a})
    return rows, attrs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("flows"); ap.add_argument("--title", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--style", default="auto"); ap.add_argument("--classification"); ap.add_argument("--owner")
    a = ap.parse_args()
    rows, attrs = parse(Path(a.flows).read_text(encoding="utf-8"))
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    cols = ["#", "From", "To", "What"] + [k.title() for k in attrs]
    table = [cols] + [[str(i), r["source"], r["target"], r["what"] or "—"] + [r["attrs"].get(k, "—") for k in attrs]
                      for i, r in enumerate(rows, 1)]
    flows = [f"{r['source']} → {r['target']}: {r['what']}" if r["what"] else f"{r['source']} → {r['target']}" for r in rows]
    systems = sorted({r["source"] for r in rows} | {r["target"] for r in rows})
    import typeset as TS
    deg = {}
    for r in rows:
        for s_ in (r["source"], r["target"]):
            deg[s_] = deg.get(s_, 0) + 1
    hub = max(deg, key=deg.get) if deg else ""
    fit = lambda c, fb: next((x for x in c if x and TS.fits_headline(x)), fb)
    head = fit([f"{hub} sits at the centre: {deg[hub]} of {len(rows)} flows" if hub and deg[hub] > 2 else "",
                f"{len(systems)} systems connected by {len(rows)} flows"], f"{len(rows)} flows")
    slides = [{"diagram": flows, "style": a.style, "headline": head,
               "notes": f"{len(systems)} parts, {len(rows)} flows. Full list on the next slide and in the register."}]
    pages = -(-len(rows) // 12)
    for start in range(0, len(rows), 12):                  # tables of up to 12 flows per slide, each part marked (2/3):
        part = [table[0]] + table[1 + start:1 + start + 12]   # one table carried on, not the same story told twice
        mark = f" ({start // 12 + 1}/{pages})" if pages > 1 else ""
        slides.append({"table": {"rows": part}, "headline": fit([f"Who sends what: {len(rows)} flows, {len(systems)} systems"
                                                                   + mark], f"Who sends what{mark}")})
    work = out.parent / (out.name + "_data"); work.mkdir(exist_ok=True)
    sp = work / "storyboard.json"
    sp.write_text(json.dumps({"classification": a.classification, "owner": a.owner, "slides": slides}))
    r = subprocess.run([sys.executable, str(TOOLS / "build_deck.py"), "build", str(sp), "--out", str(out.with_suffix(".pptx")), "--verbose"],
                       capture_output=True, text=True)
    overall = next((l.split(":", 1)[1].strip().split(" -")[0] for l in r.stdout.splitlines() if l.startswith("OVERALL")),
                   "build failed: " + (r.stdout + r.stderr)[-300:])
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    import brand as B
    wb = Workbook(); ws = wb.active; ws.title = "Flows"
    for row in table:
        ws.append(row)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor=B.current().ui("dark_accent"))
    for col, w in zip("ABCDEFGHIJ", [5, 28, 28, 36] + [20] * 6):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"; ws.auto_filter.ref = f"A1:{chr(64 + len(cols))}{len(table)}"
    sysws = wb.create_sheet("Parts")
    sysws.append(["Part", "Sends", "Receives"])
    for s_ in systems:
        sysws.append([s_, sum(r["source"] == s_ for r in rows), sum(r["target"] == s_ for r in rows)])
    import atomic
    atomic.save(wb, f"{out}-register.xlsx")
    import plain; plain.clean(f"{out}-register.xlsx")     # plain punctuation: no em dashes in what a reader sees
    import brand_colours
    for x in brand_colours.summary(f"{out}-register.xlsx", 3):
        print(f"  FAIL colour in the workbook: {x}")
    print(f"DIAGRAM PACK {overall} | {out}.pptx (diagram + table) | {out.name}-slide1.drawio | {out}-register.xlsx | "
          f"{len(systems)} parts, {len(rows)} flows")


if __name__ == "__main__":
    main()
