"""Read and write a .pptx's document properties (core + custom) without touching the slides.

    from docprops import read_props, write_props
    write_props(path, core={"title": "...", "subject": "..."}, custom={"Classification": "Internal"})
"""
import re, zipfile
from pathlib import Path

from lxml import etree
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

CUSTOM = "http://schemas.openxmlformats.org/officeDocument/2006/custom-properties"
VT = "http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes"
CORE_NS = {"cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties",
           "dc": "http://purl.org/dc/elements/1.1/", "dcterms": "http://purl.org/dc/terms/",
           "xsi": "http://www.w3.org/2001/XMLSchema-instance"}
FMTID = "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}"
LIMIT = 255   # Office keeps a text property to 255 characters (Word and PowerPoint object models, Office.js); a longer one makes
              # PowerPoint say "found a problem with content" and offer to repair the file (Excel crashes on it)
PART = "__part"   # a longer value is kept whole across properties: Name, Name__part2, Name__part3 ... (read_props joins them)
CORE_TAGS = {"title": "dc:title", "subject": "dc:subject", "creator": "dc:creator", "keywords": "cp:keywords",
             "description": "dc:description", "lastModifiedBy": "cp:lastModifiedBy", "revision": "cp:revision",
             "category": "cp:category", "contentStatus": "cp:contentStatus", "modified": "dcterms:modified"}


def read_props(path):
    z = zipfile.ZipFile(path)
    core, custom = {}, {}
    if "docProps/core.xml" in z.namelist():
        x = etree.fromstring(z.read("docProps/core.xml"))
        for k, tag in CORE_TAGS.items():
            el = x.find(tag, CORE_NS)
            if el is not None and el.text:
                core[k] = el.text
    if "docProps/custom.xml" in z.namelist():
        x = etree.fromstring(z.read("docProps/custom.xml"))
        for p in x:
            v = next(iter(p), None)
            custom[p.get("name")] = v.text if v is not None else None
    return core, _joined(custom)


def _joined(custom):
    """The properties as they were written: a value kept across Name, Name__part2 ... is one value again."""
    out = {}
    for k, v in custom.items():
        m = re.match(r"^(.*)" + PART + r"\d+$", k or "")
        if m and m.group(1) in custom:
            continue
        out[k] = v
        i = 2
        while f"{k}{PART}{i}" in custom:
            out[k] = (out[k] or "") + (custom[f"{k}{PART}{i}"] or ""); i += 1
    return out


def _pieces(v, n=LIMIT):
    """v in pieces Office accepts: at most n UTF-16 units each (what Office counts), never splitting a character."""
    out, cur, used = [], [], 0
    for ch in v:
        w = 2 if ord(ch) > 0xFFFF else 1
        if used + w > n:
            out.append("".join(cur)); cur, used = [], 0
        cur.append(ch); used += w
    return out + ["".join(cur)]


def _core_xml(old, core):
    x = etree.fromstring(old) if old else etree.Element("{%s}coreProperties" % CORE_NS["cp"], nsmap=CORE_NS)
    for k, v in core.items():
        tag = CORE_TAGS[k]
        pre, local = tag.split(":")
        el = x.find(tag, CORE_NS)
        if el is None:
            el = etree.SubElement(x, "{%s}%s" % (CORE_NS[pre], local))
        if k == "modified":
            el.set("{%s}type" % CORE_NS["xsi"], "dcterms:W3CDTF")
        el.text = str(v) if k in ("modified", "revision") else _pieces(str(v))[0]   # a title Office can show (255)
    return etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)


def _custom_xml(old, custom, remove=()):
    """The custom properties with `custom` set and `remove` (name prefixes) gone. Every text value is kept to what Office
    accepts (255): a longer one - this write's, or one an older build or another tool left in the file - is stored across
    Name, Name__part2 ... and read_props joins it again, so the file opens clean and nothing is lost."""
    x = etree.fromstring(old) if old else etree.Element("{%s}Properties" % CUSTOM, nsmap={None: CUSTOM, "vt": VT})
    base = lambda name: re.sub(PART + r"\d+$", "", name or "")
    for p in list(x):
        if base(p.get("name")) in custom or any((p.get("name") or "").startswith(r) for r in remove):
            x.remove(p)
    long_ = {}
    for p in list(x):                                   # what is already in the file and too long for Office
        v = next(iter(p), None)
        if v is not None and etree.QName(v).localname in ("lpwstr", "lpstr") and len(_pieces(v.text or "")) > 1:
            long_[p.get("name")] = v.text
    for p in list(x):
        if base(p.get("name")) in long_:
            x.remove(p)
    pid = max([int(p.get("pid")) for p in x] + [1]) + 1
    for k, v in list(long_.items()) + list(custom.items()):
        if v is None:
            continue
        for i, piece in enumerate(_pieces(str(v)), 1):
            p = etree.SubElement(x, "{%s}property" % CUSTOM, fmtid=FMTID, pid=str(pid), name=k if i == 1 else f"{k}{PART}{i}"); pid += 1
            etree.SubElement(p, "{%s}lpwstr" % VT).text = piece
    return etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)


def write_props(path, core=None, custom=None, remove=()):
    z = zipfile.ZipFile(path)
    items = {n: z.read(n) for n in z.namelist()}
    infos = {n: z.getinfo(n) for n in z.namelist()}
    z.close()
    if core:
        items["docProps/core.xml"] = _core_xml(items.get("docProps/core.xml"), core)
    if custom or remove:
        items["docProps/custom.xml"] = _custom_xml(items.get("docProps/custom.xml"), custom or {}, remove)
        ct = items["[Content_Types].xml"].decode()
        if "/docProps/custom.xml" not in ct:
            ct = ct.replace("</Types>", '<Override PartName="/docProps/custom.xml" ContentType="application/'
                            'vnd.openxmlformats-officedocument.custom-properties+xml"/></Types>')
            items["[Content_Types].xml"] = ct.encode()
        rels = items["_rels/.rels"].decode()
        if "docProps/custom.xml" not in rels:
            rels = rels.replace("</Relationships>", '<Relationship Id="rIdCustomProps" Type="http://schemas.'
                                'openxmlformats.org/officeDocument/2006/relationships/custom-properties" '
                                'Target="docProps/custom.xml"/></Relationships>')
            items["_rels/.rels"] = rels.encode()
    import atomic
    with atomic.zip_out(path) as w:
        for n, d in items.items():
            w.writestr(infos[n] if n in infos else n, d)


def purview_label(custom):
    """Name of the Microsoft Purview sensitivity label the file carries, or None."""
    for k, v in custom.items():
        if re.match(r"MSIP_Label_[0-9a-f-]+_Name$", k or ""):
            return v
    return None
