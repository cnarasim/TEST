"""Native drawing in the Ulta template's own visual language - the base for every drawn timeline, swimlane and
infographic, so a drawn slide looks like the template's own slides (7, 12, 15-20) and edits like a hand-made one.

Rules enforced here (callers never pick raw colours, fonts or effects):
  colour   theme-bound (schemeClr) in the template's order - ACCENT_2 magenta D01381, TEXT_2 pink-red EA0B59,
           ACCENT_4 red-orange F14C24, ACCENT_1 orange F16A1C (template slide 12's rows) - plus the template's literal
           tints and neutrals (BLUSH FDE1D2, PAGE FFF5F3, TINT F2F2F2, LINE D9D9D9, MUTED 404040, PLUM 5D0F43).
           tools/brand_colours.py audits every build: nothing else passes.
  type     Circular Std Bold (labels, sub-headlines), Circular Std Book (body), the display face for big numbers.
           Template sizes: 24 highlight, 18 sub-headline, 14 card text, 12 body, 10.5 dense labels, 9 the floor.
  effects  none: every shape and line gets an empty effect list - otherwise PowerPoint draws the theme's drop shadow
           (LibreOffice previews hide it, the user's PowerPoint shows it).
  text     inside its own shape (editable like a hand-made slide); a free label is a text box with no fill.
  lines    connectors glued to their shapes at the connection point they start / end on: the stored line is what
           PowerPoint shows, so stored geometry and glue always agree (no jump when a shape is moved).
  frame    content stays inside the box build_deck hands over (clear of the headline, the logo and the footer).

    import native_draw as ND
    b = ND.box(sl, x, y, w, h, fill=ND.accent(0), text="Discovery", size=ND.T_SUB, color=ND.WHITE, bold=True)
    c = ND.box(sl, x2, y, w, h, fill=ND.WHITE, line=ND.LINE, text="Design")
    ND.connect(sl, b, c)                      # glued right -> left, stored on the glue points, arrowhead at c
"""

from lxml import etree
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_THEME_COLOR
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.util import Emu, Pt

IN = 914400
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
ORDER = ["ACCENT_2", "TEXT_2", "ACCENT_4", "ACCENT_1"]                     # template slide 12's row order
HEX = {"ACCENT_2": "D01381", "TEXT_2": "EA0B59", "ACCENT_4": "F14C24", "ACCENT_1": "F16A1C"}
BLUSH, PAGE, TINT, LINE, MUTED, PLUM, INK, WHITE = "FDE1D2", "FFF5F3", "F2F2F2", "D9D9D9", "404040", "5D0F43", "000000", "FFFFFF"
PINK_TINT, WARM_TINT, ROSE_TINT = "FFE8EE", "F9E3DE", "FAD3DB"
STATUS = {"green": "00B050", "amber": "FFC000", "red": "FF0000"}          # marks only, never text
BODY, BOLD, DISPLAY = "Circular Std Book", "Circular Std Bold", "Playfair Display Black"
T_HIGHLIGHT, T_SUB, T_CARD, T_BODY, T_SMALL, T_MIN = 24, 18, 14, 12, 10.5, 9
SAFE_BOTTOM = int(6.4 * IN)                                                  # nothing below: the template's content ends here


def accent(i):
    """The i-th colour in the template's order (cycles)."""
    return ORDER[i % len(ORDER)]


def hexof(colour):
    return HEX.get(colour, colour)


def _set_fill(fmt, colour):
    """fmt: a FillFormat; colour: a theme name (ACCENT_2 ...), a hex string, or None for no fill."""
    if colour is None:
        fmt.background()
        return
    fmt.solid()
    if colour in HEX:
        fmt.fore_color.theme_color = getattr(MSO_THEME_COLOR, colour)
    else:
        fmt.fore_color.rgb = RGBColor.from_string(colour)


def _font_colour(font, colour):
    if colour in HEX:
        font.color.theme_color = getattr(MSO_THEME_COLOR, colour)
    else:
        font.color.rgb = RGBColor.from_string(colour)


P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"


def _drop_style(el):
    """Remove the theme style reference (fill / line / effect / font refs): every colour here is explicit, and the
    reference is what makes previews draw the theme's shadow."""
    for st in el.findall(P + "style"):
        el.remove(st)


def no_effects(shape):
    """An empty effect list in the shape's properties (schema position: after the fill / line, before scene3d)."""
    _drop_style(shape._element)
    sppr = shape._element.spPr
    for old in sppr.findall(A + "effectLst"):
        sppr.remove(old)
    eff = etree.SubElement(sppr, A + "effectLst")
    for tag in ("scene3d", "sp3d", "extLst"):
        nxt = sppr.find(A + tag)
        if nxt is not None:
            nxt.addprevious(eff)
            break
    return shape


def _line(shape, colour, width=0.75, dash=None):
    ln = shape.line
    if colour is None:
        ln.fill.background()
    else:
        _set_fill(ln.fill, colour)
        ln.width = Pt(width)
        if dash:
            from pptx.enum.dml import MSO_LINE_DASH_STYLE
            ln.dash_style = getattr(MSO_LINE_DASH_STYLE, dash)


def write(shape, text, size=T_BODY, color=INK, bold=False, font=None, align="c", anchor="m", margin=0.08,
          spacing=None):
    """Text inside a shape. Lines split on '\\n'; 'Lead: detail' is NOT split here (use rich())."""
    tf = shape.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.vertical_anchor = {"t": MSO_ANCHOR.TOP, "m": MSO_ANCHOR.MIDDLE, "b": MSO_ANCHOR.BOTTOM}[anchor]
    m = int(margin * IN)
    tf.margin_left = tf.margin_right = m
    tf.margin_top = tf.margin_bottom = int(m * 0.6)
    for k, line in enumerate(str(text).split("\n")):
        p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
        p.alignment = {"l": PP_ALIGN.LEFT, "c": PP_ALIGN.CENTER, "r": PP_ALIGN.RIGHT}[align]
        if spacing:
            p.line_spacing = spacing
        r = p.add_run()
        r.text = line
        f = r.font
        f.size = Pt(size)
        f.bold = bold
        f.name = font or (BOLD if bold else BODY)
        _font_colour(f, color)
    return shape


def rich(shape, parts, align="l", anchor="t", margin=0.12, spacing=None):
    """parts: [(text, size, bold, colour, new_paragraph)] - e.g. a bold lead line then a body line."""
    tf = shape.text_frame
    tf.clear()
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.vertical_anchor = {"t": MSO_ANCHOR.TOP, "m": MSO_ANCHOR.MIDDLE, "b": MSO_ANCHOR.BOTTOM}[anchor]
    m = int(margin * IN)
    tf.margin_left = tf.margin_right = m
    tf.margin_top = tf.margin_bottom = int(m * 0.7)
    p = tf.paragraphs[0]
    first = True
    for text, size, bold, colour, new_par in parts:
        if new_par and not first:
            p = tf.add_paragraph()
        p.alignment = {"l": PP_ALIGN.LEFT, "c": PP_ALIGN.CENTER, "r": PP_ALIGN.RIGHT}[align]
        if spacing:
            p.line_spacing = spacing
        r = p.add_run()
        r.text = text
        r.font.size = Pt(size)
        r.font.bold = bold
        r.font.name = BOLD if bold else BODY
        _font_colour(r.font, colour)
        first = False
    return shape


def shape(sl, kind, x, y, w, h, fill=None, line=None, line_w=0.75, radius=None, name="drawn shape", **text):
    """Any preset shape (MSO_SHAPE name or member), template-styled: fill, optional outline, no effects, text inside."""
    k = getattr(MSO_SHAPE, kind) if isinstance(kind, str) else kind
    sh = sl.shapes.add_shape(k, Emu(int(x)), Emu(int(y)), Emu(int(w)), Emu(int(h)))
    _set_fill(sh.fill, fill)
    _line(sh, line, line_w)
    if radius is not None and k == MSO_SHAPE.ROUNDED_RECTANGLE:
        sh.adjustments[0] = max(0.0, min(0.5, radius))
    no_effects(sh)
    sh.name = name
    if text.get("text") is not None:
        t = text.pop("text")
        write(sh, t, **text)
    return sh


def box(sl, x, y, w, h, fill=WHITE, line=None, radius=0.12, name="drawn box", **text):
    """A card / bar: rounded rectangle like the template's cards (radius = share of the short side)."""
    kind = "ROUNDED_RECTANGLE" if radius else "RECTANGLE"
    return shape(sl, kind, x, y, w, h, fill=fill, line=line, radius=radius, name=name, **text)


def label(sl, x, y, w, h, text, size=T_BODY, color=INK, bold=False, align="l", anchor="m", font=None, name="drawn label"):
    """A free text label (no fill, no line)."""
    tb = sl.shapes.add_textbox(Emu(int(x)), Emu(int(y)), Emu(int(w)), Emu(int(h)))
    no_effects(tb)
    tb.name = name
    write(tb, text, size=size, color=color, bold=bold, font=font, align=align, anchor=anchor, margin=0.02)
    return tb


def line(sl, x1, y1, x2, y2, colour=LINE, width=1.0, dash=None, head=None, tail=None, name="drawn line"):
    """A straight line (not glued) with optional arrowheads ('triangle', 'oval', 'stealth')."""
    c = sl.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, Emu(int(x1)), Emu(int(y1)), Emu(int(x2)), Emu(int(y2)))
    _style_connector(c, colour, width, dash, head, tail)
    c.name = name
    return c


def _style_connector(c, colour, width, dash, head, tail):
    _set_fill(c.line.fill, colour)
    c.line.width = Pt(width)
    if dash:
        from pptx.enum.dml import MSO_LINE_DASH_STYLE
        c.line.dash_style = getattr(MSO_LINE_DASH_STYLE, dash)
    ln = c.line._get_or_add_ln()
    for tag, kind in (("headEnd", head), ("tailEnd", tail)):
        if kind:
            e = ln.find(A + tag)
            if e is None:
                e = etree.SubElement(ln, A + tag)
            e.set("type", kind)
            e.set("w", "med")
            e.set("len", "med")
    _drop_style(c._element)
    sppr = c._element.spPr
    for old in sppr.findall(A + "effectLst"):
        sppr.remove(old)
    eff = etree.SubElement(sppr, A + "effectLst")
    ext = sppr.find(A + "extLst")
    if ext is not None:
        ext.addprevious(eff)
    # schema order inside a:ln: fill, prstDash, round/bevel/miter, headEnd, tailEnd, extLst
    order = {A + t: i for i, t in enumerate(("noFill", "solidFill", "gradFill", "pattFill", "prstDash", "custDash", "round",
                                              "bevel", "miter", "headEnd", "tailEnd", "extLst"))}
    kids = sorted(list(ln), key=lambda e: order.get(e.tag, 99))
    for k_ in list(ln):
        ln.remove(k_)
    for k_ in kids:
        ln.append(k_)


SITES = {"top": 0, "left": 1, "bottom": 2, "right": 3}                      # rectangle / rounded rectangle / diamond


def site_point(sh, site):
    x, y, w, h = sh.left, sh.top, sh.width, sh.height
    return {"top": (x + w // 2, y), "left": (x, y + h // 2), "bottom": (x + w // 2, y + h),
            "right": (x + w, y + h // 2)}[site]


def connect(sl, a, b, a_site=None, b_site=None, colour=MUTED, width=1.25, dash=None, arrow=True, elbow=None,
            name="drawn flow"):
    """A connector glued from shape a to shape b (rectangles, rounded rectangles, diamonds). Sites default to the
    facing sides; elbow defaults to True when the sites are not on one straight line. Stored geometry = glue points."""
    ax, ay = a.left + a.width // 2, a.top + a.height // 2
    bx, by = b.left + b.width // 2, b.top + b.height // 2
    if a_site is None or b_site is None:
        if abs(bx - ax) >= abs(by - ay):
            a_site, b_site = ("right", "left") if bx >= ax else ("left", "right")
        else:
            a_site, b_site = ("bottom", "top") if by >= ay else ("top", "bottom")
    p1, p2 = site_point(a, a_site), site_point(b, b_site)
    straight = p1[0] == p2[0] or p1[1] == p2[1]
    use_elbow = (not straight) if elbow is None else elbow
    kind = MSO_CONNECTOR.ELBOW if use_elbow else MSO_CONNECTOR.STRAIGHT
    c = sl.shapes.add_connector(kind, Emu(int(p1[0])), Emu(int(p1[1])), Emu(int(p2[0])), Emu(int(p2[1])))
    c.begin_connect(a, SITES[a_site])
    c.end_connect(b, SITES[b_site])
    if use_elbow and a_site in ("top", "bottom") and b_site in ("top", "bottom"):
        _vertical_elbow(c)
    _style_connector(c, colour, width, dash, None, "triangle" if arrow else None)
    c.name = name
    return c


def _vertical_elbow(c):
    """bentConnector3 runs horizontal-vertical-horizontal; a top/bottom flow needs vertical-horizontal-vertical:
    rotate the connector 90 degrees and swap its box so the stored ends stay on the glue points."""
    x1, y1, x2, y2 = c.begin_x, c.begin_y, c.end_x, c.end_y
    xfrm = c._element.spPr.find(A + "xfrm")
    cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
    w, h = abs(y2 - y1), abs(x2 - x1)
    off, ext = xfrm.find(A + "off"), xfrm.find(A + "ext")
    off.set("x", str(int(cx - w / 2)))
    off.set("y", str(int(cy - h / 2)))
    ext.set("cx", str(int(w)))
    ext.set("cy", str(int(h)))
    xfrm.set("rot", "5400000")
    flipH = (y2 < y1)
    flipV = (x2 > x1)
    for k, v in (("flipH", flipH), ("flipV", flipV)):
        if v:
            xfrm.set(k, "1")
        elif k in xfrm.attrib:
            del xfrm.attrib[k]


def _visual_box(el):
    """(x0, y0, x1, y1) a child shape really covers: a connector turned by 90 degrees stores its unturned box, centred
    on the same point (python-pptx sizes a group from the stored boxes, which overstates the turned ones)."""
    xf = el.find(f"{P}spPr/{A}xfrm")
    if xf is None:
        xf = el.find(f"{P}grpSpPr/{A}xfrm")
    if xf is None or xf.find(A + "off") is None or xf.find(A + "ext") is None:
        return None
    x, y = int(xf.find(A + "off").get("x")), int(xf.find(A + "off").get("y"))
    w, h = int(xf.find(A + "ext").get("cx")), int(xf.find(A + "ext").get("cy"))
    if int(xf.get("rot", "0")) % 10800000 == 5400000:
        cx, cy = x + w / 2, y + h / 2
        return int(cx - h / 2), int(cy - w / 2), int(cx + h / 2), int(cy + w / 2)
    return x, y, x + w, y + h


def group(sl, shapes, name="drawn graphic"):
    """Group a graphic's shapes so it moves as one object (text stays editable inside). The group's frame is what its
    shapes really cover (turned connectors included), so the chrome gate measures the true extent."""
    shapes = [s for s in shapes if s is not None]
    if len(shapes) < 2:
        return shapes[0] if shapes else None
    g = sl.shapes.add_group_shape(shapes)
    g.name = name
    boxes = [b for b in (_visual_box(ch) for ch in g._element if ch.tag.split("}")[-1] in ("sp", "cxnSp", "grpSp", "pic"))
             if b]
    xf = g._element.find(f"{P}grpSpPr/{A}xfrm")
    if boxes and xf is not None:
        x0, y0 = min(b[0] for b in boxes), min(b[1] for b in boxes)
        x1, y1 = max(b[2] for b in boxes), max(b[3] for b in boxes)
        for tag in ("off", "chOff"):
            e = xf.find(A + tag); e.set("x", str(x0)); e.set("y", str(y0))
        for tag in ("ext", "chExt"):
            e = xf.find(A + tag); e.set("cx", str(x1 - x0)); e.set("cy", str(y1 - y0))
    return g




def contrast_ratio(colour, text=WHITE):
    """WCAG contrast of a text colour on a fill."""
    def lum(h):
        r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
        lin = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
        return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
    a, b = lum(hexof(colour)), lum(hexof(text))
    return (max(a, b) + 0.05) / (min(a, b) + 0.05)


def contrast_text(colour, size=None, bold=False):
    """White or black text on a fill, readable: white while it reaches 4.5:1 - 3:1 from 18 pt - else black. Bold earns no
    allowance (a viewer without the template's font draws it regular), and the template's white bold on its orange and
    red header fills (3.1-4.5:1) is kept only where the text is that large: on deep pink and plum white stays."""
    h = hexof(colour)
    return WHITE if contrast_ratio(h) >= (3.0 if size is not None and size >= 18 else 4.5) else INK


def text_lines(text, width_emu, pt, bold=False):
    """Lines a text needs at pt in a box width (template font metrics; the same measure the build's fit check uses)."""
    import brand as _B
    b = _B.current()
    M = _B.metrics_for(b)
    face = BOLD if bold else BODY
    room = max(1, width_emu - int(0.16 * IN))
    lines, cur = 0, ""
    for para in str(text).split("\n"):
        cur = ""
        lines += 1
        for word in para.split():
            trial = (cur + " " + word).strip()
            ems = _B.width_of(trial, face, M) or len(trial) * 0.55
            if ems * pt * 12700 > room and cur:
                lines += 1
                cur = word
            else:
                cur = trial
    return lines


def fits(text, w, h, pt, bold=False, spacing=1.15):
    """True when text set at pt fits a w x h box (EMU)."""
    need = text_lines(text, w, pt, bold) * pt * spacing * 12700 + int(0.1 * IN)
    return need <= h
