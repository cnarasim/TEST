"""Step-by-step knowledge guides from screenshots ("walk me through it"): the user takes screenshots and draws a RED box
or circle around what to click (Snipping Tool / Mac markup). Python finds each red mark, removes it, dims the rest of
the screen, and builds:
  - <Name>.pptx  Ulta deck: cover, steps overview, one slide per step (screenshot + ring + numbered badge + zoomed
                 close-up + optional tip - native shapes, editable), closing. Checked like every deck.
  - <Name>.html  interactive walkthrough: the screen dims around the target, click it (or press →) for the next step.
  - <Name>.pdf   the deck as PDF (when LibreOffice is available).
No AI looks at the images: positions come from the user's red marks (or "box" given by hand).

    python tools/walkthrough.py marks s1.png s2.png ...         where the red mark is on each screenshot (+ preview sheet)
    python tools/walkthrough.py build guide.json --out /mnt/data/out/<Name>

guide.json:
  {"title": "Create a store transfer", "subtitle": "Store Operations Portal · for store leads",
   "steps": [{"image": "/mnt/data/s1.png", "text": "Choose the receiving store", "tip": "Type the store number to filter"},
             {"image": "/mnt/data/s2.png", "text": "Click Save", "box": [1180, 52, 60, 28]}]}
  text = the instruction (becomes the slide headline, 56 characters max); tip and notes are optional;
  box = [x, y, width, height] in image pixels, only when there is no red mark.
"""
import argparse, base64, io, json, re, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
MAX_W = 1600                                           # screenshots are scaled down to this width (sharp, not heavy)


# ------------------------------------------------------------------------------------------------ red marks
def red_mask(im):
    """Pen red (Snipping Tool, Mac markup): strong red, little green AND little blue. Ulta pink (E8275A, blue 90) and
    magenta are not pen red, so brand headings and buttons on Ulta screens are never taken for the mark."""
    import numpy as np
    a = np.asarray(im.convert("RGB")).astype(int)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    return (r > 170) & (g < 95) & (b < 80) & (r - g > 110) & (r - b > 120)


def thin(mask, stroke=13):
    """Only pen strokes: solid red areas thicker than a pen line (a red button, banner, error badge) are removed, so a
    box drawn around a red button is not swallowed by the button."""
    import numpy as np
    from PIL import ImageFilter
    m = Image_from(mask)
    solid = m.filter(ImageFilter.MinFilter(stroke)).filter(ImageFilter.MaxFilter(stroke + 2))
    return mask & ~(np.asarray(solid) > 0)


def components(mask, step=2):
    """Connected clusters of red pixels on a downsampled grid: [(x0, y0, x1, y1, pixels)] in full-size pixels."""
    import numpy as np
    m = mask[::step, ::step]
    seen = np.zeros_like(m, dtype=bool)
    H, W = m.shape
    out = []
    ys, xs = np.nonzero(m)
    for sy, sx in zip(ys, xs):
        if seen[sy, sx]:
            continue
        stack, pts = [(sy, sx)], 0
        seen[sy, sx] = True
        x0 = x1 = sx; y0 = y1 = sy
        while stack:
            cy, cx = stack.pop(); pts += 1
            x0, x1, y0, y1 = min(x0, cx), max(x1, cx), min(y0, cy), max(y1, cy)
            for ny in (cy - 1, cy, cy + 1):
                for nx in (cx - 1, cx, cx + 1):
                    if 0 <= ny < H and 0 <= nx < W and m[ny, nx] and not seen[ny, nx]:
                        seen[ny, nx] = True; stack.append((ny, nx))
        out.append((x0 * step, y0 * step, (x1 + 1) * step, (y1 + 1) * step, pts))
    return out


def ring_like(mask, x0, y0, x1, y1):
    """A drawn box or circle has red on all four sides of its bounding box (a letter like U or C does not)."""
    sub = mask[y0:y1, x0:x1]
    h, w = sub.shape
    if h < 10 or w < 14:
        return False
    bh, bw = max(3, h // 5), max(3, w // 5)
    sides = (sub[:bh].any(0), sub[-bh:].any(0), sub[:, :bw].any(1), sub[:, -bw:].any(1))
    return all(x.mean() > 0.5 for x in sides)


def find_marks(im):
    """Every drawn mark: HOLLOW pen-red clusters closed on all four sides, biggest first: [(x, y, w, h)] of the area
    inside each mark."""
    mask = thin(red_mask(im), max(13, im.width // 70 | 1))   # phone screenshots (3x) are drawn with thicker pens
    found = []
    for x0, y0, x1, y1, pts in components(mask):
        w, h = x1 - x0, y1 - y0
        if w < 14 or h < 10:
            continue
        if pts * 4 / max(w * h, 1) > 0.45:            # outline: small share of its box is red
            continue
        if not ring_like(mask, x0, y0, x1, y1):
            continue
        found.append((x0, y0, w, h))
    found.sort(key=lambda b: -b[2] * b[3])
    return [b for b in found if b[2] * b[3] >= 0.2 * found[0][2] * found[0][3]]   # red letters (an "o", a "0") are not marks


def find_mark(im):
    """The user's mark (the biggest one), or None."""
    m = find_marks(im)
    return m[0] if m else None


def clean(im, mask, rounds=8):
    """Paint over the red mark from the outside in: each pass fills the pixels next to known ones with the MEDIAN of
    their known neighbours (an average blends a button's colour with the white beside it into streaks)."""
    import numpy as np
    from PIL import Image, ImageFilter
    a = np.asarray(im.convert("RGB")).astype(float)
    todo = np.asarray(Image_from(mask).filter(ImageFilter.MaxFilter(5))) > 0      # the mark's anti-aliased edge too
    if not todo.any():
        return im.convert("RGB")
    ys, xs = np.nonzero(todo)                          # work on the mark's bounding box only (fast on big screens)
    y0, y1, x0, x1 = max(0, ys.min() - 2), ys.max() + 3, max(0, xs.min() - 2), xs.max() + 3
    sub, t = a[y0:y1, x0:x1].copy(), todo[y0:y1, x0:x1].copy()
    H, W = t.shape
    pad = lambda z, v: np.pad(z, ((1, 1), (1, 1)) + ((0, 0),) * (z.ndim - 2), constant_values=v)
    for _ in range(rounds * 6):
        if not t.any():
            break
        P, K = pad(sub, 0), pad(~t, False)
        nb = [(P[1 + dy:1 + dy + H, 1 + dx:1 + dx + W], K[1 + dy:1 + dy + H, 1 + dx:1 + dx + W])
              for dy in (-1, 0, 1) for dx in (-1, 0, 1) if dy or dx]
        vals = np.stack([np.where(k[..., None], v, np.nan) for v, k in nb])
        cnt = np.stack([k for _, k in nb]).sum(0)
        fill = t & (cnt >= 2) if (t & (cnt >= 2)).any() else t & (cnt > 0)
        with np.errstate(all="ignore"):
            med = np.nanmedian(vals[:, fill], axis=0)
        sub[fill] = med; t &= ~fill
    a[y0:y1, x0:x1] = sub
    return Image.fromarray(a.clip(0, 255).astype("uint8"))


def Image_from(mask):
    from PIL import Image
    return Image.fromarray((mask * 255).astype("uint8"))


def dim(im, box, amount=0.30, pad=8):
    """Everything except the target darkened, so the eye goes to the right place."""
    from PIL import Image, ImageDraw
    x, y, w, h = box
    shade = Image.new("RGBA", im.size, (20, 10, 20, int(255 * amount)))
    hole = Image.new("L", im.size, 255)
    ImageDraw.Draw(hole).rounded_rectangle([x - pad, y - pad, x + w + pad, y + h + pad], radius=10, fill=0)
    shade.putalpha(Image.eval(hole, lambda v: int(v * amount)))
    out = im.convert("RGBA"); out.alpha_composite(shade)
    return out.convert("RGB")


def zoom_crop(im, box, out_w=720, aspect=1.15):
    """The target with a little context, cropped to the close-up's shape (about square) so it fills the frame, enlarged
    up to 3x, with the same orange ring as on the screen."""
    from PIL import Image, ImageDraw
    x, y, w, h = box
    cw = max(w / 0.72, 200)                            # the target fills about 70% of the close-up's width
    ch = max(cw / aspect, h / 0.5)
    cw = max(cw, ch * aspect)
    cx, cy = x + w / 2, y + h / 2
    l, t = max(0, int(cx - cw / 2)), max(0, int(cy - ch / 2))
    r, b = min(im.width, int(cx + cw / 2)), min(im.height, int(cy + ch / 2))
    c = im.crop((l, t, r, b))
    f = min(3.0, out_w / c.width)
    z = c.resize((int(c.width * f), int(c.height * f)), Image.LANCZOS)
    p = 6
    ImageDraw.Draw(z).rounded_rectangle([(x - l) * f - p, (y - t) * f - p, (x - l + w) * f + p, (y - t + h) * f + p],
                                        radius=10, outline=(242, 105, 35), width=5)
    return z


def prepare(step, k, work):
    """(dimmed screen path, close-up path, clean screen path, box in scaled pixels, problem or None)."""
    from PIL import Image
    src = Path(step["image"])
    im, err = open_image(src)
    if err:
        return None, None, None, None, f"step {k}: {err}"
    f = min(1.0, MAX_W / im.width)
    if f < 1:
        im = im.resize((int(im.width * f), int(im.height * f)), Image.LANCZOS)
    box = step.get("box")
    if box:
        W0, H0 = im.width / f, im.height / f
        try:
            x, y, w, h = (float(v) for v in box)
        except (TypeError, ValueError):
            return None, None, None, None, f"step {k}: \"box\" must be [x, y, width, height] in pixels, e.g. [1180, 52, 60, 28]"
        if w < 4 or h < 4 or x >= W0 or y >= H0 or x + w <= 0 or y + h <= 0:
            return None, None, None, None, (f"step {k}: \"box\" {box} is outside the {int(W0)} x {int(H0)} screenshot "
                                            "or empty - give [x, y, width, height] in the screenshot's own pixels")
        x, y = max(0.0, x), max(0.0, y); w, h = min(w, W0 - x), min(h, H0 - y)
        box = [int(v * f) for v in (x, y, w, h)]
    if not box:                                       # a given box means there is no hand-drawn mark: never "clean" the
        mark = find_mark(im)                          # picture then (brand reds in a screenshot would be painted over)
        if mark is not None:
            import numpy as np
            x, y, w, h = mark; near = np.zeros(im.size[::-1], dtype=bool)
            near[max(0, y - 8):y + h + 8, max(0, x - 8):x + w + 8] = True
            im = clean(im, red_mask(im) & near)       # only the drawn mark: other red on the screen stays
            box = [int(v) for v in mark]
    if not box:
        return None, None, None, None, (f"step {k}: no red mark found on {src.name} - draw a red box around what to "
                                        "click, or give \"box\": [x, y, width, height]")
    plain = work / f"step{k}-screen.png"; im.save(plain, optimize=True)
    shot = work / f"step{k}.png"; dim(im, box).save(shot, optimize=True)
    zoom = work / f"step{k}-zoom.png"; zoom_crop(im, box).save(zoom, optimize=True)
    return shot, zoom, plain, box, None


# ------------------------------------------------------------------------------------------------ outputs
def storyboard(g, steps):
    import brand as B
    b = B.current()
    slides = [{"source": b.role("cover", 1), "title": g["title"], "subtitle": g.get("subtitle") or f"{len(steps)} steps"}]
    if 3 <= len(steps) <= 10:
        slides.append({"bullets": [s["text"] for s in steps], "numbered": True, "headline": "Steps at a glance"})
    elif len(steps) > 10:                             # every step listed: 9 a slide, numbers carried on (never cut at 10)
        for c in range(0, len(steps), 9):
            part = steps[c:c + 9]
            slides.append({"bullets": [s["text"] for s in part], "numbered": True, "start": c + 1,
                           "headline": f"Steps at a glance ({c + 1}-{c + len(part)})"})
    for i, s in enumerate(steps, 1):
        slides.append({"step": {"image": str(s["_shot"]), "zoom": str(s["_zoom"]), "box": s["_box"], "n": i,
                                "tip": s.get("tip"), "alt": f"Step {i}: {s['text']}"},
                       "headline": f"{i}. {s['text']}", "notes": s.get("notes") or s["text"]})
    slides.append({"source": 32 if b.name == "ulta" else b.role("closing", 32), "text": ["Thank you!"]})
    return {"slides": slides}


def b64(p):
    return "data:image/png;base64," + base64.b64encode(Path(p).read_bytes()).decode()


def html(g, steps):
    from PIL import Image
    data = []
    for i, s in enumerate(steps, 1):
        with Image.open(s["_plain"]) as im:
            W, H = im.size
        x, y, w, h = s["_box"]
        data.append({"n": i, "text": s["text"], "tip": s.get("tip") or "", "img": b64(s["_plain"]),
                     "box": [x / W * 100, y / H * 100, w / W * 100, h / H * 100], "ratio": H / W})
    esc = lambda t: str(t).replace("&", "&amp;").replace("<", "&lt;")
    return HTML.replace("__TITLE__", esc(g["title"])).replace("__SUB__", esc(g.get("subtitle") or "")).replace(
        "__DATA__", json.dumps(data).replace("</", "<\\/").replace("<!--", "<\\!--"))   # step text can never end the script


HTML = r"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>__TITLE__</title><style>
:root{--o:#F26923;--b:#5D0F43;--p:#E8275A;--bg:#FFF5F3;--ink:#404040}
*{box-sizing:border-box}body{margin:0;font-family:'Circular Std',Inter,Arial,sans-serif;background:var(--bg);color:var(--ink)}
header{padding:18px 28px;border-top:8px solid;border-image:linear-gradient(90deg,#F26923,#E8275A,#C10060) 1;display:flex;justify-content:space-between;align-items:flex-end;gap:16px;flex-wrap:wrap}
h1{margin:0;font-size:26px;color:var(--b)}header p{margin:4px 0 0;color:#404040}
.prog{font-size:14px;color:#404040}.bar{height:6px;background:#f9e3de;border-radius:3px;margin:0 28px}.bar i{display:block;height:100%;background:linear-gradient(90deg,#F26923,#E8275A);border-radius:3px;transition:width .3s}
main{display:grid;grid-template-columns:minmax(0,3fr) minmax(260px,1fr);gap:24px;padding:20px 28px}
.stage{position:relative;align-self:start;height:max-content;line-height:0;border-radius:10px;overflow:hidden;box-shadow:0 6px 24px rgba(93,15,67,.15);background:#fff}
.stage{justify-self:center;width:fit-content;max-width:100%}.stage img{display:block;width:auto;max-width:100%;max-height:calc(100vh - 130px)}
.hot{position:absolute;border:3px solid var(--o);border-radius:8px;box-shadow:0 0 0 9999px rgba(20,10,20,.45);cursor:pointer;animation:pulse 1.6s infinite}
.hot:focus{outline:3px solid #fff}
.badge{position:absolute;transform:translate(-50%,-50%);width:34px;height:34px;border-radius:50%;background:var(--b);color:#fff;border:2px solid #fff;font-weight:700;display:grid;place-items:center;font-size:15px;pointer-events:none}
@keyframes pulse{0%,100%{border-color:var(--o)}50%{border-color:#FF893F}}
aside{display:flex;flex-direction:column;gap:14px}.card{background:#fff;border-radius:10px;padding:18px;box-shadow:0 2px 10px rgba(93,15,67,.08)}
.k{font-size:13px;color:var(--p);font-weight:700;letter-spacing:.04em;text-transform:uppercase}.t{font-size:22px;line-height:1.3;margin:6px 0 0;color:var(--b);font-weight:700}
.tip{background:#FDE1D2}.tip b{color:var(--b)}
.nav{display:flex;gap:10px}button{font:inherit;border:0;border-radius:8px;padding:10px 16px;cursor:pointer;background:var(--b);color:#fff}button.ghost{background:#fff;color:var(--b);border:1px solid #f9e3de}
ol{margin:0;padding-left:20px;line-height:1.7;font-size:14px}ol li.on{color:var(--p);font-weight:700}ol li{cursor:pointer}
.hint{font-size:13px;color:#404040}
@media(max-width:820px){main{grid-template-columns:1fr}}
.all{display:none}
@media print{header,.bar,main{display:none}.all{display:block}.all section{page-break-after:always;break-inside:avoid;padding:20px}.all .stage{width:auto}.all .stage img{max-height:none;width:100%}.all .hot{box-shadow:none}.all h2{color:var(--b)}.all .stage{box-shadow:none}}
</style></head><body>
<header><div><h1>__TITLE__</h1><p>__SUB__</p></div><div class="prog" id="prog"></div></header><div class="bar"><i id="bar"></i></div>
<main><div class="stage" id="stage"></div><aside>
<div class="card"><div class="k" id="k"></div><p class="t" id="t"></p></div>
<div class="card tip" id="tipc"><b>Tip</b><div id="tip"></div></div>
<div class="nav"><button class="ghost" id="back">← Back</button><button id="next">Next →</button><button class="ghost" onclick="print()" title="Every step on its own page - choose Save as PDF">Print / PDF</button></div>
<div class="hint">Click the highlighted spot, or use the arrow keys.</div>
<div class="card"><ol id="list"></ol></div></aside></main>
<div class="all" id="all"></div>
<script>
const S=__DATA__;let i=0;const $=id=>document.getElementById(id);
function bpos(s){const[x,y,w,h]=s.box,bw=3.2,bh=bw/s.ratio;   // badge outside the ring: left, else above, else right
if(x>bw+1)return`left:${x-bw/2-0.6}%;top:${y+h/2}%`;if(y>bh+1)return`left:${x+bw/2}%;top:${y-bh/2-0.6}%`;return`left:${x+w+bw/2+0.6}%;top:${y+h/2}%`}
function show(n){i=Math.max(0,Math.min(S.length-1,n));const s=S[i],[x,y,w,h]=s.box;
$('stage').innerHTML=`<img src="${s.img}" alt="Step ${s.n} screen"><div class="hot" tabindex="0" role="button" aria-label="Step ${s.n}: ${s.text.replace(/"/g,'')}" style="left:${x}%;top:${y}%;width:${w}%;height:${h}%"></div><div class="badge" style="${bpos(s)}">${s.n}</div>`;
$('k').textContent=`Step ${s.n} of ${S.length}`;$('t').textContent=s.text;$('tip').textContent=s.tip;$('tipc').style.display=s.tip?'':'none';
$('prog').textContent=`${Math.round((i+1)/S.length*100)}% complete`;$('bar').style.width=((i+1)/S.length*100)+'%';
$('back').disabled=i===0;$('next').textContent=i===S.length-1?'Done ✓':'Next →';
[...$('list').children].forEach((li,j)=>li.className=j===i?'on':'');
try{history.replaceState(null,'','#'+s.n)}catch(e){}
const hot=document.querySelector('.hot');{const r=hot.getBoundingClientRect();if(r.top<0||r.bottom>innerHeight)hot.scrollIntoView({block:'center'})}hot.onclick=()=>show(i+1);hot.onkeydown=e=>{if(e.key==='Enter'||e.key===' ')show(i+1)}}
$('list').innerHTML=S.map((s,j)=>`<li onclick="show(${j})">${s.text.replace(/</g,'&lt;')}</li>`).join('');
$('all').innerHTML=S.map(s=>`<section><h2>Step ${s.n}. ${s.text.replace(/</g,'&lt;')}</h2><div class="stage" style="position:relative"><img src="${s.img}" style="width:100%"><div class="hot" style="left:${s.box[0]}%;top:${s.box[1]}%;width:${s.box[2]}%;height:${s.box[3]}%;animation:none"></div></div>${s.tip?`<p><b>Tip:</b> ${s.tip.replace(/</g,'&lt;')}</p>`:''}</section>`).join('');
$('back').onclick=()=>show(i-1);$('next').onclick=()=>show(i+1);
document.addEventListener('keydown',e=>{if(e.key==='ArrowRight')show(i+1);if(e.key==='ArrowLeft')show(i-1)});const fromHash=()=>show(((location.hash.match(/\d+/)||['1'])[0]|0)-1);fromHash();addEventListener('hashchange',fromHash);   // #4 opens step 4; the address always shows the current step (copy it to share)
</script></body></html>"""


# ------------------------------------------------------------------------------------------------ commands
def open_image(p):
    """The screenshot as RGB, or (None, a plain-English problem) - iPhone HEIC, PDFs and broken files say what to do."""
    from PIL import Image
    try:
        return Image.open(p).convert("RGB"), None
    except FileNotFoundError:
        return None, f"{Path(p).name} not found"
    except Exception:
        return None, (f"{Path(p).name} is not a picture this can read - save it as PNG or JPG (iPhone: a screenshot, "
                      "or Settings > Camera > Formats > Most Compatible)")


def cmd_marks(a):
    from PIL import Image, ImageDraw
    thumbs = []
    for k, p in enumerate(a.images, 1):
        im, err = open_image(p)
        if err:
            print(f"  {k}. {err}"); continue
        f0 = min(1.0, MAX_W / im.width)               # look exactly as build does (it scales first)
        work = im.resize((int(im.width * f0), int(im.height * f0))) if f0 < 1 else im
        ms = [[int(v / f0) for v in m] for m in find_marks(work)]
        m = ms[0] if ms else None
        print(f"  {k}. {Path(p).name}: " + (f"mark at x={m[0]} y={m[1]} w={m[2]} h={m[3]}" if m else "NO red mark found")
              + (f" - {len(ms)} marks found, the biggest is used: one mark per screenshot" if len(ms) > 1 else ""))
        t = im.copy(); t.thumbnail((480, 300))
        if m:
            f = t.width / im.width
            ImageDraw.Draw(t).rectangle([m[0] * f, m[1] * f, (m[0] + m[2]) * f, (m[1] + m[3]) * f], outline=(242, 105, 35), width=3)
        ImageDraw.Draw(t).text((6, 4), str(k), fill=(93, 15, 67))
        thumbs.append(t)
    if thumbs and a.out:
        cols = min(3, len(thumbs)); rows = (len(thumbs) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * 490, rows * 310), (255, 245, 243))
        for i, t in enumerate(thumbs):
            sheet.paste(t, ((i % cols) * 490 + 5, (i // cols) * 310 + 5))
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        sheet.save(a.out); print(f"PICTURE {a.out}")


def cmd_build(a):
    g = json.loads(Path(a.guide).read_text(encoding="utf-8"))
    out = Path(a.out).with_suffix("")
    out.parent.mkdir(parents=True, exist_ok=True)
    work = out.parent / (out.name + "_steps"); work.mkdir(exist_ok=True)
    problems, steps = [], []
    for k, s in enumerate(g.get("steps") or [], 1):
        if not str(s.get("text") or "").strip():
            problems.append(f"step {k}: no instruction text"); continue
        if len(s["text"]) > 56:
            problems.append(f"step {k}: instruction is {len(s['text'])} characters - keep it to 56 (it is the slide headline)")
        shot, zoom, plain, box, err = prepare(s, k, work)
        if err:
            problems.append(err); continue
        steps.append(dict(s, _shot=shot, _zoom=zoom, _plain=plain, _box=box))
    if not g.get("steps"):
        problems.append("the guide has no steps - add one {\"image\": …, \"text\": …} per screenshot")
    if not str(g.get("title") or "").strip():
        problems.append("the guide has no title")
    if problems:
        print("NEEDS CORRECTION | nothing built")
        for p in problems: print("  FAIL " + p)
        sys.exit(1)
    sb = work / "storyboard.json"; sb.write_text(json.dumps(storyboard(g, steps)))
    pptx = out.with_suffix(".pptx")
    r = subprocess.run([sys.executable, str(TOOLS / "build_deck.py"), "build", str(sb), "--out", str(pptx), "--no-tokens"], capture_output=True, text=True)
    deck_lines = [l for l in r.stdout.strip().splitlines() if not l.startswith("TOKENS")]
    page = out.with_suffix(".html"); page.write_text(html(g, steps), encoding="utf-8")
    import htmlpdf, compliance
    htmlpdf.ensure(page)
    pdf = pptx.parent / (pptx.stem + "_validation") / (pptx.stem + ".pdf")
    if pdf.exists():
        import shutil; shutil.copyfile(pdf, out.with_suffix(".pdf"))
    status = deck_lines[0] if deck_lines else "deck not built: " + r.stderr[-300:]
    import brand_colours
    off = brand_colours.gate([page])                      # the guide page too: zero deviation from the template palette
    if off and status.startswith("READY"):
        status = "NEEDS CORRECTION" + status[len("READY"):]
    print(f"{status.split(' |')[0]} | {pptx.name}, {page.name}" + (f", {out.with_suffix('.pdf').name}" if pdf.exists() else "")
          + f" | {len(steps)} steps")
    for l in deck_lines[1:8]:
        print(l)
    blk = [x for x in compliance.scan([page]) if x["severity"] == "BLOCK"]
    for x in blk[:3]:
        print(f"  FAIL {x['kind']} in the guide text - remove it")
    for x in off[:5]:
        print("  " + x)
    print("  Screens are images: blur or crop customer names, prices and personal data BEFORE taking the screenshots"
          " (or use test data) - the text checks cannot read inside pictures.")
    import tokens as TK
    print(TK.report(pptx, Path(a.guide).read_text(encoding="utf-8"), "\n".join(deck_lines), "walkthrough"))


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    m = sub.add_parser("marks"); m.add_argument("images", nargs="+"); m.add_argument("--out", default="/mnt/data/out/marks.png")
    b = sub.add_parser("build"); b.add_argument("guide"); b.add_argument("--out", required=True)
    a = ap.parse_args()
    {"marks": cmd_marks, "build": cmd_build}[a.cmd](a)


if __name__ == "__main__":
    main()
