"""Approved slide library: slides inserted exactly as approved (company overview, legal disclaimer, org, contacts).

    python tools/library.py add Approved.pptx --slide 4 --key legal-disclaimer --title "Legal disclaimer"
    python tools/library.py list
    storyboard: {"library": "legal-disclaimer"}           # the slide goes in unchanged, never regenerated

Each slide is stored as a one-slide file plus its fingerprint (shapes, text and pictures) in library.json, per brand:
/mnt/data/brands/<brand>/library (this conversation) or the skill's brands/<brand>/library (permanent).
The validator re-computes the fingerprint of every library slide in a deck: any change = FAIL.
"""
import argparse, datetime, hashlib, json, sys
from pathlib import Path

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import brand as B   # noqa: E402

R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_open = {}


def dirs(brand=None):
    b = brand or B.current()
    out = []
    for base in (B.RUN_BRANDS, B.SKILL_BRANDS):
        d = base / b.name / "library"
        if d.exists():
            out.append(d)
    return out


def catalogue(brand=None):
    cat = {}
    for d in reversed(dirs(brand)):                 # conversation library overrides the skill's
        f = d / "library.json"
        if f.exists():
            for k, v in json.loads(f.read_text()).items():
                cat[k] = dict(v, path=str(d / f"{k}.pptx"))
    return cat


def slide_hash_of(slide):
    """Fingerprint of a slide: its shape tree with picture links replaced by the pictures' own hashes."""
    tree = etree.fromstring(etree.tostring(slide.shapes._spTree))
    for el in tree.iter():
        for a in list(el.attrib):
            if a.startswith(R) and el.attrib[a] in slide.part.rels:
                rel = slide.part.rels[el.attrib[a]]
                el.attrib[a] = "ext:" + rel.target_ref if rel.is_external else hashlib.sha256(rel.target_part.blob).hexdigest()[:20]
    for el in tree.iter("{http://schemas.openxmlformats.org/presentationml/2006/main}cNvPr"):
        el.attrib.pop("id", None)                  # ids are renumbered on import
    for el in tree.iter():
        if etree.QName(el).localname in ("stCxn", "endCxn"):
            el.attrib.pop("id", None)
    return hashlib.sha256(etree.tostring(tree, method="c14n")).hexdigest()


def slide(key):
    cat = catalogue()
    if key not in cat:
        raise SystemExit(f"no library slide {key!r}; available: {', '.join(cat) or 'none'} (tools/library.py add ...)")
    from pptx import Presentation
    if key not in _open:
        _open[key] = Presentation(cat[key]["path"])
    return _open[key].slides[0]


def add(src, number, key, title):
    from pptx import Presentation
    b = B.current()
    base = (B.RUN_BRANDS if B.RUN_BRANDS.parent.exists() else B.SKILL_BRANDS) / b.name / "library"
    base.mkdir(parents=True, exist_ok=True)
    prs = Presentation(str(src))
    lst = prs.slides._sldIdLst
    for i, sid in reversed(list(enumerate(list(lst), 1))):
        if i != number:
            prs.part.drop_rel(sid.rId); lst.remove(sid)
    out = base / f"{key}.pptx"
    import atomic
    atomic.save(prs, out)
    h = slide_hash_of(Presentation(str(out)).slides[0])
    f = base / "library.json"
    cat = json.loads(f.read_text()) if f.exists() else {}
    cat[key] = {"title": title or key, "sha256": h, "source": Path(src).name, "slide": number,
                "added": datetime.date.today().isoformat()}
    f.write_text(json.dumps(cat, indent=1))
    return out


def verify(deck, entries):
    """[(slide, key, ok)] for the library slides recorded in a deck's .ulta.json."""
    from pptx import Presentation
    prs = Presentation(str(deck))
    cat = catalogue()
    out = []
    for e in entries:
        i, key = e["slide"], e["key"]
        want = (cat.get(key) or {}).get("sha256") or e.get("sha256")
        ok = i <= len(prs.slides) and slide_hash_of(prs.slides[i - 1]) == want
        out.append((i, key, ok))
    return out


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    a_ = sub.add_parser("add"); a_.add_argument("pptx"); a_.add_argument("--slide", type=int, required=True)
    a_.add_argument("--key", required=True); a_.add_argument("--title")
    sub.add_parser("list")
    a = ap.parse_args()
    if a.cmd == "add":
        print(f"added {a.key}: {add(a.pptx, a.slide, a.key, a.title)}")
    else:
        cat = catalogue()
        for k, v in cat.items():
            print(f"{k:24} {v['title']}  (from {v['source']} slide {v['slide']}, {v['added']})")
        if not cat:
            print("library is empty: tools/library.py add <approved.pptx> --slide N --key <name>")


if __name__ == "__main__":
    main()
