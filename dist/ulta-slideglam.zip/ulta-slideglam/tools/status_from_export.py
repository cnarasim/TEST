"""Weekly status one-pager straight from a tracker export (Jira, ServiceNow, Smartsheet, Azure DevOps, Excel).
Next week: upload the new export and run the same command - that is the refresh.

    python tools/status_from_export.py export.csv --project "Customer Portal Launch" --lead "Name" \
        [--as-of 2026-10-10] [--sheet Tasks] --out /mnt/data/out/Portal-Status

Reads columns by their usual names (any order, case-insensitive):
  item      Summary | Short description | Task Name | Title | Name
  group     Epic Link | Epic | Component | Workstream | Parent | Category | Area Path   (one status row each)
  status    Status | State                  owner  Assignee | Assigned to | Owner
  due       Due date | Due | End Date | Target date      done-on  Resolved | Closed | Updated | Changed Date
  priority  Priority | Severity             rag    RAG | Health | Status Color          labels Labels | Tags
Rules (written into the one-pager's notes so readers can see how RAG was set):
  Red    a blocked item, or an open item past its due date
  Amber  an open item due in the next 7 days with no progress, or a high-priority open item
  Green  otherwise. Overall = the worst workstream. An explicit RAG/Health column always wins.
  This week = items finished in the last 7 days; next week = items due in the next 7 days.
  Risks = blocked items, overdue high-priority items, items labelled risk/issue.
  Milestones = items labelled milestone (or of type Milestone/Epic), next four by due date.
  Decision = an item labelled decision, or whose title starts with "Decide"/"Decision".
Then: kit one-pager -> brand conform -> native editing -> accessibility -> sensitive-data scan -> stamp.
"""
import argparse, collections, datetime, re, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import data_slides as DS   # noqa: E402

COLS = {
    "item": ["summary", "short description", "short_description", "task name", "title", "name", "work item"],
    "group": ["epic link", "epic", "epic name", "component", "components", "workstream", "parent", "category",
              "area path", "project phase", "assignment group"],
    "status": ["status", "state"],
    "owner": ["assignee", "assigned to", "assigned_to", "owner", "assigned"],
    "due": ["due date", "due", "end date", "target date", "due_date", "finish"],
    "done_on": ["resolved", "closed", "resolution date", "closed date", "updated", "changed date", "sys_updated_on"],
    "priority": ["priority", "severity", "impact"],
    "rag": ["rag", "health", "status color", "rag status"],
    "labels": ["labels", "tags", "label"],
    "type": ["issue type", "type", "work item type"],
}
DONE = re.compile(r"(?i)\b(done|closed|resolved|complete|completed|cancel+ed|finished)\b")
BLOCKED = re.compile(r"(?i)\b(blocked|on hold|impediment|waiting)\b")
HIGH = re.compile(r"(?i)\b(highest|high|critical|blocker|urgent|p1|p2|1 - |2 - )")
ORDER = {"Green": 0, "Amber": 1, "Red": 2}


def find_cols(header):
    low = [str(h).strip().lower() for h in header]
    return {k: next((low.index(n) for n in names if n in low), None) for k, names in COLS.items()}


def date_of(v):
    if isinstance(v, datetime.datetime):
        return v.date()
    if isinstance(v, datetime.date):
        return v
    s = str(v or "").strip()
    if not s:
        return None
    s = re.split(r"[ T]", s)[0]
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%d/%m/%Y", "%m/%d/%y", "%d-%b-%Y", "%d-%b-%y", "%d/%b/%y", "%b %d, %Y"):
        try:
            return datetime.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def rag_word(v):
    s = str(v or "").lower()
    if "red" in s or "off track" in s or "critical" in s:
        return "Red"
    if "amber" in s or "yellow" in s or "at risk" in s:
        return "Amber"
    if "green" in s or "on track" in s:
        return "Green"
    return None


def short(t, n=70):
    t = re.sub(r"\s+", " ", str(t or "")).strip()
    return t if len(t) <= n else t[:n - 1].rsplit(" ", 1)[0] + "…"


def md_date(d):
    return d.strftime("%m/%d") if d else "—"


def build_md(rows, project, lead, today, phase):
    header, body = rows[0], rows[1:]
    c = find_cols(header)
    if c["item"] is None or c["status"] is None:
        raise SystemExit(f"need at least a summary/title column and a status column; found {header}")
    get = lambda r, k: (r[c[k]] if c[k] is not None and c[k] < len(r) else "")
    items = []
    for r in body:
        it = {k: get(r, k) for k in COLS}
        it["due"], it["done_on"] = date_of(it["due"]), date_of(it["done_on"])
        it["done"] = bool(DONE.search(str(it["status"])))
        it["blocked"] = bool(BLOCKED.search(str(it["status"]))) or "block" in str(it["labels"]).lower()
        it["group"] = str(it["group"]).strip() or project
        it["labels"] = str(it["labels"]).lower()
        items.append(it)
    week = today + datetime.timedelta(days=7)
    groups = collections.OrderedDict()
    for it in items:
        groups.setdefault(it["group"], []).append(it)
    lines_ws, worst = [], "Green"
    why = []
    for g, its in groups.items():
        open_ = [i for i in its if not i["done"]]
        explicit = [rag_word(i["rag"]) for i in its if rag_word(i["rag"])]
        if explicit:
            rag = max(explicit, key=ORDER.get); reason = "RAG column"
        elif any(i["blocked"] for i in open_) or any(i["due"] and i["due"] < today for i in open_):
            rag = "Red"; reason = "blocked or overdue item"
        elif any(i["due"] and today <= i["due"] <= week for i in open_) or any(HIGH.search(str(i["priority"])) for i in open_):
            rag = "Amber"; reason = "due this week or high priority open"
        else:
            rag = "Green"; reason = "no overdue or blocked items"
        worst = max(worst, rag, key=ORDER.get)
        owner = collections.Counter(str(i["owner"]).strip() for i in its if str(i["owner"]).strip()).most_common(1)
        done_wk = [i for i in its if i["done"] and i["done_on"] and today - datetime.timedelta(days=7) <= i["done_on"] <= today]
        next_wk = [i for i in open_ if i["due"] and today < i["due"] <= week]
        lines_ws.append(f"| {short(g, 40)} | {owner[0][0] if owner else '—'} | {rag} | "
                        f"{'; '.join(short(i['item'], 45) for i in done_wk[:2]) or '—'} | "
                        f"{'; '.join(short(i['item'], 45) for i in next_wk[:2]) or '—'} |")
        why.append(f"{g}: {rag} ({reason})")
    risks = [i for i in items if not i["done"] and (i["blocked"] or "risk" in i["labels"] or "issue" in i["labels"]
             or (i["due"] and i["due"] < today and HIGH.search(str(i["priority"]))))]
    risks.sort(key=lambda i: (not i["blocked"], i["due"] or datetime.date.max))
    risk_lines = [f"| {short(i['item'], 80)} | {short(i['group'], 30)} | {str(i['owner']).strip() or '—'} | "
                  f"{md_date(i['due'])} | {'Red' if i['blocked'] or (i['due'] and i['due'] < today) else 'Amber'} |"
                  for i in risks[:4]]
    ms = [i for i in items if "milestone" in i["labels"] or str(i["type"]).strip().lower() in ("milestone", "epic")]
    ms = sorted([i for i in ms if i["due"]], key=lambda i: i["due"])
    upcoming = [i for i in ms if i["due"] >= today - datetime.timedelta(days=7)][:4] or ms[-4:]
    dec = next((i for i in items if not i["done"] and ("decision" in i["labels"] or
                re.match(r"(?i)\s*(decide|decision)", str(i["item"])))), None)
    wd = today.weekday()                       # the Friday of this week; at the weekend, the one just passed
    week_end = today + datetime.timedelta(days=(4 - wd) if wd <= 4 else -(wd - 4))
    md = [f"# {project} - Weekly Status", f"Week ending: {md_date(week_end)}", f"Overall status: {worst}",
          f"Project lead: {lead or '—'}", f"Phase: {phase or '—'}", "",
          "## Workstreams",
          f"| Workstream | Owner | Status | This week ({md_date(today)}) | Next week ({md_date(week)}) |",
          "|---|---|---|---|---|", *lines_ws, ""]
    if risk_lines:
        md += ["## Risks & support required", "| Risk or ask | Support needed from | Owner | Need by | Severity |",
               "|---|---|---|---|---|", *risk_lines, ""]
    if upcoming:
        md += ["## Milestones", *[f"- {md_date(i['due'])}: {short(i['item'], 60)}" for i in upcoming], ""]
    md += ["## Decision needed", short(dec["item"], 140) if dec else "—", ""]
    notes = (f"Built from the tracker export on {today:%Y-%m-%d}: {len(items)} items, {len(groups)} workstreams. "
             "RAG rules: Red = blocked or overdue open item; Amber = open item due within 7 days or high priority "
             "open; Green = otherwise; an explicit RAG/Health column wins. " + " · ".join(why))
    return "\n".join(md), notes, worst


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, (r.stdout + r.stderr).strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("export"); ap.add_argument("--project", required=True); ap.add_argument("--lead")
    ap.add_argument("--phase"); ap.add_argument("--as-of"); ap.add_argument("--sheet")
    ap.add_argument("--out", required=True); ap.add_argument("--format", default="onepager")
    ap.add_argument("--classification")
    a = ap.parse_args()
    today = date_of(a.as_of) if a.as_of else datetime.date.today()
    md, notes, overall = build_md(DS.read_table(a.export, a.sheet), a.project, a.lead, today, a.phase)
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    import plain                                         # plain punctuation: no em dashes in what a reader sees
    mdp = out.with_suffix(".md"); mdp.write_text(plain.markdown(md), encoding="utf-8")
    kit = TOOLS.parent / "modules" / "ultabranddeliverables" / "scripts" / "ulta.py"
    code, log = run([sys.executable, "-I", str(kit), "infographic", str(mdp), "--template", "status",
                     "--format", a.format, "--out", str(out)])
    if code:
        sys.exit(f"kit failed: {log[-400:]}")
    pptx = out.with_suffix(".pptx")
    files = [str(p) for p in (pptx, out.with_suffix(".svg"), out.with_suffix(".html")) if p.exists()]
    import htmlpdf
    for f in files:
        if f.endswith(".html"): htmlpdf.frame(f)              # in the chat's preview frame, say so if saving is blocked
    _, conf = run([sys.executable, str(TOOLS / "ulta_conform.py"), *files, "--keep-sizes"])
    run([sys.executable, str(TOOLS / "nativize.py"), str(pptx)])
    from pptx import Presentation
    prs = Presentation(str(pptx))
    prs.slides[0].notes_slide.notes_text_frame.text = plain.text(notes)
    import atomic
    atomic.save(prs, pptx); plain.clean_all(files)
    import a11y, compliance, stamp
    a11y.fix(pptx, flat_all=True)                    # the kit draws flat: no theme shadow
    if a.classification:
        compliance.classify(pptx, a.classification)
    sens = compliance.scan(files)
    blk = [x for x in sens if x["severity"] == "BLOCK"]
    af, ar = a11y.check(pptx)
    brand_line = next((l for l in conf.splitlines() if l.startswith(("BRAND CHECK", "RESULT"))), "")
    result = "NEEDS CORRECTION" if blk or af or "FAIL" in brand_line else "READY"
    ver = stamp.stamp(pptx, f"status refresh from {Path(a.export).name}", result, a.lead, a.classification)
    print(f"STATUS {overall} | {result} | v{ver} | {pptx}")
    print(f"  source md: {mdp} (edit and re-run the kit if wording needs changing)")
    for x in blk + [x for x in sens if x["severity"] == "REVIEW"][:5]:
        print(f"  {x['severity']} {x['where']}: {x['kind']} '{x['match']}'")
    for x in af:
        print("  FAIL " + x)
    print("  " + brand_line if brand_line else "")


if __name__ == "__main__":
    main()
