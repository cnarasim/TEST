"""Process flows drawn natively in the Ulta template's own visual language (tools/native_draw.py).

A process is steps in order. Every style is built from the template's parts - the blush page, white rounded cards,
header bars and chevrons in the theme colours (template order: magenta, pink-red, red-orange, orange), Circular text on
the template's type scale, Playfair numbers - so it sits next to the template's own flow slide (20) as if it came with
it. Shapes are native and grouped (one object to move), text sits inside its shape, connectors are glued, white words
only where they read (small white words only on magenta and plum; on the orange and red family from 18 pt).

Storyboard slide:   {"process": {...}, "style": "<style>", "headline": "<takeaway>", "notes": "..."}
Process data:       {"steps": [{"title", "text", "owner", "value", "rate", "items", "when", "outcome"}] or ["Title: text"],
                     "center" (cycle), "inputs" / "outputs" (io), "result" (converge), "source" (diverge)}
  title             1-3 words (the step's name); text one line of detail (the limit depends on the style)
  value / rate      pipeline: the stage's number ("1.2M") and the share that moves on to the next stage ("38%")
  items / when / outcome   phases: the phase's activities (2-4), its timing ("Weeks 1-4"), what it ends with
  icon              a pictogram for the step (truck, dc, store, vendor, invoice ... tools/pictograms.py) or one of the
                    template's icons; "icons": "auto" on the process gives every step the one its words call for. The
                    circles then show the pictogram with a small number tag; cards carry it beside or above the text.

Styles (STYLES, gallery order) - when to use them and their limits:
  chevrons          steps in order as chevron arrows with a card of detail under each - 3-6 steps
  arrow             one process arrow, numbered stations on it, detail cards above and below in turn - 4-7 steps
  numbered          numbered circles on one line, a card under each - 3-7 steps
  cycle             a loop that repeats (plan-do-check-act, a review rhythm): the ring of numbered steps around its
                    purpose, the steps' detail beside it - 3-6 steps
  snake             a long process in two rows, the path turning back like a road - 5-10 steps
  vertical          steps down a spine, a wide card each: when every step needs a sentence - 3-6 steps
  phases            phases as chevron headers, each with its timing, 2-4 activities and its outcome - 2-5 phases
  pipeline          stages with their numbers and the share that moves on between them - 3-5 stages
  io                inputs -> the process -> outputs, in three columns joined by arrows - 2-5 of each
  converge          several inputs coming together in one result - 2-5 inputs
  diverge           one source branching into several results - 2-5 results

    import flows as FL
    style = FL.auto_style(spec["process"]); problems = FL.lint(spec) + FL.draw(slide, box, spec)
"""
import math
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # run on its own (python -I too): its sibling modules
import native_draw as ND
import pictograms as PG
import timelines as TL                                      # the canvas, text measuring and fit checks of the drawn families

IN = ND.IN
_in, _para = TL._in, TL._para

STYLES = {
    "chevrons": "Steps in order as chevron arrows in the template colours, a card of detail under each (3-6 steps)",
    "arrow": "One process arrow with numbered stations, detail cards above and below in turn (4-7 steps)",
    "numbered": "Numbered circles on one line, a card of detail under each (3-7 steps)",
    "cycle": "A loop that repeats: numbered steps around a ring with the loop's purpose in the middle, the detail of "
             "each step beside it (3-6 steps)",
    "snake": "A long process in two rows, the path turning back like a road, numbered stops with their detail "
             "(5-10 steps)",
    "vertical": "Steps down a spine of numbered circles, a wide card each: when every step needs a sentence (3-6 steps)",
    "phases": "Phases as chevron headers, each with its timing, 2-4 activities and its outcome (2-5 phases)",
    "pipeline": "Stages with their numbers and the share that moves on to the next one (3-5 stages)",
    "io": "Inputs, the process and outputs in three columns joined by arrows (2-5 of each)",
    "converge": "Several inputs coming together in one result (2-5 inputs)",
    "diverge": "One source branching into several results (2-5 results)",
}
LIMITS = {"chevrons": (3, 6), "arrow": (4, 7), "numbered": (3, 7), "cycle": (3, 6), "snake": (5, 10), "vertical": (3, 6),
          "phases": (2, 5), "pipeline": (3, 5), "io": (1, 6), "converge": (2, 5), "diverge": (2, 5)}
DENSE_LIMITS = {"chevrons": (3, 7), "arrow": (4, 8), "numbered": (3, 8), "cycle": (3, 7), "snake": (5, 12),
                "vertical": (3, 8), "phases": (2, 5), "pipeline": (3, 5), "io": (1, 8), "converge": (2, 6),
                "diverge": (2, 6)}                     # a slide set dense: more steps (and about twice the words)


HINT = ""                                           # (no dense setting in this skill: a limit says only the limit)


def is_dense(spec):
    """A slide set dense ("density": "dense" on the slide or its deck): more steps and words, type down to 10.5 pt."""
    spec = spec or {}
    return bool(spec.get("_dense")) or str(spec.get("density") or "").strip().lower() in ("dense", "compact")


# ============================================================================================ data
def _words(t):
    return len(str(t or "").split())


def _step(v):
    """A step from a dict or a 'Title: text' string."""
    if isinstance(v, dict):
        title = str(v.get("title") or v.get("name") or v.get("label") or v.get("step") or "").strip()
        text = str(v.get("text") or v.get("detail") or v.get("description") or "").strip()
        items = v.get("items") or v.get("activities") or []
        if isinstance(items, str):
            items = [x for x in re.split(r"[;\n]", items) if x.strip()]
        return {"title": title, "text": text, "owner": str(v.get("owner") or "").strip(),
                "value": str(v.get("value") or "").strip(), "rate": str(v.get("rate") or v.get("conversion") or "").strip(),
                "items": [str(x).strip() for x in items if str(x).strip()], "when": str(v.get("when") or "").strip(),
                "outcome": str(v.get("outcome") or "").strip(), "icon": str(v.get("icon") or "").strip().lower()}
    s = str(v or "").strip()
    title, sep, text = s.partition(":")
    if not sep or _words(title) > 4:
        title, text = s, ""
    text = text.strip()
    if len(text) > 1 and text[0].islower() and (text[1].islower() or text[1] == " "):
        text = text[0].upper() + text[1:]                       # 'Receive: guest drops it' -> 'Guest drops it'
    return {"title": title.strip(), "text": text, "owner": "", "value": "", "rate": "", "items": [], "when": "",
            "outcome": "", "icon": ""}


def _data(data):
    if isinstance(data, list):
        data = {"steps": data}
    if not isinstance(data, dict):
        return None
    d = dict(data)
    d["steps"] = [_step(s) for s in (data.get("steps") or []) if s]
    for k in ("inputs", "outputs"):
        d[k] = [_step(s) for s in (data.get(k) or []) if s]
    for k in ("result", "source"):
        v = data.get(k) or (data.get("outcome") if k == "result" else None)
        d[k] = _step(v) if v else None
    d["center"] = str(data.get("center") or data.get("purpose") or "").strip()
    d["icons_on"] = str(data.get("icons") if data.get("icons") is not True else "auto").strip().lower() in \
        ("auto", "on", "yes", "true", "1") or any(s["icon"] for s in _items(d))
    _resolve_icons(d)
    return d


ICON_STYLES = ("chevrons", "arrow", "numbered", "cycle", "snake", "vertical", "io", "converge", "diverge")


def _items(D):
    return D["steps"] + D["inputs"] + D["outputs"] + [x for x in (D.get("result"), D.get("source")) if x]


def _resolve_icons(D):
    """When the process asks for icons, every item gets one: its own, else the pictogram its words call for (a
    different one for each where the words allow)."""
    if not D["icons_on"]:
        return
    items = _items(D)
    for s, n in zip(items, PG.assign([(s["title"], s["text"], s["icon"]) for s in items])):
        if not s["icon"]:
            s["icon"], s["auto_icon"] = n, True


def auto_style(data):
    """The style the content asks for, when the slide names none."""
    D = _data(data) or {"steps": []}
    st = D["steps"]
    if D.get("inputs") or D.get("outputs"):
        return "io"
    if D.get("result"):
        return "converge"
    if D.get("source"):
        return "diverge"
    if D.get("center") or (isinstance(data, dict) and data.get("cycle")):
        return "cycle"
    if any(s["items"] for s in st):
        return "phases"
    if any(s["value"] for s in st):
        return "pipeline"
    n = len(st)
    if n >= 7:
        return "snake"
    if st and sum(_words(s["text"]) for s in st) / len(st) > 12:
        return "vertical"
    return "chevrons" if n <= 5 else "numbered"


# ============================================================================================ lint
def lint(spec):
    """Content problems for the slide's style - each says how to fix it."""
    spec = spec or {}
    D = _data(spec.get("process"))
    if D is None:
        return ["\"process\" needs an object: {\"steps\": [{\"title\": \"...\", \"text\": \"...\"}, ...]}"]
    style = spec.get("style") or auto_style(spec.get("process"))
    if style not in STYLES:
        return [f"process style '{style}' does not exist - use one of: {', '.join(STYLES)}"]
    P, st = [], D["steps"]
    d = is_dense(spec)
    lo, hi = (DENSE_LIMITS if d else LIMITS)[style]
    grow = (lambda v: round(v * 1.8)) if d else (lambda v: v)    # a dense slide: about twice the words
    n = len(st)
    if style == "io":
        io_hi, io_w = (7, 14) if d else (5, 8)
        for k, what in (("inputs", "inputs"), ("outputs", "outputs")):
            if not 1 <= len(D[k]) <= io_hi:
                P.append(f"{len(D[k])} {what} - the io style lists 1-{io_hi} {what} (\"{k}\": [...])"
                         + (HINT if len(D[k]) > io_hi and not d else ""))
        if not 1 <= n <= hi:
            P.append(f"{n} process steps - the io style shows 1-{hi} in the middle column")
        for s in D["inputs"] + D["outputs"] + st:
            if _words(s["title"] + " " + s["text"]) > io_w:
                P.append(f"'{(s['title'] + ' ' + s['text']).strip()[:40]}' is {_words(s['title'] + ' ' + s['text'])} words - "
                         f"keep each input, step and output to {io_w}" + ("" if d else HINT))
                break
        return P
    if not lo <= n <= hi:
        P.append(f"{n} step{'s' if n != 1 else ''} - the {style} style shows {lo}-{hi}" +
                 (" (use snake for a longer process, or split it over two slides)" if n > hi else "") +
                 (HINT if n > hi and not d else ""))
    if style == "converge" and not D.get("result"):
        P.append("converge needs the \"result\" the inputs come together in: {\"title\": \"...\", \"text\": \"...\"}")
    if style == "diverge" and not D.get("source"):
        P.append("diverge needs the \"source\" the results branch from: {\"title\": \"...\", \"text\": \"...\"}")
    missing = [s for s in st if not s["title"]]
    if missing:
        P.append("a step has no title - give every step a 1-3 word \"title\"")
    title_cap = (3 if style in ("chevrons", "phases", "cycle", "arrow") else 4) + (1 if d and style not in
                                                                                    ("chevrons", "phases") else 0)
    long_t = [s for s in st if _words(s["title"]) > title_cap]
    if long_t:
        P.append(f"step title '{long_t[0]['title'][:40]}' is {_words(long_t[0]['title'])} words - name a step in "
                 f"1-{title_cap} words (the detail goes in its text)")
    cap = grow({"vertical": 24, "cycle": 16, "phases": 0, "pipeline": 10, "converge": 14, "diverge": 14, "snake": 10,
                "arrow": 14, "numbered": 14 if n <= 5 else 10, "chevrons": 16 if n <= 4 else 12}.get(style, 14))
    long_x = [s for s in st if cap and _words(s["text"]) > cap]
    if long_x:
        P.append(f"step '{long_x[0]['title'][:30]}': its text is {_words(long_x[0]['text'])} words - with {n} steps the "
                 f"{style} style gives each {cap} (the detail goes in the speaker notes)" + ("" if d else HINT))
    if style == "phases":
        most, aw = (6, 14) if d else (4, 8)
        for s in st:
            if not 1 <= len(s["items"]) <= most:
                P.append(f"phase '{s['title'][:30]}' has {len(s['items'])} activities - list 1-{most} (\"items\": [...])"
                         + (HINT if len(s["items"]) > most and not d else ""))
            if any(_words(x) > aw for x in s["items"]):
                P.append(f"phase '{s['title'][:30]}': keep each activity to {aw} words" + ("" if d else HINT))
    if style == "pipeline":
        if not all(s["value"] for s in st):
            P.append("every pipeline stage needs its \"value\" (the number at that stage, from the user's data)")
    if style == "cycle" and _words(D.get("center")) > (8 if d else 6):
        P.append(f"the cycle's centre '{D['center'][:40]}' is {_words(D['center'])} words - name the loop in 1-"
                 f"{8 if d else 6}")
    for k in ("result", "source"):
        s = D.get(k)
        if s and _words(s["text"]) > grow(20):
            P.append(f"the {k}'s text is {_words(s['text'])} words - keep it to {grow(20)}")
    return P + icon_problems(D, style)


def icon_problems(D, style):
    if not D["icons_on"]:
        return []
    if style not in ICON_STYLES:
        return [f"the {style} style has no room for icons - they show in {', '.join(ICON_STYLES)}"]
    bad = [s for s in _items(D) if s["icon"] and not PG.known(s["icon"])]
    if bad:
        return [f"'{bad[0]['title'][:30]}': there is no icon '{bad[0]['icon']}' - name a pictogram ("
                + ", ".join(PG.NAMES[:12]) + " ...: python tools/pictograms.py lists them) or leave it out "
                "(\"icons\": \"auto\" picks one by the step's words)"]
    return []


# ============================================================================================ drawing helpers
def _colour(i):
    return ND.accent(i)


TYPE = ((18, 14), (14, 14), (14, 12), (12, 12), (12, 10.5))     # title / text sizes, largest first (template scale)
TEXT_ONLY = ((14, 14), (12, 12), (10.5, 10.5))
BAR = 0.07                                                      # the coloured bar along a card's top (inches)
ML, MT = 0.12, 0.08                                             # card insets (inches)


def _step_parts(s, title=True):
    """parts_at(tp, xp) for a step: its title (bold), its text and its owner (muted)."""
    def parts(tp, xp):
        out = [_para(s["title"], tp, True, ND.INK, False)] if title and s.get("title") else []
        if s.get("text"):
            out.append(_para(s["text"], xp, False, ND.INK, bool(out)))
        if s.get("owner"):
            out.append(_para(s["owner"], xp, False, ND.MUTED, True))
        return out
    return parts


def _need(parts, w, ml=ML, mt=MT):
    """EMU the parts need in a box w wide (insets ml / mt inches); None when a word is wider than the box."""
    inner = w - _in(2 * ml)
    paras = TL._paras(parts)
    if any(TL._longest_word(t, pt, b) > inner for t, pt, b, _f in paras):
        return None
    return TL._height(paras, inner) + _in(2 * mt)


def _uniform(steps, w, avail, sizes=TYPE, title=True, ml=ML, mt=MT):
    """One type size for a whole row of cards: the largest (title, text) sizes at which every step fits w x avail, and
    the tallest card's need at those sizes (the row's cards share both)."""
    for tp, xp in sizes:
        needs = [_need(_step_parts(s, title)(tp, xp), w, ml, mt) for s in steps]
        if all(n_ is not None and n_ <= avail for n_ in needs):
            return (tp, xp), max(needs or [0])
    tp, xp = sizes[-1]
    return (tp, xp), max((_need(_step_parts(s, title)(tp, xp), w, ml, mt) or avail) for s in steps)


ICON_TOP = 0.5                                                  # an icon above a card's text (inches) and its room
ICON_ROOM = ICON_TOP + 0.24


def _side_icon(h):
    """The size of an icon beside a card's text (EMU) for a card h tall."""
    return min(_in(0.44), max(_in(0.26), h - _in(0.22)))


def _card(C, x, y, w, h, s, i, size, title=True, align="l", anchor="t", bar=True, edge=False, name="process card",
          icon_top=False):
    """A white rounded card with the step's title, text and owner at size (title_pt, text_pt); a bar in the step's colour
    along its top (bar) or its left side (edge). The step's icon, when it has one, sits above the text (icon_top) or
    beside it in the step's colour (edge cards)."""
    top = BAR if bar else 0.0
    left = 0.08 if edge else 0.0
    icon = s.get("icon") if (icon_top or edge) else None
    up = ICON_ROOM if icon and icon_top else 0.0
    beside = _side_icon(h) / IN + 0.14 if icon and not icon_top else 0.0
    sh = C.rect(x, y, w, h, ND.WHITE, r=0.08, name=name)
    p = _step_parts(s, title)(*size)
    C.write(sh, p, align=align, anchor=anchor, ml=ML + left + beside, mr=ML, mt=MT + top + up, mb=MT)
    C.check(TL._paras(p), int(w - _in(left + beside)), int(h - _in(top + up)), f"step '{s['title'][:30]}'", ml=ML, mt=MT)
    if bar:
        C.top_rounded(x, y, w, _in(BAR), _colour(i), 0.08, name=f"{name} colour")
    if edge:
        C.rect(x, y, _in(0.08), h, _colour(i), r=None, name=f"{name} colour")
    if icon and icon_top:
        PG.icon(C, icon, x + w / 2, y + _in(top + 0.14 + ICON_TOP / 2), _in(ICON_TOP), colour=_colour(i), bg=ND.WHITE)
    elif icon:
        d = _side_icon(h)
        PG.icon(C, icon, x + _in(left + ML) + d / 2, y + h / 2, d, colour=_colour(i), bg=ND.WHITE)
    return sh


def _badge(C, cx, cy, d, i, label, fill=None, name="process step number", icon=None):
    """A numbered circle in the step's colour, the number white and bold at 20 pt and up (white reads on all four
    template colours from 18 pt). With an icon: the pictogram in white, the number on a small plum tag at its top
    right (small white words read on plum)."""
    f = fill or _colour(i)
    if icon:
        sh = C.dot(cx, cy, d, f, name=name.replace("number", "icon"))
        PG.icon(C, icon, cx, cy, d * 0.56, colour=ND.WHITE, bg=f)
        t = max(_in(0.26), d * 0.36)
        tag = C.dot(cx + d * 0.3536, cy - d * 0.3536, t, ND.PLUM, line=ND.WHITE, line_w=1.25, name=name)
        C.write(tag, [_para(str(label), 12 if t >= _in(0.3) else 10.5, True, ND.WHITE, False)], align="c", anchor="m",
                ml=0.0, mt=0.0)
        return sh
    pt = 24 if d >= _in(0.7) else 20
    sh = C.dot(cx, cy, d, f, name=name)
    C.write(sh, [_para(str(label), pt, True, ND.WHITE, False)], align="c", anchor="m", ml=0.0, mt=0.0)
    return sh


def _small_badge(C, cx, cy, d, label, name="process step number"):
    """A small plum circle with a white bold number (small white words read on plum)."""
    sh = C.dot(cx, cy, d, ND.PLUM, name=name)
    C.write(sh, [_para(str(label), 12, True, ND.WHITE, False)], align="c", anchor="m", ml=0.0, mt=0.0)
    return sh


def _chevron(C, x, y, w, h, i, title, tip, first=False, pt=18, name="process chevron"):
    """A chevron (the first one flat-backed) in the step's colour, its title white and bold at 18 pt."""
    sh = ND.shape(C.sl, "PENTAGON" if first else "CHEVRON", int(x), int(y), int(w), int(h), fill=_colour(i), name=name)
    sh.adjustments[0] = tip / h
    C.add(sh)
    # the preset's own text area leaves the notch and the point out (a chevron: tip .. w - tip; the flat-backed first
    # one: 0 .. w - tip/2); the insets centre the title on the body
    ml, mr = (0.14, tip / 2 / IN + 0.06) if first else (0.06, 0.06)
    inner = (w - tip / 2 if first else w - 2 * tip) - _in(ml + mr)
    C.write(sh, [_para(title, pt, True, ND.WHITE, False)], align="c", anchor="m", ml=ml, mt=0.04, mr=mr)
    C.check([(title, pt, True, None)], int(inner), int(h), f"step title '{title[:30]}'", ml=0.0, mt=0.04)
    return sh


def _chevron_row(C, y, h, steps, tip, gap, name="Step"):
    """Nested chevrons across the frame, `gap` apart; returns their x positions and width. The card under chevron i
    spans x + tip/2 .. x + w - tip/2: equal cards, `gap` apart, centred under their chevrons."""
    bx, by, bw, bh = C.box
    n = len(steps)
    cw = (bw + (n - 1) * (tip - gap)) / n
    xs = [bx + i * (cw - tip + gap) for i in range(n)]
    for i, s in enumerate(steps):
        _chevron(C, xs[i], y, cw, h, i, s["title"], tip, first=(i == 0), name=f"{name} {i + 1}")
    return xs, cw


def _row_geometry(bw, n, tip, gap):
    cw = (bw + (n - 1) * (tip - gap)) / n
    return cw, cw - tip


def _top(C, total):
    """The top of a block `total` EMU tall: centred in the frame, a little above the middle."""
    bx, by, bw, bh = C.box
    return by + max(0, (bh - total) * 0.4)


def _polyline(C, pts, colour, width, name="process path"):
    """An open path through points (a native freeform, no fill): the road of the snake."""
    fb = C.sl.shapes.build_freeform(int(pts[0][0]), int(pts[0][1]), scale=1.0)
    fb.add_line_segments([(int(x), int(y)) for x, y in pts[1:]], close=False)
    sh = fb.convert_to_shape()
    sh.fill.background()
    ND._line(sh, colour, width)
    ND.no_effects(sh)
    sh.name = name
    return C.add(sh)


def _pointer(C, cx, cy, w, h, angle_deg, colour, name="process direction"):
    """A small chevron centred on cx, cy pointing along angle_deg (0 = right, 90 = down): the direction of travel."""
    sh = ND.shape(C.sl, "CHEVRON", int(cx - w / 2), int(cy - h / 2), int(w), int(h), fill=colour, name=name)
    sh.adjustments[0] = 0.5
    sh.rotation = angle_deg % 360
    return C.add(sh)


def _link_arrow(C, x, cy, w, h=None, name="process arrow"):
    """A short blush chevron between two blocks (the direction of flow)."""
    h = h or _in(0.5)
    sh = ND.shape(C.sl, "CHEVRON", int(x), int(cy - h / 2), int(w), int(h), fill=ND.ROSE_TINT, name=name)
    sh.adjustments[0] = min(0.6, (w * 0.55) / h)
    return C.add(sh)


# ============================================================================================ styles
def _draw_chevrons(C, D):
    bx, by, bw, bh = C.box
    st = D["steps"]
    tip, gap, ch, sp = _in(0.32), _in(0.12), _in(1.0), _in(0.22)
    cw, card_w = _row_geometry(bw, len(st), tip, gap)
    icons = D["icons_on"]
    up = _in(ICON_ROOM) if icons else 0                         # the icon above each card's text
    text = any(s["text"] or s["owner"] for s in st)
    size = TEXT_ONLY[0]
    if text:
        size, need = _uniform(st, card_w, bh - ch - sp - up, TEXT_ONLY, title=False)
        card_h = min(bh - ch - sp, max(need + up + _in(0.3), _in(1.8)))
    elif icons:
        card_h = up + _in(0.14)
    y0 = _top(C, ch + (sp + card_h if text or icons else 0))
    xs, cw = _chevron_row(C, y0, ch, st, tip, gap)
    if text or icons:
        for i, s in enumerate(st):
            _card(C, xs[i] + tip / 2, y0 + ch + sp, card_w, card_h, s, i, size, title=False, bar=False,
                  align="c" if icons else "l", icon_top=icons, name=f"Step {i + 1} card")


def _draw_arrow(C, D):
    bx, by, bw, bh = C.box
    st = D["steps"]
    n = len(st)
    ah, stem, d = _in(0.7), _in(0.32), _in(0.62)
    pitch = (bw - _in(0.5)) / n
    up_n = (n + 1) // 2
    card_w = min(_in(3.2), (bw - _in(0.16) * (up_n - 1)) / up_n, 2 * pitch - _in(0.16))
    room = (bh - ah) / 2 - stem
    size, need = _uniform(st, card_w, room - _in(BAR))
    card_h = min(room, max(need + _in(BAR) + _in(0.2), _in(1.1)))
    y0 = _top(C, 2 * (card_h + stem) + ah)
    ay = y0 + card_h + stem
    arrow = ND.shape(C.sl, "RIGHT_ARROW", int(bx), int(ay), int(bw), int(ah), fill=ND.ROSE_TINT, name="process arrow")
    arrow.adjustments[0], arrow.adjustments[1] = 0.6, 0.5
    C.add(arrow)
    cy = ay + ah / 2
    cxs = [bx + pitch * (i + 0.5) for i in range(n)]
    left = {}
    for side in (0, 1):                                         # above (even steps) and below (odd): no overlap
        ks = list(range(side, n, 2))
        mids = TL._spread([cxs[k] for k in ks], bx + card_w / 2, bx + bw - card_w / 2, card_w + _in(0.16), 0)
        left.update({k: m - card_w / 2 for k, m in zip(ks, mids)})
    for i, s in enumerate(st):
        cx = cxs[i]
        up = i % 2 == 0
        y = y0 if up else ay + ah + stem
        x = left[i]
        _card(C, x, y, card_w, card_h, s, i, size, name=f"Step {i + 1} card")
        if up:
            C.line(cx, y + card_h, cx, cy - d / 2, colour=ND.MUTED, width=1.0, name=f"Step {i + 1} stem")
        else:
            C.line(cx, cy + d / 2, cx, y, colour=ND.MUTED, width=1.0, name=f"Step {i + 1} stem")
        _badge(C, cx, cy, d, i, i + 1, name=f"Step {i + 1} number", icon=s["icon"])


def _draw_numbered(C, D):
    bx, by, bw, bh = C.box
    st = D["steps"]
    n = len(st)
    d = _in(0.82 if n <= 5 else 0.7)
    gap, sp = _in(0.18), _in(0.25)
    pitch = (bw + gap) / n
    w = pitch - gap
    size, need = _uniform(st, w, bh - d - sp - _in(BAR))
    tall = _in(1.5) if any(s["text"] or s["owner"] for s in st) else 0
    card_h = min(bh - d - sp, max(need + _in(BAR) + _in(0.3), tall))
    y0 = _top(C, d + sp + card_h)
    ly = y0 + d / 2
    C.line(bx + w / 2, ly, bx + bw - w / 2, ly, colour=ND.ROSE_TINT, width=4.0, name="process line")
    for i, s in enumerate(st):
        x = bx + i * pitch
        _badge(C, x + w / 2, ly, d, i, i + 1, name=f"Step {i + 1} number", icon=s["icon"])
        _card(C, x, y0 + d + sp, w, card_h, s, i, size, align="c", name=f"Step {i + 1} card")


def _draw_cycle(C, D):
    bx, by, bw, bh = C.box
    st = D["steps"]
    n = len(st)
    d = _in(0.8)
    t = _in(0.3)                                                # the ring's thickness
    rm = min(_in(1.95), bh / 2 - d / 2 - _in(0.02))             # the ring's centre line
    cx, cy = bx + rm + d / 2 + _in(0.05), by + bh / 2
    R = rm + t / 2
    ring = ND.shape(C.sl, "DONUT", int(cx - R), int(cy - R), int(2 * R), int(2 * R), fill=ND.ROSE_TINT,
                    name="cycle ring")
    ring.adjustments[0] = t / (2 * R)
    C.add(ring)
    if D.get("center"):
        hd = 2 * (rm - t / 2 - _in(0.12))
        hub = C.dot(cx, cy, hd, ND.WHITE, name="cycle purpose")
        p = [_para(D["center"], ND.T_SUB, True, ND.PLUM, False)]
        C.write(hub, p, align="c", anchor="m", ml=0.04, mt=0.04)
        side = hd - 2 * 0.1464 * hd                             # a circle's text area: its inscribed square
        C.check(TL._paras(p), int(side), int(side), "the cycle's centre", ml=0.04, mt=0.04)
    angles = [-90 + 360 * k / n for k in range(n)]
    for a in angles:                                            # the direction of travel, half way between two steps
        m = math.radians(a + 180 / n)
        _pointer(C, cx + rm * math.cos(m), cy + rm * math.sin(m), _in(0.2), _in(0.24), a + 180 / n + 90, ND.PLUM)
    for k, a in enumerate(angles):
        r = math.radians(a)
        _badge(C, cx + rm * math.cos(r), cy + rm * math.sin(r), d, k, k + 1, name=f"Step {k + 1} number",
               icon=st[k]["icon"])
    x0 = cx + R + d / 2 + _in(0.5)
    w = bx + bw - x0 - _in(0.62)
    gap = _in(0.14)
    room = (bh - gap * (n - 1)) / n
    size, need = _uniform(st, w, room, TYPE[1:])
    h = min(room, max(need + _in(0.2), _in(0.9)))
    y0 = by + (bh - (n * h + (n - 1) * gap)) / 2
    for k, s in enumerate(st):
        y = y0 + k * (h + gap)
        _badge(C, x0 + _in(0.25), y + h / 2, _in(0.5), k, k + 1, name=f"Step {k + 1} key")
        _card(C, x0 + _in(0.62), y, w, h, s, k, size, bar=False, anchor="m", name=f"Step {k + 1} card")


def _draw_snake(C, D):
    """Two rows joined by a turn on the right: the top row's labels above it, the bottom row's below it."""
    bx, by, bw, bh = C.box
    st = D["steps"]
    n = len(st)
    top_n = (n + 1) // 2
    d = _in(0.62)
    s_gap = _in(1.15)                                           # the two roads, centre to centre
    pitch = bw / top_n
    lw = min(pitch - _in(0.16), _in(2.8))
    lab_h = (bh - s_gap - d) / 2 - _in(0.1)
    size, need = _uniform(st, lw, lab_h, TYPE[1:], ml=0.04, mt=0.02)
    lab_h = min(lab_h, need + _in(0.04))
    y1 = _top(C, 2 * (lab_h + _in(0.1)) + s_gap + d) + lab_h + _in(0.1) + d / 2
    y2 = y1 + s_gap
    xs1 = [bx + pitch * (k + 0.5) for k in range(top_n)]
    xs2 = list(reversed(xs1))[:n - top_n]
    r = s_gap / 2
    xr = xs1[-1]
    arc = [(xr + r * math.sin(math.pi * k / 16), y1 + r - r * math.cos(math.pi * k / 16)) for k in range(17)]
    end = (xs2[-1] if xs2 else xr) - min(pitch / 2, _in(0.9))
    _polyline(C, [(bx, y1)] + arc + [(end + _in(0.15), y2)], ND.ROSE_TINT, 14.0)
    _pointer(C, end + _in(0.1), y2, _in(0.3), _in(0.42), 180, ND.ROSE_TINT, name="process end")
    for k, s in enumerate(st):
        top = k < top_n
        x, y = (xs1[k], y1) if top else (xs2[k - top_n], y2)
        _badge(C, x, y, d, k, k + 1, name=f"Step {k + 1} number", icon=s["icon"])
        p = _step_parts(s)(*size)
        ly = y - d / 2 - _in(0.1) - lab_h if top else y + d / 2 + _in(0.1)
        C.text(x - lw / 2, ly, lw, lab_h, p, align="c", anchor="b" if top else "t", name=f"Step {k + 1} label")
        C.check(TL._paras(p), int(lw), int(lab_h), f"step '{s['title'][:30]}'", ml=0.04, mt=0.02)


def _draw_vertical(C, D):
    bx, by, bw, bh = C.box
    st = D["steps"]
    n = len(st)
    gap = _in(0.14)
    h = (bh - gap * (n - 1)) / n
    d = min(_in(0.66), h * 0.82)
    sx = bx + d / 2 + _in(0.02)
    C.line(sx, by + h / 2, sx, by + bh - h / 2, colour=ND.ROSE_TINT, width=4.0, name="process spine")
    x = sx + d / 2 + _in(0.28)
    tw = _in(2.7)
    x2 = x + _in(0.2) + tw
    w2 = bx + bw - x2 - _in(0.15)
    tsz = next((p_ for p_ in (18, 14) if all((_need([_para(s["title"], p_, True)], tw - _in(0.1), 0.04, 0.02) or h * 2)
                                             <= h for s in st)), 14)
    body = lambda s, pt: ([_para(s["text"], pt, False, ND.INK, False)] if s["text"] else []) + \
        ([_para(s["owner"], pt, False, ND.MUTED, bool(s["text"]))] if s["owner"] else [])
    sizes = (14, 12, 10.5) if C.dense else (14, 12)
    bsz = next((p_ for p_ in sizes if all((_need(body(s, p_), w2, 0.04, 0.02) or h * 2) <= h for s in st)), sizes[-1])
    for i, s in enumerate(st):
        y = by + i * (h + gap)
        _badge(C, sx, y + h / 2, d, i, i + 1, name=f"Step {i + 1} number", icon=s["icon"])
        C.rect(x, y, bx + bw - x, h, ND.WHITE, r=0.08, name=f"Step {i + 1} card")
        C.rect(x, y, _in(0.08), h, _colour(i), r=None, name=f"Step {i + 1} colour")
        pt_ = [_para(s["title"], tsz, True, ND.INK, False)]
        C.text(x + _in(0.2), y, tw - _in(0.1), h, pt_, align="l", anchor="m", name=f"Step {i + 1} title")
        C.check(TL._paras(pt_), int(tw - _in(0.1)), int(h), f"step title '{s['title'][:30]}'", ml=0.04, mt=0.02)
        b = body(s, bsz)
        if b:
            C.text(x2, y, w2, h, b, align="l", anchor="m", name=f"Step {i + 1} text")
            C.check(TL._paras(b), int(w2), int(h), f"step '{s['title'][:30]}'", ml=0.04, mt=0.02)


def _draw_phases(C, D):
    bx, by, bw, bh = C.box
    st = D["steps"]
    tip, gap, ch, sp = _in(0.3), _in(0.12), _in(0.8), _in(0.14)
    cw, w = _row_geometry(bw, len(st), tip, gap)
    any_when = any(s["when"] for s in st)
    any_out = any(s["outcome"] for s in st)
    when_h = _in(0.36) if any_when else 0
    out_h = _in(0.66) if any_out else 0
    out_sp = _in(0.12) if any_out else 0
    bullets = lambda s, pt: [_para("• " + it, pt, False, ND.INK, k > 0) for k, it in enumerate(s["items"])]
    room = bh - ch - sp - when_h - out_h - out_sp
    need_at = lambda pt: max([(_need(bullets(s, pt), w - _in(0.13), ML, 0.12) or room * 2) +
                              _in(6 / 72) * max(0, len(s["items"]) - 1) for s in st] or [0])
    pt = next((p_ for p_ in (14, 12, 10.5)[:3 if C.dense else 2] if need_at(p_) <= room), 10.5 if C.dense else 12)
    card_h = min(room, max(need_at(pt) + _in(0.2), _in(1.2)))
    y0 = _top(C, ch + sp + when_h + card_h + out_sp + out_h)
    xs, cw = _chevron_row(C, y0, ch, st, tip, gap, name="Phase")
    for i, s in enumerate(st):
        x = xs[i] + tip / 2
        y = y0 + ch + sp
        if any_when:
            p = [_para(s["when"] or " ", 12, True, ND.PLUM, False)]
            C.text(x, y, w, _in(0.3), p, align="l", anchor="t", ml=0.12, name=f"Phase {i + 1} timing")
            C.check(TL._paras(p), int(w), _in(0.3), f"phase '{s['title'][:30]}' timing", ml=0.12, mt=0.02)
            y += when_h
        sh = C.rect(x, y, w, card_h, ND.WHITE, r=0.08, name=f"Phase {i + 1} activities")
        p = bullets(s, pt)
        C.write(sh, p, align="l", anchor="t", ml=0.12, mt=0.12)
        extra = TL._space(sh, before=6)
        TL._bullets(sh)
        C.check(TL._paras(p), int(w - _in(0.13)), int(card_h - extra), f"phase '{s['title'][:30]}' activities",
                ml=0.12, mt=0.12)
        if any_out:
            o = C.rect(x, y + card_h + out_sp, w, out_h, ND.PINK_TINT, r=0.08, name=f"Phase {i + 1} outcome")
            p = [_para(s["outcome"] or " ", 12, True, ND.PLUM, False)]
            C.write(o, p, align="l", anchor="m", ml=0.12, mt=0.04)
            C.check(TL._paras(p), int(w), int(out_h), f"phase '{s['title'][:30]}' outcome", ml=0.12, mt=0.04)


def _draw_pipeline(C, D):
    bx, by, bw, bh = C.box
    st = D["steps"]
    n = len(st)
    link = _in(0.86 if n <= 4 else 0.7)
    w = (bw - link * (n - 1)) / n
    tw = w - _in(0.12)
    text_need = max([_need([_para(s["text"], 12, False)], tw, 0.04, 0.02) or 0 for s in st if s["text"]] or [0])
    h = min(bh, max(_in(1.88) + text_need + _in(0.3), _in(2.6)))
    y0 = _top(C, h)
    for i, s in enumerate(st):
        x = bx + i * (w + link)
        C.rect(x, y0, w, h, ND.WHITE, r=0.08, name=f"Stage {i + 1}")
        C.top_rounded(x, y0, w, _in(BAR), _colour(i), 0.08, name=f"Stage {i + 1} colour")
        tp = [_para(s["title"], 14, True, ND.INK, False)]
        C.text(x + _in(0.06), y0 + _in(0.22), tw, _in(0.62), tp, align="c", anchor="t", name=f"Stage {i + 1} title")
        C.check(TL._paras(tp), int(tw), _in(0.62), f"stage '{s['title'][:30]}'", ml=0.04, mt=0.02)
        v = s["value"] or "-"
        vpt = next((p_ for p_ in (40, 36, 32, 28, 24) if TL._tw(v, p_, face=ND.DISPLAY) <= tw - _in(0.12)), 24)
        if TL._tw(v, vpt, face=ND.DISPLAY) > tw - _in(0.12):
            C.P.append(f"stage '{s['title'][:30]}': the number '{v}' is too wide for its stage - write it short "
                       "(120K, $1.2M)")
        val = C.text(x + _in(0.06), y0 + _in(0.86), tw, _in(0.86), [_para(v, vpt, False, ND.PLUM, False)],
                     align="c", anchor="m", name=f"Stage {i + 1} value")
        C.face(val, v)
        if s["text"]:
            bp = [_para(s["text"], 12, False, ND.INK, False)]
            C.text(x + _in(0.06), y0 + _in(1.82), tw, h - _in(1.9), bp, align="c", anchor="t",
                   name=f"Stage {i + 1} text")
            C.check(TL._paras(bp), int(tw), int(h - _in(1.9)), f"stage '{s['title'][:30]}'", ml=0.04, mt=0.02)
        if i < n - 1:
            _link_arrow(C, x + w + _in(0.16), y0 + h / 2 - _in(0.14), link - _in(0.32), _in(0.5),
                        name=f"Stage {i + 1} to {i + 2}")
            if s["rate"]:
                pw = link - _in(0.08)
                pill = C.rect(x + w + _in(0.04), y0 + h / 2 + _in(0.3), pw, _in(0.34), "ACCENT_2", r=0.17,
                              name=f"Stage {i + 1} rate")
                C.write(pill, [_para(s["rate"], 12, True, ND.WHITE, False)], align="c", anchor="m", ml=0.02, mt=0.0)
                C.check([(s["rate"], 12, True, None)], int(pw), _in(0.34), f"rate '{s['rate']}'", ml=0.02, mt=0.0)


def _stack(C, items, x, y, w, h, size, i0, numbered=False, name="item"):
    """Cards one under another from y, all h tall; returns them."""
    out = []
    gap = _in(0.12)
    for j, it in enumerate(items):
        yy = y + j * (h + gap)
        if numbered:
            sh = C.rect(x, yy, w, h, ND.WHITE, r=0.08, name=f"{name} {j + 1}")
            if it.get("icon"):                                  # the step's icon in plum instead of its number
                PG.icon(C, it["icon"], x + _in(0.3), yy + h / 2, _in(0.4), colour=ND.PLUM, bg=ND.WHITE)
            else:
                _small_badge(C, x + _in(0.3), yy + h / 2, _in(0.36), j + 1, name=f"{name} {j + 1} number")
            p = _step_parts(it)(*size)
            C.write(sh, p, align="l", anchor="m", ml=0.6, mr=ML, mt=MT)
            C.check(TL._paras(p), int(w - _in(0.48)), int(h), f"{name.lower()} '{it['title'][:30]}'", ml=ML, mt=MT)
            out.append(sh)
        else:
            out.append(_card(C, x, yy, w, h, it, i0, size, bar=False, edge=True, anchor="m", name=f"{name} {j + 1}"))
    return out


def _draw_io(C, D):
    bx, by, bw, bh = C.box
    link = _in(0.7)
    w = (bw - 2 * link) / 3
    titles = D.get("titles") if isinstance(D.get("titles"), list) and len(D["titles"]) == 3 else \
        ["Inputs", "Process", "Outputs"]
    lists = [D["inputs"], D["steps"], D["outputs"]]
    fills = ["ACCENT_2", ND.PLUM, "TEXT_2"]
    head_h, sp, gap = _in(0.6), _in(0.16), _in(0.12)
    nmax = max(1, max(len(l_) for l_ in lists))
    room = (bh - head_h - sp - gap * (nmax - 1)) / nmax
    size, need = _uniform([s for l_ in lists for s in l_] or [{"title": "-", "text": ""}],
                          w - _in(0.68 if D["icons_on"] else 0.5), room, TYPE[1:])
    h = min(room, max(need + _in(0.16), _in(0.62)))
    stack_h = nmax * h + (nmax - 1) * gap
    y0 = _top(C, head_h + sp + stack_h)
    for k in range(3):
        x = bx + k * (w + link)
        hd = C.rect(x, y0, w, head_h, fills[k], r=0.08, name=f"{titles[k]} header")
        C.write(hd, [_para(titles[k], 18, True, ND.WHITE, False)], align="c", anchor="m", ml=0.1, mt=0.02)
        C.check([(titles[k], 18, True, None)], int(w), int(head_h), f"the {titles[k].lower()} header", ml=0.1, mt=0.02)
        _stack(C, lists[k], x, y0 + head_h + sp, w, h, size, 0 if k == 0 else 1, numbered=(k == 1),
               name=("Input", "Step", "Output")[k])
        if k < 2:
            _link_arrow(C, x + w + _in(0.16), y0 + head_h + sp + stack_h / 2, link - _in(0.32), _in(0.5),
                        name=f"{titles[k]} to {titles[k + 1]}")


def _hub_cards(C, items, x, w, name):
    bx, by, bw, bh = C.box
    n = len(items)
    gap = _in(0.16)
    room = (bh - gap * (n - 1)) / n
    size, need = _uniform(items, w - _in(0.66 if any(s.get("icon") for s in items) else 0.08), room, TYPE[1:])
    h = min(room, max(need + _in(0.2), _in(0.8)))
    y0 = by + (bh - (n * h + (n - 1) * gap)) / 2
    return [_card(C, x, y0 + i * (h + gap), w, h, s, i, size, bar=False, edge=True, anchor="m", name=f"{name} {i + 1}")
            for i, s in enumerate(items)]


def _focus(C, x, y, w, h, s, name):
    """The block the flow comes together in (or starts from): magenta, white words (they read on magenta)."""
    sh = C.rect(x, y, w, h, "ACCENT_2", r=0.1, name=name)
    p = [_para(s["title"], ND.T_SUB, True, ND.WHITE, False)] + ([_para(s["text"], 12, False, ND.WHITE, True)]
                                                                 if s["text"] else [])
    if s.get("icon"):                                           # the icon right above the words, the pair centred
        need = TL._height(TL._paras(p), w - _in(0.4)) + (6 * TL.PT if len(p) > 1 else 0)
        room = _in(ICON_TOP + 0.16)
        top = max(_in(0.12), (h - need - room) / 2)
        C.write(sh, p, align="c", anchor="t", ml=0.2, mt=(top + room) / IN, mb=0.06)
        extra = TL._space(sh, before=6)
        C.check(TL._paras(p), int(w), int(h - top - room - extra), f"'{s['title'][:30]}'", ml=0.2, mt=0.03)
        PG.icon(C, s["icon"], x + w / 2, y + top + _in(ICON_TOP) / 2, _in(ICON_TOP), colour=ND.WHITE, bg="ACCENT_2")
        return sh
    C.write(sh, p, align="c", anchor="m", ml=0.2, mt=0.12)
    extra = TL._space(sh, before=6)
    C.check(TL._paras(p), int(w), int(h - extra), f"'{s['title'][:30]}'", ml=0.2, mt=0.12)
    return sh


def _draw_converge(C, D):
    bx, by, bw, bh = C.box
    w_in, w_out = bw * 0.36, bw * 0.3
    cards = _hub_cards(C, D["steps"], bx, w_in, "Input")
    fh = min(bh * 0.62, _in(2.6))
    res = _focus(C, bx + bw - w_out, by + (bh - fh) / 2, w_out, fh, D["result"] or {"title": "-", "text": ""}, "Result")
    jx = bx + w_in + (bw - w_in - w_out) * 0.62
    j = C.dot(jx, by + bh / 2, _in(0.2), ND.PLUM, name="process join")
    for c in cards:
        C.add(ND.connect(C.sl, c, j, "right", "left", colour=ND.MUTED, width=1.25, arrow=False, elbow=True,
                         name="input flow"))
    C.add(ND.connect(C.sl, j, res, "right", "left", colour=ND.PLUM, width=2.0, arrow=True, name="result flow"))


def _draw_diverge(C, D):
    bx, by, bw, bh = C.box
    w_src, w_out = bw * 0.3, bw * 0.36
    fh = min(bh * 0.62, _in(2.6))
    src = _focus(C, bx, by + (bh - fh) / 2, w_src, fh, D["source"] or {"title": "-", "text": ""}, "Source")
    cards = _hub_cards(C, D["steps"], bx + bw - w_out, w_out, "Result")
    jx = bx + w_src + (bw - w_src - w_out) * 0.38
    j = C.dot(jx, by + bh / 2, _in(0.2), ND.PLUM, name="process split")
    C.add(ND.connect(C.sl, src, j, "right", "left", colour=ND.PLUM, width=2.0, arrow=False, name="source flow"))
    for c in cards:
        C.add(ND.connect(C.sl, j, c, "right", "left", colour=ND.MUTED, width=1.25, arrow=True, elbow=True,
                         name="result flow"))


DRAW = {"chevrons": _draw_chevrons, "arrow": _draw_arrow, "numbered": _draw_numbered, "cycle": _draw_cycle,
        "snake": _draw_snake, "vertical": _draw_vertical, "phases": _draw_phases, "pipeline": _draw_pipeline,
        "io": _draw_io, "converge": _draw_converge, "diverge": _draw_diverge}


def draw(slide, box, spec):
    """Draw the process into box (x, y, w, h EMU) on a title-only slide; returns problems (empty = fine)."""
    spec = spec or {}
    D = _data(spec.get("process"))
    style = spec.get("style") or auto_style(spec.get("process"))
    if D is None or style not in DRAW:
        return [f"process style '{style}' does not exist - use one of: {', '.join(STYLES)}"] if D is not None else \
            ["\"process\" needs an object: {\"steps\": [...]}"]
    if style != "io" and not D["steps"]:
        return ["process not drawn: it has no steps"]
    C = TL._Canvas(slide, tuple(int(v) for v in box))
    C.dense = is_dense(spec)                                    # a dense slide: the smaller sizes of the type scale too
    frame = C.box
    if D["icons_on"]:                                           # room for the number tags on the top circles
        C.box = (C.box[0], C.box[1] + _in(0.06), C.box[2], C.box[3] - _in(0.06))
    try:
        DRAW[style](C, D)
    except Exception as e:                                      # never break the build: report and leave the slide
        import traceback
        tb = traceback.extract_tb(e.__traceback__)[-1]
        for sh in C.shapes:
            sh._element.getparent().remove(sh._element)
        return [f"process style '{style}' could not be drawn ({type(e).__name__}: {str(e)[:60]}, line {tb.lineno}) "
                "- check the steps and counts"]
    bx, by, bw, bh = frame
    tol = _in(0.02)
    for sh in C.shapes:
        if sh.left < bx - tol or sh.top < by - tol or sh.left + sh.width > bx + bw + tol or \
                sh.top + sh.height > by + bh + tol:
            C.P.append(f"'{sh.name}' runs outside the content frame - use fewer steps or shorter text")
            break
    C.group(f"Process ({style})")
    return list(dict.fromkeys(C.P))


# ============================================================================================ samples
def sample():
    """One storyboard slide per style, realistic content of the shape each style needs (each a different picture)."""
    return [
        {"style": "chevrons", "headline": "Five steps take a return from bag to shelf",
         "process": {"steps": [
             {"title": "Receive", "text": "Guest drops the item at any register or the app counter"},
             {"title": "Inspect", "text": "Associate checks the seal and condition in two minutes"},
             {"title": "Decide", "text": "Resell, return to vendor or donate by the guide"},
             {"title": "Restock", "text": "Resellable items are back on the shelf the same day"},
             {"title": "Refund", "text": "The guest gets the refund before leaving the store"}]},
         "notes": "Chevrons: steps in order, a card of detail under each."},
        {"style": "arrow", "headline": "Six stations move a new brand to launch",
         "process": {"steps": [
             {"title": "Brief", "text": "Merchant sets the target guest and price"},
             {"title": "Samples", "text": "Brand sends 3 rounds of samples"},
             {"title": "Testing", "text": "Quality and claims cleared in 4 weeks"},
             {"title": "Content", "text": "Photos and copy ready for ulta.com"},
             {"title": "Allocation", "text": "Stores and DCs get the first buy"},
             {"title": "Launch", "text": "Online first, stores the week after"}]},
         "notes": "Arrow: one process arrow, numbered stations, cards above and below in turn."},
        {"style": "numbered", "headline": "Four steps book a salon guest in one visit",
         "process": {"steps": [
             {"title": "Consult", "text": "Stylist asks about the look and hair history"},
             {"title": "Plan", "text": "Service, products and time agreed at the chair"},
             {"title": "Book", "text": "Next visit booked before the guest leaves"},
             {"title": "Follow up", "text": "A care tip and a rebooking reminder by text"}]},
         "notes": "Numbered: circles on one line with a card under each."},
        {"style": "cycle", "headline": "One weekly loop keeps shelves 98% full",
         "process": {"center": "Weekly replenishment loop", "steps": [
             {"title": "Forecast", "text": "Demand plan by store and item every Monday"},
             {"title": "Order", "text": "Store orders built from the plan and stock on hand"},
             {"title": "Deliver", "text": "DC ships within 48 hours"},
             {"title": "Review", "text": "Out-of-stocks and overstocks checked on Friday"}]},
         "notes": "Cycle: a loop that repeats, its purpose in the middle, the detail of each step beside it."},
        {"style": "snake", "headline": "Eight stops take a store from lease to opening",
         "process": {"steps": [
             {"title": "Lease", "text": "Site signed with the landlord"},
             {"title": "Design", "text": "Floor plan and fixtures approved"},
             {"title": "Permits", "text": "City permits in hand"},
             {"title": "Build", "text": "Construction in 10 weeks"},
             {"title": "Systems", "text": "Registers and network live"},
             {"title": "Hiring", "text": "Team of 25 hired and trained"},
             {"title": "Stock", "text": "Opening inventory set on the floor"},
             {"title": "Open", "text": "Grand opening weekend"}]},
         "notes": "Snake: a long process in two rows, the path turning back like a road."},
        {"style": "vertical", "headline": "Four checks clear a vendor before the first order",
         "process": {"steps": [
             {"title": "Compliance", "text": "Safety data sheets and ingredient lists reviewed against the policy",
              "owner": "Quality team"},
             {"title": "Finance", "text": "Payment terms, tax forms and bank details set up in the vendor master",
              "owner": "Accounts payable"},
             {"title": "Supply chain", "text": "Pack sizes, case labels and routing guide signed off for the DCs",
              "owner": "Inbound logistics"},
             {"title": "Systems", "text": "EDI connection tested with a sample purchase order and invoice",
              "owner": "Integration team"}]},
         "notes": "Vertical: steps down a spine, a wide card each, when every step needs a sentence."},
        {"style": "phases", "headline": "Three phases take loyalty pricing live by June",
         "process": {"steps": [
             {"title": "Discover", "when": "Weeks 1-4", "items": ["Interview 20 members", "Size the price gap",
                                                                     "Map current offers"],
              "outcome": "Approved pricing rules"},
             {"title": "Build", "when": "Weeks 5-12", "items": ["Configure the price engine", "Update the app screens",
                                                                   "Train store leads"],
              "outcome": "Tested in 10 stores"},
             {"title": "Launch", "when": "Weeks 13-16", "items": ["Roll out by region", "Track redemption daily"],
              "outcome": "Live in every store"}]},
         "notes": "Phases: chevron headers, timing, activities and the outcome of each phase."},
        {"style": "pipeline", "headline": "38% of trial guests become members",
         "process": {"steps": [
             {"title": "Trial", "value": "120K", "text": "Guests who used a sample", "rate": "54%"},
             {"title": "Second visit", "value": "65K", "text": "Came back within 30 days", "rate": "71%"},
             {"title": "Sign-up", "value": "46K", "text": "Joined the rewards program"}]},
         "notes": "Pipeline: the stages, their numbers and the share that moves on (sample figures)."},
        {"style": "io", "headline": "One planning step turns four inputs into three plans",
         "process": {"inputs": ["Sales history", "Promotions calendar", "Store openings", "Vendor lead times"],
                     "steps": ["Clean the data", "Build the forecast", "Review with merchants"],
                     "outputs": ["Store orders", "DC purchase orders", "Weekly in-stock report"]},
         "notes": "IO: inputs, the process and outputs in three columns."},
        {"style": "converge", "headline": "Four teams feed one holiday launch plan",
         "process": {"steps": [
             {"title": "Merchandising", "text": "Gift sets and price points"},
             {"title": "Marketing", "text": "Campaign dates and channels"},
             {"title": "Stores", "text": "Staffing and floor sets"},
             {"title": "Supply chain", "text": "Inventory by DC and week"}],
             "result": {"title": "Holiday launch plan", "text": "One calendar every team works from, signed off by Sep 15"}},
         "notes": "Converge: several inputs coming together in one result."},
        {"style": "diverge", "headline": "One guest profile powers four experiences",
         "process": {"source": {"title": "Guest profile", "text": "Purchases, preferences and services in one record"},
                     "steps": [
                         {"title": "App", "text": "Offers matched to the guest's routine"},
                         {"title": "Stores", "text": "Associates see past purchases at checkout"},
                         {"title": "Salon", "text": "Stylists see the service history"},
                         {"title": "E-mail", "text": "Reminders when products run low"}]},
         "notes": "Diverge: one source branching into several results."},
    ]


if __name__ == "__main__":
    print(__doc__)
