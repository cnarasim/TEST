"""Data -> native, editable PowerPoint charts and tables (used by build_deck.py), plus reading CSV / Excel.

Storyboard slide with a chart (drawn on the brand's title-only slide; right-click > Edit Data works in PowerPoint):
  {"chart": {"data": "/mnt/data/sales.xlsx", "sheet": "Q3", "type": "column", "x": "Month",
             "y": ["Actual", "Target"], "title": "Sales vs target", "format": "$#,##0"},
   "headline": "Sales are 4% behind target", "notes": "Source: sales.xlsx, Q3 tab"}
  type: column | bar | line | pie | doughnut | stacked | stacked_bar | stacked100 (each column as 100%) | area
  Series colours are the brand THEME colours (accent1, accent2 ...), so a new template recolours them.
Template table filled from a file (header row of the template kept; never adds rows):
  "slots": {"Table 3": {"from": "/mnt/data/cutover.csv", "columns": ["What", "Description", "When"]}}
"""
import copy, csv, re
from pathlib import Path
from pptx.text.text import _Run
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I


BASE = [Path.cwd()]          # build_deck.py adds the storyboard's folder: relative data paths resolve there


def resolve(path):
    p = Path(path)
    if p.is_absolute() or p.exists():
        return p
    for b in BASE[::-1] + [Path("/mnt/data")]:
        if (b / p).exists():
            return b / p
    raise SystemExit(f"data file not found: {path} (looked in {[str(b) for b in BASE]} and /mnt/data)")


def read_table(path, sheet=None):
    """[[header...], [row...], ...] from .csv / .xlsx / .xlsm (first sheet unless `sheet`)."""
    p = resolve(path)
    if p.suffix.lower() in (".xlsx", ".xlsm"):
        from openpyxl import load_workbook
        wb = load_workbook(str(p), data_only=True, read_only=True)
        ws = wb[sheet] if sheet else wb.worksheets[0]
        rows = [["" if v is None else v for v in r] for r in ws.iter_rows(values_only=True)]
    else:
        raw = p.read_text(encoding="utf-8-sig", errors="replace")
        dialect = csv.Sniffer().sniff(raw[:4096], delimiters=",;\t|") if raw.strip() else csv.excel
        rows = [r for r in csv.reader(raw.splitlines(), dialect)]
    rows = [r for r in rows if any(str(c).strip() for c in r)]
    width = max(len(r) for r in rows) if rows else 0
    return [list(r) + [""] * (width - len(r)) for r in rows]


def number(v):
    """(value, is_percent) from 12, '12', '1,234', '$1.2M', '45%', '(3)'."""
    if isinstance(v, (int, float)):
        return float(v), False
    s = str(v).strip()
    if not s:
        return None, False
    pct = s.endswith("%")
    mult = 1.0
    m = re.search(r"([kmb])\s*$", s, re.I)
    if m:
        mult = {"k": 1e3, "m": 1e6, "b": 1e9}[m.group(1).lower()]
    neg = s.startswith("(") and s.endswith(")")
    s = re.sub(r"[^\d.\-]", "", s)
    try:
        x = float(s) * mult
    except ValueError:
        return None, False
    x = -x if neg else x
    return (x / 100 if pct else x), pct


def col(header, name):
    low = [str(h).strip().lower() for h in header]
    if isinstance(name, int):
        return name
    if str(name).strip().lower() in low:
        return low.index(str(name).strip().lower())
    raise SystemExit(f"column {name!r} not in {header}")


def table_rows(spec):
    rows = read_table(spec["from"], spec.get("sheet"))
    header, body = rows[0], rows[1:]
    idx = [col(header, c) for c in spec["columns"]] if spec.get("columns") else list(range(len(header)))
    return [[str(r[i]) if i < len(r) else "" for i in idx] for r in body]


CHART_TYPES = {"column": "COLUMN_CLUSTERED", "bar": "BAR_CLUSTERED", "line": "LINE_MARKERS", "pie": "PIE",
               "doughnut": "DOUGHNUT", "stacked": "COLUMN_STACKED", "stacked_bar": "BAR_STACKED", "stacked100": "COLUMN_STACKED_100", "area": "AREA"}


AXIS_MAX = 0x7FFFFFFF                                    # Office reads an axis id as a signed 32-bit number


def office_axis_ids(cs):
    """Every axis id of one chart (its c:chartSpace) within 0..2147483647; returns how many values changed.
    python-pptx writes negative ids (-2068027336), which ISO/IEC 29500 (unsignedInt) rejects; Office reads the id as a
    signed 32-bit number, so one above 2147483647 (what v139 and earlier wrote for bar, column and pie charts:
    2226939960) makes PowerPoint offer to repair the file. An id out of range keeps its low 31 bits (the next free value
    if that one is taken), the same new id wherever the old one appears (axId and crossAx): each axis keeps its partner."""
    C = "{http://schemas.openxmlformats.org/drawingml/2006/chart}"
    els = list(cs.iter(C + "axId", C + "crossAx"))
    fits = lambda v: 0 <= v <= AXIS_MAX
    taken = {int(e.get("val")) for e in els if fits(int(e.get("val")))}
    new, n = {}, 0
    for e in els:
        v = int(e.get("val"))
        if fits(v):
            continue
        if v not in new:
            c = (v & AXIS_MAX) or 1
            while c in taken:
                c = c % AXIS_MAX + 1
            new[v] = c; taken.add(c)
        e.set("val", str(new[v])); n += 1
    return n


def fix_axis_ids(gf):
    """A new chart's axis ids within what Office reads (office_axis_ids)."""
    office_axis_ids(gf.chart._chartSpace)
    return gf


def fix_chart_files(path):
    """A deck already made: every chart's axis ids within what Office reads, in place; returns how many charts changed
    (0 leaves the file untouched)."""
    import zipfile
    from lxml import etree
    with zipfile.ZipFile(path) as z:
        items = {n: z.read(n) for n in z.namelist()}; infos = {n: z.getinfo(n) for n in z.namelist()}
    parser = etree.XMLParser(resolve_entities=False, no_network=True)
    changed = 0
    for n in [n for n in items if re.match(r"ppt/charts/[^/]*chart\d+\.xml$", n)]:
        x = etree.fromstring(items[n], parser)
        if office_axis_ids(x):
            items[n] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True); changed += 1
    if changed:
        import atomic
        with atomic.zip_out(path) as w:
            for n, d in items.items():
                w.writestr(infos[n], d)
    return changed


MONEY_NAME = re.compile(r"(?i)(sales|revenue|amount|value|gmv|spend|cost|margin|profit|income|price|\$)")
STRONG_EXTRA = ("C10060", "404040")            # 5th and 6th slice / series: the theme's accents 5-6 are pale tints


def value_format(data, ys):
    """$4.2M rather than 4,238,830.58: money gets its $, millions and thousands are scaled, and close values keep a
    second decimal so the labels still differ."""
    vals = [abs(v) for s_ in data._series for v in s_.values if v is not None]
    if not vals:
        return "#,##0.##"
    big, lo = max(vals), min(vals)
    cur = "$" if any(MONEY_NAME.search(str(y)) for y in ys) else ""
    dec = "00" if big and (big - lo) / big < 0.05 else "0"
    if big >= 1e6:
        return f'{cur}#,##0.{dec},,"M"'
    if big >= 1e4:
        return f'{cur}#,##0.{dec},"K"'
    return f"{cur}#,##0" if big >= 100 else f"{cur}#,##0.##"


def skip_labels(cat_ax, k):
    """c:tickLblSkip / c:tickMarkSkip = k on a category axis, in the schema's place (before noMultiLvlLbl and extLst)."""
    C = "{http://schemas.openxmlformats.org/drawingml/2006/chart}"
    for tag in ("tickLblSkip", "tickMarkSkip"):
        for old in cat_ax.findall(C + tag):
            cat_ax.remove(old)
    after = next((e for e in cat_ax if e.tag in (C + "noMultiLvlLbl", C + "extLst")), None)
    for tag in ("tickLblSkip", "tickMarkSkip"):
        el = cat_ax.makeelement(C + tag, {"val": str(k)})
        if after is not None:
            after.addprevious(el)
        else:
            cat_ax.append(el)


def date_axis(ax, dates):
    """A date axis whose labels stay level, whatever the points' spacing: every month, or every 2nd, 3rd, 6th or 12th
    month, so that at most 14 labels share the axis ('Jan' within one year, 'Jan 25' across years). 24 monthly labels
    of 'Jan 25' do not fit across a slide: PowerPoint turns them on their side and they overlap."""
    C = "{http://schemas.openxmlformats.org/drawingml/2006/chart}"
    span = (max(dates).year - min(dates).year) * 12 + max(dates).month - min(dates).month + 1
    months = next((m for m in (1, 2, 3, 6, 12) if span / m <= 14), 12)
    for tag in ("majorUnit", "majorTimeUnit", "baseTimeUnit"):
        for old in ax.findall(C + tag):
            ax.remove(old)
    nf = ax.find(C + "numFmt")
    if nf is None:
        nf = ax.makeelement(C + "numFmt", {}); ax.find(C + "axPos").addnext(nf)
    nf.set("formatCode", "mmm" if len({d.year for d in dates}) == 1 else "mmm yy"); nf.set("sourceLinked", "0")   # one year: Apr
    after = next((e for e in ax if e.tag in (C + "minorUnit", C + "minorTimeUnit", C + "extLst")), None)
    for tag, val in (("baseTimeUnit", "days"), ("majorUnit", str(months)), ("majorTimeUnit", "months")):
        el = ax.makeelement(C + tag, {"val": val})
        if after is not None:
            after.addprevious(el)
        else:
            ax.append(el)


def add_chart(slide, spec, box, brand):
    """Native chart in `box` (x, y, w, h EMU). Returns the chart's one-line description (used as alt text)."""
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION
    from pptx.enum.dml import MSO_THEME_COLOR
    from pptx.dml.color import RGBColor
    from pptx.util import Pt
    rows = read_table(spec["data"], spec.get("sheet"))
    header, body = rows[0], rows[1:]
    xi = col(header, spec.get("x", 0))
    ys = spec.get("y") or [h for k, h in enumerate(header) if k != xi][:1]
    yi = [col(header, y) for y in ys]
    kind = spec.get("type", "column")
    if kind in ("bar", "stacked_bar"):                        # horizontal bars are drawn from the bottom up: the rows go in
        body = body[::-1]                                     # reversed, so the first one (the leader) reads on top
    data = CategoryChartData()
    data.categories = [str(r[xi]) for r in body]
    import datetime as _dt
    dated = kind == "line" and len(body) > 16 and all(re.match(r"^\d{4}-\d\d-\d\d$", str(r[xi])[:10]) for r in body)
    if dated:                                                 # a long trend over dates: a date axis, one label a month (or quarter)
        dates = [_dt.date.fromisoformat(str(r[xi])[:10]) for r in body]
        data.categories = dates
    pct = False
    for name, k in zip(ys, yi):
        vals = []
        for r in body:
            v, p = number(r[k])
            vals.append(v); pct |= p
        data.add_series(str(header[k]), vals)
    fmt = "0%" if kind == "stacked100" else spec.get("format") or ("0%" if pct else value_format(data, ys))   # a 100% chart reads its axis as shares
    x, y, w, h = box
    gf = fix_axis_ids(slide.shapes.add_chart(getattr(XL_CHART_TYPE, CHART_TYPES.get(kind, "COLUMN_CLUSTERED")), x, y, w, h, data))
    ch = gf.chart
    body_font = brand.font("body")
    ch.font.name = body_font; ch.font.size = Pt(12); ch.font.color.rgb = RGBColor(0x40, 0x40, 0x40)
    if spec.get("title"):
        ch.has_title = True; ch.chart_title.text_frame.text = spec["title"]
        for r in ch.chart_title.text_frame.paragraphs[0].runs:
            r.font.size = Pt(14); r.font.bold = True; r.font.name = body_font
    else:
        ch.has_title = False
    accents = [MSO_THEME_COLOR.ACCENT_1, MSO_THEME_COLOR.ACCENT_2, MSO_THEME_COLOR.ACCENT_3,
               MSO_THEME_COLOR.ACCENT_4, MSO_THEME_COLOR.ACCENT_5, MSO_THEME_COLOR.ACCENT_6]
    order = [int(a[-1]) - 1 for a in (brand.get("chart_order") or [])] or list(range(6))
    plot = ch.plots[0]
    many = len(ys) > 1
    if kind in ("pie", "doughnut"):
        for k, pt in enumerate(plot.series[0].points):
            pt.format.fill.solid()
            if k % 6 < 4:
                pt.format.fill.fore_color.theme_color = accents[order[k % len(order)]]
            else:
                pt.format.fill.fore_color.rgb = RGBColor.from_string(STRONG_EXTRA[k % 6 - 4])
        ch.has_legend = True; ch.legend.position = XL_LEGEND_POSITION.RIGHT; ch.legend.include_in_layout = False
        plot.has_data_labels = True
        dl = plot.data_labels
        dl.number_format = "0%"; dl.number_format_is_linked = False
        dl.show_value = pct; dl.show_percentage = not pct; dl.show_category_name = False
        dl.font.size = Pt(12); dl.font.bold = True; dl.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        from pptx.enum.chart import XL_LABEL_POSITION
        if kind == "pie":
            dl.position = XL_LABEL_POSITION.OUTSIDE_END
    else:
        for k, s in enumerate(plot.series):
            c = accents[order[k % len(order)]] if k % 6 < 4 else None
            if kind == "line":
                if c is not None:
                    s.format.line.color.theme_color = c
                else:
                    s.format.line.color.rgb = RGBColor.from_string(STRONG_EXTRA[k % 6 - 4])
                s.format.line.width = Pt(2.25); s.smooth = False
            else:
                s.format.fill.solid()
                if c is not None:
                    s.format.fill.fore_color.theme_color = c
                else:
                    s.format.fill.fore_color.rgb = RGBColor.from_string(STRONG_EXTRA[k % 6 - 4])
        if hasattr(plot, "gap_width"):
            plot.gap_width = 60
        if len(body) <= 12 and kind not in ("line", "stacked100"):          # a share chart labels shares, not the amounts underneath
            plot.has_data_labels = True
            plot.data_labels.number_format = fmt; plot.data_labels.number_format_is_linked = False
            plot.data_labels.font.size = Pt(10)
        va = ch.value_axis
        if kind not in ("line", "area"):
            va.minimum_scale = 0                                  # bars start at zero: no exaggerated differences
        va.tick_labels.number_format = fmt.replace(".00", ".0"); va.tick_labels.number_format_is_linked = False   # axis: $0.5M
        va.has_major_gridlines = True
        va.major_gridlines.format.line.color.rgb = RGBColor(0xD9, 0xD9, 0xD9)
        va.format.line.fill.background()
        ch.category_axis.format.line.color.rgb = RGBColor(0xD9, 0xD9, 0xD9)
        if dated:
            date_axis(ch.category_axis._element, dates)
        elif len(body) > 16:                                  # a long series of names: every point drawn, every k-th label shown
            skip_labels(ch.category_axis._element, -(-len(body) // 12))
        ch.has_legend = many
        if many:
            ch.legend.position = XL_LEGEND_POSITION.BOTTOM; ch.legend.include_in_layout = False
    desc = f"{kind} chart: {spec.get('title') or ', '.join(map(str, ys))} by {header[xi]}"
    gf._element.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}cNvPr").set("descr", desc)
    return desc


RAG = {"green": "00B050", "on track": "00B050", "done": "00B050", "complete": "00B050", "completed": "00B050",
       "amber": "FFC000", "at risk": "FFC000", "yellow": "FFC000", "watch": "FFC000",
       "red": "FF0000", "off track": "FF0000", "blocked": "FF0000", "late": "FF0000", "overdue": "FF0000"}


ULTA_ROW_THEME = ("ACCENT_2", "TEXT_2", "ACCENT_4", "ACCENT_1")   # the action table's (template slide 12) row colours


def add_table(slide, rows, box, brand, header=True, rag_cols=()):
    """Native PowerPoint table in brand style, column widths by content, font size stepped down for big tables.
    Ulta: the template's own table look (action table / grid, slides 12 and 14) - header row unfilled with bold dark
    text, the first column in the theme's row colours with white bold text, body cells white / blush FDE1D2, all
    centred; colours are theme references, so they are the template's. Other brands: header in the brand's dark
    accent, light banded rows. RAG words get a coloured dot."""
    from pptx.util import Pt, Emu
    from pptx.dml.color import RGBColor
    x, y, w, h = box
    nr, nc = len(rows), max(len(r) for r in rows)
    rows = [list(r) + [""] * (nc - len(r)) for r in rows]
    size = 16 if nr <= 6 else 14 if nr <= 9 else 12 if nr <= 13 else 10
    row_h = min(int(h / max(nr, 1)), Emu(int(0.8 * 914400)))      # rows grow to use the slide (up to 0.8 in each)
    gf = slide.shapes.add_table(nr, nc, x, y, w, row_h * nr)
    tbl = gf.table
    lens = [max(min(len(str(r[c])), 60) for r in rows) + 4 for c in range(nc)]
    # every column at least as wide as its longest word at the size the type standard sets (header 18 pt bold, body
    # 12 pt) - a narrow "Cost" column broke "Medium" into "Medi / um"; the rest is shared by how much text a column has
    import brand as _BR
    M = _BR.metrics_for(brand)
    pad = 2 * 68580 + 45720
    ulta = brand.name == "ulta"
    def widest(c):
        best = 0
        for r in range(nr):
            hdr = header and r == 0
            lab = ulta and c == 0 and nc >= 2 and not hdr      # row labels are set like the header (18 pt bold)
            f = brand.font("body_bold") if hdr or lab else brand.font("body")
            for word in str(rows[r][c] or "").split():
                best = max(best, (_BR.width_of(word, f, M) or len(word) * 0.6) * (18 if hdr or lab else 12) * 12700)
        return best + pad
    minw = [widest(c) for c in range(nc)]
    if nc > 2:
        minw[0] *= 1.08                                  # the row label column breathes a little
    spare = w - sum(minw)
    if spare < 0:
        gf_problems = [f"table: the longest words need {sum(minw) / 914400:.1f} in but the slide has {w / 914400:.1f} in - "
                       "fewer columns or shorter words (a word would break mid-word)"]
        widths = [w * m / sum(minw) for m in minw]
    else:
        gf_problems = []
        widths = [minw[c] + spare * lens[c] / sum(lens) for c in range(nc)]
    for c in range(nc):
        tbl.columns[c].width = Emu(int(widths[c]))
    dark = RGBColor.from_string(brand.ui("dark_accent")); light = RGBColor.from_string(brand.ui("light_tint"))
    font = brand.font("body")
    from pptx.enum.dml import MSO_THEME_COLOR
    from pptx.enum.text import PP_ALIGN
    tbl.first_row = header; tbl.horz_banding = False
    for r in range(nr):
        tbl.rows[r].height = row_h
        for c in range(nc):
            cell = tbl.cell(r, c)
            txt = str(rows[r][c] if rows[r][c] is not None else "")
            cell.text = txt
            cell.margin_left = cell.margin_right = Emu(91440); cell.margin_top = cell.margin_bottom = Emu(22860)
            from pptx.enum.text import MSO_ANCHOR
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            hdr = header and r == 0
            lab = ulta and c == 0 and nc >= 2 and not hdr
            body_r = r - (1 if header else 0)
            if ulta and hdr:
                cell.fill.background()                                   # on the slide's blush, as in the template
            elif lab:
                cell.fill.solid(); cell.fill.fore_color.theme_color = getattr(MSO_THEME_COLOR, ULTA_ROW_THEME[body_r % 4])
            elif ulta:
                cell.fill.solid(); cell.fill.fore_color.rgb = RGBColor(0xFF, 0xFF, 0xFF) if body_r % 2 == 0 else RGBColor(0xFD, 0xE1, 0xD2)
            else:
                cell.fill.solid()
                cell.fill.fore_color.rgb = dark if hdr else light if r % 2 == 0 else RGBColor(0xFF, 0xFF, 0xFF)
            for p in cell.text_frame.paragraphs:
                if ulta:
                    p.alignment = PP_ALIGN.CENTER
                for run in p.runs:
                    run.font.name = brand.font("body_bold") if ulta and (hdr or lab) else font; run.font.size = Pt(size)
                    run.font.bold = hdr or lab
                    if ulta:
                        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF) if lab else RGBColor(0, 0, 0)
                    else:
                        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF) if hdr else \
                            dark if c == 0 and nc > 2 else RGBColor(0x40, 0x40, 0x40)   # the row label in the dark accent
                    if r and (c in rag_cols or txt.strip().lower() in RAG) and txt.strip().lower() in RAG:
                        # the template's status colours mark (a dot); the word stays in the text colour - never red font
                        ink = run.font.color.rgb
                        word = copy.deepcopy(run._r)
                        run._r.addnext(word)
                        run.text = "● "
                        run.font.color.rgb = RGBColor.from_string(RAG[txt.strip().lower()])
                        w = _Run(word, p)
                        w.text = txt
                        w.font.color.rgb = ink
                        w.font.bold = True
    head = [str(v) for v in rows[0]][:6] if header else []
    gf._element.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}cNvPr").set(
        "descr", "Table: " + (", ".join(h for h in head if h) or f"{nr} rows"))
    gf.problems = gf_problems
    return gf


def _item(it):
    """A bullet as (level, text): "text", [level, "text"] or {"text": .., "level": ..}."""
    if isinstance(it, dict):
        return int(it.get("level", 0)), str(it.get("text", ""))
    if isinstance(it, (list, tuple)) and len(it) == 2 and isinstance(it[0], int):
        return it[0], str(it[1])
    return 0, str(it)


def bullet_size(items, w, h, font, M, top=20, floor=12):
    """Largest point size (top..floor, 1 pt steps) at which the bullets fit w x h EMU, from the brand's font metrics;
    returns (size, fits)."""
    import math
    from brand import width_of
    for pt in range(top, floor - 1, -1):
        size = pt * 12700
        need = 0
        for lvl, txt in map(_item, items):
            inner = w - 182880 - lvl * 342900 - 228600                      # margins + bullet indent + level indent
            ems = width_of(txt, font, M) or len(txt) * 0.55
            lines = max(1, math.ceil(ems * size * (0.9 if lvl else 1) / max(inner, 1)))
            need += lines * size * 1.2 + size * 0.45
        if need <= h:
            return pt, True
    return floor, False


def add_bullets(slide, items, box, brand, M, numbered=False, start=1):
    """Bulleted body text in the brand's body font, sized to fit the box (largest of 20-12 pt). Returns (pt, fits)."""
    from pptx.util import Pt, Emu
    from pptx.dml.color import RGBColor
    from pptx.oxml.ns import qn
    from lxml import etree
    etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
    x, y, w, h = box
    font = brand.font("body")
    pt, fits = bullet_size(items, w, h, font, M)
    tb = slide.shapes.add_textbox(x, y, w, h)
    tb.name = "Body text"
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Emu(91440)
    for k, (lvl, txt) in enumerate(map(_item, items)):
        p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
        pPr = p._p.get_or_add_pPr()
        pPr.set("marL", str(228600 + lvl * 342900)); pPr.set("indent", "-228600"); pPr.set("lvl", str(min(lvl, 4)))
        for tag in ("buFont", "buChar"):
            for old in pPr.findall(qn("a:" + tag)):
                pPr.remove(old)
        for old in pPr.findall(qn("a:buAutoNum")):
            pPr.remove(old)
        if numbered and lvl == 0:                      # a native numbered list: PowerPoint renumbers it when edited
            pPr.set("marL", "342900"); pPr.set("indent", "-342900")
            bf = etree.SubElement(pPr, qn("a:buFont")); bf.set("typeface", "+mj-lt")
            an = etree.SubElement(pPr, qn("a:buAutoNum")); an.set("type", "arabicPeriod")
            if start and int(start) > 1:
                an.set("startAt", str(int(start)))
        else:
            bf = etree.SubElement(pPr, qn("a:buFont")); bf.set("typeface", "Arial")
            bc = etree.SubElement(pPr, qn("a:buChar")); bc.set("char", "•" if lvl == 0 else "–")
        p.space_after = Pt(pt * 0.45)
        r = p.add_run(); r.text = txt
        r.font.name = font; r.font.size = Pt(pt if lvl == 0 else max(pt - 2, 11))
        r.font.color.rgb = RGBColor(0x40, 0x40, 0x40)
    return pt, fits


def add_picture(slide, path, box, alt=""):
    """A picture scaled to fit the box (aspect kept), centred."""
    from PIL import Image
    x, y, w, h = box
    with Image.open(str(resolve(path))) as im:
        iw, ih = im.size
    s = min(w / iw, h / ih)
    pw, ph = int(iw * s), int(ih * s)
    pic = slide.shapes.add_picture(str(resolve(path)), x + (w - pw) // 2, y + (h - ph) // 2, pw, ph)
    pic._element.find(".//{http://schemas.openxmlformats.org/presentationml/2006/main}cNvPr").set(
        "descr", alt or "Picture")
    return pic
