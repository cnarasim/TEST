"""Run the hash-pinned fit checker (modules/ultapowerpointvalidator/scripts/ulta_pptx_fit.py) unchanged, with the
active brand's font metrics added, so a new template's fonts are measured instead of skipped.

    python tools/fit_runner.py <reference.pptx> <deck.pptx> --mapping 1,2 --report fit.json   (same CLI as the checker)
"""
import hashlib, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import brand as B   # noqa: E402

FIT = TOOLS.parent / "modules" / "ultapowerpointvalidator" / "scripts" / "ulta_pptx_fit.py"


FIT_SHA = "bcc2f9de8e06f722a279100e873d66522be763269340d1eea96f4e2866d17d4e"


def load():
    if hashlib.sha256(FIT.read_bytes()).hexdigest() != FIT_SHA:
        raise SystemExit("fit validator hash mismatch - the bundled checker was changed")
    from lxml import etree
    etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # the checker parses with the
    sys.path.insert(0, str(FIT.parent))                                                    # default parser: no DTD entities
    import ulta_pptx_fit as mod   # the bundled checker, verified above
    B.patch_metrics(mod)
    return mod


if __name__ == "__main__":
    mod = load()
    sys.argv = [str(FIT)] + sys.argv[1:]
    mod.main()
