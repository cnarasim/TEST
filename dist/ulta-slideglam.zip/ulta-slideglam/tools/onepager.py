"""One command for kit outputs: draw -> brand colours/fonts -> native editing -> accessibility -> label -> scan -> stamp.

    python tools/onepager.py content.md --template status [--format onepager|slide|square] [--theme glow] [--frame] --out /mnt/data/out/<Name>
        one page: the portrait one-pager, or one 16:9 slide (--frame, on request: with the template's cover and closing slides)
    python tools/onepager.py --diagram flows.txt --style zones --title "Order platform" --out /mnt/data/out/<Name>
    [--classification internal] [--owner "Name"]
Prints one status line plus only the problems. Outputs: .pptx, .svg, .html (one-pager) or .pptx, .drawio, .svg (diagram).
"""
import argparse, json, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
SKILL = TOOLS.parent
sys.path.insert(0, str(TOOLS))
KIT = TOOLS.parent / "modules" / "ultabranddeliverables" / "scripts" / "ulta.py"
PICS = r"^pictures: (\d+) placed, (\d+) screenshots, (\d+) without a caption, (\d+) missing, (\d+) samples"
READ = r"^readable text: (\d+) texts, (\d+) under the bar"


def run(cmd):
    r = subprocess.run(cmd, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def make(src, out, template=None, fmt="onepager", diagram=False, style="auto", title=None, classification=None,
         owner=None, action=None, theme="ulta", frame=False):
    out = Path(out); out.parent.mkdir(parents=True, exist_ok=True)
    if diagram:
        import re
        txt = Path(src).read_text(encoding="utf-8")
        if "[" in txt:                             # "[type=...; owner=...]" belongs in the register, not on the slide
            src = out.parent / (out.name + "-flows.txt")
            src.write_text("\n".join(re.sub(r"\s*\[[^\]]*\]\s*$", "", l) for l in txt.splitlines()), encoding="utf-8")
        cmd = [sys.executable, "-I", str(KIT), "diagram", str(src), "--style", style, "--out", str(out)]
        if title:
            cmd += ["--title", title]
        exts = (".pptx", ".drawio", ".svg")
    else:
        cmd = [sys.executable, "-I", str(KIT), "infographic", str(src), "--template", template or "auto", "--format", fmt,
               "--theme", theme or "ulta", "--out", str(out)] + (["--frame"] if frame else [])   # a one-pager is one slide
        exts = (".pptx", ".svg", ".html")
    code, log = run(cmd)
    notes = [l.strip() for l in log.splitlines() if "drawn as" in l or l.startswith("warning")]
    from ulta_text import cut_problems
    notes += cut_problems(log)
    if not out.with_suffix(".pptx").exists():
        return "FAILED", [f"the kit drew nothing: {log.strip()[-240:]}"]
    files = [str(out.with_suffix(e)) for e in exts if out.with_suffix(e).exists()]
    if not diagram and template and template not in ("auto", "free"):
        notes += sample_left(src, template)
    import re
    m = re.search(PICS, log, re.M)                       # the pictures the kit placed (a story told with pictures)
    rows = [picture_row(*map(int, m.groups()))] if m else []
    m = re.search(READ, log, re.M)                       # every text against what it sits on, as the kit drew it
    rows += [text_row(*map(int, m.groups()))] if m else []
    return finish(out, files, diagram, action or ("diagram" if diagram else f"one-pager ({template})"), classification,
                  owner, notes, rows)


def picture_row(*counts):
    sys.path.insert(0, str(KIT.parent / "kit" / "infographic"))
    import pictures
    return pictures.check_row(*counts)


def text_row(texts, low):
    """The "Readable text" row of the check record: each text 4.5:1 on what it sits on (3:1 from 18 pt), in the files' colours."""
    name = "Readable text (4.5:1 on what each text sits on, 3:1 from 18 pt)"
    if low:
        return (name, "FAIL", f"{low} of {texts} texts under the bar (the warnings name them) - change the colour or the box")
    return (name, "PASS", f"{texts} texts")


def sample_left(src, template):
    """FAIL lines when the content still carries the template's own sample facts (it was built without asking)."""
    import re
    code, sample = run([sys.executable, "-I", str(KIT), "content-template", template])
    if code:
        return []
    norm = lambda l: re.sub(r"\s+", " ", l.strip().strip("|-*").strip()).lower()
    keep = lambda l: l.strip() and not l.lstrip().startswith(("#", "|---", "| ---")) and len(norm(l)) > 3
    ref = {norm(l) for l in sample.splitlines() if keep(l)}
    mine = [l for l in Path(src).read_text(encoding="utf-8", errors="replace").splitlines() if keep(l)]
    head = {norm(l) for l in sample.splitlines() if l.startswith("|") and not l.startswith("|---")}
    same = [l for l in mine if norm(l) in ref and norm(l) not in head]     # table header rows are meant to stay
    if mine and len(same) >= max(2, len(mine) * 0.25):
        return [f"FAIL {len(same)} of {len(mine)} lines are the template's sample content (e.g. '{same[0].strip()[:60]}') - "
                "ask the user for their facts (infographic.py ask " + template + ") and rebuild"]
    return []


def pictures(out, files):
    """PNG and PDF next to the PowerPoint: the kit draws them (resvg); when that renderer is missing in the sandbox,
    LibreOffice makes them from the .pptx instead. Returns (files with the pictures added, note or None)."""
    import shutil
    out = Path(out); png, pdf = out.with_suffix(".png"), out.with_suffix(".pdf")
    how = "kit"
    if not (png.exists() and pdf.exists()):
        soffice = shutil.which("soffice") or shutil.which("libreoffice")
        pptx = out.with_suffix(".pptx")
        if soffice and pptx.exists():
            how = "LibreOffice"
            if not pdf.exists():
                import lo; lo.convert(pptx, out.parent, "pdf", timeout=180)
            if not png.exists() and pdf.exists() and shutil.which("pdftoppm"):
                subprocess.run(["pdftoppm", "-png", "-r", "150", "-singlefile", "-f", "1", "-l", "1", str(pdf), str(out)],
                               capture_output=True, timeout=120)
    files = list(dict.fromkeys([files[0]] + [str(p) for p in (png, pdf) if p.exists()] + list(files[1:])))
    missing = [p.suffix[1:].upper() for p in (png, pdf) if not p.exists()]
    note = (f"REVIEW no {' or '.join(missing)}: this sandbox has no picture renderer (resvg or LibreOffice) - "
            "the .html has an Export PDF button; the .svg opens in any browser") if missing else (
            "note: PNG/PDF made by LibreOffice from the .pptx (substitute fonts)" if how == "LibreOffice" else None)
    return files, note


OFFICE_ACCENT1 = {"4F81BD", "4472C4", "156082"}   # the blue accent 1 of Office's default themes (python-pptx's blank one: 4F81BD)


def office_theme(x):
    """True for a theme with Office's default colours (python-pptx's blank one, a notes master's): never a designed theme."""
    import re
    name = re.search(r'<a:clrScheme name="([^"]*)"', x)
    acc = re.search(r'<a:accent1>\s*<a:srgbClr val="([0-9A-Fa-f]{6})"', x)
    return bool(name and name.group(1).strip().lower() == "office") or bool(acc and acc.group(1).upper() in OFFICE_ACCENT1)


def schemes(path):
    """{scheme name: {slot: colour}} of the designed colour themes in a .pptx (Office defaults left out)."""
    import re, zipfile
    out = {}
    with zipfile.ZipFile(path) as z:
        for n in z.namelist():
            if re.fullmatch(r"ppt/theme/theme\d+\.xml", n):
                x = z.read(n).decode("utf-8")
                m = re.search(r'<a:clrScheme name="([^"]*)">(.*?)</a:clrScheme>', x, re.S)
                if m and not office_theme(x):
                    out[m.group(1)] = {k: v.upper() for k, v in re.findall(
                        r'<a:(dk1|lt1|dk2|lt2|accent\d|hlink|folHlink)>\s*<a:(?:srgbClr val|sysClr val="\w+" lastClr)="([0-9A-Fa-f]{6})"', m.group(2))}
    return out


def theme_changes(pptx):
    """[(theme, slot, colour, the template's)] wherever the file's copy of a colour theme from the brand's template differs from the
    template's own (v136: the slide format sits on the template, whose content theme gives its slides their light background)."""
    import brand as _B
    try:
        ref = schemes(_B.current().base_template)
    except Exception:                                    # no template to compare with: nothing to report
        return []
    return [(name, k, v, ref[name][k]) for name, cols in schemes(pptx).items() if name in ref
            for k, v in cols.items() if k in ref[name] and ref[name][k] != v]


def brand_theme(pptx):
    """Write the brand's theme colours and fonts into the file's Office default themes. The one-pager is built on
    python-pptx's blank theme (Office blue accent 1, Calibri), so a shape or chart the user adds in PowerPoint came out
    blue. A theme from the Ulta template is its design and stays as it is (v136: the slide format sits on the template,
    and writing the brand colours over its content theme turned the cream background (accent 5) pink and its magenta
    plum)."""
    import re, shutil, zipfile
    b = json.load(open(SKILL / "brands" / "ulta" / "brand.json", encoding="utf-8"))
    th, fo = b.get("theme") or {}, b.get("fonts") or {}
    import atomic
    tmp = atomic.scratch() / "t.pptx"
    with zipfile.ZipFile(pptx) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
        for it in zi.infolist():
            data = zi.read(it.filename)
            if re.fullmatch(r"ppt/theme/theme\d+\.xml", it.filename) and office_theme(data.decode("utf-8")):
                x = data.decode("utf-8")
                for k, v in th.items():
                    x = re.sub(rf"<a:{k}>.*?</a:{k}>", f'<a:{k}><a:srgbClr val="{v}"/></a:{k}>', x, count=1, flags=re.S)
                for k, f in (("majorFont", fo.get("heading")), ("minorFont", fo.get("body"))):
                    if f:
                        x = re.sub(rf'(<a:{k}>\s*<a:latin typeface=")[^"]*', rf"\g<1>{f}", x, count=1)
                data = x.encode("utf-8")
            zo.writestr(it, data)
    shutil.move(str(tmp), str(pptx))


def page_palette(path):
    """An infographic page lays itself out again after every edit: it gets the colour rules the files were checked with
    (tools/ulta_conform.page_palette), so an edited page keeps the delivered colours. A page that has them is left as it is."""
    import re, ulta_conform
    t = Path(path).read_text(encoding="utf-8")
    m = re.search(r'(<script id="assets" type="application/json">)(.*?)(</script>)', t, re.S)
    if not m or "UltaInfo" not in t:
        return
    a = json.loads(m.group(2))
    if a.get("palette") or "metrics" not in a:
        return
    a["palette"] = ulta_conform.page_palette()
    js = json.dumps(a, ensure_ascii=False).replace("</", "<\\/").replace("\u2014", "\\u2014")
    Path(path).write_text(t[:m.start(2)] + js + t[m.end(2):], encoding="utf-8")


def finish(out, files, diagram, action, classification=None, owner=None, notes=(), rows=()):
    """Plain punctuation, brand colours, native editing, accessibility, label, sensitive-data scan, stamp; returns
    (status line, problems). `rows`: more checks the build ran (the pictures' check), recorded with the rest."""
    out = Path(out); notes = list(notes); rows = [r for r in rows if r]
    import htmlpdf
    for f in files:
        if str(f).lower().endswith(".html"): htmlpdf.frame(f)   # in the chat's preview frame, say so if saving is blocked
    import plain                                         # the kit drew from clean text; this catches anything else
    plain.clean_all(list(files) + [str(x) for x in out.parent.glob(out.name + "-*.svg")]
                    + [str(out.with_suffix(".drawio")), str(out.parent / (out.name + "-content.md"))])
    for f in files:                                      # the page recolours its own edits as the files are recoloured
        if str(f).lower().endswith(".html"): page_palette(f)
    _, conf = run([sys.executable, str(TOOLS / "ulta_conform.py"), *files] + ([] if diagram else ["--keep-sizes"]))
    run([sys.executable, str(TOOLS / "nativize.py"), files[0]])
    import a11y, compliance, stamp
    pptx = out.with_suffix(".pptx")
    brand_theme(pptx)
    a11y.fix(pptx, flat_all=True)                        # the kit draws flat: no theme shadow on any shape
    if classification:
        compliance.classify(pptx, classification)
    sens = compliance.scan(files)
    af, _ = a11y.check(pptx)
    conform = [l.strip() for l in conf.splitlines() if "FAIL" in l or "brand check:" in l]
    import brand_colours                                 # zero deviation from the template palette, every format
    extra = sorted(str(x) for x in out.parent.glob(out.name + "-*.svg") if x.name[len(out.name) + 1:-4].isdigit())
    if extra:                                            # a slide one-pager's later pages (Name-2.svg ...)
        run([sys.executable, str(TOOLS / "ulta_conform.py"), *extra, "--keep-sizes"])
    colours = [f"FAIL colour in {Path(f).name}: {x}" for f in list(files) + extra for x in brand_colours.summary(f, 3)]
    kept = [f"FAIL the template's {t} colour theme changed: {k} #{v}, the template's #{r} (its slides' background and colours change with it)"
            for t, k, v, r in theme_changes(pptx)]
    blocked = [f"FAIL {x['where']}: {x['kind']} '{x['match']}' - remove it" for x in sens if x["severity"] == "BLOCK"]
    to_check = [f"REVIEW {x['where']}: {x['kind']} '{x['match']}'" for x in sens if x["severity"] == "REVIEW"]
    import ooxml_check                                   # PowerPoint is stricter than any preview
    opens = [f"FAIL would not open clean in PowerPoint - {x}" for x in ooxml_check.summary(pptx)]
    fit = [n for n in notes if n.startswith("FAIL")]
    problems = conform + colours + kept + blocked + to_check + ["FAIL " + x for x in af] + opens \
        + [f"{r[1]} {r[2]}" for r in rows if r[1] in ("FAIL", "REVIEW")]
    res = "NEEDS CORRECTION" if any(p.startswith("FAIL") or "FAIL" in p for p in problems + fit) else "READY"
    ver = stamp.stamp(pptx, action, res, owner, classification)
    import checks                                        # the evidence the RESULT line's score is computed from
    gate = lambda found: ("FAIL" if found else "PASS", "; ".join(found[:2]))
    checks.record(pptx, [("Template conformance (kit brand check)", *gate(conform)),
                         ("Brand colours (template palette only)", *gate(colours)),
                         ("Template look kept (its background and colour theme)", *gate(kept)),
                         ("Sensitive data", "FAIL" if blocked else "REVIEW" if to_check else "PASS",
                          "; ".join((blocked or to_check)[:2]), not blocked and bool(to_check)),
                         ("Accessibility (alt text, contrast, reading order)", *gate(af)),
                         ("Opens clean in PowerPoint (package check)", *gate(opens)),
                         ("Text fit and content (no cut text, no sample facts left)", *gate(fit))] + rows, res)
    files, pnote = pictures(out, files)
    lead = [f"FILES (attach every one): {', '.join(Path(f).name for f in files)}"] + ([pnote] if pnote else [])
    return f"{res} | {' '.join(Path(f).name for f in files)} | v{ver}", lead + notes + problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("content", nargs="?"); ap.add_argument("--template"); ap.add_argument("--format", default="onepager")
    ap.add_argument("--diagram"); ap.add_argument("--style", default="auto"); ap.add_argument("--title")
    ap.add_argument("--out", required=True); ap.add_argument("--classification"); ap.add_argument("--owner")
    ap.add_argument("--theme", default="ulta", help="ulta, glow, velvet, frost, paper, sunset, charcoal")
    ap.add_argument("--frame", action="store_true", help="16:9: add the template's cover and closing slides (asked for only)")
    a = ap.parse_args()
    if not a.diagram and not a.content:
        sys.exit("give content.md (with --template) or --diagram flows.txt")
    line, extra = make(a.diagram or a.content, a.out, a.template, a.format, bool(a.diagram), a.style, a.title,
                       a.classification, a.owner, theme=a.theme, frame=a.frame)
    print(line)
    for x in extra[:10]:
        print("  " + x)
    pptx = Path(a.out).with_suffix(".pptx")
    if pptx.exists():
        import tokens as TK
        src = Path(a.diagram or a.content)
        print(TK.report(pptx, src.read_text(encoding="utf-8", errors="replace"), line + "\n".join(extra[:10]),
                        "diagram" if a.diagram else "one-pager"))
    sys.exit(0 if line.startswith("READY") else 1)


if __name__ == "__main__":
    main()
