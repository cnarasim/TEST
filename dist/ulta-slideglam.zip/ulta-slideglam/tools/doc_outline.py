"""Word / PDF / PowerPoint / text document -> a short outline to write a storyboard from, with page references.

    python tools/doc_outline.py report.docx|.pdf|.pptx|.md --out /mnt/data/out/report-outline.md
    python tools/doc_outline.py report.pdf --section S7 [--section S8]   # full text of the sections you need

The outline (read THIS, not the document) lists every section as:
  S7  p.12  3. Delivery plan  (840 words, 1 table)   first two sentences ... | numbers: $1.2M, 18%, Q3
so a 60-page document becomes ~2-4k characters. Pull full text only for the sections a slide needs.
In the storyboard, cite sources in each slide's notes: "Source: report.pdf p.12 (S7)". Numbers come only from the
document - never round, invent or "update" them.
"""
import argparse, re
from pathlib import Path

NUM = re.compile(r"(?<![\w.])(?:[$€£]\s?\d[\d,]*(?:\.\d+)?\s?(?:[KMB]|bn|million|billion)?|\d[\d,]*(?:\.\d+)?\s?%|"
                 r"\d{1,3}(?:,\d{3})+(?:\.\d+)?|Q[1-4](?:\s?\d{2,4})?|FY\s?\d{2,4})(?![\w])")


def sections_docx(p):
    from docx import Document
    doc = Document(str(p))
    secs, cur = [], {"title": "(start)", "level": 1, "page": None, "text": [], "tables": 0}
    body = doc.element.body
    for el in body.iterchildren():
        tag = el.tag.split("}")[-1]
        if tag == "p":
            from docx.text.paragraph import Paragraph
            par = Paragraph(el, doc)
            style = (par.style.name if par.style is not None else "") or ""
            m = re.match(r"(?i)heading\s*(\d)|title", style)
            if m and par.text.strip():
                if cur["text"] or cur["tables"]:
                    secs.append(cur)
                cur = {"title": par.text.strip(), "level": int(m.group(1) or 1) if m.group(1) else 1, "page": None,
                       "text": [], "tables": 0}
            elif par.text.strip():
                cur["text"].append(par.text.strip())
        elif tag == "tbl":
            cur["tables"] += 1
            rows = el.findall(".//{http://schemas.openxmlformats.org/wordprocessingml/2006/main}tr")[:6]
            for r in rows:
                cells = ["".join(t.text or "" for t in c.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t"))
                         for c in r.findall("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}tc")]
                cur["text"].append(" | ".join(cells))
    secs.append(cur)
    return secs


def pdf_reader():
    """pypdf, or PyPDF2 (its older name, same API) - whichever the sandbox has."""
    try:
        from pypdf import PdfReader
    except ImportError:
        try:
            from PyPDF2 import PdfReader
        except ImportError:
            raise SystemExit("reading a PDF needs pypdf (or PyPDF2), which this environment does not have - "
                             "attach the deck as .pptx or the document as .docx instead")
    return PdfReader


def sections_pdf(p):
    rd = pdf_reader()(str(p))
    secs, cur = [], None
    head = re.compile(r"^(?:\d{1,2}(?:\.\d{1,2})*\.?\s+[A-Z][^.]{2,80}|[A-Z][A-Z &/,-]{4,80}|(?:Executive summary|Introduction|Background|Conclusion|Recommendations?|Appendix)\b.{0,60})$")
    for pn, page in enumerate(rd.pages, 1):
        for line in (page.extract_text() or "").splitlines():
            s = line.strip()
            if not s:
                continue
            if head.match(s) and len(s.split()) <= 12 and not s.endswith((",", ";")):
                if cur and (cur["text"] or cur is None):
                    secs.append(cur)
                cur = {"title": s, "level": s.count(".") + 1 if s[0].isdigit() else 1, "page": pn, "text": [], "tables": 0}
            else:
                if cur is None:
                    cur = {"title": "(start)", "level": 1, "page": pn, "text": [], "tables": 0}
                cur["text"].append(s)
    if cur:
        secs.append(cur)
    return secs


def sections_pptx(p):
    from pptx import Presentation
    secs = []
    for i, s in enumerate(Presentation(str(p)).slides, 1):
        texts = [sh.text_frame.text.strip() for sh in s.shapes if sh.has_text_frame and sh.text_frame.text.strip()]
        secs.append({"title": texts[0][:80] if texts else f"Slide {i}", "level": 1, "page": i, "text": texts[1:], "tables": 0})
    return secs


def sections_text(p):
    secs, cur = [], {"title": "(start)", "level": 1, "page": None, "text": [], "tables": 0}
    for line in Path(p).read_text(encoding="utf-8", errors="replace").splitlines():
        m = re.match(r"^(#{1,4})\s+(.*)", line)
        if m:
            if cur["text"]:
                secs.append(cur)
            cur = {"title": m.group(2).strip(), "level": len(m.group(1)), "page": None, "text": [], "tables": 0}
        elif line.strip():
            cur["text"].append(line.strip())
    secs.append(cur)
    return secs


def load(path):
    p = Path(path)
    ext = p.suffix.lower()
    secs = {".docx": sections_docx, ".pdf": sections_pdf, ".pptx": sections_pptx}.get(ext, sections_text)(p)
    for k, s in enumerate(secs, 1):
        s["id"] = f"S{k}"
    return secs


def first_sentences(text, n=2, limit=260):
    t = " ".join(text)
    parts = re.split(r"(?<=[.!?])\s+", t)
    out = " ".join(parts[:n])
    return out[:limit] + ("…" if len(out) > limit else "")


def outline(path):
    secs = load(path)
    total = sum(len(" ".join(s["text"]).split()) for s in secs)
    lines = [f"# Outline of {Path(path).name}: {len(secs)} sections, {total:,} words",
             "Cite as: <file> p.<page> (<id>). Pull full text: doc_outline.py <file> --section <id>", ""]
    for s in secs:
        words = len(" ".join(s["text"]).split())
        nums = list(dict.fromkeys(NUM.findall(" ".join(s["text"]))))[:6]
        ref = f"p.{s['page']}" if s["page"] else ""
        lines.append(f"{s['id']:>4}  {ref:>5}  {'  ' * (s['level'] - 1)}{s['title'][:90]}  ({words} words"
                     + (f", {s['tables']} table(s)" if s["tables"] else "") + ")")
        if words:
            lines.append(f"        {first_sentences(s['text'])}" + (f"  | numbers: {', '.join(nums)}" if nums else ""))
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("doc"); ap.add_argument("--out"); ap.add_argument("--section", action="append")
    a = ap.parse_args()
    if a.section:
        secs = {s["id"]: s for s in load(a.doc)}
        for sid in a.section:
            s = secs.get(sid)
            if not s:
                print(f"{sid}: no such section"); continue
            print(f"## {sid} {s['title']} ({'p.' + str(s['page']) if s['page'] else ''})\n" + "\n".join(s["text"]) + "\n")
        return
    text = outline(a.doc)
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(text)
        print(f"OUTLINE {a.out}: {len(text):,} characters (the document: {Path(a.doc).stat().st_size:,} bytes)")
    else:
        print(text)


if __name__ == "__main__":
    main()
