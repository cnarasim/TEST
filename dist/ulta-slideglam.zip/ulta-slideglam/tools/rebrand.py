"""Put kit output (drawn in the Ulta profile) onto the ACTIVE brand: its template master/layouts, theme colours,
fonts and logo. No-op when the active brand is Ulta. ulta_conform.py calls this for you.

    python tools/rebrand.py Name.pptx [Name.drawio] [Name.svg] [Name.html] [--brand acme]

.pptx: every slide is moved onto the brand template (same layout name, else its title-only / blank layout),
       colours are mapped by ROLE (Ulta accent1 -> brand accent1 ..., tints stay tints, RAG status kept) and written
       as theme references (schemeClr) where they are theme colours, so a later theme change in PowerPoint still
       flows through; fonts: Ulta heading -> brand heading, Ulta body/medium/bold -> brand body/medium/bold;
       SVG icons are recoloured; the Ulta logo becomes the brand logo (or is removed if the brand has none).
.drawio/.svg/.html: the same colour and font mapping on the text.
"""
import argparse, copy, re, sys, zipfile
from pathlib import Path

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import brand as B   # noqa: E402

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
SVGNS = "http://schemas.microsoft.com/office/drawing/2016/SVG/main"


def pick_layout(prs, name, portrait, tgt):
    layouts = [l for m in prs.slide_masters for l in m.slide_layouts]
    same = next((l for l in layouts if l.name == name), None)
    if same is not None:
        return same
    def busy(l):                              # fewest drawn things, no own background
        return len(l.shapes) + (5 if l._element.find(f"{P}cSld/{P}bg") is not None else 0)
    if portrait or "blank" in (name or "").lower():
        blank = [l for l in layouts if "blank" in l.name.lower()]
        return min(blank or layouts, key=busy)
    base = tgt.role("diagram_base")
    if base and base <= len(prs.slides):
        return prs.slides[base - 1].slide_layout
    return sorted(layouts, key=lambda l: len(l.placeholders))[0]


def is_logo(part):
    return "logo" in str(part.partname).lower()


def transplant(src_path, tgt):
    """New presentation from the brand template holding the kit slides (all pictures re-linked)."""
    from pptx import Presentation
    from pptx.opc.package import Part
    src = Presentation(str(src_path))
    prs = Presentation(str(tgt.template))
    lst = prs.slides._sldIdLst
    for sid in list(lst):
        prs.part.drop_rel(sid.rId); lst.remove(sid)
    prs.slide_width, prs.slide_height = src.slide_width, src.slide_height
    portrait = src.slide_height > src.slide_width
    logo = (tgt.dir / tgt["logo"]) if tgt.get("logo") else None
    notes = []
    for s in src.slides:
        new = prs.slides.add_slide(pick_layout(prs, s.slide_layout.name, portrait, tgt))
        tree = new.shapes._spTree
        for el in list(tree):
            tree.remove(el)
        remap, logo_rids = {}, set()
        pkg = new.part.package
        for rid, rel in s.part.rels.items():
            if "slideLayout" in rel.reltype or "notesSlide" in rel.reltype:
                continue
            if rel.is_external:
                remap[rid] = new.part.relate_to(rel.target_ref, rel.reltype, is_external=True); continue
            tp = rel.target_part
            blob, ext, ctype = tp.blob, str(tp.partname).rsplit(".", 1)[-1], tp.content_type
            if is_logo(tp):
                logo_rids.add(rid)
                if logo is None:
                    continue
                blob, ext = logo.read_bytes(), logo.suffix.lstrip(".").lower()
                ctype = {"svg": "image/svg+xml", "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg"}.get(ext, ctype)
            name = pkg.next_partname("/ppt/media/brand-art-%d." + ext)
            remap[rid] = new.part.relate_to(Part(name, ctype, pkg, blob), rel.reltype)
        for el in s.shapes._spTree:
            c = copy.deepcopy(el)
            if etree.QName(c).localname == "pic" and any(
                    (n.get(R + "embed") in logo_rids) for n in c.iter() if n.get(R + "embed")):
                if logo is None:
                    notes.append("kit logo removed (brand has no logo)"); continue
                fit_logo(c, logo, remap, logo_rids)
            for node in c.iter():
                for attr in list(node.attrib):
                    if attr.startswith(R) and node.attrib[attr] in remap:
                        node.attrib[attr] = remap[node.attrib[attr]]
            tree.append(c)
        if s.has_notes_slide and s.notes_slide.notes_text_frame.text.strip():
            new.notes_slide.notes_text_frame.text = s.notes_slide.notes_text_frame.text
    return prs, notes


def fit_logo(pic, logo, remap, logo_rids):
    """Keep the logo's height and right edge; width follows the brand logo's own proportions."""
    w = h = None
    if logo.suffix.lower() == ".svg":
        m = re.search(rb'viewBox="\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)', logo.read_bytes())
        if m:
            w, h = float(m.group(1)), float(m.group(2))
    else:
        try:
            from PIL import Image
            w, h = Image.open(logo).size
        except Exception:
            pass
    blip = pic.find(f".//{A}blip")
    if logo.suffix.lower() != ".svg" and blip is not None:     # PNG/JPG logo: plain blip, no svgBlip extension
        rid = next(iter(logo_rids))
        blip.set(R + "embed", rid)
        for e in list(blip):
            if etree.QName(e).localname == "extLst":
                blip.remove(e)
    if w and h:
        off, ext = pic.find(f".//{A}xfrm/{A}off"), pic.find(f".//{A}xfrm/{A}ext")
        cy = int(ext.get("cy")); right = int(off.get("x")) + int(ext.get("cx"))
        cx = int(cy * w / h)
        ext.set("cx", str(cx)); off.set("x", str(max(0, right - cx)))


TEXT_PARENTS = ("rPr", "defRPr", "endParaRPr")


def readability(x):
    """Role mapping can turn a dark accent into a light one. Keep text readable: coloured text on a light page
    at least 4.5:1, a coloured fill behind white text at least 3:1 (darkened in its own hue)."""
    for c in x.iter(A + "srgbClr"):
        fill = c.getparent()
        owner = fill.getparent() if fill is not None else None
        if owner is None or etree.QName(fill).localname != "solidFill":
            continue
        v = c.get("val").upper()
        if etree.QName(owner).localname in TEXT_PARENTS and v != "FFFFFF" and B.lch(v)[1] >= 10:
            c.set("val", B.darken_to(v, "FFFFFF", 4.5))
    def box(el):
        o, e = el.find(f"{P}spPr/{A}xfrm/{A}off"), el.find(f"{P}spPr/{A}xfrm/{A}ext")
        return None if o is None or e is None else (int(o.get("x")), int(o.get("y")), int(e.get("cx")), int(e.get("cy")))
    def white_text(sp):
        cols = []
        for r in sp.iter(A + "rPr"):
            c = r.find(f"{A}solidFill/{A}srgbClr")
            sc = r.find(f"{A}solidFill/{A}schemeClr")
            cols.append("FFFFFF" if sc is not None and sc.get("val") in ("bg1", "lt1") else (c.get("val").upper() if c is not None else None))
        return bool(cols) and all(c == "FFFFFF" for c in cols)
    shapes = list(x.iter(P + "sp"))
    filled = [(sp, sp.find(f"{P}spPr/{A}solidFill/{A}srgbClr")) for sp in shapes]
    filled = [(sp, f, box(sp)) for sp, f in filled if f is not None and box(sp)]
    for sp in shapes:
        if not white_text(sp):
            continue
        own = sp.find(f"{P}spPr/{A}solidFill/{A}srgbClr")
        if own is None:                        # text box laid over a card: the card behind it is the background
            b = box(sp)
            if b is None:
                continue
            cx, cy = b[0] + b[2] / 2, b[1] + b[3] / 2
            under = [(fb[2] * fb[3], f) for o, f, fb in filled if o is not sp and
                     fb[0] <= cx <= fb[0] + fb[2] and fb[1] <= cy <= fb[1] + fb[3]]
            own = min(under, key=lambda t: t[0])[1] if under else None
        if own is not None and own.get("val").upper() != "FFFFFF":
            own.set("val", B.darken_to(own.get("val").upper(), "FFFFFF", 3.0))


def recolour_xml(x, cmap, fmap, theme_slots, scales={}):
    bound = []
    for c in list(x.iter(A + "srgbClr")):
        old = c.get("val").upper()
        c.set("val", cmap(old))
        slot = cmap.slot_of(old)
        if slot and theme_slots.get(slot) == c.get("val"):
            bound.append((c, slot))
    readability(x)
    for c, slot in bound:                      # still the theme colour after the readability pass: bind to the theme
        if c.get("val") == theme_slots[slot]:
            c.tag = A + "schemeClr"; c.set("val", slot)
    # per paragraph: shrink so the text takes no more width in the new font than it did in the kit's font
    # (kit boxes are fixed; this keeps every line break where the kit put it)
    M = scales.get("__metrics__")
    for p_ in x.iter(A + "p"):
        runs = [(r.find(A + "rPr"), r.findtext(A + "t") or "") for r in p_.findall(A + "r")]
        runs = [(rp, t) for rp, t in runs if rp is not None and rp.find(A + "latin") is not None]
        if not runs or M is None:
            continue
        src_w = tgt_w = 0.0
        for rp, t in runs:
            old = rp.find(A + "latin").get("typeface")
            new = fmap.get(old, (old, False))[0] or old
            a_, b_ = B.width_of(t, old, M), B.width_of(t, new, M)
            if a_ is None or b_ is None:
                src_w = tgt_w = 0; break
            sz = int(rp.get("sz") or 1800)
            src_w += a_ * sz; tgt_w += b_ * sz
        if tgt_w > src_w > 0:
            k = src_w / tgt_w
            for rp, _ in runs:
                if rp.get("sz"):
                    rp.set("sz", str(max(700, int(int(rp.get("sz")) * k / 50) * 50)))
    for tag in ("latin", "ea", "cs"):
        for f in x.iter(A + tag):
            tf = f.get("typeface")
            if tf in fmap and fmap[tf][0]:
                f.set("typeface", fmap[tf][0])
                rpr = f.getparent()
                if fmap[tf][1] and rpr is not None:
                    rpr.set("b", "1")



def scale_text(s, src, scales):
    """SVG <text>/<tspan> font-size and drawio fontSize, scaled by the source->target width ratio of their font."""
    heading = scales.get(src.font("heading"), 1.0)
    body = {"700": scales.get(src.font("body_bold"), 1.0), "500": scales.get(src.font("body_medium"), 1.0)}
    def factor(tag):
        if "Playfair" in tag:
            return heading
        if "Circular" in tag or "fontFamily" not in tag and "font-family" not in tag:
            w = re.search(r'font-weight="(\d+)"', tag)
            return body.get(w.group(1) if w else "", scales.get(src.font("body"), 1.0))
        return 1.0
    def svg_tag(mo):
        tag, k = mo.group(0), factor(mo.group(0))
        return tag if k >= 0.99 else re.sub(r'font-size="([\d.]+)"', lambda m: f'font-size="{float(m.group(1)) * k:.1f}"', tag)
    s = re.sub(r"<(?:text|tspan)\b[^>]*>", svg_tag, s)
    def drawio_style(mo):
        st, k = mo.group(0), factor(mo.group(0))
        return st if k >= 0.99 else re.sub(r"fontSize=([\d.]+)", lambda m: f"fontSize={float(m.group(1)) * k:.1f}", st)
    return re.sub(r'style="[^"]*fontSize=[^"]*"', drawio_style, s)


def recolour_text(s, cmap, fmap, families=(), readable=False):
    s = re.sub(r"#([0-9A-Fa-f]{6})\b", lambda mo: "#" + cmap(mo.group(1)), s)
    if readable:                               # SVG headings/labels in a light brand colour: darken to 4.5:1
        s = re.sub(r'(<(?:text|tspan)\b[^>]*fill=")(#?)([0-9A-Fa-f]{6})"',
                   lambda mo: mo.group(1) + mo.group(2) +
                   (B.darken_to(mo.group(3).upper()) if B.lch(mo.group(3).upper())[1] >= 10 else mo.group(3)) + '"', s)
    s = re.sub(r'(fill|stroke|stop-color)="([0-9A-Fa-f]{6})"', lambda mo: f'{mo.group(1)}="{cmap(mo.group(2))}"', s)
    for old, (new, _b) in sorted(fmap.items(), key=lambda kv: -len(kv[0])):
        if new and old not in ("Calibri", "Arial"):
            s = s.replace(old, new)
    for old, new in families:                    # bare family names (CSS font-family, drawio fontFamily)
        s = s.replace(old, new)
    return s


def rebrand_pptx(path, tgt, cmap, fmap, scales):
    prs, notes = transplant(path, tgt)
    import atomic
    atomic.save(prs, path)
    z = zipfile.ZipFile(path)
    items = {n: z.read(n) for n in z.namelist()}
    infos = {n: z.getinfo(n) for n in z.namelist()}
    slots = {k: v.upper() for k, v in (tgt.get("theme") or {}).items()}
    for n in items:
        if re.match(r"ppt/slides/slide\d+\.xml$", n):
            x = etree.fromstring(items[n])
            recolour_xml(x, cmap, fmap, slots, scales)
            items[n] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
        elif n.startswith("ppt/media/brand-art-") and n.endswith(".svg") and not (tgt.get("logo") and
                items[n] == (tgt.dir / tgt["logo"]).read_bytes()):
            items[n] = recolour_text(items[n].decode("utf8"), cmap, fmap).encode("utf8")   # icons: colours only
    import atomic
    with atomic.zip_out(path) as w:
        for n, d in items.items():
            w.writestr(infos[n], d)
    return notes


def rebrand(paths, brand_name=None):
    tgt = B.Brand(brand_name)
    if tgt.name == B.SOURCE:
        return 0, []
    src = B.Brand(B.SOURCE)
    cmap, fmap = B.ColourMap(src, tgt), B.font_map(src, tgt)
    families = [("Playfair Display", tgt.font("heading")), ("Circular Std", tgt.font("body")),
                ("Playfair", tgt.font("heading")), ("Circular", tgt.font("body"))]
    scales = B.font_scales(src, tgt)
    scales["__metrics__"] = B.metrics_for(tgt)
    notes = []
    for p in map(Path, paths):
        if p.suffix == ".pptx":
            notes += rebrand_pptx(p, tgt, cmap, fmap, scales)
        elif p.suffix in (".drawio", ".svg", ".html") and p.exists():
            t = scale_text(p.read_text(encoding="utf8"), src, scales) if p.suffix in (".svg", ".drawio") else p.read_text(encoding="utf8")
            p.write_text(recolour_text(t, cmap, fmap, families, readable=p.suffix == ".svg"), encoding="utf8")
    return len(cmap.changed), sorted(set(notes))


def audit(paths, brand_name=None):
    """Brand conformance of finished files: [(file, problem)]. Empty list = PASS."""
    tgt = B.Brand(brand_name)
    src = B.Brand(B.SOURCE)
    if tgt.name == src.name:
        return []
    allowed_fonts = {f for f in (tgt.get("fonts") or {}).values() if isinstance(f, str)}
    src_fonts = {f for f in (src.get("fonts") or {}).values() if isinstance(f, str)} | {"Playfair", "Circular"}
    src_logo = (TOOLS.parent / "modules/ultabranddeliverables/scripts/kit/infographic/ulta-logo.svg").read_bytes()
    out = []
    for p in map(Path, paths):
        if not p.exists():
            continue
        if p.suffix == ".pptx":
            z = zipfile.ZipFile(p)
            own = (tgt.dir / tgt["logo"]).read_bytes() if tgt.get("logo") else None
            slide_media = {"ppt/media/" + m.split("/media/")[-1] for r in z.namelist()
                           if re.match(r"ppt/slides/_rels/slide\d+\.xml\.rels$", r)
                           for m in re.findall(r'Target="([^"]*media/[^"]+)"', z.read(r).decode())}
            for n in z.namelist():                      # only what the slides show; the master is the brand's own
                if n in slide_media and z.read(n) == src_logo and own != src_logo:
                    out.append((p.name, f"Ulta logo still embedded ({n})"))
                if not re.match(r"ppt/slides/slide\d+\.xml$", n):
                    continue
                x = etree.fromstring(z.read(n))
                fonts = {f.get("typeface") for f in x.iter(A + "latin")} - {None}
                bad = sorted(f for f in fonts if f not in allowed_fonts and not f.startswith("+"))
                if bad:
                    out.append((p.name, f"fonts outside the brand: {bad}"))
                cols = {c.get("val").upper() for c in x.iter(A + "srgbClr")}
                off = sorted(c for c in cols if not B.in_family(c, tgt))
                if off:
                    out.append((p.name, f"colours outside the brand family: {off[:6]}"))
                for r in x.iter(A + "rPr"):
                    c = r.find(f"{A}solidFill/{A}srgbClr")
                    if c is not None and B.lch(c.get("val"))[1] >= 10 and B.contrast(c.get("val"), "FFFFFF") < 4.4:
                        t = r.getparent().findtext(A + "t") or ""
                        out.append((p.name, f"low-contrast text #{c.get('val')} '{t[:25]}'")); break
        elif p.suffix in (".svg", ".drawio", ".html"):
            t = p.read_text(encoding="utf8")
            left = sorted({f for f in src_fonts if f in t})
            if left:
                out.append((p.name, f"Ulta font names left: {left}"))
            off = sorted({c.upper() for c in re.findall(r"#([0-9A-Fa-f]{6})\b", t)} - {""})
            off = [c for c in off if not B.in_family(c, tgt)]
            if off:
                out.append((p.name, f"colours outside the brand family: {off[:6]}"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+"); ap.add_argument("--brand"); ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if a.check:
        probs = audit(a.files, a.brand)
        for f, m in probs:
            print(f"  {f}: {m}")
        print("BRAND CHECK: " + ("PASS" if not probs else f"FAIL ({len(probs)})"))
        sys.exit(1 if probs else 0)
    n, notes = rebrand(a.files, a.brand)
    name = a.brand or B.active_name()
    print(f"rebrand: {'nothing to do (active brand is ulta)' if name == B.SOURCE else f'{n} colour(s) mapped to brand {name!r}'}")
    for x in notes:
        print("  " + x)


if __name__ == "__main__":
    main()
