#!/usr/bin/env python3
"""ULTA Presentation Central - Pre-flight Health & Capability Diagnostic Tool

Usage:
    python tools/doctor.py [--json]
"""
import os, sys, shutil, json, platform
from pathlib import Path

TOOLS_DIR = Path(__file__).resolve().parent
SKILL_DIR = TOOLS_DIR.parent
sys.path.insert(0, str(TOOLS_DIR))                       # its sibling modules, also under python -I
from stamp import SKILL_VERSION                          # noqa: E402

def check_env():
    results = {
        "skill": "ulta-slideglam",
        "version": SKILL_VERSION,
        "python": {
            "version": platform.python_version(),
            "executable": sys.executable,
            "compatible": sys.version_info >= (3, 10)
        },
        "packages": {},
        "binaries": {},
        "assets": {},
        "paths": {}
    }

    # Core & optional packages
    packages = [
        ("lxml", True),
        ("pptx", True),
        ("docx", True),
        ("openpyxl", True),
        ("PIL", True),
        ("pypdf", False),
        ("fontTools", False),
        ("resvg_py", False),
        ("numpy", False)
    ]
    for pkg, required in packages:
        try:
            __import__(pkg)
            results["packages"][pkg] = {"installed": True, "required": required}
        except ImportError:
            results["packages"][pkg] = {"installed": False, "required": required}

    # External binaries
    binaries = ["soffice", "libreoffice", "pdftoppm", "resvg", "antiword"]
    for b in binaries:
        path = shutil.which(b)
        results["binaries"][b] = {"found": bool(path), "path": path}

    # Templates & schemas
    tpl_pptx = SKILL_DIR / "assets" / "templates" / "Ulta Beauty PPT Standard_Curated.pptx"
    tpl_word = SKILL_DIR / "modules" / "ultabranddeliverables" / "scripts" / "kit" / "templates" / "Ulta Beauty Word template.docx"
    schemas = SKILL_DIR / "tools" / "ooxml_schemas" / "ISO-IEC29500-4_2016"
    fonts_inter = SKILL_DIR / "fonts" / "Inter-Regular.otf"
    fonts_playfair = SKILL_DIR / "fonts" / "PlayfairDisplay-Black.ttf"

    results["assets"]["pptx_template"] = tpl_pptx.exists()
    results["assets"]["word_template"] = tpl_word.exists()
    results["assets"]["ooxml_schemas"] = schemas.exists() and len(list(schemas.glob("*.xsd"))) >= 10
    results["assets"]["bundled_fonts"] = fonts_inter.exists() and fonts_playfair.exists()

    # Paths
    has_mnt = Path("/mnt/data").exists()
    out_dir = Path("/mnt/data/out") if has_mnt else Path(os.environ.get("ULTA_OUT_DIR", Path.cwd() / "out"))
    results["paths"]["chatgpt_sandbox"] = has_mnt
    results["paths"]["out_directory"] = str(out_dir)
    results["paths"]["out_writable"] = os.access(str(out_dir.parent), os.W_OK) if not out_dir.exists() else os.access(str(out_dir), os.W_OK)

    # Readiness score
    core_ok = all(results["packages"][p]["installed"] for p, req in packages if req)
    assets_ok = all(results["assets"].values())
    results["ready"] = core_ok and assets_ok

    return results

def main():
    json_mode = "--json" in sys.argv
    data = check_env()

    if json_mode:
        print(json.dumps(data, indent=2))
        sys.exit(0 if data["ready"] else 1)

    print("======================================================================")
    print(f"  ULTA Presentation Central - Pre-Flight Diagnostic Report ({SKILL_VERSION})")
    print("======================================================================")
    py_status = "OK" if data["python"]["compatible"] else "UPGRADE NEEDED"
    print(f"• Runtime: Python {data['python']['version']} ({py_status}) [{data['python']['executable']}]")

    print("\n• Core & Extended Dependencies:")
    for pkg, info in data["packages"].items():
        state = "OK" if info["installed"] else ("MISSING (Required)" if info["required"] else "Not installed (Optional)")
        print(f"  - {pkg:<12}: {state}")

    print("\n• External Binary Converters:")
    lo = "FOUND" if (data["binaries"]["soffice"]["found"] or data["binaries"]["libreoffice"]["found"]) else "NOT FOUND (Previews use pure-Python fallbacks)"
    print(f"  - LibreOffice : {lo}")
    pdf2png = "FOUND" if data["binaries"]["pdftoppm"]["found"] else "NOT FOUND (pypdf/resvg fallback used)"
    print(f"  - pdftoppm    : {pdf2png}")

    print("\n• Template & Schema Assets:")
    print(f"  - PPTX Standard Template : {'OK' if data['assets']['pptx_template'] else 'MISSING'}")
    print(f"  - Word Standard Template : {'OK' if data['assets']['word_template'] else 'MISSING'}")
    print(f"  - ISO/IEC 29500 Schemas  : {'OK' if data['assets']['ooxml_schemas'] else 'MISSING'}")
    print(f"  - Bundled Brand Fonts    : {'OK' if data['assets']['bundled_fonts'] else 'MISSING'}")

    print("\n• Target Storage & Sandboxing:")
    print(f"  - ChatGPT /mnt/data Sandbox : {'ACTIVE' if data['paths']['chatgpt_sandbox'] else 'STANDALONE / LOCAL WORKSPACE'}")
    print(f"  - Active Output Target      : {data['paths']['out_directory']}")

    print("----------------------------------------------------------------------")
    if data["ready"]:
        print("✔ STATUS: FULLY OPERATIONAL (Enterprise Ready)")
    else:
        print("▲ STATUS: INCOMPLETE (Install missing core packages)")
    print("======================================================================\n")

if __name__ == "__main__":
    main()
