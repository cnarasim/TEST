"""Zero-deviation brand colours: every colour in every file the skill writes is an Ulta template colour.

    python tools/brand_colours.py FILE [FILE ...]      PASS / FAIL per file, one line per off-brand colour; exit 1 on any

The palette is the template's own (brand.json "palette", completed from the template at run time):
  colour wheel (template slide 3)   E9341C Fiery Sunset, E8275A Magenta Mood, DE7445 Orange Squeeze, 5D0F43 Berry Bliss
  theme colours                     both slide masters' themes (UB_Corporate, ULTA 2024) - not the Office notes theme
  shades, tints, neutrals           the ones the template's content slides use
  status (RAG)                      00B050 / 0BA03E green, FFC000 amber, FF0000 red - on status marks only, never text
A slide copied from the template may also keep the colours of its own template slide (e.g. slide 17's dark teal).
Each format is held to its own Ulta template: Word files to the Ulta Word template's colours; architecture diagrams
made to the ULTA Enterprise Diagram Standards (draw.io, their page and picture) to that standard's colours plus the
palette above. Checked: .pptx (slides, charts), .docx, .xlsx, .svg, .html / .htm, .drawio, .json specs.
"""
import json, re, sys, zipfile
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import brand as _B   # noqa: E402

A = "http://schemas.openxmlformats.org/drawingml/2006/main"
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
HEX = re.compile(r"^[0-9A-F]{6}$")
NAMED = {"white": "FFFFFF", "black": "000000", "red": "FF0000", "green": "008000", "blue": "0000FF", "gray": "808080",
         "grey": "808080", "orange": "FFA500", "yellow": "FFFF00", "purple": "800080", "pink": "FFC0CB", "navy": "000080",
         "teal": "008080", "silver": "C0C0C0", "maroon": "800000", "lime": "00FF00", "aqua": "00FFFF", "fuchsia": "FF00FF",
         "olive": "808000", "lightgray": "D3D3D3", "lightgrey": "D3D3D3", "darkgray": "A9A9A9", "darkgrey": "A9A9A9",
         "whitesmoke": "F5F5F5", "gainsboro": "DCDCDC", "dimgray": "696969", "dimgrey": "696969", "gold": "FFD700",
         "crimson": "DC143C", "tomato": "FF6347", "coral": "FF7F50", "salmon": "FA8072", "magenta": "FF00FF",
         "cyan": "00FFFF", "indigo": "4B0082", "violet": "EE82EE", "brown": "A52A2A", "beige": "F5F5DC", "ivory": "FFFFF0"}
DRAWIO_KEYS = ("fillColor", "strokeColor", "fontColor", "gradientColor", "labelBackgroundColor", "labelBorderColor",
               "swimlaneFillColor", "imageBackground", "imageBorder")
_CACHE = {}
MARKS = set("●○■□▲▼◆◇★►◀▶◄• ")


def _themes(path):
    """{theme part: {slot: hex}} for every theme in an Office package."""
    out = {}
    with zipfile.ZipFile(str(path)) as z:
        for n in z.namelist():
            if re.search(r"theme/theme\d+\.xml$", n):
                x = z.read(n).decode("utf-8", "ignore")
                out[n] = {k: v.upper() for k, v in re.findall(
                    r"<a:(dk1|lt1|dk2|lt2|accent\d|hlink|folHlink)>.*?(?:srgbClr val|lastClr)=\"(\w{6})\"", x, re.S)}
    return out


def palette(b=None):
    """{'allowed': set, 'status': set, 'by_source': {template slide: set}} - the template's colours."""
    b = b or _B.current()
    if b.name in _CACHE:
        return _CACHE[b.name]
    p = b.get("palette") or {}
    allowed = {c.upper() for k in ("brand", "theme", "tints", "neutrals") for c in p.get(k, [])}
    status = {c.upper() for c in p.get("status", ["00B050", "FFC000", "FF0000"])}
    by_source = {}
    try:
        ref = Path(str(b.template))
        with zipfile.ZipFile(str(ref)) as z:
            masters = [n for n in z.namelist() if re.match(r"ppt/slideMasters/_rels/slideMaster\d+\.xml\.rels$", n)]
            used = {"ppt/theme/" + t for n in masters for t in re.findall(r"theme/(theme\d+\.xml)", z.read(n).decode())}
            names = sorted((n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)),
                           key=lambda n: int(re.findall(r"\d+", n)[-1]))
            for n in names:
                k = int(re.findall(r"\d+", n)[-1])
                by_source[k] = {c.upper() for c in re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', z.read(n).decode("utf-8", "ignore"))}
        for part, slots in _themes(ref).items():
            if part in used:
                allowed |= set(slots.values())
    except Exception:
        pass
    _CACHE[b.name] = {"allowed": allowed | status, "status": status, "by_source": by_source}
    return _CACHE[b.name]


def word_palette():
    """The Ulta Word template's colours (tools/ulta_word.py)."""
    try:
        import ulta_word
    except ImportError:   # ULTA SlideGlam ships no Word tools
        return set()
    return set(ulta_word.WORD_PALETTE)


def diagram_palette():
    """ULTA Enterprise Diagram Standards colours (brands/<brand>/diagram_standard.json) plus the brand palette."""
    p = palette()
    std = (TOOLS.parent / "brands" / "ulta" / "diagram_standard.json").read_text(encoding="utf-8")
    return {"allowed": p["allowed"] | {c.upper() for c in re.findall(r"#?([0-9A-Fa-f]{6})\b", std)},
            "status": p["status"], "by_source": p["by_source"]}


def is_enterprise(text):
    return "Enterprise Diagram" in text or "Existing / Keep" in text


def _hex(v):
    v = (v or "").strip().lstrip("#").upper()
    if len(v) == 8 and HEX.match(v[2:]):            # ARGB (Excel)
        v = v[2:]
    if len(v) == 3 and re.match(r"^[0-9A-F]{3}$", v):
        v = "".join(c * 2 for c in v)
    return v if HEX.match(v) else None


def _css_colours(text):
    """[(hex, is_text_colour)] from CSS / SVG / HTML text."""
    out = []
    for m in re.finditer(r"(?<![\w-])(color|fill|stroke|background(?:-color)?|border(?:-[a-z]+)?(?:-color)?|stop-color|"
                         r"outline(?:-color)?|box-shadow|text-decoration-color|caret-color|accent-color|column-rule-color|"
                         r"--[\w-]+)\s*[:=]\s*[\"']?([^;\"'}<>]+)", text, re.I):
        prop, val = m.group(1).lower(), m.group(2)
        for h in re.findall(r"#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})\b", val):
            out.append((_hex(h), prop == "color"))
        for r_, g_, b_ in re.findall(r"rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)", val):
            out.append((f"{int(r_):02X}{int(g_):02X}{int(b_):02X}", prop == "color"))
        plain = re.sub(r"var\(--[\w-]+\)", " ", val)          # a CSS variable's NAME is not a colour (var(--orange))
        if not prop.startswith("--") and not re.search(r"[\[\]|.({]", plain):   # JS (STICKY.yellow, {error: PINK}) is not CSS
            for w in re.findall(r"(?<![\w-])([a-z]+)(?![\w-])", plain.lower()):
                if w in NAMED:
                    out.append((NAMED[w], prop == "color"))
    return [(h, t) for h, t in out if h]


def _sources(deck):
    """{slide number: template slide} from the deck's build record (when it has one)."""
    for side in (Path(str(deck) + ".ulta.json"),):
        try:
            meta = json.loads(side.read_text())
            src = (meta.get("typeset") or {}).get("sources") or {}
            return {int(k): v for k, v in src.items() if isinstance(v, int)}
        except Exception:
            pass
    return {}


def audit_pptx(path, pal, sources=None):
    """sources: {slide number: template slide} (validate_deck passes the mapping; else the build record)."""
    probs = []
    src = sources or _sources(path)
    with zipfile.ZipFile(str(path)) as z:
        names = z.namelist()
        slides = sorted((n for n in names if re.match(r"ppt/slides/slide\d+\.xml$", n)), key=lambda n: int(re.findall(r"\d+", n)[-1]))
        order = {}
        try:                                          # slide order = presentation order, not part names
            pres = z.read("ppt/presentation.xml").decode()
            rels = z.read("ppt/_rels/presentation.xml.rels").decode()
            rid = dict(re.findall(r'Id="(rId\d+)"[^>]*Target="(slides/slide\d+\.xml)"', rels))
            rid.update({a: b_ for b_, a in re.findall(r'Target="(slides/slide\d+\.xml)"[^>]*Id="(rId\d+)"', rels)})
            for i, r_ in enumerate(re.findall(r'<p:sldId [^>]*r:id="(rId\d+)"', pres), 1):
                if r_ in rid:
                    order["ppt/" + rid[r_]] = i
        except Exception:
            pass
        for n in slides:
            i = order.get(n, int(re.findall(r"\d+", n)[-1]))
            ok = pal["allowed"] | pal["by_source"].get(src.get(i), set())
            x = z.read(n).decode("utf-8", "ignore")
            parts = [(n, x)]
            relp = n.replace("slides/", "slides/_rels/") + ".rels"
            if relp in names:
                for t in re.findall(r'Target="\.\./charts/(chart\d+\.xml)"', z.read(relp).decode()):
                    parts.append(("ppt/charts/" + t, z.read("ppt/charts/" + t).decode("utf-8", "ignore")))
            for part, xml in parts:
                for c in sorted({c.upper() for c in re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', xml)} - ok):
                    probs.append(f"slide {i} ({part.rsplit('/', 1)[-1]}): {c} is not an Ulta template colour")
                for c in sorted({v.lower() for v in re.findall(r'prstClr val="(\w+)"', xml)}):
                    h = NAMED.get(c)
                    if not h or h not in ok:
                        probs.append(f"slide {i}: preset colour '{c}' is not an Ulta template colour")
                for rpr, txt in re.findall(r"<a:r><a:rPr\b[^>]*>(.*?)</a:rPr>.*?<a:t>([^<]*)</a:t>", xml, re.S):
                    if txt.strip() and set(txt.strip()) <= MARKS:      # a status dot / square / arrow: a mark, not text
                        continue
                    for c in re.findall(r'<a:solidFill><a:srgbClr val="([0-9A-Fa-f]{6})"', rpr):
                        if c.upper() in pal["status"] and c.upper() not in pal["by_source"].get(src.get(i), set()):
                            probs.append(f"slide {i}: text in status colour {c.upper()} - status colours mark, never colour text "
                                         "(template rule: never use red font)")
    return sorted(set(probs), key=lambda s: (int(re.findall(r"\d+", s)[0]) if re.findall(r"\d+", s) else 0, s))


def _theme_map(z, part):
    try:
        x = z.read(part).decode("utf-8", "ignore")
    except KeyError:
        return {}
    return {k: v.upper() for k, v in re.findall(r"<a:(dk1|lt1|dk2|lt2|accent\d|hlink|folHlink)>.*?(?:srgbClr val|lastClr)=\"(\w{6})\"", x, re.S)}


def audit_docx(path, pal):
    probs = []
    pal = {"allowed": word_palette(), "status": set()}
    with zipfile.ZipFile(str(path)) as z:
        theme = _theme_map(z, "word/theme/theme1.xml")
        alias = {"text1": "dk1", "background1": "lt1", "text2": "dk2", "background2": "lt2", "dark1": "dk1", "light1": "lt1",
                 "dark2": "dk2", "light2": "lt2", "hyperlink": "hlink", "followedHyperlink": "folHlink"}
        for n in z.namelist():
            if not re.match(r"word/(document|styles|numbering|header\d*|footer\d*|footnotes|endnotes)\.xml$", n):
                continue
            x = z.read(n).decode("utf-8", "ignore")
            for tag, attrs in re.findall(r"<w:(color|shd|top|bottom|left|right|insideH|insideV|u)\b([^>]*)/?>", x):
                tc = re.search(r'w:themeColor="(\w+)"', attrs)
                vals = []
                if tc:
                    vals.append(theme.get(alias.get(tc.group(1), tc.group(1))))
                else:
                    for key in ("w:val", "w:fill", "w:color"):
                        mm = re.search(key + r'="([0-9A-Fa-f]{6})"', attrs)
                        if mm and not (tag == "u" and key == "w:val"):
                            vals.append(mm.group(1).upper())
                for c in vals:
                    if c and c not in pal["allowed"]:
                        probs.append(f"{n.rsplit('/', 1)[-1]}: {c} ({tag}) is not an Ulta template colour")
                    elif c and tag == "color" and c in pal["status"]:
                        probs.append(f"{n.rsplit('/', 1)[-1]}: text in status colour {c} - never red / green text")
            for h in re.findall(r'w:highlight w:val="(\w+)"', x):
                if h != "none":
                    probs.append(f"{n.rsplit('/', 1)[-1]}: highlighter '{h}' is not an Ulta template colour")
            for c in re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', x):
                if c.upper() not in pal["allowed"]:
                    probs.append(f"{n.rsplit('/', 1)[-1]}: {c.upper()} (drawing) is not an Ulta template colour")
    return sorted(set(probs))


def audit_xlsx(path, pal):
    probs = []
    with zipfile.ZipFile(str(path)) as z:
        theme = _theme_map(z, "xl/theme/theme1.xml")
        idx = ["lt1", "dk1", "lt2", "dk2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hlink", "folHlink"]
        for n in z.namelist():
            if not re.match(r"xl/(styles|worksheets/sheet\d+|drawings/drawing\d+|charts/chart\d+)\.xml$", n):
                continue
            x = z.read(n).decode("utf-8", "ignore")
            for el, attrs in re.findall(r"<(\w*:?(?:color|fgColor|bgColor|tabColor))\b([^>]*)/?>", x):
                rgb = re.search(r'rgb="([0-9A-Fa-f]{8}|[0-9A-Fa-f]{6})"', attrs)
                th = re.search(r'theme="(\d+)"', attrs)
                c = _hex(rgb.group(1)) if rgb else (theme.get(idx[int(th.group(1))]) if th and int(th.group(1)) < len(idx) else None)
                if c and c not in pal["allowed"]:
                    probs.append(f"{n.rsplit('/', 1)[-1]}: {c} ({el}) is not an Ulta template colour")
            for c in re.findall(r'srgbClr val="([0-9A-Fa-f]{6})"', x):
                if c.upper() not in pal["allowed"]:
                    probs.append(f"{n.rsplit('/', 1)[-1]}: {c.upper()} (chart/drawing) is not an Ulta template colour")
    return sorted(set(probs))


def audit_text(path, pal):
    """SVG, HTML, draw.io, JSON: every colour literal (CSS, attributes, draw.io styles, the kit's embedded page spec)."""
    x = Path(path).read_text(encoding="utf-8", errors="ignore")
    if is_enterprise(x):
        pal = diagram_palette()
    found = list(_css_colours(x))
    found += [(v.upper(), False) for v in re.findall(
        r'"(?:[a-z_]*(?:colou?r|fill|stroke|ink|accent|line|bg|tint|band|edge|text)[a-z_]*)"\s*:\s*"([0-9A-Fa-f]{6})"', x, re.I)]
    for m in re.finditer(r"\b(fill|stroke|stop-color|color|bgcolor)=\"([^\"]+)\"", x):       # SVG / HTML attributes
        v = m.group(2).strip()
        h = _hex(v) if v.startswith("#") else NAMED.get(v.lower())
        if h:
            found.append((h, False))
    for k in DRAWIO_KEYS:                                                                     # draw.io styles
        for v in re.findall(k + r"=(#?[0-9A-Fa-f]{6}|#[0-9A-Fa-f]{3}\b)", x):
            found.append((_hex(v), k == "fontColor"))
    if Path(path).suffix.lower() == ".json":
        for v in re.findall(r"\"#?([0-9A-Fa-f]{6})\"", x):
            found.append((v.upper(), False))
    probs = set()
    for h, is_text in found:
        if h and h not in pal["allowed"]:
            probs.add(f"{h} is not an Ulta template colour")
        elif h and is_text and h in pal["status"]:
            probs.add(f"text in status colour {h} - status colours mark, never colour text")
    return sorted(probs)


def audit(path):
    p = Path(path)
    pal = palette()
    ext = p.suffix.lower()
    if ext in (".pptx", ".potx"):
        return audit_pptx(p, pal)
    if ext in (".docx", ".dotx"):
        return audit_docx(p, pal)
    if ext in (".xlsx", ".xlsm"):
        return audit_xlsx(p, pal)
    if ext in (".svg", ".html", ".htm", ".drawio", ".json", ".css"):
        return audit_text(p, pal)
    return []


def gate(files, conform=True):
    """For tools that write pages and drawings: map stray colours to the template's (ulta_conform), then return one
    'FAIL ...' line per colour still off the template - an empty list means zero deviation."""
    files = [str(f) for f in files if f and Path(str(f)).exists()]
    if conform:
        import subprocess
        text = [f for f in files if Path(f).suffix.lower() in (".svg", ".html", ".htm", ".drawio", ".pptx")]
        enterprise = [f for f in text if Path(f).suffix.lower() != ".pptx" and is_enterprise(Path(f).read_text(errors="ignore"))]
        text = [f for f in text if f not in enterprise]           # a standard diagram keeps its standard's colours
        if text:
            subprocess.run([sys.executable, str(TOOLS / "ulta_conform.py"), *text, "--keep-sizes", "--no-rebrand"],
                           capture_output=True, text=True)
    return [f"FAIL colour in {Path(f).name}: {x}" for f in files for x in summary(f, 4)]


def summary(path, limit=6):
    probs = audit(path)
    return probs[:limit] + ([f"... and {len(probs) - limit} more"] if len(probs) > limit else [])


def main():
    bad = 0
    for f in sys.argv[1:]:
        probs = audit(f)
        print(("PASS  " if not probs else "FAIL  ") + f"brand colours (zero deviation from the Ulta template): {f}")
        for line in probs[:30]:
            print("      - " + line)
        if len(probs) > 30:
            print(f"      ... and {len(probs) - 30} more")
        bad += bool(probs)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
