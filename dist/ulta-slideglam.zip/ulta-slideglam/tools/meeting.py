"""Meeting notes or a transcript -> decisions & actions one-pager + action-tracker spreadsheet + short e-mail/Teams recap.

Step 1 (cheap: no need to read the whole transcript):
    python tools/meeting.py prep transcript.vtt|.txt|.docx --out /mnt/data/out/mtg
      -> mtg-clean.txt   speaker: text, timestamps and filler removed, consecutive lines merged (much shorter)
      -> mtg-cues.txt    only the lines that sound like a decision, action, date, risk or question (read this one)
Step 2: write meeting.json from the cues (ChatGPT), then:
    python tools/meeting.py build meeting.json --out /mnt/data/out/Team-Sync [--classification internal]
meeting.json:
  {"title": "Portal launch sync", "date": "2026-10-10", "attendees": ["Ana", "Raj"], "purpose": "Go/no-go prep",
   "decisions": ["Launch on 11/3 with the pilot group"],
   "actions": [{"action": "Book load test", "owner": "Raj", "due": "2026-10-15"}],
   "risks": ["Vendor SSO fix not yet scheduled"], "open_questions": ["Who signs off the runbook?"],
   "next_meeting": "2026-10-17"}
Outputs: <out>.pptx (a 2-3 slide recap on the Ulta template: the decisions as tiles under a decision headline, the
actions as a table, risks and open questions as tiles; date, attendees and purpose in the notes - nothing invented),
<out>-actions.xlsx (status drop-down, overdue highlighting, filters; append next week's actions to the same file with
--tracker), <out>-recap.txt (paste into e-mail or Teams).
"""
import argparse, datetime, json, re, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))

FILLER = re.compile(r"\b(um+|uh+|erm|you know|i mean|kind of|sort of|like,)\s*", re.I)
CUE = re.compile(r"(?i)\b(action|todo|to-do|follow[- ]?up|will (?:send|share|book|set up|schedule|check|own|draft|update|review)|"
                 r"i'll|we'll|can you|could you|by (?:mon|tue|wed|thu|fri|eod|end of|next|tomorrow|\d)|due|deadline|"
                 r"decid|agreed|decision|approve|sign[- ]?off|go with|let's go|risk|blocker|blocked|concern|issue|"
                 r"question|not sure|who (?:owns|will)|next (?:step|meeting))")


def read_text(path):
    p = Path(path)
    if p.suffix.lower() == ".docx":
        from docx import Document
        return "\n".join(par.text for par in Document(str(p)).paragraphs)
    return p.read_text(encoding="utf-8-sig", errors="replace")


def clean(raw):
    """[(speaker, text)] from .vtt / Teams / Zoom / plain notes."""
    lines, speaker = [], ""
    for ln in raw.splitlines():
        s = ln.strip()
        if not s or s == "WEBVTT" or re.match(r"^\d+$", s) or re.match(r"^[\d:.,]+\s*-->\s*[\d:.,]+", s) or s.startswith("NOTE"):
            continue
        s = re.sub(r"^\[?\d{1,2}:\d{2}(:\d{2})?(\.\d+)?\]?\s*", "", s)
        m = re.match(r"^<v\s+([^>]+)>(.*?)(</v>)?$", s)
        if m:
            speaker, s = m.group(1).strip(), m.group(2)
        else:
            m = re.match(r"^([A-Z][\w.'-]+(?: [A-Z][\w.'-]+){0,2})\s*[:：]\s+(.*)$", s)
            if m:
                speaker, s = m.group(1), m.group(2)
        s = FILLER.sub("", re.sub(r"<[^>]+>", "", s)).strip()
        if not s:
            continue
        if lines and lines[-1][0] == speaker:
            lines[-1] = (speaker, lines[-1][1] + " " + s)
        else:
            lines.append((speaker, s))
    return lines


def prep(path, out):
    lines = clean(read_text(path))
    out = Path(out); out.parent.mkdir(parents=True, exist_ok=True)
    txt = "\n".join(f"{sp + ': ' if sp else ''}{t}" for sp, t in lines)
    Path(f"{out}-clean.txt").write_text(txt)
    cues = []
    for sp, t in lines:
        for sent in re.split(r"(?<=[.!?])\s+", t):
            if CUE.search(sent):
                cues.append(f"{sp + ': ' if sp else ''}{sent.strip()}")
    Path(f"{out}-cues.txt").write_text("\n".join(cues))
    raw = len(read_text(path))
    print(f"PREP {len(lines)} turns, {len(cues)} cue lines | clean {len(txt):,} chars (from {raw:,}) | "
          f"read {out}-cues.txt ({sum(len(c) for c in cues):,} chars), open {out}-clean.txt only to check a cue")


def date_of(s):
    s = str(s or "").strip()
    for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%m/%d", "%d %b %Y", "%b %d, %Y"):
        try:
            d = datetime.datetime.strptime(s, fmt).date()
            return d.replace(year=datetime.date.today().year) if fmt == "%m/%d" else d
        except ValueError:
            continue
    return None


def short_date(s):
    d = date_of(s)
    return d.strftime("%m/%d") if d else (s or "—")


def tracker(m, path, append=None):
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.formatting.rule import FormulaRule
    import brand as B
    b = B.current()
    if append and Path(append).exists():
        wb = load_workbook(append); ws = wb["Actions"]
    else:
        wb = Workbook(); ws = wb.active; ws.title = "Actions"
        ws.append(["#", "Action", "Owner", "Due", "Status", "Raised in", "Notes"])
        for c in ws[1]:
            c.fill = PatternFill("solid", fgColor=b.ui("dark_accent")); c.font = Font(bold=True, color="FFFFFF")
        for col, w in zip("ABCDEFG", (5, 60, 18, 12, 14, 34, 40)):
            ws.column_dimensions[col].width = w
        ws.freeze_panes = "A2"
    start = ws.max_row
    for i, a_ in enumerate(m.get("actions") or [], start):
        d = date_of(a_.get("due"))
        ws.append([i, a_.get("action"), a_.get("owner") or "—", d if d else (a_.get("due") or ""), a_.get("status") or "Open",
                   f"{m.get('title', 'Meeting')} {m.get('date', '')}".strip(), a_.get("notes") or ""])
        ws.cell(ws.max_row, 4).number_format = "mm/dd/yyyy"
        for c in ws[ws.max_row]:
            c.alignment = Alignment(wrap_text=True, vertical="top")
    dv = DataValidation(type="list", formula1='"Open,In progress,Done,Blocked"', allow_blank=True)
    ws.add_data_validation(dv); dv.add(f"E2:E{max(ws.max_row, 2) + 200}")
    rng = f"A2:G{ws.max_row + 200}"
    ws.conditional_formatting.add(rng, FormulaRule(formula=['AND($E2<>"Done",ISNUMBER($D2),$D2<TODAY())'],
                                                   fill=PatternFill("solid", fgColor="FFE8EE")))
    ws.conditional_formatting.add(rng, FormulaRule(formula=['$E2="Done"'], font=Font(color="8A8C8F", strike=True)))
    ws.auto_filter.ref = f"A1:G{ws.max_row}"
    wb.save(path)


def onepager_md(m):
    acts = m.get("actions") or []
    md = [f"# {m.get('title', 'Meeting')} — Decisions & Actions", f"Chair: {m.get('owner') or (m.get('attendees') or ['—'])[0]}",
          f"Meeting date: {short_date(m.get('date'))}", f"Status: {'Decided' if m.get('decisions') else 'Open'}", ""]
    md += ["## Context", m.get("purpose") or f"Attendees: {', '.join(m.get('attendees') or []) or '—'}", ""]
    if m.get("decisions"):
        md += ["## Recommendation", "; ".join(m["decisions"][:3]), ""]
    if acts:
        md += ["## Next steps", *[f"{i}. {a_.get('owner') or '—'}: {a_.get('action')} (by {short_date(a_.get('due'))})"
                                  for i, a_ in enumerate(acts[:6], 1)], ""]
    if m.get("risks") or m.get("open_questions"):
        md += ["## Impact", *[f"- Risk: {r}" for r in (m.get("risks") or [])[:3]],
               *[f"- Open question: {q}" for q in (m.get("open_questions") or [])[:3]], ""]
    return "\n".join(md)


def recap(m):
    acts = m.get("actions") or []
    out = [f"Subject: {m.get('title', 'Meeting')} - decisions and actions ({m.get('date', '')})", "",
           f"Thanks all. Summary of {m.get('title', 'the meeting')}:"]
    if m.get("decisions"):
        out += ["", "Decisions:", *[f"- {d}" for d in m["decisions"]]]
    if acts:
        out += ["", "Actions:", *[f"- {a_.get('owner') or 'Unassigned'}: {a_.get('action')} - by {short_date(a_.get('due'))}" for a_ in acts]]
    if m.get("risks") or m.get("open_questions"):
        out += ["", "Open:", *[f"- {x}" for x in (m.get("risks") or []) + (m.get("open_questions") or [])]]
    if m.get("next_meeting"):
        out += ["", f"Next meeting: {short_date(m['next_meeting'])}"]
    out += ["", "The action tracker is attached; update the Status column as you go."]
    return "\n".join(out)


def storyboard(m):
    """The recap deck: only what the meeting said, every headline a takeaway that fits one line."""
    import typeset as TS
    fit = lambda c, fb: next((x for x in c if x and TS.fits_headline(x)), fb)
    acts = [a_ for a_ in (m.get("actions") or []) if a_.get("action")]
    dec = [str(d).strip() for d in (m.get("decisions") or []) if str(d).strip()]
    notes = "; ".join(x for x in (f"{m.get('title', 'Meeting')} on {short_date(m.get('date'))}" if m.get("date") else m.get("title"),
                                  f"Purpose: {m['purpose']}" if m.get("purpose") else "",
                                  f"Attendees: {', '.join(m.get('attendees') or [])}" if m.get("attendees") else "") if x)
    slides = []
    if dec:
        tiles = [f"Decision: {d}" for d in dec[:4]]
        if m.get("next_meeting"):
            tiles.append(f"Next meeting: {short_date(m['next_meeting'])}")
        if len(tiles) < 2 and m.get("attendees"):
            tiles.append(f"Attendees: {', '.join(m['attendees'][:6])}")
        if len(tiles) < 2 and m.get("purpose"):
            tiles.append(f"Purpose: {m['purpose']}")
        d0 = dec[0].rstrip(".")
        slides.append({"bullets": tiles, "numbered": False, "notes": notes,
                       "headline": fit([f"Decided: {d0[0].lower() + d0[1:]}", d0, f"{len(dec)} decision{'s' * (len(dec) > 1)} made"],
                                       "Decisions")})
    if acts:
        dues = sorted(str(a_.get("due") or "") for a_ in acts if a_.get("due"))
        last = short_date(dues[-1]) if dues else ""
        rows = [["Action", "Owner", "Due"]] + [[str(a_.get("action")), str(a_.get("owner") or "Unassigned"),
                                                short_date(a_.get("due")) if a_.get("due") else "Not set"] for a_ in acts[:12]]
        slides.append({"table": {"rows": rows}, "notes": notes,
                       "headline": fit([f"{len(acts)} action{'s' * (len(acts) > 1)}, all due by {last}" if last and all(a_.get("due") for a_ in acts) else "",
                                        f"{len(acts)} action{'s' * (len(acts) > 1)} agreed with owners"], "Actions")})
    opens = [f"Risk: {r}" for r in (m.get("risks") or [])[:3]] + [f"Open question: {q}" for q in (m.get("open_questions") or [])[:3]]
    if opens:
        nr, nq = len(m.get("risks") or []), len(m.get("open_questions") or [])
        parts = [f"{nr} risk{'s' * (nr != 1)}" if nr else "", f"{nq} open question{'s' * (nq != 1)}" if nq else ""]
        what = " and ".join(x for x in parts if x)
        if len(opens) == 1:
            opens.append(f"Next meeting: {short_date(m['next_meeting'])}" if m.get("next_meeting") else "Owner: to be agreed")
        slides.append({"bullets": opens, "numbered": False, "notes": notes,
                       "headline": fit([f"{what[0].upper() + what[1:]} to close", what[0].upper() + what[1:]], "Open items")})
    return {"slides": slides, "owner": m.get("owner")}


def build(spec_path, out, classification=None, append=None):
    m = json.loads(Path(spec_path).read_text())
    out = Path(out); out.parent.mkdir(parents=True, exist_ok=True)
    story = storyboard(m)
    story["classification"] = classification
    sp = Path(f"{out}-storyboard.json"); sp.write_text(json.dumps(story, indent=1))
    r = subprocess.run([sys.executable, str(TOOLS / "build_deck.py"), "build", str(sp), "--out", str(out.with_suffix(".pptx")),
                        "--no-tokens"], capture_output=True, text=True)
    deck = next((l for l in r.stdout.splitlines() if l.startswith(("READY", "NEEDS", "DRAFT"))), "")
    fails = [l.strip() for l in r.stdout.splitlines() if l.strip().startswith("FAIL")]
    xlsx = Path(f"{out}-actions.xlsx"); tracker(m, xlsx, append)
    rec = Path(f"{out}-recap.txt"); rec.write_text(recap(m))
    import compliance, brand_colours
    sens = compliance.scan([str(out.with_suffix(".pptx")), str(rec)])
    blk = [x for x in sens if x["severity"] == "BLOCK"]
    off = brand_colours.summary(xlsx, 3)                    # the tracker too: template colours only
    res = "READY" if deck.startswith("READY") and not blk and not off else "NEEDS CORRECTION"
    print(f"MEETING {res} | {len(m.get('decisions') or [])} decisions, {len(m.get('actions') or [])} actions | "
          f"{out.with_suffix('.pptx')} | {xlsx} | {rec}")
    for x in fails[:6] + [f"FAIL colour in the tracker: {o}" for o in off]:
        print("  " + x)
    for x in sens:
        print(f"  {x['severity']} {x['where']}: {x['kind']} '{x['match']}'")
    missing = [a_.get("action") for a_ in m.get("actions") or [] if not a_.get("owner") or not a_.get("due")]
    if missing:
        print(f"  NOTE {len(missing)} action(s) without an owner or due date: ask the user: {missing[:3]}")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("prep"); p.add_argument("transcript"); p.add_argument("--out", required=True)
    b = sub.add_parser("build"); b.add_argument("spec"); b.add_argument("--out", required=True)
    b.add_argument("--classification"); b.add_argument("--tracker", help="existing actions .xlsx to append to")
    a = ap.parse_args()
    if a.cmd == "prep":
        prep(a.transcript, a.out)
    else:
        build(a.spec, a.out, a.classification, a.tracker)


if __name__ == "__main__":
    main()
