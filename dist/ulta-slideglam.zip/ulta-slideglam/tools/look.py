"""How the deck LOOKS once rendered (LibreOffice PDF): text that overlaps other text, text that runs off the slide,
and slides too dense to read comfortably. Shape geometry alone misses these - a box can be in the right place while
its text spills over the box below it.

    python tools/look.py deck.pdf            (validate_deck.py runs it on the PDF it already renders)
Returns FAIL lines (overlap, off-slide) and REVIEW lines (dense slides). Positions come from substitute fonts, so
small overlaps (under a third of a line) are ignored.
"""
import re, subprocess, sys
from html import unescape
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

WORDS_DENSE = 110          # words on one slide before it reads as a document
OVERLAP = 0.33             # share of the smaller line's area that must be covered to count
FOOTER = re.compile(r"(?i)ulta beauty|proprietary|confidential")
_FOOT = []


def footer_like(t):
    """The layout's footer line, or a piece of it: 'Ulta Beauty | Proprietary & Confidential', 'Internal Use Only',
    'Only' (a classification footer wraps differently in the layout and on the slide)."""
    if FOOTER.search(t):
        return True
    if not _FOOT:
        try:
            import compliance
            phrases = list(compliance.FOOTER_PHRASES)
        except Exception:
            phrases = ["Public", "Internal Use Only", "Proprietary & Confidential", "Restricted - Do Not Forward"]
        _FOOT.append({w for ph in phrases + ["Ulta Beauty"] for w in re.findall(r"[a-z]+", ph.lower())})
    ws = re.findall(r"[a-z]+", t.lower())
    return bool(ws) and all(w in _FOOT[0] for w in ws)


def lines(pdf):
    """[(page, w, h, [(x0, y0, x1, y1, text, block_id)])] from pdftotext -bbox-layout."""
    out = subprocess.run(["pdftotext", "-bbox-layout", str(pdf), "-"], capture_output=True, text=True).stdout
    pages = []
    for pm in re.finditer(r'<page width="([\d.]+)" height="([\d.]+)">(.*?)</page>', out, re.S):
        w, h, body = float(pm.group(1)), float(pm.group(2)), pm.group(3)
        ls = []
        for bi, bm in enumerate(re.finditer(r"<block[^>]*>(.*?)</block>", body, re.S)):
            for lm in re.finditer(r'<line xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</line>', bm.group(1), re.S):
                txt = " ".join(unescape(t) for t in re.findall(r"<word[^>]*>(.*?)</word>", lm.group(5)))
                if txt.strip():
                    ls.append((*map(float, lm.groups()[:4]), txt, bi))
        pages.append((len(pages) + 1, w, h, ls))
    return pages


def check(pdf):
    return check_pages(lines(pdf))


def check_pages(pages):
    """The same checks on lines from any renderer: [(page, w, h, [(x0, y0, x1, y1, text, block)])] - LibreOffice's PDF (above) or the
    Studio's own drawing of each slide (v6.33, slide_svg.deck_pictures: no LibreOffice)."""
    fails, reviews = [], []
    for n, w, h, ls in pages:
        words = sum(len(l[4].split()) for l in ls)
        if words > WORDS_DENSE:
            reviews.append(f"slide {n}: {words} words - dense; split it or move detail to the notes")
        for x0, y0, x1, y1, t, _ in ls:
            if x1 > w + 2 or y1 > h + 2 or x0 < -2 or y0 < -2:
                fails.append(f"slide {n}: '{t[:30]}' runs off the slide - shorten it or use a roomier layout")
        seen = set()
        for i, a in enumerate(ls):
            for b in ls[i + 1:]:
                ix = min(a[2], b[2]) - max(a[0], b[0])
                iy = min(a[3], b[3]) - max(a[1], b[1])
                if ix <= 0 or iy <= 0:
                    continue
                ha, hb = a[3] - a[1], b[3] - b[1]
                if (len(a[4].strip()) <= 3 and ha >= 2.5 * hb) or (len(b[4].strip()) <= 3 and hb >= 2.5 * ha):
                    continue                           # a big decorative numeral behind a title (template divider)
                if footer_like(a[4]) and footer_like(b[4]):
                    continue                           # the layout's footer under a full-bleed photo and the slide's own copy on top
                small = min((a[2] - a[0]) * ha, (b[2] - b[0]) * hb) or 1
                if ix * iy / small >= OVERLAP and (a[4], b[4]) not in seen:
                    seen.add((a[4], b[4]))
                    fails.append(f"slide {n}: text overlaps - '{a[4][:28]}' and '{b[4][:28]}' sit on top of each other")
    return fails, reviews


if __name__ == "__main__":
    f, r = check(sys.argv[1])
    for x in f: print("FAIL  " + x)
    for x in r: print("REVIEW " + x)
    print(f"look: {len(f)} fail, {len(r)} review")
