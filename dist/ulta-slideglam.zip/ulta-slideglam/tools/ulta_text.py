"""Put text into an Ulta template shape or table cell WITHOUT losing the template formatting.

Always use this instead of text_frame.text = ..., text_frame.clear() or add_run()/add_paragraph():
those create runs with no formatting, which fall back to Calibri / table-style colours
(white-on-cream labels, oversized bulleted cells).

    import sys; sys.path.insert(0, f"{SKILL_DIR}/tools")
    from ulta_text import set_text
    set_text(shape.text_frame, "PLANNING\\nScope and budget")       # one line per paragraph
    set_text(table.cell(0, 2).text_frame, "PROTECT")
    set_text(shape.text_frame, "")                                   # blank a slot, keep its formatting

The first line copies the template's lead paragraph (font, size, colour, bold); later lines copy its body paragraph
in regular weight (a card: bold sub-headline, plain sentence). Extra template paragraphs are removed.
Leading spaces a template label carries to clear an icon beside it ("        Headline", "  Recap") stay in front of
the new text, line by line, so the icon never sits on the words.
"""
import copy, re

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"


def _style(p, fallback=None):
    """(pPr, rPr, endParaRPr) of a template paragraph. A paragraph with no visible run (an empty cell) takes
    `fallback` (pPr, rPr) when one is given, else its end-of-paragraph size and font - what PowerPoint does when you
    type there."""
    run = next((r for r in p.findall(A + "r") if (r.findtext(A + "t") or "").strip()), None)
    rpr = run.find(A + "rPr") if run is not None else None
    if run is None:
        if fallback is not None:
            return (fallback[0] if fallback[0] is not None else p.find(A + "pPr"), fallback[1], p.find(A + "endParaRPr"))
        else:
            end = p.find(A + "endParaRPr")
            if end is not None:
                rpr = etree.Element(A + "rPr", {k: v for k, v in end.attrib.items() if k in ("lang", "sz", "b", "i", "kern")})
                rpr.extend(copy.deepcopy(c) for c in end if etree.QName(c).localname in ("latin", "ea", "cs"))
    return (p.find(A + "pPr"), rpr, p.find(A + "endParaRPr"))


def _template_parts(txBody, fallback=None):
    """The frame's paragraphs plus two styles: the lead (first paragraph with text) and the body (the next paragraph
    with text, e.g. 'Sub-headline' then 'Lorem ipsum ...' in a card, 'XX%' then 'Text here' under a big number).
    A frame with one styled paragraph uses it for both."""
    paras = txBody.findall(A + "p")
    if not paras:
        p = etree.SubElement(txBody, A + "p")
        paras = [p]
    texted = [p for p in paras if any((r.findtext(A + "t") or "").strip() for r in p.findall(A + "r"))]
    lead = _style(texted[0] if texted else paras[0], fallback)
    body = _style(texted[1]) if len(texted) > 1 else lead
    blank = next((p for p in paras[1:] if not p.findall(A + "r")), None)
    return paras, lead, body, (_style(blank) if blank is not None else None)


BODY_PT = 1600          # body lines at or below 16 pt are set in regular weight: bold is for the lead line only



def _unbold(rpr):
    sz = rpr.get("sz")
    if rpr.get("b") == "1" and (sz is None or int(sz) <= BODY_PT):
        rpr.set("b", "0")
    return rpr


def _pads(paras):
    """Per paragraph with text: the run of 2+ leading spaces that keeps it clear of an icon ("" when none)."""
    out = []
    for p in paras:
        t = "".join(x.text or "" for x in p.iter(A + "t"))
        if t.strip():
            m = re.match(r"[ \u00a0]{2,}", t)
            out.append(m.group(0) if m else "")
    return out


def set_text(text_frame, text, fallback=None):
    """One paragraph per line. The first line takes the template's lead style; later lines take its body style (in
    regular weight), blank lines its spacer paragraph - so a card reads 'bold sub-headline, plain sentence' instead of
    every line in the sub-headline's bold colour."""
    txBody = text_frame._txBody
    paras, lead, body, spacer = _template_parts(txBody, fallback)
    pads = _pads(paras)
    anchor = paras[0].getprevious()
    for p in paras:
        txBody.remove(p)
    lines = text.split("\n") if text else [""]
    if any(pads):
        lines = [(pads[min(k, len(pads) - 1)] + ln.lstrip(" \u00a0")) if ln.strip() else ln for k, ln in enumerate(lines)]
    lead_ppr = lead[0]                                  # a bulleted list: every point the same weight (no bold first point)
    bulleted = lead_ppr is not None and (lead_ppr.find(A + "buChar") is not None or lead_ppr.find(A + "buAutoNum") is not None)
    insert_at = list(txBody).index(anchor) + 1 if anchor is not None else len(txBody)
    two_styles = body is not lead
    for k, line in enumerate(lines):
        if k == 0:
            ppr, rpr, end = lead
        elif not line.strip() and spacer is not None:
            ppr, rpr, end = spacer
        else:
            ppr, rpr, end = body
        p = etree.Element(A + "p")
        if ppr is not None:
            p.append(copy.deepcopy(ppr))
        if line:
            r = etree.SubElement(p, A + "r")
            if rpr is not None:
                rp = copy.deepcopy(rpr)
                r.append(_unbold(rp) if (k > 0 or bulleted) and (two_styles or len(lines) > 1) else rp)
            t = etree.SubElement(r, A + "t")
            t.text = line
        if end is not None:
            p.append(copy.deepcopy(end))
        txBody.insert(insert_at + k, p)
    return text_frame


def cut_problems(log, where=""):
    """FAIL lines for text the drawing engines had to cut with '…' (they write 'CUT<TAB>room<TAB>text' to stderr).
    Cut text is never delivered: the fix is a shorter label, not a smaller font."""
    out, seen = [], set()
    for line in (log or "").splitlines():
        if line.startswith("CUT\t"):
            _, room, text = (line.split("\t", 2) + ["", ""])[:3]
            key = text.rstrip("…")[:50]
            if key not in seen:
                seen.add(key)
                out.append(f"FAIL {where}text cut off: '{text[:70]}' does not fit (room for about {room} characters) - "
                           "shorten it to a few words and rebuild")
    return out
