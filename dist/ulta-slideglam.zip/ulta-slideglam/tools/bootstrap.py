"""Ulta Presentation Central - integrity gate.

Run once per conversation, before any deck work:
    python <this skill dir>/tools/bootstrap.py

Verifies: template binary hash, every skill-manifest resource hash, the hash of every shipped file - code, page
templates, layouts, pictures, rules (integrity.json; SKILL.md, agents/*.yaml, brand.json and credits.json, which an admin
or the platform sets, aside) - Python deps, fonts. An added file stops the skill only when Python could import it in
place of the skill's own code; any other added file is reported and ignored.
Exit 0 = ready; exit 1 = a hard gate failed (do NOT build a deck).
"""
import os, sys
_HERE = os.path.dirname(os.path.realpath(__file__))
if __name__ == "__main__":      # run as a script: the standard library is found before any file added to this folder
    sys.path[:] = [p for p in sys.path if os.path.realpath(p or os.curdir) != _HERE]
import ast, contextlib, hashlib, importlib, importlib.util, io, json, re, shutil, subprocess, zipfile  # noqa: E401
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILLS = ROOT / "modules"
TEMPLATE_SHA = "46e7c3bda4bf611cb7d1903c7c3d7b1ccffc6ddd73246919b5559894110a2c95"
KIT = ROOT / "modules" / "ultabranddeliverables" / "scripts"
SEARCH = [KIT / "kit" / "templates"]   # bundled template only

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def find_template():
    if BRAND.name != "ulta":
        t = BRAND.template
        return t if t.exists() and sha(t) == BRAND.sha else None
    for base in SEARCH:
        for p in base.rglob("*.pptx"):
            if p.stat().st_size > 1_000_000 and sha(p) == TEMPLATE_SHA:
                return p
    return None

RECORD_ONLY = {"example_outputs", "outputs"}  # hashes of past generated outputs, not bundled files

def manifest_entries(obj, key=""):
    if key in RECORD_ONLY: return
    if isinstance(obj, dict):
        if "path" in obj and "sha256" in obj:
            yield obj; return
        for k, v in obj.items(): yield from manifest_entries(v, k)
    elif isinstance(obj, list):
        for v in obj: yield from manifest_entries(v, key)

CODE = (".py", ".pyc", ".so", ".pyd", ".js", ".mjs", ".html", ".htm", ".sh")   # files that can run
IMPORTABLE = (".py", ".pyc", ".so", ".pyd")
ADMIN = re.compile(r"^(SKILL\.md|credits\.json|agents/[^/]+\.ya?ml|brands/[^/]+/brand\.json)$")   # set by an admin or the platform


def import_names(root, files):
    """Every module name the shipped code could import: the modules it imports, its own and the standard library's."""
    names = set(getattr(sys, "stdlib_module_names", ())) | {"sitecustomize", "usercustomize"}
    for rel in files:
        if rel.endswith(".py"):
            names.add(Path(rel).stem)
            try:
                tree = ast.parse((root / rel).read_text(encoding="utf-8"))
            except (OSError, SyntaxError, ValueError):
                continue
            for n in ast.walk(tree):
                if isinstance(n, ast.Import):
                    names |= {a.name.split(".")[0] for a in n.names}
                elif isinstance(n, ast.ImportFrom) and n.module and not n.level:
                    names.add(n.module.split(".")[0])
    return names


def integrity_report(root=None):
    """(problems, notes) against integrity.json. Problems stop the skill: a shipped file that changed or is missing,
    or an added file Python could import in place of one of the skill's modules (it has the name of a module the code
    imports - its own, a library's or the standard library's). Notes do not: other added files, which the skill never
    runs (a reviewer's test script, a file left from an earlier install). Files an admin or the platform sets
    (SKILL.md, agents/*.yaml, brand.json, credits.json) are not compared."""
    root = Path(root or ROOT)
    integ = root / "integrity.json"
    if not integ.exists():
        return [], []
    want = {f: h for f, h in json.loads(integ.read_text())["files"].items() if not ADMIN.match(f)}
    bad = sorted(f for f, h in want.items() if not (root / f).is_file() or sha(root / f) != h)
    extra = sorted(r for r in (f.relative_to(root).as_posix() for f in root.rglob("*") if f.suffix.lower() in CODE
                               and f.is_file() and "__pycache__" not in f.parts) if r not in want and not ADMIN.match(r))
    if not extra:
        return bad, []
    names = import_names(root, want)
    module = lambda r: Path(r).parent.name if Path(r).name == "__init__.py" else Path(r).name.split(".")[0]
    shadow = [r for r in extra if Path(r).suffix.lower() in IMPORTABLE and module(r) in names]
    return bad + shadow, [r for r in extra if r not in shadow]


_RUN = []                       # this run's report: every shipped file is read and hashed once a run, not once a step


def run_report():
    if not _RUN:
        _RUN.append(integrity_report())
    return _RUN[0]


if __name__ == "__main__":      # the verdict comes before any of the skill's own modules is imported
    _bad = run_report()[0]
    if _bad:
        print("FAIL  the skill's files differ from its package (changed, missing, or added under a module name its code "
              "imports): " + ", ".join(_bad[:6]) + " - reinstall the skill from its package zip")
        print("NOT READY - do not build; report the FAIL lines to the user")
        sys.exit(1)
sys.path.insert(0, _HERE)
import brand as _B   # noqa: E402
BRAND = _B.current()
REQUIRED_FONTS = (BRAND.get("fonts") or {}).get("installed_check") or []


def cache_key():
    h = hashlib.sha256(BRAND.name.encode())
    for f in sorted((ROOT / "tools").glob("*.py")) + [BRAND.template]:
        st = f.stat(); h.update(f"{f.name}{st.st_size}{int(st.st_mtime)}".encode())
    return h.hexdigest()


def main():
    import contextlib, io
    if "--dashboard" in sys.argv:
        dashboard_main()
        return
    verbose = "--verbose" in sys.argv or "--full" in sys.argv
    out = Path("/mnt/data/out") if Path("/mnt/data").exists() else Path.cwd() / "out"
    out.mkdir(parents=True, exist_ok=True)
    marker = out / ".bootstrap_ok"
    if not verbose and marker.exists() and marker.read_text() == cache_key():
        bad, notes = run_report()                  # every run: the files themselves, not their dates and sizes
        if bad:
            print("FAIL  package files changed since the skill was installed: " + ", ".join(bad[:6]) +
                  " - reinstall the skill from its package zip"); sys.exit(1)
        print(f"READY (checked earlier in this chat; files verified) | brand {BRAND.name} | output folder {out}"
              + (f" | {len(notes)} added file(s) ignored, never run: {', '.join(notes[:3])}" if notes else ""))
        return
    buf = io.StringIO()
    code = 0
    with contextlib.redirect_stdout(buf):
        try:
            _main()
        except SystemExit as e:
            code = e.code or 0
    log = buf.getvalue()
    if verbose or code:
        print(log)
    else:
        fonts = re.findall(r"WARN\s+font '([^']+)'", log)
        other = [l.strip()[6:170] for l in log.splitlines() if l.startswith("WARN") and "font '" not in l]
        print(f"READY | brand {BRAND.name} | {log.count('PASS')} checks ok | output {out}"
              + (f" | preview-only fonts missing: {', '.join(fonts)}" if fonts else "")
              + (" | " + "; ".join(other) if other else ""))
        marker.write_text(cache_key())
    sys.exit(code)


def _main():
    hard_fail = False
    out = Path("/mnt/data/out") if Path("/mnt/data").exists() else Path.cwd() / "out"
    out.mkdir(parents=True, exist_ok=True)
    print(f"Output folder: {out}\n")
    print(f"== Brand: {BRAND.name} ({BRAND.get('label', '')}) - switch with tools/brand.py use <name> ==")
    print("== Template ==")
    t = find_template()
    if t:
        n = sum(1 for x in zipfile.ZipFile(t).namelist()
                if x.startswith("ppt/slides/slide") and x.endswith(".xml"))
        print(f"PASS  {t}  sha256 ok  slides={n}")
        if n != BRAND.get("slides", n): print(f"FAIL  expected {BRAND['slides']} slides"); hard_fail = True
        print(f"      use this path as reference.pptx in every validator command")
    else:
        print(f"FAIL  template for brand '{BRAND.name}' with pinned SHA-256 not found ({BRAND.template})")
        hard_fail = True

    print("\n== Brand kit (ulta.py check) ==")
    p = subprocess.run([sys.executable, str(KIT / "ulta.py"), "check"], capture_output=True, text=True)
    for line in (p.stdout + p.stderr).strip().splitlines(): print("      " + line)
    print(("PASS" if p.returncode == 0 else "FAIL") + "  brand kit ready")
    diag = KIT / "kit" / "diagram" / "slide_diagram.py"
    if diag.exists():
        print("PASS  diagram engine: 17 architecture styles + 8 point graphics (ulta.py diagram)")
    else:
        print("WARN  smart diagram engine MISSING (scripts/kit/diagram/slide_diagram.py) -> the kit silently DROPS "
              "diagram/architecture sections. Do not use ulta.py for diagrams; tell the user (SKILL.md, Other modules).")
    if p.returncode: hard_fail = True

    print("\n== Skill resources ==")
    for skill in sorted(p for p in SKILLS.iterdir() if p.is_dir()):
        bad, ok = [], 0
        for mf in ("manifest.json", "metadata.json"):
            m = skill / mf
            if not m.exists(): continue
            for e in manifest_entries(json.loads(m.read_text())):
                f = skill / ("MODULE.md" if e["path"] == "SKILL.md" else e["path"])
                if not f.exists() or sha(f) != e["sha256"] or \
                   ("bytes" in e and f.stat().st_size != e["bytes"]):
                    bad.append(e["path"])
                else: ok += 1
        bad = sorted(set(bad))
        status = "PASS" if not bad else "FAIL"
        if bad: hard_fail = True
        print(f"{status}  {skill.name:38} verified={ok}" + (f" bad={bad}" if bad else ""))
        if not (skill / "MODULE.md").exists():
            print(f"FAIL  {skill.name} missing MODULE.md"); hard_fail = True
    integ = ROOT / "integrity.json"                     # written by the packager: SHA-256 of every file shipped
    if integ.exists():
        want = [f for f in json.loads(integ.read_text())["files"] if not ADMIN.match(f)]
        bad, notes = run_report()
        changed, impostor = [f for f in bad if f in want], [f for f in bad if f not in want]
        print(("FAIL" if bad else "PASS") + f"  files match the package: {len(want) - len(changed)}/{len(want)}"
              + (f" - changed or missing: {changed[:5]}" if changed else "")
              + (f" - added under a module name the skill imports (could run instead of its code): {impostor[:5]}" if impostor else ""))
        if notes:
            print(f"WARN  {len(notes)} added file(s) ignored, never run by the skill: {', '.join(notes[:3])}")
        if bad: hard_fail = True
    else:
        print("WARN  integrity.json absent - a development copy, not a packaged skill")
    try:
        import full_template
        ref = full_template.combined(BRAND)
        print(f"PASS  40-layout template: {len(full_template.collection()['slides'])} layouts, the deck reference "
              f"holds 53 sources ({ref.name})" if BRAND.get("layouts") else "PASS  brand without the 40-layout collection")
    except SystemExit as e:
        print(f"FAIL  {e}"); hard_fail = True

    print("\n== Python deps ==")
    core = ("lxml", "pptx", "PIL")                      # nothing builds without these
    for mods, use in ((("lxml",), "every file"), (("pptx",), "decks"), (("PIL",), "pictures"), (("docx",), "Word files"),
                      (("openpyxl",), "Excel input"), (("numpy",), "screenshot guides"), (("pypdf", "PyPDF2"), "PDF input"),
                      (("fontTools",), "importing a brand's fonts")):
        ok = next((m for m in mods if importlib.util.find_spec(m)), None)
        if ok: print(f"PASS  {ok}")
        else:
            print(f"{'FAIL' if mods[0] in core else 'WARN'}  {' / '.join(mods)} not importable - needed for {use}")
            if mods[0] in core: hard_fail = True

    print("\n== Renderer / fonts ==")
    print(("PASS" if shutil.which("soffice") or shutil.which("libreoffice") else "WARN") +
          "  LibreOffice " + ("available" if shutil.which("soffice") or shutil.which("libreoffice")
                              else "missing -> render review UNVERIFIED"))
    try:                                              # bundled Playfair Display / Inter (OFL), seen through lo.font_env()
        import lo; env = lo.font_env()
    except Exception:
        env = None
    try: fl = subprocess.run(["fc-list"], capture_output=True, text=True, env=env).stdout
    except FileNotFoundError: fl = ""
    for f in REQUIRED_FONTS:
        print(("PASS" if f in fl else "WARN") + f"  font '{f}' " +
              ("installed" if f in fl else "missing -> preview render uses a substitute; fit is measured with the bundled/brand metrics"))

    print("\nREADY" if not hard_fail else "\nNOT READY - do not build; report the FAIL lines to the user")
    sys.exit(1 if hard_fail else 0)


def dashboard_main():
    """Validate only resources required for standalone interactive HTML dashboards."""
    required = [
        ROOT / "tools" / "dashboard.py",
        ROOT / "tools" / "htmlpdf.py",
        ROOT / "tools" / "compliance.py",
        KIT / "kit" / "data" / "dashboard.py",
    ]
    missing = [str(path.relative_to(ROOT)) for path in required if not path.is_file()]
    if missing:
        for path in missing:
            print(f"FAIL  missing dashboard resource: {path}")
        print("NOT READY - do not build; report the FAIL lines to the user")
        raise SystemExit(1)
    bad = run_report()[0]                              # the scripts themselves, every run
    if bad:
        print("FAIL  package files changed since the skill was installed: " + ", ".join(bad[:6])
              + " - reinstall the skill from its package zip")
        raise SystemExit(1)
    out = Path("/mnt/data/out") if Path("/mnt/data").exists() else Path.cwd() / "out"
    out.mkdir(parents=True, exist_ok=True)
    print(f"READY | dashboard HTML tools verified | output {out}")

if __name__ == "__main__":
    main()
