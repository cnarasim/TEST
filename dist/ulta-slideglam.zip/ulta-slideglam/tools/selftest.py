"""Health check: runs every main feature on built-in sample content and prints a scoreboard (about 4 minutes).
Use it when something misbehaves in a chat ("run the self-test") - the table shows which part fails and why.

    python tools/selftest.py [--quick] [--keep]   --quick skips the PDF conversion and the diagram deck
The work folder (about 180 MB of sample files) is removed after a clean pass and kept when a check fails, to look into;
--keep keeps it either way.
"""
import argparse, csv, json, re, shutil, subprocess, sys, tempfile, time, zipfile, hashlib
from pathlib import Path

T = Path(__file__).resolve().parent
LIB_ONE, LIB_TWO, LIB_SEARCH, LIB_PICK = 'sc-wh-cycle-count', ['rt-oc-fulfilment', 'fi-pp-three-way-match'], ('cycle count', 'sc-wh-cycle-count'), ('three-way match controls; cycle count swimlane; cutover timeline', ['fi-pp-three-way-match (', 'sc-wh-cycle-count (', 'pp-dl-cutover ('])   # library cases
LIB_REVIEW = '# Update\n\n## Milestones\n- Design signed off: Mar 15, 2027\n- Pilot in 20 stores: May 1, 2027\n- Wave 1 live: Jul 15, 2027\n- All stores live: Oct 1, 2027\n\n## Risks\n- Data quality in the item master\n- Store staffing in peak: [owner]\n- Vendor readiness for ASNs\n'
sys.path.insert(0, str(T))
PY = sys.executable


def run(name, cmd, cwd, expect="READY", tokens=True, check=None):
    tool = next((Path(str(c)) for c in cmd if str(c).endswith(".py")), None)
    if tool is not None and not tool.exists():          # Word, Excel, dashboards, sites, whiteboards: not in this skill
        return (name, True, "SKIP", "not part of this PowerPoint skill", 0.0)
    t0 = time.time()
    try:
        r = subprocess.run([PY, *map(str, cmd)], capture_output=True, text=True, cwd=cwd, timeout=240)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        return (name, False, "TIMEOUT", "over 240 s", round(time.time() - t0, 1))
    st = "CRASH" if "Traceback" in out else "READY" if re.search(r"^READY|OVERALL: READY", out, re.M) else (
        "NEEDS CORRECTION" if "NEEDS CORRECTION" in out else "-")
    note = check(out) if check else ""
    first = next((l.strip() for l in out.splitlines() if re.match(r"\s*(FAIL|BLOCK|Traceback|\w+Error)", l)), "")
    score = next((l for l in out.splitlines() if l.startswith("RESULT") and "Standards Match" in l), "")
    why = ""                                             # strict: a READY needs a clean exit and a fully evidenced 100%
    if expect == "READY" and st == "READY" and r.returncode != 0:
        why = f"printed READY but exited {r.returncode}"
    elif tokens and not score:
        why = "no RESULT line"
    elif tokens and expect == "READY" and "Standards Match 100%" not in score:
        why = "RESULT is not a recorded 100%: " + score.split("Standards Match", 1)[1].split("·")[0].strip()[:70]
    ok = st == expect and not why and not note.startswith("BAD")
    return (name, ok, st, note if ok or note.startswith("BAD") else (why or first[:90] or note), round(time.time() - t0, 1))


def unsafe_files(w):
    """The slide-swap reader refuses archives that escape their folder, repeat an entry, or declare XML entities."""
    import slide_package as SP, warnings
    t0, refused = time.time(), 0
    with zipfile.ZipFile(w / "escape.pptx", "w") as z:
        z.writestr("../escape.xml", "x")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        with zipfile.ZipFile(w / "twice.pptx", "w") as z:
            z.writestr("a.xml", "1"); z.writestr("a.xml", "2")
    for f in (lambda: SP.read(w / "escape.pptx"), lambda: SP.read(w / "twice.pptx"),
              lambda: SP.xml(b'<!DOCTYPE x [<!ENTITY s SYSTEM "file:///etc/passwd">]><x>&s;</x>')):
        try:
            f()
        except ValueError:
            refused += 1
    for p in (w / "escape.pptx", w / "twice.pptx"):     # test archives, not decks: gone before the decks are checked
        p.unlink()
    return ("unsafe files refused (swap)", refused == 3, "-", f"{refused}/3 refused", round(time.time() - t0, 1))


def metadata(w):
    """The clean-up takes the templates' people and a code library's defaults out of a file's properties; business
    properties and any note of how the file was made stay exactly as they were."""
    import docprops, privacy
    from pptx import Presentation
    t0, f = time.time(), w / "meta.pptx"
    prs = Presentation(); prs.slides.add_slide(prs.slide_layouts[5]).shapes.title.text = "Metadata check"
    prs.core_properties.comments = "Generated with an assistant from the Q3 notes"
    prs.save(str(f))
    docprops.write_props(f, custom={"BusinessOwnerEmail": "store.owner@example.com", "CostCenter": "4410"})
    privacy.scrub(f, "Store Operations")
    core, custom = docprops.read_props(f)
    kept = custom.get("BusinessOwnerEmail") == "store.owner@example.com" and custom.get("CostCenter") == "4410"
    note = (core.get("description") or "") == "Generated with an assistant from the Q3 notes"
    owner = core.get("creator") == "Store Operations" and core.get("lastModifiedBy") == "Store Operations"
    ok = kept and note and owner
    return ("people out, business data and provenance kept", ok, "-",
            "the library's author became the owner; owner e-mail, cost centre and the 'generated with' note kept" if ok else
            "BAD " + ("business property removed" if not kept else "a note of how the file was made was changed" if not note
                      else f"author not the owner: {core.get('creator')!r} / {core.get('lastModifiedBy')!r}"), round(time.time() - t0, 1))


def integrity_rules(w):
    """Startup integrity on a small package: a platform-set file may change and an added test script is only noted;
    an added file named like a module the code imports, or a changed shipped file, stops the skill."""
    import bootstrap as BS
    t0, root = time.time(), w / "integ"
    files = {"tools/a.py": "import json\nimport helper\n", "tools/helper.py": "X = 1\n", "agents/openai.yaml": "interface: {}\n"}
    for rel, text in files.items():
        (root / rel).parent.mkdir(parents=True, exist_ok=True); (root / rel).write_text(text)
    (root / "integrity.json").write_text(json.dumps({"files": {r: hashlib.sha256((root / r).read_bytes()).hexdigest()
                                                              for r in files if not BS.ADMIN.match(r)}}))
    (root / "agents" / "openai.yaml").write_text("interface: {display_name: x}\n")
    (root / "tools" / "test_review.py").write_text("print(1)\n")
    steps = [BS.integrity_report(root) == ([], ["tools/test_review.py"])]
    (root / "tools" / "json.py").write_text("X = 2\n")
    steps.append(BS.integrity_report(root)[0] == ["tools/json.py"])
    (root / "tools" / "json.py").unlink(); (root / "tools" / "helper.py").write_text("X = 3\n")
    steps.append(BS.integrity_report(root)[0] == ["tools/helper.py"])
    return ("startup integrity rules", all(steps), "-", "added script noted; impostor and changed file refused" if all(steps)
            else f"BAD {['added script noted', 'impostor refused', 'changed file refused'][steps.index(False)]} failed",
            round(time.time() - t0, 1))


def reset_safe(w):
    """PowerPoint's Reset (or a slide added from the same layout) keeps the one-line headline: the deck's own layout
    carries the full-width headline box, not only the slide (a reset 5.8 in box wrapped into the table below)."""
    t0, f = time.time(), w / "cards.pptx"
    name = "headline after PowerPoint Reset"
    if not f.exists():
        return (name, False, "-", "BAD no deck to check", 0.0)
    from pptx import Presentation
    P_, A_ = "{http://schemas.openxmlformats.org/presentationml/2006/main}", "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    prs = Presentation(str(f))
    W, got = prs.slide_width, []
    for s in prs.slides:
        for sh in s.placeholders:
            xf = sh._element.find(f"{P_}spPr/{A_}xfrm")
            if xf is None or not sh.has_text_frame or not sh.text_frame.text.strip() or (sh.top or 0) > 914400 \
                    or sh.width < 0.9 * (W - 2 * sh.left):
                continue
            room = W - 2 * sh.left
            sh._element.find(f"{P_}spPr").remove(xf)               # Reset: the slide's own box goes, the layout's applies
            got.append(sh.width / room)
            ph = next((x for x in prs.slides.add_slide(s.slide_layout).placeholders
                       if x.placeholder_format.idx == sh.placeholder_format.idx), None)
            if ph is not None:
                got.append(ph.width / room)
            break
        if got:
            break
    ok = bool(got) and min(got) >= 0.9
    return (name, ok, "-", "reset slide and a new slide keep the full-width box" if ok else
            f"BAD the layout's headline box is {min(got or [0]):.0%} of the content width", round(time.time() - t0, 1))


def cards_fit(w):
    """The card slide and the four pillars take what a storyboard gives without keeping any template sample text:
    cards with no column labels become numbered tiles, one card row or two columns fit the layout, and four
    pillars with no row labels show none (not the template's 'Category' / 'Insights')."""
    t0, name = time.time(), "cards and pillars fit (no sample text)"
    pairs = [["Signals", "Analysis", "Backlog"], ["Usage and incidents\n\nOwners validate data and root causes",
              "Anomaly analysis\n\nSRE and product teams verify hypotheses", "Backlog and experiments\n\nProduct lead approves next iteration"]]
    (w / "cards-fit.json").write_text(json.dumps({"slides": [
        {"source": 1, "title": "Card fit check"},
        {"source": "agenda-list", "table": [[None, "Signals"], [None, "Analysis"], [None, "Backlog"]]},   # (agenda: its box
        {"source": 7, "headline": "Operations closes the product learning loop", "table": [[
            "Product usage, incidents and service signals\nOwners validate data and root causes",
            "AI-assisted anomaly and feedback analysis\nSRE and product teams verify hypotheses",
            "Prioritized backlog and experiments\nProduct lead approves next iteration"]]},
        {"source": "divider-berry", "title": "Owners"},       # (a divider between card slides: never two told one way)
        {"source": 7, "headline": "Every signal reaches an owner within a week", "table": pairs},
        {"source": "divider-berry", "title": "Review"},
        {"source": 7, "headline": "Two teams share the weekly review", "table": [["Signals", "Analysis"],
            ["Usage\n\nOwners validate the data", "Anomalies\n\nSRE verifies each hypothesis"],
            ["Incidents\n\nRoot causes are logged", "Feedback\n\nThemes are reviewed weekly"]]},
        {"source": "divider-berry", "title": "Governance"},
        {"source": "four-pillars", "headline": "Governance stays human-led at every gate", "table": [
            [None, "Trust", "Security", "Quality"], [None, "Reliable and grounded", "Protect enterprise data", "Verify every output"],
            [None, "Source traceability\nBias review", "Approved tools\nPrivacy checks", "Review evidence\nRelease controls"]]},
        {"source": "thank-you"}]}))
    r = subprocess.run([sys.executable, "-I", str(T / "build_deck.py"), "build", str(w / "cards-fit.json"), "--out", str(w / "cards-fit.pptx")],
                       capture_output=True, text=True, cwd=w, timeout=900)
    out = r.stdout + r.stderr
    f = w / "cards-fit.pptx"
    if not f.exists():
        return (name, False, "-", "BAD no deck built", round(time.time() - t0, 1))
    from pptx import Presentation
    left = []
    for k, sl in enumerate(Presentation(str(f)).slides, 1):
        for sh in sl.shapes:
            texts = [c.text for row in sh.table.rows for c in row.cells] if sh.has_table else \
                    [sh.text_frame.text] if sh.has_text_frame else []
            left += [f"slide {k}: {t.strip()[:20]!r}" for t in texts
                     if re.search(r"(?i)lorem ipsum|^sub-headline|^headline$|^category$|^insights$", t.strip())]
    tiles = "set as numbered tiles" in out
    ok = bool(re.search(r"^READY", out, re.M)) and not left and tiles
    return (name, ok, "READY" if ok else "-", "tiles for unlabelled cards, 1 card row, 2 columns, no 'Category'" if ok else
            "BAD " + (left[0] if left else "not READY" if tiles else "unlabelled cards were not set as tiles"), round(time.time() - t0, 1))


def placeholders_never_ship(w):
    """A slide given only a headline keeps the template's placeholder text: the build writes no deck (NOT WRITTEN,
    an INCOMPLETE work copy in the validation folder). A deck that went out like that converts back clean: the
    placeholders are left out, cards written into the header row become tiles, the classification stays."""
    t0, name = time.time(), "placeholder text never ships"
    py = [sys.executable, "-I"]
    (w / "holes.json").write_text(json.dumps({"classification": "internal", "slides": [
        {"source": 1, "title": "Placeholder check"},
        {"source": 7, "headline": "Operations closes the product learning loop"},
        {"source": 12, "headline": "Four actions keep us on time"}, {"source": "thank-you"}]}))
    r = subprocess.run(py + [str(T / "build_deck.py"), "build", str(w / "holes.json"), "--out", str(w / "holes.pptx")],
                       capture_output=True, text=True, cwd=w, timeout=900)
    work = w / "holes_validation" / "holes-INCOMPLETE.pptx"
    lines = r.stdout.splitlines()
    first_line = lines[0] if lines else ""
    held = "NOT WRITTEN" in first_line and not (w / "holes.pptx").exists() and work.exists()
    if not held:
        err = first_line or (r.stderr.strip()[:100] if r.stderr else "build process exited without output")
        return (name, False, "-", f"BAD {err}", round(time.time() - t0, 1))
    from pptx import Presentation                       # the deck as it went out before v110: cards in the header row
    prs = Presentation(str(work))
    tbl = next(sh for sh in prs.slides[1].shapes if sh.has_table).table
    for c, txt in zip(tbl.rows[0].cells, ["Product usage and service signals\nOwners validate data and root causes",
                                          "AI-assisted anomaly analysis\nSRE and product teams verify hypotheses",
                                          "Prioritized backlog and experiments\nProduct lead approves next iteration"]):
        c.text_frame.text = txt
    prs.save(str(w / "went-out.pptx"))
    r = subprocess.run(py + [str(T / "convert_deck.py"), str(w / "went-out.pptx"), "--out", str(w / "went-out-rebuilt.pptx"), "--build"],
                       capture_output=True, text=True, cwd=w, timeout=900)
    f = w / "went-out-rebuilt.pptx"
    import validate_deck as V
    left = V.placeholder_slides(f) if f.exists() else {"?": ["not built"]}
    foot = " ".join(sh.text_frame.text for sl in Presentation(str(f)).slides for sh in sl.shapes
                    if sh.has_text_frame and "|" in sh.text_frame.text) if f.exists() else ""
    ok = bool(re.search(r"^READY", r.stdout, re.M)) and not left and "Internal Use Only" in foot
    return (name, ok, "READY" if ok else "-", "not written with placeholders; the deck that went out converts back clean"
            if ok else f"BAD rebuilt deck: {left or 'not READY'} {foot[:30]!r}", round(time.time() - t0, 1))


def cut_off_build(w):
    """A build stopped part-way (the chat's cell time limit) leaves no deck where deliverables go - neither the half-made
    one nor the deck an earlier build left there - and the next build of the same file runs and puts its deck there."""
    t0, name = time.time(), "cut-off build leaves no deck"
    import atomic, os, signal
    out = w / "cut-off.pptx"
    out.write_bytes(b"an earlier build"); Path(str(out) + ".checks.json").write_text("{}")
    cmd = [sys.executable, "-I", str(T / "build_deck.py"), "build", str(w / "cards.json"), "--out", str(out)]
    p = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=w, start_new_session=True)
    st = atomic.stage_for(out, p.pid) / out.name
    while p.poll() is None and not st.exists() and time.time() - t0 < 180:
        time.sleep(0.2)
    time.sleep(1)                                      # into the fitting and checks
    try:
        os.killpg(p.pid, signal.SIGKILL) if hasattr(os, "killpg") else p.kill()
    except (ProcessLookupError, OSError):              # (already ended: the row below says it finished before the cut)
        pass
    p.wait()
    left = sorted(x.name for x in w.glob("cut-off*")) + sorted(x.name for x in w.glob(".cut-off.pptx.*.part"))
    if not st.exists() or left:
        return (name, False, "-", f"BAD {'left at the output path: ' + ', '.join(left) if left else 'finished before the cut'}",
                round(time.time() - t0, 1))
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=w, timeout=900)
    ok = r.stdout.startswith("READY") and out.exists() and not st.parent.exists()   # (and cleared the cut-off build's folder)
    return (name, ok, "READY" if ok else "-", "nothing left at the output path; the next build finished" if ok
            else f"BAD rebuild after the cut: {r.stdout.strip()[:80]}", round(time.time() - t0, 1))


def tracked_job(w):
    """job.py runs the skill's own tools and nothing else: a tool runs to DONE with its exit code; another program, or a
    job name outside the jobs folder, is refused and starts nothing."""
    t0, name = time.time(), "tracked job runs only the skill's tools"
    import os
    me = f"selftest-{os.getpid()}"                      # this run's own job names: two self-tests never share one
    go = lambda *a, timeout=60: subprocess.run([PY, "-I", str(T / "job.py"), *a], capture_output=True, text=True, cwd=w, timeout=timeout)
    s = go("start", me, "--", "python", str(T / "build_deck.py"), "--help")
    d = go("wait", me, "--max", "60", timeout=90)
    sw = go("start", me + "-w", "--wait", "60", "--", "python", str(T / "build_deck.py"), "--help", timeout=90)   # one cell
    other = go("start", me + "-other", "--", "sh", "-c", "echo started")
    inline = go("start", me + "-inline", "--", "python", "-c", "print(1)")
    bad = go("start", "../" + me, "--", "python", str(T / "build_deck.py"), "--help")
    jobs = (Path("/mnt/data/out") if Path("/mnt/data").exists() else w / "out") / ".jobs"
    made = [n for n in (f"{me}-other.json", f"{me}-inline.json") if (jobs / n).exists()] + (
        [f"{me}.json"] if (jobs.parent / f"{me}.json").exists() else [])
    for n in (f"{me}.json", f"{me}.log", f"{me}-w.json", f"{me}-w.log"):
        (jobs / n).unlink(missing_ok=True)
    same_cell = sw.stdout.startswith(f"DONE {me}-w") and "usage:" in sw.stdout and "STARTED" not in sw.stdout
    ok = (s.stdout.startswith("STARTED") and d.stdout.startswith(f"DONE {me}") and "(exit code 0)" in d.stdout and same_cell
          and all(r.returncode != 0 and "nothing was started" in r.stderr for r in (other, inline)) and bad.returncode != 0 and not made)
    return (name, ok, "-", "a skill tool ran to DONE (exit code 0), with --wait in the same cell; another program and a name outside "
            "the jobs folder were refused"
            if ok else f"BAD {s.stdout.strip()[:40]!r} {d.stdout.strip()[:40]!r} {sw.stdout.strip()[:40]!r} {other.stderr.strip()[:50]!r} "
            f"{bad.stderr.strip()[:40]!r} {made}", round(time.time() - t0, 1))


def fast_render(w):
    """The quicker render gives the same files: slide pictures drawn three pages at a time on several processors are
    pixel for pixel the ones a single pass draws, and a deck stores its pictures as they are (its text parts deflated)."""
    t0, name = time.time(), "faster render, same pictures"
    import lo
    pdf, deck = w / "cards_validation" / "cards.pdf", w / "cards.pptx"
    if not (pdf.exists() and deck.exists() and shutil.which("pdftoppm")):
        return (name, False, "-", "BAD no rendered deck to compare (LibreOffice or pdftoppm missing)", round(time.time() - t0, 1))
    from PIL import Image, ImageChops
    one, many = w / "render-one", w / "render-many"
    one.mkdir(exist_ok=True); many.mkdir(exist_ok=True)
    subprocess.run(["pdftoppm", "-png", "-r", "96", str(pdf), str(one / "s")], capture_output=True, timeout=300)
    got, ref = lo.rasterize(pdf, many / "s", 96), sorted(one.glob("s-*.png"))
    same = len(got) == len(ref) > 0 and all(ImageChops.difference(Image.open(a).convert("RGB"), Image.open(b).convert("RGB")).getbbox()
                                            is None for a, b in zip(ref, got))
    z = zipfile.ZipFile(deck)
    pics = [i for i in z.infolist() if i.filename.lower().endswith((".png", ".jpeg", ".jpg"))]
    xml = [i for i in z.infolist() if i.filename.endswith(".xml")]
    stored = pics and all(i.compress_type == zipfile.ZIP_STORED for i in pics) and all(i.compress_type == zipfile.ZIP_DEFLATED for i in xml)
    ok = same and stored
    return (name, ok, "-", f"{len(got)} slide pictures identical to one pass ({lo.cpus()} processors); {len(pics)} pictures stored as they "
            "are, text parts deflated" if ok else f"BAD pictures {'identical' if same else 'differ'}, compression "
            f"{'ok' if stored else 'not as expected'}", round(time.time() - t0, 1))


def safety_rules():
    """The promises in SKILL.md's "How this skill works" section, checked against the skill's own files (tools/safety_rules.py):
    no network access, only its own programs, pages change nothing in the browser, honest records, no internal addresses,
    publishing only on request, a description that says what the skill does."""
    t0 = time.time()
    import safety_rules as SR
    res = SR.check()
    broken = [(n, b) for n, b in res if b]
    return ("safety rules kept", not broken, "-", f"{len(res)}/{len(res)} rules kept: " + ", ".join(n.lower() for n, _ in res[:3]) + " ..."
            if not broken else f"BAD {broken[0][0]}: {broken[0][1][0][:90]}", round(time.time() - t0, 1))


def _saved_edit(page, out, change):
    """What the page's Save writes: the same page with its data block changed (here by change(data), as a person's edit)."""
    t = Path(page).read_text(encoding="utf-8")
    m = re.search(r'(<script id="data" type="application/json">)(.*?)(</script>)', t, re.S)
    data = json.loads(m.group(2)); change(data)
    Path(out).write_text(t[:m.start(2)] + json.dumps(data).replace("<", "\\u003c") + t[m.end(2):], encoding="utf-8")


def _page_engine(kind, page_data, assets, w):
    """The page's own JavaScript engine (kit/editor) laying the page's content out again, as the browser does after an edit,
    with the page's brand colour pass: the SVG it shows, page by page; None when node is not on this computer (a browser-free sandbox)."""
    node = shutil.which("node")
    if not node:
        return None
    ed = (T.parent / "modules" / "ultabranddeliverables" / "scripts" / "kit" / "editor").as_posix()
    (w / f"{kind}-data.json").write_text(json.dumps(page_data)); (w / f"{kind}-assets.json").write_text(json.dumps(assets))
    js = ("const fs=require('fs');const C=require(process.argv[1]+'/engine-core.js'),I=require(process.argv[1]+'/info-engine.js');"
          "const A=JSON.parse(fs.readFileSync(process.argv[3]));C.setMetrics(A.metrics);C.setIcons(A.icons,A.catalog,A.logo);"
          "const D=JSON.parse(fs.readFileSync(process.argv[2]));"
          "let out=process.argv[4]==='screens'?require(process.argv[1]+'/screens-engine.js').design(D.spec).designs.map(d=>I.toSvg(d)):I.pageSvgs(I.design(D.src));"
          "const CF=process.argv[4]!=='screens'&&A.palette?new C.Conform(A.palette):null;if(CF)out=out.map(s=>CF.svg(s));"   # the brand colour pass the page runs after every layout
          "process.stdout.write(JSON.stringify(out));")
    r = subprocess.run([node, "-e", js, ed, str(w / f"{kind}-data.json"), str(w / f"{kind}-assets.json"), kind], capture_output=True, text=True, timeout=120)
    try:
        return json.loads(r.stdout)
    except ValueError:
        return ["ERROR " + (r.stderr or r.stdout)[-200:]]


def _svg_norm(s):
    s = re.sub(r'(id="|url\(#)[gc][0-9_]+', r"\1G", s)              # gradient and picture-clip ids are per page
    s = re.sub(r'href="data:[^"]*"', 'href=""', s)                  # a picture: the page keeps its data once, in its content
    return re.sub(r"-?\d+(?:\.\d+)?(?:e[-+]?\d+)?", lambda m: repr(round(float(m.group(0)), 4) + 0.0), s)


def _page_parts(page):
    t = Path(page).read_text(encoding="utf-8")
    data = json.loads(re.search(r'<script id="data" type="application/json">(.*?)</script>', t, re.S).group(1))
    m = re.search(r'<script id="assets" type="application/json">(.*?)</script>', t, re.S)
    return t, data, json.loads(m.group(1)) if m else None


def editable_pages(w):
    """The infographic page is its own editor: the engine, the fonts and the pictograms inside it, Edit / Undo / Save in the
    page; the page's JavaScript engine lays the content out exactly as the Python kit did (checked with node where it is
    installed); a page the user changed and saved rebuilds into a PowerPoint that carries the change."""
    t0, name = time.time(), "editable infographic page"
    py = [sys.executable, "-I"]
    (w / "edit-me.json").write_text(json.dumps({"title": "Store transfers in three steps", "format": "onepager", "blocks": [
        {"type": "stats", "items": [{"value": "38%", "label": "fewer out-of-stocks"}, {"value": "2 days", "label": "faster than a DC order"}]},
        {"type": "steps", "title": "How it works", "items": [{"title": "Find", "text": "Look up nearby stores"}, {"title": "Request", "text": "Send the transfer"}, {"title": "Receive", "text": "Scan it in"}]},
        {"type": "takeaway", "text": "Check nearby stores before you order from the DC."}]}))
    r = subprocess.run(py + [str(T / "infographic.py"), "make", str(w / "edit-me.json"), "--out", str(w / "edit-me")],
                       capture_output=True, text=True, cwd=w, timeout=600)
    page = w / "edit-me.html"
    if not r.stdout.startswith("READY") or not page.exists():
        return (name, False, "-", "BAD not built: " + r.stdout[:80], round(time.time() - t0, 1))
    t, data, assets = _page_parts(page)
    need = ['id="editBtn"', 'id="undoBtn"', 'id="saveBtn"', "UltaInfo", "UltaPage", "UltaCore", "@font-face", 'id="assets"']
    miss = [x for x in need if x not in t] + ([] if isinstance(data.get("src"), dict) and assets and assets.get("metrics") and assets.get("icons") else ["page data"])
    if miss:
        return (name, False, "-", "BAD the page cannot edit itself: missing " + ", ".join(miss), round(time.time() - t0, 1))
    js = _page_engine("info", data, assets, w)
    py_svgs = data["svg"].split('<div class="pgap"></div>')
    same = None if js is None else len(js) == len(py_svgs) and all(_svg_norm(a) == _svg_norm(b) for a, b in zip(js, py_svgs))
    if same is False:
        return (name, False, "-", "BAD the page's engine draws it differently from Python: " + str(js[0])[:60], round(time.time() - t0, 1))

    def change(data):
        data["src"]["title"] = "Store transfers made simple"
        data["src"]["blocks"][1]["items"].append({"title": "Close", "text": "Confirm the count"})
    _saved_edit(page, w / "edited.html", change)
    r = subprocess.run(py + [str(T / "infographic.py"), "make", str(w / "edited.html"), "--out", str(w / "rebuilt")],
                       capture_output=True, text=True, cwd=w, timeout=600)
    spec = json.loads((w / "rebuilt-spec.json").read_text()) if (w / "rebuilt-spec.json").exists() else {}
    ok = r.stdout.startswith("READY") and spec.get("title") == "Store transfers made simple" and len(spec.get("blocks", [{}, {}])[1].get("items", [])) == 4
    eng = "the page's engine draws it as Python does" if same else "node not here: engine parity checked when the skill is built"
    return (name, ok, "READY" if ok else "-", f"edits itself (panel, click-to-edit, Save); {eng}; the saved edit rebuilds" if ok
            else f"BAD rebuild from the edited page: {r.stdout[:80]}", round(time.time() - t0, 1))


def picture_onepager(w):
    """A one-pager told around the user's pictures: a screenshot and a phone photo (EXIF, GPS and a comment, stored on its
    side) build READY; each picture is in the PowerPoint, the SVG and the page, described, upright and without metadata;
    the Pictures check asks for a look at the screenshot; the page's engine draws it as Python does; a template's sample
    picture left in the content FAILs; the page rebuilds with its pictures."""
    t0, name = time.time(), "one-pager with pictures"
    from PIL import Image
    from PIL.TiffImagePlugin import IFDRational
    kit = T.parent / "modules" / "ultabranddeliverables" / "scripts" / "kit"
    shutil.copyfile(kit / "infographic" / "samples" / "approval-queue.png", w / "my-screen.png")
    ph = Image.open(kit / "infographic" / "samples" / "guest-bag.jpg").convert("RGB").rotate(90, expand=True)
    ex = Image.Exif(); ex[0x010F] = "PhoneMaker"; ex[0x0112] = 6
    ex[0x8825] = {1: "N", 2: (IFDRational(41, 1), IFDRational(52, 1), IFDRational(30, 1))}
    ph.save(w / "my-photo.jpg", "JPEG", quality=90, exif=ex.tobytes(), comment=b"private note")
    md = ("# Store Pickup Lockers\nProduct owner: Rowan Pike\nStatus: In pilot\nLaunch: Q2 FY27\n\n## What it is\nOrders ready in a locker, open with a code.\n\n"
          "## In pictures\n![The order queue that fills each locker](my-screen.png)\n![A guest collecting an order](my-photo.jpg)\n\n"
          "## Who it's for\n- Guests: Pick up without a line\n- Associates: Back on the floor\n\n## Next step\nApprove 40 pilot stores.\n")
    (w / "pics.md").write_text(md, encoding="utf-8")
    py = [sys.executable, "-I"]
    r = subprocess.run(py + [str(T / "onepager.py"), "pics.md", "--template", "intro", "--out", str(w / "pics")], capture_output=True, text=True, cwd=w, timeout=600)
    if not r.stdout.startswith("READY"):
        return (name, False, "-", "BAD " + r.stdout[:120], round(time.time() - t0, 1))
    bad = []
    with zipfile.ZipFile(w / "pics.pptx") as z:
        media = [n for n in z.namelist() if n.startswith("ppt/media/") and not n.endswith((".svg", ".emf"))]
        import io
        for n in media:
            raw = z.read(n); im = Image.open(io.BytesIO(raw))
            if len(im.getexif()) or b"private note" in raw or b"PhoneMaker" in raw:
                bad.append(f"{n} keeps its metadata")
            if im.format == "JPEG" and im.width < im.height:
                bad.append(f"{n} is on its side")
        alts = [a for a in re.findall(r'<p:pic>.*?descr="([^"]*)"', z.read("ppt/slides/slide1.xml").decode(), re.S) if a != "Ulta Beauty logo"]
    if sorted(alts) != sorted(["The order queue that fills each locker", "A guest collecting an order"]):
        bad.append(f"descriptions {alts}")
    if (w / "pics.svg").read_text(encoding="utf-8").count("<image") != 2:
        bad.append("the SVG does not hold both pictures")
    rec = json.loads((w / "pics.pptx.checks.json").read_text())
    row = next((x for x in rec["rows"] if x["check"].startswith("Pictures")), {})
    if row.get("result") != "REVIEW" or "screenshot" not in row.get("detail", ""):
        bad.append(f"Pictures check {row.get('result')}: {row.get('detail', '')[:60]}")
    t, data, assets = _page_parts(w / "pics.html")
    adds = ['id="picBtn"', "addEventListener('drop'", "addEventListener('paste'", 'data-act="gadd"', 'data-act="besidepic"', "function addPictures"]
    if [x for x in adds if x not in t]:                  # the page adds pictures: + Picture, drop, paste, a gallery's + Add, beside points
        bad.append("the page cannot add pictures: missing " + ", ".join(x for x in adds if x not in t))
    if len((data.get("src") or {}).get("images") or {}) != 2 or (data.get("design") or {}).get("spec", {}).get("images"):
        bad.append("the page does not keep each picture once, in its content")
    js = _page_engine("pics", data, assets, w)
    same = None if js is None else all(_svg_norm(a) == _svg_norm(b) for a, b in zip(js, data["svg"].split('<div class="pgap"></div>')))
    if same is False:
        bad.append("the page's engine draws the pictures differently from Python")
    (w / "pics-sample.md").write_text(md.replace("my-screen.png", "sample:price-portal"), encoding="utf-8")
    r2 = subprocess.run(py + [str(T / "onepager.py"), "pics-sample.md", "--template", "intro", "--out", str(w / "pics-sample")], capture_output=True, text=True, cwd=w, timeout=600)
    if not r2.stdout.startswith("NEEDS CORRECTION") or "sample pictures" not in r2.stdout:
        bad.append("a sample picture left in the content did not FAIL")
    r3 = subprocess.run(py + [str(T / "infographic.py"), "make", str(w / "pics.html"), "--out", str(w / "pics-rebuilt")], capture_output=True, text=True, cwd=w, timeout=600)
    spec = json.loads((w / "pics-rebuilt-spec.json").read_text()) if (w / "pics-rebuilt-spec.json").exists() else {}
    if not r3.stdout.startswith("READY") or len(spec.get("images") or {}) != 2:
        bad.append("the page did not rebuild with its pictures: " + r3.stdout[:60])
    eng = "the page's engine draws it as Python does" if same else "node not here: engine parity checked when the skill is built"
    return (name, not bad, "READY" if not bad else "-", ("2 pictures placed, described, upright, no metadata; screenshot flagged for a look; "
            f"sample picture FAILs; the page adds and replaces pictures; {eng}; the page rebuilds") if not bad else "BAD " + "; ".join(bad)[:200], round(time.time() - t0, 1))


PINKS = {"E8275A", "D01381", "DB0058", "C10060", "5D0F43", "EA0B59", "FAD3DB", "E4C8DB", "FFE8EE", "FFF2F6"}   # the template's pinks, magenta, plum
MARKS = ("list badge", "card icon disc", "status icon disc", "tile disc", "hub disc", "hub spoke", "pillar capital", "pillar foot", "pillar disc",
         "title bar", "top rule")   # the small marks that take the brand's colours in turn (v139); every big shape leads in light orange


def orange_light(w):
    """Infographics lead with a light orange gradient on a light page (v139; v136: Ulta orange, light). A user's slide (three levels as
    numbered steps, six enablers with pictograms, the decision) built as a slide keeps the template's colour theme - the cream
    background its content slides have, not the first master's pink a brand-colour pass once wrote over it; its steps and its message
    banner run from Ulta's light orange into Ulta orange with dark words; the discs behind its pictograms and the section marks take
    the brand's colours in turn, and nothing else on the page is pink or berry; every word reads, in every format;
    the page's own engine draws it as Python does."""
    t0, name = time.time(), "infographic leads in light orange"
    spec = {"title": "Agentic AI for Omnichannel Fulfillment", "subtitle": "Vision: detect risk, recover orders, protect the customer promise",
            "theme": "ulta", "blocks": [
                {"type": "steps", "title": "Three levels of fulfillment intelligence", "items": [
                    {"title": "L1 | Assisted", "text": "Surface late orders, backorders, inventory and node risks."},
                    {"title": "L2 | Augmented", "text": "Recommend reroute, substitution, split shipment or escalation."},
                    {"title": "L3 | Autonomous", "text": "Execute approved recovery within policy and update the promise."}]},
                {"type": "list", "title": "Agentic platform enablers", "items": [
                    {"title": t, "text": x} for t, x in (("Fulfillment agents", "Monitor orders, inventory and exceptions."),
                                                         ("Tools and APIs", "Provide governed order and inventory actions."),
                                                         ("Model gateway", "Route models and enforce approved access."),
                                                         ("Agent builder", "Configure workflows and tool permissions."),
                                                         ("Embedded assistant", "Bring actions into associate workflows."),
                                                         ("Guardrails and monitoring", "Audit decisions, approvals, costs and outcomes."))]},
                {"type": "takeaway", "text": "Human oversight stays in control: policy-based autonomy, escalation thresholds and auditable recovery actions.", "icon": "target"}]}
    (w / "orange.json").write_text(json.dumps(spec))
    r = subprocess.run([PY, "-I", str(T / "infographic.py"), "make", str(w / "orange.json"), "--out", str(w / "orange"), "--format", "slide"],
                       capture_output=True, text=True, cwd=w, timeout=600)
    if not r.stdout.startswith("READY") or not (w / "orange.pptx").exists():
        return (name, False, "-", "BAD not built: " + (r.stdout or r.stderr)[:80], round(time.time() - t0, 1))
    import onepager, a11y
    bad = [f"the template's {t} theme lost its {k} (#{v}, the template's #{c})" for t, k, v, c in onepager.theme_changes(w / "orange.pptx")]
    with zipfile.ZipFile(w / "orange.pptx") as z:
        parts = a11y.slide_parts(z); part = parts[0]       # the slide alone: no cover, no closing slide (v137)
        ground = a11y.background(z, part, a11y.slide_theme(z, part, {}))
    if len(parts) != 1:
        bad.append(f"{len(parts)} slides for a one-slide infographic")
    if a11y.B.luminance(ground) < 0.85:
        bad.append(f"the slide's background is #{ground}, not a light one")
    kit = T.parent / "modules" / "ultabranddeliverables" / "scripts" / "kit"
    for p_ in (kit, kit / "infographic"):
        if str(p_) not in sys.path:
            sys.path.insert(0, str(p_))
    import info as IG
    lead = {c for pair in IG.LIGHT_STAGES for c in pair} | set(IG.LIGHT_LEAD)
    for fmt in IG.FORMAT_ORDER:
        d = IG.layout(dict(spec, format=fmt))
        cols = lambda e: {str(c).upper() for c in [e.get("fill"), e.get("stroke"), e.get("color")] + list(e.get("grad") or []) if c}
        off = sorted({e.get("name") for e in d["els"] if cols(e) & PINKS and e.get("name") not in MARKS})
        dots = [e for e in d["els"] if e.get("name") == "step dot"]
        nums = {str(e.get("color")).upper() for e in d["els"] if e.get("name") == "step number"}
        band = [e for e in d["els"] if e.get("name") == "takeaway"]
        words = {str(e.get("color")).upper() for e in d["els"] if e.get("name") == "takeaway text"}
        badges = [str(e.get("fill")).upper() for e in d["els"] if e.get("name") == "list badge"]
        if off:
            bad.append(f"{fmt}: pink or berry beyond the small marks ({', '.join(off)})")
        if not dots or not all(set(e.get("grad") or []) <= lead for e in dots) or nums != {"000000"}:
            bad.append(f"{fmt}: the steps do not lead in light orange with dark numbers")
        if not band or list(band[0].get("grad") or []) != list(IG.LIGHT_LEAD) or words != {"000000"}:
            bad.append(f"{fmt}: the message banner is not light orange with dark words")
        brand = set(IG.PALETTE) | {g[0] for g in IG.GRAD.values()}   # each colour, or where its gradient starts
        if not badges or len(set(badges)) < 3 or not set(badges) <= brand:
            bad.append(f"{fmt}: the icon discs do not take the brand's colours in turn ({', '.join(badges)})")
        if IG.readable_report(d)[1]:
            bad.append(f"{fmt}: {len(IG.readable_report(d)[1])} words under the contrast bar")
    t, data, assets = _page_parts(w / "orange.html")
    js = _page_engine("info", data, assets, w)
    py_svgs = data["svg"].split('<div class="pgap"></div>')
    same = None if js is None else len(js) == len(py_svgs) and all(_svg_norm(a) == _svg_norm(b) for a, b in zip(js, py_svgs))
    if same is False:
        bad.append("the page's engine draws it differently from Python")
    eng = "the page's engine draws it as Python does" if same else "node not here: engine parity checked when the skill is built"
    return (name, not bad, "READY" if not bad else "-",
            f"slide keeps the template's colour theme, background #{ground}; steps and banner in a light orange run with dark words, icon "
            f"discs and section marks in the brand's colours in turn, nothing else pink, every word readable, in {len(IG.FORMAT_ORDER)} formats; {eng}"
            if not bad else "BAD " + "; ".join(bad)[:200], round(time.time() - t0, 1))


def result_line(w):
    """The RESULT line says what is measured and what is estimated (v140; asked: label it "Estimated efficiency versus
    modeled baseline", not verified cost savings): the checks and the time the tool took are measured; the fewer tokens and
    credits are labelled "Estimated efficiency versus modeled baseline ... not billing data", with "(assumed rate)" while
    credits.json's rate is the shipped assumption; the file's audit record keeps the method and its assumptions; tokens.py
    --explain prints the method and that file's numbers, the same percentage as the line."""
    t0, name = time.time(), "efficiency labelled as an estimate"
    if not (w / "orange.json").exists():
        (w / "orange.json").write_text(json.dumps({"title": "Pickup in two hours", "theme": "ulta", "blocks": [
            {"type": "stats", "items": [{"value": "2 h", "label": "order to pickup"}, {"value": "96%", "label": "on time"}]},
            {"type": "takeaway", "text": "Open pickup in 40 more stores."}]}))
    r = subprocess.run([PY, "-I", str(T / "infographic.py"), "make", str(w / "orange.json"), "--out", str(w / "estimate")], capture_output=True, text=True, cwd=w, timeout=600)
    res = next((l for l in r.stdout.splitlines() if l.startswith("RESULT this turn")), "")
    bad = []
    import tokens
    if tokens.fewer(60, 20000) != 99 or tokens.fewer(1000, 3998) != 75:     # 99.7% must not round to an impossible 100%
        bad.append("the estimate can read 100% fewer tokens")
    for want in ("ULTA Standards Match 100%", " · built in ", "Estimated efficiency versus modeled baseline", "% fewer tokens", "% fewer credits",
                 "not billing data", "(assumed rate)"):
        if want not in res:
            bad.append(f"the line lacks '{want.strip(' ·')}'")
    m = re.search(r"(\d+)% fewer tokens", res)
    e = subprocess.run([PY, "-I", str(T / "tokens.py"), "--explain", str(w / "estimate.pptx")], capture_output=True, text=True, cwd=w, timeout=120).stdout
    if not all(x in e for x in ("Measured", "Estimated", "modeled baseline", "This file")) or not m or f"{m.group(1)}% fewer" not in e:
        bad.append("--explain does not give the method and this file's own numbers")
    try:
        est = next(x["token_estimate"] for x in reversed(json.loads((w / "estimate.pptx.audit.json").read_text())) if isinstance(x, dict) and x.get("token_estimate"))
        if not (est.get("method", "").startswith("estimate") and est.get("rate_is_assumed") is True and est.get("messages_without") and "took_s" in est):
            bad.append("the audit record lacks the method, the assumptions or the time")
    except Exception:
        bad.append("no estimate in the audit record")
    return (name, not bad, "READY" if not bad else "-",
            "measured checks and time first; efficiency labelled an estimate versus a modeled baseline, not billing data, at the assumed "
            "rate (never 100%); the audit record keeps the method; --explain gives this file's numbers" if not bad else "BAD " + "; ".join(bad)[:200],
            round(time.time() - t0, 1))


def office_charts(w):
    """Charts open clean in PowerPoint and draw in any viewer (v140; asked: a dashboard deck PowerPoint offered to repair,
    and a workbook whose charts came out empty, with 'Series 1' and 2529079.65, in a file preview). Deck: every chart's
    axis ids fit the signed 32-bit number Office reads (v139 wrote 2226939960 on bar, column and pie charts), the package
    check refuses one that does not, and fix_deck's renumbering heals it. Workbook: every series stores its name,
    categories and values, and a line on a second axis has its own axis pair, as Excel writes them."""
    t0, name = time.time(), "charts open in Office, draw in any viewer"
    import random
    rnd, lines = random.Random(140), ["Order Date,Region,Category,Units Ordered,Units Shipped,Fill Rate,Net Sales"]
    for i in range(600):
        o = rnd.randint(20, 90); s = round(o * rnd.uniform(.8, .98))
        lines.append(f"2026-{1 + i % 12:02d}-{1 + i % 28:02d},{rnd.choice(['West', 'South', 'Southeast', 'Northeast'])},"
                     f"{rnd.choice(['Fragrance', 'Skincare', 'Cosmetics', 'Haircare'])},{o},{s},{s / o:.4f},{s * rnd.uniform(28, 40):.2f}")
    (w / "fill.csv").write_text("\n".join(lines) + "\n")
    deck, book, bad = None, None, []                     # ULTA SlideGlam: chart decks only (no dashboard, no workbook)
    import data_slides, ooxml_check
    from pptx import Presentation
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE
    prs = Presentation(); sl = prs.slides.add_slide(prs.slide_layouts[6])
    cd = CategoryChartData(); cd.categories = ["West", "South", "East"]; cd.add_series("Net Sales", (3.0, 2.0, 1.0))
    kinds = sorted(set(data_slides.CHART_TYPES.values()))     # every chart the decks draw, as python-pptx makes it
    for k in kinds:
        data_slides.fix_axis_ids(sl.shapes.add_chart(getattr(XL_CHART_TYPE, k), 0, 0, 3000000, 2000000, cd))
    prs.save(w / "kinds.pptx")
    import privacy
    privacy.scrub(w / "kinds.pptx")                      # not python-pptx's template author and 2013 date
    ids = []
    for f in [w / "kinds.pptx"] + ([deck] if deck else []):
        with zipfile.ZipFile(f) as z:
            ids += [int(v) for n in z.namelist() if re.match(r"ppt/charts/chart\d+\.xml$", n)
                    for v in re.findall(r'<c:(?:axId|crossAx) val="(-?\d+)"', z.read(n).decode("utf-8"))]
    if not ids or not all(0 <= v <= 2147483647 for v in ids):
        bad.append(f"axis id {max(ids, default='none')} (PowerPoint reads 0 to 2147483647)")
    with zipfile.ZipFile(w / "kinds.pptx") as z:          # a deck as v139 wrote it: the check refuses it, the fix heals it
        items, infos = {n: z.read(n) for n in z.namelist()}, {n: z.getinfo(n) for n in z.namelist()}
    bar = next(n for n in sorted(items) if re.match(r"ppt/charts/chart\d+\.xml$", n) and b"<c:barChart>" in items[n])
    first = re.search(rb'<c:axId val="(\d+)"', items[bar])[1]
    items[bar] = re.sub(rb'(<c:(?:axId|crossAx) val=")' + first + rb'(")', rb"\g<1>2226939960\2", items[bar])
    with zipfile.ZipFile(w / "kinds-v139.pptx", "w", zipfile.ZIP_DEFLATED) as zo:
        for n, d in items.items():
            zo.writestr(infos[n], d)
    if not any("beyond what PowerPoint reads" in l for l in ooxml_check.summary(w / "kinds-v139.pptx", 3)):
        bad.append("the package check lets an axis id above 2147483647 through")
    elif not data_slides.fix_chart_files(w / "kinds-v139.pptx") or ooxml_check.summary(w / "kinds-v139.pptx", 1):
        bad.append("fix_deck's renumbering does not heal it")
    cp, combo = [], ["-", "-"]
    if book:
      with zipfile.ZipFile(book) as zb:
        cp = ulta_excel.cache_problems(zb)
        combo = [x for x in (zb.read(n).decode("utf-8") for n in zb.namelist() if re.match(r"xl/charts/chart\d+\.xml$", n))
                 if "<lineChart>" in x and "<barChart>" in x]
    if cp:
        bad.append("workbook " + cp[0])
    if len(combo) < 2:
        bad.append(f"{len(combo)} combo charts in the workbook (the fill rate line and the Pareto line)")
    return (name, not bad, "READY" if not bad else "-",
            f"deck: {len(kinds)} chart kinds with axis ids PowerPoint reads, a v139 deck refused and healed"
            if not bad else "BAD " + "; ".join(bad)[:200], round(time.time() - t0, 1))


def bq_demo(w):
    """Dashboards from the demo BigQuery project (v141; asked: connect dashboards to a dummy BigQuery with synthetic data):
    BigQuery's own SQL (backticked paths, DATE literals, DATE_TRUNC, INTERVAL, SAFE_DIVIDE, COUNTIF, QUALIFY, CAST rounding,
    INFORMATION_SCHEMA) gives the answers the stored rows give; what the demo cannot run, or would change data, stops with a
    message; a dashboard, deck and workbook built with --bq name the source as synthetic, keep the SQL (deck notes, the
    workbook's Notes, <Name>.dashboard.json) and --view runs it again to the same numbers."""
    t0, name, bad = time.time(), "dashboards from the demo BigQuery project", []
    import bq_demo as BQ
    con, meta = BQ.project()
    raw = lambda sql: con.execute(sql).fetchone()[0]
    try:
        _, r, _ = BQ.query("SELECT ROUND(SUM(net_sales), 2) AS s, COUNT(DISTINCT DATE_TRUNC(order_date, MONTH)) AS months, 7 / 2 AS half, "
                           "CAST(2.5 AS INT64) AS up, SAFE_DIVIDE(1, 0) AS z FROM `ulta-demo.retail.sales_flat`")
        if r[0] != [round(raw('SELECT SUM(net_sales) FROM "retail.sales"'), 2), 22, 3.5, 3, None]:
            bad.append(f"totals, months or arithmetic differ: {r[0]}")
        _, r, _ = BQ.query("SELECT region, store_name FROM retail.sales_flat GROUP BY 1, 2 "
                           "QUALIFY ROW_NUMBER() OVER (PARTITION BY region ORDER BY SUM(net_sales) DESC) = 1")
        _, r2, _ = BQ.query("SELECT COUNTIF(loyalty_member) AS m FROM retail.sales WHERE order_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY)")
        if len(r) != 5 or r2[0][0] != raw("SELECT SUM(loyalty_member) FROM \"retail.sales\" WHERE order_date >= '2026-08-03'"):
            bad.append("QUALIFY or COUNTIF over the last 90 days is off")
        _, r, _ = BQ.query("SELECT table_name FROM `ulta-demo.supply.INFORMATION_SCHEMA.TABLES` WHERE table_type = 'VIEW' ORDER BY 1")
        if [x[0] for x in r] != ["po_otif", "replenishment_flat"]:
            bad.append(f"INFORMATION_SCHEMA.TABLES lists {r}")
    except BQ.BQError as e:
        bad.append(f"a supported query failed: {e}")
    for sql, want in (("DELETE FROM retail.sales WHERE TRUE", "SELECT queries only"), ("SELECT * FROM `other-project.retail.sales`", "Not found: Project"),
                      ("SELECT ARRAY_AGG(state) FROM retail.stores", "not in the demo")):
        try:
            BQ.query(sql); bad.append(f"ran: {sql}")
        except BQ.BQError as e:
            if want not in str(e):
                bad.append(f"unclear refusal: {e}")
    sql = ("SELECT order_date, order_id, channel, region, state, category, units, net_sales, gross_margin "
           "FROM `ulta-demo.retail.sales_flat` WHERE order_date >= DATE '2026-02-01'")
    r = subprocess.run([PY, "-I", str(T / "dashboard.py"), "build", "--bq", sql, "--out", str(w / "bqdash"), "--title", "Fiscal 2026 sales",
                        "--deck", "--excel"], capture_output=True, text=True, cwd=w, timeout=900)
    out = r.stdout + r.stderr
    if not re.search(r"^READY", out, re.M) or "deck: READY" not in out or "workbook: READY" not in out:
        bad.append("not READY: " + (out.strip().splitlines() or ["no output"])[-1][:100])
    else:
        page = (w / "bqdash.html").read_text(encoding="utf-8")
        v = json.loads((w / "bqdash.dashboard.json").read_text())
        from pptx import Presentation
        notes = Presentation(w / "bqdash.pptx").slides[1].notes_slide.notes_text_frame.text
        import openpyxl
        nb = openpyxl.load_workbook(w / "bqdash.xlsx", read_only=True)["Notes"]
        kept = {str(x[0]): str(x[1]) for x in nb.iter_rows(min_row=3, max_row=8, values_only=True) if x[0]}
        if "BigQuery demo project (synthetic data)" not in page or "SQL: SELECT" not in notes or not kept.get("Query", "").startswith("SELECT"):
            bad.append("the page, deck notes or workbook Notes do not name the source and keep the SQL")
        if not v.get("bq") or v["bq"][0].get("sql") != sql:
            bad.append("the saved view does not keep the SQL")
        r2 = subprocess.run([PY, "-I", str(T / "dashboard.py"), "build", "--view", str(w / "bqdash.dashboard.json"), "--out", str(w / "bqdash2")],
                            capture_output=True, text=True, cwd=w, timeout=900).stdout
        rows = lambda s: re.findall(r"^SOURCE: .*?([\d,]+) rows", s, re.M)
        if not rows(r2) or rows(r2) != rows(out) or not re.search(r"^READY", r2, re.M):
            bad.append(f"--view did not run the saved query again ({rows(out)} vs {rows(r2)})")
    return (name, not bad, "READY" if not bad else "-",
            f"{meta['rows']['retail.sales']:,} order lines built in {meta['built']} s; BigQuery SQL answers as the rows do; unsupported and "
            "data-changing queries refused; page, deck and workbook name the synthetic source and keep the SQL; --view runs it again"
            if not bad else "BAD " + "; ".join(bad)[:200], round(time.time() - t0, 1))


WAYS = {"stairs": "stair", "chevrons": "chevron", "pyramid": "pyramid layer", "curve": "curve line", "rings": "ring", "hub": "hub", "house": "house roof", "cards": "tile"}


def story_ways(w):
    """Ways to tell a story (v139; asked for: "instead of 1, 2, 3, climbing steps... several ways of storytelling"): the same journey
    as stairs, arrows, a pyramid, a rising curve or widening rings, its parts around a hub, on a house's pillars or as tiles - each
    block in every theme, format and Ulta look draws its shapes with every word whole and readable and nothing left out; on the Ulta
    theme a journey leads in the light orange run with dark names; the make tool keeps an item's pictogram, a timeline's words, half rows
    and the look, and builds one slide whose shapes carry their gradients; the page's own engine draws it as Python does."""
    t0, name = time.time(), "ways to tell a story"
    kit = T.parent / "modules" / "ultabranddeliverables" / "scripts" / "kit"
    for p_ in (kit, kit / "infographic"):
        if str(p_) not in sys.path:
            sys.path.insert(0, str(p_))
    import info as IG, io, contextlib
    stages = [{"when": "Stage 01", "title": "Foundational", "text": "Establish governed patterns, tools and delivery foundations."},
              {"when": "Stage 02", "title": "Operational", "text": "Embed the capabilities in daily workflows and support."},
              {"when": "Stage 03", "title": "Scaled", "text": "Expand adoption through orchestrated, autonomous use cases."}]
    parts = [{"title": t, "text": x} for t, x in (("Shared tools", "One governed way to reach systems."), ("Approved patterns", "Architecture that is reviewed once."),
                                                   ("Roadmap", "Priorities everyone can see."), ("Builder agents", "Code assist and knowledge help."),
                                                   ("Monitoring", "Logs read and errors explained."), ("Orchestration", "Multi-step work with guardrails."))]
    msg = {"type": "takeaway", "text": "Scale responsibly: human oversight, policy-based autonomy and auditable actions.", "icon": "target"}
    bad, n = [], 0
    for t, shape in WAYS.items():
        b = dict({"type": t, "title": "Adoption journey"}, items=stages if t in ("stairs", "chevrons", "pyramid", "curve", "rings") else parts)
        if t == "hub": b["center"] = "AI adoption"
        if t == "house": b.update(roof="Accelerate responsible adoption, from trusted foundations to scale.", base=msg["text"])
        spec = {"title": "One story, many ways", "subtitle": "The same content in another shape", "blocks": [b] + ([msg] if t != "house" else [])}
        for fmt in IG.FORMAT_ORDER:
            for th in IG.THEME_ORDER:
                for lk in (IG.LOOKS if th == "ulta" else ("light",)):
                    err = io.StringIO()
                    with contextlib.redirect_stderr(err):
                        d = IG.layout(dict(spec, format=fmt, theme=th, look=lk))
                    n += 1; at = f"{t} {fmt} {th}{'/' + lk if th == 'ulta' else ''}"
                    if not any(e.get("name") == shape for e in d["els"]):
                        bad.append(f"{at}: no {shape} drawn")
                    if [x for x in d["warnings"] if "left out" in x] or "CUT" in err.getvalue():
                        bad.append(f"{at}: text cut or a block left out")
                    if IG.readable_report(d)[1]:
                        bad.append(f"{at}: words under the contrast bar")
                    if th == "ulta" and lk == "light" and t in ("stairs", "chevrons", "pyramid", "rings"):
                        lead = {c for pair in IG.LIGHT_STAGES for c in pair}
                        shapes = [e for e in d["els"] if e.get("name") == shape]
                        names = {str(e.get("color")).upper() for e in d["els"] if e.get("name") in (shape + " title", "ring title")}
                        if not all(set(e.get("grad") or []) <= lead for e in shapes) or names - {"000000"}:
                            bad.append(f"{at}: the journey does not lead in light orange with dark names")
    spec = {"title": "One story, many ways", "format": "slide", "theme": "ulta", "blocks": [
        {"type": "pyramid", "title": "Adoption journey", "items": [dict(s, icon="layers") for s in stages], "half": True},
        {"type": "list", "title": "What enables it", "items": [dict(p, icon="network") if i == 0 else p for i, p in enumerate(parts)], "half": True},
        {"type": "timeline", "title": "When", "items": stages}]}
    (w / "ways.json").write_text(json.dumps(spec))
    r = subprocess.run([PY, "-I", str(T / "infographic.py"), "make", str(w / "ways.json"), "--out", str(w / "ways")], capture_output=True, text=True, cwd=w, timeout=600)
    made = json.loads((w / "ways-spec.json").read_text()) if (w / "ways-spec.json").exists() else {"blocks": []}
    if not r.stdout.startswith("READY"):
        bad.append("make: " + (r.stdout or r.stderr)[:80])
    bl = made["blocks"]
    if len(bl) != 3 or not (bl[0].get("half") and bl[1].get("half")) or bl[0]["items"][0].get("icon") != "layers" or bl[1]["items"][0].get("icon") != "network" \
            or not bl[2]["items"][0].get("text"):
        bad.append("make dropped a pictogram, a timeline's words or the half rows")
    if (w / "ways.pptx").exists():
        with zipfile.ZipFile(w / "ways.pptx") as z:
            xml = z.read(sorted(n_ for n_ in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n_))[0]).decode("utf-8")
        if not re.search(r"<a:custGeom>.*?</a:custGeom>\s*<a:gradFill", xml, re.S):
            bad.append("the pyramid's layers lost their gradient in the PowerPoint")
    r2 = subprocess.run([PY, "-I", str(T / "infographic.py"), "make", str(w / "ways.json"), "--look", "flat", "--out", str(w / "ways-flat")], capture_output=True, text=True, cwd=w, timeout=600)
    (w / "story.json").write_text(json.dumps({"title": "One story, many ways", "subtitle": "The vision in one line", "theme": "ulta", "blocks": [
        {"type": "steps", "title": "Adoption journey", "items": [{"title": s["title"], "text": s["text"]} for s in stages]},
        {"type": "list", "title": "What enables it", "items": parts}, msg]}))
    r3 = subprocess.run([PY, "-I", str(T / "infographic.py"), "ways", str(w / "story.json"), "--out", str(w / "story-ways")], capture_output=True, text=True, cwd=w, timeout=900)
    from pptx import Presentation
    n_ways = len([l_ for l_ in r3.stdout.splitlines() if re.match(r"\s+\d+\. ", l_)])
    deck = len(Presentation(str(w / "story-ways.pptx")).slides) if (w / "story-ways.pptx").exists() else 0
    if not r3.stdout.startswith("READY") or n_ways < 8 or deck != n_ways + 1 or "PICTURE" not in r3.stdout or not (w / "story-ways-2.json").exists():
        bad.append(f"ways: {n_ways} ways, a deck of {deck} slides: " + (r3.stdout or r3.stderr)[:60])
    flat = json.loads((w / "ways-flat-spec.json").read_text()) if (w / "ways-flat-spec.json").exists() else {}
    if not r2.stdout.startswith("READY") or flat.get("look") != "flat":
        bad.append("the flat look did not build")
    same = None
    if (w / "ways.html").exists():
        t_, data, assets = _page_parts(w / "ways.html")
        js = _page_engine("info", data, assets, w)
        py_svgs = data["svg"].split('<div class="pgap"></div>')
        same = None if js is None else len(js) == len(py_svgs) and all(_svg_norm(a) == _svg_norm(b) for a, b in zip(js, py_svgs))
        if same is False:
            bad.append("the page's engine draws the new blocks differently from Python")
    eng = "the page's engine draws them as Python does" if same else "node not here: engine parity checked when the skill is built"
    return (name, not bad, "READY" if not bad else "-",
            f"{len(WAYS)} blocks in {n} designs (themes, formats, Ulta looks): shapes drawn, no cut or dropped text, every word readable, the journey "
            f"leads in light orange; make keeps pictograms, timeline words, half rows and the look, gradients in the PowerPoint; `ways` makes a deck of {n_ways} ways; {eng}"
            if not bad else "BAD " + "; ".join(bad[:4])[:220], round(time.time() - t0, 1))


def one_slide(w):
    """A one-pager PowerPoint is one page (v137; reported: "it always spits out 3 pages"): an infographic as a 16:9 slide is the
    slide alone, a short status report too, and the portrait one-pager is one page; the template's cover and closing slides come
    only with --frame (then cover, the slide, the closing slide, in that order)."""
    t0, name = time.time(), "one-pager is one slide"
    from pptx import Presentation
    spec = json.loads((w / "orange.json").read_text()) if (w / "orange.json").exists() else {"title": "Pickup in two hours", "theme": "ulta",
            "blocks": [{"type": "stats", "items": [{"value": "2 h", "label": "order to pickup"}, {"value": "96%", "label": "on time"}]},
                       {"type": "takeaway", "text": "Open pickup in 40 more stores."}]}
    (w / "one.json").write_text(json.dumps(spec))
    (w / "short-status.md").write_text("# Loyalty App Launch - Weekly Status\nWeek ending: 10/16\nOverall status: Amber\nProject lead: Nadia Wren\n"
                                       "Phase: Build\n\n## Workstreams\n| Workstream | Owner | Status | This week | Next week |\n| --- | --- | --- | --- | --- |\n"
                                       "| Rewards engine | Quinn Hale | Green | Points rules signed off | Load test |\n"
                                       "| App release | Zara Fenn | Amber | 12 beta defects open | Fix top 5 |\n\n"
                                       "## Decision needed\nApprove the 11/01 release date with the top 5 defects fixed.\n", encoding="utf-8")
    runs = {"slide": ([str(T / "infographic.py"), "make", str(w / "one.json"), "--format", "slide", "--out", str(w / "one-slide")], "one-slide.pptx"),
            "page": ([str(T / "infographic.py"), "make", str(w / "one.json"), "--format", "onepager", "--out", str(w / "one-page")], "one-page.pptx"),
            "status": ([str(T / "onepager.py"), "short-status.md", "--template", "status", "--format", "slide", "--out", str(w / "one-status")], "one-status.pptx"),
            "frame": ([str(T / "infographic.py"), "make", str(w / "one.json"), "--format", "slide", "--frame", "--out", str(w / "one-frame")], "one-frame.pptx")}
    n, bad = {}, []
    for k, (cmd, f) in runs.items():
        r = subprocess.run([PY, "-I"] + cmd, capture_output=True, text=True, cwd=w, timeout=600)
        if not r.stdout.startswith("READY") or not (w / f).exists():
            bad.append(f"{k}: not built ({(r.stdout or r.stderr)[:60]})"); continue
        n[k] = Presentation(str(w / f)).slides
    for k in ("slide", "page", "status"):
        if k in n and len(n[k]) != 1:
            bad.append(f"{k}: {len(n[k])} slides, not one")
    if "frame" in n:
        said = [" ".join(sh.text_frame.text.split()) for s_ in n["frame"] for sh in s_.shapes if sh.has_text_frame]
        if len(n["frame"]) != 3 or not any("Thank you" in t for t in said):
            bad.append(f"--frame: {len(n['frame'])} slides, the closing slide {'found' if any('Thank you' in t for t in said) else 'missing'}")
    return (name, not bad, "READY" if not bad else "-",
            "a slide, a short status report and a portrait one-pager: one page each; --frame adds the cover and closing slides"
            if not bad else "BAD " + "; ".join(bad)[:200], round(time.time() - t0, 1))


def readable_text(w):
    """Every word readable on what it sits on - 4.5:1, 3:1 from 18 pt, in the colours the files get: each diagram style and
    point graphic, each infographic template on a page and a slide, each theme (a status report too). Words on a gradient
    read at both ends of their line, not only its middle; no dark words on a colour seen as dark (light text there) - but the light
    orange lead's words, marked dark, stay dark: white does not read on its light end (v139). On the built chart deck, words made white on an orange block are
    found by the deck's check and made readable again by the accessibility fix."""
    t0, name = time.time(), "readable text"
    kit = T.parent / "modules" / "ultabranddeliverables" / "scripts" / "kit"
    for p_ in (kit, kit / "infographic", kit / "diagram"):
        if str(p_) not in sys.path:
            sys.path.insert(0, str(p_))
    try:
        import info as IG, templates as TP, slide_diagram as SD, build_deck as BD, a11y
    except Exception as e:
        return (name, False, "CRASH", f"{type(e).__name__}: {e}"[:90], round(time.time() - t0, 1))
    seen, bad, graded = [0], [], [0]
    def look(label, d, bg=None):
        seen[0] += 1
        bad.extend(f"{label}: '{x[0][:24]}' {x[3]}:1" for x in IG.readable_report(d, bg)[1][:1])
        for p in [d] + list(d.get("pages") or []):   # texts on a gradient: judged at the ends of their line as well
            for i, e in enumerate(p["els"]):
                said = "".join(e.get("lines") or []).strip()
                if e.get("k") != "text" or not said:
                    continue
                gs = IG._grounds(p["els"], i, e, bg or p.get("bg") or "FFFFFF", IG.brand_fill)[0]
                graded[0] += len(gs) > 1
                col = IG.brand_text(str(e.get("color") or IG.INK).upper())   # dark words on a colour seen as dark: light text there
                if said not in IG.DOTS and not e.get("dark") and any(IG._light_better(u) and IG._apca(col, u) > 0 for u in gs):   # the light lead's words stay dark (v139)
                    bad.append(f"{label}: '{said[:24]}' dark #{col} on #{gs[0]}")
    for st in BD.STYLE_ORDER:
        lines = BD.STYLE_EXAMPLES.get(st, BD.STYLE_EXAMPLES["_landscape"])
        look(f"diagram {st}", SD.build(SD.arrow_lines(lines) if isinstance(lines, list) else lines, "Order platform", style=st)[0], SD.SLIDE_BG)
    for g, items in BD.GRAPHIC_EXAMPLES.items():
        nodes = [{"id": f"n{k}", "label": it.split(":")[0].strip(), "sub": it.split(":", 1)[1].strip() if ":" in it else ""}
                 for k, it in enumerate(items)]
        look(f"graphic {g}", SD.layout({"nodes": nodes, "flows": [], "from": "points"}, style=g), SD.SLIDE_BG)
    for tid in [x["id"] for x in TP.T]:
        for fmt in ("onepager", "slide"):
            look(f"{tid} {fmt}", IG.layout(TP.sample_spec(tid, fmt)))
    for th in ("ulta", "glow", "velvet", "frost", "paper", "sunset", "charcoal"):
        look(f"theme {th}", IG.layout(IG.sample_spec("onepager", th)))
        look(f"status {th}", IG.layout(IG.status_spec(IG.STATUS_TEMPLATE_MD, "onepager", th)))
    if not graded[0]:
        bad.append("no text on a gradient was checked - the Ulta theme draws its cards in gradients")
    if a11y.B.DEEPEN != IG.DEEPEN:                   # the deck pass and the drawing engine take a block to the same deep colour
        bad.append("the deck pass and the drawing engine deepen to different colours (brand.DEEPEN vs info.DEEPEN)")
    deck, said = w / "modern.pptx", "chart deck not built here"
    if deck.exists() and Path(str(deck) + ".ulta.json").exists():
        from lxml import etree
        cp = w / "readable.pptx"
        shutil.copyfile(deck, cp); shutil.copyfile(str(deck) + ".ulta.json", str(cp) + ".ulta.json")
        drawn = set(json.loads(Path(str(cp) + ".ulta.json").read_text()).get("diagram_slides") or [])
        base = {k: v.upper() for k, v in (a11y.B.current().get("theme") or {}).items()}
        with zipfile.ZipFile(cp) as z:
            items, infos, hit = {n: z.read(n) for n in z.namelist()}, {n: z.getinfo(n) for n in z.namelist()}, None
            for i, part in enumerate(a11y.slide_parts(z), 1):
                th = a11y.slide_theme(z, part, base) if i in drawn else None
                x = etree.fromstring(items[part]) if th else None
                for sp in (x.iter(a11y.P + "sp") if th else []):
                    f = a11y.fill_hex(sp, th)
                    runs = [r for r in sp.iter(a11y.A + "rPr") if a11y.run_hex(r, th) and (r.getparent().findtext(a11y.A + "t") or "").strip()]
                    if f and runs and a11y.B.contrast("FFFFFF", f) < 3.5 and all(int(r.get("sz") or 1800) < 1800 for r in runs):
                        for r in runs:
                            a11y._paint(r, "FFFFFF")
                        hit = i
                        items[part] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
                        break
                if hit:
                    break
        with zipfile.ZipFile(cp, "w", zipfile.ZIP_DEFLATED) as z:
            for n, d in items.items():
                z.writestr(infos[n], d)
        found = len(a11y.drawn_text(cp, drawn)[1])
        a11y.fix(cp)
        left = len(a11y.drawn_text(cp, drawn)[1])
        if not hit:
            bad.append("no orange block with words on the chart deck to test with")
        elif not found:
            bad.append("white words on an orange block were not found on the deck")
        elif left:
            bad.append(f"the accessibility fix left {left} hard-to-read text(s)")
        said = f"white words planted on an orange block of the chart deck: found ({found}), fixed"
    return (name, not bad, "READY" if not bad else "-",
            f"{seen[0]} designs, every text 4.5:1 on what it sits on (3:1 from 18 pt), light on dark colours, {graded[0]} on gradients at both ends; {said}"
            if not bad else "BAD " + "; ".join(bad)[:200],
            round(time.time() - t0, 1))


def summary_on_slide(w):
    """The crisp summary on the slide: a takeaway line under the headline, a decision bar above the footer, a context line
    under big numbers and, in pre-read mode, an At a glance slide after the agenda - each only where its layout has clear
    space (nothing it touches), each also in the notes. That deck builds READY 100%. A summary with a number the slide
    does not hold, one over 24 words and one that needs two lines where one fits each FAIL; a cover keeps its summary
    in the notes."""
    t0, name = time.time(), "summary on the slide"
    py = [sys.executable, "-I"]
    items = [{"name": "Data feeds", "group": "Data", "start": "2026-01-05", "end": "2026-04-24", "owner": "Data lead", "status": "done"},
             {"name": "Order engine", "group": "Data", "start": "2026-02-02", "end": "2026-05-29", "owner": "Data lead", "status": "done"},
             {"name": "Pilot stores", "group": "Stores", "start": "2026-03-02", "end": "2026-07-31", "owner": "Store ops", "status": "on track"},
             {"name": "Regional rollout", "group": "Stores", "start": "2026-08-03", "end": "2026-12-18", "owner": "Store ops", "status": "at risk"}]
    cards = [["Today", "Change", "Result"], ["Weekly orders\n\nStores order once a week from a fixed list",
             "Daily orders\n\nOrders follow each day's sales and deliveries", "Fuller shelves\n\nShelf availability rises from 91% to 96% in pilots"]]
    good = {"classification": "internal", "mode": "read",
            "glance": ["Daily orders: shelves fill from 91% to 96% in pilot stores", "Rollout: regions follow from August",
                       "Ask: a second store ops lead for the rollout"],
            "slides": [
        {"source": 1, "title": "Store replenishment review", "summary": "Daily orders keep shelves full"},
        {"source": "agenda-list", "table": [[None, "Why daily orders"], [None, "Results so far"], [None, "Plan and next steps"]]},
        {"source": 7, "headline": "Daily orders cut empty shelves", "table": cards,
         "summary": "Orders follow each day's sales, so pilot shelves fill from 91% to 96%"},
        {"source": "headline-metrics", "headline": "Pilot stores fill shelves faster", "summary": "Twelve weeks in, the pilot stores hold less stock and still fill more shelves",
         "table": [["96%\nShelf availability\nfrom 91%", "-18%\nBackroom stock\n$2.1M less", "2 days\nOrder lead time\nfrom 5 days", "40\nPilot stores\nin 3 regions"]]},
        {"timeline": {"items": items, "today": "2026-06-15", "unit": "month"}, "style": "status-roadmap",
         "headline": "One deliverable at risk: regional rollout", "decision": "Decision: add a second store ops lead for the regional rollout"},
        {"source": 12, "headline": "Four actions keep the rollout on time", "summary": "Budget in June, store teams in July, regions in August, weekly reviews from September",
         "decision": "Ask: approve the pilot budget in June",
         "table": [["What", "Description", "When / Who"], ["Approve budget", "Daily orders for 40 more stores", "Jun 2026 / Steering group"],
                   ["Train store teams", "Two sessions per store before go-live", "Jul 2026 / Store ops"],
                   ["Start the regions", "Two regions, then the rest each month", "Aug 2026 / Store ops"],
                   ["Review weekly", "Shelf availability and stock every Monday", "Sep 2026 / Store ops"]]},
        {"source": "thank-you"}]}
    bad = {"classification": "internal", "slides": [
        {"source": 1, "title": "Store replenishment review"},
        {"source": 7, "headline": "Daily orders cut empty shelves", "table": cards,
         "summary": "Daily orders lift shelf availability by 37% in the pilot stores"},
        {"source": "objectives-scope", "headline": "Three moves take daily orders live",
         "summary": "Pilot stores start in May, the next regions follow once the data feeds are stable and every store manager has completed the training, then all stores move",
         "table": [["Start now", "Next quarter", "By go-live"], ["Pilot daily orders\nTrain store teams", "Connect the data feeds\nAdd two regions", "All stores live\nReview weekly"]]},
        {"source": "objectives-scope", "headline": "Three moves take the plan live",
         "summary": "Pilot stores start ordering daily in May; the remaining regions follow once the automated data feeds hold steady through one complete month",
         "table": [["Start now", "Next quarter", "By go-live"], ["Pilot daily orders\nTrain store teams", "Connect the data feeds\nAdd two regions", "All stores live\nReview weekly"]]},
        {"source": "thank-you"}]}
    (w / "summary.json").write_text(json.dumps(good)); (w / "summary-bad.json").write_text(json.dumps(bad))
    r = subprocess.run(py + [str(T / "build_deck.py"), "build", str(w / "summary.json"), "--out", str(w / "summary.pptx")],
                       capture_output=True, text=True, cwd=w, timeout=900)
    rb = subprocess.run(py + [str(T / "build_deck.py"), "build", str(w / "summary-bad.json"), "--out", str(w / "summary-bad.pptx")],
                        capture_output=True, text=True, cwd=w, timeout=900)
    out, bad_out, why = r.stdout + r.stderr, rb.stdout + rb.stderr, []
    if not (re.search(r"^READY", out, re.M) and "Standards Match 100%" in out):
        why.append("the deck is not READY 100%: " + next((l.strip() for l in out.splitlines() if "FAIL" in l or "Traceback" in l), out[-120:]))
    else:
        from pptx import Presentation
        import build_deck as BD
        IN = 914400
        prs = Presentation(str(w / "summary.pptx"))
        sl = list(prs.slides)
        def text_of(s_):                               # text boxes and table cells, spaces as a reader sees them
            return " ".join(" ".join((sh.text_frame.text if sh.has_text_frame else " ".join(c.text for row in sh.table.rows
                            for c in row.cells) if sh.has_table else "").split()) for sh in s_.shapes)
        def clear(s_, x):                              # nothing a reader sees overlaps the line or the bar
            prev = x._element.getprevious()
            for o in s_.shapes:
                if o._element is x._element or o._element is prev or o.top is None or not o.width:
                    continue
                if o.is_placeholder and any(k in str(o.placeholder_format.type) for k in ("SLIDE_NUMBER", "FOOTER", "DATE")):
                    continue
                if o.has_text_frame and not o.text_frame.text.strip() and not BD._filled(o):
                    continue
                if o.left < x.left + x.width and x.left < o.left + o.width and o.top < x.top + x.height and x.top < o.top + o.height:
                    return False
            return True
        named = lambda s_, nm: next((sh for sh in s_.shapes if sh.name == nm), None)
        if len(sl) != 8 or not text_of(sl[2]).startswith("At a glance"):
            why.append("no At a glance slide after the agenda")
        for k, spec in ((3, good["slides"][2]), (4, good["slides"][3]), (6, good["slides"][5])):
            x = named(sl[k], "ULTA summary")
            prev = x._element.getprevious() if x is not None else None
            if x is None:
                why.append(f"slide {k + 1}: no takeaway line"); continue
            said = " ".join("".join(t.text or "" for t in prev.iter() if t.tag.endswith("}t")).split()) if prev is not None else ""
            if spec["headline"].lower() not in said.lower():
                why.append(f"slide {k + 1}: the takeaway line does not follow its headline")
            if not clear(sl[k], x):
                why.append(f"slide {k + 1}: the takeaway line overlaps the slide")
            if not sl[k].notes_slide.notes_text_frame.text.startswith("Takeaway: "):
                why.append(f"slide {k + 1}: the takeaway is not in the notes")
        for k in (5, 6):                               # a drawn timeline and a template table
            x = named(sl[k], "ULTA decision")
            if x is None or not clear(sl[k], x) or x.top + x.height > int(6.4 * IN):
                why.append(f"slide {k + 1}: " + ("no decision bar" if x is None else "the decision bar is not clear of the slide"))
        if "from 5 days" not in text_of(sl[4]):
            why.append("no context line under the big numbers")
        if "takes no summary line" not in out or "Takeaway: Daily orders keep shelves full" not in sl[0].notes_slide.notes_text_frame.text:
            why.append("the cover's summary is not kept in its notes")
    for k, want in (("a new number", "says 37%"), ("over 24 words", "words - one crisp sentence"), ("two lines", "needs two lines")):
        if want not in bad_out:
            why.append(f"{k} in a summary is not a FAIL")
    if re.search(r"^READY", bad_out, re.M):
        why.append("the deck with bad summaries is READY")
    ok = not why
    return (name, ok, "READY" if ok else "-",
            "takeaway lines under 3 headlines, decision bars on a drawn and a template slide, context under big numbers, "
            "At a glance after the agenda: READY 100%; a new number, 27 words and a two-line summary FAIL"
            if ok else "BAD " + "; ".join(why)[:220], round(time.time() - t0, 1))


def expert_review(w):
    """The presentation expert's review (tools/deck_expert.py): on a storyboard written as text it names the picture each
    slide's content asks for - figures as big numbers, dates as a timeline, shares as a donut, risks in the risk table,
    steps as a flow, system flows as a diagram, before and after with context, actions in the action table - and asks for
    the answer up front; on a well-made storyboard it finds nothing to change; it counts the source document's figures
    that reached the slides, the notes or nothing; and every deck build prints it."""
    t0, name = time.time(), "expert review"
    try:
        import deck_expert as DX
    except Exception as e:
        return (name, False, "CRASH", f"{type(e).__name__}: {e}"[:90], round(time.time() - t0, 1))
    text = {"classification": "internal", "slides": [
        {"source": 1, "title": "Store replenishment review for the steering group"},
        {"source": 44, "table": [[None, "Why change"], [None, "Results"], [None, "Plan"]]},
        {"bullets": ["Shelf availability: 96% in pilot stores", "Backroom stock: down 18%", "Order lead time: 2 days, from 5",
                     "Pilot: 40 stores"], "headline": "Pilot stores fill shelves faster"},
        {"bullets": ["Discovery: Jan 2026", "Pilot design: Mar 2026", "Pilot live: May 2026", "Regional rollout: Aug 2026",
                     "All stores: Jan 2027"], "headline": "Daily orders reach every store by 2027"},
        {"bullets": ["Cosmetics: 38% of stock", "Skincare: 24% of stock", "Haircare: 16% of stock", "Fragrance: 14%", "Other: 8%"],
         "headline": "Cosmetics holds the most stock"},
        {"bullets": ["Data gaps: a risk to the forecast; mitigate with a data owner per domain",
                     "Store adoption: a risk in busy weeks; mitigate with coaching",
                     "Vendor delay: a risk to rollout; mitigate with phase gates"], "headline": "Three risks need owners"},
        {"bullets": ["Sense: sales land daily", "Forecast: item by store", "Review: planners clear exceptions",
                     "Order: stores order daily"], "headline": "Daily orders run in four steps"},
        {"bullets": ["Store POS -> Data platform: daily sales", "Data platform -> Order engine: forecast",
                     "Order engine -> ERP: purchase orders"], "headline": "Three systems carry each order"},
        {"source": 6, "headline": "Shelves stay fuller with daily orders",
         "text": ["Availability rose from 91% to 96% in 12 weeks", "Backroom stock fell from $11.6M to $9.5M"]},
        {"bullets": ["Approve the budget: Jun 2026, steering group", "Train store teams: Jul 2026, store ops lead",
                     "Start the regions: Aug 2026, store ops lead"], "headline": "Three actions keep the rollout on time"},
        {"source": 32}]}
    want = {3: "big numbers", 4: "a timeline", 5: "a donut", 6: "the risk table", 7: "a flow", 8: "a diagram",
            9: "big numbers with a context line", 10: "the action table"}
    found = {}
    for k, spec in enumerate(text["slides"], 1):
        sg = DX.suggest(spec, k, DX.consts())
        if sg:
            found[k] = sg[1]
    bad = [f"slide {k}: {found.get(k, 'nothing')} (wanted {v})" for k, v in want.items() if found.get(k) != v]
    lines = DX.review(text, text["slides"])
    if not any("open with the answer" in l for l in lines):
        bad.append("no 'open with the answer' on a deck without an opening summary")
    good = json.loads((w / "summary.json").read_text()) if (w / "summary.json").exists() else None
    if good:
        import build_deck as BD
        gl, _ = BD.glance(good, [dict(x) for x in good["slides"]])
        for x in gl:
            if isinstance(x.get("source"), str) and BD.LAYOUTS:
                r_ = BD.FT.resolve(x["source"])
                x["source"] = r_ if isinstance(r_, int) else x["source"]
        head = DX.review(good, gl)[0]
        if "0 slide(s) with a better picture" not in head:
            bad.append("a well-made deck got upgrades: " + head[:80])
    (w / "source.md").write_text("Accuracy rose from 72% to 80%. Margin is up 80 bps. Inventory fell by $60M. Turns are 3.4x.")
    cover = DX.source_coverage(w / "source.md", [{"headline": "Accuracy 72% to 80%", "summary": "Margin up 80 bps",
                                                  "notes": "Inventory fell by $60M."}])
    if not cover or "3 of 5 figures" not in cover or "1 only in the notes" not in cover or "1 nowhere (3.4x)" not in cover:
        bad.append(f"source figures miscounted: {cover}")
    (w / "parts.md").write_text(
        "## Why change\nMerchandising and finance plan in separate spreadsheet files that rarely match. Forecasts refresh once a "
        "month and miss promotions, local events and online demand shifts. Planners spend most of the week reconciling files.\n"
        "## Targets\nForecast accuracy rises from 72% to 80% by item and week. Gross margin rises from 38.6% to 39.4% on fewer "
        "markdowns. Inventory falls from $1.20B to $1.14B and the plan cycle from 21 days to 10 days.\n"
        "## Risks\nVendor timelines slip without fixed-scope phases and exit gates. Promotions skew the baseline unless their "
        "lift is modelled separately. Data quality gaps delay the forecast without named domain owners and a weekly score.\n")
    parts = DX.section_coverage(w / "parts.md", [
        {"headline": "Accuracy 72% to 80%, margin 38.6% to 39.4%", "summary": "Inventory $1.20B to $1.14B; plan cycle 21 to 10 days",
         "notes": "Today merchandising and finance reconcile separate spreadsheet files; forecasts miss promotions and local events."}])
    got = {t: ("notes" if nt >= 0.5 else "nowhere") for t, on, nt in parts}
    if got != {"Why change": "notes", "Risks": "nowhere"}:
        bad.append(f"source parts misjudged: {got}")
    log = w / "summary_validation" / "build-log.txt"
    if log.exists() and "EXPERT REVIEW:" not in log.read_text():
        bad.append("the deck build printed no EXPERT REVIEW")
    from pptx import Presentation                       # 40 words at 8 pt on a slide: too small to read in a room
    from pptx.util import Inches, Pt
    prs = Presentation()
    sl = prs.slides.add_slide(prs.slide_layouts[6])
    tb = sl.shapes.add_textbox(Inches(1), Inches(1), Inches(6), Inches(3))
    r = tb.text_frame.paragraphs[0].add_run()
    r.text = " ".join(["word"] * 40); r.font.size = Pt(8)
    prs.save(str(w / "small-type.pptx"))
    card = lambda n_: {"scorecard": {"groups": [{"name": "All", "kpis": [[f"KPI {i}", "1", "2", "3", "green"] for i in range(n_)]}]}}
    small = DX.small_text(w / "small-type.pptx", [card(10)])
    if not small or "40 words under 10 pt" not in small[0] or "6-8 KPIs" not in small[0]:
        bad.append(f"small type not found: {small}")
    if DX.small_text(w / "small-type.pptx", [card(8)]):
        bad.append("a scorecard of 8 KPIs was told to show 6-8 KPIs")
    (w / "small-type.pptx").unlink()
    deck = [{"source": "cover-photo", "title": "Planning review"},                  # the build's own At a glance slide is the
            {"bullets": ["Answer: accuracy 72% to 80%", "Value: $60M freed", "Ask: approve the 12-week pilot"],   # takeaway;
             "headline": "Approve the pilot", "_glance": True},                         # one photo twice reads as a repeat
            {"source": "divider-photo", "title": "Where we are"}, {"quad": ["80%\nForecast accuracy", "$60M\nFreed"], "headline": "Accuracy and cash both improve"},
            {"source": "divider-photo", "title": "Next steps"}, {"source": 12, "headline": "Two decisions keep the plan on time",
             "table": [["What", "Description", "When / Who"], ["Approve pilot", "Two categories, 12 weeks", "Nov / Steering group"]]}]
    rv = DX.review({"slides": deck}, deck)
    if any(l.startswith("EXPERT context: slide 2 ") for l in rv):
        bad.append("the At a glance slide was asked for a takeaway line")
    if not any("slides 3 and 5 show the same photo (divider-photo)" in l for l in rv):
        bad.append("a photo used twice was not named: " + " / ".join(rv)[:120])
    ok = not bad
    return (name, ok, "READY" if ok else "-",
            f"{len(want)} text slides each given its picture, the answer asked up front, a well-made deck left alone, "
            "source figures and parts counted on slides, notes and nowhere, small type found (8 KPIs left alone), the At a "
            "glance slide not asked for a takeaway, a photo used twice named" if ok else "BAD " + "; ".join(bad)[:220],
            round(time.time() - t0, 1))


def ui_screens(w):
    """UI screens: the worked example builds READY with every file (pictures, PDF, PowerPoint, the page) and its brand
    check runs to the end with the pictures among the files; the page's engine draws the screens as Python does (with
    node); a page the user edited rebuilds with the edit."""
    t0, name = time.time(), "UI screens (edit, rebuild)"
    py = [sys.executable, "-I"]
    r = subprocess.run(py + [str(T / "ui_screens.py"), "sample", "--out", str(w / "screens")], capture_output=True, text=True, cwd=w, timeout=900)
    files = [w / f for f in ("screens.html", "screens.png", "screens-2.png", "screens-3.png", "screens.pdf", "screens.pptx")]
    if not r.stdout.startswith("READY") or not all(f.exists() for f in files):
        miss = [f.name for f in files if not f.exists()]
        return (name, False, "-", f"BAD {r.stdout[:70]} {'missing ' + ', '.join(miss) if miss else ''}", round(time.time() - t0, 1))
    c = subprocess.run(py + [str(T / "ulta_conform.py"), str(w / "screens.png"), str(w / "screens.pdf"), "--keep-sizes"],
                       capture_output=True, text=True, cwd=w, timeout=300)
    conf = c.stdout + c.stderr
    with zipfile.ZipFile(w / "screens.pptx") as z:       # the label is the brand check's last step: it ran to the end
        label = "MSIP_Label" in (z.read("docProps/custom.xml").decode() if "docProps/custom.xml" in z.namelist() else "")
    if "RESULT: PASS" not in conf or not label:
        return (name, False, "-", "BAD the brand check stopped on the screen pictures: "
                + (conf.strip().splitlines() or ["no output"])[-1][:120] if "RESULT: PASS" not in conf
                else "BAD the screens' PowerPoint has no sensitivity label: the build's brand check did not run to the end",
                round(time.time() - t0, 1))

    def change(data):
        data["spec"]["app"] = "Store Ops Portal"
    _saved_edit(w / "screens.html", w / "screens-edited.html", change)
    r2 = subprocess.run(py + [str(T / "ui_screens.py"), "build", str(w / "screens-edited.html"), "--out", str(w / "screens2")],
                        capture_output=True, text=True, cwd=w, timeout=900)
    spec = json.loads((w / "screens2-spec.json").read_text()) if (w / "screens2-spec.json").exists() else {}
    page = (w / "screens.html").read_text(encoding="utf-8", errors="ignore")
    editor = all(x in page for x in ("root.UltaScreens", "root.UltaPage", 'data-act="addblock"', 'data-act="bdel"', 'data-act="taddrow"', 'id="editBtn"'))
    _, data, assets = _page_parts(w / "screens.html")
    js = _page_engine("screens", data, assets, w)
    same = None if js is None else len(js) == len(data["svgs"]) and all(_svg_norm(a) == _svg_norm(b) for a, b in zip(js, data["svgs"]))
    ok = r2.stdout.startswith("READY") and spec.get("app") == "Store Ops Portal" and editor and same is not False
    why = (f"rebuild: {r2.stdout[:60]}" if not r2.stdout.startswith("READY") or spec.get("app") != "Store Ops Portal"
           else "the page has no block editor (engine, add / remove block, table rows)" if not editor
           else "the page's engine draws the screens differently from Python: " + str(js[0])[:60])
    eng = "the page's engine draws them as Python does" if same else "node not here: engine parity checked when the skill is built"
    return (name, ok, "READY" if ok else "-", f"3 screens, every file, the brand check run to the end with the pictures; {eng}; "
            "a page that adds, removes and changes blocks; an edited page rebuilds"
            if ok else "BAD " + why, round(time.time() - t0, 1))


def classified_swap(w):
    """Other ways to show a slide in an 'Internal' deck: the option is built with the deck's classification, the
    swap reuses the deck's own layouts (no second copy of the template) and the deck stays READY."""
    t0, name = time.time(), "swap in a classified deck"
    (w / "classified.json").write_text(json.dumps({"classification": "internal", "slides": [
        {"source": 1, "title": "Classified deck"},
        {"source": 7, "headline": "KPIs connect planning to execution", "table": [["Sales", "Margin", "Inventory"],
            ["Net sales", "Gross margin %", "Inventory turns"], ["Sales vs plan\n\nComp growth", "Markdown rate\n\nIMU", "Weeks of supply\n\nSell-through"]]},
        {"source": "thank-you"}]}))
    (w / "classified-opts.json").write_text(json.dumps({"options": [{"id": "A", "label": "Three columns", "slide": {
        "source": "objectives-scope", "headline": "KPIs connect planning to execution", "table": [["Sales", "Margin", "Inventory"],
            ["Net sales\nSales vs plan\nComp growth", "Gross margin %\nMarkdown rate\nIMU", "Inventory turns\nWeeks of supply\nSell-through"]]}}]}))
    py = [sys.executable, "-I"]
    steps = [[T / "build_deck.py", "build", w / "classified.json", "--out", w / "classified.pptx"],
             [T / "slide_options.py", "preview", w / "classified.pptx", "--slide", "2", "--options", w / "classified-opts.json", "--out", w / "classified-o"],
             [T / "slide_options.py", "apply", w / "classified.pptx", "--session", w / "classified-o", "--choice", "A", "--out", w / "classified-v2.pptx"]]
    out = ""
    for st in steps:
        r = subprocess.run(py + [str(x) for x in st], capture_output=True, text=True, cwd=w, timeout=900)
        out = r.stdout + r.stderr
    f = w / "classified-v2.pptx"
    if not f.exists() or not re.search(r"^READY", out, re.M):
        return (name, False, "-", "BAD " + (next((l for l in out.splitlines() if "FAIL" in l), out.strip()[-80:]) or "no result")[:80],
                round(time.time() - t0, 1))
    z = zipfile.ZipFile(f)
    masters = [n for n in z.namelist() if re.match(r"ppt/slideMasters/[^/]+\.xml$", n)]
    from pptx import Presentation
    s2 = Presentation(str(f)).slides[1]
    foot = " ".join(sh.text_frame.text for sh in list(s2.shapes) + list(s2.slide_layout.shapes)
                    if sh.has_text_frame and "|" in sh.text_frame.text)
    ok = "Internal Use Only" in foot and "Confidential" not in foot and not any("option-" in m for m in masters)
    return (name, ok, "READY" if ok else "-", "footer 'Internal Use Only', the deck's own layout, READY" if ok else
            f"BAD footer {foot[:40]!r}, {len(masters)} masters", round(time.time() - t0, 1))


def isolated_paths():
    """python -I leaves the script's folder off sys.path: every tool that imports a sibling puts its own folder there at
    module level (a path set inside one function misses the helpers called before it)."""
    import ast
    mods = {p.stem for p in T.glob("*.py")}
    def sets_path(nodes):
        for n in nodes:
            if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and ast.unparse(n.value.func) in ("sys.path.insert", "sys.path.append"):
                return True
            if isinstance(n, (ast.If, ast.For)) and sets_path(n.body):
                return True
        return False
    bad = []
    for p in sorted(T.glob("*.py")):
        tree = ast.parse(p.read_text(encoding="utf-8"))
        names = {a.name.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names} | \
                {n.module.split(".")[0] for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module and not n.level}
        if (names & mods) - {p.stem} and not sets_path(tree.body):
            bad.append(p.name)
    return ("isolated runs (python -I)", not bad, "-", "every tool finds its sibling modules" if not bad else
            "BAD no module-level path for: " + ", ".join(bad[:5]), 0.0)


def broken_files(w):
    """A deck cut off part-way (a step stopped while writing), one with a link to a missing part and one carrying a document
    property longer than Office keeps (255 characters - the record a shape-heavy dashboard deck wrote): all three are
    refused, so a file PowerPoint would offer to repair never reaches the user; and the kit's own property writer keeps a
    long value whole across properties Office accepts."""
    import ooxml_check, docprops
    src = w / "cards.pptx"
    if not src.exists():
        return ("broken files caught", False, "-", "no deck to test with", 0.0)
    data = src.read_bytes()
    cut, dangling, longp, healed = w / "cut.pptx", w / "dangling.pptx", w / "long-prop.pptx", w / "healed.pptx"
    cut.write_bytes(data[: len(data) * 2 // 3])
    with zipfile.ZipFile(src) as zi, zipfile.ZipFile(dangling, "w", zipfile.ZIP_DEFLATED) as zo, zipfile.ZipFile(longp, "w", zipfile.ZIP_DEFLATED) as zl:
        for it in zi.infolist():
            b = zi.read(it.filename)
            zl.writestr(it.filename, b.replace(b"</Properties>", b'<property fmtid="{D5CDD505-2E9C-101B-9397-08002B2CF9AE}" pid="900" name="LongRecord">'
                                      b"<vt:lpwstr>" + b"x" * 600 + b"</vt:lpwstr></property></Properties>") if it.filename == "docProps/custom.xml" else b)
            if it.filename == "ppt/slides/_rels/slide1.xml.rels":
                b = b.replace(b'Target="../slideLayouts/', b'Target="../slideLayouts/missing-', 1)
            zo.writestr(it, b)
    caught = {p.name: ooxml_check.summary(p, 1) for p in (cut, dangling, longp)}
    shutil.copyfile(longp, healed)
    docprops.write_props(healed, custom={"A11yAdded": "y" * 700})          # any write keeps every property within 255
    kept = docprops.read_props(healed)[1]
    whole = kept.get("LongRecord") == "x" * 600 and kept.get("A11yAdded") == "y" * 700 and not ooxml_check.summary(healed, 1)
    for p in (cut, dangling, longp, healed):
        p.unlink()
    ok = all(caught.values()) and whole
    return ("broken files caught", ok, "-", "a cut-off file, a broken link and a 600-character property are refused; long values kept whole" if ok
            else f"BAD not refused: {[k for k, v in caught.items() if not v]}" if not all(caught.values()) else "BAD a long property was not kept whole within 255",
            0.0)


def page_scripts(w):
    """Every page the run made can run its own scripts: each inline script compiles (node, where it is installed). A colour
    pass that rewrote a script's code ({fill: GOLD} read as the CSS colour gold) leaves the page's editor dead."""
    pages = sorted(p for p in w.rglob("*.html") if "_source" not in str(p))
    node = shutil.which("node")
    if not node:
        return ("page scripts compile", bool(pages), "-", f"{len(pages)} pages; node not here: checked when the skill is built", 0.0)
    t0, d, files = time.time(), w / "_scripts", []
    d.mkdir(exist_ok=True)
    for p in pages:
        for i, m in enumerate(re.finditer(r"<script\b([^>]*)>(.*?)</script>", p.read_text(encoding="utf-8", errors="ignore"), re.S | re.I), 1):
            kind = (re.findall(r"\btype\s*=\s*[\"']?([^\"'\s>]+)", m.group(1), re.I) or ["text/javascript"])[0].lower()
            if kind in ("text/javascript", "application/javascript") and "src=" not in m.group(1) and m.group(2).strip():
                files.append(d / f"{p.stem}.{i}.js"); files[-1].write_text(m.group(2), encoding="utf-8")
    js = ("const fs=require('fs'),vm=require('vm');const bad=[];for(const f of process.argv.slice(1)){try{new vm.Script("
          "fs.readFileSync(f,'utf8'))}catch(e){bad.push(require('path').basename(f)+': '+e.message)}}process.stdout.write(JSON.stringify(bad))")
    r = subprocess.run([node, "-e", js] + [str(f) for f in files], capture_output=True, text=True, timeout=240)
    shutil.rmtree(d, ignore_errors=True)
    try:
        bad = json.loads(r.stdout)
    except ValueError:
        bad = ["node: " + (r.stderr or r.stdout)[-100:]]
    return ("page scripts compile", not bad and bool(files), "-", f"{len(files)} scripts in {len(pages)} pages compile" if not bad
            else f"BAD {bad[0][:90]}" + (f" (+{len(bad) - 1} more)" if len(bad) > 1 else ""), round(time.time() - t0, 1))


def library_checks(w):
    """The process library: every page lints clean and application-agnostic; templates build READY on their own and
    as one deck of chapters; search finds a template by its words."""
    rows, t0 = [], time.time()
    r = subprocess.run([PY, str(T / "playbook.py"), "check", "--agnostic"], capture_output=True, text=True, timeout=240)
    m = re.search(r"(\d+) templates, (\d+) problem", r.stdout)
    n, bad = (int(m.group(1)), int(m.group(2))) if m else (0, -1)
    rows.append(("process library (every page lints clean)", n >= 294 and bad == 0, "-", f"{n} templates, {bad} problem(s)", round(time.time() - t0, 1)))
    rows.append(run("library deck (one template)", [T / "playbook.py", "build", LIB_ONE, "--out", w / "lib-one.pptx"], w))
    rows.append(run("library deck (templates as chapters)", [T / "playbook.py", "build", *LIB_TWO, "--out", w / "lib-two.pptx"], w))
    t0 = time.time()
    r = subprocess.run([PY, str(T / "playbook.py"), "search", *LIB_SEARCH[0].split()], capture_output=True, text=True)
    rows.append(("library search", LIB_SEARCH[1] in r.stdout, "-", (r.stdout.strip().splitlines() or ['no output'])[-1][:60], round(time.time() - t0, 1)))
    t0 = time.time()
    r = subprocess.run([PY, str(T / "playbook.py"), "pick", LIB_PICK[0], "--out", str(w / "picked.md"), "--title", "Picked"], capture_output=True, text=True)
    page = (w / "picked.md").read_text(encoding="utf-8") if (w / "picked.md").exists() else ""
    rows.append(("library pick (one slide per request, any template)", all(f"template {i}" in page for i in LIB_PICK[1]), "-",
                 f"{page.count(chr(10) + '## ')} slides from {len(LIB_PICK[1])} templates", round(time.time() - t0, 1)))
    t0 = time.time()
    (w / "weak.md").write_text(LIB_REVIEW, encoding="utf-8")
    r = subprocess.run([PY, str(T / "playbook.py"), "review", str(w / "weak.md")], capture_output=True, text=True)
    seen = [k for k in ("a timeline", "name a topic", "placeholders") if k in r.stdout]
    rows.append(("library expert review (dates, topic headings, placeholders)", len(seen) == 3, "-",
                 f"{len(seen)} of 3 findings: {', '.join(seen) or 'none'}", round(time.time() - t0, 1)))
    return rows


def slides(p):
    z = zipfile.ZipFile(p)
    return {n: hashlib.sha256(z.read(n)).hexdigest() for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--quick", action="store_true")
    ap.add_argument("--keep", action="store_true", help="keep the work folder after a clean pass"); a = ap.parse_args()
    w = Path(tempfile.mkdtemp(prefix="ulta-selftest-"))
    (w / "cards.json").write_text(json.dumps({"slides": [
        {"source": 1, "title": "Self-test deck", "subtitle": "Sample content"},
        {"source": 9, "headline": "Decks build 74% faster on the template", "table": [["Speed", "Reach", "Quality"], ["74%\nfaster builds", "13\nready designs", "100%\neditable shapes"]]},
        {"source": 7, "headline": "Fewer tokens, real PowerPoint, safer data", "table": [["Tokens", "PowerPoint", "Security"],
            ["Fewer tokens\n\nA short storyboard replaces generated code", "Real placeholders\n\nTitles and tables come from the master", "Data checks\n\nSecrets and card numbers are blocked"],
            ["Focused edits\n\nOnly the changed text is rewritten", "Two outputs\n\nNative shapes plus a draw.io file", "Labels kept\n\nSensitivity labels carry through"]]},
        {"diagram": ["Web store → Order service: order", "Order service → Payment: charge", "Order service → Warehouse: pick"], "headline": "Every order fans out from the order service"},
        {"source": 32, "text": ["Thank you!"]}]}))
    (w / "own.json").write_text(json.dumps({"title": "Self-test one-pager", "format": "onepager", "theme": "ulta", "blocks": [
        {"type": "stats", "title": "Impact", "items": [["89%", "token savings"], ["13", "designs"], ["1", "line per edit"]]},
        {"type": "takeaway", "text": "One change, nothing else breaks"}]}))
    with open(w / "sales.csv", "w", newline="") as f:
        cw = csv.writer(f); cw.writerow(["Order date", "Region", "Channel", "Net sales", "Margin %"])
        for i in range(60):
            cw.writerow([f"2026-0{1 + i % 6}-1{i % 9}", ["North", "South", "East"][i % 3], ["Store", "Online"][i % 2], 100 + 7 * i, round(0.3 + (i % 5) / 50, 2)])
    rows = []
    def drawn_headline(o):                             # the diagram slide's headline sits where every headline sits: the
        from pptx import Presentation as _P            # engine's 110% line spacing would drop it onto a takeaway line
        if not (w / "cards.pptx").exists():
            return ""
        sl = _P(str(w / "cards.pptx")).slides[3]
        head = next((sh for sh in sl.shapes if sh.has_text_frame and "fans out" in sh.text_frame.text), None)
        xml = head._element.xml if head is not None else ""
        return ("BAD the diagram slide's headline keeps the engine's line spacing" if "lnSpc" in xml or "spcBef" in xml
                else "diagram headline set like every headline")
    rows.append(run("deck (cards, numbers, diagram)", [T / "build_deck.py", "build", w / "cards.json", "--out", w / "cards.pptx"], w,
                    check=drawn_headline))
    if (w / "cards.pptx").exists():
        before = slides(w / "cards.pptx")
        def same(o):
            after = slides(w / "cards-e.pptx") if (w / "cards-e.pptx").exists() else {}
            ch = [n for n in before if before[n] != after.get(n)]
            return "only 1 slide changed" if len(ch) == 1 else f"BAD {len(ch)} slides changed"
        rows.append(run("edit one line", [T / "edit_deck.py", "apply", w / "cards.pptx", "--set", "3.13.r3c1=Quick edits\n\nOnly this cell changes",
                                         "--out", w / "cards-e.pptx"], w, check=same))
    (w / "layouts.json").write_text(json.dumps({"slides": [
        {"source": "cover-collage", "title": "Holiday guest experience review"},
        {"source": "divider-photo", "title": "What guests said"},
        {"source": "headline-metrics", "headline": "The plan targets $2.1B in holiday sales",
         "table": [["$2.1B\nHoliday net sales", "+6%\nComparable growth", "+1.2M\nNew loyalty members", "92%\nOn-shelf goal"]]},
        {"source": "team", "headline": "Four leads run the store pilot",
         "people": [["Remy Reyes", "Program lead"], ["Nadia Wren", "Store operations"], ["Elena Duarte", "Services"], ["Grace Liu", "Analytics"]]},
        {"source": "big-note", "title": "Guests come back for the people"},
        {"source": "thank-you"}]}))
    rows.append(run("40-layout template (new layouts)", [T / "build_deck.py", "build", w / "layouts.json", "--out", w / "layouts.pptx"], w))
    (w / "counts.json").write_text(json.dumps({"slides": [     # fewer items than the template's samples: they fit
        {"source": "cover-gradient", "title": "Strategy on a page"},
        {"priorities": {"vision": "Be the most loved beauty destination, in store and online",
                        "goals": ["Grow loyal guests", "Win in digital"],
                        "strategies": [{"name": "Guests", "text": "Services in every store", "kpis": ["NPS 72"]},
                                       {"name": "Digital", "text": "App-first shopping", "kpis": ["App sales +20%"]},
                                       {"name": "Supply", "text": "Right product, right store", "kpis": ["In-stock 97%"]},
                                       {"name": "People", "text": "Grow great teams", "kpis": ["Retention 85%"]}]},
         "headline": "2026 Priorities"},
        {"funnel": ["Visits: 1.2M", "Product views: 640K", "Add to bag: 120K"], "headline": "Most visitors leave before the bag"},
        {"ogsm": {"objective": "Make Ulta the first choice for beauty services", "goals": ["Grow services 15%", "NPS 75"],
                  "strategies": [{"title": "Book", "text": "Online booking everywhere"}, {"title": "Train", "text": "Certify every stylist"}],
                  "measures": [{"title": "Bookings", "value": "+15%", "text": "vs last year"}, {"title": "NPS", "value": "75", "text": "services"}]},
         "headline": "Services grow 15% on two strategies"},     # (the funnel between the two frameworks: one way each)
        {"quad": ["-38%\nPickup wait", "4.6\nGuest rating", "+9%\nPickup orders"], "headline": "Pickup waits fell 38% in the pilot"},
        {"source": "four-pillars", "headline": "Three pillars carry the pickup plan",
         "table": [[None, "Guest", "Digital", "Supply"], [None, "Services in every store", "App-first shopping", "Right product, right store"],
                   [None, "Book online\nTrain stylists", "Faster checkout\nPickup in 2 hours", "Auto-replenish\nFewer stock-outs"]]},
        {"source": "recap-today", "headline": "Last week closed three pilot items",
         "text": ["Recap\n(10/12)", "Today's Focus\n(10/19)"],
         "slots": {"Table 1": [["Pilot stores picked"], ["Desk staffing set"], ["Alerts tested"]], "Table 21": [["Go-live checklist"], ["Training plan"]]}},
        {"source": "thank-you"}]}))
    rows.append(run("vision house and fitted counts", [T / "build_deck.py", "build", w / "counts.json", "--out", w / "counts.pptx"], w,
                    check=lambda o: "vision house, OGSM, funnel, 3 numbers, 3 pillars, recap fit"
                    if "3 big numbers go on the headline-metrics row" in o and "four-pillars with 3 of 4 items" in o
                    and "recap-today with 3 of 5 rows" in o else "BAD the items were not fitted"))
    if (w / "layouts.pptx").exists():
        (w / "options.json").write_text(json.dumps({"options": [
            {"id": "A", "label": "Four metrics in quadrants", "slide": {"quad": ["$2.1B\nHoliday net sales", "+6%\nComparable growth",
             "+1.2M\nNew loyalty members", "92%\nOn-shelf goal"], "headline": "The plan targets $2.1B in holiday sales"}},
            {"id": "B", "label": "Three numbers (drops one)", "slide": {"source": "kpi-cards", "headline": "The plan targets $2.1B in holiday sales",
             "table": [["Sales", "Growth", "Loyalty"], ["$2.1B\nHoliday net sales", "+6%\nComparable growth", "+1.2M\nNew loyalty members"]]}}]}))
        rows.append(run("other ways to show a slide", [T / "slide_options.py", "preview", w / "layouts.pptx", "--slide", "3",
                         "--options", w / "options.json", "--out", w / "opts"], w, expect="-", tokens=False,
                        check=lambda o: "option A built; B refused (drops 92%)" if "OPTION A" in o and "numbers missing: 92%" in o
                        else "BAD the options were not checked as expected"))
        rows.append(run("swap in the chosen option", [T / "slide_options.py", "apply", w / "layouts.pptx", "--session", w / "opts",
                         "--choice", "A", "--out", w / "layouts-v2.pptx"], w,
                        check=lambda o: "other slides byte-identical" if "byte-identical" in o else "BAD other slides changed"))
    rows.append(reset_safe(w))
    rows.append(classified_swap(w))
    rows.append(cards_fit(w))
    rows.append(placeholders_never_ship(w))
    rows.append(cut_off_build(w))
    rows.append(tracked_job(w))
    rows.append(fast_render(w))
    rows.append(picture_onepager(w))
    rows.append(orange_light(w))
    rows.append(one_slide(w))
    rows.append(story_ways(w))
    rows.append(result_line(w))
    rows.append(office_charts(w))
    rows.append(unsafe_files(w))
    rows.append(metadata(w))
    rows.append(integrity_rules(w))
    rows.append(safety_rules())
    rows.append(isolated_paths())
    rows.append(run("advanced charts (every type)", [T / "build_deck.py", "build", T.parent / "brands" / "ulta" / "modern-sample.json",
                     "--out", w / "modern.pptx"], w))
    rows.append(readable_text(w))
    rows.append(summary_on_slide(w))
    rows.append(expert_review(w))
    def pct_text(o):                                   # Margin % holds fractions (0.32): every slide shows 32%, never 0.32%
        try:
            from pptx import Presentation as _P
            said = [sh.text_frame.text for s_ in _P(w / "advised.pptx").slides for sh in s_.shapes if sh.has_text_frame]
        except Exception as e:
            return f"BAD deck not readable ({e.__class__.__name__})"
        bad = [m for t in said for m in re.findall(r"(?<![\d.])0\.\d+ ?%", t)]
        return "percentages read 32%, not 0.32%" if not bad else "BAD a fraction shown as a percent: " + bad[0]
    rows.append(run("chart my data", [T / "chart_advisor.py", w / "sales.csv", "--build", w / "advised.pptx"], w, check=pct_text))
    try:                                               # a chart slide: other ways come from its own numbers; a note without them is refused
        from pptx import Presentation as _P
        cs = next((i for i, s_ in enumerate(_P(w / "advised.pptx").slides, 1) if any(sh.has_chart for sh in s_.shapes)), 0)
        r = subprocess.run([PY, str(T / "slide_options.py"), "show", str(w / "advised.pptx"), "--slide", str(cs)],
                           capture_output=True, text=True, cwd=w, timeout=240)
        m = re.search(r"^OPTIONS (\S+\.json) - (.*)$", r.stdout, re.M)
        if not cs or not m:
            raise RuntimeError("no options from the chart's numbers" if cs else "no chart slide in the chart-my-data deck")
        opts = json.loads(Path(m.group(1)).read_text(encoding="utf-8"))["options"]
        opts.append({"id": "Z", "label": "Big note", "slide": {"source": "big-note", "title": "Sales are spread across regions"}})
        (w / "data-opts.json").write_text(json.dumps({"options": opts}))
        rows.append(run("other ways for a data slide", [T / "slide_options.py", "preview", w / "advised.pptx", "--slide", cs, "--options",
                         w / "data-opts.json", "--out", w / "dopts"], w, expect="-", tokens=False,
                        check=lambda o: f"{len(opts) - 1} options from the chart's numbers; a note without them refused"
                        if "OPTION A" in o and re.search(r"REJECTED Z: .*values missing", o) else "BAD the data options were not checked"))
    except Exception as e:
        rows.append(("other ways for a data slide", False, "CRASH", str(e)[:80], 0))
    import datetime as _dt                             # weekly sales in dollars: 48,213,000 reads $48.2M, the weeks stay weeks
    with open(w / "weekly.csv", "w", newline="") as f:
        cw = csv.writer(f); cw.writerow(["Week", "Region", "Net sales", "Sales plan"])
        for k in range(26):
            for j, rg in enumerate(["North", "South", "East"]):
                v = 41_000_000 + 1_300_000 * j + 450_000 * k + (k % 4) * 600_000
                cw.writerow([(_dt.date(2026, 4, 6) + _dt.timedelta(weeks=k)).isoformat(), rg, v, round(v * 0.97)])
    def money_text(o):
        try:
            from pptx import Presentation as _P
            said = [sh.text_frame.text for s_ in _P(w / "weekly.pptx").slides for sh in s_.shapes if sh.has_text_frame]
            z = zipfile.ZipFile(w / "weekly.pptx")
            charts = [z.read(n).decode("utf-8", "ignore") for n in z.namelist() if n.startswith("ppt/charts/chart")]
        except Exception as e:
            return f"BAD deck not readable ({e.__class__.__name__})"
        raw = [m for t in said for m in re.findall(r"\d{1,3}(?:,\d{3}){2,}|\d{7,}", t)]
        if raw:
            return "BAD a raw number on a slide: " + raw[0]
        if not any(re.search(r"\$\d[\d.,]*[MB]\b", t) for t in said):
            return "BAD no $M / $B values"
        if any("furthest below" in t for t in said):
            return "BAD 'furthest below' while every region beats its plan"
        if not any("<c:dateAx>" in x for x in charts):
            return "BAD 26 weekly dates without a date axis (the labels collide)"
        return "$M and $B, weekly points on a date axis, all regions beat plan"
    rows.append(run("chart my data (big values)", [T / "chart_advisor.py", w / "weekly.csv", "--pick", "1,2", "--build",
                                                   w / "weekly.pptx"], w, check=money_text))
    def whole_frame(f):                                # the preview-frame helper once, whole, right before </body>
        t = f.read_text(encoding="utf-8", errors="ignore") if f.exists() else ""
        return t.count('id="ultaFrame"') == 1 and bool(re.search(r'<script id="ultaFrame">.*?</script>\s*</body>', t, re.S))
    rows.append(run("own infographic", [T / "infographic.py", "make", w / "own.json", "--out", w / "own"], w,
                    check=lambda o: "one-pager page: the preview helper sits whole before </body>" if whole_frame(w / "own.html")
                    else "BAD the preview-frame helper is not once, whole, before </body> - the page shows its code as text"))
    rows.append(run("design thumbnails", [T / "infographic.py", "show", "--group", "status", "--out", w / "designs.png"], w,
                    expect="-", tokens=False, check=lambda o: "" if (w / "designs.png").exists() else "BAD no picture"))
    def page_cfg(f):
        h = f.read_text(errors="ignore") if f.exists() else ""
        return h, (json.loads(h[h.index("/*CFG*/") + 7:h.index("/*CFG-END*/")]) if "/*CFG-END*/" in h else {})
    def pct(o):                                        # charts chosen from the data, every type drawable, Add chart and Save in the page
        h, cfg = page_cfg(w / "dash.html")
        if not (("pctScale" in h or "pctOf" in h) and 'class="kpi"' in h):
            return "BAD old page (no % formatting or no KPI tiles)"
        if "function trimEnds" not in h:
            return "BAD the trend keeps part periods at its ends"
        if not all(x in h for x in ('id="addChart"', 'id="saveDash"', "function openAdd", "function saveDashboard")):
            return "BAD no Add chart or Save in the page"
        drawn = [f for f in ("sankeyChart", "heatChart", "pairedChart", "bulletChart", "stackedChart", "linesChart", "stackTimeChart",
                             "comboChart", "histChart", "changeChart", "lollipopChart") if f"function {f}(" not in h]
        if drawn:
            return "BAD the page cannot draw " + ", ".join(drawn)
        if not whole_frame(w / "dash.html"):
            return "BAD the page cannot tell the user when the chat's preview blocks saving (no helper, or not whole before </body>)"
        import importlib.util                          # no picture renderer here: the page alone is the dashboard
        if importlib.util.find_spec("resvg_py") and (not (w / "dash.png").exists() or "PICTURE " not in o):
            return "BAD no dashboard picture for the chat"
        kinds = sorted({c["kind"] for c in cfg.get("cards") or []})
        if len(kinds) < 5 or len(cfg.get("ideas") or []) < 6:
            return f"BAD the same few charts ({', '.join(kinds)}) or few ideas ({len(cfg.get('ideas') or [])})"
        return f"{len(kinds)} chart types from the data ({', '.join(kinds)}), {len(cfg['ideas'])} ideas under Add chart, a picture for the chat"
    rows.append(run("dashboard", [T / "dashboard.py", "build", w / "sales.csv", "--out", w / "dash", "--title", "Sales"], w, check=pct))
    def plan_dash(o):                                  # other data, other charts: a plan column gets bullets; the deck mixes its layouts
        _, a = page_cfg(w / "dash.html"); _, b = page_cfg(w / "plandash.html")
        ka, kb = {c["kind"] for c in a.get("cards") or []}, {c["kind"] for c in b.get("cards") or []}
        if "bullet" not in kb:
            return "BAD no actual-vs-plan chart for a plan column: " + ", ".join(sorted(kb))
        if ka == kb:
            return "BAD two different datasets got the same charts: " + ", ".join(sorted(ka))
        if "deck: READY" not in o:
            return "BAD the deck of the dashboard is not READY: " + next((l.strip() for l in o.splitlines() if "deck:" in l), "no deck line")[:90]
        return f"plan vs actual: {', '.join(sorted(kb - ka))} (not in the sales one); deck READY"
    rows.append(run("dashboard (other data, deck)", [T / "dashboard.py", "build", w / "weekly.csv", "--out", w / "plandash", "--title", "Plan", "--deck"], w, check=plan_dash))
    h0, cfg0 = page_cfg(w / "dash.html")                # what the page's Save writes: three tiles in a new order, a filter on
    if cfg0.get("cards"):
        keep = list(reversed(cfg0["cards"][:3]))
        saved = dict(cfg0, cards=keep, order=["trend", "c0", "c1", "c2", "table"], saved="2026-01-01T00:00:00Z",
                     view={"dims": {"Region": ["North"]}, "from": "", "to": "", "grain": cfg0.get("grain") or "month", "measure": None})
        js = json.dumps(saved).replace("<", "\\u003c").replace("*/", "*\\/")
        (w / "saved.html").write_text(h0[:h0.index("/*CFG*/") + 7] + js + h0[h0.index("/*CFG-END*/"):], encoding="utf-8")
        def resaved(o):
            _, c = page_cfg(w / "resaved.html")
            got = [(x["kind"], x.get("dim") or "") for x in c.get("cards") or []]
            want = [(x["kind"], x.get("dim") or "") for x in keep]
            if got != want:
                return f"BAD the saved tiles came back as {got}"
            if (c.get("view") or {}).get("dims") != {"Region": ["North"]}:
                return "BAD the saved filter was lost"
            return f"{len(got)} tiles in their saved order, filter Region = North kept"
        rows.append(run("dashboard from a saved page", [T / "dashboard.py", "build", w / "saved.html", "--out", w / "resaved"], w, check=resaved))
    with open(w / "stores.csv", "w", newline="") as f:  # places: a state column and store coordinates give the two maps
        cw = csv.writer(f); cw.writerow(["Order date", "Store", "State", "Latitude", "Longitude", "Channel", "Net sales"])
        spots = [("Dallas", "TX", 32.78, -96.8), ("Austin", "TX", 30.27, -97.74), ("Los Angeles", "CA", 34.05, -118.24), ("San Diego", "CA", 32.72, -117.16),
                 ("Miami", "FL", 25.76, -80.19), ("Tampa", "FL", 27.95, -82.46), ("Chicago", "IL", 41.88, -87.63), ("New York", "NY", 40.71, -74.0),
                 ("Seattle", "WA", 47.61, -122.33), ("Denver", "CO", 39.74, -104.99), ("Atlanta", "GA", 33.75, -84.39), ("Phoenix", "AZ", 33.45, -112.07),
                 ("Boston", "MA", 42.36, -71.06), ("Columbus", "OH", 39.96, -83.0)]
        for i in range(840):
            c_, st, la, lo = spots[(i * 5) % len(spots)]
            cw.writerow([(_dt.date(2026, 1, 5) + _dt.timedelta(days=i % 120)).isoformat(), c_ + " store", st, la, lo, ["Store", "Online"][i % 2],
                         round(40 + (i % 13) * 9.5 + (60 if st in ("TX", "CA") else 0), 2)])
    def maps_ok(o):
        h, c = page_cfg(w / "geodash.html"); g = c.get("geo") or {}; kinds = {x["kind"] for x in c.get("cards") or []}
        if g.get("states") != ["State"] or g.get("lat") != "Latitude" or g.get("label") != "Store":
            return f"BAD places not found: {g}"
        if not {"map", "pointmap"} <= kinds:
            return "BAD no map cards: " + ", ".join(sorted(kinds))
        if "Latitude" in (c.get("measures") or []) or not all(f"function {f}(" in h for f in ("choroChart", "pointChart", "stateData")):
            return "BAD latitude summed, or the page cannot draw maps"
        if 'const GEO={"source"' not in h or "const GEO=null" not in page_cfg(w / "dash.html")[0]:
            return "BAD state shapes missing, or carried by a page without places"
        if "deck: READY" not in o:
            return "BAD the deck is not READY: " + next((l.strip() for l in o.splitlines() if "deck:" in l), "no deck line")[:90]
        try:
            from pptx import Presentation as _P
            per = [sum(1 for sh in s_.shapes if sh.name.startswith("modern map")) for s_ in _P(w / "geodash.pptx").slides]
        except Exception as e:
            return f"BAD deck not readable ({e.__class__.__name__})"
        if sum(1 for n in per if n >= 51) < 2:
            return f"BAD the deck has {sum(1 for n in per if n >= 51)} map slides, not 2"
        return f"state map and store circles in the page; 2 deck slides of {max(per)} editable shapes"
    rows.append(run("dashboard maps (states, stores, deck)", [T / "dashboard.py", "build", w / "stores.csv", "--out", w / "geodash", "--title", "Stores",
                                                             "--charts", "pointmap:@Net sales", "--deck"], w, check=maps_ok))
    def site_ok(o):                                    # two pages as one site: index.html at the root, every page checked again
        root = w / "dash-site"; idx = root / "index.html"
        if not idx.exists():
            return "BAD no index.html at the site's root"
        pages = sorted(root.glob("pages/*.html")); h = idx.read_text(encoding="utf-8", errors="ignore")
        if len(pages) != 2 or not all(f'href="pages/{p.name}"' in h for p in pages):
            return f"BAD the landing page does not link {len(pages)} pages"
        if not all('name="robots" content="noindex' in p.read_text(encoding="utf-8", errors="ignore")[:4000] for p in pages):
            return "BAD a page can be listed by search engines"
        if any(f.name.endswith(".checks.json") for f in root.rglob("*")) or not (w / "dash-site.zip").exists():
            return "BAD check records inside the site, or no .zip"
        wk = w / "dash-site.worker.js"                 # the same site as one Worker module: every page inside, unchanged
        line = next((x for x in (wk.read_text(encoding="utf-8").splitlines() if wk.exists() else [])
                     if x.startswith("const PAGES = new Map(Object.entries(")), "")
        try:
            served = json.loads(line[len("const PAGES = new Map(Object.entries("):-len("));")])
        except ValueError:
            served = {}
        files = {"/" + f.relative_to(root).as_posix(): f.read_text(encoding="utf-8") for f in root.rglob("*.html")}
        if served != files or "export default" not in wk.read_text(encoding="utf-8"):
            return f"BAD the Worker module does not serve the site's {len(files)} pages unchanged"
        (w / "leak.html").write_text("<!doctype html><html><head><title>Leak</title></head><body>Card 4111 1111 1111 1111</body></html>")
        r = subprocess.run([PY, str(T / "site.py"), str(w / "leak.html"), "--out", str(w / "leak-site")], capture_output=True, text=True, cwd=w, timeout=120)
        if r.returncode == 0 or (w / "leak-site").exists() or (w / "leak-site.worker.js").exists():
            return "BAD a page with a card number was published"
        import htmlpdf                                 # a v118-v119 page: the helper inside "</b" ... "ody>" is mended on the site
        (w / "old.html").write_text("<!doctype html><html><head><title>Old page</title></head><body><p>Old</p></b"
                                    + htmlpdf.FRAME + "ody></html>", encoding="utf-8")
        r = subprocess.run([PY, str(T / "site.py"), str(w / "old.html"), "--out", str(w / "old-site")], capture_output=True, text=True, cwd=w, timeout=120)
        if not whole_frame(w / "old-site" / "index.html"):
            return "BAD a page with its preview helper inside </body> went on the site as it was"
        return "landing page + 2 pages, noindex, zip, a Worker module serving them unchanged; a card number refused; an old page mended"
    pillars = lambda names, sums, pts: [[None] + names, [None] + sums, [None] + pts]
    (w / "neighbours.json").write_text(json.dumps({"classification": "internal", "slides": [   # look-alike neighbours
        {"source": 1, "text": ["Neighbour check"]},
        {"source": "four-pillars", "headline": "AI helps at every product stage", "table": pillars(
            ["Discover", "Define", "Deliver", "Learn"], ["Find the problem", "Shape the build", "Ship it right", "Measure change"],
            ["Research synthesis\nJourney insights", "PRD drafts\nBacklog refinement", "Prototype concepts\nContent support",
             "Feedback themes\nExperiment readouts"])},
        {"source": "objectives-scope", "headline": "Three steps take the pilot to scale", "table": [
            ["Pilot", "Measure", "Scale"], ["Five stores\nOne region", "Wait times\nGuest ratings", "Every region\nAll stores"]]},
        {"source": "four-pillars", "headline": "Controls keep AI delivery safe", "table": pillars(
            ["Controls", "Accountability", "Policy"], ["Guardrails for every team", "People own each decision", "Review matches the risk"],
            ["Approved tools and data boundaries\nPrivacy and security review\nTraceable outputs for audits",
             "Product owner approves the value\nEngineers own the code they ship\nSecurity owns every exception",
             "Low risk gets guided assistance\nMedium risk gets an enhanced review\nHigh risk passes a formal gate"])},
        {"source": 7, "headline": "Each wave ends on a measured exit", "table": [
            ["Establish", "Scale", "Optimize"],
            ["Select pilot teams\n\nBaseline every metric and set the tool policies for each team",
             "Expand proven patterns\n\nEnable champions in every team and integrate the toolchain end to end",
             "Tune unit economics\n\nAutomate the evidence and retire the weak use cases"],
            ["Exit: safe pilots\n\nEvery pilot runs inside the guardrails", "Exit: a playbook\n\nEvery team can follow it",
             "Exit: measured outcomes\n\nValue tracked for every use case"]]},
        {"source": 20, "headline": "Four moves take AI from pilot to habit", "steps": [
            {"label": "Foundation", "text": "Tools, policies, baselines"}, {"label": "Validation", "text": "Pilots prove the value"},
            {"label": "Governance", "text": "Controls in every team"}, {"label": "Adoption", "text": "Champions scale the use"}]},
        {"source": 32, "text": ["Thank you!"]}]}))
    def neighbours_ok(o):                              # 2-3 re-laid as a flow, 4-5 too long to move: a FAIL naming both
        if "slide 3: set as a process flow" not in o:
            return "BAD the sequence after a headed-column slide was not set as a flow"
        if "slides 2 and 3 look alike" in o or "slides 4 and 5 look alike" not in o:
            return "BAD the look-alike neighbours were not caught as expected"
        if "a flow" in o.split("slides 4 and 5 look alike", 1)[1].split("\n", 1)[0]:
            return "BAD the advice offers a look the neighbours already have"
        r = subprocess.run([PY, "-I", "-c", "import sys; sys.path.insert(0, sys.argv[1]); import build_deck as B, json; "
                            "s = json.load(open(sys.argv[2]))['slides']; s = [dict(x, source={'four-pillars': 43, "
                            "'objectives-scope': 47}.get(x.get('source'), x.get('source'))) for x in s]; "
                            "same = B.vary_neighbours(s, converted=True) == s; B.design_lint(s, converted=True); "
                            "print(same, any('look alike' in a for a in B.ADVICE), any('look alike' in p for p in B.PROBLEMS))",
                            str(T), str(w / "neighbours.json")], capture_output=True, text=True, cwd=w, timeout=120)
        if r.stdout.split() != ["True", "True", "False"]:
            return f"BAD a converted deck was changed or failed for its own layouts ({(r.stdout + r.stderr).strip()[-120:]})"
        return "a sequence after headed columns set as a flow; two long column slides in a row FAIL with other layouts; converted decks get advice"
    rows.append(run("neighbouring slides look different", [T / "build_deck.py", "build", w / "neighbours.json", "--out", w / "neighbours.pptx"], w,
                    expect="NEEDS CORRECTION", check=neighbours_ok))
    tasks = [{"group": "Build", "task": "Design", "start": "2026-03-02", "end": "2026-03-13"},
             {"group": "Build", "task": "Build", "start": "2026-03-16", "end": "2026-04-03"}]
    (w / "ways.json").write_text(json.dumps({"classification": "internal", "slides": [   # one way of telling twice in a row
        {"source": 1, "title": "Storytelling check"},
        {"modern": "lollipop", "headline": "East leads net sales at 6,270", "items": [["East", 6270], ["South", 6130], ["North", 5990]]},
        {"modern": "bubbles", "headline": "Skincare brings the most units", "items": [["Skincare", 420], ["Makeup", 360], ["Hair", 210]]},
        {"modern": "gantt", "headline": "Design ends in March; build runs to April", "today": "2026-03-11", "tasks": tasks},
        {"modern": "gantt", "headline": "Design ends in March; build runs to April (2/2)", "today": "2026-03-11",
         "tasks": [dict(t_, group="Launch") for t_ in tasks]},
        {"bullets": [{"lead": "Price", "text": "Match the online price in store"}, {"lead": "Stock", "text": "Fill the top 200 items first"}],
         "headline": "Two levers lift store conversion"},
        {"source": 7, "headline": "Three steps take the pilot to scale", "table": [["Pilot", "Measure", "Scale"],
            ["Five stores\n\nOne region first", "Wait times\n\nGuest ratings weekly", "Every region\n\nAll stores live"]]},
        {"source": "headline-metrics", "headline": "Pilot stores fill shelves faster",
         "table": [["96%\nShelf availability\nfrom 91%", "-18%\nBackroom stock\n$2.1M less"]]},
        {"modern": "kpi", "headline": "Guests rate the app higher", "continues": True,
         "items": [{"label": "App rating", "value": "4.6"}, {"label": "Reviews", "value": "12K"}]},
        {"source": 32, "text": ["Thank you!"]}]}))
    def ways_ok(o):                                    # rank twice: FAIL; the gantt marked (2/2): fine; steps: a flow; a
        line = next((l for l in o.splitlines() if "slides 2 and 3 tell their story the same way" in l), "")   # false claim: FAIL
        if not line or "slides 4 and 5" in o:
            return "BAD two rankings in a row not caught, or the marked continuation was"
        if re.search(r"(?i)lollipop|ranked|bars", line.split("another way:", 1)[-1]):
            return "BAD the advice offers the way the slide before already tells its story"
        if "slide 7: set as a process flow" not in o:
            return "BAD points that run in order after other points were not set as a flow"
        if "slides 8 and 9 tell their story the same way" not in o or "shares neither its subject nor its form" not in o:
            return "BAD a slide marked as carrying on an unrelated one was let through"
        r = subprocess.run([PY, "-I", "-c", "import sys, json; sys.path.insert(0, sys.argv[1]); import build_deck as B, storyline as SL; "
                            "s = json.load(open(sys.argv[2]))['slides']; B.design_lint(s, converted=True); "
                            "a = any('same way' in x for x in B.ADVICE) and not any('same way' in x for x in B.PROBLEMS); "
                            "B.PROBLEMS.clear(); B.ADVICE.clear(); B.design_lint(s, gallery=True); "
                            "print(a, not any('same way' in x for x in B.PROBLEMS), SL.clashes(s, gallery=True) == [])",
                            str(T), str(w / "ways.json")], capture_output=True, text=True, cwd=w, timeout=120)
        if r.stdout.split() != ["True", "True", "True"]:
            return f"BAD a converted deck or a catalogue was held to the rule ({(r.stdout + r.stderr).strip()[-120:]})"
        c = subprocess.run([PY, "-I", str(T / "storyline.py"), str(w / "ways.json")], capture_output=True, text=True, cwd=w, timeout=60)
        if c.returncode != 1 or c.stdout.count("CLASH") != 3:
            return f"BAD storyline.py did not list the 3 pairs (exit {c.returncode})"
        return "rank twice FAILs with other ways; (2/2) continues; steps after points set as a flow; a false claim FAILs"
    rows.append(run("slides in a row tell their story different ways", [T / "build_deck.py", "build", w / "ways.json", "--out",
                                                                      w / "ways.pptx"], w, expect="NEEDS CORRECTION", check=ways_ok))
    def flows_ok(o):                                   # every process flow style has a sample slide of its own
        import flows as FL
        missing = [k for k in FL.STYLES if k not in {s_.get("style") for s_ in FL.sample()}]
        return f"BAD no sample for {', '.join(missing)}" if missing else f"{len(FL.STYLES)} process flow styles, each its own picture"
    rows.append(run("process flows (every style)", [T / "build_deck.py", "flows", "--out", w / "flows.pptx"], w, check=flows_ok))
    def retail_ok(o):                                  # trucks, DCs and invoices drawn as native shapes; auto icons differ
        import flows as FL, retail as RT
        from pptx import Presentation as _P

        def walk(shapes):
            for sh in shapes:
                yield sh
                if sh.shape_type == 6:
                    yield from walk(sh.shapes)
        picto = [sh for s_ in _P(w / "retail.pptx").slides for sh in walk(s_.shapes) if sh.name.startswith("pictogram ")]
        if len(picto) < 60 or not all(sh.shape_type == 5 for sh in picto):
            return f"BAD {len(picto)} pictograms, not all of them native shapes"
        auto = [s_["icon"] for s_ in FL._data({"icons": "auto", "steps": ["Order", "Pick", "Pack", "Ship", "Deliver",
                                                                            "Invoice"]})["steps"]]
        if len(set(auto)) != len(auto):
            return "BAD the auto icons repeat: " + ", ".join(auto)
        if not (RT.lint({"retail": "no-such-process"}) and FL.lint(
                {"process": {"steps": [{"title": "Plan", "icon": "rocket"}, "Build", "Run"]}, "style": "chevrons"})):
            return "BAD an unknown starter or icon name was let through"
        return (f"{len(RT.STYLES)} retail styles and {len(RT.STARTERS)} starters; {len(picto)} pictograms, all native shapes; "
                f"auto icons {', '.join(auto)}")
    rows.append(run("retail diagrams and starters", [T / "build_deck.py", "retail", "--out", w / "retail.pptx"], w,
                    check=retail_ok))
    (w / "rfirst.json").write_text(json.dumps({"classification": "internal", "slides": [   # retail first
        {"source": 1, "title": "Retail first check"},
        {"headline": "Product moves from vendors to guests through three stops",
         "bullets": ["Vendors: brand partners ship to our DCs", "DCs: receive, store and pick store orders",
                     "Stores: shelves filled twice a week", "Guests: shop in store or pick up online"]},
        {"source": "headline-metrics", "headline": "Peak volume runs 38% above an average week",
         "table": [["38%\nPeak volume\nvs an average week", "96.4%\nStore fill rate\nlast holiday"]]},
        {"headline": "Five documents take a purchase from order to payment",
         "bullets": ["Purchase order: buyer orders the items", "Ship notice: vendor confirms the cartons",
                     "Goods receipt: DC counts the delivery", "Invoice: vendor bills the order", "Payment: AP pays on terms"]},
        {"headline": "Three risks could slow the holiday peak",
         "bullets": ["Port congestion: ocean freight two weeks late", "DC capacity: peak volume over plan",
                     "Carrier rates: parcel surcharges from November"]},
        {"headline": "Order to cash runs in five steps", "style": "chevrons", "process": {"steps": [
            "Order: guest checks out online", "Authorize: card authorized", "Ship: carrier collects the parcel",
            "Deliver: parcel reaches the guest", "Settle: payment captured"]}},
        {"headline": "Freight moves from vendors to stores in three hops", "retail_first": False,
         "bullets": ["Vendors: ship by appointment", "DCs: sort by store", "Stores: receive twice a week"]},
        {"source": 20, "headline": "The procure to pay process takes 34 days today",
         "steps": [{"label": "Requisition", "text": "Raised in the portal"}, {"label": "Approval", "text": "Two levels sign off"},
                   {"label": "Sourcing", "text": "The buyer picks a vendor"},
                   {"label": "Contract", "text": "Terms agreed and loaded"}]},
        {"source": 32, "text": ["Thank you!"]}]}))
    def rfirst_ok(o):                                  # a supply chain, a document chain and a retail process set as
        if not all(f"note: slide {k}: {what}" in o for k, what in ((2, "set as a supply chain network"),   # their retail
                                                                  (4, "set as a document flow"),          # diagrams
                                                                  (6, "its steps get their retail pictograms"))):
            return "BAD a supply chain, a document chain or a retail process was not set as its retail diagram"
        if re.search(r"note: slide [578]: (?:set as|its steps)", o):
            return "BAD a risk list, a slide marked \"retail_first\": false or a flow that does not fit was re-laid"
        if not re.search(r"EXPERT retail: slide 8: .*procure-to-pay", o):
            return "BAD the expert review did not name the procure to pay starter for slide 8"
        from pptx import Presentation as _P

        def walk(shapes):
            for sh in shapes:
                yield sh
                if sh.shape_type == 6:
                    yield from walk(sh.shapes)
        deck = [list(walk(s_.shapes)) for s_ in _P(w / "rfirst.pptx").slides]
        said = " ".join(sh.text_frame.text for s_ in deck for sh in s_ if sh.has_text_frame).lower()
        lost = [x for x in ("brand partners ship to our dcs", "shelves filled twice a week", "vendor bills the order",
                            "ap pays on terms", "carrier collects the parcel") if x not in said]
        if lost or not {"Retail (network)", "Retail (document-flow)"} <= {sh.name for s_ in deck for sh in s_} or \
                not any(sh.name.startswith("pictogram ") for sh in deck[5]):
            return "BAD the retail diagrams were not drawn, or words were lost: " + ", ".join(lost)
        r = subprocess.run([PY, "-I", "-c", "import sys, json; sys.path.insert(0, sys.argv[1]); import build_deck as B, retail as RT; "
                            "s = json.load(open(sys.argv[2]))['slides']; "
                            "dept = {'headline': 'Three teams own the vendor relationship', 'bullets': ['Vendor relations: "
                            "negotiate terms', 'Distribution center: plan labor', 'Customer service: answer questions']}; "
                            "print(RT.fit(dept) is None, B.retail_first([s[5], s[3]])[1] is s[3], "
                            "B.retail_first(s, converted=True) == s)", str(T), str(w / "rfirst.json")],
                           capture_output=True, text=True, cwd=w, timeout=120)
        if r.stdout.split()[-3:] != ["True", "True", "True"]:             # (after the build's own notes)
            return f"BAD a department list was read as a supply chain, a new repeat was made, or a converted deck changed " \
                   f"({(r.stdout + r.stderr).strip()[-120:]})"
        return ("vendors to guests a network, documents a document flow, order to cash with pictograms, every word kept; "
                "risks, an opt-out and a loose fit left; procure to pay named")
    rows.append(run("retail and supply chain slides first", [T / "build_deck.py", "build", w / "rfirst.json", "--out",
                                                             w / "rfirst.pptx"], w, check=rfirst_ok))
    rows.append(run("site (pages for ChatGPT Sites)", [T / "site.py", w / "dash.html", w / "geodash.html", "--out", w / "dash-site", "--title", "Self-test site"], w,
                    check=site_ok))
    (w / "word.md").write_text("# Word check\n\n## Table of contents\n\n## Section\n\n| A | B |\n| --- | --- |\n| 1 | 2 |\n\n"
                               "## Second section\n\n> A prompt\n", encoding="utf-8")
    def word_ok(o):
        if "PASS  Ulta Word template" not in o:
            return "BAD not on the letterhead"
        import zipfile
        try:
            x = zipfile.ZipFile(w / "word.docx").read("word/document.xml").decode("utf-8", "ignore")
        except Exception:
            return "BAD no file"
        links = x.count('w:hyperlink w:anchor="_Toc')
        import docprops, stamp
        made = docprops.read_props(w / "word.docx")[1].get("Producer")
        if made != f"{stamp.PRODUCER} {stamp.SKILL_VERSION}":
            return f"BAD the file does not name its producer ({made!r})"
        return f"letterhead, table of contents ({links} links), producer named" if " TOC " in x and links >= 2 else "BAD the table of contents is not a real one"
    rows.append(run("Word file (Ulta template)", [T / "ulta_word.py", "md", w / "word.md", "--out", w / "word.docx"], w, check=word_ok))
    def excel_ok(o):                                   # the KPI workbook: sheets, table, native charts, formulas with values
        x = w / "kpi.xlsx"
        if not x.exists():
            return "BAD no workbook"
        if "values, not formulas" in o:
            return "BAD some numbers are values: " + next(l for l in o.splitlines() if "values, not formulas" in l).strip()[:70]
        z = zipfile.ZipFile(x); names = z.namelist()
        sheets = re.findall(r'<sheet [^>]*name="([^"]+)"', z.read("xl/workbook.xml").decode("utf-8"))
        charts = [n for n in names if re.match(r"xl/charts/chart\d+\.xml$", n)]
        tables = [n for n in names if re.match(r"xl/tables/table\d+\.xml$", n)]
        cells = "".join(z.read(n).decode("utf-8") for n in names if n.startswith("xl/worksheets/sheet"))
        f = len(re.findall(r"<f>", cells)); empty = len(re.findall(r"</f>(?:<v></v>|<v/>)?</c>", cells))
        app = (re.findall(r"<Application>([^<]*)<", z.read("docProps/app.xml").decode("utf-8")) or [""])[0]
        if sheets[:4] != ["Scorecard", "Chart data", "Data", "Notes"] or len(charts) < 2 or not tables:
            return f"BAD sheets {sheets}, {len(charts)} charts, {len(tables)} tables"
        if not f or empty:
            return f"BAD {f} formulas, {empty} without a value"
        if not app.startswith("Ulta Presentation Central"):
            return f"BAD the workbook calls itself {app!r}"
        drawing = "".join(z.read(n).decode("utf-8") for n in names if re.match(r"xl/drawings/drawing\d+\.xml$", n))
        if drawing.count("<twoCellAnchor>") < len(charts) or "<oneCellAnchor>" in drawing:
            return "BAD a chart placed by its size, not tied to its cells (it runs into its neighbour in other viewers)"
        try:
            rec = {r["check"].split(" (")[0]: r["result"] for r in json.loads((w / "kpi.xlsx.checks.json").read_text())["rows"]}
        except (OSError, ValueError, KeyError):
            rec = {}
        if rec.get("Layout") != "PASS" or rec.get("Readable text") != "PASS":
            return f"BAD layout {rec.get('Layout')}, text contrast {rec.get('Readable text')}"
        d = subprocess.run([PY, str(T / "dashboard.py"), "build", str(w / "sales.csv"), "--out", str(w / "dashx"), "--excel"],
                           capture_output=True, text=True, cwd=w, timeout=600).stdout
        if "workbook: READY" not in d:
            return "BAD dashboard --excel: " + next((l.strip() for l in d.splitlines() if "workbook" in l), "no workbook line")[:70]
        return (f"{len(charts)} native charts tied to their cells, {f} formulas with their values, layout and contrast checked, "
                "the data as an Excel table; dashboard --excel too")
    rows.append(run("Excel KPI workbook", [T / "ulta_excel.py", "build", w / "sales.csv", "--out", w / "kpi", "--title", "Sales"], w, check=excel_ok))
    desc = next((l[12:].strip() for l in (T.parent / "SKILL.md").read_text(encoding="utf-8").splitlines()[:6] if l.startswith("description:")), "")
    bs = subprocess.run([sys.executable, str(T / "bootstrap.py")], capture_output=True, text=True).stdout
    bad = [l for l in bs.splitlines() if l.startswith("FAIL")]
    rows.append(("startup integrity (bootstrap)", "READY" in bs.splitlines()[-1] if bs.strip() else False, "-",
                 ("READY" if bs.strip() else "no output") if not bad else "NOT READY: " + "; ".join(b[:80] for b in bad[:3]), 0.0))
    rows.append(("skill description (upload limit)", 0 < len(desc) <= 500, "-", f"{len(desc)} characters" + ("" if len(desc) <= 500 else " - BAD over 500, the upload is refused"), 0.0))
    import random as _r; _r.seed(3)                  # an order header and its lines, as two files
    (w / "so_head.csv").write_text("Sales Order,Order Date,Region,Status\n" + "\n".join(
        f"SO{i},2026-{1 + i % 12:02d}-{1 + i % 27:02d},{['North', 'South', 'East', 'West'][i % 4]},{'Shipped' if i % 9 else 'Backordered'}"
        for i in range(300)), encoding="utf-8")
    (w / "so_lines.csv").write_text("Order Number,Item,Category,Quantity,Net Value\n" + "\n".join(
        f"SO{i},{10 * (k + 1)},{['Skin', 'Hair', 'Makeup'][(i + k) % 3]},{1 + k},{round(_r.uniform(5, 60), 2)}"
        for i in range(300) for k in range(1 + i % 3)), encoding="utf-8")
    rows.append(run("header + item tables (join)", [T / "chart_advisor.py", w / "so_head.csv", w / "so_lines.csv",
                                                    "--build", w / "so.pptx"], w,
                    check=lambda o: "" if "JOINED" in o and "300 orders" in o else "BAD tables not joined"))
    rows.append(run("whiteboard", [T / "whiteboard.py", "build", "--method", "fishbone", "--topic", "Late orders", "--blank", "--out", w / "wb"], w))
    rows.append(run("whiteboard slide (python -I)", ["-I", T / "whiteboard.py", "build", "--method", "swot", "--topic", "Store launch",
                                                     "--blank", "--out", w / "wb2", "--deck"], w,
                    check=lambda o: "board and slide READY in standard fonts" if re.search(r"slide: READY", o)
                    else "BAD the slide is not READY: " + next((l.strip() for l in o.splitlines() if "slide" in l), "no slide")[:70]))
    try:
        import template_infographics as _TI, look as _LK, typeset as _TS, brand as _BR
        word = (_TI._long_word("Inventory", int(1.4 * 914400), 28, True) == "Inventory"
                and _TI._long_word("$1.2B", int(1.4 * 914400), 28, True) is None)      # 'Inventor / y' in a donut's hole
        foot = (_LK.footer_like("Only") and _LK.footer_like("Ulta Beauty | Internal Use")
                and not _LK.footer_like("Net sales rose 4%"))                          # a classification footer is chrome
        b_ = _BR.current(); sp_ = _TS.spec(b_); room = _TS.headline_room(b_); txt = "Net sales rose"
        while _TS.headline_fits(txt + "i", room, sp_["headline"][1], sp_["headline"][0], b_):
            txt += "i"
        tight = not _TS.fits_headline(txt)               # a headline filling its box fails the deck check: never offered
        rows.append(("fit checks (word, footer, headline)", word and foot and tight, "-",
                     "a word wider than its box, classification footers, headline margin" if word and foot and tight else
                     "BAD " + ", ".join(n for n, ok in (("long word", word), ("footer", foot), ("headline margin", tight)) if not ok), 0.0))
    except Exception as e:
        rows.append(("fit checks (word, footer, headline)", False, "CRASH", str(e)[:80], 0))
    rows.append(run("architecture (diagram standard)", [T / "enterprise_diagram.py", T.parent / "brands" / "ulta" / "arch-example.json",
                                                         "--out", w / "arch"], w, check=lambda o: "" if " 0 violation(s)" in o else "BAD audit"))
    rows.append(run("architecture (kit arch.json)", [T / "enterprise_diagram.py", T.parent / "brands" / "ulta" / "arch-example-kit.json",
                                                         "--out", w / "arch2"], w, check=lambda o: "" if " 0 violation(s)" in o else "BAD audit"))
    if not a.quick:
        rows.append(run("convert deck → template", [T / "convert_deck.py", w / "cards-e.pptx" if (w / "cards-e.pptx").exists() else w / "cards.pptx",
                                                    "--out", w / "conv.pptx", "--build"], w))
        from pptx import Presentation as _Prs           # a plain deck: the agenda as a numbered table, the stages as one
        from pptx.util import Inches as _In              # table row, two text boxes of one short sentence each
        src = _Prs()
        s_ = src.slides.add_slide(src.slide_layouts[0]); s_.shapes.title.text = "Store operations review"
        s_ = src.slides.add_slide(src.slide_layouts[5]); s_.shapes.title.text = "Agenda"
        t_ = s_.shapes.add_table(4, 2, _In(0.5), _In(1.5), _In(9), _In(3)).table
        for r_, it in enumerate(["Context", "Operating model", "Measures", "Next steps"]):
            t_.cell(r_, 0).text = str(r_ + 1); t_.cell(r_, 1).text = it
        s_ = src.slides.add_slide(src.slide_layouts[5]); s_.shapes.title.text = "Orders pass two core services"
        for x_, txt in ((0.5, "Digital channels submit customer orders to an order service."),
                        (5.2, "Inventory availability informs fulfillment and exception handling.")):
            s_.shapes.add_textbox(_In(x_), _In(2), _In(4.3), _In(2)).text_frame.text = txt
        s_ = src.slides.add_slide(src.slide_layouts[5]); s_.shapes.title.text = "Delivery follows five controlled stages"
        t_ = s_.shapes.add_table(1, 5, _In(0.5), _In(2), _In(9), _In(0.6)).table
        for c_, v_ in enumerate(["Discover", "Design", "Build", "Test", "Launch"]):
            t_.cell(0, c_).text = v_
        s_ = src.slides.add_slide(src.slide_layouts[5]); s_.shapes.title.text = "2026 Priorities"   # a vision over pillars
        s_.shapes.add_textbox(_In(0.5), _In(1.4), _In(9), _In(0.5)).text_frame.text = "Vision: Every guest leaves happier"
        for k_, (n_, t_x) in enumerate((("Stores", "Faster checkout"), ("Online", "One-tap reorder"), ("Services", "Book in two taps"))):
            tf_ = s_.shapes.add_textbox(_In(0.5 + 3 * k_), _In(2.5), _In(2.8), _In(1.5)).text_frame
            tf_.text = n_; tf_.add_paragraph().text = t_x
        s_ = src.slides.add_slide(src.slide_layouts[5]); s_.shapes.title.text = "Services plan on a page"   # an OGSM table
        t_ = s_.shapes.add_table(4, 2, _In(0.5), _In(1.5), _In(9), _In(4)).table
        for r_, (k_, v_) in enumerate((("Objective", "Make services the first choice"), ("Goals", "Grow services 15%"),
                                        ("Strategies", "Book: online booking everywhere"), ("Measures", "Bookings +15% vs last year"))):
            t_.cell(r_, 0).text = k_; t_.cell(r_, 1).text = v_
        src.save(w / "plain-src.pptx")
        want = {"agenda slide": r"agenda\s+← 4 items \(from a table\)", "two tiles": r"points \(2\)", "chevron": r"process \(5 stages\)",
                "vision house": r"vision house ← '2026 Priorities' \(0 goals, 3 pillars\)", "OGSM": r"OGSM\s+← 'Services plan on a page'"}
        rows.append(run("convert: agenda, vision, OGSM", [T / "convert_deck.py", w / "plain-src.pptx", "--out",
                                                                 w / "conv2.pptx", "--build"], w,
                        check=lambda o: ", ".join(want) if all(re.search(v, o) for v in want.values()) else
                        "BAD not on their slides: " + ", ".join(k for k, v in want.items() if not re.search(v, o))))
    import plain                                        # every file above, and every PDF drawn: no em dash a reader sees
    made = sorted(p for p in w.rglob("*") if p.suffix in (".pptx", ".docx", ".xlsx", ".html", ".svg", ".drawio")
                  and "_source" not in str(p))
    left = [(p.name, plain.remaining(p)) for p in made]
    if shutil.which("pdftotext"):
        for p in sorted(w.rglob("*.pdf")):
            txt = subprocess.run(["pdftotext", str(p), "-"], capture_output=True, text=True).stdout
            left.append((p.name, txt.count("\u2014")))
    left = [x for x in left if x[1]]
    rows.append(("plain punctuation (no em dash)", not left and bool(made), "-",
                 f"{len(made)} files clean" if not left else f"{left[0][0]}: {left[0][1]} em dash(es)"
                 + (f" (+{len(left) - 1} more files)" if len(left) > 1 else ""), 0.0))
    rows.append(broken_files(w))
    import ooxml_check                                  # every file above: would PowerPoint / Word open it clean?
    office = sorted(p for p in w.rglob("*") if p.suffix in (".pptx", ".docx") and "_validation" not in str(p) and "_source" not in str(p))
    bad = [(p.name, l) for p in office for l in ooxml_check.summary(p, 1)]
    rows.append(("opens clean in PowerPoint/Word", not bad and bool(office), "-",
                 f"{len(office)} files valid (ISO/IEC 29500)" if not bad else f"{bad[0][0]}: {bad[0][1][:70]}", 0.0))
    def shadow_linked(p):                              # shapes a LibreOffice preview (ChatGPT) would draw with a theme shadow
        z = zipfile.ZipFile(p); n = 0
        for part in z.namelist():
            if re.match(r"ppt/slides/slide\d+\.xml$", part):
                for sp in re.findall(r"<p:(?:sp|cxnSp)\b[^>]*>.*?</p:(?:sp|cxnSp)>", z.read(part).decode("utf-8", "ignore"), re.S):
                    own = p.name.startswith("own") or re.search(r'name="(ULTA|modern)', sp)
                    n += bool(own and re.search(r'<a:effectRef idx="[1-9]', sp))
        return n
    decks = [p for p in office if p.suffix == ".pptx"]
    raised = [(p.name, shadow_linked(p)) for p in decks]
    raised = [x for x in raised if x[1]]
    rows.append(("flat shapes in every viewer", not raised and bool(decks), "-",
                 f"{len(decks)} files: no drawn shape linked to a theme shadow" if not raised else f"BAD {raised[0][0]}: {raised[0][1]} shapes would show a shadow in previews", 0.0))
    import privacy                                      # no template author, editor, comment authors or SharePoint people
    made = [p for p in office if p.name != "plain-src.pptx"]     # (the convert test's input is a user's file, not ours)
    people = [(p.name, f"{x[0]}: {x[1]}") for p in made for x in privacy.findings(p)]
    pdfs = sorted(p for p in w.rglob("*.pdf") if "_validation" not in str(p) and "_source" not in str(p))
    try:
        from pypdf import PdfReader
        for p in pdfs:
            who = str((PdfReader(str(p)).metadata or {}).get("/Author") or "")
            if who and who.strip().lower() in privacy.template_people():
                people.append((p.name, f"PDF author '{who}'"))
    except Exception:
        pass
    rows.append(("no hidden personal data", not people and bool(office), "-",
                 f"{len(office)} files, {len(pdfs)} PDFs clean" if not people else f"{people[0][0]}: {people[0][1][:70]}"
                 + (f" (+{len(people) - 1} more)" if len(people) > 1 else ""), 0.0))
    rows.extend(library_checks(w))
    skipped = [r[0] for r in rows if r[2] == "SKIP"]
    rows = [r for r in rows if r[2] != "SKIP"]
    import importlib.util
    tools = {k: bool(shutil.which(k)) for k in ("soffice", "pdftoppm")}
    tools["resvg"] = importlib.util.find_spec("resvg_py") is not None
    print(f"{'check':<32}{'ok':<4}{'status':<18}{'sec':>6}  note")
    for n, ok, st, note, dt in rows:
        print(f"{n:<32}{'✓' if ok else '✗':<4}{st:<18}{dt:>6}  {note}")
    passed = sum(r[1] for r in rows)
    if passed == len(rows) and not a.keep:              # nothing to look into: leave no sample files in the temp folder
        shutil.rmtree(w, ignore_errors=True)
    print(f"SELFTEST {passed}/{len(rows)} passed in {sum(r[4] for r in rows):.0f}s | renderers: "
          + ", ".join(f"{k} {'yes' if v else 'NO'}" for k, v in tools.items())
          + (f" | work folder {w}" if w.exists() else " | work folder removed"))
    if skipped:
        print(f"not part of this PowerPoint skill (not run): {', '.join(skipped)}")


if __name__ == "__main__":
    main()
