"""Project timelines drawn natively in the Ulta template's own visual language (tools/native_draw.py).

Every style is built from the template's parts - the blush page, white rounded cards, header bars and tabs in the theme
colours (template order: magenta, pink-red, red-orange, orange), blush / white period bands like template slides
15-19, black Circular text on the template's type scale - so it sits next to the template's own timeline slides as
if it came with them. Shapes are native and grouped (one object to move), text sits inside its shape, connectors are
glued, white text only where it passes contrast (ND.contrast_text), status colours only as small marks.

Storyboard slide:   {"timeline": {...}, "style": "<style>", "headline": "<takeaway with a number>", "notes": "..."}
Timeline data:      {"items": [{"name", "group", "start", "end", "date", "milestone", "owner", "status", "text"}],
                     "start", "end", "today", "unit": "week|month|quarter", "data": "plan.xlsx"}
  dates             2026-03-15, "Mar 15, 2026", "Mar 2026" (a month), "Q2 2026" (a quarter); a milestone needs only
                    "date"; "data" reads Task / Start / End / Group / Milestone (+ Owner, Status, Notes) columns
  group             the workstream (lanes, status-roadmap), phase (phases), release (sprints) or now / next / later
  status            done | on track | at risk | late - a green / amber / red mark plus the word, never coloured text
  text              one line of detail; phases and countdown split it on ";" into deliverables / checks
  today             the "today" marker (default: the real date; false hides it); "golive": true marks the go-live

Styles (STYLES, gallery order) - when to use them and their limits:
  lanes             a plan by workstream (template slide 15's look) - 2-6 workstreams, up to 14 tasks and milestones
  status-roadmap    a steering-committee view: deliverables, owners, status, today - up to 12 rows
  phases            a programme in stages: chevrons with dates, deliverables, real-duration ruler - 3-6 phases
  quarters          a year roadmap: quarter blocks, launches above, deliverables below - 2-6 quarters, 8 milestones
  sprints           an agile release train: equal sprints, goals, releases - 3-12 sprints, 4 releases
  now-next-later    a product roadmap without firm dates (template slide 7's cards) - 1-5 items per column
  countdown         readiness for one go-live: T-minus gates and the go-live badge - 3-7 gates
  storyline         a history or rollout story: dated events above and below one line - 5-8 events
  vertical          a short list of key dates with detail: spine of date badges and wide cards - 4-7 milestones
  calendar          a year at a glance: month tiles, key dates circled and named - 6 or 12 months, 3 dates a month

    import timelines as TL
    style = TL.auto_style(spec["timeline"]); problems = TL.lint(spec) + TL.draw(slide, box, spec)
"""
import calendar as _cal
import datetime as dt
import re

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
from pptx.util import Pt

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # run on its own (python -I too): its sibling modules
import native_draw as ND

IN, PT = ND.IN, 12700
A = ND.A
K = 1.07                       # the preview font (Inter) sets ~6% wider than Circular: lay out with headroom
LS = 1.265                     # Circular's line height / point size (ascent .997 + descent .268): the fit checker's
LS_DISPLAY = 1.333             # Playfair Display's (1.082 + .251)

STYLES = {
    "lanes": "Workstream Gantt in template slide 15's look: period bands, coloured workstream tabs, labelled bars, "
             "milestone diamonds, today line (2-6 workstreams, up to 14 tasks)",
    "status-roadmap": "Status roadmap: one row per deliverable with its owner and a green / amber / red status edge, "
                      "bars on period bands, milestones, today line, legend (up to 12 rows)",
    "phases": "Phase chevrons across the slide with each phase's dates and deliverables, the current phase marked, "
              "and a ruler of the real durations (3-6 phases)",
    "quarters": "Quarter blocks on one band with launch markers above and each quarter's deliverables below "
                "(2-6 quarters)",
    "sprints": "Release train: equal sprint cards with dates and goals under the releases they ship, release markers "
               "on a dated axis, the current sprint marked (3-12 sprints)",
    "now-next-later": "Now / Next / Later cards with coloured header bars (template slide 7) listing what ships in each "
                      "horizon (1-5 items per column)",
    "countdown": "T-minus countdown: readiness gates counting down to a go-live badge, done and at-risk gates marked "
                 "(3-7 gates)",
    "storyline": "Story line: dated dots on one line with text cards alternating above and below (5-8 events)",
    "vertical": "Vertical spine of date badges with a wide card per milestone, years and today marked (4-7 milestones)",
    "calendar": "Year at a glance: month tiles with key dates circled and named (6 or 12 months, up to 3 dates a month)",
}

STATUS_OF = {"done": "done", "complete": "done", "completed": "done", "closed": "done", "shipped": "done",
             "live": "done", "on track": "on track", "on-track": "on track", "ontrack": "on track", "green": "on track",
             "ok": "on track", "in progress": "on track", "g": "on track", "at risk": "at risk", "at-risk": "at risk",
             "amber": "at risk", "yellow": "at risk", "risk": "at risk", "watch": "at risk", "a": "at risk",
             "late": "late", "red": "late", "off track": "late", "off-track": "late", "blocked": "late",
             "delayed": "late", "overdue": "late", "r": "late"}
STATUS_FILL = {"done": ND.STATUS["green"], "on track": ND.STATUS["green"], "at risk": ND.STATUS["amber"],
               "late": ND.STATUS["red"]}
STATUS_WORD = {"done": "Done", "on track": "On track", "at risk": "At risk", "late": "Late"}
GOLIVE = re.compile(r"go[\s-]?live|launch|cut[\s-]?over|\blive\b|grand opening|\bopening\b", re.I)
NNL = {"done": 0, "now": 1, "next": 2, "later": 3}


def _in(v):
    return int(round(v * IN))


# ============================================================================================ text measuring
_MET = []


def _metrics():
    if not _MET:
        import brand as _B
        _MET.extend([_B, _B.metrics_for(_B.current())])
    return _MET


def _face(bold=False, face=None):
    return face or (ND.BOLD if bold else ND.BODY)


def _tw(text, pt, bold=False, face=None):
    """Width (EMU) of one line of text, with the preview headroom."""
    B, M = _metrics()
    ems = B.width_of(str(text), _face(bold, face), M)
    if ems is None:
        ems = len(str(text)) * 0.55
    return int(ems * pt * PT * K)


def _nlines(text, inner, pt, bold=False, face=None):
    """Lines text needs in an inner width (EMU): ND.text_lines (the build's own measure) with the preview headroom;
    the display face is measured the same way with its own metrics."""
    if face in (None, ND.BOLD, ND.BODY):
        return ND.text_lines(text, int(inner / K) + _in(0.16), pt, bold if face is None else face == ND.BOLD)
    B, M = _metrics()
    lines = 0
    for para in str(text).split("\n"):
        cur, lines = "", lines + 1
        for word in para.split():
            trial = (cur + " " + word).strip()
            if (B.width_of(trial, face, M) or len(trial) * 0.55) * pt * PT * K > inner and cur:
                lines, cur = lines + 1, word
            else:
                cur = trial
    return lines


def _lh(face=None):
    return LS_DISPLAY if face == ND.DISPLAY else LS


def _height(paras, inner):
    """EMU a stack of paragraphs [(text, pt, bold, face)] needs in an inner width (the fit checker's line height)."""
    return sum(_nlines(t, inner, pt, b, f) * pt * _lh(f) * PT for t, pt, b, f in paras if str(t).strip())


def _longest_word(text, pt, bold=False, face=None):
    return max((_tw(w_, pt, bold, face) for w_ in str(text).split()), default=0)


def _paras(parts):
    """[(text, pt, bold, colour, new_paragraph)] -> [(text, pt, bold, None)] per paragraph (largest size wins)."""
    out = []
    for t, pt, b, _c, newp in parts:
        if newp or not out:
            out.append([t, pt, b, None])
        else:
            out[-1][0] += t
            out[-1][1] = max(out[-1][1], pt)
            out[-1][2] = out[-1][2] or b
    return [tuple(p) for p in out]


# ============================================================================================ dates
def _date(v):
    """(date, precision) from 2026-03-15, 'Mar 15, 2026', 'Mar 2026' (month), 'Q2 2026' (quarter), '2026-03'."""
    if isinstance(v, dt.datetime):
        return v.date(), "day"
    if isinstance(v, dt.date):
        return v, "day"
    s = " ".join(str(v if v is not None else "").split())
    if not s:
        raise ValueError("no date")
    m = re.match(r"^(?:FY)?Q([1-4])\s*[-/ ]?\s*['’]?(\d{2}|\d{4})$", s, re.I)
    if m:
        y = int(m.group(2))
        return dt.date(y + 2000 if y < 100 else y, 3 * int(m.group(1)) - 2, 1), "quarter"
    m = re.match(r"^(\d{4})\s*[-/ ]?\s*Q([1-4])$", s, re.I)
    if m:
        return dt.date(int(m.group(1)), 3 * int(m.group(2)) - 2, 1), "quarter"
    m = re.match(r"^(\d{4})-(\d{1,2})$", s)
    if m:
        return dt.date(int(m.group(1)), int(m.group(2)), 1), "month"
    m = re.match(r"^(\d{4}-\d{2}-\d{2})[T ][\d:.]+$", s)            # an ISO timestamp from a sheet
    if m:
        s = m.group(1)
    s2 = re.sub(r"\bSept\b", "Sep", s)
    import modern_charts as MC
    d = MC._date(s2)
    return d, ("month" if re.match(r"^[A-Za-z]+\.?\s+\d{4}$", s2) else "day")


def _month_end(d):
    return dt.date(d.year, d.month, _cal.monthrange(d.year, d.month)[1])


def _add_months(d, n):
    y, m = divmod(d.month - 1 + n, 12)
    return dt.date(d.year + y, m + 1, 1)


def _end_of(d, prec):
    if prec == "month":
        return _month_end(d)
    if prec == "quarter":
        return _add_months(d, 3) - dt.timedelta(days=1)
    return d


def _md(d, prec="day", year=False):
    """'Mar 14' / 'Mar 14, 2026' / 'Mar 2026' / 'Q2 2026'."""
    if prec == "quarter":
        return f"Q{(d.month - 1) // 3 + 1} {d.year}"
    if prec == "month":
        return f"{d:%b} {d.year}"
    return f"{d:%b} {d.day}" + (f", {d.year}" if year else "")


def _range(a, b, pa="day", pb="day", year=False):
    """'Mar 2 - Apr 10', 'Mar 2–14', 'Jan - Mar 2026'."""
    if pa != "day" or pb != "day":
        if (a.year, a.month) == (b.year, b.month):
            return _md(a, "month")
        left = f"{a:%b}" + (f" {a.year}" if a.year != b.year else "")
        return f"{left} – {b:%b} {b.year}"
    if a == b:
        return _md(a, year=year)
    if (a.year, a.month) == (b.year, b.month):
        return f"{a:%b} {a.day}–{b.day}" + (f", {a.year}" if year else "")
    left = _md(a, year=year and a.year != b.year)
    return f"{left} – {_md(b, year=year)}"


def _duration(a, b):
    days = (b - a).days + 1
    if days < 14:
        return f"{days} day{'s' if days != 1 else ''}"
    if days <= 7 * 26:
        return f"{round(days / 7)} weeks"
    return f"{round(days / 30.44)} months"


def _mid(i):
    """Where a milestone sits: its day, or the middle of its month / quarter."""
    if i["sp"] == "month":
        return i["start"] + dt.timedelta(days=14)
    if i["sp"] == "quarter":
        return i["start"] + dt.timedelta(days=45)
    return i["start"]


# ============================================================================================ data
def _words(t):
    return len(str(t or "").split())


def _plan(path, sheet, P):
    """Items from an Excel / CSV plan (modern_charts.read_plan) plus its Owner / Status / Notes columns."""
    import modern_charts as MC
    try:
        import data_slides as DS
        p = DS.resolve(path)
    except BaseException:                                   # data_slides.resolve exits when the file is missing
        P.append(f"plan file '{path}' was not found - put it next to the storyboard (or in /mnt/data) and give its "
                 "file name in \"data\"")
        return []
    try:
        tasks = MC.read_plan(str(p), sheet)
    except Exception as e:
        P.append(f"plan '{path}' could not be read ({str(e)[:80]}) - it needs columns Task, Start, End "
                 "(+ Group, Milestone, Owner, Status)")
        return []
    rows = []
    try:
        if str(p).lower().endswith(".csv"):
            import csv
            with open(p, encoding="utf-8-sig") as fh:
                rows = list(csv.DictReader(fh))
        else:
            import openpyxl
            wb = openpyxl.load_workbook(p, data_only=True)
            ws = wb[sheet] if sheet else wb.active
            it = ws.iter_rows(values_only=True)
            head = [str(h_ or "").strip() for h_ in next(it)]
            rows = [dict(zip(head, r)) for r in it if any(c not in (None, "") for c in r)]
    except Exception:
        rows = []

    def pick(r, *ks):
        return next((r[k] for k in r if str(k).strip().lower() in ks and r[k] not in (None, "")), None)
    rows = [r for r in rows if pick(r, "task", "activity", "name", "deliverable", "milestone name")]
    out = []
    for i, t in enumerate(tasks):
        r = rows[i] if i < len(rows) else {}
        out.append({"name": t["task"], "group": t.get("group") or "", "start": t.get("start"), "end": t.get("end"),
                    "milestone": bool(t.get("milestone")),
                    "owner": pick(r, "owner", "lead", "responsible", "accountable") or "",
                    "status": pick(r, "status", "rag", "health") or "",
                    "text": pick(r, "notes", "note", "text", "description", "detail", "goal", "comment") or ""})
    return out


def _clean(v):
    return " ".join(str(v or "").split())


def _parse(data, need_dates=True):
    """{items, lo, hi, today, unit, problems}. Items: name, group, start, end, ms (milestone), sp / ep (precision),
    owner, status, text, golive, k (input order). Undated items are reported, not drawn (unless need_dates is False)."""
    data = data if isinstance(data, dict) else {"items": data if isinstance(data, list) else []}
    P = []
    raw = list(data.get("items") or [])
    if data.get("data"):
        raw += _plan(data["data"], data.get("sheet"), P)
    items = []
    for k, it in enumerate(raw, 1):
        if isinstance(it, str):
            it = {"name": it}
        if not isinstance(it, dict):
            P.append(f"timeline item {k} is not an object - write {{\"name\": \"...\", \"start\": \"2026-03-02\", "
                     "\"end\": \"2026-04-10\"}}")
            continue
        name = _clean(it.get("name") or it.get("task") or it.get("title") or it.get("label"))
        if not name:
            P.append(f"timeline item {k} has no name - give it a 2-5 word name")
            continue
        sv = it.get("start") or it.get("begin")
        ev = it.get("end") or it.get("finish") or it.get("due")
        dv = it.get("date")
        rec = {"name": name, "k": k,
               "group": _clean(it.get("group") or it.get("workstream") or it.get("lane") or it.get("phase")
                               or it.get("release") or it.get("team")),
               "owner": _clean(it.get("owner") or it.get("lead")),
               "text": _clean(it.get("text") or it.get("detail") or it.get("goal") or it.get("notes")),
               "golive": bool(it.get("golive") or it.get("go_live")), "start": None, "end": None, "ms": False,
               "sp": "day", "ep": "day"}
        st_raw = str(it.get("status") or "").strip().lower()
        rec["status"] = STATUS_OF.get(st_raw, "?" if st_raw else "")
        rec["status_raw"] = st_raw
        try:
            if sv not in (None, "") and ev not in (None, ""):
                (s, sp), (e, ep) = _date(sv), _date(ev)
                e = _end_of(e, ep)
                if e < s:
                    s, e, sp, ep = e, s, ep, sp
                rec.update(start=s, end=e, sp=sp, ep=ep)
            elif dv not in (None, "") or sv not in (None, "") or ev not in (None, ""):
                d, p = _date(dv if dv not in (None, "") else (ev if ev not in (None, "") else sv))
                rec.update(start=d, end=d, sp=p, ep=p, ms=True)
            elif need_dates:
                P.append(f"timeline item '{name[:40]}' has no date - give it \"start\" and \"end\" (2026-03-02, "
                         "\"Mar 2026\" or \"Q2 2026\"), or \"date\" for a milestone")
                continue
        except Exception:
            bad = next((v for v in (sv, ev, dv) if v not in (None, "")), "")
            P.append(f"timeline item '{name[:40]}': '{bad}' is not a date - write 2026-03-15, \"Mar 15, 2026\", "
                     "\"Mar 2026\" or \"Q2 2026\"")
            continue
        if it.get("milestone") and rec["start"] is not None and not rec["ms"]:
            rec.update(start=rec["end"], sp=rec["ep"], ms=True)     # a milestone falls on its end date
        items.append(rec)
    dated = [i for i in items if i["start"] is not None]
    lo = min((i["start"] for i in dated), default=None)
    hi = max((max(i["end"], _mid(i)) if i["ms"] else i["end"] for i in dated), default=None)
    for key in ("start", "end"):
        if data.get(key):
            try:
                d, p = _date(data[key])
                if key == "start":
                    lo = d if lo is None else min(lo, d)
                else:
                    d = _end_of(d, p)
                    hi = d if hi is None else max(hi, d)
            except Exception:
                P.append(f"timeline \"{key}\": '{data[key]}' is not a date - write 2026-03-15 or \"Mar 2026\"")
    today = dt.date.today()
    if "today" in data:
        try:
            today = _date(data["today"])[0] if data["today"] else None
        except Exception:
            P.append(f"timeline \"today\": '{data['today']}' is not a date - write 2026-03-15, or false to hide it")
            today = None
    unit = str(data.get("unit") or "").strip().lower() or None
    if unit and unit not in ("week", "month", "quarter"):
        P.append(f"timeline \"unit\": '{unit}' - use week, month or quarter (or leave it out)")
        unit = None
    for i in items:
        if i["status"] == "?":
            P.append(f"timeline item '{i['name'][:40]}': status '{i['status_raw']}' - use done, on track, at risk or late")
            i["status"] = ""
    first = {}
    for i in items:                                             # groups keep the order the user listed them in
        first.setdefault(i["group"], i["k"])
    items.sort(key=lambda i: (i["start"] or dt.date.max, i["end"] or dt.date.max, i["k"]))
    return {"items": items, "lo": lo, "hi": hi, "today": today, "unit": unit, "problems": P,
            "group_order": [g for g, _ in sorted(first.items(), key=lambda kv: kv[1])],
            "start_given": bool(data.get("start"))}


def _groups(T, items=None):
    items = T["items"] if items is None else items
    present = {i["group"] for i in items}
    order = [g for g in T.get("group_order", []) if g in present]
    return order or [""]


# ============================================================================================ period axis
def _periods(lo, hi, unit=None):
    """Equal columns covering lo..hi: ([(start, next_start)], unit)."""
    months = (hi.year - lo.year) * 12 + hi.month - lo.month + 1
    days = (hi - lo).days + 1
    if unit not in ("week", "month", "quarter"):
        unit = "week" if days <= 84 else "month" if months <= 15 else "quarter"
    out = []
    if unit == "week":
        s = lo - dt.timedelta(days=lo.weekday())
        while s <= hi:
            out.append((s, s + dt.timedelta(days=7)))
            s += dt.timedelta(days=7)
    elif unit == "month":
        s = dt.date(lo.year, lo.month, 1)
        while s <= hi:
            out.append((s, _add_months(s, 1)))
            s = _add_months(s, 1)
    else:
        s = dt.date(lo.year, 3 * ((lo.month - 1) // 3) + 1, 1)
        while s <= hi:
            out.append((s, _add_months(s, 3)))
            s = _add_months(s, 3)
    return out, unit


def _period_labels(periods, unit, cw, pt):
    """One label per column that fits the column width at pt (the year on the first column and where it changes)."""
    room = cw - _in(0.1)
    labs = []
    for i, (s, _) in enumerate(periods):
        if unit == "week":
            first = i == 0 or s.month != periods[i - 1][0].month
            cands = ([f"{s:%b} {s.day}, {s.year}"] if i == 0 else []) + ([f"{s:%b} {s.day}", f"{s.day}"] if first
                                                                          else [f"{s.day}"])
        elif unit == "month":
            yr = i == 0 or s.month == 1
            cands = ([f"{s:%b} {s.year}", f"{s:%b} '{s:%y}"] if yr else []) + [f"{s:%b}", f"{s:%b}"[:1]]
        else:
            q = (s.month - 1) // 3 + 1
            cands = [f"Q{q} {s.year}", f"Q{q} '{s:%y}", f"Q{q}"]
        labs.append(next((c for c in cands if _tw(c, pt) <= room), cands[-1]))
    return labs


def _xmap(periods, gx, cw):
    def X(d):
        for i, (s, n) in enumerate(periods):
            if d < n:
                return gx + (i + max(0, (d - s).days) / max(1, (n - s).days)) * cw
        return gx + len(periods) * cw
    return X


# ============================================================================================ drawing helpers
class _Canvas:
    """Collects the shapes of one graphic (z-order = creation order) and the problems found while drawing."""

    def __init__(self, sl, box):
        self.sl, self.box, self.shapes, self.P = sl, box, [], []

    def add(self, sh):
        if sh is not None:
            self.shapes.append(sh)
        return sh

    def check(self, paras, w, h, what, ml=0.08, mt=0.048):
        """Fit check of a text stack [(text, pt, bold, face)] in a w x h box (EMU) with insets ml / mt (inches):
        records a problem when it would overflow at its size."""
        inner = w - _in(2 * ml)
        paras = [p for p in paras if str(p[0]).strip()]
        if not paras:
            return True
        need = _height(paras, inner) + _in(2 * mt)
        text = " ".join(str(p[0]) for p in paras)
        for t, pt, b, f in paras:
            if _longest_word(t, pt, b, f) > inner + _in(0.01):
                self.P.append(f"{what}: the word '{max(str(t).split(), key=len)[:30]}' is wider than its box - use a "
                              "shorter word")
                return False
        if need > h + _in(0.02):
            self.P.append(f"{what} '{text[:45]}' does not fit its box at {paras[0][1]:g} pt - shorten it")
            return False
        return True

    def rect(self, x, y, w, h, fill, r=None, line=None, line_w=0.75, name="timeline shape", kind=None, **text):
        """A rectangle (r = corner radius in inches; None = square corners), template-styled, text inside."""
        if kind is None:
            kind = "ROUNDED_RECTANGLE" if r else "RECTANGLE"
        radius = None
        if r and kind == "ROUNDED_RECTANGLE":
            radius = min(0.5, _in(r) / max(1, min(w, h)))
        sh = ND.shape(self.sl, kind, int(x), int(y), max(1, int(w)), max(1, int(h)), fill=fill, line=line,
                      line_w=line_w, radius=radius, name=name, **text)
        return self.add(sh)

    def top_rounded(self, x, y, w, h, fill, r, name="timeline header", flip=False, **text):
        """A bar with two rounded corners (the top ones; flip=True: the bottom ones) - sits flush on a rounded card."""
        sh = ND.shape(self.sl, "ROUND_2_SAME_RECTANGLE", int(x), int(y), int(w), int(h), fill=fill, name=name, **text)
        a = min(0.5, _in(r) / max(1, min(w, h)))
        sh.adjustments[0], sh.adjustments[1] = (0.0, a) if flip else (a, 0.0)
        return self.add(sh)

    def dot(self, cx, cy, d, fill, line=None, line_w=1.5, name="timeline dot", **text):
        """A circle with rectangle connection sites (a fully rounded square): connectors glue top/left/bottom/right."""
        return self.rect(cx - d / 2, cy - d / 2, d, d, fill, r=d / IN, line=line, line_w=line_w, name=name, **text)

    def diamond(self, cx, cy, d, fill, line=ND.WHITE, line_w=1.0, name="timeline milestone"):
        return self.add(ND.shape(self.sl, "DIAMOND", int(cx - d / 2), int(cy - d / 2), int(d), int(d), fill=fill,
                                 line=line, line_w=line_w, name=name))

    def tri(self, cx, y, w, h, fill, down=True, name="timeline pointer"):
        sh = ND.shape(self.sl, "ISOSCELES_TRIANGLE", int(cx - w / 2), int(y), int(w), int(h), fill=fill, name=name)
        if down:
            sh.rotation = 180
        return self.add(sh)

    def text(self, x, y, w, h, parts, align="l", anchor="t", ml=0.04, mt=0.02, name="timeline label"):
        """A free label (no fill): parts [(text, pt, bold, colour, new_paragraph)]."""
        tb = self.sl.shapes.add_textbox(int(x), int(y), max(1, int(w)), max(1, int(h)))
        ND.no_effects(tb)
        tb.name = name
        self._rich(tb, parts, align, anchor, ml, mt)
        return self.add(tb)

    def write(self, sh, parts, align="l", anchor="t", ml=0.08, mt=0.048, mr=None, mb=None):
        """Rich text inside an existing shape with explicit insets (inches)."""
        self._rich(sh, parts, align, anchor, ml, mt, mr, mb)
        return sh

    @staticmethod
    def _rich(sh, parts, align, anchor, ml, mt, mr=None, mb=None):
        kept, carry = [], False                             # an empty part is dropped (an empty paragraph still
        for t, pt, b, c, newp in parts:                     # measures at its inherited size); its paragraph break
            if str(t).strip():                              # carries over to the next part
                kept.append((t, pt, b, c, newp or carry))
                carry = False
            elif newp:
                carry = True
        parts = kept or [("", ND.T_BODY, False, ND.INK, False)]
        ND.rich(sh, parts, align=align, anchor=anchor, margin=ml)
        tf = sh.text_frame
        tf.margin_left, tf.margin_right = _in(ml), _in(ml if mr is None else mr)
        tf.margin_top, tf.margin_bottom = _in(mt), _in(mt if mb is None else mb)
        for r in sh._element.iter(A + "r"):                 # 'Mar 14' never breaks between month and day
            t = r.find(A + "t")
            if t is not None and t.text and re.search(r"\b[A-Z][a-z]{2} \d", t.text):
                t.text = re.sub(r"\b([A-Z][a-z]{2}) (\d)", "\\1\u00a0\\2", t.text)

    def face(self, sh, text, face=ND.DISPLAY):
        """Set the runs whose text is `text` in another face (the display face for big numbers and column titles)."""
        for r_ in sh._element.iter(A + "r"):
            if r_.findtext(A + "t") == text:
                lat = r_.find(A + "rPr").find(A + "latin")
                lat.set("typeface", face)

    def line(self, x1, y1, x2, y2, colour=ND.LINE, width=1.0, dash=None, name="timeline line"):
        return self.add(ND.line(self.sl, int(x1), int(y1), int(x2), int(y2), colour=colour, width=width, dash=dash,
                                name=name))

    def connect(self, a, b, a_site, b_site, colour=ND.LINE, width=1.25, elbow=False, name="timeline stem"):
        return self.add(ND.connect(self.sl, a, b, a_site, b_site, colour=colour, width=width, arrow=False,
                                   elbow=elbow, name=name))

    def group(self, name):
        g = ND.group(self.sl, self.shapes, name=name)
        self.shapes = [g] if g is not None else []
        return g


def _para(text, pt, bold=False, colour=ND.INK, newp=True):
    return (text, pt, bold, colour, newp)


def _space(sh, before=None, after=None, idx=None):
    """Paragraph spacing (pt) on the shape's paragraphs (all, or those in idx); returns the EMU it adds."""
    added = 0
    for k, p in enumerate(sh.text_frame.paragraphs):
        if idx is None or k in idx:
            if before is not None and k > 0:
                p.space_before = Pt(before)
                added += before * PT
            if after is not None:
                p.space_after = Pt(after)
                added += after * PT
    return added


def _bullets(sh, marker="• ", indent=0.13):
    """Paragraphs written '• text' become real bullets with a hanging indent (wrapped lines align with the text)."""
    for p in sh.text_frame.paragraphs:
        runs = p.runs
        if not runs or not runs[0].text.startswith(marker):
            continue
        runs[0].text = runs[0].text[len(marker):]
        pPr = p._p.get_or_add_pPr()
        pPr.set("marL", str(_in(indent)))
        pPr.set("indent", str(-_in(indent)))
        for tag in ("buFontTx", "buChar"):
            el = etree.SubElement(pPr, A + tag)
            if tag == "buChar":
                el.set("char", "•")
        order = [A + t for t in ("lnSpc", "spcBef", "spcAft", "buClrTx", "buClr", "buSzTx", "buSzPct", "buSzPts",
                                 "buFontTx", "buFont", "buNone", "buAutoNum", "buChar", "buBlip", "tabLst", "defRPr",
                                 "extLst")]
        kids = sorted(list(pPr), key=lambda e: order.index(e.tag) if e.tag in order else 99)
        for k_ in list(pPr):
            pPr.remove(k_)
        for k_ in kids:
            pPr.append(k_)


def _today_tag(C, cx, y, lo_x, hi_x, label="Today", pt=ND.T_SMALL):
    """A plum pill centred on x (kept inside lo_x..hi_x)."""
    w = _tw(label, pt, True) + _in(0.24)
    h = _in(0.25)
    x = min(max(cx - w / 2, lo_x), hi_x - w)
    return C.rect(x, y, w, h, ND.PLUM, r=0.5 * h / IN, name="timeline today tag", text=label, size=pt, bold=True,
                  color=ND.contrast_text(ND.PLUM), margin=0.02)


def _edge(C, x, y, h, status, name="timeline status"):
    """The status mark: a slim rounded bar in green / amber / red."""
    return C.rect(x, y, _in(0.06), h, STATUS_FILL[status], r=0.03, name=f"{name} {STATUS_WORD[status]}")


def _period_bands(C, periods, unit, gx, y, cw, h, pt):
    labs = _period_labels(periods, unit, cw, pt)
    for i, lab in enumerate(labs):
        C.rect(gx + i * cw, y, cw + 1, h, ND.WHITE if i % 2 == 0 else ND.BLUSH, name=f"timeline period {lab}",
               text=lab, size=pt, color=ND.INK, anchor="t", margin=0.04)
        C.shapes[-1].text_frame.margin_top = _in(0.07)


# ============================================================================================ style: lanes
def _clear(a, b, tx):
    """True when a label spanning a..b keeps clear of the today line at tx."""
    return tx is None or not (a - _in(0.05) <= tx <= b + _in(0.05))


def _side(right, left, lo, hi, tx):
    """Pick a label side: right / left spans (x1, x2); the first that fits lo..hi and keeps clear of the today line,
    else the first that fits, else None."""
    fits = [(k, sp) for k, sp in (("right", right), ("left", left)) if sp[0] >= lo and sp[1] <= hi]
    return next((k for k, sp in fits if _clear(sp[0], sp[1], tx)), fits[0][0] if fits else None)


def _lane_rows(items, X, gx, gw, pt, bh, tx=None):
    """Pack a lane's items into rows (first fit). Entry: (item, x_from, x_to, label place 'in'|'right'|'left',
    label x, label w). Labels outside a bar take the side that keeps clear of the today line."""
    gap = _in(0.1)
    rows = []
    for it in items:
        if it["ms"]:
            d = min(bh * 1.05, _in(0.3))
            cx = min(max(X(_mid(it)), gx + d / 2), gx + gw - d / 2)
            side = None
            for with_date in (True, False):                     # no room for name + date: the name alone
                lab = f"{it['name']}  {_md(it['start'], it['sp'])}" if with_date else it["name"]
                lw = _tw(lab, pt, True) + _in(0.08)
                r_ = (cx + d / 2 + _in(0.04), cx + d / 2 + _in(0.04) + lw)
                l_ = (cx - d / 2 - _in(0.04) - lw, cx - d / 2 - _in(0.04))
                side = _side(r_, l_, gx, gx + gw, tx)
                if side:
                    break
            if side is None:                                    # the larger side, the label clipped to it
                room_r, room_l = gx + gw - r_[0], l_[1] - gx
                side = "right" if room_r >= room_l else "left"
                lw = max(_in(0.3), room_r if side == "right" else room_l)
                r_ = (r_[0], r_[0] + lw)
                l_ = (l_[1] - lw, l_[1])
            it["_lab"] = lab
            ent = (it, cx - d / 2, r_[1], "right", r_[0], lw) if side == "right" else \
                (it, l_[0], cx + d / 2, "left", l_[0], lw)
        else:
            x1, x2 = X(it["start"]), X(it["end"] + dt.timedelta(days=1))
            x2 = max(x2, x1 + _in(0.14))
            lw = _tw(it["name"], pt, True) + _in(0.1)
            r_ = (x2 + _in(0.05), x2 + _in(0.05) + lw)
            l_ = (x1 - _in(0.05) - lw, x1 - _in(0.05))
            side = "in" if _tw(it["name"], pt, True) + _in(0.22) <= x2 - x1 else _side(r_, l_, gx, gx + gw, tx)
            if side == "in":
                ent = (it, x1, x2, "in", x1, x2 - x1)
            elif side == "right":
                ent = (it, x1, r_[1], "right", r_[0], lw)
            elif side == "left":
                ent = (it, l_[0], x2, "left", l_[0], lw)
            else:
                room_r, room_l = gx + gw - x2 - _in(0.06), x1 - gx - _in(0.06)
                ent = (it, x1, gx + gw, "right", x2 + _in(0.05), room_r) if room_r >= room_l else \
                    (it, gx, x2, "left", gx, room_l)
        for row in rows:
            if all(ent[1] >= o[2] + gap or ent[2] + gap <= o[1] for o in row):
                row.append(ent)
                break
        else:
            rows.append([ent])
    return rows


def _draw_lanes(C, T):
    x0, y0, w, h = C.box
    items = [i for i in T["items"] if i["start"] is not None]
    groups = _groups(T, items)
    tabbed = groups != [""]
    tab_pt = ND.T_BODY
    tab_vis = 0
    if tabbed:
        widest = max(_longest_word(g, tab_pt, True) for g in groups)
        full = max(_tw(g, tab_pt, True) for g in groups)
        tab_vis = int(min(max(full + _in(0.3), _in(1.3)), _in(1.75)))
        tab_vis = max(tab_vis, int(widest + _in(0.3)))
    hide = _in(0.12)                                            # the tab runs under the grid (template slide 15)
    gx = x0 + tab_vis
    gw = x0 + w - gx
    periods, unit = _periods(T["lo"], T["hi"], T["unit"])
    cw = gw / len(periods)
    X = _xmap(periods, gx, cw)
    head_pt = ND.T_SMALL if cw >= _in(0.5) else ND.T_MIN
    head = _in(0.34)
    today = T["today"]
    show_today = bool(today and periods[0][0] <= today < periods[-1][1])
    foot = _in(0.34) if show_today else 0
    L = len(groups)
    pad, lane_gap = _in(0.07), _in(0.1)
    avail = h - head - foot - _in(0.12)
    by_group = {g: [i for i in items if i["group"] == g] for g in groups}
    choice = None
    for pt, bh, slack, pad_, gap_ in ((ND.T_BODY, _in(0.34), _in(0.08), pad, lane_gap),
                                      (ND.T_SMALL, _in(0.29), _in(0.08), pad, lane_gap),
                                      (ND.T_MIN, _in(0.25), _in(0.06), pad, lane_gap),
                                      (ND.T_MIN, _in(0.22), _in(0.04), _in(0.04), _in(0.06)),
                                      (ND.T_MIN, _in(0.22), _in(0.04), _in(0.04), _in(0.06))):
        rows = {g: _lane_rows(by_group[g], X, gx, gw, pt, bh, X(today) if show_today else None) for g in groups}
        R = sum(len(v) for v in rows.values())
        if R * (bh + slack) + L * 2 * pad_ + (L - 1) * gap_ <= avail:
            choice = (pt, bh, rows, R)
            pad, lane_gap = pad_, gap_
            break
        if show_today and foot and pt == ND.T_MIN and bh == _in(0.22) and gap_ == _in(0.06):
            foot = 0                                            # last resort: the dashed line stays, the tag goes
            avail += _in(0.34)
    if choice is None:
        choice = (pt, bh, rows, R)
        C.P.append(f"{R} rows of bars do not fit the slide - keep to 6 workstreams and about 14 tasks, or split the plan "
                   "over two slides (e.g. by quarter)")
    pt, bh, rows, R = choice
    p = min(bh + _in(0.2), (avail - L * 2 * pad - (L - 1) * lane_gap) / max(R, 1))
    p = max(p, bh + _in(0.03))
    lane_h = {g: len(rows[g]) * p + 2 * pad for g in groups}
    spare = avail - sum(lane_h.values()) - (L - 1) * lane_gap
    if spare > 0:
        lane_gap2 = min(_in(0.24), lane_gap + spare / max(L, 1))
        spare -= (lane_gap2 - lane_gap) * (L - 1)
        lane_gap = lane_gap2
        cap = _in(1.14) if L >= 3 else _in(1.5)
        for g in groups:
            lane_h[g] += max(0, min(spare / L, cap - lane_h[g]))
    grid_h = head + _in(0.06) + sum(lane_h.values()) + (L - 1) * lane_gap + _in(0.06)
    # 1. workstream tabs first: the grid covers their right end, as on template slide 15
    ly = y0 + head + _in(0.06)
    lane_top = {}
    for gi, g in enumerate(groups):
        lane_top[g] = ly
        if tabbed:
            col = ND.accent(gi)
            tab = C.rect(x0, ly, tab_vis + hide, lane_h[g], col, r=0.08, name=f"timeline workstream {g}")
            size = tab_pt if _nlines(g, tab_vis - _in(0.2), tab_pt, True) * tab_pt * _lh() * PT <= lane_h[g] - _in(0.08) \
                else ND.T_SMALL
            C.write(tab, [_para(g, size, True, ND.contrast_text(col), False)], anchor="m", ml=0.12, mt=0.03,
                    mr=(hide + _in(0.08)) / IN)
            C.check([(g, size, True, None)], tab_vis - _in(0.04), lane_h[g], "workstream name", ml=0.08, mt=0.03)
        ly += lane_h[g] + lane_gap
    # 2. period bands with their labels (white / blush columns)
    _period_bands(C, periods, unit, gx, y0, cw, grid_h, head_pt)
    # 3. today line behind the bars (it never runs through a label)
    if show_today:
        tx = X(today)
        C.line(tx, y0 + head - _in(0.02), tx, y0 + grid_h, colour=ND.PLUM, width=1.5, dash="DASH",
               name="timeline today line")
    # 4. bars and milestones
    for gi, g in enumerate(groups):
        col = ND.accent(gi)
        rr = rows[g]
        top = lane_top[g] + (lane_h[g] - len(rr) * p) / 2
        for ri, row in enumerate(rr):
            cy = top + ri * p + p / 2
            for it, a, b, place, lx, lw in row:
                if it["ms"]:
                    d = min(bh * 1.05, _in(0.3))
                    cx = min(max(X(_mid(it)), gx + d / 2), gx + gw - d / 2)
                    C.diamond(cx, cy, d, col, name=f"timeline milestone {it['name']}")
                    parts = [_para(it["name"], pt, True, ND.INK, False)]
                    if it.get("_lab", "") != it["name"]:
                        parts.append(_para("  " + _md(it["start"], it["sp"]), pt, False, ND.MUTED, False))
                    C.text(lx, cy - p / 2, lw, p, parts, align="l" if place == "right" else "r",
                           anchor="m", ml=0.02, mt=0.0, name=f"timeline milestone label {it['name']}")
                    C.check(_paras(parts), lw + _in(0.04), p, "milestone label", ml=0.02, mt=0.0)
                    continue
                x1 = X(it["start"])
                x2 = max(X(it["end"] + dt.timedelta(days=1)), x1 + _in(0.14))
                bar = C.rect(x1, cy - bh / 2, x2 - x1, bh, col, r=bh / 2 / IN, name=f"timeline bar {it['name']}")
                if place == "in":
                    C.write(bar, [_para(it["name"], pt, True, ND.contrast_text(col), False)], anchor="m", ml=0.11,
                            mt=0.0)
                else:
                    C.text(lx, cy - p / 2, lw, p, [_para(it["name"], pt, True, ND.INK, False)],
                           align="l" if place == "right" else "r", anchor="m", ml=0.02, mt=0.0,
                           name=f"timeline bar label {it['name']}")
                    C.check([(it["name"], pt, True, None)], lw + _in(0.04), p, "bar label", ml=0.02, mt=0.0)
    if show_today and foot:
        _today_tag(C, X(today), y0 + grid_h + _in(0.06), gx, gx + gw, label=f"Today {_md(today)}")


# ============================================================================================ style: status-roadmap
def _draw_status(C, T):
    x0, y0, w, h = C.box
    items = [i for i in T["items"] if i["start"] is not None]
    groups = _groups(T, items)
    tabbed = groups != [""]
    rows = [i for g in groups for i in items if i["group"] == g]
    n = len(rows)
    tab_w = 0
    if tabbed:
        tab_w = int(min(max(max(_tw(g, ND.T_SMALL, True) for g in groups) + _in(0.26), _in(1.05)), _in(1.45)))
    leg_h = _in(0.36)
    head = _in(0.34)
    gap_rows = _in(0.05)
    p = min(_in(0.78) if n <= 5 else _in(0.62), (h - head - leg_h - _in(0.06)) / max(n, 1))
    two = p >= _in(0.43)
    pt = ND.T_BODY if p >= _in(0.56) else ND.T_SMALL
    if p < _in(0.27):
        C.P.append(f"{n} rows do not fit a status roadmap - keep to 12 deliverables (group small ones) or split the "
                   "slide")

    def meta(it):
        return " · ".join(x for x in (it["owner"], STATUS_WORD.get(it["status"], "")) if x)
    label_need = max(max(_tw(it["name"], pt, True) for it in rows),
                     max((_tw(meta(it), pt) for it in rows), default=0)) + _in(0.4)
    label_w = int(min(max(label_need, _in(2.25)), _in(3.1)))
    lx = x0 + (tab_w + _in(0.08) if tabbed else 0)
    gx = lx + label_w + _in(0.12)
    gw = x0 + w - gx
    periods, unit = _periods(T["lo"], T["hi"], T["unit"])
    cw = gw / len(periods)
    X = _xmap(periods, gx, cw)
    head_pt = ND.T_SMALL if cw >= _in(0.5) else ND.T_MIN
    grid_h = head + n * p + _in(0.04)
    _period_bands(C, periods, unit, gx, y0, cw, grid_h, head_pt)
    C.text(lx, y0, label_w, head, [_para("Deliverable", ND.T_SMALL, True, ND.INK, False),
                                   _para("   Owner · status", ND.T_SMALL, False, ND.MUTED, False)],
           anchor="t", ml=0.14, mt=0.07, name="timeline column header")
    ry = y0 + head
    today = T["today"]
    show_today = bool(today and periods[0][0] <= today < periods[-1][1])
    tx = X(today) if show_today else None
    if show_today:                                              # behind the bars
        C.line(X(today), y0 + head - _in(0.02), X(today), y0 + grid_h, colour=ND.PLUM, width=1.5, dash="DASH",
               name="timeline today line")
    if tabbed:
        for gi, g in enumerate(groups):
            r0 = next(k for k, it in enumerate(rows) if it["group"] == g)
            cnt = sum(1 for it in rows if it["group"] == g)
            col = ND.accent(gi)
            th = cnt * p - gap_rows
            tab = C.rect(x0, ry + r0 * p, tab_w, th, col, r=0.07, name=f"timeline workstream {g}")
            C.write(tab, [_para(g, ND.T_SMALL, True, ND.contrast_text(col), False)], anchor="m", ml=0.1, mt=0.02)
            C.check([(g, ND.T_SMALL, True, None)], tab_w, th, "workstream name", ml=0.1, mt=0.02)
    bh = min(_in(0.24), p * 0.44)
    for ri, it in enumerate(rows):
        col = ND.accent(groups.index(it["group"]))
        y = ry + ri * p
        ch = p - gap_rows
        card = C.rect(lx, y, label_w, ch, ND.WHITE, r=0.06, name=f"timeline row {it['name']}")
        m = meta(it)
        if two and m:
            parts = [_para(it["name"], pt, True, ND.INK, False), _para(m, pt, False, ND.MUTED, True)]
        else:
            parts = [_para(it["name"], pt, True, ND.INK, False)] + ([_para("   " + m, pt, False, ND.MUTED, False)]
                                                                     if m else [])
        C.write(card, parts, anchor="m", ml=0.22, mt=0.0, mr=0.08)
        C.check(_paras(parts), label_w - _in(0.14), ch, "row label", ml=0.08, mt=0.0)
        if it["status"]:
            _edge(C, lx + _in(0.08), y + _in(0.07), ch - _in(0.14), it["status"])
        cy = y + ch / 2
        if it["ms"]:
            d = min(_in(0.26), ch * 0.8)
            cx = min(max(X(_mid(it)), gx + d / 2), gx + gw - d / 2)
            C.diamond(cx, cy, d, col, name=f"timeline milestone {it['name']}")
            lab = _md(it["start"], it["sp"])
            lw = _tw(lab, ND.T_MIN) + _in(0.08)
            side = _side((cx + d / 2 + _in(0.03), cx + d / 2 + _in(0.03) + lw),
                         (cx - d / 2 - _in(0.03) - lw, cx - d / 2 - _in(0.03)), gx, gx + gw, tx) or "left"
            C.text(cx + d / 2 + _in(0.03) if side == "right" else cx - d / 2 - _in(0.03) - lw, y, lw, ch,
                   [_para(lab, ND.T_MIN, False, ND.INK, False)], align="l" if side == "right" else "r", anchor="m",
                   ml=0.02, mt=0.0, name="timeline date")
        else:
            x1 = X(it["start"])
            x2 = max(X(it["end"] + dt.timedelta(days=1)), x1 + _in(0.14))
            bar = C.rect(x1, cy - bh / 2, x2 - x1, bh, col, r=bh / 2 / IN, name=f"timeline bar {it['name']}")
            lab = _md(it["end"], it["ep"])
            lw = _tw(lab, ND.T_MIN) + _in(0.08)
            r_, l_ = (x2 + _in(0.03), x2 + _in(0.03) + lw), (x1 - _in(0.03) - lw, x1 - _in(0.03))
            side = _side(r_, l_, gx, gx + gw, tx)
            if side and not _clear(*(r_ if side == "right" else l_), tx) and x2 - x1 >= lw + _in(0.24):
                C.write(bar, [_para(lab, ND.T_MIN, False, ND.contrast_text(col), False)], align="r", anchor="m",
                        ml=0.04, mt=0.0, mr=0.1)          # both outside spots cross the today line: inside the bar
                side = None
            if side:
                C.text(x2 + _in(0.03) if side == "right" else x1 - _in(0.03) - lw, y, lw, ch,
                       [_para(lab, ND.T_MIN, False, ND.INK, False)], align="l" if side == "right" else "r",
                       anchor="m", ml=0.02, mt=0.0, name="timeline due date")
    bottom = y0 + grid_h
    tag = _today_tag(C, X(today), bottom + _in(0.06), gx, gx + gw, label=f"Today {_md(today)}") if show_today else None
    # legend: the status marks used, the milestone
    used = [s for s in ("done", "on track", "at risk", "late") if any(i["status"] == s for i in rows)]
    entries = []
    if "done" in used and "on track" in used:
        entries.append(("on track", "On track / done"))
        used = [s for s in used if s not in ("done", "on track")]
    entries += [(s, STATUS_WORD[s]) for s in ("done", "on track", "at risk", "late") if s in used]
    if any(i["ms"] for i in rows):
        entries.append(("ms", "Milestone"))
    ly = bottom + _in(0.07)
    x = lx
    lim = (tag.left - _in(0.15)) if tag is not None and tag.left > lx + _in(1) else x0 + w
    for s, word in entries:
        tw_ = _tw(word, ND.T_MIN) + _in(0.06)
        if x + _in(0.2) + tw_ > lim:
            break
        if s == "ms":
            C.diamond(x + _in(0.07), ly + _in(0.13), _in(0.15), ND.accent(0), name="timeline legend milestone")
        else:
            _edge(C, x + _in(0.04), ly + _in(0.04), _in(0.18), s, name="timeline legend")
        C.text(x + _in(0.17), ly, tw_, _in(0.26), [_para(word, ND.T_MIN, False, ND.INK, False)], anchor="m",
               ml=0.02, mt=0.0, name=f"timeline legend label {word}")
        x += _in(0.17) + tw_ + _in(0.16)


# ============================================================================================ style: phases
def _phase_list(T):
    """[{name, start, end, sp, ep, dels: [(kind, text, item)]}] - groups as phases, or one phase per task
    (deliverables from its text, split on ';'); milestones join the phase they fall in."""
    items = [i for i in T["items"] if i["start"] is not None]
    tasks = [i for i in items if not i["ms"]]
    phases = []
    if len({i["group"] for i in items if i["group"]}) >= 2:
        for g in _groups(T, items):
            mem = [i for i in items if i["group"] == g]
            dels = [("ms" if i["ms"] else "task", i["name"], i) for i in mem]
            phases.append({"name": g or "Other", "start": min(i["start"] for i in mem),
                           "end": max(i["end"] for i in mem), "sp": "day", "ep": "day", "dels": dels})
    else:
        for t in tasks:
            dels = [("task", d.strip(), None) for d in re.split(r"[;\n]", t["text"]) if d.strip()]
            phases.append({"name": t["name"], "start": t["start"], "end": t["end"], "sp": t["sp"], "ep": t["ep"],
                           "dels": dels})
        for m in (i for i in items if i["ms"]):
            ph = next((p for p in phases if p["start"] <= m["start"] <= p["end"]), None)
            if ph is None and phases:
                ph = min(phases, key=lambda p: min(abs((p["start"] - m["start"]).days),
                                                   abs((p["end"] - m["start"]).days)))
            if ph is not None:
                ph["dels"].append(("ms", m["name"], m))
    phases.sort(key=lambda p: p["start"])
    return phases


def _draw_phases(C, T):
    x0, y0, w, h = C.box
    phases = _phase_list(T)
    n = len(phases)
    if not n:
        C.P.append("no phases to draw - give 3-6 phases with start and end dates")
        return
    today = T["today"]
    cur = next((k for k, p in enumerate(phases) if today and p["start"] <= today <= p["end"]), None)
    tag_h = _in(0.38) if cur is not None else 0
    g = _in(0.1)
    ch = _in(0.95)
    adj = 0.32
    tip = ch * adj
    cw = (w - tip / 2 - (n - 1) * g) / n
    y_ch = y0 + tag_h
    name_pt = ND.T_SUB
    room = cw - tip - _in(0.16)
    for p in phases:
        while name_pt > ND.T_BODY and (_nlines(p["name"], room, name_pt, True) * name_pt * _lh() * PT > ch - _in(0.12)
                                       or _longest_word(p["name"], name_pt, True) > room):
            name_pt = ND.T_CARD if name_pt == ND.T_SUB else ND.T_BODY
    # duration ruler at the bottom: each phase's real length on a calendar axis
    lo, hi = min(p["start"] for p in phases), max(p["end"] for p in phases)
    periods, unit = _periods(lo, hi)
    ruler_h = _in(0.5)
    ruler_y = y0 + h - ruler_h
    rw = w / len(periods)
    X = _xmap(periods, x0, rw)
    card_y = y_ch + ch + _in(0.16)
    card_h = ruler_y - _in(0.22) - card_y
    inner = cw - _in(0.24) - _in(0.2)

    def del_text(kind, txt, it):
        return txt + (f" · {_md(it['start'], it['sp'])}" if kind == "ms" and it is not None else "")
    date_pt = ND.T_CARD
    for del_pt in (ND.T_CARD, ND.T_BODY, ND.T_SMALL):
        need = 0
        for p in phases:
            hh = _in(0.72)
            for kind, txt, it in p["dels"]:
                hh += _nlines(del_text(kind, txt, it), inner - (_in(0.22) if kind == "ms" else 0), del_pt,
                              kind == "ms") * del_pt * _lh() * PT + _in(0.18) + _in(0.08)
            need = max(need, hh + _in(0.04))
        if need <= card_h:
            break
    if need > card_h:
        C.P.append("phase deliverables are long for their cards - keep 1-3 deliverables of up to 8 words per phase")
    for k, p in enumerate(phases):
        col = ND.accent(k)
        cx = x0 + k * (cw + g)
        card = C.rect(cx, card_y, cw, card_h, ND.WHITE, r=0.1, line=ND.PLUM if k == cur else None, line_w=1.75,
                      name=f"timeline phase card {p['name']}")
        rng = _range(p["start"], p["end"], p["sp"], p["ep"])
        C.write(card, [_para(rng, date_pt, True, ND.INK, False),
                       _para(_duration(p["start"], p["end"]), ND.T_SMALL, False, ND.MUTED, True)],
                anchor="t", ml=0.14, mt=0.12)
        C.check([(rng, date_pt, True, None)], cw, _in(0.42), "phase dates", ml=0.14, mt=0.0)
        yy = card_y + _in(0.74)
        for kind, txt, it in p["dels"]:
            t_ = del_text(kind, txt, it)
            lines = _nlines(t_, inner - (_in(0.22) if kind == "ms" else 0), del_pt, kind == "ms")
            hh = lines * del_pt * _lh() * PT + _in(0.18)
            chip = C.rect(cx + _in(0.12), yy, cw - _in(0.24), hh, ND.BLUSH, r=0.07, name=f"timeline deliverable {txt}")
            C.write(chip, [_para(t_, del_pt, kind == "ms", ND.INK, False)], anchor="m",
                    ml=0.1 if kind == "task" else 0.32, mt=0.04, mr=0.1)
            if kind == "ms":
                C.diamond(cx + _in(0.12) + _in(0.17), yy + hh / 2, _in(0.16), col, name=f"timeline milestone {txt}")
            yy += hh + _in(0.08)
    for k, p in enumerate(phases):
        col = ND.accent(k)
        cx = x0 + k * (cw + g)
        kind = "PENTAGON" if k == 0 else "CHEVRON"
        sx = cx if k == 0 else cx - tip / 2
        sw = cw + tip / 2 if k == 0 else cw + tip
        sh = C.rect(sx, y_ch, sw, ch, col, kind=kind, name=f"timeline phase {p['name']}")
        sh.adjustments[0] = adj * ch / min(sw, ch)
        C.write(sh, [_para(p["name"], name_pt, True, ND.contrast_text(col), False)], align="c", anchor="m", ml=0.06,
                mt=0.04)
        C.check([(p["name"], name_pt, True, None)], cw - tip, ch, "phase name", ml=0.08, mt=0.04)
    # ruler: thin axis, period labels, one bar per phase at its real dates
    base = ruler_y + _in(0.22)
    labs = _period_labels(periods, unit, rw, ND.T_MIN)
    C.line(x0, base, x0 + w, base, colour=ND.LINE, width=1.0, name="timeline ruler")
    for i, lab in enumerate(labs):
        C.line(x0 + i * rw, base - _in(0.04), x0 + i * rw, base + _in(0.04), colour=ND.LINE, width=1.0,
               name="timeline ruler tick")
        C.text(x0 + i * rw, base + _in(0.04), rw, _in(0.22), [_para(lab, ND.T_MIN, False, ND.MUTED, False)],
               anchor="t", ml=0.04, mt=0.0, name=f"timeline ruler {lab}")
    for k, p in enumerate(phases):
        x1, x2 = X(p["start"]), X(p["end"] + dt.timedelta(days=1))
        C.rect(x1 + _in(0.01), base - _in(0.17), max(_in(0.06), x2 - x1 - _in(0.02)), _in(0.13), ND.accent(k),
               r=0.065, name=f"timeline phase span {p['name']}")
    if today and lo <= today <= hi:
        tx = X(today)
        C.line(tx, base - _in(0.21), tx, base + _in(0.04), colour=ND.PLUM, width=2.0, name="timeline today mark")
    if cur is not None:
        p = phases[cur]
        cx = x0 + cur * (cw + g)
        frac = (today - p["start"]).days / max(1, (p["end"] - p["start"]).days)
        tx = cx + _in(0.25) + frac * (cw - tip - _in(0.5))
        tag = _today_tag(C, tx, y0, x0, x0 + w, label=f"Today {_md(today)}")
        C.tri(tx, tag.top + tag.height - _in(0.01), _in(0.16), _in(0.1), ND.PLUM)


# ============================================================================================ style: quarters
def _draw_quarters(C, T):
    x0, y0, w, h = C.box
    items = [i for i in T["items"] if i["start"] is not None]
    periods, _ = _periods(T["lo"], T["hi"], "quarter")
    n = len(periods)
    g = _in(0.1)
    qw = (w - (n - 1) * g) / n
    ms = [i for i in items if i["ms"]]
    tasks = [i for i in items if not i["ms"]]

    def X(d):
        for k, (s, e) in enumerate(periods):
            if d < e:
                return x0 + k * (qw + g) + max(0, (d - s).days) / max(1, (e - s).days) * qw
        return x0 + w
    # launch labels above the band: name (wraps to 2 lines if it must) and date, staggered in rows
    lab_pt = ND.T_SMALL
    placed, entries = [], []
    row_h = _in(0.44)
    for m in ms:
        cx = min(max(X(_mid(m)), x0 + _in(0.13)), x0 + w - _in(0.13))
        t1, t2 = m["name"], _md(m["start"], m["sp"])
        lw = min(max(_tw(t1, lab_pt, True), _tw(t2, lab_pt)) + _in(0.14), _in(1.9))
        x1 = min(max(cx - lw / 2, x0), x0 + w - lw)
        row = 0
        while any(r == row and not (x1 >= b_ + _in(0.08) or x1 + lw + _in(0.08) <= a_) for r, a_, b_ in placed):
            row += 1
        placed.append((row, x1, x1 + lw))
        entries.append((m, cx, x1, lw, row, t1, t2))
        row_h = max(row_h, _height([(t1, lab_pt, True, None), (t2, lab_pt, False, None)], lw - _in(0.08)) + _in(0.06))
    nrows = max((e[4] for e in entries), default=-1) + 1
    today = T["today"]
    show_today = bool(today and periods[0][0] <= today < periods[-1][1])
    # deliverables (by due date): the densest setting that fits the column
    due = [[t for t in tasks if s <= t["end"] < e] for s, e in periods]
    inner = qw - _in(0.32)

    def stack(lst, npt, spt, pad, gap):
        return sum(_height([(t["name"], npt, True, None)], inner) + spt * _lh() * PT + pad for t in lst) + \
            gap * max(0, len(lst) - 1)
    settings = ((ND.T_CARD, ND.T_SMALL, _in(0.3), _in(0.1)), (ND.T_BODY, ND.T_SMALL, _in(0.22), _in(0.08)),
                (ND.T_SMALL, ND.T_MIN, _in(0.16), _in(0.06)))
    fits = False
    for stem_h, band_h, gap_c in ((_in(0.22), _in(0.78), _in(0.44) if show_today else _in(0.16)),
                                  (_in(0.14), _in(0.62), _in(0.38) if show_today else _in(0.12))):
        avail_c = h - (nrows * row_h + (stem_h if nrows else 0) + band_h + gap_c)
        for name_pt, sub_pt, pad, gap_d in settings:
            need_c = max([stack(lst, name_pt, sub_pt, pad, gap_d) for lst in due] + [_in(0.5)])
            if need_c <= avail_c:
                fits = True
                break
        if fits:
            break
    if not fits:
        C.P.append("a quarter has more deliverables than its column holds - list up to 4 per quarter with 2-4 word "
                   "names, and keep launch names to 2-3 words")
    spare = max(0, avail_c - need_c)
    band_h += min(_in(0.22), spare * 0.25)
    if nrows:
        row_h += min(_in(0.12), spare * 0.2 / nrows)
    card_h = h - (nrows * row_h + (stem_h if nrows else 0) + band_h + gap_c)
    band_y = y0 + nrows * row_h + (stem_h if nrows else 0)
    labs = [(f"Q{(s.month - 1) // 3 + 1} {s.year}", f"{s:%b} – {(e - dt.timedelta(days=1)):%b}") for s, e in periods]
    q_pt, m_pt, q_mt = next(((qp, mp, mt) for qp, mp, mt in ((ND.T_HIGHLIGHT, ND.T_BODY, 0.1), (ND.T_SUB, ND.T_BODY, 0.1),
                                                           (ND.T_CARD, ND.T_SMALL, 0.06), (ND.T_BODY, ND.T_SMALL, 0.05))
                             if (qp + mp) * _lh() * PT + _in(2 * mt) <= band_h
                             and max(_tw(a_, qp, True) for a_, _b in labs) <= qw - _in(0.34)),
                            (ND.T_BODY, ND.T_SMALL, 0.05))
    for k, (s, e) in enumerate(periods):
        col = ND.accent(k)
        q = (s.month - 1) // 3 + 1
        months = f"{s:%b} – {(e - dt.timedelta(days=1)):%b}"
        blk = C.rect(x0 + k * (qw + g), band_y, qw, band_h, col, r=0.1, name=f"timeline quarter Q{q} {s.year}")
        tc = ND.contrast_text(col)
        C.write(blk, [_para(f"Q{q} {s.year}", q_pt, True, tc, False), _para(months, m_pt, False, tc, True)],
                anchor="b", ml=0.16, mt=q_mt)
        C.check([(f"Q{q} {s.year}", q_pt, True, None), (months, m_pt, False, None)], qw, band_h, "quarter",
                ml=0.16, mt=q_mt)
    for m, cx, x1, lw, row, t1, t2 in entries:
        ly = y0 + (nrows - 1 - row) * row_h
        al = "c" if abs((x1 + lw / 2) - cx) < _in(0.05) else ("l" if cx < x1 + lw / 2 else "r")
        C.text(x1, ly, lw, row_h - _in(0.04), [_para(t1, lab_pt, True, ND.INK, False),
                                               _para(t2, lab_pt, False, ND.MUTED, True)],
               align=al, anchor="b", ml=0.04, mt=0.0, name=f"timeline launch label {t1}")
        C.check([(t1, lab_pt, True, None), (t2, lab_pt, False, None)], lw, row_h - _in(0.04), "milestone label",
                ml=0.04, mt=0.0)
        C.line(cx, ly + row_h - _in(0.03), cx, band_y - _in(0.1), colour=ND.MUTED, width=0.75,
               name=f"timeline stem {t1}")
        C.diamond(cx, band_y, _in(0.24), ND.WHITE, line=ND.PLUM, line_w=1.75, name=f"timeline launch {t1}")
    card_y = band_y + band_h + gap_c
    for k, (s, e) in enumerate(periods):
        cx = x0 + k * (qw + g)
        if not due[k]:
            C.rect(cx, card_y, qw, _in(0.5), ND.WHITE, r=0.1, name=f"timeline quarter {k + 1} empty",
                   text="No deliverables due", size=ND.T_SMALL, color=ND.MUTED, align="l", anchor="m", margin=0.16)
            continue
        hs = []
        for t in due[k]:
            sub = "Due " + _md(t["end"], t["ep"]) + (f" · {t['owner']}" if t["owner"] else "")
            parts = [_para(t["name"], name_pt, True, ND.INK, False), _para(sub, sub_pt, False, ND.MUTED, True)]
            hs.append((t, parts, _height(_paras(parts), inner) + pad))
        total = sum(x[2] for x in hs) + gap_d * (len(hs) - 1)
        grow = max(0.0, min(_in(0.3), (card_h - total) / len(hs)))
        yy = card_y
        for t, parts, hh in hs:
            hh += grow
            cd = C.rect(cx, yy, qw, hh, ND.WHITE, r=0.1, name=f"timeline deliverable {t['name']}")
            C.write(cd, parts, anchor="m", ml=0.16, mt=min(0.08, pad / IN / 2))
            C.check(_paras(parts), qw, hh, "deliverable", ml=0.16, mt=min(0.08, pad / IN / 2))
            yy += hh + gap_d
    if show_today:
        tx = min(max(X(today), x0 + _in(0.09)), x0 + w - _in(0.09))
        C.tri(tx, band_y + band_h + _in(0.03), _in(0.18), _in(0.11), ND.PLUM, down=False, name="timeline today pointer")
        _today_tag(C, tx, band_y + band_h + _in(0.13), x0, x0 + w, label=f"Today {_md(today)}")


# ============================================================================================ style: sprints
def _sprint_no(name):
    m = re.match(r"^(?:sprint|iteration|s|it)\s*#?\s*(\d+)$", name.strip(), re.I)
    return m.group(1) if m else None


def _draw_sprints(C, T):
    x0, y0, w, h = C.box
    items = [i for i in T["items"] if i["start"] is not None]
    sprints = [i for i in items if not i["ms"]]
    rels = sorted((i for i in items if i["ms"]), key=lambda i: i["start"])
    n = len(sprints)
    if not n:
        C.P.append("no sprints to draw - give each sprint a start and end date")
        return
    g = _in(0.1)
    sw = (w - (n - 1) * g) / n
    rel_of = []                                     # each sprint ships in the first release on or after its end
    for s in sprints:
        rel_of.append(next((k for k, r_ in enumerate(rels) if r_["start"] >= s["end"] - dt.timedelta(days=3)), None))
    rel_h = _in(0.7) if rels else 0
    axis_h = _in(0.56)
    axis_y = y0 + h - axis_h + _in(0.16)
    card_y = y0 + (rel_h + _in(0.16) if rels else 0)
    card_h = axis_y - _in(0.3) - card_y
    today = T["today"]
    cur = next((k for k, s in enumerate(sprints) if today and s["start"] <= today <= s["end"]), None)
    for r, rel in enumerate(rels):
        ks = [k for k, rr in enumerate(rel_of) if rr == r]
        if not ks:
            continue
        a, b = min(ks), max(ks)
        col = ND.accent(r)
        bx = x0 + a * (sw + g)
        bw = (b - a + 1) * sw + (b - a) * g
        sub = f"Ships {_md(rel['start'], rel['sp'])}" + (f" · {len(ks)} sprints" if len(ks) > 1 else "")
        blk = C.rect(bx, y0, bw, rel_h, col, r=0.1, name=f"timeline release {rel['name']}")
        tc = ND.contrast_text(col)
        name_pt = ND.T_CARD if _tw(rel["name"], ND.T_CARD, True) <= bw - _in(0.3) else ND.T_BODY
        C.write(blk, [_para(rel["name"], name_pt, True, tc, False), _para(sub, ND.T_SMALL, False, tc, True)],
                anchor="m", ml=0.15, mt=0.04)
        C.check([(rel["name"], name_pt, True, None), (sub, ND.T_SMALL, False, None)], bw, rel_h, "release name",
                ml=0.15, mt=0.04)
    num_pt, goal_pt, name_pt = (32, ND.T_BODY, ND.T_CARD) if sw >= _in(1.35) else \
        ((28, ND.T_SMALL, ND.T_BODY) if sw >= _in(1.0) else (24, ND.T_MIN, ND.T_SMALL))
    date_pt = ND.T_SMALL if sw >= _in(1.0) else ND.T_MIN
    for k, s in enumerate(sprints):
        r = rel_of[k]
        col = ND.accent(r) if r is not None else ND.LINE
        cx = x0 + k * (sw + g)
        card = C.rect(cx, card_y, sw, card_h, ND.WHITE, r=0.1, line=ND.PLUM if k == cur else None, line_w=1.75,
                      name=f"timeline sprint {s['name']}")
        rng = _range(s["start"], s["end"], s["sp"], s["ep"])
        no = _sprint_no(s["name"])
        if no:
            parts = [_para("SPRINT", ND.T_MIN, True, ND.MUTED, False), (no, num_pt, True, ND.INK, True)]
        else:
            parts = [_para(s["name"], name_pt, True, ND.INK, False)]
        parts.append(_para(rng, date_pt, False, ND.MUTED, True))
        if s["text"]:
            parts.append(_para(s["text"], goal_pt, False, ND.INK, True))
        mh = 0.1 if sw >= _in(1.0) else 0.05
        C.write(card, parts, align="c", anchor="m", ml=mh, mt=0.2)
        if no:
            C.face(card, no)
        extra = _space(card, before=10, idx={len(parts) - 1}) if s["text"] else 0
        checks = [(t_, s_, b_, ND.DISPLAY if t_ == no else None) for t_, s_, b_, _, _ in parts]
        C.check(checks, sw, card_h - _in(0.3) - extra, "sprint", ml=mh, mt=0.2)
        C.top_rounded(cx, card_y, sw, _in(0.09), col, 0.1, name=f"timeline sprint strip {s['name']}")
        if k == cur:
            _today_tag(C, cx + sw / 2, card_y + card_h - _in(0.36), cx + _in(0.06), cx + sw - _in(0.06), label="Now")
    # dated axis: sprint starts, release diamonds, today
    C.line(x0, axis_y, x0 + w - _in(0.02), axis_y, colour=ND.INK, width=1.5, name="timeline sprint axis")
    pts = [(s["start"], x0 + k * (sw + g)) for k, s in enumerate(sprints)] + [(sprints[-1]["end"] + dt.timedelta(days=1),
                                                                              x0 + w)]

    def ax(d):
        for (d1, x1), (d2, x2) in zip(pts, pts[1:]):
            if d1 <= d < d2:
                return x1 + (x2 - x1) * (d - d1).days / max(1, (d2 - d1).days)
        return x0 + w if d >= pts[-1][0] else x0
    lab_w = sw + g
    for k, s in enumerate(sprints):
        x = x0 + k * (sw + g)
        C.dot(x + _in(0.04), axis_y, _in(0.08), ND.INK, name="timeline sprint start")
        C.text(x, axis_y + _in(0.06), sw if k == n - 1 else lab_w, _in(0.22), [_para(_md(s["start"], s["sp"]), ND.T_MIN, False, ND.MUTED,
                                                                False)], ml=0.02, mt=0.0,
               name=f"timeline sprint date {k + 1}")
    for r, rel in enumerate(rels):
        C.diamond(min(max(ax(rel["start"]), x0 + _in(0.13)), x0 + w - _in(0.13)), axis_y, _in(0.24), ND.accent(r),
                  line=ND.WHITE, line_w=1.25, name=f"timeline release marker {rel['name']}")
    if today and pts[0][0] <= today < pts[-1][0]:
        C.dot(min(max(ax(today), x0 + _in(0.09)), x0 + w - _in(0.09)), axis_y, _in(0.16), ND.PLUM, line=ND.WHITE,
              line_w=1.0, name="timeline today mark")


# ============================================================================================ style: now-next-later
def _nnl_columns(T):
    """[(title, window, [items])] - by the items' group (now / next / later / done) or by date against today."""
    items = T["items"]
    today = T["today"] or dt.date.today()
    cols = {0: [], 1: [], 2: [], 3: []}
    explicit = bool(items) and all(i["group"].strip().lower() in NNL for i in items)
    q0 = dt.date(today.year, 3 * ((today.month - 1) // 3) + 1, 1)
    q1, q2 = _add_months(q0, 3), _add_months(q0, 6)
    for i in items:
        if explicit:
            cols[NNL[i["group"].strip().lower()]].append(i)
        elif i["status"] == "done" or (i["end"] is not None and i["end"] < today):
            cols[0].append(i)
        elif i["start"] is None or i["start"] < q1:
            cols[1].append(i)
        elif i["start"] < q2:
            cols[2].append(i)
        else:
            cols[3].append(i)

    def qn(d):
        return f"Q{(d.month - 1) // 3 + 1} {d.year}"
    win = {0: "Shipped", 1: f"{qn(q0)} · in flight", 2: qn(q1), 3: f"{qn(q2)} and later"}
    if explicit:
        for c in cols:
            ds = [i for i in cols[c] if i["start"]]
            win[c] = _range(min(i["start"] for i in ds), max(i["end"] for i in ds)) if ds else ""
        win[0] = win[0] or "Shipped"
    titles = {0: "Done", 1: "Now", 2: "Next", 3: "Later"}
    out = [(titles[c], win[c], cols[c]) for c in (0, 1, 2, 3) if c > 0 or cols[0]]
    for _t, _w, its in out:
        its.sort(key=lambda i: (i["start"] or dt.date.max, i["k"]))
    return out


def _draw_nnl(C, T):
    x0, y0, w, h = C.box
    cols = _nnl_columns(T)
    n = len(cols)
    g = _in(0.14)
    cw = (w - (n - 1) * g) / n
    head_h = _in(0.95)
    r = 0.1
    k_acc = 0
    nmax = max(3, max(len(c[2]) for c in cols))
    y_items = y0 + head_h + _in(0.12)
    slot = (y0 + h - _in(0.12) - y_items + _in(0.1)) / nmax
    box_h = slot - _in(0.1)
    inner = cw - _in(0.2) - _in(0.32)
    for k, (title, window, its) in enumerate(cols):
        if title == "Done":
            col = ND.MUTED
        else:
            col = ND.accent(k_acc)
            k_acc += 1
        cx = x0 + k * (cw + g)
        C.rect(cx, y0, cw, h, ND.WHITE, r=r, name=f"timeline column {title}")
        hb = C.top_rounded(cx, y0, cw, head_h, col, r, name=f"timeline header {title}")
        tc = ND.contrast_text(col)
        C.write(hb, [(title, ND.T_HIGHLIGHT, True, tc, False), _para(window, ND.T_BODY, False, tc, True)],
                align="c", anchor="m", ml=0.1, mt=0.06)
        C.face(hb, title)
        C.check([(title, ND.T_HIGHLIGHT, True, ND.DISPLAY), (window, ND.T_BODY, False, None)], cw, head_h,
                "column header", ml=0.1, mt=0.06)
        for j, it in enumerate(its):
            y = y_items + j * slot
            when = ("Due " + _md(it["end"], it["ep"])) if it["end"] and not it["ms"] else \
                (_md(it["start"], it["sp"]) if it["start"] else "")
            meta = " · ".join(x for x in (when, it["owner"], STATUS_WORD.get(it["status"], "")) if x)
            inner = cw - _in(0.2) - _in(0.24 if it["status"] else 0.14) - _in(0.12)
            for name_pt, body_pt, meta_pt in ((ND.T_CARD if box_h >= _in(0.95) else ND.T_BODY, ND.T_BODY, ND.T_SMALL),
                                              (ND.T_BODY, ND.T_SMALL, ND.T_SMALL), (ND.T_SMALL, ND.T_SMALL, ND.T_MIN),
                                              (ND.T_SMALL, ND.T_MIN, ND.T_MIN)):
                parts = [_para(it["name"], name_pt, True, ND.INK, False)]
                if it["text"]:
                    parts.append(_para(it["text"], body_pt, False, ND.INK, True))
                if meta:
                    parts.append(_para(meta, meta_pt, False, ND.MUTED, True))
                if _height(_paras(parts), inner) + _in(0.12) + 2 * PT * (len(parts) - 1) <= box_h:
                    break
            bx = C.rect(cx + _in(0.1), y, cw - _in(0.2), box_h, ND.PAGE, r=0.07, name=f"timeline item {it['name']}")
            C.write(bx, parts, anchor="m", ml=0.24 if it["status"] else 0.14, mt=0.05, mr=0.12)
            extra = _space(bx, before=2) if len(parts) > 1 else 0
            if it["status"]:
                _edge(C, cx + _in(0.18), y + _in(0.09), box_h - _in(0.18), it["status"])
            C.check(_paras(parts), inner + _in(0.16), box_h - extra, "item", ml=0.08, mt=0.05)


# ============================================================================================ style: countdown
def _countdown_parts(T):
    items = [i for i in T["items"] if i["start"] is not None]
    gl = next((i for i in items if i["golive"]), None)
    if gl is None:
        cands = [i for i in items if i["ms"] and GOLIVE.search(i["name"])]
        gl = cands[-1] if cands else max((i for i in items if i["ms"]), key=lambda i: i["start"], default=None)
    gates = [i for i in items if i is not gl]
    return gl, sorted(gates, key=lambda i: (i["end"], i["k"]))


def _tminus(d, gl):
    days = (gl - d).days
    if days <= 0:
        return "T–0", "go-live day"
    if days < 7:
        return f"T–{days}", "day" if days == 1 else "days"
    wk = round(days / 7)
    return f"T–{wk}", "week" if wk == 1 else "weeks"


def _draw_countdown(C, T):
    x0, y0, w, h = C.box
    gl, gates = _countdown_parts(T)
    if gl is None:
        C.P.append("no go-live to count down to - mark the go-live milestone (\"golive\": true) or name it 'Go-live'")
        return
    n = len(gates)
    today = T["today"]
    bd = min(_in(2.15), h * 0.46)
    bx = x0 + w - bd
    step = (bx - _in(0.3) - x0) / max(n, 1)
    col_w = step - _in(0.14)
    lab_h = _in(0.86)
    inner = col_w - _in(0.36)
    name_pt = ND.T_BODY
    cards = []
    for gt in gates:
        done = gt["status"] == "done" or (today is not None and gt["end"] < today and gt["status"] not in ("at risk", "late"))
        st = gt["status"] or ("done" if done else "")
        parts = [_para(_md(gt["end"], gt["ep"]), ND.T_SMALL, True, ND.MUTED, False),
                 _para(gt["name"], name_pt, True, ND.INK, True)]
        if gt["owner"]:
            parts.append(_para(gt["owner"], ND.T_SMALL, False, ND.MUTED, True))
        if st:
            parts.append(_para(STATUS_WORD[st], ND.T_SMALL, True, ND.INK, True))
        for c in [c.strip() for c in re.split(r"[;\n]", gt["text"]) if c.strip()]:
            parts.append(_para("• " + c, ND.T_SMALL, False, ND.INK, True))
        cards.append((gt, done, st, parts))
    card_need = max([_height(_paras(p), inner) + _in(0.36) + (5 * PT if st else 0) for _g, _d, st, p in cards]
                    + [_in(1.3)])
    card_gap = _in(0.38)
    above = max(lab_h + _in(0.24), bd / 2)
    below = max(card_gap + card_need, bd / 2 + _in(0.4))
    top = y0 + max(0, (h - above - below) / 2)
    track_y = top + above
    card_h = min(card_need, y0 + h - (track_y + card_gap))
    C.rect(x0, track_y - _in(0.07), bx + bd / 2 - x0, _in(0.14), ND.BLUSH, r=0.07, name="timeline countdown track")
    xs = [x0 + step * k + step / 2 for k in range(n)]
    pts = [(gt["end"], xs[k]) for k, gt in enumerate(gates)] + [(gl["start"], bx + bd / 2)]
    if today and gates and gates[0]["end"] <= today < gl["start"]:
        for (d1, xa), (d2, xb) in zip(pts, pts[1:]):
            if d1 <= today <= d2:
                tx = xa + (xb - xa) * (today - d1).days / max(1, (d2 - d1).days)
                if min(abs(tx - xa), abs(tx - xb)) > _in(0.32):        # a plum dot, unless it would touch a gate
                    C.dot(tx, track_y, _in(0.17), ND.PLUM, line=ND.WHITE, line_w=1.0, name="timeline today mark")
                break
    for k, (gt, done, st, parts) in enumerate(cards):
        cx = xs[k]
        col = ND.accent(3 - min(3, int(k * 4 / max(n, 1))))
        big, unit = _tminus(gt["end"], gl["start"])
        num_pt = 32 if _tw(big, 32, True, ND.DISPLAY) <= col_w else 28
        lab = C.text(cx - col_w / 2, track_y - _in(0.24) - lab_h, col_w, lab_h,
                     [(big, num_pt, True, ND.INK, False), _para(unit, ND.T_BODY, False, ND.MUTED, True)],
                     align="c", anchor="b", ml=0.02, mt=0.0, name=f"timeline T-minus {big}")
        C.face(lab, big)
        node = C.dot(cx, track_y, _in(0.34), col if done else ND.WHITE, line=col, line_w=2.25,
                     name=f"timeline gate {gt['name']}")
        cy = track_y + card_gap
        card = C.rect(cx - col_w / 2, cy, col_w, card_h, ND.WHITE, r=0.08, name=f"timeline gate card {gt['name']}")
        C.write(card, parts, anchor="t", ml=0.22 if st else 0.14, mt=0.14, mr=0.1)
        _bullets(card)
        extra = 0
        if st:
            extra = _space(card, before=5, idx={len(parts) - len([c for c in parts if c[0].startswith("• ")]) - 1})
            _edge(C, cx - col_w / 2 + _in(0.08), cy + _in(0.1), card_h - _in(0.2), st)
        C.check(_paras(parts), col_w - _in(0.1), card_h - extra, "gate", ml=0.14, mt=0.14)
        C.connect(node, card, "bottom", "top", colour=col, width=1.5, name=f"timeline gate stem {gt['name']}")
    badge = C.rect(bx, track_y - bd / 2, bd, bd, ND.accent(0), r=bd / 2 / IN, name="timeline go-live badge")
    tc = ND.contrast_text(ND.accent(0))
    gname = gl["name"] if len(gl["name"]) <= 16 else "Go-live"
    dtext = _md(gl["start"], gl["sp"])
    room = bd * 0.7071 - _in(0.24)                     # the circle's own text box is its inscribed square
    big_pt = next((p_ for p_ in (36, 32, 28, 24, 20) if max(_tw(dtext, p_, True, ND.DISPLAY), _tw(dtext, p_, True))
                   <= room), 20)
    name_pt_b = ND.T_CARD if _tw(gname, ND.T_CARD, True) <= room else ND.T_BODY
    sub = f"{gl['start']:%A}" if gl["sp"] == "day" else ""
    C.write(badge, [(gname, name_pt_b, True, tc, False), (dtext, big_pt, True, tc, True),
                    _para(sub, ND.T_BODY, False, tc, True)], align="c", anchor="m", ml=0.12, mt=0.1)
    C.face(badge, dtext)
    C.check([(gname, name_pt_b, True, None), (dtext, big_pt, True, ND.DISPLAY), (sub, ND.T_BODY, False, None)],
            int(bd * 0.7071), int(bd * 0.7071), "go-live", ml=0.12, mt=0.1)
    if today and today < gl["start"]:
        days = (gl["start"] - today).days
        ty = track_y + bd / 2 + _in(0.16)
        lo_x = xs[-1] + col_w / 2 + _in(0.1) if n else x0
        lab = next((t_ for t_ in (f"Today {_md(today)} · {days} days to go", f"{days} days to go")
                    if _tw(t_, ND.T_SMALL, True) + _in(0.24) <= x0 + w - lo_x), None)
        if lab and ty + _in(0.25) <= y0 + h:
            _today_tag(C, bx + bd / 2, ty, lo_x, x0 + w, label=lab)


# ============================================================================================ style: storyline
def _spread(t, L, R, d1, d2):
    """Positions close to t (sorted) with x[i+1]-x[i] >= d1 and x[i+2]-x[i] >= d2, inside L..R."""
    n = len(t)
    x = list(t)
    for _ in range(60):
        for i in range(n):
            lo = L
            if i >= 1:
                lo = max(lo, x[i - 1] + d1)
            if i >= 2:
                lo = max(lo, x[i - 2] + d2)
            x[i] = max(x[i], lo)
        for i in range(n - 1, -1, -1):
            hi = R
            if i + 1 < n:
                hi = min(hi, x[i + 1] - d1)
            if i + 2 < n:
                hi = min(hi, x[i + 2] - d2)
            x[i] = min(x[i], hi)
        if all(x[i + 1] - x[i] >= d1 - 2 for i in range(n - 1)) and \
                all(x[i + 2] - x[i] >= d2 - 2 for i in range(n - 2)) and x[0] >= L - 2 and x[-1] <= R + 2:
            return x
    return [L + (R - L) * i / max(1, n - 1) for i in range(n)]


def _draw_storyline(C, T):
    x0, y0, w, h = C.box
    ev = [i for i in T["items"] if i["start"] is not None]
    n = len(ev)
    if not n:
        C.P.append("no dated events to draw - give each event a date")
        return
    g = _in(0.18)
    cw = min(_in(2.9), (2 * w - g * (n - 1)) / (n + 1)) if n > 1 else _in(3.0)
    L, R = x0 + cw / 2, x0 + w - cw / 2
    d0, d1_ = min(_mid(i) for i in ev), max(_mid(i) for i in ev)
    span = max(1, (d1_ - d0).days)
    xs = _spread([L + (R - L) * (_mid(i) - d0).days / span for i in ev], L, R, _in(0.55), cw + g)
    ymid = y0 + h / 2
    inner = cw - _in(0.3)
    need = 0
    for it in ev:
        paras = [(_md(it["start"], it["sp"], year=True), ND.T_SMALL, True, None), (it["name"], ND.T_CARD, True, None)]
        if it["text"]:
            paras.append((it["text"], ND.T_BODY, False, None))
        need = max(need, _height(paras, inner) + _in(0.42) + 2 * PT * (len(paras) - 1))
    room = h / 2 - _in(0.34)
    ch = min(room, max(need, _in(1.2)))
    if need > room:
        C.P.append("story cards are too long for half the slide - keep each event to a 2-5 word title and 15 words")
    stem = min(_in(0.75), max(_in(0.34), h / 2 - ch - _in(0.06)))
    C.line(x0, ymid, x0 + w, ymid, colour=ND.accent(1), width=2.25, name="timeline story line")
    for k, (it, cx) in enumerate(zip(ev, xs)):
        col = ND.accent(k)
        above = k % 2 == 0
        cy = ymid - stem - ch if above else ymid + stem
        card = C.rect(cx - cw / 2, cy, cw, ch, ND.WHITE, r=0.1, name=f"timeline story card {it['name']}")
        parts = [_para(_md(it["start"], it["sp"], year=True), ND.T_SMALL, True, ND.MUTED, False),
                 _para(it["name"], ND.T_CARD, True, ND.INK, True)]
        if it["text"]:
            parts.append(_para(it["text"], ND.T_BODY, False, ND.INK, True))
        C.write(card, parts, anchor="b" if above else "t", ml=0.15, mt=0.16 if not above else 0.14,
                mb=0.2 if above else 0.14)
        extra = _space(card, before=2)
        C.check(_paras(parts), cw, ch - _in(0.08) - extra, "story card", ml=0.15, mt=0.16)
        C.top_rounded(cx - cw / 2, cy + ch - _in(0.075) if above else cy, cw, _in(0.075), col, 0.1, flip=above,
                      name=f"timeline story accent {it['name']}")
        dot = C.dot(cx, ymid, _in(0.26), col, line=ND.WHITE, line_w=2.0, name=f"timeline story dot {it['name']}")
        C.connect(dot, card, "top" if above else "bottom", "bottom" if above else "top", colour=col, width=1.5,
                  name=f"timeline story stem {it['name']}")


# ============================================================================================ style: vertical
def _draw_vertical(C, T):
    x0, y0, w, h = C.box
    ev = [i for i in T["items"] if i["start"] is not None]
    n = len(ev)
    if not n:
        C.P.append("no dated milestones to draw - give each milestone a date")
        return
    today = T["today"]
    pitch = h / n
    ch = pitch - _in(0.12)
    bd = min(_in(0.78), max(_in(0.48), pitch * 0.74))
    zone = max(_tw("2026", ND.T_SUB, True), _tw(f"Today {_md(today)}" if today else "", ND.T_SMALL, True) + _in(0.24)) \
        + _in(0.24)                                            # years and the today tag live left of the spine
    sx = x0 + zone + bd / 2
    card_x = sx + bd / 2 + _in(0.3)
    card_w = x0 + w - card_x
    big = pitch >= _in(1.0)
    meta_w = _in(2.2)
    inner = card_w - meta_w - _in(0.1) - _in(0.24)
    sizes = ((ND.T_SUB, ND.T_CARD), (ND.T_CARD, ND.T_BODY), (ND.T_BODY, ND.T_SMALL), (ND.T_SMALL, ND.T_MIN))
    for t_pt, b_pt in sizes[0 if big else 1:]:               # the largest pair whose tallest card fits the pitch
        if all(_height([(i["name"], t_pt, True, None)] + ([(i["text"], b_pt, False, None)] if i["text"] else []),
                       inner) + _in(0.12) <= ch for i in ev):
            break
    years = {}
    badges = []
    for k, it in enumerate(ev):
        cy = y0 + pitch * k + pitch / 2
        col = ND.accent(k)
        past = today is not None and _mid(it) <= today
        fill, tc = (col, ND.contrast_text(col)) if past else (ND.WHITE, ND.INK)
        if it["sp"] == "quarter":
            l1, l2 = f"Q{(it['start'].month - 1) // 3 + 1}", ""
        elif it["sp"] == "month":
            l1, l2 = f"{it['start']:%b}".upper(), ""
        else:
            l1, l2 = f"{it['start']:%b}".upper(), f"{it['start'].day}"
        b = C.dot(sx, cy, bd, fill, line=col, line_w=2.25, name=f"timeline badge {it['name']}")
        parts = [(l1, ND.T_MIN if l2 else ND.T_BODY, True, tc, False)] + ([(l2, ND.T_SUB if big else ND.T_CARD, True,
                                                                            tc, True)] if l2 else [])
        C.write(b, parts, align="c", anchor="m", ml=0.0, mt=0.0)
        b.text_frame.word_wrap = False
        badges.append(b)
        if it["start"].year not in years:
            years[it["start"].year] = cy
    for k in range(n - 1):
        C.connect(badges[k], badges[k + 1], "bottom", "top", colour=ND.LINE, width=2.0, name="timeline spine")
    for yr, cy in years.items():
        C.text(x0, cy - _in(0.2), zone - _in(0.18), _in(0.4), [(str(yr), ND.T_SUB, True, ND.INK, False)],
               align="r", anchor="m", ml=0.0, mt=0.0, name=f"timeline year {yr}")
    for k, it in enumerate(ev):
        cy = y0 + pitch * k + pitch / 2
        card = C.rect(card_x, cy - ch / 2, card_w, ch, ND.WHITE, r=0.1, name=f"timeline card {it['name']}")
        parts = [_para(it["name"], t_pt, True, ND.INK, False)]
        if it["text"]:
            parts.append(_para(it["text"], b_pt, False, ND.INK, True))
        C.write(card, parts, anchor="m", ml=0.22, mt=0.06, mr=(meta_w + _in(0.2)) / IN)
        C.check(_paras(parts), card_w - meta_w - _in(0.1), ch, "milestone card", ml=0.12, mt=0.06)
        mparts = []
        if it["owner"]:
            mparts.append(_para(it["owner"], ND.T_SMALL, True, ND.INK, False))
        if it["status"]:
            mparts.append(_para(STATUS_WORD[it["status"]], ND.T_SMALL, False, ND.MUTED, bool(mparts)))
        if not mparts:
            mparts.append(_para(_md(it["start"], it["sp"], year=True), ND.T_SMALL, False, ND.MUTED, False))
        C.text(card_x + card_w - meta_w - _in(0.1), cy - ch / 2, meta_w - _in(0.1), ch, mparts, align="r",
               anchor="m", ml=0.04, mt=0.04, name=f"timeline card meta {it['name']}")
        C.check(_paras(mparts), meta_w - _in(0.1), ch, "milestone date / owner", ml=0.04, mt=0.04)
        if it["status"]:
            _edge(C, card_x + card_w - _in(0.12), cy - ch / 2 + _in(0.1), ch - _in(0.2), it["status"])
        C.connect(badges[k], card, "right", "left", colour=ND.LINE, width=1.5, name=f"timeline link {it['name']}")
    if today and n > 1 and _mid(ev[0]) < today < _mid(ev[-1]):
        for k in range(n - 1):
            a, b_ = _mid(ev[k]), _mid(ev[k + 1])
            if a <= today < b_:
                y = y0 + pitch * k + pitch / 2 + pitch * (today - a).days / max(1, (b_ - a).days)
                y = min(max(y, y0 + pitch * k + pitch / 2 + bd / 2 + _in(0.04)), y0 + pitch * (k + 1) + pitch / 2
                        - bd / 2 - _in(0.04))
                C.dot(sx, y, _in(0.16), ND.PLUM, line=ND.WHITE, line_w=1.0, name="timeline today mark")
                lab = f"Today {_md(today)}"
                tw_ = _tw(lab, ND.T_SMALL, True) + _in(0.24)
                near = [cy for cy in years.values() if abs(cy - y) < _in(0.36)]
                if not near:
                    _today_tag(C, sx - bd / 2 - _in(0.12) - tw_ / 2, y - _in(0.125), x0, sx - bd / 2 - _in(0.1),
                               label=lab)
                break


# ============================================================================================ style: calendar
def _tabs(tb, cell, cells, colour, bold=False, pt=ND.T_MIN):
    """Fill a text box with one centred tab stop per day column (a calendar week on one line)."""
    p = tb.text_frame.paragraphs[0]
    for r in list(p.runs):
        r._r.getparent().remove(r._r)
    pPr = p._p.get_or_add_pPr()
    for old in pPr.findall(A + "tabLst"):
        pPr.remove(old)
    tl = etree.SubElement(pPr, A + "tabLst")
    for c in range(7):
        etree.SubElement(tl, A + "tab", pos=str(int(cell * c + cell / 2)), algn="ctr")
    order = [A + t for t in ("lnSpc", "spcBef", "spcAft", "buClrTx", "buClr", "buSzTx", "buSzPct", "buSzPts",
                             "buFontTx", "buFont", "buNone", "buAutoNum", "buChar", "buBlip", "tabLst", "defRPr",
                             "extLst")]
    kids = sorted(list(pPr), key=lambda e: order.index(e.tag) if e.tag in order else 99)
    for k_ in list(pPr):
        pPr.remove(k_)
    for k_ in kids:
        pPr.append(k_)
    for val in cells:
        r = p.add_run()
        r.text = "\t" + str(val)
        f = r.font
        f.size = Pt(pt)
        f.bold = bold
        f.name = ND.BOLD if bold else ND.BODY
        ND._font_colour(f, colour)
    tb.text_frame.word_wrap = False


def _draw_calendar(C, T):
    x0, y0, w, h = C.box
    items = [i for i in T["items"] if i["start"] is not None]
    lo, hi = T["lo"], T["hi"]
    span = (hi.year - lo.year) * 12 + hi.month - lo.month + 1
    nm = 6 if span <= 6 else 12
    start = dt.date(lo.year, lo.month, 1)
    if nm == 12 and lo.year == hi.year and not T.get("start_given"):
        start = dt.date(lo.year, 1, 1)
    cols, rws = (3, 2) if nm == 6 else (4, 3)
    g = _in(0.12)
    tw_ = (w - (cols - 1) * g) / cols
    th = (h - (rws - 1) * g) / rws
    head_h = _in(0.3) if nm == 12 else _in(0.34)
    day_pt = ND.T_MIN if nm == 12 else ND.T_SMALL
    today = T["today"]
    for m in range(nm):
        ms = _add_months(start, m)
        me = _add_months(start, m + 1)
        col = ND.accent((ms.month - 1) // 3)
        tx = x0 + (m % cols) * (tw_ + g)
        ty = y0 + (m // cols) * (th + g)
        now_month = bool(today and ms <= today < me)
        C.rect(tx, ty, tw_, th, ND.WHITE, r=0.08, line=ND.PLUM if now_month else None, line_w=1.5,
               name=f"timeline month {ms:%b %Y}")
        hdr = C.top_rounded(tx, ty, tw_, head_h, col, 0.08, name=f"timeline month header {ms:%b %Y}")
        tc = ND.contrast_text(col)
        C.write(hdr, [(f"{ms:%B}", ND.T_BODY, True, tc, False), (f"  {ms.year}", ND.T_SMALL, False, tc, False)],
                anchor="m", ml=0.12, mt=0.0)
        grid_w = min(tw_ * 0.5, _in(1.7)) if nm == 12 else min(tw_ * 0.5, _in(2.1))
        cell = grid_w / 7
        gx = tx + _in(0.08)
        body_top = ty + head_h + _in(0.06)
        weeks = _cal.Calendar(0).monthdayscalendar(ms.year, ms.month)
        rh = min(_in(0.22) if nm == 12 else _in(0.3), (th - head_h - _in(0.12)) / (len(weeks) + 1))
        evs = [i for i in items if i["start"] < me and i["end"] >= ms]
        keyd = {}
        for i in evs:
            if i["ms"] and i["sp"] == "day" and ms <= i["start"] < me:
                keyd.setdefault(i["start"].day, i)
        ranges = [i for i in evs if not i["ms"] and i["sp"] == "day"]
        for wi, wk in enumerate(weeks):                        # multi-day events: a soft pill behind the days
            y = body_top + (wi + 1) * rh
            for i in ranges:
                days = [c for c, d in enumerate(wk) if d and i["start"] <= dt.date(ms.year, ms.month, d) <= i["end"]]
                if days:
                    a, b = min(days), max(days)
                    C.rect(gx + a * cell + _in(0.01), y + _in(0.015), (b - a + 1) * cell - _in(0.02), rh - _in(0.03),
                           ND.ROSE_TINT, r=(rh - _in(0.03)) / 2 / IN, name=f"timeline range {i['name']}")
        wd = C.text(gx, body_top, grid_w, rh, [("", ND.T_MIN, False, ND.MUTED, False)], ml=0.0, mt=0.0,
                    anchor="m", name="timeline weekdays")
        _tabs(wd, cell, "MTWTFSS", ND.MUTED, bold=True, pt=day_pt)
        for wi, wk in enumerate(weeks):
            y = body_top + (wi + 1) * rh
            for c, d in enumerate(wk):
                if d and d in keyd:
                    kd = C.dot(gx + c * cell + cell / 2, y + rh / 2, max(cell, rh) * 0.98, col,
                               name=f"timeline key date {keyd[d]['name']}", text=str(d), size=day_pt, bold=True,
                               color=ND.contrast_text(col), margin=0.0)
                    kd.text_frame.word_wrap = False
                    kd.text_frame.margin_left = kd.text_frame.margin_right = 0
            tb = C.text(gx, y, grid_w, rh, [("", ND.T_MIN, False, ND.INK, False)], ml=0.0, mt=0.0, anchor="m",
                        name=f"timeline week {wi + 1}")
            _tabs(tb, cell, [("" if (not d or d in keyd) else str(d)) for d in wk], ND.INK, pt=day_pt)
            if today and ms <= today < me and today.day in wk:
                c = wk.index(today.day)
                C.dot(gx + c * cell + cell / 2, y + rh / 2, max(cell, rh) * 1.02, None, line=ND.PLUM, line_w=1.25,
                      name="timeline today ring")
        lx = gx + grid_w + _in(0.1)
        lw = tx + tw_ - lx - _in(0.08)
        lh = th - head_h - _in(0.12)
        # listed in the month they start (a run that began before the first month: in the first month)
        lst = sorted((i for i in evs if ms <= i["start"] < me or (m == 0 and i["start"] < ms)), key=lambda i: i["start"])

        def when(i):
            if i["sp"] != "day":
                return f"{i['start']:%b}"
            if i["ms"]:
                return f"{i['start'].day}"
            a = max(i["start"], ms)
            if i["end"] < me:
                return f"{a.day}" if a == i["end"] else f"{a.day}–{i['end'].day}"
            return f"{a.day} – {i['end']:%b} {i['end'].day}"

        def entries(k, gap):
            parts = []
            for i in lst[:k]:
                parts.append((when(i) + "  ", day_pt, True, ND.INK, bool(parts)))
                parts.append((i["name"], day_pt, False, ND.INK, False))
            if k < len(lst):
                parts.append((f"+{len(lst) - k} more", day_pt, False, ND.MUTED, True))
            paras = _paras(parts)
            return parts, _height(paras, lw - _in(0.04)) + _in(0.06) + gap * PT * len(paras)
        best = None
        for gap in (4, 2, 0):
            for k in range(len(lst), 0, -1):
                parts, need = entries(k, gap)
                if need <= lh:
                    if best is None or k > best[2]:
                        best = (parts, gap, k)
                    break
            if best and best[2] == len(lst):
                break
        if lst:
            parts, gap, k = best or (entries(1, 0)[0], 0, 1)
            lt = C.text(lx, body_top, lw, lh, parts, ml=0.02, mt=0.03, name=f"timeline key dates {ms:%b}")
            if gap:
                _space(lt, after=gap)
            if k < len(lst):
                C.P.append(f"{ms:%B}: {len(lst) - k} of its {len(lst)} key dates do not fit the month tile - shorten "
                           "the names to 2-3 words or keep the main dates")


# ============================================================================================ contract
DRAW = {"lanes": _draw_lanes, "status-roadmap": _draw_status, "phases": _draw_phases, "quarters": _draw_quarters,
        "sprints": _draw_sprints, "now-next-later": _draw_nnl, "countdown": _draw_countdown,
        "storyline": _draw_storyline, "vertical": _draw_vertical, "calendar": _draw_calendar}


def _months(T):
    return (T["hi"].year - T["lo"].year) * 12 + T["hi"].month - T["lo"].month + 1


def _sequential(spans, slack=7):
    """True when (start, end) spans follow one another (each starts after the previous one ends, give or take)."""
    spans = sorted(spans)
    return all(b[0] >= a[1] - dt.timedelta(days=slack) for a, b in zip(spans, spans[1:]))


def auto_style(data):
    """The style that fits the timeline's shape best (a style the data can fill without lint problems)."""
    try:
        T = _parse(data, need_dates=False)
    except Exception:
        return "lanes"
    items = T["items"]
    if items and all(i["group"].strip().lower() in NNL for i in items):
        return "now-next-later"                                   # the user sorted it into horizons
    dated = [i for i in items if i["start"] is not None]
    if not dated:
        return "now-next-later"
    ms = [i for i in dated if i["ms"]]
    tasks = [i for i in dated if not i["ms"]]
    groups = [g for g in _groups(T, dated) if g]
    months = _months(T)
    today = T["today"]
    if tasks and sum(bool(_sprint_no(t["name"])) for t in tasks) >= 0.6 * len(tasks):
        return "sprints"
    if any(i["golive"] for i in items):
        return "countdown"
    gl, gates = _countdown_parts(T)
    if gl is not None and GOLIVE.search(gl["name"]) and gl["start"] >= T["hi"] and 3 <= len(gates) <= 7 \
            and len(tasks) <= 1 and sum(1 for g_ in gates if g_["status"] or g_["owner"]) >= 0.5 * len(gates):
        return "countdown"                                        # readiness gates in front of one go-live
    if not tasks:                                                 # milestones only
        if len(ms) > 8:
            return "calendar" if months <= 12 else "storyline"
        detail = any(i["owner"] or i["status"] for i in ms) or \
            sum(_words(i["text"]) for i in ms) > 8 * len(ms)
        return "vertical" if len(ms) <= 4 or (len(ms) <= 7 and detail) else "storyline"
    short = sum(1 for i in dated if (i["end"] - i["start"]).days <= 31)
    if len(dated) >= 9 and months <= 12 and short >= 0.8 * len(dated) and not groups:
        return "calendar"                                         # many dates and short events within a year
    if len(tasks) >= 2 and sum(1 for i in dated if i["status"]) >= max(2, 0.6 * len(dated)) and len(dated) <= 12:
        return "status-roadmap"
    if 3 <= len(groups) <= 6 and _sequential([(min(i["start"] for i in dated if i["group"] == g),
                                                max(i["end"] for i in dated if i["group"] == g)) for g in groups]):
        return "phases"                                           # groups that follow one another are phases
    if not groups and 3 <= len(tasks) <= 6 and len(ms) <= 3 and _sequential([(t["start"], t["end"]) for t in tasks]):
        return "phases"
    if 2 <= len(groups) <= 6 and len(dated) <= 14:
        return "lanes"
    if not groups and today and len(tasks) >= 3 and sum(1 for t in tasks if t["start"] > today) >= 0.5 * len(tasks) \
            and T["hi"] >= _add_months(dt.date(today.year, 3 * ((today.month - 1) // 3) + 1, 1), 6):
        return "now-next-later"                                   # a roadmap that is mostly ahead of today
    if months >= 6 and ms:
        return "quarters"
    return "lanes"


def _count_words(items, field, limit, what, P):
    for i in items:
        if _words(i[field]) > limit:
            P.append(f"{what} '{i[field][:40]}' is {_words(i[field])} words - keep it to {limit} (detail goes in the notes)")


def _explicit_nnl(data):
    return isinstance(data, dict) and bool(data.get("items")) and all(
        str((i or {}).get("group") or "").strip().lower() in NNL for i in data["items"] if isinstance(i, dict))


def lint(spec):
    """Content problems for the slide's style - each says how to fix it."""
    spec = spec or {}
    data = spec.get("timeline")
    if isinstance(data, list):
        data = {"items": data}
    if not isinstance(data, dict):
        return ["\"timeline\" needs an object: {\"items\": [{\"name\", \"start\", \"end\" | \"date\", ...}]}"]
    style = spec.get("style") or auto_style(data)
    if style not in STYLES:
        return [f"timeline style '{style}' does not exist - use one of: {', '.join(STYLES)}"]
    T = _parse(data, need_dates=not (style == "now-next-later" and _explicit_nnl(data)))
    P = list(T["problems"])
    items = T["items"]
    dated = [i for i in items if i["start"] is not None]
    ms = [i for i in dated if i["ms"]]
    tasks = [i for i in dated if not i["ms"]]
    if not items:
        return P or [f"the {style} timeline has no items - add items with a name and dates"]
    if style != "now-next-later" and not dated:
        return P
    groups = [g for g in _groups(T, dated) if g]
    span_m = _months(T) if dated else 0
    if style == "lanes":
        if len(groups) > 6:
            P.append(f"{len(groups)} workstreams - lanes hold 6: merge small workstreams or split the plan over two slides")
        if len(dated) > 14:
            P.append(f"{len(dated)} tasks and milestones - lanes hold 14: keep the ones the audience must see, or split "
                     "the plan by quarter")
        _count_words(dated, "name", 6, "task name", P)
        _count_words([{"g": g} for g in groups], "g", 3, "workstream name", P)
        if span_m > 24:
            P.append(f"the plan spans {span_m} months - lanes read best over 2-24 months; split it or use quarters")
    elif style == "status-roadmap":
        if len(dated) > 12:
            P.append(f"{len(dated)} rows - a status roadmap holds 12: group small deliverables or split the slide")
        missing = [i["name"] for i in dated if not i["status"]]
        if missing:
            P.append(f"no status on '{missing[0][:40]}'" + (f" and {len(missing) - 1} more" if len(missing) > 1 else "")
                     + " - give each row \"status\": done, on track, at risk or late")
        if len(groups) > 6:
            P.append(f"{len(groups)} workstreams - keep a status roadmap to 6")
        _count_words(dated, "name", 6, "deliverable", P)
        _count_words(dated, "owner", 3, "owner", P)
        if span_m > 24:
            P.append(f"the plan spans {span_m} months - keep a status roadmap to 2-24 months")
    elif style == "phases":
        phases = _phase_list(T)
        if not 3 <= len(phases) <= 6:
            P.append(f"{len(phases)} phases - the phases style shows 3-6: give each phase a start and end date "
                     "(or group the items by phase)")
        for p in phases:
            if _words(p["name"]) > 3:
                P.append(f"phase name '{p['name'][:40]}' is {_words(p['name'])} words - name a phase in 1-3 words")
            if len(p["dels"]) > 3:
                P.append(f"phase '{p['name'][:30]}' has {len(p['dels'])} deliverables - show 1-3 (the rest go in the "
                         "notes)")
            for _k, d, _i in p["dels"]:
                if _words(d) > 8:
                    P.append(f"deliverable '{d[:40]}' is {_words(d)} words - keep it to 8")
    elif style == "quarters":
        qs = _periods(T["lo"], T["hi"], "quarter")[0]
        if not 2 <= len(qs) <= 6:
            P.append(f"the plan covers {len(qs)} quarters - the quarters style shows 2-6 (use lanes for a shorter plan, "
                     "split a longer one)")
        if len(ms) > 8:
            P.append(f"{len(ms)} launches - keep the quarter band to 8 milestones (the rest go in the notes)")
        _count_words(ms, "name", 4, "milestone name", P)
        _count_words(tasks, "name", 5 if len(qs) <= 4 else 4, "deliverable", P)
        cap = 4 if len(qs) <= 4 else 3
        for s, e in qs:
            due = [t for t in tasks if s <= t["end"] < e]
            if len(due) > cap:
                P.append(f"Q{(s.month - 1) // 3 + 1} {s.year} has {len(due)} deliverables - with {len(qs)} quarters a "
                         f"quarter lists {cap} (the rest go in the notes)")
    elif style == "sprints":
        if not 3 <= len(tasks) <= 12:
            P.append(f"{len(tasks)} sprints - the release train shows 3-12 (each sprint: name, start, end, goal in "
                     "\"text\"); releases are milestones")
        if len(ms) > 4:
            P.append(f"{len(ms)} releases - keep to 4 on one release train")
        _count_words(tasks, "text", 12 if len(tasks) <= 8 else 8, "sprint goal", P)
        _count_words(ms, "name", 4, "release name", P)
        lens = {(t["end"] - t["start"]).days for t in tasks}
        if lens and max(lens) - min(lens) > 7:
            P.append("sprints differ in length by more than a week - the release train draws equal sprints; check the "
                     "dates or use lanes")
        late = [r for r in ms if tasks and r["start"] > max(t["end"] for t in tasks) + dt.timedelta(days=21)]
        if late:
            P.append(f"release '{late[0]['name'][:30]}' comes after the last sprint - add the sprints that ship it")
    elif style == "now-next-later":
        cols = _nnl_columns(T)
        nmax = max(len(its) for _t, _w, its in cols)
        limit = 12 if nmax <= 3 else (8 if nmax == 4 else 5)        # every column shares the busiest one's rows
        for title, _w, its in cols:
            if not its and title != "Done":
                P.append(f"the '{title}' column is empty - give it 1-5 items, or set each item's \"group\" to now, next "
                         "or later")
            if len(its) > 5:
                P.append(f"the '{title}' column has {len(its)} items - show 5 at most (the rest go in the notes)")
            long_ = [i for i in its if _words(i["text"]) > limit]
            if long_ and nmax <= 5:
                P.append(f"with {nmax} items in a column, each item's text gets {limit} words - "
                         f"'{long_[0]['text'][:40]}' has {_words(long_[0]['text'])} (detail goes in the notes)")
        _count_words(items, "name", 5, "item name", P)
    elif style == "countdown":
        gl, gates = _countdown_parts(T)
        if gl is None:
            P.append("no go-live milestone - add one (\"golive\": true, or a milestone named 'Go-live' / 'Launch')")
        else:
            n0 = len(P)
            if not 3 <= len(gates) <= 7:
                P.append(f"{len(gates)} readiness gate{'s' if len(gates) != 1 else ''} - the countdown shows 3-7 before "
                         "the go-live")
            late = [g_ for g_ in gates if g_["end"] > gl["start"]]
            if late:
                P.append(f"gate '{late[0]['name'][:40]}' falls after the go-live - countdown gates come before it")
            if len(P) > n0 and not gl["golive"] and not GOLIVE.search(gl["name"]):
                P.insert(n0, f"no milestone is marked as the go-live, so the last one ('{gl['name'][:30]}', "
                             f"{_md(gl['start'], gl['sp'])}) was used - mark the real go-live with \"golive\": true")
            _count_words(gates, "name", 5, "gate name", P)
            for g_ in gates:
                checks = [c for c in re.split(r"[;\n]", g_["text"]) if c.strip()]
                if len(checks) > 3 or any(_words(c) > 6 for c in checks):
                    P.append(f"gate '{g_['name'][:30]}': keep its detail to 3 checks of up to 6 words (\"a; b; c\")")
    elif style == "storyline":
        if not 5 <= len(dated) <= 8:
            P.append(f"{len(dated)} events - the story line shows 5-8 (4 or fewer read better as vertical)")
        _count_words(dated, "name", 5, "event title", P)
        _count_words(dated, "text", 12, "event text", P)
    elif style == "vertical":
        if not 4 <= len(dated) <= 7:
            P.append(f"{len(dated)} milestones - the vertical timeline shows 4-7 (use storyline for 8, lanes for a plan)")
        _count_words(dated, "name", 6, "milestone title", P)
        _count_words(dated, "text", 14 if len(dated) <= 5 else 10, "milestone text", P)
    elif style == "calendar":
        if span_m > 12:
            P.append(f"the dates span {span_m} months - a year-at-a-glance calendar shows 12; split it or use quarters")
        per = {}
        for i in dated:
            per.setdefault((i["start"].year, i["start"].month), []).append(i)
        for (y, m), its in sorted(per.items()):
            if len(its) > 3:
                P.append(f"{dt.date(y, m, 1):%B %Y} has {len(its)} key dates - a month tile lists 3; keep the main ones")
        _count_words(dated, "name", 3, "key date name", P)
    return P


def draw(slide, box, spec):
    """Draw the timeline into box (x, y, w, h EMU) on a title-only slide; returns problems (empty = fine)."""
    spec = spec or {}
    data = spec.get("timeline") or {}
    style = spec.get("style") or auto_style(data)
    if style not in DRAW:
        return [f"timeline style '{style}' does not exist - use one of: {', '.join(STYLES)}"]
    try:
        T = _parse(data, need_dates=not (style == "now-next-later" and _explicit_nnl(data)))
    except Exception as e:
        return [f"timeline data could not be read ({str(e)[:80]}) - see the timeline format in tools/timelines.py"]
    if not T["items"] or (style != "now-next-later" and T["lo"] is None):
        return ["timeline not drawn: it has no dated items (fix the timeline problems listed for this slide)"]
    C = _Canvas(slide, tuple(int(v) for v in box))
    try:
        DRAW[style](C, T)
    except Exception as e:                                      # never break the build: report and leave the slide
        import traceback
        tb = traceback.extract_tb(e.__traceback__)[-1]
        for sh in C.shapes:
            sh._element.getparent().remove(sh._element)
        return [f"timeline style '{style}' could not be drawn ({type(e).__name__}: {str(e)[:60]}, line {tb.lineno}) "
                "- check the dates and counts"]
    bx, by, bw, bh = C.box
    tol = _in(0.02)
    for sh in C.shapes:
        if sh.left < bx - tol or sh.top < by - tol or sh.left + sh.width > bx + bw + tol or \
                sh.top + sh.height > by + bh + tol:
            C.P.append(f"'{sh.name}' runs outside the content frame - use fewer items or shorter text")
            break
    C.group(f"Timeline ({style})")
    return list(dict.fromkeys(C.P))


# ============================================================================================ samples
def sample():
    """One storyboard slide per style, realistic content of the shape each style needs (each a different picture)."""
    T0 = "2026-10-17"
    return [
        {"style": "lanes", "headline": "5 teams, 12 tasks: holiday readiness locks Nov 6",
         "notes": "Lanes (template slide 15's look): one lane per workstream, bars are tasks, the diamond is the code "
                  "freeze, the dashed line is today. Store ops hiring and supply chain inbound are the critical path.",
         "timeline": {"today": T0, "items": [
             {"name": "Peak staffing plan", "group": "Store ops", "start": "2026-08-03", "end": "2026-09-11"},
             {"name": "Seasonal hiring", "group": "Store ops", "start": "2026-09-14", "end": "2026-10-30"},
             {"name": "Holiday sets", "group": "Store ops", "start": "2026-11-02", "end": "2026-11-20"},
             {"name": "Gift finder build", "group": "ulta.com", "start": "2026-08-10", "end": "2026-10-02"},
             {"name": "Load testing", "group": "ulta.com", "start": "2026-10-05", "end": "2026-10-30"},
             {"name": "Code freeze", "group": "ulta.com", "date": "2026-11-06", "milestone": True},
             {"name": "Inbound peak", "group": "Supply chain", "start": "2026-08-17", "end": "2026-10-16"},
             {"name": "DC overflow space", "group": "Supply chain", "start": "2026-10-19", "end": "2026-12-18"},
             {"name": "Campaign creative", "group": "Marketing", "start": "2026-08-24", "end": "2026-10-16"},
             {"name": "Holiday campaign live", "group": "Marketing", "start": "2026-11-09", "end": "2026-12-31"},
             {"name": "Double points offer", "group": "Loyalty", "start": "2026-09-21", "end": "2026-11-13"},
             {"name": "Member days", "group": "Loyalty", "start": "2026-12-01", "end": "2026-12-14"}]}},
        {"style": "status-roadmap", "headline": "Pilot live in 9 weeks; 3 of 5 teams on track",
         "notes": "Status roadmap: one row per deliverable with its owner; the edge is its status. Supply chain is "
                  "at risk (supplier feeds); Stores IT is late (shelf-label hardware arrives Dec 4, recovery plan in "
                  "review).",
         "timeline": {"today": T0, "items": [
             {"name": "Pilot store selection", "group": "Store ops", "start": "2026-08-03", "end": "2026-09-04",
              "owner": "R. Vale", "status": "done"},
             {"name": "Associate training", "group": "Store ops", "start": "2026-11-09", "end": "2026-12-11",
              "owner": "R. Vale", "status": "on track"},
             {"name": "Demand model tuning", "group": "Supply chain", "start": "2026-09-07", "end": "2026-11-13",
              "owner": "T. Marsh", "status": "on track"},
             {"name": "Supplier data feeds", "group": "Supply chain", "start": "2026-09-21", "end": "2026-11-27",
              "owner": "T. Marsh", "status": "at risk"},
             {"name": "Shelf-label hardware", "group": "Stores IT", "start": "2026-10-05", "end": "2026-12-04",
              "owner": "D. Lowe", "status": "late"},
             {"name": "Store app release", "group": "Stores IT", "start": "2026-10-12", "end": "2026-12-11",
              "owner": "D. Lowe", "status": "on track"},
             {"name": "Replenishment dashboard", "group": "Analytics", "start": "2026-09-14", "end": "2026-11-20",
              "owner": "S. Frey", "status": "on track"},
             {"name": "Pilot go-live", "group": "Analytics", "date": "2026-12-18", "milestone": True,
              "owner": "S. Frey", "status": "on track"},
             {"name": "Change network", "group": "Change", "start": "2026-10-19", "end": "2026-12-18",
              "owner": "N. Cole", "status": "on track"}]}},
        {"style": "phases", "headline": "Store refresh: 1,400 stores in 5 phases by June",
         "notes": "Phases: one chevron per phase with its dates and key deliverables; the outlined card is today's "
                  "phase. The ruler at the bottom shows how long each phase really runs.",
         "timeline": {"today": T0, "items": [
             {"name": "Discover", "start": "2026-01-05", "end": "2026-02-27",
              "text": "Guest research in 40 stores; Fixture cost baseline"},
             {"name": "Design", "start": "2026-03-02", "end": "2026-04-24",
              "text": "New beauty bar layout; Capex case approved"},
             {"name": "Pilot", "start": "2026-05-04", "end": "2026-07-31",
              "text": "12 pilot stores refreshed; Sales lift read-out"},
             {"name": "Scale", "start": "2026-08-03", "end": "2026-12-18",
              "text": "600 stores in two waves; Install crews trained"},
             {"name": "Chain-wide", "start": "2027-01-11", "end": "2027-06-25",
              "text": "Remaining 800 stores; Benefits tracked monthly"}]}},
        {"style": "quarters", "headline": "Digital roadmap: 5 of 7 launches live, 2 in Q4",
         "notes": "Quarters: launches above the quarter band (on their dates), deliverables due in each quarter below.",
         "timeline": {"today": T0, "items": [
             {"name": "App redesign", "date": "2026-02-18", "milestone": True},
             {"name": "Virtual try-on", "date": "2026-04-22", "milestone": True},
             {"name": "Faster checkout", "date": "2026-06-10", "milestone": True},
             {"name": "Points at checkout", "date": "2026-08-05", "milestone": True},
             {"name": "Search relaunch", "date": "2026-09-16", "milestone": True},
             {"name": "Gift finder", "date": "2026-11-04", "milestone": True},
             {"name": "Pickup slots", "date": "2026-12-09", "milestone": True},
             {"name": "Design system v2", "start": "2026-01-05", "end": "2026-03-20", "owner": "Digital"},
             {"name": "Product data cleanup", "start": "2026-01-12", "end": "2026-03-27", "owner": "Merch"},
             {"name": "Try-on shade library", "start": "2026-02-02", "end": "2026-05-15", "owner": "Digital"},
             {"name": "Payments upgrade", "start": "2026-04-06", "end": "2026-06-26", "owner": "IT"},
             {"name": "Loyalty API", "start": "2026-05-04", "end": "2026-08-28", "owner": "Loyalty"},
             {"name": "Search tuning", "start": "2026-07-06", "end": "2026-09-25", "owner": "Digital"},
             {"name": "Peak load readiness", "start": "2026-09-14", "end": "2026-11-06", "owner": "IT"},
             {"name": "Store slot booking", "start": "2026-10-05", "end": "2026-12-11", "owner": "Store ops"}]}},
        {"style": "sprints", "headline": "Loyalty app: 8 sprints ship 3 releases by Jan 8",
         "notes": "Release train: equal two-week sprints with their goals under the release they ship; diamonds on "
                  "the axis are release dates. The outlined sprint is the current one.",
         "timeline": {"today": T0, "items": [
             {"name": "Sprint 21", "start": "2026-09-14", "end": "2026-09-25", "text": "Tier rules engine"},
             {"name": "Sprint 22", "start": "2026-09-28", "end": "2026-10-09", "text": "Tier badges in app"},
             {"name": "Sprint 23", "start": "2026-10-12", "end": "2026-10-23", "text": "Points history redesign"},
             {"name": "Sprint 24", "start": "2026-10-26", "end": "2026-11-06", "text": "Birthday gift flow"},
             {"name": "Sprint 25", "start": "2026-11-09", "end": "2026-11-20", "text": "Hardening for peak"},
             {"name": "Sprint 26", "start": "2026-11-23", "end": "2026-12-04", "text": "Personal offers feed"},
             {"name": "Sprint 27", "start": "2026-12-07", "end": "2026-12-18", "text": "Offer targeting rules"},
             {"name": "Sprint 28", "start": "2026-12-21", "end": "2027-01-01", "text": "Launch readiness"},
             {"name": "R1 Tier badges", "date": "2026-10-09", "milestone": True},
             {"name": "R2 Points and gifts", "date": "2026-11-20", "milestone": True},
             {"name": "R3 Personal offers", "date": "2027-01-08", "milestone": True}]}},
        {"style": "now-next-later", "headline": "3 initiatives in flight; 6 more queued for 2027",
         "notes": "Now / Next / Later: what ships this quarter, next quarter and after. Items move left as they are "
                  "funded and staffed; store pickup slots is at risk on staffing.",
         "timeline": {"today": T0, "items": [
             {"name": "Holiday gift finder", "start": "2026-08-10", "end": "2026-11-06", "owner": "Digital",
              "status": "on track", "text": "Guided gifting by budget"},
             {"name": "Store pickup slots", "start": "2026-09-14", "end": "2026-12-11", "owner": "Store ops",
              "status": "at risk", "text": "Book a 30-minute pickup window"},
             {"name": "Faster guest checkout", "start": "2026-10-05", "end": "2026-12-18", "owner": "Digital",
              "status": "on track", "text": "One-page checkout for guests"},
             {"name": "Points at checkout", "start": "2027-01-11", "end": "2027-03-26", "owner": "Loyalty",
              "text": "Redeem points when paying"},
             {"name": "Lip try-on", "start": "2027-01-18", "end": "2027-03-19", "owner": "Digital",
              "text": "Virtual try-on for 900 shades"},
             {"name": "Search relevance", "start": "2027-02-01", "end": "2027-03-31", "owner": "Merch",
              "text": "Ranking tuned on conversion"},
             {"name": "Personal homepage", "start": "2027-04-05", "end": "2027-07-30", "owner": "Digital",
              "text": "Content by beauty profile"},
             {"name": "Auto-replenish", "start": "2027-05-03", "end": "2027-08-27", "owner": "Loyalty",
              "text": "Subscribe to repeat products"},
             {"name": "Live shopping", "start": "2027-06-07", "end": "2027-09-24", "owner": "Marketing",
              "text": "Hosted product launches"}]}},
        {"style": "countdown", "headline": "POS go-live Nov 30: 6 gates, 1 done, 1 at risk",
         "notes": "Countdown: readiness gates in weeks before go-live. Filled gates are done; the amber edge is at "
                  "risk - user acceptance sign-off waits on two defects (fix due Oct 23).",
         "timeline": {"today": T0, "items": [
             {"name": "Code freeze", "date": "2026-10-05", "owner": "IT", "status": "done",
              "text": "Branch cut; Scope locked"},
             {"name": "UAT sign-off", "date": "2026-10-19", "owner": "Store ops", "status": "at risk",
              "text": "2 defects open; Retest Oct 23"},
             {"name": "Training done", "date": "2026-11-02", "owner": "HR", "status": "on track",
              "text": "18K trained; Leads certified"},
             {"name": "Dress rehearsal", "date": "2026-11-09", "owner": "IT", "status": "on track",
              "text": "Cutover run; Rollback tested"},
             {"name": "Data migration", "date": "2026-11-16", "owner": "Data", "status": "on track",
              "text": "Final load; Totals reconciled"},
             {"name": "Go / no-go", "date": "2026-11-23", "owner": "Steering", "status": "on track",
              "text": "Gates green; Hypercare staffed"},
             {"name": "POS go-live", "date": "2026-11-30", "milestone": True, "golive": True}]}},
        {"style": "storyline", "headline": "Same-day delivery: 1 market to 50 in 18 months",
         "notes": "Story line: the rollout's milestones in order; spacing follows the dates.",
         "timeline": {"today": T0, "items": [
             {"name": "Pilot in one market", "date": "2025-04-07", "text": "Orders by 2 pm arrive the same evening"},
             {"name": "Second courier", "date": "2025-07-14", "text": "Capacity for weekend peaks"},
             {"name": "10 markets", "date": "2025-10-06", "text": "Top metros, 35% of online demand"},
             {"name": "Holiday peak", "date": "2025-12-15", "text": "48K same-day orders in one week"},
             {"name": "30 markets", "date": "2026-04-13", "text": "Ship-from-store in 600 stores"},
             {"name": "In the app", "date": "2026-07-20", "text": "Same-day filter on every product page"},
             {"name": "50 markets", "date": "2026-10-05", "text": "70% of guests now in range"}]}},
        {"style": "vertical", "headline": "Mobile checkout: all 1,400 stores in 6 steps",
         "notes": "Vertical timeline: each badge is a milestone date; filled badges are done, the plum dot is today.",
         "timeline": {"today": T0, "items": [
             {"name": "Pilot design", "date": "2026-03-02", "owner": "Store ops", "status": "done",
              "text": "Scan-and-pay flow tested with 40 guests"},
             {"name": "5-store pilot", "date": "2026-05-04", "owner": "Store ops", "status": "done",
              "text": "Lines 12% shorter at peak hours"},
             {"name": "Region launch", "date": "2026-07-13", "owner": "Region West", "status": "done",
              "text": "120 stores, associate devices refreshed"},
             {"name": "Holiday ready", "date": "2026-10-05", "owner": "IT", "status": "done",
              "text": "Load tested for 3x peak traffic"},
             {"name": "Chain-wide", "date": "2027-01-11", "owner": "Store ops", "status": "on track",
              "text": "All 1,400 stores live after the holiday freeze"},
             {"name": "Benefits review", "date": "2027-03-01", "owner": "Finance", "status": "on track",
              "text": "Labor hours and conversion read-out"}]}},
        {"style": "calendar", "headline": "2027 marketing: 15 key dates, 5 in Nov–Dec",
         "notes": "Year at a glance: circled days are key dates, shaded runs are multi-day events. Five of the 15 "
                  "fall in the Nov-Dec peak (Black Friday to the year-end sale); spring and fall beauty events run 3 "
                  "weeks each.",
         "timeline": {"today": T0, "start": "2027-01-01", "end": "2027-12-31", "items": [
             {"name": "New year reset", "start": "2027-01-04", "end": "2027-01-17"},
             {"name": "Valentine's Day", "date": "2027-02-14"},
             {"name": "Spring beauty event", "start": "2027-03-07", "end": "2027-03-27"},
             {"name": "Earth Day", "date": "2027-04-22"},
             {"name": "Mother's Day", "date": "2027-05-09"},
             {"name": "Summer launch", "date": "2027-06-03"},
             {"name": "Member days", "start": "2027-07-12", "end": "2027-07-18"},
             {"name": "Back to school", "start": "2027-08-01", "end": "2027-08-21"},
             {"name": "Fall beauty event", "start": "2027-09-05", "end": "2027-09-25"},
             {"name": "Gift guide live", "date": "2027-10-28"},
             {"name": "Black Friday", "date": "2027-11-26"},
             {"name": "Cyber Monday", "date": "2027-11-29"},
             {"name": "Last ship day", "date": "2027-12-18"},
             {"name": "Gift card push", "start": "2027-12-19", "end": "2027-12-24"},
             {"name": "Year-end sale", "start": "2027-12-26", "end": "2027-12-31"}]}},
    ]


if __name__ == "__main__":
    print(__doc__)
