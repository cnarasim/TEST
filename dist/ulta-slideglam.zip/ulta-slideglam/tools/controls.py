"""Enterprise controls on a file the Studio built (Deliverable Studio v6.17): accessibility fix + check, sensitive-data
scan, optional classification label, version stamp. One JSON line on stdout; the file is changed in place.
    python central/tools/controls.py Deck.pptx [--action built] [--classification internal] [--owner "Name"] [--no-fix]
    python central/tools/controls.py Diagram.drawio Page.svg ...      (non-.pptx files: the sensitive-data scan only)
JSON: {"accessibility": PASS|REVIEW|FAIL, "a11y_fixed": n, "a11y": [lines], "sensitive": PASS|REVIEW|FAIL,
       "findings": [masked lines], "version": "1.0", "classification": label or null}
Each control is independent: one that errors is reported as "ERROR: ..." and the others still run. Never prints a
sensitive match in full (compliance.py masks them).
"""
import argparse, json, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))


def run(files, action="built", classification=None, owner=None, fix=True):
    res = {"accessibility": None, "a11y_fixed": 0, "a11y": [], "sensitive": None, "findings": [], "version": None,
           "classification": None, "errors": []}
    decks = [Path(f) for f in files if str(f).lower().endswith(".pptx")]
    for deck in decks[:1]:
        try:
            import a11y
            if fix:
                res["a11y_fixed"] = a11y.fix(deck)
            f, r = a11y.check(deck)
            res["accessibility"] = "FAIL" if f else "REVIEW" if r else "PASS"
            res["a11y"] = [f"FAIL {x}" for x in f] + [f"REVIEW {x}" for x in r[:15]]
        except (Exception, SystemExit) as e:  # noqa: BLE001  a control that errors is reported, never fatal
            res["errors"].append(f"accessibility: {type(e).__name__}: {e}"[:200])
        if classification:
            try:
                import compliance
                compliance.classify(deck, classification)
                res["classification"] = classification
            except (Exception, SystemExit) as e:  # noqa: BLE001
                res["errors"].append(f"classification: {type(e).__name__}: {e}"[:200])
    try:
        import compliance
        found = compliance.scan([str(f) for f in files])
        block = sum(x["severity"] == "BLOCK" for x in found)
        res["sensitive"] = "FAIL" if block else "REVIEW" if found else "PASS"
        res["findings"] = [f"{x['severity']} {Path(x['file']).name} {x['where']}: {x['kind']} '{x['match']}'" for x in found[:30]]
    except (Exception, SystemExit) as e:  # noqa: BLE001
        res["errors"].append(f"sensitive-data scan: {type(e).__name__}: {e}"[:200])
    for deck in decks[:1]:
        try:
            import stamp
            result = "FAIL" if "FAIL" in (res["accessibility"], res["sensitive"]) else \
                     "REVIEW" if "REVIEW" in (res["accessibility"], res["sensitive"]) else "READY"
            res["version"] = stamp.stamp(deck, action, result, owner, classification)
        except (Exception, SystemExit) as e:  # noqa: BLE001
            res["errors"].append(f"version stamp: {type(e).__name__}: {e}"[:200])
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+"); ap.add_argument("--action", default="built")
    ap.add_argument("--classification"); ap.add_argument("--owner"); ap.add_argument("--no-fix", action="store_true")
    a = ap.parse_args()
    print(json.dumps(run(a.files, a.action, a.classification, a.owner, not a.no_fix), ensure_ascii=False))


if __name__ == "__main__":
    main()
