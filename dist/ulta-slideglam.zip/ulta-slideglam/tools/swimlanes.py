"""Cross-functional swimlanes, drawn natively in the Ulta template's visual language (tools/native_draw.py): blush
page, white rounded cards, lane / header labels in the theme colours in the template's order, blush / white banding,
black text, glued connectors, no shadows. Ten styles, each a different picture:

  style      use it for                                              holds (one slide)
  lanes      the classic map: who does what, in order, with decisions 2-6 lanes, 3-16 steps, ~7 side by side
  columns    the same map read top to bottom (teams head columns)    2-5 lanes, 3-14 steps, ~6 one under another
  phased     a process with named stages (phase chevrons on top)     2-6 lanes, 2-5 phases, 3-16 steps
  handoffs   where work changes hands: numbered, counted, manual ones 2-5 lanes, 3-12 steps, 1+ hand-off
  blueprint  a guest-facing service: guest / frontstage / backstage / support, with the three blueprint lines
                                                                     3-5 layers, 4-16 steps
  matrix     who is Responsible / Accountable / Consulted / Informed 2-7 teams, 3-10 activities
  sipoc      scope a process: suppliers, inputs, process, outputs, customers   3-7 steps, 1-5 entries a column
  timed      a plan over days or weeks (bars sized by duration)      2-6 lanes, 2-14 steps, 26 days / weeks
  systems    people on top, the systems they read / write below      2-4 people + 1-4 system lanes, 3-10 steps
  cards      the simplest view: each team a row of numbered cards    2-6 lanes, 6 cards a lane, 24 steps

    {"swimlane": {"lanes": ["Guest", "Store", "Finance"], "phases": ["Order", "Collect"],      (phases optional)
                  "steps": [{"id": "a", "lane": "Guest", "text": "Place order", "kind": "start"},
                            {"id": "b", "lane": "Store", "text": "In stock?", "kind": "decision", "after": "a"},
                            {"id": "c", "lane": "Store", "text": "Pick items", "after": "b", "label": "Yes"}, ...]},
     "style": "lanes", "headline": "Pickup orders: 8 steps, 4 teams, 1 stock check", "notes": "..."}

Step fields: id, lane, text (1-5 words; detail goes in the notes), after (id or [ids]; left out = the step listed
before), kind (start | task | decision | end), label (Yes / No on a branch from a decision), phase (phased),
day + duration (timed; unit "day" | "week"), system + data (1-2 words) + io ("write" | "read") (systems),
raci {"Team": "R" | "A" | "C" | "I"} (matrix; without it the step's lane is marked R), manual: true (handoffs: the
hand-off INTO this step is manual). Extras: "sipoc": {"suppliers", "inputs", "outputs", "customers": [..]} (sipoc),
"systems": [names] (systems: order of the system lanes). A flow back to an earlier step (rework) is drawn as a loop.

Contract (build_deck.py): STYLES, auto_style(data), lint(spec), draw(slide, box, spec), sample().
Layout: steps are layered in flow order (a hand-off may stay in its column when columns run short), independent steps
are re-ordered when that removes crossings, and every flow is routed orthogonally clear of every box. Connectors are
glued (ND.connect, or a glued elbow whose stored geometry runs exactly through the glue points) and use only the
shapes PowerPoint and LibreOffice draw identically: 1-3 segments; a 4-segment detour is drawn as two connectors
meeting at a small junction. Text is measured with the template's font metrics (ND.text_lines) at 12 / 10.5 / 9 pt;
whatever does not fit at 9 pt is reported by lint with the fix.
"""
from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
from pptx.enum.shapes import MSO_CONNECTOR
from pptx.util import Emu

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # run on its own (python -I too): its sibling modules
import native_draw as ND

IN = ND.IN
PT = 12700
A = ND.A
FRAME = (558105, 1531233, 11075790, ND.SAFE_BOTTOM - 1531233)   # build_deck's drawn-slide box (Ulta template): the
# slide margins, 0.2 in under the headline, down to where the template's own content ends (native_draw.SAFE_BOTTOM)

STYLES = {
    "lanes": "Classic swimlanes: a lane per team, steps left to right in order, decisions with Yes / No",
    "columns": "Vertical lanes: teams as column headers, the flow runs top to bottom",
    "phased": "Lanes x phases: each step in its team's row and its phase's column",
    "handoffs": "Hand-off view: cross-team hand-offs highlighted, numbered and counted per team pair",
    "blueprint": "Service blueprint: guest actions, frontstage, backstage, support - with the lines of interaction, "
                 "visibility and internal interaction",
    "matrix": "Responsibility matrix: activities x teams in the template's table look, R / A / C / I or owner marks",
    "sipoc": "SIPOC: suppliers, inputs, process, outputs, customers",
    "timed": "Timed lanes: steps as bars over a day / week axis, sized by duration, dependencies linked",
    "systems": "People and systems: team lanes on top, system lanes below, data flows between them",
    "cards": "Step cards: each team a row of numbered step cards - the simplest, most readable view",
}
KINDS = ("start", "task", "decision", "end")
SIZES = (ND.T_BODY, ND.T_SMALL, ND.T_MIN)          # 12, 10.5, 9 - nothing smaller
SAFE = 0.93           # preview fonts (LibreOffice) set ~5-7% wider than Circular: keep that much room spare
LEAD = 1.2            # line height as a share of the type size
MAX_WORDS = 5


# ------------------------------------------------------------------------------------------------ text measure
_MET = []


def _metrics():
    if not _MET:
        import brand as _B
        _MET.extend([_B, _B.metrics_for(_B.current())])
    return _MET


def _width(text, pt, bold=False):
    """Width of one line of text at pt (EMU), template font metrics."""
    B, M = _metrics()
    ems = B.width_of(str(text), ND.BOLD if bold else ND.BODY, M)
    return (ems if ems is not None else len(str(text)) * 0.55) * pt * PT


def _lines(text, inner_w, pt, bold=False):
    """Lines text needs in an inner width (EMU) - ND.text_lines with the preview headroom; 99 when a word is wider."""
    room = int(inner_w * SAFE)
    if any(_width(wd, pt, bold) > room for wd in str(text).split()):
        return 99
    return ND.text_lines(text, room + int(0.16 * IN), pt, bold)


def _fits(text, inner_w, inner_h, pt, bold=False, max_lines=9):
    n = _lines(text, inner_w, pt, bold)
    return n <= max_lines and n * pt * LEAD * PT <= inner_h


def _inner(prst, w, h, margin, radius=0.12):
    """The text area ND.write leaves inside a shape (preset text rectangle minus the margins), EMU. A pill's text is
    centred, so it may run into the height its rounded ends take from the text box (they only trim the width)."""
    if prst == "DIAMOND":
        tw, th = w / 2, h / 2
    elif prst == "ROUNDED_RECTANGLE":
        d = min(w, h) * (radius or 0) * 0.29289
        tw, th = w - 2 * d, (h - 0.06 * IN if (radius or 0) >= 0.45 else h - 2 * d)
    elif prst == "OVAL":
        tw, th = w * 0.7071, h * 0.7071
    else:
        tw, th = w, h
    return tw - 2 * margin * IN, th - 1.2 * margin * IN


def _balance(text, inner_w, pt, bold=False):
    """Text with explicit, balanced line breaks when it needs more than one line ('Request / new item', not
    'Request new / item'); unchanged when it fits one line or no balanced split fits."""
    words = str(text).split()
    n = _lines(text, inner_w, pt, bold)
    if n <= 1 or n > 4 or len(words) < 2 or n > len(words):
        return text
    room = inner_w * SAFE
    best = None
    for lines in _splits(words, n):
        widths = [_width(ln, pt, bold) for ln in lines]
        if max(widths) > room:
            continue
        key = (max(widths), -widths[-1])
        if best is None or key < best[0]:
            best = (key, lines)
    return "\n".join(best[1]) if best else text


def _size_for(items, sizes=SIZES):
    """Largest template size at which every (text, inner_w, inner_h, bold, max_lines) fits; None if not even 9 pt."""
    for pt in sizes:
        if all(_fits(t, w, h, pt, b, ml) for t, w, h, b, ml in items):
            return pt
    return None


def _words(t):
    return len(str(t).split())


# ------------------------------------------------------------------------------------------------- the data
def _as_list(v):
    if v is None or v == "" or v == []:
        return []
    return [v] if isinstance(v, (str, int, float)) else [x for x in v if x not in (None, "")]


def _model(data):
    """Normalised swimlane data: lanes, steps (with lane index li; None = unknown lane), edges (a, b, label)
    and the content problems, each saying how to fix it."""
    probs = []
    data = data if isinstance(data, dict) else {}
    lanes = []
    for l in _as_list(data.get("lanes")):
        l = str(l).strip()
        if l and l.lower() not in [x.lower() for x in lanes]:
            lanes.append(l)
    lane_ix = {l.lower(): i for i, l in enumerate(lanes)}
    raw = [s for s in (data.get("steps") or []) if isinstance(s, dict)]
    steps, seen = [], set()
    explicit = any(_as_list(s.get("after")) for s in raw)
    for k, s in enumerate(raw):
        sid = str(s.get("id") if s.get("id") not in (None, "") else f"s{k + 1}").strip()
        if sid in seen:
            probs.append(f"step id '{sid}' is used twice - give every step its own id")
            sid = f"{sid}~{k + 1}"
        seen.add(sid)
        lane = str(s.get("lane") or "").strip()
        kind = str(s.get("kind") or "task").strip().lower()
        if kind not in KINDS:
            probs.append(f"step '{sid}' has kind '{kind}' - use start, task, decision or end")
            kind = "task"
        text = " ".join(str(s.get("text") or "").split())
        steps.append({"id": sid, "lane": lane, "li": lane_ix.get(lane.lower()), "text": text, "kind": kind,
                      "label": " ".join(str(s.get("label") or "").split()), "after": [str(a).strip() for a in _as_list(s.get("after"))],
                      "raw": s, "k": k})
    by = {s["id"]: s for s in steps}
    for k, s in enumerate(steps):                       # "after" left out: the step listed before (a chain)
        dated = s["raw"].get("day") not in (None, "")    # a dated step stands on its own date
        if not s["after"] and k and s["kind"] != "start" and not (explicit and dated):
            prev = steps[k - 1]
            if prev["kind"] != "end":
                s["after"] = [prev["id"]]
                s["implicit"] = True
            elif explicit:
                probs.append(f"step '{s['id']}' has no 'after' and the step before it is an end - say which step it "
                             "follows (\"after\": \"<id>\") or make it kind 'start'")
    edges = []
    for s in steps:
        for a in s["after"]:
            if a not in by:
                probs.append(f"step '{s['id']}' comes after '{a}', which is not a step id - use one of: "
                             f"{', '.join(list(by)[:12])}")
                continue
            if a == s["id"]:
                probs.append(f"step '{s['id']}' comes after itself - point 'after' at the step before it")
                continue
            lab = s["label"] if by[a]["kind"] == "decision" else ""
            edges.append((a, s["id"], lab))
    m = {"lanes": lanes, "steps": steps, "by": by, "edges": edges, "problems": probs, "data": data}
    _graph(m)
    return m


def _content_lint(m, style):
    """Problems with the data itself (any style): counts, unknown lanes, ids, word limits, decisions."""
    probs = list(m["problems"])
    lanes, steps, by = m["lanes"], m["steps"], m["by"]
    if not lanes:
        probs.append("no lanes - give 'lanes': the 2-6 teams or roles that do the work, in the order to show them")
    if not steps:
        probs.append("no steps - give 'steps': [{\"id\", \"lane\", \"text\" (1-5 words), \"after\"}, ...]")
    for s in steps:
        if s["li"] is None:
            if not s["lane"]:
                probs.append(f"step '{s['id']}' has no lane - give it one of: {', '.join(lanes)}")
            else:
                probs.append(f"step '{s['id']}' is in lane '{s['lane']}', which is not in lanes ({', '.join(lanes)}) - "
                             f"add '{s['lane']}' to 'lanes' or use one of them")
        if not s["text"]:
            probs.append(f"step '{s['id']}' has no text - give it 1-5 words (verb + object: 'Approve refund')")
        elif _words(s["text"]) > MAX_WORDS:
            probs.append(f"step '{s['id']}' text '{s['text'][:40]}' is {_words(s['text'])} words - a step takes 1-5 words "
                         "(verb + object); put the detail in the speaker notes")
        if s["label"] and _words(s["label"]) > 2:
            probs.append(f"step '{s['id']}' label '{s['label']}' is {_words(s['label'])} words - a branch label is 1-2 "
                         "words (Yes / No, Approved / Rejected)")
    out = {}
    for a, b, lab in m["edges"]:
        out.setdefault(a, []).append((b, lab))
    if style not in ("matrix", "sipoc", "cards"):
        for s in steps:
            if s["kind"] == "decision":
                br = out.get(s["id"], [])
                if len(br) < 2:
                    probs.append(f"decision '{s['id']}' has {len(br)} branch{'es' if len(br) != 1 else ''} - a decision "
                                 f"needs two: steps with \"after\": \"{s['id']}\" and \"label\": \"Yes\" / \"No\" (or make it a task)")
                for b, lab in br:
                    if not lab:
                        probs.append(f"step '{b}' follows decision '{s['id']}' but has no label - add \"label\": \"Yes\" "
                                     "or \"No\" so the branch reads")
        for s in steps:
            if s["label"] and not any(by.get(a, {}).get("kind") == "decision" for a in s["after"]):
                probs.append(f"step '{s['id']}' has label '{s['label']}' but follows no decision - drop the label, or "
                             "make the step before it kind 'decision'")
    used = {s["li"] for s in steps if s["li"] is not None}
    for i, l in enumerate(lanes):
        if i not in used and style not in ("sipoc",):
            probs.append(f"lane '{l}' has no steps - drop it from 'lanes' or give it a step")
    return probs


def _graph(m):
    """Forward successors / predecessors of the drawable steps, back edges (loops) and a topological order."""
    ids = [s["id"] for s in m["steps"] if s["li"] is not None]
    ok = set(ids)
    succ = {i: [] for i in ids}
    pred = {i: [] for i in ids}
    for a, b, _ in m["edges"]:
        if a in ok and b in ok:
            succ[a].append(b)
            pred[b].append(a)
    state, back = {}, set()
    roots = [i for i in ids if not pred[i]] + ids
    for r in roots:                                   # iterative DFS in list order: an edge to the open path is a loop
        if state.get(r):
            continue
        stack = [(r, iter(succ[r]))]
        state[r] = 1
        while stack:
            u, it = stack[-1]
            v = next(it, None)
            if v is None:
                state[u] = 2
                stack.pop()
            elif state.get(v) == 1:
                back.add((u, v))
            elif not state.get(v):
                state[v] = 1
                stack.append((v, iter(succ[v])))
    fsucc = {i: [v for v in succ[i] if (i, v) not in back] for i in ids}
    fpred = {i: [u for u in pred[i] if (u, i) not in back] for i in ids}
    pos = {i: k for k, i in enumerate(ids)}
    indeg = {i: len(fpred[i]) for i in ids}
    ready = sorted([i for i in ids if not indeg[i]], key=pos.get)
    topo = []
    while ready:
        u = ready.pop(0)
        topo.append(u)
        for v in fsucc[u]:
            indeg[v] -= 1
            if not indeg[v]:
                ready.append(v)
                ready.sort(key=pos.get)
    m.update(ids=ids, succ=succ, pred=pred, fsucc=fsucc, fpred=fpred, back=back, topo=topo,
             order={i: k for k, i in enumerate(topo)})


def _reach(m):
    """{step: set of steps it leads to} over the forward edges."""
    if "_reach" not in m:
        out = {}
        for u in reversed(m["topo"]):
            r = set()
            for v in m["fsucc"][u]:
                r.add(v)
                r |= out.get(v, set())
            out[u] = r
        m["_reach"] = out
    return m["_reach"]


def _layers(m, compact=False, lane_of=None, start=None):
    """Column (slot) of every drawable step: after all its predecessors, one step per lane and column. compact: a
    hand-off to another lane may sit in the SAME column (a straight vertical flow) when nothing is in between.
    m["swap"]: pairs of independent steps placed in each other's order (the crossing search)."""
    lane_of = lane_of or (lambda i: m["by"][i]["li"])
    col, occ = {}, {}
    topo = list(m["topo"])
    for u, v in m.get("swap") or []:
        if u in topo and v in topo:
            iu, iv = topo.index(u), topo.index(v)
            topo[iu], topo[iv] = topo[iv], topo[iu]
            pos = {x: k for k, x in enumerate(topo)}
            if any(pos[a] > pos[b] for a in topo for b in m["fsucc"][a]):
                topo[iu], topo[iv] = topo[iv], topo[iu]  # would break the order of the flow: keep it
    for u in topo:
        lu = lane_of(u)
        lo, vert = (start or {}).get(u, 0), None
        for p in m["fpred"][u]:
            lp = lane_of(p)
            need = col[p] + 1
            if compact and lp != lu and len(m["fpred"][u]) == 1 and len(m["fsucc"][p]) <= 2:
                lo_l, hi_l = min(lp, lu), max(lp, lu)
                if all((l, col[p]) not in occ for l in range(lo_l + 1, hi_l)) and (lu, col[p]) not in occ:
                    need, vert = col[p], p
            lo = max(lo, need)
        c = lo
        while (lu, c) in occ:
            c += 1
        col[u] = c
        occ[(lu, c)] = u
        if vert is not None and col[vert] == c:
            lp = lane_of(vert)
            for l in range(min(lp, lu) + 1, max(lp, lu)):
                occ[(l, c)] = "|"
    return col


# --------------------------------------------------------------------------------------------- plan / execute
class _Plan:
    """Drawing operations in z-order, computed without a slide (lint dry-runs the same layout and fit checks)."""

    def __init__(self, style, box):
        self.style, self.frame = style, box
        self.ops, self.rects, self.problems = [], {}, []
        self.n = 0

    def shape(self, prst, x, y, w, h, key=None, **kw):
        self.n += 1
        key = key or f"_{self.n}"
        x, y, w, h = int(round(x)), int(round(y)), int(round(w)), int(round(h))
        self.ops.append(("shape", key, prst, x, y, w, h, kw))
        self.rects[key] = (x, y, x + w, y + h)
        return key

    def box(self, x, y, w, h, key=None, radius=0.12, **kw):
        return self.shape("ROUNDED_RECTANGLE" if radius else "RECTANGLE", x, y, w, h, key=key,
                          radius=radius if radius else None, **kw)

    def label(self, x, y, w, h, text, **kw):
        self.ops.append(("label", None, int(x), int(y), int(w), int(h), dict(kw, text=text)))

    def line(self, x1, y1, x2, y2, **kw):
        self.ops.append(("line", int(x1), int(y1), int(x2), int(y2), kw))

    def flow(self, a, a_site, b, b_site, pts, **kw):
        self.ops.append(("flow", a, a_site, b, b_site, [(int(x), int(y)) for x, y in pts], kw))

    def need(self, what, text, inner_w, inner_h, pt, bold=False, max_lines=9):
        """Record a fit problem when text does not fit its box at pt (pt is already the smallest the style allows)."""
        if not _fits(text, inner_w, inner_h, pt, bold, max_lines):
            self.problems.append(f"{what} '{str(text)[:40]}' does not fit its box at {pt:g} pt - shorten it "
                                 "(1-5 words; the detail goes in the speaker notes)")


def _execute(sl, plan, name):
    shapes, made = {}, []
    for op in plan.ops:
        if op[0] == "shape":
            _, key, prst, x, y, w, h, kw = op
            kw = dict(kw)
            dash = kw.pop("dash", None)
            wrap = kw.pop("wrap", True)
            inset_l = kw.pop("inset_l", None)
            rich = kw.pop("rich", None)
            if rich:
                for k_ in ("size", "color", "bold"):
                    kw.pop(k_, None)
                align, margin = kw.pop("align", "l"), kw.pop("margin", 0.1)
                anchor = kw.pop("anchor", "m")
            sh = ND.shape(sl, prst, x, y, w, h, **kw)
            if rich:
                ND.rich(sh, rich, align=align, anchor=anchor, margin=margin)
            if not wrap:
                sh.text_frame.word_wrap = False
            if inset_l is not None:                     # text clear of a badge drawn on the card's left
                sh.text_frame.margin_left = Emu(int(inset_l))
            if dash and kw.get("line"):
                from pptx.enum.dml import MSO_LINE_DASH_STYLE
                sh.line.dash_style = getattr(MSO_LINE_DASH_STYLE, dash)
            shapes[key] = sh
            made.append(sh)
        elif op[0] == "label":
            _, _, x, y, w, h, kw = op
            made.append(ND.label(sl, x, y, w, h, **kw))
        elif op[0] == "line":
            _, x1, y1, x2, y2, kw = op
            made.append(ND.line(sl, x1, y1, x2, y2, **kw))
        elif op[0] == "flow":
            _, a, sa, b, sb, pts, kw = op
            if a in shapes and b in shapes:
                made.append(_connector(sl, shapes[a], sa, shapes[b], sb, pts, **kw))
    return _group(sl, made, name)


def _visual_box(el):
    """(x0, y0, x1, y1) a child shape actually covers: a 90-degree turned connector's stored box is its unturned
    one, centred on the same point."""
    xf = el.find(f"{ND.P}spPr/{A}xfrm")
    if xf is None:
        xf = el.find(f"{ND.P}grpSpPr/{A}xfrm")
    if xf is None or xf.find(A + "off") is None:
        return None
    x, y = int(xf.find(A + "off").get("x")), int(xf.find(A + "off").get("y"))
    w, h = int(xf.find(A + "ext").get("cx")), int(xf.find(A + "ext").get("cy"))
    if int(xf.get("rot", "0")) % 10800000 == 5400000:
        cx, cy = x + w / 2, y + h / 2
        return int(cx - h / 2), int(cy - w / 2), int(cx + h / 2), int(cy + w / 2)
    return x, y, x + w, y + h


def _group(sl, shapes, name):
    """ND.group, with the group's frame set to what its shapes really cover (python-pptx sizes it from the stored,
    unturned boxes, which overstates a turned connector). Child and group frames stay equal: nothing moves."""
    g = ND.group(sl, shapes, name)
    if g is None or not hasattr(g, "_element") or not g._element.tag.endswith("grpSp"):
        return g
    boxes = [b for b in (_visual_box(ch) for ch in g._element if ch.tag.split("}")[-1] in ("sp", "cxnSp", "grpSp"))
             if b]
    if not boxes:
        return g
    x0, y0 = min(b[0] for b in boxes), min(b[1] for b in boxes)
    x1, y1 = max(b[2] for b in boxes), max(b[3] for b in boxes)
    xf = g._element.find(f"{ND.P}grpSpPr/{A}xfrm")
    for tag, (vx, vy) in (("off", (x0, y0)), ("chOff", (x0, y0))):
        e = xf.find(A + tag)
        e.set("x", str(vx)); e.set("y", str(vy))
    for tag in ("ext", "chExt"):
        e = xf.find(A + tag)
        e.set("cx", str(x1 - x0)); e.set("cy", str(y1 - y0))
    return g


# ---------------------------------------------------------------------------------------------- connectors
def _set_adj(c, vals):
    geom = c._element.spPr.find(A + "prstGeom")
    av = geom.find(A + "avLst")
    if av is None:
        av = etree.SubElement(geom, A + "avLst")
    for k in list(av):
        av.remove(k)
    for i, v in enumerate(vals, 1):
        etree.SubElement(av, A + "gd", name=f"adj{i}", fmla=f"val {int(round(v * 100000))}")


def _fracs(pts):
    """adj values of an orthogonal route: positions of its inner turns as shares of the end-to-end extent."""
    p0, pn = pts[0], pts[-1]
    first_h = pts[1][1] == p0[1]
    ax, bx = (0, 1) if first_h else (1, 0)              # first axis index, second axis index
    d1, d2 = pn[ax] - p0[ax], pn[bx] - p0[bx]
    f = lambda p: (p[ax] - p0[ax]) / d1 if d1 else 0.5
    g = lambda p: (p[bx] - p0[bx]) / d2 if d2 else 0.5
    n = len(pts) - 1
    if n == 3:
        return [f(pts[1])]
    if n == 4:
        return [f(pts[1]), g(pts[2])]
    return []


JUNCTION = int(0.1 * IN)


def _split(pts, size=JUNCTION):
    """A 4-segment route is drawn as two glued connectors (3 + 2 segments) meeting at a small junction on its third
    segment - glued 4-segment connectors are redrawn differently by some previews. Returns (junction centre, side the
    first part enters, side the second leaves) or None when the third segment has no room."""
    if len(pts) != 5:
        return None
    P, A2, A3 = pts[0], pts[2], pts[3]
    horiz = A2[1] == A3[1]
    ax = 0 if horiz else 1
    lo, hi = sorted((A2[ax], A3[ax]))
    if hi - lo < size + int(0.24 * IN):
        return None
    d = _sgn(A3[ax] - A2[ax])
    for t in (0.5, 0.35, 0.65, 0.25, 0.75):
        c = int(A2[ax] + (A3[ax] - A2[ax]) * t)
        if abs(c - P[ax]) < int(0.06 * IN):          # the first part needs extent along its first axis
            continue
        if min(abs(c - A2[ax]), abs(c - A3[ax])) < size // 2 + int(0.1 * IN):
            continue
        J = (c, A2[1]) if horiz else (A2[0], c)
        into = ("left" if d > 0 else "right") if horiz else ("top" if d > 0 else "bottom")
        out = ("right" if d > 0 else "left") if horiz else ("bottom" if d > 0 else "top")
        return J, into, out
    return None


def _connector(sl, a, a_site, b, b_site, pts, colour=ND.MUTED, width=1.25, dash=None, arrow=True, name="drawn flow"):
    """A connector glued a -> b along an orthogonal route of 1-4 segments; the stored geometry runs exactly through
    the route (straight = ND.connect, 3 segments = ND.connect's elbow with its turn moved onto the route)."""
    n = len(pts) - 1
    if n == 1:
        return ND.connect(sl, a, b, a_site, b_site, colour=colour, width=width, dash=dash, arrow=arrow, name=name)
    if n == 3:
        c = ND.connect(sl, a, b, a_site, b_site, colour=colour, width=width, dash=dash, arrow=arrow, elbow=True, name=name)
        _set_adj(c, _fracs(pts))
        return c
    p0, pn = pts[0], pts[-1]                           # 2 segments (bentConnector2) / 4 (bentConnector4)
    first_h = pts[1][1] == p0[1]
    dx, dy = pn[0] - p0[0], pn[1] - p0[1]
    c = sl.shapes.add_connector(MSO_CONNECTOR.ELBOW, Emu(p0[0]), Emu(p0[1]), Emu(pn[0]), Emu(pn[1]))
    c.begin_connect(a, ND.SITES[a_site])
    c.end_connect(b, ND.SITES[b_site])
    geom = c._element.spPr.find(A + "prstGeom")
    geom.set("prst", f"bentConnector{n}")
    _set_adj(c, _fracs(pts))
    xfrm = c._element.spPr.find(A + "xfrm")
    for k in ("flipH", "flipV", "rot"):
        xfrm.attrib.pop(k, None)
    W, H = (abs(dx), abs(dy)) if first_h else (abs(dy), abs(dx))
    cx, cy = (p0[0] + pn[0]) / 2, (p0[1] + pn[1]) / 2
    off, ext = xfrm.find(A + "off"), xfrm.find(A + "ext")
    off.set("x", str(int(round(cx - W / 2))))
    off.set("y", str(int(round(cy - H / 2))))
    ext.set("cx", str(int(W)))
    ext.set("cy", str(int(H)))
    if first_h:
        if dx < 0:
            xfrm.set("flipH", "1")
        if dy < 0:
            xfrm.set("flipV", "1")
    else:                                              # vertical first: the preset turned 90 degrees
        xfrm.set("rot", "5400000")
        if dy < 0:
            xfrm.set("flipH", "1")
        if dx > 0:
            xfrm.set("flipV", "1")
    ND._style_connector(c, colour, width, dash, None, "triangle" if arrow else None)
    c.name = name
    return c


# -------------------------------------------------------------------------------------------------- router
OUT = {"top": (0, -1), "bottom": (0, 1), "left": (-1, 0), "right": (1, 0)}
INTO = {"top": (0, 1), "bottom": (0, -1), "left": (1, 0), "right": (-1, 0)}


def _site(r, s):
    x0, y0, x1, y1 = r
    w, h = x1 - x0, y1 - y0
    return {"top": (x0 + w // 2, y0), "left": (x0, y0 + h // 2), "bottom": (x0 + w // 2, y1),
            "right": (x1, y0 + h // 2)}[s]


def _sgn(v):
    return (v > 0) - (v < 0)


def _hits(p, q, r, pad, rhombus=False):
    x0, y0, x1, y1 = r[0] - pad, r[1] - pad, r[2] + pad, r[3] + pad
    if rhombus:                                        # a diamond: only its rhombus blocks (corners are free)
        cx, cy, hw, hh = (r[0] + r[2]) / 2, (r[1] + r[3]) / 2, (r[2] - r[0]) / 2 + pad, (r[3] - r[1]) / 2 + pad
        if p[1] == q[1]:
            dy = abs(p[1] - cy)
            if dy >= hh:
                return False
            half = hw * (1 - dy / hh)
            return min(p[0], q[0]) < cx + half and max(p[0], q[0]) > cx - half
        dx = abs(p[0] - cx)
        if dx >= hw:
            return False
        half = hh * (1 - dx / hw)
        return min(p[1], q[1]) < cy + half and max(p[1], q[1]) > cy - half
    if p[1] == q[1]:
        return y0 < p[1] < y1 and min(p[0], q[0]) < x1 and max(p[0], q[0]) > x0
    return x0 < p[0] < x1 and min(p[1], q[1]) < y1 and max(p[1], q[1]) > y0


class _Router:
    """Orthogonal routes between glued sites: 1-4 segments (4 only as a true detour), clear of every box, preferring
    short routes with few bends, no crossings and no shared tracks with unrelated flows."""
    MIN_FIRST, MIN_LAST, MIN_SEG = int(0.07 * IN), int(0.13 * IN), int(0.05 * IN)

    def __init__(self, rects, area, xs=(), ys=(), exit_cost=None, entry_cost=None, pad=int(0.05 * IN), diamonds=(),
                 bands=None, axis=1):
        self.rects = dict(rects)
        self.area = area
        self.pad = pad
        self.diamonds = set(diamonds)
        self.bands, self.axis = bands or [], axis      # lanes along axis (1 = rows): leaving the lanes a flow joins costs
        self.lane_of = {}
        g = int(0.12 * IN)
        X, Y = set(int(v) for v in xs), set(int(v) for v in ys)
        for (x0, y0, x1, y1) in self.rects.values():
            X.update((x0 - g, x1 + g))
            Y.update((y0 - g, y1 + g))
        ax0, ay0, ax1, ay1 = area
        self.xs = sorted(v for v in X if ax0 <= v <= ax1)
        self.ys = sorted(v for v in Y if ay0 <= v <= ay1)
        self.segs = []
        self.used_out, self.used_in = {}, {}
        self.exit_cost, self.entry_cost = exit_cost or {}, entry_cost or {}

    def _cands(self, P, e, Q, n, four):
        if e == n and (P[0] == Q[0] or P[1] == Q[1]):
            yield [P, Q]
        if e[0] * n[0] + e[1] * n[1] == 0:            # perpendicular: an L, or a 4-segment detour
            yield [P, (Q[0], P[1]), Q] if e[0] else [P, (P[0], Q[1]), Q]
            if four:
                if e[0]:
                    m1s = sorted([x for x in self.xs if (x - P[0]) * e[0] > 0], key=lambda x: abs(x - P[0]))[:6]
                    for m1 in m1s:
                        for m2 in self.ys:
                            yield [P, (m1, P[1]), (m1, m2), (Q[0], m2), Q]
                else:
                    m1s = sorted([y for y in self.ys if (y - P[1]) * e[1] > 0], key=lambda y: abs(y - P[1]))[:6]
                    for m1 in m1s:
                        for m2 in self.xs:
                            yield [P, (P[0], m1), (m2, m1), (m2, Q[1]), Q]
        elif e[0] and n[0]:                            # both horizontal: H-V-H (a Z, or a U round a box)
            for m in self.xs:
                yield [P, (m, P[1]), (m, Q[1]), Q]
        elif e[1] and n[1]:
            for m in self.ys:
                yield [P, (P[0], m), (Q[0], m), Q]

    def _ok(self, pts, a, b):
        n = len(pts) - 1
        ax0, ay0, ax1, ay1 = self.area
        for p in pts[1:-1]:
            if not (ax0 <= p[0] <= ax1 and ay0 <= p[1] <= ay1):
                return False
        for i in range(n):
            p, q = pts[i], pts[i + 1]
            if p == q or (p[0] != q[0] and p[1] != q[1]):
                return False
            L = abs(q[0] - p[0]) + abs(q[1] - p[1])
            if L < (self.MIN_FIRST if i == 0 else self.MIN_LAST if i == n - 1 else self.MIN_SEG):
                return False
            if i and (pts[i - 1][0] == q[0] or pts[i - 1][1] == q[1]):      # two segments on one line
                return False
        P, Q = pts[0], pts[-1]
        if n == 3 and (P[0] == Q[0] or P[1] == Q[1]):
            return False                               # a U between equal sites: no extent for the preset's turn
        if n == 4 and _split(pts) is None:
            return False                               # drawn as 3 + 2 segments through a junction: needs a spot
        if n > 4:
            return False
        for i in range(n):
            p, q = pts[i], pts[i + 1]
            for k, r in self.rects.items():
                if k == a:
                    pad = 0 if i == 0 else self.pad
                elif k == b:
                    pad = 0 if i == n - 1 else self.pad
                else:
                    pad = self.pad
                if _hits(p, q, r, pad, k in self.diamonds):
                    return False
        return True

    def _band(self, v):
        for i, (lo, hi) in enumerate(self.bands):
            if lo <= v <= hi:
                return i
        return None

    def _outside(self, pts, a, b):
        """Lanes a route runs through that are not between its two ends' lanes (a detour through another team)."""
        if not self.bands:
            return 0
        la, lb = self._band(_site(self.rects[a], "top")[self.axis] + 1), self._band(_site(self.rects[b], "top")[self.axis] + 1)
        if la is None or lb is None:
            return 0
        lo, hi = min(la, lb), max(la, lb)
        out = set()
        for p in pts:
            k = self._band(p[self.axis])
            if k is not None and not lo <= k <= hi:
                out.add(k)
        return len(out)

    def _cost(self, pts, key):
        a, sa, b, sb = key
        c = 0.0
        for i in range(len(pts) - 1):
            p, q = pts[i], pts[i + 1]
            c += (abs(q[0] - p[0]) + abs(q[1] - p[1])) / IN
            hz = p[1] == q[1]
            for (r, s, k2, *_) in self.segs:
                related = (k2[0], k2[1]) == (a, sa) or (k2[2], k2[3]) == (b, sb)
                hz2 = r[1] == s[1]
                if hz != hz2:
                    h0, h1, v0, v1 = (p, q, r, s) if hz else (r, s, p, q)
                    if min(h0[0], h1[0]) < v0[0] < max(h0[0], h1[0]) and min(v0[1], v1[1]) < h0[1] < max(v0[1], v1[1]):
                        c += 0.5 if related else 1.8
                else:
                    ax_ = 1 if hz else 0
                    d = abs(p[ax_] - r[ax_])
                    lo = max(min(p[1 - ax_], q[1 - ax_]), min(r[1 - ax_], s[1 - ax_]))
                    hi = min(max(p[1 - ax_], q[1 - ax_]), max(r[1 - ax_], s[1 - ax_]))
                    if hi - lo > int(0.02 * IN):
                        if d < int(0.02 * IN):
                            c += 0.2 if related else 14
                        elif d < int(0.09 * IN) and not related:
                            c += 2.5
        return c + 0.35 * (len(pts) - 2) + (0.8 if len(pts) == 5 else 0)

    def score(self, a, b, sa, sb, pts, spread=None):
        """What a route costs against everything routed so far (the measure route() minimises)."""
        base = self.exit_cost.get(sa, 0) + self.entry_cost.get(sb, 0) + (spread or {}).get(sa, 0) \
            + 0.6 * self.used_in.get((b, sb), 0)
        return base + self._cost(pts, (a, sa, b, sb)) + 1.4 * self._outside(pts, a, b)

    def remove(self, eid):
        keep = []
        for seg in self.segs:
            if len(seg) > 3 and seg[3] == eid:
                continue
            keep.append(seg)
        self.segs = keep
        info = self.routes.pop(eid, None)
        if info:
            a, sa, b, sb = info
            self.used_out[(a, sa)] -= 1
            self.used_in[(b, sb)] -= 1

    def route(self, a, b, exits=None, entries=None, spread=None, eid=None):
        """(a_site, b_site, points) of the best route a -> b, or None. spread: {site: extra cost} (e.g. a decision's
        used vertices)."""
        if not hasattr(self, "routes"):
            self.routes = {}
        ra, rb = self.rects[a], self.rects[b]
        best = None
        for four in (False, True):
            for sa in exits or OUT:
                P, e = _site(ra, sa), OUT[sa]
                for sb in entries or INTO:
                    Q, n = _site(rb, sb), INTO[sb]
                    base = self.exit_cost.get(sa, 0) + self.entry_cost.get(sb, 0) + (spread or {}).get(sa, 0) \
                        + 0.6 * self.used_in.get((b, sb), 0)
                    if best and base > best[0]:
                        continue
                    for pts in self._cands(P, e, Q, n, four):
                        if (len(pts) == 5) != four:
                            continue
                        if not self._ok(pts, a, b):
                            continue
                        cst = base + self._cost(pts, (a, sa, b, sb)) + 1.4 * self._outside(pts, a, b)
                        if best is None or cst < best[0]:
                            best = (cst, sa, sb, pts)
            if best and best[0] < 6:
                break
        if best is None:
            return None
        _, sa, sb, pts = best
        self.add(a, b, sa, sb, pts, eid)
        return sa, sb, pts

    def add(self, a, b, sa, sb, pts, eid=None):
        if not hasattr(self, "routes"):
            self.routes = {}
        for i in range(len(pts) - 1):
            self.segs.append((pts[i], pts[i + 1], (a, sa, b, sb), eid))
        self.used_out[(a, sa)] = self.used_out.get((a, sa), 0) + 1
        self.used_in[(b, sb)] = self.used_in.get((b, sb), 0) + 1
        if eid is not None:
            self.routes[eid] = (a, sa, b, sb)

    def block(self, key, rect):
        self.rects[key] = rect


# ------------------------------------------------------------------------------------------ shared drawing
def _accent(i):
    return ND.accent(i)


def _on(fill):
    return ND.contrast_text(fill)


def _label_width(names, lo=1.15, hi=1.7, pt=ND.T_BODY):
    """Lane label width (EMU): room for the longest word plus padding, wider for long names (2 lines max)."""
    need = lo * IN
    for n in names:
        need = max(need, max((_width(wd, pt, True) for wd in str(n).split()), default=0) / SAFE + 0.32 * IN)
        if _width(n, pt, True) / SAFE + 0.32 * IN <= hi * IN:
            need = max(need, min(hi * IN, _width(n, pt, True) / SAFE * 0.62 + 0.32 * IN))
    return int(min(hi * IN, need))


def _lane_labels(plan, names, x, y0, lh, lw, colours=None, gap=0.06, orient="h", size=None):
    """Template lane labels (slides 15 / 16 / 19): coloured rounded rectangles, bold text, theme colours in order."""
    keys = []
    g = int(gap * IN)
    if orient == "h":
        items = [(nm, lw - 2 * 0.08 * IN, lh - 2 * g - 0.1 * IN, True, 3) for nm in names]
    else:
        items = [(nm, lh - 2 * g - 0.16 * IN, lw - 0.1 * IN, True, 2) for nm in names]
    pt = size or _size_for(items) or ND.T_MIN
    for i, nm in enumerate(names):
        fill = (colours or {}).get(i) or _accent(i)
        if orient == "h":
            k = plan.box(x, y0 + i * lh + g, lw, lh - 2 * g, radius=0.1, fill=fill, text=nm, size=pt, bold=True,
                         color=_on(fill), name="lane label")
            plan.need("lane", nm, lw - 2 * 0.08 * IN, lh - 2 * g - 0.1 * IN, pt, True, 3)
        else:
            k = plan.box(y0 + i * lh + g, x, lh - 2 * g, lw, radius=0.1, fill=fill, text=nm, size=pt, bold=True,
                         color=_on(fill), name="lane header")
            plan.need("lane", nm, lh - 2 * g - 0.16 * IN, lw - 0.1 * IN, pt, True, 2)
        keys.append(k)
    return keys, pt


DIAMOND_MARGIN = 0.02


def _step_dims(kind, d):
    """(prst, w, h, radius, margin, bold) of a step shape from the style's dims d = {task: (w, h), decision: .., pill: ..}."""
    if kind == "decision":
        w, h = d["decision"]
        return "DIAMOND", w, h, None, DIAMOND_MARGIN, True
    if kind in ("start", "end"):
        w, h = d["pill"]
        return "ROUNDED_RECTANGLE", w, h, 0.5, 0.04, True
    w, h = d["task"]
    return "ROUNDED_RECTANGLE", w, h, d.get("radius", 0.14), 0.07, False


def _splits(words, n):
    """Every way to break a word list into n non-empty lines (in order)."""
    if n == 1:
        yield [" ".join(words)]
        return
    for k in range(1, len(words) - n + 2):
        for rest in _splits(words[k:], n - 1):
            yield [" ".join(words[:k])] + rest


def _diamond_lines(text, w, h, pt, pad=0.07):
    """Lines (balanced, at most 3) that keep text at pt inside a w x h rhombus, or None. The diamond's own text box is
    only its middle half, so decisions are set unwrapped in explicit lines measured against the rhombus itself."""
    words = str(text).split()
    if not words:
        return [""]
    lh = pt * LEAD * PT
    best = None
    for n in range(1, min(3, len(words)) + 1):
        tot = n * lh
        if tot > h * 0.62:
            break
        for lines in _splits(words, n):
            ok, widest = True, 0
            for k, ln in enumerate(lines):
                top = -tot / 2 + k * lh
                dy = max(abs(top), abs(top + lh))
                allowed = w * (1 - dy / (h / 2)) - 2 * pad * IN
                wd = _width(ln, pt, True) / SAFE
                widest = max(widest, wd)
                if wd > allowed:
                    ok = False
                    break
            if ok and (best is None or (n, widest) < (len(best[1]), best[0])):
                best = (widest, lines)
        if best:
            return best[1]
    return None


def _step_size(m, ids, d, sizes=SIZES):
    """Type sizes {kind: pt} for a graphic: one for every card and pill (consistent boxes) and one for the decision
    diamonds (short bold questions) - the largest at which all of them fit; never above the cards' size."""
    items = {"card": [], "decision": []}
    for i in ids:
        s = m["by"][i]
        prst, w, h, rad, mar, bold = _step_dims(s["kind"], d)
        iw, ih = _inner(prst, w, h, mar, rad)
        items["decision" if s["kind"] == "decision" else "card"].append((s["text"], iw, ih, bold, 4))
    card = _size_for(items["card"], sizes) or sizes[-1]
    dw, dh = d["decision"]
    dec = next((p for p in sizes if p <= card and all(_diamond_lines(t, dw, dh, p) for t, *_ in items["decision"])),
               sizes[-1])
    return {"card": card, "decision": dec}


def _draw_step(plan, s, cx, cy, d, pt, colour, task_line=None, key=None, task_fill=ND.WHITE):
    """A step at centre (cx, cy): task = white card, start / end = pill in the lane colour, decision = diamond."""
    prst, w, h, rad, mar, bold = _step_dims(s["kind"], d)
    if isinstance(pt, dict):
        pt = pt["decision" if s["kind"] == "decision" else "card"]
    w, h = int(w) // 2 * 2, int(h) // 2 * 2           # even sizes on integer centres: aligned sites align exactly
    x, y = int(round(cx)) - w // 2, int(round(cy)) - h // 2
    if s["kind"] == "decision":
        lines = _diamond_lines(s["text"], w, h, pt)
        k = plan.shape("DIAMOND", x, y, w, h, key=key or s["id"], fill=ND.WHITE, line=colour, line_w=1.5,
                       text="\n".join(lines) if lines else s["text"], size=pt, bold=True, color=ND.INK, margin=0,
                       wrap=not lines, name=f"decision {s['id']}")
        if not lines:
            plan.problems.append(f"decision '{s['id']}' '{s['text'][:40]}' does not fit its diamond at {pt:g} pt - "
                                 "ask it in 1-3 short words ('In stock?', 'Approved?')")
        return k
    iw, ih = _inner(prst, w, h, mar, rad)
    if s["kind"] in ("start", "end"):
        k = plan.box(x, y, w, h, key=key or s["id"], radius=0.5, fill=colour, text=_balance(s["text"], iw, pt, True),
                     size=pt, bold=True, color=_on(colour), margin=mar, name=f"{s['kind']} {s['id']}")
    else:
        k = plan.box(x, y, w, h, key=key or s["id"], radius=rad, fill=task_fill, line=task_line or colour, line_w=1,
                     text=_balance(s["text"], iw, pt), size=pt, color=ND.INK, margin=mar, name=f"step {s['id']}")
    plan.need(f"step '{s['id']}'", s["text"], iw, ih, pt, bold, 4)
    return k


def _edge_list(m):
    """Drawable edges: forward ones by span (short first), loops last."""
    ok = set(m["ids"])
    es = [(a, b, lab) for a, b, lab in m["edges"] if a in ok and b in ok]
    return es


def _crossings(pts, R, eid):
    n = 0
    for p, q in zip(pts, pts[1:]):
        hz = p[1] == q[1]
        for (r, s_, k2, *rest) in R.segs:
            if rest and rest[0] == eid:
                continue
            if (r[1] == s_[1]) == hz:
                continue
            h0, h1, v0, v1 = (p, q, r, s_) if hz else (r, s_, p, q)
            if min(h0[0], h1[0]) < v0[0] < max(h0[0], h1[0]) and min(v0[1], v1[1]) < h0[1] < max(v0[1], v1[1]):
                n += 1
    return n


def _route_all(plan, m, R, edges, style_of, prio=None, exits_of=None, entries_of=None):
    """Route every edge with R (then re-route the ones that cross others, with everything else in place) and add the
    glued connectors to the plan; returns [(a, b, label, pts)]."""
    order = sorted(edges, key=prio) if prio else list(edges)
    res = {}

    def spread_for(a, eid):
        if m["by"][a]["kind"] != "decision":
            return None
        cnt = {}
        for e2, (a2, sa2, *_r) in res.items():
            if a2 == a and e2 != eid:
                cnt[sa2] = cnt.get(sa2, 0) + 1
        return {s_: 3.0 * c for s_, c in cnt.items()}

    for k, (a, b, lab) in enumerate(order):
        r = R.route(a, b, (exits_of or {}).get((a, b)), (entries_of or {}).get((a, b)), spread_for(a, k), eid=k)
        if r is None:
            plan.problems.append(f"the flow '{a}' -> '{b}' has no clear path between the other steps - put the two "
                                 "steps closer in the order, or use the 'cards' style")
            continue
        res[k] = (a, r[0], b, r[1], r[2])
    for _ in range(2):                                   # rip up and re-route: an early flow may now dodge a later one
        changed = False
        for k, (a, b, lab) in enumerate(order):
            if k not in res:
                continue
            a_, sa, b_, sb, pts = res[k]
            if not _crossings(pts, R, k):
                continue
            R.remove(k)
            old = R.score(a, b, sa, sb, pts, spread_for(a, k))
            r = R.route(a, b, (exits_of or {}).get((a, b)), (entries_of or {}).get((a, b)), spread_for(a, k), eid=k)
            if r is not None:
                new = R.score(a, b, r[0], r[1], r[2], spread_for(a, k))
                R.remove(k)
            if r is not None and new < old - 0.05:
                R.add(a, b, r[0], r[1], r[2], k)
                res[k] = (a, r[0], b, r[1], r[2])
                changed = True
            else:
                R.add(a, b, sa, sb, pts, k)
        if not changed:
            break
    out = []
    plan.routes = getattr(plan, "routes", []) + [res[k][4] for k in res]
    for k, (a, b, lab) in enumerate(order):
        if k not in res:
            continue
        _, sa, _, sb, pts = res[k]
        st = dict(style_of(a, b))
        if len(pts) == 5:
            J, into, leave = _split(pts)
            size = JUNCTION
            jk = plan.box(J[0] - size // 2, J[1] - size // 2, size, size, radius=0.5,
                          fill=st.get("colour", ND.MUTED), name="flow junction")
            first = pts[:3] + [_site(plan.rects[jk], into)]
            second = [_site(plan.rects[jk], leave)] + pts[3:]
            plan.flow(a, sa, jk, into, first, **dict(st, arrow=False))
            plan.flow(jk, leave, b, sb, second, **st)
            R.block(jk, plan.rects[jk])
        else:
            plan.flow(a, sa, b, sb, pts, **st)
        out.append((a, b, lab, pts))
    return out


def _in_diamond(r, d, pad=0):
    """True when rectangle r overlaps the rhombus inscribed in box d."""
    cx, cy = (d[0] + d[2]) / 2, (d[1] + d[3]) / 2
    hw, hh = (d[2] - d[0]) / 2 + pad, (d[3] - d[1]) / 2 + pad
    if r[0] >= cx + hw or r[2] <= cx - hw or r[1] >= cy + hh or r[3] <= cy - hh:
        return False
    nx = max(0, r[0] - cx, cx - r[2])                 # nearest point of r to the centre
    ny = max(0, r[1] - cy, cy - r[3])
    return nx / hw + ny / hh < 1


def _tag_rect(pts, w, h, avoid, taken, diamond=None):
    """Where a branch tag (Yes / No) sits: on the route near its start, clear of boxes and other tags (the source
    diamond counts as its rhombus, so a tag may sit in its empty corner)."""
    pad = int(0.03 * IN)
    def free(r):
        for q in list(avoid) + list(taken):
            if diamond is not None and q == diamond:
                if _in_diamond(r, q, pad):
                    return False
                continue
            if r[0] < q[2] + pad and r[2] > q[0] - pad and r[1] < q[3] + pad and r[3] > q[1] - pad:
                return False
        return True
    for i in range(len(pts) - 1):
        p, q = pts[i], pts[i + 1]
        horiz = p[1] == q[1]
        L = abs(q[0] - p[0]) + abs(q[1] - p[1])
        need = (w if horiz else h) + int(0.1 * IN)
        if L < need:
            continue
        dx, dy = _sgn(q[0] - p[0]), _sgn(q[1] - p[1])
        steps = range(int(0.05 * IN) + (w if horiz else h) // 2, L - (w if horiz else h) // 2 - int(0.04 * IN), int(0.04 * IN))
        for d in steps:
            cx, cy = p[0] + dx * d, p[1] + dy * d
            r = (cx - w // 2, cy - h // 2, cx + w // 2, cy + h // 2)
            if free(r):
                return r
    p, q = pts[0], pts[1]                              # beside the first segment, sliding from its start
    horiz = p[1] == q[1]
    L = abs(q[0] - p[0]) + abs(q[1] - p[1])
    along = _sgn(q[0] - p[0]) if horiz else _sgn(q[1] - p[1])
    for lift in (0, 1, 2, 3):
        for shift in range(-int(0.3 * IN), L + int(0.05 * IN), int(0.04 * IN)):
            for side in (-1, 1):
                if horiz:
                    cx = p[0] + along * shift
                    cy = p[1] + side * (h // 2 + int((0.04 + 0.07 * lift) * IN))
                else:
                    cx = p[0] + side * (w // 2 + int((0.05 + 0.07 * lift) * IN))
                    cy = p[1] + along * shift
                r = (cx - w // 2, cy - h // 2, cx + w // 2, cy + h // 2)
                if free(r):
                    return r
    return None


def _seg_rects(pts, pad=int(0.025 * IN)):
    return [(min(p[0], q[0]) - pad, min(p[1], q[1]) - pad, max(p[0], q[0]) + pad, max(p[1], q[1]) + pad)
            for p, q in zip(pts, pts[1:])]


def _tags(plan, routed, avoid, pt=ND.T_MIN, fill=ND.WHITE, line=ND.MUTED):
    """Branch labels as small pills on their flow (text inside its own shape), clear of the other flows."""
    taken = []
    h = int(0.22 * IN)
    for k, (a, b, lab, pts) in enumerate(routed):
        if not lab:
            continue
        w = int(_width(lab, pt, True) / SAFE + 0.2 * IN)
        others = [r for j, (*_, p2) in enumerate(routed) if j != k for r in _seg_rects(p2)]
        own = set(_seg_rects(pts))
        others = [r for r in others if r not in own]
        r = _tag_rect(pts, w, h, list(avoid) + others, taken, diamond=plan.rects.get(a))
        if r is None:
            r = _tag_rect(pts, w, h, avoid, taken, diamond=plan.rects.get(a))
        if r is None:
            plan.problems.append(f"no room for the '{lab}' label on the flow '{a}' -> '{b}' - widen the gaps (fewer steps "
                                 "in a row) or shorten the label")
            continue
        taken.append(r)
        plan.box(r[0], r[1], r[2] - r[0], r[3] - r[1], radius=0.5, fill=fill, line=line, line_w=0.75, text=lab,
                 size=pt, bold=True, color=ND.INK, margin=0.02, name="branch label")


# --------------------------------------------------------------------------------------- lane-based styles
def _cols(m, cap, compact_first=False, comfort=None):
    """Columns for the flow: plain (a new column for every step in order) unless that needs more than `comfort`
    columns (default cap) - then hand-offs to another lane stay in their column (straight down / up)."""
    col = _layers(m, compact=compact_first)
    if (max(col.values()) + 1 if col else 0) > (comfort or cap) and not compact_first:
        col2 = _layers(m, compact=True)
        if max(col2.values()) < max(col.values()):
            col = col2
    return col, (max(col.values()) + 1 if col else 1)


def _lanes_geometry(m, box, label_w=None, max_lane=1.45, right_pad=0.1):
    x, y, w, h = box
    nl = max(1, len(m["lanes"]))
    lw = label_w or _label_width(m["lanes"])
    lh = int(min(h / nl, max_lane * IN))
    return {"x": x, "y": y, "w": w, "h": h, "nl": nl, "lw": lw, "lh": lh, "band_x": x + lw - int(0.16 * IN),
            "sx0": x + lw + int(0.2 * IN), "sx1": x + w - int(right_pad * IN)}


def _flow_dims(pitch, lh, max_w=1.9, max_h=0.74, min_gap=0.38):
    """Box sizes for a slot pitch and lane height: every gap (task or diamond) keeps min_gap for flows and tags."""
    gap = min(max(pitch * 0.26, min_gap * IN), 0.6 * IN)
    bw = min(pitch - gap, max_w * IN)
    bh = min(max(lh * 0.56, min(lh - 0.3 * IN, 0.52 * IN)), max_h * IN)     # thin lanes: use more of the height
    dw = min(pitch - 0.3 * IN, bw + 0.14 * IN)
    dh = min(lh - 0.34 * IN, bh * 1.5)
    return {"task": (int(bw), int(bh)), "decision": (int(dw), int(dh)), "pill": (int(bw), int(bh))}


def _columns_x(x0, x1, ncols, wide):
    """Column centres and widths: a column holding a decision gets 30% more room (diamonds need it)."""
    wts = [1.3 if c in wide else 1.0 for c in range(ncols)]
    unit = (x1 - x0) / sum(wts)
    X, acc = [], x0
    for wt in wts:
        X.append(int(acc + unit * wt / 2))
        acc += unit * wt
    return X, unit, [unit * wt for wt in wts]


def _fit_decisions(m, ids, d, max_w, max_h=None):
    """Widen (up to max_w) and heighten (up to max_h) the decision diamonds until every question fits as large as
    the cards' text."""
    decs = [m["by"][i]["text"] for i in ids if m["by"][i]["kind"] == "decision"]
    if not decs:
        return d
    w, h = d["decision"]
    sizes = _step_size(m, [i for i in ids if m["by"][i]["kind"] != "decision"], d)
    target = sizes["card"]
    for pt in [p for p in SIZES if p <= target]:
        for hh in sorted({h, int(max_h or h)}):
            ww = w
            while ww <= max_w:
                if all(_diamond_lines(t, ww, hh, pt) for t in decs):
                    return dict(d, decision=(int(ww), int(hh)))
                ww += int(0.04 * IN)
    return dict(d, decision=(int(max(w, min(max_w, w))), int(max_h or h)))


def _gaps_between(rects, X, ids, col, k=2, step=0.07):
    """Vertical tracks in each gap between two columns, from the shapes actually there."""
    half = {}
    for i in ids:
        r = rects[i]
        half[col[i]] = max(half.get(col[i], 0), (r[2] - r[0]) / 2)
    out = []
    for c in range(len(X) - 1):
        g0, g1 = X[c] + half.get(c, 0), X[c + 1] - half.get(c + 1, 0)
        mid = (g0 + g1) / 2
        for j in range(-k, k + 1):
            v = mid + j * step * IN
            if g0 + 0.06 * IN < v < g1 - 0.06 * IN:
                out.append(int(v))
    return out


def _flow_in_lanes(plan, m, g, col, ncols, *, d=None, line_of=None, style_of=None, extra=None, sizes=SIZES,
                   task_fill=ND.WHITE, lane_y=None):
    """Steps in their lane at their column, connectors routed between them. Returns (rects, routed, pt, d, X, Y)."""
    ids = list(m["ids"])
    wide = {col[i] for i in ids if m["by"][i]["kind"] == "decision"}
    X, unit, widths = _columns_x(g["sx0"], g["sx1"], ncols, wide)
    d = d or _flow_dims(unit, g["lh"])
    if wide:
        d = _fit_decisions(m, ids, d, unit * 1.3 - 0.3 * IN, g["lh"] - 0.3 * IN)
    Y = lane_y or [int(g["y"] + g["lh"] * (i + 0.5)) for i in range(g["nl"])]
    pt = _step_size(m, ids, d, sizes)
    for i in ids:
        s = m["by"][i]
        c = _accent(s["li"])
        _draw_step(plan, s, X[col[i]], Y[s["li"]], d, pt, c, task_line=(line_of or {}).get(i) or c, task_fill=task_fill)
    rects = {i: plan.rects[i] for i in ids}
    area = (g["band_x"] + int(0.24 * IN), g["y"] + int(0.03 * IN), g["x"] + g["w"] - int(0.03 * IN),
            g["y"] + g["nl"] * g["lh"] - int(0.03 * IN))
    xs = _gaps_between(rects, X, ids, col) + [int(v) for v in X]
    ys = [int(v) for v in Y]
    for i in range(g["nl"]):
        top, bot = g["y"] + i * g["lh"], g["y"] + (i + 1) * g["lh"]
        mar = (g["lh"] - d["task"][1]) / 2
        for f in (0.3, 0.55):
            ys += [int(top + mar * f), int(bot - mar * f)]
    obstacles = dict(rects)
    obstacles.update(extra or {})
    bands = [(g["y"] + i * g["lh"], g["y"] + (i + 1) * g["lh"]) for i in range(g["nl"])]
    R = _Router(obstacles, area, xs, ys, exit_cost={"right": 0, "top": 0.35, "bottom": 0.35, "left": 1.2},
                entry_cost={"left": 0, "top": 0.3, "bottom": 0.3, "right": 1.2},
                diamonds=[i for i in ids if m["by"][i]["kind"] == "decision"], bands=bands, axis=1)
    edges = _edge_list(m)
    span = lambda e: ((e[0], e[1]) in m["back"], abs(col[e[1]] - col[e[0]]) + 0.1 * abs(m["by"][e[1]]["li"] - m["by"][e[0]]["li"]),
                      m["order"].get(e[1], 0))
    routed = _route_all(plan, m, R, edges, style_of or (lambda a, b: {}), prio=span)
    plan._router = R
    return rects, routed, pt, d, X, Y


def _p_lanes(plan, m, box):
    g = _lanes_geometry(m, box)
    cap = max(3, int((g["sx1"] - g["sx0"]) / (1.12 * IN)))
    col, ncols = _cols(m, cap, comfort=int((g["sx1"] - g["sx0"]) / (1.45 * IN)))
    if ncols > cap:
        plan.problems.append(f"the flow needs {ncols} steps side by side; the lanes style fits {cap} - merge steps, "
                             "split the process over two slides, or use the 'cards' style")
    for i in range(g["nl"]):
        plan.box(g["band_x"], g["y"] + i * g["lh"], g["x"] + g["w"] - g["band_x"], g["lh"], radius=None,
                 fill=ND.WHITE if i % 2 == 0 else ND.BLUSH, name="lane band")
    _lane_labels(plan, m["lanes"], g["x"], g["y"], g["lh"], g["lw"])
    rects, routed, pt, d, X, Y = _flow_in_lanes(plan, m, g, col, ncols)
    _tags(plan, routed, list(rects.values()))


def _bands(plan, g, fills=None):
    for i in range(g["nl"]):
        fill = (fills or {}).get(i) or (ND.WHITE if i % 2 == 0 else ND.BLUSH)
        plan.box(g["band_x"], g["y"] + i * g["lh"], g["x"] + g["w"] - g["band_x"], g["lh"], radius=None, fill=fill,
                 name="lane band")


def _cap(g, pitch=1.12):
    return max(3, int((g["sx1"] - g["sx0"]) / (pitch * IN)))


# ------------------------------------------------------------------------------------------------ handoffs
def _handoffs(m, col=None):
    """Hand-offs (flows between two teams), numbered in flow order: [(n, a, b, manual)]."""
    out = []
    es = [(a, b) for a, b, _ in _edge_list(m) if m["by"][a]["li"] != m["by"][b]["li"]]
    es.sort(key=lambda e: (m["order"].get(e[1], 0), m["order"].get(e[0], 0)))
    for n, (a, b) in enumerate(es, 1):
        out.append((n, a, b, bool(m["by"][b]["raw"].get("manual"))))
    return out


def _badge_spot(pts, d, avoid, taken):
    """Centre of a number badge on a route: the middle of its longest free stretch."""
    best = None
    pad = int(0.03 * IN)
    for i in range(len(pts) - 1):
        p, q = pts[i], pts[i + 1]
        L = abs(q[0] - p[0]) + abs(q[1] - p[1])
        if L < d + int(0.14 * IN):
            continue
        dx, dy = _sgn(q[0] - p[0]), _sgn(q[1] - p[1])
        for t in (0.5, 0.4, 0.6, 0.3, 0.7, 0.2, 0.8):
            c = (p[0] + dx * int(L * t), p[1] + dy * int(L * t))
            r = (c[0] - d // 2, c[1] - d // 2, c[0] + d // 2, c[1] + d // 2)
            if any(r[0] < q_[2] + pad and r[2] > q_[0] - pad and r[1] < q_[3] + pad and r[3] > q_[1] - pad
                   for q_ in list(avoid) + list(taken)):
                continue
            score = L * (1 - abs(t - 0.5))
            if best is None or score > best[0]:
                best = (score, r)
            break
    return best[1] if best else None


def _corner_spot(rb, ra, d, avoid, taken):
    """(1v) A number badge centred on a step's top corner: the receiving step's left, then right, then the sending
    step's; None when every corner touches another step or badge."""
    pad = int(0.03 * IN)
    for own in (rb, ra):
        if not own:
            continue
        for cx in (own[0], own[2]):
            r = (cx - d // 2, own[1] - d // 2, cx + d // 2, own[1] + d // 2)
            if any(q_ != own and r[0] < q_[2] + pad and r[2] > q_[0] - pad and r[1] < q_[3] + pad and r[3] > q_[1] - pad
                   for q_ in list(avoid) + list(taken)):
                continue
            return r
    return None


def _p_handoffs(plan, m, box):
    x, y, w, h = box
    pw = int(3.05 * IN)                                 # the side panel
    lane_box = (x, y, w - pw - int(0.25 * IN), h)
    g = _lanes_geometry(m, lane_box, right_pad=0.06)
    cap = _cap(g, 1.1)
    col, ncols = _cols(m, cap, comfort=int((g["sx1"] - g["sx0"]) / (1.4 * IN)))
    if ncols > cap:
        plan.problems.append(f"the flow needs {ncols} steps side by side; the hand-off view fits {cap} beside its panel - "
                             "merge steps or use the 'lanes' style")
    hand = _handoffs(m)
    cross = {(a, b): (n, man) for n, a, b, man in hand}
    _bands(plan, g)
    _lane_labels(plan, m["lanes"], g["x"], g["y"], g["lh"], g["lw"])

    def style_of(a, b):
        if (a, b) in cross:
            return {"colour": ND.accent(0), "width": 2.25, "dash": "DASH" if cross[(a, b)][1] else None}
        return {"colour": ND.LINE if False else ND.MUTED, "width": 1.0}
    rects, routed, pt, d, X, Y = _flow_in_lanes(plan, m, g, col, ncols, style_of=style_of,
                                                line_of={i: ND.LINE for i in m["ids"]})
    taken = []
    bd = int(0.27 * IN)
    avoid = list(rects.values())
    for a, b, lab, pts in routed:
        if (a, b) not in cross:
            continue
        n, man = cross[(a, b)]
        r = _badge_spot(pts, bd, avoid, taken)
        if r is None:                                   # (1v) on a step's corner
            r = _corner_spot(rects.get(b), rects.get(a), bd, avoid, taken)
        if r is None:
            plan.problems.append(f"no room for hand-off number {n} on the flow '{a}' -> '{b}' - fewer steps side by side")
            continue
        taken.append(r)
        plan.box(r[0], r[1], bd, bd, radius=0.5, fill=ND.accent(0), line=ND.WHITE, line_w=1.0, text=str(n),
                 size=ND.T_MIN, bold=True, color=_on(ND.accent(0)), margin=0.0, name=f"hand-off {n}")
        if man:
            mk = int(0.1 * IN)
            plan.box(r[2] - int(0.06 * IN), r[1] - int(0.03 * IN), mk, mk, radius=0.5, fill=ND.STATUS["amber"],
                     line=ND.WHITE, line_w=0.5, name="manual mark")
    _tags(plan, routed, avoid + taken)
    # side panel: total, per team pair, manual marks
    px = x + w - pw
    plan.box(px, y, pw, g["nl"] * g["lh"], radius=0.04, fill=ND.WHITE, name="hand-off panel")
    pad = int(0.2 * IN)
    teams = sorted({m["by"][a]["li"] for _, a, b, _ in hand} | {m["by"][b]["li"] for _, a, b, _ in hand})
    manual = sum(1 for *_, man in hand if man)
    plan.label(px + pad, y + int(0.14 * IN), int(0.75 * IN), int(0.62 * IN), str(len(hand)), size=36,
               font=ND.DISPLAY, color=ND.INK, align="l", anchor="m", name="hand-off total")
    lead = f"hand-offs\nbetween {len(teams)} teams"
    plan.label(px + pad + int(0.72 * IN), y + int(0.16 * IN), pw - 2 * pad - int(0.72 * IN), int(0.6 * IN), lead,
               size=ND.T_BODY, bold=True, color=ND.INK, align="l", anchor="m", name="hand-off lead")
    pairs = {}
    for n, a, b, man in hand:
        key = (m["by"][a]["li"], m["by"][b]["li"])
        pairs.setdefault(key, []).append((n, man))
    rows = sorted(pairs.items(), key=lambda kv: (-len(kv[1]), kv[1][0][0]))
    top = y + int(0.92 * IN)
    plan.line(px + pad, top - int(0.08 * IN), px + pw - pad, top - int(0.08 * IN), colour=ND.LINE, width=0.75,
              name="panel rule")
    foot = int(0.42 * IN) if manual else 0
    avail = g["nl"] * g["lh"] - (top - y) - foot - int(0.12 * IN)
    if not rows:
        return
    rh = int(min(avail / len(rows), 0.58 * IN))
    if rh < int(0.3 * IN):
        plan.problems.append(f"{len(rows)} team pairs do not fit the hand-off panel - group teams (6 pairs max)")
        rows = rows[:max(1, int(avail / (0.3 * IN)))]
        rh = int(0.3 * IN)
    names = m["lanes"]
    for k, ((la, lb), items) in enumerate(rows):
        ry = top + k * rh
        txt = f"{names[la]} → {names[lb]}"
        tw = pw - 2 * pad - int(1.0 * IN)
        tpt = _size_for([(txt, tw - 0.04 * IN, rh, True, 2)], (ND.T_SMALL, ND.T_MIN)) or ND.T_MIN
        plan.label(px + pad, ry, tw, rh, txt, size=tpt, bold=True, color=ND.INK, align="l", anchor="m", name="pair")
        plan.need("team pair", txt, tw - 0.04 * IN, rh, tpt, True, 2)
        bx = px + pw - pad - int(0.98 * IN)
        for j, (n, man) in enumerate(items[:4]):
            cx = bx + j * int(0.25 * IN)
            plan.box(cx, ry + (rh - int(0.22 * IN)) // 2, int(0.22 * IN), int(0.22 * IN), radius=0.5,
                     fill=ND.accent(0), text=str(n), size=ND.T_MIN, bold=True, color=_on(ND.accent(0)), margin=0.0,
                     name=f"pair hand-off {n}")
            if man:
                plan.box(cx + int(0.15 * IN), ry + (rh - int(0.22 * IN)) // 2 - int(0.03 * IN), int(0.09 * IN),
                         int(0.09 * IN), radius=0.5, fill=ND.STATUS["amber"], line=ND.WHITE, line_w=0.5,
                         name="manual mark")
        if k < len(rows) - 1:
            plan.line(px + pad, ry + rh, px + pw - pad, ry + rh, colour=ND.TINT, width=0.75, name="pair rule")
    if manual:
        fy = y + g["nl"] * g["lh"] - foot - int(0.06 * IN)
        plan.box(px + pad, fy + int(0.15 * IN), int(0.11 * IN), int(0.11 * IN), radius=0.5, fill=ND.STATUS["amber"],
                 name="manual legend mark")
        plan.label(px + pad + int(0.18 * IN), fy, pw - 2 * pad - int(0.18 * IN), int(0.4 * IN),
                   f"{manual} manual hand-off{'s' if manual > 1 else ''} (dashed line)",
                   size=ND.T_MIN, color=ND.INK, align="l", anchor="m", name="manual legend")


# ----------------------------------------------------------------------------------------------- blueprint
BLUEPRINT_LINES = ["Line of interaction", "Line of visibility", "Line of internal interaction", "Line of implementation"]


def _free_on_line(y, x0, x1, w, h, routed, rects, taken=(), prefer="right"):
    """x of a w-wide pill centred on the horizontal line y, clear of every flow crossing the line and every box."""
    pad = int(0.1 * IN)
    blocked = []
    for *_, pts in routed:
        for p, q in zip(pts, pts[1:]):
            if p[0] == q[0] and min(p[1], q[1]) - h / 2 <= y <= max(p[1], q[1]) + h / 2:
                blocked.append((p[0] - pad, p[0] + pad))
            if p[1] == q[1] and abs(p[1] - y) < h / 2 + pad:
                blocked.append((min(p[0], q[0]) - pad, max(p[0], q[0]) + pad))
    for r in list(rects) + list(taken):
        if r[1] < y + h / 2 + pad and r[3] > y - h / 2 - pad:
            blocked.append((r[0] - pad, r[2] + pad))
    cands = range(int(x1 - w), int(x0) - 1, -int(0.05 * IN)) if prefer == "right" else range(int(x0), int(x1 - w) + 1, int(0.05 * IN))
    for left in cands:
        if all(left + w <= b0 or left >= b1 for b0, b1 in blocked):
            return left
    return None


def _p_blueprint(plan, m, box):
    x, y, w, h = box
    g = _lanes_geometry(m, box)
    cap = _cap(g, 1.12)
    col, ncols = _cols(m, cap, compact_first=True)     # a blueprint stacks each guest moment's response under it
    if ncols > cap:
        plan.problems.append(f"the journey needs {ncols} moments side by side; a blueprint fits {cap} - merge steps or "
                             "split the journey over two slides")
    _bands(plan, g)
    _lane_labels(plan, m["lanes"], g["x"], g["y"], g["lh"], g["lw"])
    lines = []
    for i in range(1, min(g["nl"], len(BLUEPRINT_LINES) + 1)):   # the lines between the layers, dashed
        ly = g["y"] + i * g["lh"]
        lines.append((ly, BLUEPRINT_LINES[i - 1]))
        plan.line(g["band_x"], ly, g["x"] + g["w"], ly, colour=ND.MUTED, width=1.0, dash="DASH", name=BLUEPRINT_LINES[i - 1])
    rects, routed, spt, d, X, Y = _flow_in_lanes(plan, m, g, col, ncols)
    pt = ND.T_MIN
    ph = int(0.22 * IN)
    taken = []
    widths = {name: int(_width(name.upper(), pt, True) / SAFE + 0.24 * IN) for _, name in lines}
    lo_x, hi_x = g["band_x"] + int(0.3 * IN), g["x"] + g["w"] - int(0.08 * IN)
    common = None                                        # one right (or left) edge for all the names, if free on every line
    for right in range(int(hi_x), int(lo_x + max(widths.values(), default=0)), -int(0.05 * IN)):
        if all(_free_on_line(ly, right - widths[name], right, widths[name], ph, routed, rects.values()) is not None
               for ly, name in lines):
            common = ("r", right)
            break
    if common is None:
        for left_ in range(int(lo_x), int(hi_x - max(widths.values(), default=0)), int(0.05 * IN)):
            if all(_free_on_line(ly, left_, left_ + widths[name], widths[name], ph, routed, rects.values()) is not None
                   for ly, name in lines):
                common = ("l", left_)
                break
    for ly, name in lines:                               # each line's name in a pill where no flow crosses it
        label = name.upper()
        pw_ = widths[name]
        if common:
            left = common[1] - pw_ if common[0] == "r" else common[1]
        else:
            left = _free_on_line(ly, lo_x, hi_x, pw_, ph, routed, rects.values(), taken)
        if left is None:
            plan.problems.append(f"no free spot on the {name.lower()} for its name - fewer flows crossing it, or fewer "
                                 "steps side by side")
            continue
        r = (left, ly - ph // 2, left + pw_, ly + ph // 2)
        taken.append(r)
        plan.box(r[0], r[1], pw_, ph, radius=0.5, fill=ND.WHITE, line=ND.MUTED, line_w=0.75, text=label, size=pt,
                 bold=True, color=ND.MUTED, margin=0.02, name="blueprint line name")
    _tags(plan, routed, list(rects.values()) + taken)


# ------------------------------------------------------------------------------------------------- systems
def _systems_of(m):
    order = [str(v).strip() for v in _as_list(m["data"].get("systems")) if str(v).strip()]
    for s in m["steps"]:
        v = str(s["raw"].get("system") or "").strip()
        if v and v.lower() not in [o.lower() for o in order]:
            order.append(v)
    return order


def _systems_cols(m, systems):
    """Columns where no step's data line to its system runs through another step: a step that touches a system
    keeps its column below it clear (the later step moves right)."""
    start = {}
    for _ in range(40):
        col = _layers(m, start=start)
        clash = None
        for u in m["ids"]:
            if not str(m["by"][u]["raw"].get("system") or "").strip():
                continue
            for v in m["ids"]:
                if v != u and col[v] == col[u] and m["by"][v]["li"] > m["by"][u]["li"]:
                    clash = (u, v)
                    break
            if clash:
                break
        if not clash:
            return col
        u, v = clash
        late = v if m["order"][v] > m["order"][u] else u
        start[late] = col[late] + 1
    return col


def _p_systems(plan, m, box):
    x, y, w, h = box
    systems = _systems_of(m)
    people = m["lanes"]
    lw = _label_width(people + systems)
    sep = int(0.14 * IN)                                 # a little air between the people and the systems
    sh = int(min(0.5 * IN, (h - sep) / max(1, len(people) + len(systems))))
    lh = int(min((h - sep - sh * len(systems)) / max(1, len(people)), 1.3 * IN))
    g = {"x": x, "y": y, "w": w, "h": h, "nl": len(people), "lw": lw, "lh": lh, "band_x": x + lw - int(0.16 * IN),
         "sx0": x + lw + int(0.2 * IN), "sx1": x + w - int(0.1 * IN)}
    cap = _cap(g, 1.05)
    col = _systems_cols(m, systems)
    ncols = max(col.values()) + 1
    if ncols > cap:
        plan.problems.append(f"the flow needs {ncols} steps side by side; the systems view fits {cap} - merge steps or "
                             "show fewer system touchpoints")
    sys_y = y + len(people) * lh + sep
    _bands(plan, g)
    for j in range(len(systems)):
        plan.box(g["band_x"], sys_y + j * sh, x + w - g["band_x"], sh, radius=None,
                 fill=ND.TINT if j % 2 == 0 else ND.WHITE, name="system band")
    _lane_labels(plan, people, x, y, lh, lw)
    _lane_labels(plan, systems, x, sys_y, sh, lw, colours={j: ND.MUTED for j in range(len(systems))}, gap=0.04)
    wide = {col[i] for i in m["ids"] if m["by"][i]["kind"] == "decision"}
    X, unit, _ = _columns_x(g["sx0"], g["sx1"], ncols, wide)
    tps = {}
    tp_h = int(min(sh - 0.14 * IN, 0.32 * IN)) // 2 * 2
    for i in m["ids"]:
        raw = m["by"][i]["raw"]
        sysn = str(raw.get("system") or "").strip()
        if not sysn:
            continue
        j = [v.lower() for v in systems].index(sysn.lower())
        txt = " ".join(str(raw.get("data") or "Record").split())
        tps[i] = (txt, int(X[col[i]]), int(sys_y + j * sh + sh / 2), j)
    tpt = ND.T_MIN
    for pt_ in (ND.T_SMALL, ND.T_MIN):
        if all(_width(t, pt_) / SAFE + 0.26 * IN <= unit - 0.22 * IN for t, *_ in tps.values()):
            tpt = pt_
            break
    for i, (txt, cx, cy, j) in tps.items():
        tw = int(min(unit - 0.22 * IN, _width(txt, tpt) / SAFE + 0.3 * IN)) // 2 * 2
        plan.box(cx - tw // 2, cy - tp_h // 2, tw, tp_h, key=f"tp:{i}", radius=0.5, fill=ND.WHITE, line=ND.MUTED,
                 line_w=1.0, dash="DASH", text=txt, size=tpt, color=ND.INK, margin=0.04, name=f"data {txt}")
        if _width(txt, tpt) / SAFE + 0.12 * IN > tw or _words(txt) > 3:
            plan.problems.append(f"data of step '{i}' '{txt[:30]}' is too long for its touchpoint - name the data in 1-2 "
                                 "short words ('Order', 'Log-ins')")
    extra = {f"tp:{i}": plan.rects[f"tp:{i}"] for i in tps}
    rects, routed, spt, d, X, Y = _flow_in_lanes(plan, m, g, col, ncols, extra=extra)
    R = _Router({**rects, **extra}, (g["band_x"], y, x + w, sys_y + len(systems) * sh), [], [],
                exit_cost={"bottom": 0, "top": 0.2, "left": 1, "right": 1}, entry_cost={"top": 0, "bottom": 0.2})
    for i, (txt, cx, cy, j) in tps.items():             # data flows: dashed, straight down to the system (up = reads)
        io = str(m["by"][i]["raw"].get("io") or "write").lower()
        if io == "read":
            a_, b_, ex, en = f"tp:{i}", i, ["top"], ["bottom"]
        else:
            a_, b_, ex, en = i, f"tp:{i}", ["bottom"], ["top"]
        res = R.route(a_, b_, exits=ex, entries=en)
        if res is None:
            plan.problems.append(f"step '{i}' cannot reach its system '{m['by'][i]['raw'].get('system')}' in a straight "
                                 "line - fewer steps in that column")
            continue
        sa, sb, pts = res
        plan.flow(a_, sa, b_, sb, pts, colour=ND.MUTED, width=1.0, dash="DASH", arrow=True)
    _tags(plan, routed, list(rects.values()) + list(extra.values()))


# ------------------------------------------------------------------------------------------------- columns
def _p_columns(plan, m, box):
    """Vertical lanes: the teams head the columns (template header bars), the flow runs down."""
    x, y, w, h = box
    nl = max(1, len(m["lanes"]))
    hh = int(0.5 * IN)                                   # header bar height
    cw = w / nl
    top = y + hh + int(0.08 * IN)
    avail = y + h - top
    cap = max(3, int(avail / (0.62 * IN)))
    col, nrows = _cols(m, cap, comfort=max(3, int(avail / (0.85 * IN))))
    if nrows > cap:
        plan.problems.append(f"the flow needs {nrows} steps one under another; the columns style fits {cap} - merge "
                             "steps, or use the 'lanes' style (it runs left to right)")
    for i in range(nl):                                  # banded columns under coloured header bars (slides 7, 20)
        plan.box(x + i * cw, top - int(0.04 * IN), cw, y + h - top + int(0.04 * IN), radius=None,
                 fill=ND.WHITE if i % 2 == 0 else ND.BLUSH, name="lane column")
    items = [(l, cw - 0.3 * IN, hh - 0.08 * IN, True, 2) for l in m["lanes"]]
    hpt = _size_for(items) or ND.T_MIN
    for i, l in enumerate(m["lanes"]):
        fill = _accent(i)
        plan.box(x + i * cw + int(0.03 * IN), y, cw - int(0.06 * IN), hh, radius=None, fill=fill, text=l, size=hpt,
                 bold=True, color=_on(fill), name="lane header")
        plan.need("lane", l, cw - 0.3 * IN, hh - 0.08 * IN, hpt, True, 2)
    wide = {col[i] for i in m["ids"] if m["by"][i]["kind"] == "decision"}
    Yc, unit, _ = _columns_x(top, y + h - int(0.04 * IN), nrows, wide)
    Xc = [int(x + cw * (i + 0.5)) for i in range(nl)]
    bw = int(min(cw - 0.5 * IN, 1.7 * IN))
    bh = int(min(unit - 0.2 * IN, 0.62 * IN))
    dh = int(min(unit * 1.3 - 0.14 * IN, bh * 1.6))
    d = {"task": (bw, bh), "pill": (bw, bh), "decision": (int(min(cw - 0.3 * IN, bw + 0.2 * IN, dh * 1.8)), dh)}
    ids = list(m["ids"])
    if wide:
        d = _fit_decisions(m, ids, d, min(cw - 0.3 * IN, dh * 2.1), dh)
    pt = _step_size(m, ids, d)
    for i in ids:
        s_ = m["by"][i]
        _draw_step(plan, s_, Xc[s_["li"]], Yc[col[i]], d, pt, _accent(s_["li"]))
    rects = {i: plan.rects[i] for i in ids}
    area = (x + int(0.03 * IN), top, x + w - int(0.03 * IN), y + h - int(0.03 * IN))
    half = {}
    for i in ids:
        r = rects[i]
        half[col[i]] = max(half.get(col[i], 0), (r[3] - r[1]) / 2)
    ys = [int(v) for v in Yc]
    for r_ in range(nrows - 1):                          # tracks in the gaps between rows
        g0, g1 = Yc[r_] + half.get(r_, 0), Yc[r_ + 1] - half.get(r_ + 1, 0)
        for j in (-1, 0, 1):
            v = (g0 + g1) / 2 + j * 0.07 * IN
            if g0 + 0.06 * IN < v < g1 - 0.06 * IN:
                ys.append(int(v))
    xs = list(Xc)
    for i in range(nl):                                  # tracks down the sides of each column
        l0, l1 = x + i * cw, x + (i + 1) * cw
        mar = (cw - bw) / 2
        for f in (0.3, 0.55):
            xs += [int(l0 + mar * f), int(l1 - mar * f)]
    bands = [(x + i * cw, x + (i + 1) * cw) for i in range(nl)]
    R = _Router(rects, area, xs, ys, exit_cost={"bottom": 0, "left": 0.35, "right": 0.35, "top": 1.2},
                entry_cost={"top": 0, "left": 0.3, "right": 0.3, "bottom": 1.2},
                diamonds=[i for i in ids if m["by"][i]["kind"] == "decision"], bands=bands, axis=0)
    span = lambda e: ((e[0], e[1]) in m["back"], abs(col[e[1]] - col[e[0]]) + 0.1 * abs(m["by"][e[1]]["li"] - m["by"][e[0]]["li"]),
                      m["order"].get(e[1], 0))
    routed = _route_all(plan, m, R, _edge_list(m), lambda a, b: {}, prio=span)
    _tags(plan, routed, list(rects.values()))


# -------------------------------------------------------------------------------------------------- phased
def _phase_of(m):
    """Phase index of every drawable step (a step without one takes its predecessor's, else the first)."""
    phases = [str(p).strip() for p in _as_list(m["data"].get("phases")) if str(p).strip()]
    ix = {p.lower(): k for k, p in enumerate(phases)}
    ph = {}
    for i in m["topo"]:
        v = str(m["by"][i]["raw"].get("phase") or "").strip().lower()
        if v in ix:
            ph[i] = ix[v]
        else:
            ph[i] = max([ph[p] for p in m["fpred"][i] if p in ph] or [0])
    return phases, ph


def _p_phased(plan, m, box):
    x, y, w, h = box
    phases, ph = _phase_of(m)
    if not phases:
        plan.problems.append("the phased style needs 'phases': the 2-5 stages of the process, in order")
        phases = ["Process"]
    npz = len(phases)
    # columns inside each phase: the steps' order within the phase
    sub = {}
    for p in range(npz):                                 # inside a phase: in order; a hand-off to another lane may
        members = [i for i in m["topo"] if ph[i] == p]   # stay in the same column (a straight vertical flow)
        rank, occ = {}, {}
        for u in members:
            lu = m["by"][u]["li"]
            preds = [q for q in m["fpred"][u] if q in rank]
            r, vert = 0, None
            for q in preds:
                lq = m["by"][q]["li"]
                need = rank[q] + 1
                if lq != lu and len(preds) == 1 and len(m["fsucc"][q]) <= 2 and \
                        all((l, rank[q]) not in occ for l in range(min(lq, lu) + 1, max(lq, lu))) and (lu, rank[q]) not in occ:
                    need, vert = rank[q], q
                r = max(r, need)
            while (lu, r) in occ:
                r += 1
            rank[u] = r
            occ[(lu, r)] = u
            if vert is not None and rank[vert] == r:
                lq = m["by"][vert]["li"]
                for l in range(min(lq, lu) + 1, max(lq, lu)):
                    occ[(l, r)] = "|"
        sub[p] = (rank, max(rank.values()) + 1 if rank else 1)
    hh = int(0.46 * IN)                                  # phase header height
    gtop = y + hh + int(0.1 * IN)
    g = _lanes_geometry(m, (x, gtop, w, y + h - gtop))
    weights = [sub[p][1] for p in range(npz)]
    total = sum(weights)
    span_w = g["x"] + g["w"] - g["band_x"]
    cap = max(3, int((g["sx1"] - g["sx0"]) / (1.08 * IN)))
    if total > cap:
        plan.problems.append(f"the phases hold {total} steps side by side; the phased style fits {cap} - merge steps or "
                             "use fewer phases")
    # phase columns: banded, sized by how many steps sit side by side in them
    x0 = g["band_x"]
    unit = span_w / total
    edges_x = [x0]
    for wt in weights:
        edges_x.append(edges_x[-1] + unit * wt)
    for p in range(npz):
        plan.box(edges_x[p], gtop, edges_x[p + 1] - edges_x[p], g["nl"] * g["lh"], radius=None,
                 fill=ND.WHITE if p % 2 == 0 else ND.BLUSH, name="phase column")
    for i in range(1, g["nl"]):                          # thin rules between the lanes
        ly = gtop + i * g["lh"]
        plan.line(x0, ly, g["x"] + g["w"], ly, colour=ND.LINE, width=0.75, name="lane rule")
    items = [(ph_, (edges_x[p + 1] - edges_x[p]) - 0.5 * IN, hh - 0.08 * IN, True, 2) for p, ph_ in enumerate(phases)]
    hpt = _size_for(items) or ND.T_MIN
    for p, name in enumerate(phases):                     # the phase chevrons: one pipeline across the top
        prst = "PENTAGON" if p == 0 else "CHEVRON"
        x_a = edges_x[p] + (0 if p == 0 else -int(0.06 * IN))
        x_b = edges_x[p + 1] + int(0.1 * IN) if p < npz - 1 else edges_x[p + 1]
        plan.shape(prst, x_a, y, x_b - x_a, hh, fill=ND.PLUM, text=name, size=hpt, bold=True, color=_on(ND.PLUM),
                   margin=0.04, name=f"phase {name}")
        plan.need("phase", name, (edges_x[p + 1] - edges_x[p]) - 0.5 * IN, hh - 0.08 * IN, hpt, True, 2)
    _lane_labels(plan, m["lanes"], g["x"], gtop, g["lh"], g["lw"])
    col = {}
    pad_l = int(0.2 * IN)
    X = []
    for p in range(npz):
        rank, n = sub[p]
        inner0, inner1 = edges_x[p] + (pad_l if p == 0 else int(0.06 * IN)), edges_x[p + 1] - int(0.06 * IN)
        if p == 0:
            inner0 = max(inner0, g["sx0"] - int(0.1 * IN))
        step = (inner1 - inner0) / n
        base = len(X)
        X += [int(inner0 + step * (k + 0.5)) for k in range(n)]
        for u, r in rank.items():
            col[u] = base + r
    pitch = min([b - a for a, b in zip(X, X[1:])] or [unit])
    d = _flow_dims(pitch, g["lh"])
    ids = list(m["ids"])
    if any(m["by"][i]["kind"] == "decision" for i in ids):
        d = _fit_decisions(m, ids, d, pitch - 0.3 * IN, g["lh"] - 0.3 * IN)
    pt = _step_size(m, ids, d)
    Y = [int(gtop + g["lh"] * (i + 0.5)) for i in range(g["nl"])]
    for i in ids:
        s_ = m["by"][i]
        _draw_step(plan, s_, X[col[i]], Y[s_["li"]], d, pt, _accent(s_["li"]))
    rects = {i: plan.rects[i] for i in ids}
    area = (x0 + int(0.2 * IN), gtop + int(0.03 * IN), g["x"] + g["w"] - int(0.03 * IN), gtop + g["nl"] * g["lh"] - int(0.03 * IN))
    xs = _gaps_between(rects, X, ids, col) + [int(v) for v in X] + [int(v) for v in edges_x[1:-1]]
    ys = list(Y)
    for i in range(g["nl"]):
        t_, b_ = gtop + i * g["lh"], gtop + (i + 1) * g["lh"]
        mar = (g["lh"] - d["task"][1]) / 2
        for f in (0.3, 0.55):
            ys += [int(t_ + mar * f), int(b_ - mar * f)]
    bands = [(gtop + i * g["lh"], gtop + (i + 1) * g["lh"]) for i in range(g["nl"])]
    R = _Router(rects, area, xs, ys, exit_cost={"right": 0, "top": 0.35, "bottom": 0.35, "left": 1.2},
                entry_cost={"left": 0, "top": 0.3, "bottom": 0.3, "right": 1.2},
                diamonds=[i for i in ids if m["by"][i]["kind"] == "decision"], bands=bands, axis=1)
    span = lambda e: ((e[0], e[1]) in m["back"], abs(col[e[1]] - col[e[0]]), m["order"].get(e[1], 0))
    routed = _route_all(plan, m, R, _edge_list(m), lambda a, b: {}, prio=span)
    _tags(plan, routed, list(rects.values()))


# --------------------------------------------------------------------------------------------------- cards
def _numbers(m):
    """Step numbers in flow order (1..n)."""
    return {i: k + 1 for k, i in enumerate(m["topo"])}


def _badge(plan, kind, x, y, size, n, fill, pt=ND.T_SMALL):
    """A step-number badge: square for a task (template slide 25's numbered goals), diamond for a decision, round for
    a start / end."""
    if kind == "decision":
        return plan.shape("DIAMOND", x - size * 0.12, y - size * 0.12, size * 1.24, size * 1.24, fill=fill, text=str(n),
                          size=pt, bold=True, color=_on(fill), margin=0, wrap=False, name=f"step number {n}")
    return plan.box(x, y, size, size, radius=0.5 if kind in ("start", "end") else 0.12, fill=fill, text=str(n),
                    size=pt, bold=True, color=_on(fill), margin=0, name=f"step number {n}")


def _p_cards(plan, m, box):
    """Each team a row of numbered step cards (template slide 25's numbered goals): no lines to follow, the numbers
    carry the order."""
    x, y, w, h = box
    nl = max(1, len(m["lanes"]))
    num = _numbers(m)
    rows = {i: [s for s in m["topo"] if m["by"][s]["li"] == i] for i in range(nl)}
    most = max(1, max(len(v) for v in rows.values()))
    if most > 6:
        plan.problems.append(f"one team has {most} steps; a card row holds 6 - merge steps or split the process")
        most = 6
    lw = _label_width(m["lanes"])
    lh = int(min(h / nl, 1.25 * IN))
    gap = int(0.07 * IN)
    _lane_labels(plan, m["lanes"], x, y, lh, lw, gap=gap / IN)
    px0 = x + lw + int(0.12 * IN)
    pw = x + w - px0
    cg = int(0.14 * IN)
    inner = int(0.1 * IN)
    ch = int(min(lh - 2 * gap - 2 * inner, 0.8 * IN))
    sq = int(min(ch, 0.62 * IN))                         # the number square, as tall as the card
    cw = int(min((pw - 2 * inner - (most - 1) * cg) / most, 2.7 * IN))
    tw = cw - sq - int(0.2 * IN)
    items = [(m["by"][i]["text"], tw, ch - 0.08 * IN, False, 3) for i in m["ids"]]
    pt = _size_for(items) or ND.T_MIN
    npt = ND.T_SUB if sq >= int(0.5 * IN) else ND.T_CARD if sq >= int(0.36 * IN) else ND.T_SMALL
    for li in range(nl):
        ry = y + li * lh + gap
        plan.box(px0, ry, pw, lh - 2 * gap, radius=0.08, fill=ND.WARM_TINT, name="card row")
        cy = ry + (lh - 2 * gap - ch) // 2
        for k, i in enumerate(rows[li][:6]):
            s_ = m["by"][i]
            cx = px0 + inner + k * (cw + cg)
            fill = _accent(li)
            plan.box(cx, cy + (ch - sq) // 2, sq, sq, radius=None, fill=fill, text=str(num[i]), size=npt, bold=True,
                     color=_on(fill), margin=0, name=f"step number {num[i]}")
            plan.box(cx + sq, cy, cw - sq, ch, radius=None, fill=ND.WHITE, text=s_["text"], size=pt,
                     bold=s_["kind"] != "task", color=ND.INK, align="l", margin=0.1, name=f"step card {num[i]}")
            plan.need(f"step '{i}'", s_["text"], tw, ch - 0.08 * IN, pt, s_["kind"] != "task", 3)


# -------------------------------------------------------------------------------------------------- matrix
RACI = {"R": "Responsible", "A": "Accountable", "C": "Consulted", "I": "Informed"}


def _raci_of(m, i):
    raw = m["by"][i]["raw"].get("raci")
    lanes = {l.lower(): k for k, l in enumerate(m["lanes"])}
    out = {}
    if isinstance(raw, dict) and raw:
        for team, v in raw.items():
            k = lanes.get(str(team).strip().lower())
            letters = "".join(c for c in str(v).upper() if c in RACI)
            if k is not None and letters:
                out[k] = letters[:2]
    else:
        out[m["by"][i]["li"]] = "R"
    return out


def _raci_mark(plan, x, y, d, letter, pt):
    """R / A / C / I as a round mark: R and A filled (magenta, plum), C outlined, I light."""
    style = {"R": (ND.accent(0), None), "A": (ND.PLUM, None), "C": (ND.WHITE, ND.accent(0)), "I": (ND.TINT, ND.LINE)}
    fill, line = style.get(letter, (ND.WHITE, ND.MUTED))
    plan.box(x, y, d, d, radius=0.5, fill=fill, line=line, line_w=1.25, text=letter, size=pt, bold=True,
             color=_on(fill), margin=0, name=f"{RACI.get(letter, letter)} mark")


def _p_matrix(plan, m, box):
    """Responsibility matrix in the template's table look (slides 11, 12, 14): coloured team headers, banded rows."""
    x, y, w, h = box
    acts = list(m["topo"])
    teams = m["lanes"]
    nt = max(1, len(teams))
    num = _numbers(m)
    has_raci = any(isinstance(m["by"][i]["raw"].get("raci"), dict) and m["by"][i]["raw"].get("raci") for i in acts)
    leg_h = int(0.34 * IN)
    hh = int(0.52 * IN)
    tot_h = int(0.42 * IN)
    rows_h = h - hh - int(0.03 * IN) - int(0.04 * IN) - tot_h - int(0.12 * IN) - leg_h
    rh = int(min(rows_h / max(1, len(acts)), 0.56 * IN))
    if rows_h / max(1, len(acts)) < 0.3 * IN:
        plan.problems.append(f"{len(acts)} activities do not fit one matrix (10 max) - merge activities or split the slide")
    aw = int(min(4.2 * IN, max(2.6 * IN, w * 0.32)))
    cw = (w - aw) / nt
    gap = int(0.03 * IN)
    # header row: team names in the theme colours (slide 11's header bars)
    items = [(t, cw - 0.2 * IN, hh - 0.08 * IN, True, 2) for t in teams]
    hpt = _size_for(items) or ND.T_MIN
    plan.box(x, y, aw - gap, hh, radius=None, fill=ND.PLUM, text="Activity", size=hpt, bold=True, color=_on(ND.PLUM),
             align="l", margin=0.12, name="matrix header")
    for k, t in enumerate(teams):
        fill = _accent(k)
        plan.box(x + aw + k * cw, y, cw - gap, hh, radius=None, fill=fill, text=t, size=hpt, bold=True, color=_on(fill),
                 name="matrix team")
        plan.need("team", t, cw - 0.2 * IN, hh - 0.08 * IN, hpt, True, 2)
    ty = y + hh + gap
    items = [(f"{num[i]}   {m['by'][i]['text']}", aw - 0.3 * IN, rh - 0.06 * IN, False, 2) for i in acts]
    apt = _size_for(items) or ND.T_MIN
    md = int(min(rh - 0.12 * IN, 0.32 * IN)) // 2 * 2
    lead = {k: 0 for k in range(nt)}
    for r, i in enumerate(acts):
        ry = ty + r * rh
        band = ND.WHITE if r % 2 == 0 else ND.BLUSH
        plan.box(x, ry, aw - gap, rh - gap, radius=None, fill=band, text=f"{num[i]}   {m['by'][i]['text']}", size=apt,
                 color=ND.INK, align="l", margin=0.12, name="activity")
        plan.need(f"activity '{i}'", m["by"][i]["text"], aw - 0.3 * IN, rh - 0.06 * IN, apt, False, 2)
        marks = _raci_of(m, i)
        for k in range(nt):
            cx = x + aw + k * cw
            plan.box(cx, ry, cw - gap, rh - gap, radius=None, fill=band, name="matrix cell")
            letters = marks.get(k, "")
            if "R" in letters:
                lead[k] += 1
            for j, letter in enumerate(letters):
                off = (j - (len(letters) - 1) / 2) * (md + int(0.06 * IN))
                _raci_mark(plan, cx + (cw - gap) / 2 - md / 2 + off, ry + (rh - gap - md) / 2, md, letter,
                           ND.T_SMALL if md >= int(0.26 * IN) else ND.T_MIN)
    # totals: how many activities each team leads
    fy = ty + len(acts) * rh + int(0.04 * IN)
    plan.box(x, fy, aw - gap, tot_h, radius=None, fill=ND.WHITE, text="Activities each team leads (R)", size=ND.T_SMALL,
             bold=True, color=ND.INK, align="l", margin=0.12, name="matrix total label")
    for k in range(nt):
        plan.box(x + aw + k * cw, fy, cw - gap, tot_h, radius=None, fill=ND.WHITE, text=str(lead[k]), size=ND.T_BODY,
                 bold=True, color=ND.INK, name="matrix total")
    ly = fy + tot_h + int(0.12 * IN)                     # legend
    lx = x
    letters = "RACI" if has_raci else "R"
    for letter in letters:
        _raci_mark(plan, lx, ly + (leg_h - int(0.24 * IN)) // 2, int(0.24 * IN), letter, ND.T_MIN)
        word = RACI[letter] if has_raci else "Owner - does the step"
        ww = int(_width(word, ND.T_MIN) / SAFE + 0.16 * IN)
        plan.label(lx + int(0.3 * IN), ly, ww, leg_h, word, size=ND.T_MIN, color=ND.INK, align="l", anchor="m",
                   name="legend")
        lx += int(0.3 * IN) + ww + int(0.18 * IN)


# --------------------------------------------------------------------------------------------------- sipoc
SIPOC = [("suppliers", "Suppliers"), ("inputs", "Inputs"), ("process", "Process"), ("outputs", "Outputs"),
         ("customers", "Customers")]


def _sipoc_lists(m):
    raw = m["data"].get("sipoc") if isinstance(m["data"].get("sipoc"), dict) else {}
    out = {}
    for key, _ in SIPOC:
        if key == "process":
            continue
        vals = raw.get(key)
        if vals is None:
            vals = raw.get(key[:-1]) if key.endswith("s") else None
        out[key] = [" ".join(str(v).split()) for v in _as_list(vals) if str(v).strip()]
    return out


def _p_sipoc(plan, m, box):
    """SIPOC: five columns under header bars; the process column is the numbered steps, linked top to bottom."""
    x, y, w, h = box
    lists = _sipoc_lists(m)
    steps = list(m["topo"])
    num = _numbers(m)
    gap = int(0.3 * IN)                                   # room for the arrows between the columns
    wts = [1.0, 1.1, 1.45, 1.1, 1.0]
    unit = (w - 4 * gap) / sum(wts)
    xs, acc = [], x
    for wt in wts:
        xs.append((int(acc), int(unit * wt)))
        acc += unit * wt + gap
    hh = int(0.5 * IN)
    body_y = y + hh + int(0.1 * IN)
    body_h = y + h - body_y
    items = [(lab, cw - 0.2 * IN, hh - 0.08 * IN, True, 1) for (_, lab), (_, cw) in zip(SIPOC, xs)]
    hpt = _size_for(items, (ND.T_CARD, ND.T_BODY, ND.T_SMALL)) or ND.T_MIN
    for k, ((key, lab), (cx, cw)) in enumerate(zip(SIPOC, xs)):
        fill = _accent(k)
        plan.box(cx, y, cw, hh, radius=None, fill=fill, text=lab, size=hpt, bold=True, color=_on(fill), name="sipoc header")
        plan.box(cx, body_y, cw, body_h, radius=0.04, fill=ND.WHITE, name="sipoc column")
        if k < 4:                                          # template slide 10's arrow between the two columns
            ax = cx + cw + int(0.07 * IN)
            plan.shape("PENTAGON", ax, body_y + body_h // 2 - int(0.16 * IN), gap - int(0.14 * IN), int(0.32 * IN),
                       fill=ND.accent(0), name="sipoc arrow")
    pad = int(0.14 * IN)
    for k, (key, lab) in enumerate(SIPOC):
        cx, cw = xs[k]
        if key == "process":
            continue
        vals = lists.get(key, [])
        if not vals:
            plan.problems.append(f"sipoc '{key}' is empty - give 1-5 {lab.lower()} in 'sipoc': {{'{key}': [...]}}")
            continue
        if len(vals) > 5:
            plan.problems.append(f"sipoc '{key}' has {len(vals)} entries; a column holds 5 - group them")
            vals = vals[:5]
        th = int(min((body_h - 2 * pad - (len(vals) - 1) * int(0.1 * IN)) / len(vals), 0.62 * IN))
        tpt = _size_for([(v, cw - 2 * pad - 0.2 * IN, th - 0.06 * IN, False, 2) for v in vals]) or ND.T_MIN
        for j, v in enumerate(vals):
            ty = body_y + pad + j * (th + int(0.1 * IN))
            plan.box(cx + pad, ty, cw - 2 * pad, th, radius=0.18, fill=ND.BLUSH, text=v, size=tpt, color=ND.INK,
                     margin=0.08, name=f"{key} item")
            plan.need(f"sipoc {key}", v, cw - 2 * pad - 0.2 * IN, th - 0.06 * IN, tpt, False, 2)
            if _words(v) > 5:
                plan.problems.append(f"sipoc {key} '{v[:30]}' is {_words(v)} words - keep each entry to 1-5 words")
    # the process: numbered steps, top to bottom, glued arrows between them; the owner team in small type
    cx, cw = xs[2]
    n = len(steps)
    if n > 7:
        plan.problems.append(f"the process has {n} steps; a SIPOC shows 3-7 - merge steps (the swimlane styles show more)")
        steps = steps[:7]
        n = 7
    if not n:
        return
    sg = int(0.17 * IN)
    sh = int(min((body_h - 2 * pad - (n - 1) * sg) / n, 0.62 * IN))
    total = n * sh + (n - 1) * sg
    sy0 = body_y + (body_h - total) // 2
    sq = sh
    tw = cw - 2 * pad - sq - int(0.2 * IN)
    two = sh >= int(0.42 * IN)
    items = [(m["by"][i]["text"], tw, (sh * 0.62 if two else sh) - 0.04 * IN, True, 2) for i in steps]
    pt = _size_for(items) or ND.T_MIN
    prev = None
    for j, i in enumerate(steps):
        s_ = m["by"][i]
        sy = sy0 + j * (sh + sg)
        fill = _accent(s_["li"]) if s_["li"] is not None else ND.accent(0)
        plan.box(cx + pad, sy, sq, sh, radius=None, fill=fill, text=str(num[i]), size=ND.T_CARD, bold=True,
                 color=_on(fill), margin=0, name=f"step number {num[i]}")
        key = plan.box(cx + pad + sq, sy, cw - 2 * pad - sq, sh, radius=None, fill=ND.WHITE, line=ND.LINE, line_w=0.75,
                       key=i, text=s_["text"], size=pt, color=ND.INK, align="l", margin=0.1, name=f"step {num[i]}")
        if two and len(m["lanes"]) > 1:                # owner team as a second, smaller line; (1ab) one lane: none
            plan.ops[-1][7].pop("text")
            plan.ops[-1][7]["rich"] = [(s_["text"], pt, True, ND.INK, True),
                                       (m["lanes"][s_["li"]] if s_["li"] is not None else "", ND.T_MIN, False, ND.MUTED, True)]
        plan.need(f"step '{i}'", s_["text"], tw, (sh * 0.62 if two else sh) - 0.04 * IN, pt, True, 2)
        if prev is not None:
            a, b = plan.rects[prev], plan.rects[key]
            plan.flow(prev, "bottom", key, "top", [_site(a, "bottom"), _site(b, "top")], colour=ND.MUTED, width=1.25)
        prev = key


# --------------------------------------------------------------------------------------------------- timed
def _schedule(m):
    """(start, duration) per drawable step: given 'day' / 'duration', else after its predecessors."""
    st = {}
    for i in m["topo"]:
        raw = m["by"][i]["raw"]
        try:
            dur = float(raw.get("duration")) if raw.get("duration") not in (None, "") else 1.0
        except (TypeError, ValueError):
            dur = 1.0
        dur = max(0.5, dur)
        try:
            day = float(raw.get("day")) if raw.get("day") not in (None, "") else None
        except (TypeError, ValueError):
            day = None
        if day is None:
            day = max([st[p][0] + st[p][1] for p in m["fpred"][i] if p in st] or [1.0])
        st[i] = (day, dur)
    return st


def _p_timed(plan, m, box):
    """Lanes over a time axis (template slides 15 / 16): banded day or week columns, steps as bars sized by duration."""
    x, y, w, h = box
    unit = str(m["data"].get("unit") or "day").lower()
    word = "Week" if unit.startswith("w") else "Day"
    st = _schedule(m)
    first = int(min(v[0] for v in st.values())) if st else 1
    last = int(max(v[0] + v[1] for v in st.values()) - 0.001) if st else 1
    span = max(1, last - first + 1)
    if span > 26:
        plan.problems.append(f"the steps span {span} {word.lower()}s; a timed view shows 26 - use weeks, or split the plan")
    nl = max(1, len(m["lanes"]))
    lw = _label_width(m["lanes"])
    hh = int(0.34 * IN)
    gy = y + hh
    # lanes: a bar row per overlapping step (template slide 16 stacks two)
    rows = {}
    for li in range(nl):
        placed = []
        for i in sorted([i for i in m["ids"] if m["by"][i]["li"] == li], key=lambda i: st[i]):
            s0, d0 = st[i]
            r = 0
            while any(rr == r and not (s0 >= e or s0 + d0 <= b) for rr, b, e in placed):
                r += 1
            placed.append((r, s0, s0 + d0))
            rows.setdefault(li, {})[i] = r
    nrows = {li: (max(rows.get(li, {}).values()) + 1 if rows.get(li) else 1) for li in range(nl)}
    tot = sum(nrows.values())
    avail = y + h - gy
    rh = min(avail / tot, 0.75 * IN)
    lane_h = {li: rh * nrows[li] for li in range(nl)}
    band_x = x + lw - int(0.16 * IN)
    ax0, ax1 = x + lw + int(0.12 * IN), x + w
    cwid = (ax1 - ax0) / span
    for k in range(span):                                 # banded day / week columns with their labels on top
        cx = ax0 + k * cwid
        plan.box(cx, gy, cwid, sum(lane_h.values()), radius=None, fill=ND.WHITE if k % 2 == 0 else ND.BLUSH,
                 name="time column")
    plan.box(band_x, gy, ax0 - band_x, sum(lane_h.values()), radius=None, fill=ND.WHITE, name="time column")
    every = 1 if cwid >= 0.62 * IN else 2 if cwid >= 0.3 * IN else 4
    lpt = ND.T_SMALL if cwid * every >= 0.62 * IN else ND.T_MIN
    for k in range(0, span, every):
        lab = f"{word} {first + k}" if cwid * every >= 0.62 * IN else f"{word[0]}{first + k}"
        plan.label(ax0 + k * cwid, y, cwid * every if every > 1 else cwid, hh, lab, size=lpt, bold=True, color=ND.INK,
                   align="c" if every == 1 else "l", anchor="m", name="time label")
    ly = gy
    lane_y = {}
    for li in range(nl):
        lane_y[li] = ly
        ly += lane_h[li]
    for li, l in enumerate(m["lanes"]):                   # lane labels like slide 15
        fill = _accent(li)
        lhh = lane_h[li]
        g_ = int(0.06 * IN)
        lpt2 = _size_for([(l, lw - 0.16 * IN, lhh - 2 * g_ - 0.1 * IN, True, 3)]) or ND.T_MIN
        plan.box(x, lane_y[li] + g_, lw, lhh - 2 * g_, radius=0.1, fill=fill, text=l, size=lpt2, bold=True,
                 color=_on(fill), name="lane label")
    bh = int(min(max(rh * 0.6, rh - 0.24 * IN), 0.54 * IN)) // 2 * 2
    inset = int(0.04 * IN)
    items = []
    geo = {}
    for i in m["ids"]:
        s0, d0 = st[i]
        li = m["by"][i]["li"]
        bx0 = ax0 + (s0 - first) * cwid + inset
        bw = d0 * cwid - 2 * inset
        cy = lane_y[li] + rh * (rows[li][i] + 0.5)
        geo[i] = (int(bx0), int(cy - bh / 2), int(bw), bh)
        iw, ih = _inner("ROUNDED_RECTANGLE", bw, bh, 0.04, 0.5)
        items.append((m["by"][i]["text"], iw, ih, True, 2))
    pt = _size_for(items) or ND.T_MIN
    for i in m["topo"]:
        s_ = m["by"][i]
        bx0, by0, bw, bh_ = geo[i]
        fill = _accent(s_["li"])
        plan.box(bx0, by0, bw, bh_, key=i, radius=0.5, fill=fill, text=s_["text"], size=pt, bold=True, color=_on(fill),
                 margin=0.04, name=f"bar {i}")
        iw, ih = _inner("ROUNDED_RECTANGLE", bw, bh_, 0.04, 0.5)
        if not _fits(s_["text"], iw, ih, pt, True, 2):
            plan.problems.append(f"step '{i}' '{s_['text'][:30]}' does not fit its {st[i][1]:g}-{word.lower()} bar at "
                                 f"{pt:g} pt - shorten the text, lengthen the step, or show weeks instead of days")
    # finish-to-start links: glued, from the end of a bar to the start of the next
    rects = {i: plan.rects[i] for i in m["ids"]}
    area = (ax0, gy + int(0.02 * IN), ax1, ly - int(0.02 * IN))
    xs = [int(ax0 + k * cwid) for k in range(span + 1)]
    ys = []
    for li in range(nl):
        for r in range(nrows[li] + 1):
            ys.append(int(lane_y[li] + r * rh))
    R = _Router(rects, area, xs, ys, exit_cost={"right": 0, "bottom": 0.4, "top": 0.4, "left": 2},
                entry_cost={"left": 0, "top": 0.4, "bottom": 0.4, "right": 2}, pad=int(0.03 * IN))
    R.MIN_FIRST, R.MIN_LAST = int(0.04 * IN), int(0.08 * IN)
    for a, b, lab in _edge_list(m):
        if (a, b) in m["back"]:
            continue
        res = R.route(a, b)
        if res is None:
            continue                                     # overlapping in time: the bars' order says it
        sa, sb, pts = res
        if len(pts) == 5:
            continue
        plan.flow(a, sa, b, sb, pts, colour=ND.MUTED, width=1.0)


# ------------------------------------------------------------------------------------------------ contract
PLANNERS = {}


def _planner(style):
    return PLANNERS.get(style) or globals().get(f"_p_{style}")


def auto_style(data):
    """The style that fits the data's shape best."""
    data = data if isinstance(data, dict) else {}
    steps = [s for s in (data.get("steps") or []) if isinstance(s, dict)]
    if data.get("sipoc"):
        return "sipoc"
    if steps and sum(1 for s in steps if s.get("day") not in (None, "") or s.get("duration") not in (None, "")) >= len(steps) / 2:
        return "timed"
    if steps and sum(1 for s in steps if isinstance(s.get("raci"), dict) and s["raci"]) >= len(steps) / 2:
        return "matrix"
    if any(s.get("system") for s in steps):
        return "systems"
    lanes = " ".join(str(l).lower() for l in (data.get("lanes") or []))
    if data.get("blueprint") or ("frontstage" in lanes and "backstage" in lanes):
        return "blueprint"
    if data.get("phases") and sum(1 for s in steps if s.get("phase")) >= len(steps) / 2:
        return "phased"
    if any(s.get("manual") for s in steps):
        return "handoffs"
    if steps and not any(_as_list(s.get("after")) for s in steps) and not any(s.get("kind") == "decision" for s in steps) \
            and len(steps) > 10:
        return "cards"
    m = _model(data)
    if m["ids"]:
        g = _lanes_geometry(m, FRAME)
        cap = max(3, int((g["sx1"] - g["sx0"]) / (1.12 * IN)))
        if _cols(m, cap)[1] > cap:
            return "cards"
    return "lanes"


def _score(plan):
    """How clean a laid-out graphic is: crossings first, then problems, then the length of the flows."""
    routes = getattr(plan, "routes", [])
    segs = [(p, q, k) for k, pts in enumerate(routes) for p, q in zip(pts, pts[1:])]
    cross = 0
    for i, (p, q, k) in enumerate(segs):
        for (r, s_, k2) in segs[i + 1:]:
            if k == k2 or (p[1] == q[1]) == (r[1] == s_[1]):
                continue
            h0, h1, v0, v1 = (p, q, r, s_) if p[1] == q[1] else (r, s_, p, q)
            if min(h0[0], h1[0]) < v0[0] < max(h0[0], h1[0]) and min(v0[1], v1[1]) < h0[1] < max(v0[1], v1[1]):
                cross += 1
    length = sum(abs(q[0] - p[0]) + abs(q[1] - p[1]) for p, q, _ in segs) / IN
    bends = sum(max(0, len(pts) - 2) for pts in routes)
    return cross * 10 + len(plan.problems) * 25 + length * 0.2 + bends * 0.5


SWAP_STYLES = ("lanes", "columns", "handoffs", "blueprint", "systems")
_CACHE = {}


def _plan(spec, box):
    import json as _json
    try:                                                 # the picture depends on the data, the style and the box only
        key = (_json.dumps(spec.get("swimlane"), sort_keys=True, default=str), str(spec.get("style")), tuple(box))
    except Exception:
        key = None
    if key is not None and key in _CACHE:
        return _CACHE[key]
    out = _plan_once(spec, box)
    plan, m = out
    if plan.style in SWAP_STYLES and getattr(plan, "routes", None) and m["ids"]:
        base = _score(plan)
        if base >= 10:                                   # a crossing: try other orders of independent steps
            reach = _reach(m)
            cands = []
            for u in m["topo"]:
                for v in m["topo"]:
                    if m["order"][u] < m["order"][v] and m["by"][u]["li"] == m["by"][v]["li"] and \
                            v not in reach[u] and u not in reach[v] and m["order"][v] - m["order"][u] <= 4:
                        cands.append((u, v))
            best = (base, out)
            for pair in cands[:10]:
                trial = _plan_once(spec, box, swap=[pair])
                sc = _score(trial[0])
                if sc < best[0] - 0.5:
                    best = (sc, trial)
            out = best[1]
    if key is not None:
        if len(_CACHE) > 64:
            _CACHE.clear()
        _CACHE[key] = out
    return out


BOTTOM_AIR = int(0.12 * IN)     # the template's lane slides end a little above the frame (15-20 end at 6.0-6.2 in)


def _plan_once(spec, box, swap=None):
    data = spec.get("swimlane") if isinstance(spec.get("swimlane"), dict) else {}
    style = spec.get("style") or auto_style(data)
    box = (box[0], box[1], box[2], box[3] - BOTTOM_AIR)
    m = _model(data)
    if swap:
        m["swap"] = swap
    plan = _Plan(style, box)
    fn = _planner(style)
    if fn is None:
        plan.problems.append(f"swimlane style '{style}' does not exist - use one of: {', '.join(STYLES)}")
        return plan, m
    if not m["ids"] and style not in ("sipoc",):
        return plan, m
    fn(plan, m, box)
    return plan, m


def lint(spec):
    """Content problems for this style (counts, word limits, unknown lanes / ids, fit) - each says how to fix it."""
    spec = spec if isinstance(spec, dict) else {}
    data = spec.get("swimlane") if isinstance(spec.get("swimlane"), dict) else {}
    style = spec.get("style") or auto_style(data)
    if style not in STYLES:
        return [f"swimlane style '{style}' does not exist - use one of: {', '.join(STYLES)}"]
    m = _model(data)
    probs = _content_lint(m, style) + _style_lint(m, style)
    try:
        plan, _ = _plan(dict(spec, style=style), FRAME)
        probs += plan.problems
    except Exception as e:                                # never let a lint crash the build
        probs.append(f"swimlane '{style}' could not be laid out ({type(e).__name__}: {e}) - check the steps' ids and lanes")
    out = []
    for p in probs:
        if p not in out:
            out.append(p)
    return out


LIMITS = {   # style: (lanes min, lanes max, steps min, steps max) - what one slide holds legibly
    "lanes": (2, 6, 3, 16), "columns": (2, 5, 3, 14), "phased": (2, 6, 3, 16), "handoffs": (2, 5, 3, 12),
    "blueprint": (3, 5, 4, 16), "matrix": (2, 7, 3, 10), "sipoc": (1, 8, 3, 7), "timed": (2, 6, 2, 14),
    "systems": (2, 4, 3, 10), "cards": (2, 6, 3, 24)}


def _style_lint(m, style):
    """What each style needs from the data, with the fix."""
    probs = []
    lo_l, hi_l, lo_s, hi_s = LIMITS.get(style, (2, 6, 3, 16))
    nl, ns = len(m["lanes"]), len(m["steps"])
    what = {"matrix": "teams (columns)", "columns": "lanes (columns)", "blueprint": "layers"}.get(style, "lanes")
    if m["lanes"] and not lo_l <= nl <= hi_l:
        probs.append(f"{nl} {what} - the {style} style shows {lo_l}-{hi_l}; "
                     + ("group teams (e.g. one 'Stores' lane) or use the 'cards' style" if nl > hi_l else "add the teams involved"))
    if m["steps"] and not lo_s <= ns <= hi_s:
        probs.append(f"{ns} steps - the {style} style shows {lo_s}-{hi_s}; "
                     + ("merge steps or split the process over two slides (the detail goes in the notes)" if ns > hi_s
                        else "add the missing steps"))
    data = m["data"]
    if style == "phased":
        phases = [str(p).strip().lower() for p in _as_list(data.get("phases"))]
        if not 2 <= len(phases) <= 5:
            probs.append(f"the phased style needs 2-5 'phases' (stages in order) - it has {len(phases)}")
        for s_ in m["steps"]:
            ph = str(s_["raw"].get("phase") or "").strip()
            if ph and ph.lower() not in phases:
                probs.append(f"step '{s_['id']}' is in phase '{ph}', which is not in phases - use one of: "
                             f"{', '.join(str(p) for p in _as_list(data.get('phases')))}")
            elif not ph:
                probs.append(f"step '{s_['id']}' has no 'phase' - give each step one of the phases")
    if style == "matrix":
        lanes = {l.lower() for l in m["lanes"]}
        for s_ in m["steps"]:
            raci = s_["raw"].get("raci")
            if raci is None:
                continue
            if not isinstance(raci, dict):
                probs.append(f"step '{s_['id']}' raci must be {{\"Team\": \"R\"}} - one letter of R, A, C, I per team")
                continue
            for team, v in raci.items():
                if str(team).strip().lower() not in lanes:
                    probs.append(f"step '{s_['id']}' raci names team '{team}', which is not in lanes - use one of: "
                                 f"{', '.join(m['lanes'])}")
                bad = [c for c in str(v).upper() if c not in RACI and not c.isspace() and c not in ",/"]
                if bad or not str(v).strip():
                    probs.append(f"step '{s_['id']}' raci '{team}': '{v}' - use R, A, C or I")
            if not any("R" in str(v).upper() for v in raci.values()):
                probs.append(f"step '{s_['id']}' has no R - every activity needs one team Responsible")
    if style == "sipoc":
        raw = data.get("sipoc")
        if not isinstance(raw, dict):
            probs.append("the sipoc style needs 'sipoc': {\"suppliers\": [..], \"inputs\": [..], \"outputs\": [..], "
                         "\"customers\": [..]} (1-5 short entries each); the steps are the process")
    if style == "timed":
        for s_ in m["steps"]:
            for k in ("day", "duration"):
                v = s_["raw"].get(k)
                if v in (None, ""):
                    continue
                try:
                    if float(v) < (0.5 if k == "duration" else 0):
                        raise ValueError
                except (TypeError, ValueError):
                    probs.append(f"step '{s_['id']}' {k} '{v}' must be a number ({'start day / week' if k == 'day' else 'length in days / weeks'})")
        if not any(s_["raw"].get("duration") not in (None, "") for s_ in m["steps"]):
            probs.append("the timed style sizes steps by 'duration' (days or weeks, set 'unit') - give each step one")
    if style == "systems":
        if not any(str(s_["raw"].get("system") or "").strip() for s_ in m["steps"]):
            probs.append("the systems style needs steps with 'system' (and 'data': what they read or write) - or use 'lanes'")
        nsys = len(_systems_of(m))
        if nsys > 4:
            probs.append(f"{nsys} systems - the systems style shows 1-4; group them (e.g. 'Store systems')")
        for s_ in m["steps"]:
            d_ = str(s_["raw"].get("data") or "")
            if _words(d_) > 3:
                probs.append(f"step '{s_['id']}' data '{d_[:30]}' is {_words(d_)} words - name the data in 1-3 words")
    if style in ("handoffs",) and m["ids"] and not _handoffs(m):
        probs.append("no hand-offs: every flow stays in one lane - use the 'lanes' or 'cards' style")
    return probs


def draw(slide, box, spec):
    """Draw spec['swimlane'] in its style into box (x, y, w, h EMU) on a title-only slide; returns problems lint does
    not already report (empty = fine)."""
    spec = spec if isinstance(spec, dict) else {}
    data = spec.get("swimlane") if isinstance(spec.get("swimlane"), dict) else {}
    style = spec.get("style") or auto_style(data)
    try:
        plan, m = _plan(dict(spec, style=style), tuple(int(v) for v in box))
        if plan.ops:
            _execute(slide, plan, f"swimlane {style}")
        probs = list(plan.problems)
        if not plan.ops:
            probs.append(f"swimlane '{style}': nothing to draw - give lanes and steps")
    except Exception as e:
        return [f"swimlane '{style}' could not be drawn ({type(e).__name__}: {e}) - check the steps' ids, lanes and 'after'"]
    known = set(lint(dict(spec, style=style)))
    return [p for p in probs if p not in known]


# -------------------------------------------------------------------------------------------------- sample
def _st(i, lane, text, after=None, **kw):
    d = {"id": i, "lane": lane, "text": text}
    if after is not None:
        d["after"] = after
    d.update(kw)
    return d


def sample():
    """One storyboard slide per style, each with content of the shape it needs (a different picture each)."""
    S = []
    S.append({"style": "lanes", "headline": "Pickup orders: 8 steps, 4 teams, 1 stock check",
              "swimlane": {"lanes": ["Guest", "Store team", "Finance", "Customer care"], "steps": [
                  _st("a", "Guest", "Place order online", kind="start"),
                  _st("b", "Store team", "Print pick list", "a"),
                  _st("c", "Store team", "Pick items", "b"),
                  _st("d", "Store team", "All in stock?", "c", kind="decision"),
                  _st("e", "Finance", "Refund missing item", "d", label="No"),
                  _st("f", "Store team", "Stage for pickup", ["d", "e"], label="Yes"),
                  _st("g", "Customer care", "Send pickup text", "f"),
                  _st("h", "Guest", "Collect order", "g", kind="end")]},
              "notes": "Buy online, pick up in store. One stock check decides the path: a short pick is refunded by "
                       "Finance before the order is staged, so the guest still collects the same day. Hand-offs: "
                       "guest to store, store to finance and back, store to customer care, customer care to guest."})
    S.append({"style": "columns", "headline": "Store returns resolve in 8 steps; 1 policy check",
              "swimlane": {"lanes": ["Guest", "Store", "Returns centre", "Finance"], "steps": [
                  _st("a", "Guest", "Bring item back", kind="start"),
                  _st("b", "Store", "Check receipt", "a"),
                  _st("c", "Store", "Within 60 days?", "b", kind="decision"),
                  _st("d", "Store", "Offer store credit", "c", label="No"),
                  _st("e", "Store", "Scan return", "c", label="Yes"),
                  _st("f", "Returns centre", "Grade item", "e"),
                  _st("g", "Finance", "Refund card", "e"),
                  _st("h", "Guest", "Leave with refund", ["g", "d"], kind="end")]},
              "notes": "The 60-day policy check is the only decision. Inside the window the return is scanned, graded "
                       "by the returns centre and refunded to the card; outside it the store offers store credit."})
    S.append({"style": "phased", "headline": "New items pass 4 phases; 1 approval gates launch",
              "swimlane": {"lanes": ["Merchant", "Vendor", "Item data team", "Supply chain"],
                           "phases": ["Request", "Build", "Approve", "Launch"], "steps": [
                  _st("a", "Merchant", "Request new item", kind="start", phase="Request"),
                  _st("b", "Vendor", "Submit item data", "a", phase="Request"),
                  _st("c", "Item data team", "Build item record", "b", phase="Build"),
                  _st("d", "Item data team", "Add images", "c", phase="Build"),
                  _st("e", "Merchant", "Approve item?", "d", kind="decision", phase="Approve"),
                  _st("f", "Vendor", "Resubmit item", "e", label="No", kind="end", phase="Approve"),
                  _st("g", "Supply chain", "Set up replenishment", "e", label="Yes", phase="Launch"),
                  _st("h", "Merchant", "Launch item", "g", kind="end", phase="Launch")]},
              "notes": "New item setup in four phases. The merchant's approval is the gate: a rejected item goes back "
                       "to the vendor, who fixes the data and resubmits it; an approved item gets replenishment set up "
                       "before launch."})
    S.append({"style": "handoffs", "headline": "POS outages: 5 hand-offs, 2 still manual",
              "swimlane": {"lanes": ["Store", "Service desk", "IT operations", "Field tech"], "steps": [
                  _st("a", "Store", "Report POS outage", kind="start"),
                  _st("b", "Service desk", "Log ticket", "a", manual=True),
                  _st("c", "Service desk", "Fix remotely?", "b", kind="decision"),
                  _st("d", "Service desk", "Guide fix by phone", "c", label="Yes"),
                  _st("e", "IT operations", "Diagnose device", "c", label="No"),
                  _st("f", "Field tech", "Replace device", "e", manual=True),
                  _st("g", "Store", "Confirm POS works", ["d", "f"], kind="end")]},
              "notes": "Incident handling for a store POS outage. Two hand-offs are still manual: the store phones the "
                       "service desk, and IT operations books the field tech by e-mail. Both are candidates for "
                       "automation (self-service ticket, dispatch from the ticket)."})
    S.append({"style": "blueprint", "headline": "A salon visit has 5 guest moments, 4 unseen steps",
              "swimlane": {"lanes": ["Guest actions", "Frontstage", "Backstage", "Support systems"], "steps": [
                  _st("g1", "Guest actions", "Book online", kind="start"),
                  _st("s1", "Support systems", "Hold time slot", "g1"),
                  _st("b1", "Backstage", "Confirm stylist", "s1"),
                  _st("g2", "Guest actions", "Arrive at salon", "b1"),
                  _st("f1", "Frontstage", "Greet and consult", "g2"),
                  _st("g3", "Guest actions", "Choose service", "f1"),
                  _st("f2", "Frontstage", "Cut and style", "g3"),
                  _st("b2", "Backstage", "Mix color", "g3"),
                  _st("g4", "Guest actions", "Pay and rebook", "f2"),
                  _st("f3", "Frontstage", "Take payment", "g4"),
                  _st("s2", "Support systems", "Add loyalty points", "f3"),
                  _st("g5", "Guest actions", "Leave review", "f3", kind="end")]},
              "notes": "Service blueprint of a salon appointment. Guest moments sit above the line of interaction; the "
                       "stylist's frontstage work above the line of visibility; the salon desk and systems below it. "
                       "The four unseen steps (slot hold, stylist confirmation, colour mixing, loyalty points) are "
                       "where most delays start."})
    S.append({"style": "matrix", "headline": "8 promo tasks: no team leads more than 2",
              "swimlane": {"lanes": ["Marketing", "Merchandising", "Pricing", "Stores", "Digital"], "steps": [
                  _st("a", "Merchandising", "Choose promo items", raci={"Merchandising": "R", "Marketing": "C", "Pricing": "C"}),
                  _st("b", "Pricing", "Set promo prices", "a", raci={"Pricing": "R", "Merchandising": "A"}),
                  _st("c", "Marketing", "Build creative", "a", raci={"Marketing": "R", "Digital": "C", "Merchandising": "I"}),
                  _st("d", "Digital", "Load site offers", ["b", "c"], raci={"Digital": "R", "Pricing": "C", "Marketing": "A"}),
                  _st("e", "Stores", "Set store signage", "c", raci={"Stores": "R", "Marketing": "C"}),
                  _st("f", "Stores", "Brief store teams", "e", raci={"Stores": "R", "Merchandising": "I"}),
                  _st("g", "Marketing", "Launch promo", ["d", "f"], raci={"Marketing": "R", "Digital": "C", "Stores": "I"}),
                  _st("h", "Merchandising", "Track sell-through", "g", raci={"Merchandising": "R", "Pricing": "I", "Marketing": "I"})]},
              "notes": "Who does what in a promotion launch: R responsible, A accountable, C consulted, I informed. "
                       "Merchandising, Stores and Marketing each lead two activities; Pricing and Digital one each."})
    S.append({"style": "sipoc", "headline": "Invoices become payments in 5 steps, 4 teams",
              "swimlane": {"lanes": ["Vendor", "Accounts payable", "Buyer", "Treasury"],
                           "sipoc": {"suppliers": ["Vendors", "Buyers", "Receiving dock"],
                                     "inputs": ["Invoice", "Purchase order", "Goods receipt"],
                                     "outputs": ["Approved invoice", "Vendor payment", "Audit trail"],
                                     "customers": ["Vendors", "Finance", "Auditors"]}, "steps": [
                  _st("a", "Vendor", "Send invoice", kind="start"),
                  _st("b", "Accounts payable", "Match PO and receipt", "a"),
                  _st("c", "Buyer", "Approve exceptions", "b"),
                  _st("d", "Accounts payable", "Post invoice", "c"),
                  _st("e", "Treasury", "Pay on terms", "d", kind="end")]},
              "notes": "Invoice approval as SIPOC. Three-way match (invoice, purchase order, goods receipt) runs in "
                       "accounts payable; buyers only see exceptions. Treasury pays on the agreed terms."})
    S.append({"style": "timed", "headline": "A new store opens in 12 weeks across 6 teams",
              "swimlane": {"lanes": ["Real estate", "Construction", "IT", "HR", "Store team", "Marketing"], "unit": "week",
                           "steps": [
                  _st("a", "Real estate", "Sign lease", day=1, duration=2),
                  _st("b", "Construction", "Build out store", "a", duration=6),
                  _st("c", "IT", "Install POS", "b", duration=2),
                  _st("d", "HR", "Hire store team", day=5, duration=4),
                  _st("e", "Store team", "Train team", "d", duration=2),
                  _st("f", "Store team", "Stock shelves", ["c", "e"], duration=1),
                  _st("g", "Marketing", "Local launch", day=9, duration=3),
                  _st("h", "Store team", "Open doors", "f", duration=1)]},
              "notes": "Store opening plan by week. Build-out (6 weeks) is the critical path; hiring starts in week 5 so "
                       "the team is trained when the POS is in. Marketing runs the local launch in weeks 9-11."})
    S.append({"style": "systems", "headline": "Onboarding: 6 of 8 steps write to 3 systems",
              "swimlane": {"lanes": ["Recruiter", "Hiring manager", "New hire", "IT support"],
                           "systems": ["HR system", "Identity and access", "Learning portal"], "steps": [
                  _st("a", "Recruiter", "Send offer", kind="start", system="HR system", data="Offer"),
                  _st("b", "New hire", "Sign offer", "a", system="HR system", data="E-signature"),
                  _st("c", "Recruiter", "Create hire record", "b", system="HR system", data="Record"),
                  _st("d", "IT support", "Create accounts", "c", system="Identity and access", data="Log-ins"),
                  _st("e", "Hiring manager", "Assign training", "c", system="Learning portal", data="Plan"),
                  _st("f", "New hire", "Complete day one", ["d", "e"]),
                  _st("g", "New hire", "Finish training", "f", system="Learning portal", data="Completion"),
                  _st("h", "Hiring manager", "Confirm ready", "g", kind="end")]},
              "notes": "Employee onboarding: people on top, the systems they write to below (dashed: data flows). "
                       "The HR system is touched three times; one shared record would remove two re-keying steps."})
    S.append({"style": "cards", "headline": "New vendors: 9 steps, 4 teams, 1 approval gate",
              "swimlane": {"lanes": ["Merchant", "Vendor", "Compliance", "Finance"], "steps": [
                  _st("a", "Merchant", "Nominate vendor", kind="start"),
                  _st("b", "Vendor", "Complete profile", "a"),
                  _st("c", "Vendor", "Upload tax forms", "b"),
                  _st("d", "Compliance", "Screen vendor", "c"),
                  _st("e", "Compliance", "Approve vendor?", "d", kind="decision"),
                  _st("f", "Finance", "Add bank details", "e", label="Yes"),
                  _st("g", "Finance", "Set payment terms", "f"),
                  _st("h", "Merchant", "Place first order", "g"),
                  _st("i", "Vendor", "Confirm order", "h", kind="end")]},
              "notes": "Vendor onboarding, read by number: each team's row shows what it owns. Compliance approval "
                       "(step 5) is the gate; a rejected vendor stops there."})
    return S


if __name__ == "__main__":
    print(__doc__)
