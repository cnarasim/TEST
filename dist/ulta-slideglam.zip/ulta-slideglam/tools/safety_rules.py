"""The promises in SKILL.md's "How this skill works" section, checked against the skill's own files.

    python tools/safety_rules.py        PASS / FAIL per rule, with the file and line of anything that breaks one; exit 1

  1. No network access - no Python module that opens connections; pages load nothing from another address (no remote
     script, style sheet, font, picture or frame; no XMLHttpRequest, WebSocket, sendBeacon or EventSource; fetch only
     of the page's own file).
  2. Only its own programs - no shell (shell=True, os.system, os.popen, os.exec*, os.spawn*, pty); tools/job.py runs
     only the skill's own tools.
  3. Pages change nothing in the browser - no script replaces a browser function or a property of the browser's own
     objects (print, open, fetch, prototypes, navigator, document).
  4. Honest records - no code writes another application's name into a file's properties, and nothing clears a file's
     description.
  5. No internal addresses - no SharePoint, Atlassian, intranet host or private network address in the skill's own text
     (code, instructions, page templates, sample records), and no one's own folder (a /Users/<name> or C:\\Users\\<name>
     path, a OneDrive-<organisation> folder). The approved Office templates are kept byte for byte, links included.
  6. Publishing only on request - SKILL.md, its guides and the site tool say a page goes on a ChatGPT Site only when the
     user asks or says yes; no wording publishes by default.
  7. The description says what the skill does - it names every kind of deliverable the skill makes.
"""
import ast, re, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
sys.path.insert(0, str(TOOLS))
SELF = Path(__file__).resolve()
TEXT = (".py", ".md", ".js", ".html", ".htm", ".css", ".json", ".txt", ".svg", ".drawio", ".xml", ".yaml", ".yml", ".csv")
PAGES = (".html", ".htm", ".js", ".css", ".svg")

NET_MODULES = ("socket", "http.client", "http.server", "urllib.request", "urllib3", "requests", "httpx", "aiohttp",
               "ftplib", "smtplib", "poplib", "imaplib", "telnetlib", "xmlrpc.client", "websocket", "websockets", "paramiko")
NET_CALLS = ("urlopen", "urlretrieve", "create_connection", "HTTPConnection", "HTTPSConnection")
REMOTE = re.compile(r"<(?:script|img|iframe|frame|embed|source|audio|video)\b[^>]*\bsrc\s*=\s*[\"']?(?:https?:)?//"
                    r"|<link\b[^>]*\bhref\s*=\s*[\"']?(?:https?:)?//|@import\s+(?:url\()?[\"']?(?:https?:)?//"
                    r"|url\(\s*[\"']?(?:https?:)?//|new\s+XMLHttpRequest|new\s+WebSocket|sendBeacon\s*\(|new\s+EventSource", re.I)
FETCH = re.compile(r"\bfetch\s*\(\s*(?!location\.href)")
SHELL_CALLS = {("os", "system"), ("os", "popen"), ("pty", "spawn"), ("subprocess", "getoutput"), ("subprocess", "getstatusoutput")}
OVERRIDE = re.compile(r"\b(?:window\.)(?:print|open|fetch|alert|confirm|prompt|close|postMessage)\s*=(?!=)"
                      r"|\b(?:HTMLElement|HTMLAnchorElement|HTMLFormElement|Element|Node|EventTarget|Document|Window|Location|History|"
                      r"Storage|Navigator|XMLHttpRequest|Function|Object|Array|String|Promise)\.prototype\.\w+\s*=(?!=)"
                      r"|\bnavigator\.\w+\s*=(?!=)|\bdocument\.(?:write|open|domain)\s*=(?!=)"
                      r"|Object\.defineProperty\(\s*(?:window|document|navigator|location|\w+\.prototype)\b")
APP_LITERAL = re.compile(r"<Application>\s*[A-Za-z]|[\"']Application[\"']\s*:\s*[\"']Microsoft|<dc:description>\s*</dc:description>"
                         r"|<dc:description/>")
HOSTS = re.compile(r"[\w.-]+\.sharepoint\.com|[\w.-]+\.atlassian\.net|\b(?:10\.\d{1,3}|192\.168|172\.(?:1[6-9]|2\d|3[01]))\.\d{1,3}\.\d{1,3}\b"
                   r"|https?://[^/\s\"'<>]+\.(?:corp|intranet|internal|local|lan)\b"
                   r"|/Users/[\w.-]+/|\b[A-Z]:\\{1,2}Users\\{1,2}[\w.-]+|OneDrive-[\w]+", re.I)
DEFAULT_PUBLISH = re.compile(r"unless the user says no|publish(?:es|ed)? (?:it |the page )?(?:automatically|by default)|always publish"
                             r"|auto-?publish", re.I)
CAPABILITIES = {"decks": ("deck", "powerpoint"), "infographics and one-pagers": ("infographic", "one-pager"),   # ULTA SlideGlam
                "diagrams": ("diagram",), "process flows": ("process flow", "swimlane"), "the process library": ("library",)}


def files(exts):
    return sorted(p for p in ROOT.rglob("*") if p.is_file() and p.suffix.lower() in exts and p != SELF
                  and "__pycache__" not in p.parts)


def where(p, text, i):
    return f"{p.relative_to(ROOT)}:{text.count(chr(10), 0, i) + 1}"


def python_trees():
    for p in files((".py",)):
        try:
            yield p, ast.parse(p.read_text(encoding="utf-8", errors="ignore"))
        except SyntaxError as e:
            yield p, e


def no_network():
    bad = []
    for p, tree in python_trees():
        if isinstance(tree, SyntaxError):
            bad.append(f"{p.relative_to(ROOT)}: not readable as Python ({tree.msg})"); continue
        for n in ast.walk(tree):
            names = [a.name for a in n.names] if isinstance(n, ast.Import) else \
                    [f"{n.module}.{a.name}" for a in n.names] + [n.module] if isinstance(n, ast.ImportFrom) and n.module else []
            for name in names:
                if any(name == m or name.startswith(m + ".") for m in NET_MODULES):
                    bad.append(f"{p.relative_to(ROOT)}:{n.lineno}: imports {name}")
            if isinstance(n, ast.Call):
                f = n.func
                nm = f.attr if isinstance(f, ast.Attribute) else f.id if isinstance(f, ast.Name) else ""
                if nm in NET_CALLS:
                    bad.append(f"{p.relative_to(ROOT)}:{n.lineno}: calls {nm}")
    for p in files(PAGES):
        t = p.read_text(encoding="utf-8", errors="ignore")
        for rx in (REMOTE, FETCH):
            for m in rx.finditer(t):
                bad.append(f"{where(p, t, m.start())}: {m.group(0)[:60]!r}")
    return bad


def own_programs():
    bad = []
    for p, tree in python_trees():
        if isinstance(tree, SyntaxError):
            continue
        for n in ast.walk(tree):
            if not isinstance(n, ast.Call):
                continue
            for k in n.keywords:
                if k.arg == "shell" and isinstance(k.value, ast.Constant) and k.value.value:
                    bad.append(f"{p.relative_to(ROOT)}:{n.lineno}: shell=True")
            f = n.func
            if isinstance(f, ast.Attribute) and isinstance(f.value, ast.Name):
                if (f.value.id, f.attr) in SHELL_CALLS or (f.value.id == "os" and f.attr.startswith(("exec", "spawn"))):
                    bad.append(f"{p.relative_to(ROOT)}:{n.lineno}: {f.value.id}.{f.attr}")
    try:
        import job
        tool = str(TOOLS / "build_deck.py")
        refused = [c for c in (["sh", "-c", "echo"], ["python", "-c", "print(1)"], ["python", "/etc/passwd"],
                               ["python", str(TOOLS / "job.py"), "wait", "x"]) if job.own_tool(c)]
        if refused or not job.own_tool(["python", tool, "--help"]):
            bad.append(f"tools/job.py: own_tool accepts {refused[0] if refused else 'nothing'} - it must run the skill's own tools and nothing else")
    except Exception as e:
        bad.append(f"tools/job.py: could not be checked ({type(e).__name__}: {e})")
    return bad


def pages_change_nothing():
    bad = []
    for p in files(PAGES):
        t = p.read_text(encoding="utf-8", errors="ignore")
        for m in OVERRIDE.finditer(t):
            bad.append(f"{where(p, t, m.start())}: {m.group(0)[:60]!r}")
    return bad


def honest_records():
    bad = []
    for p in files((".py",)):
        t = p.read_text(encoding="utf-8", errors="ignore")
        for m in APP_LITERAL.finditer(t):
            bad.append(f"{where(p, t, m.start())}: {m.group(0)[:60]!r}")
    return bad


def no_internal_addresses():
    bad = []
    for p in files(TEXT):
        t = p.read_text(encoding="utf-8", errors="ignore")
        for m in HOSTS.finditer(t):
            bad.append(f"{where(p, t, m.start())}: {m.group(0)[:60]!r}")
    return bad


def publish_on_request():
    bad = []
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    if not (TOOLS / "site.py").exists():                # ULTA SlideGlam publishes nothing: no page may say it publishes by default
        for name, t in [("SKILL.md", skill)] + [(f"guides/{g.name}", g.read_text(encoding="utf-8")) for g in sorted((ROOT / "guides").glob("*.md"))]:
            for m in DEFAULT_PUBLISH.finditer(t):
                bad.append(f"{name}:{t.count(chr(10), 0, m.start()) + 1}: {m.group(0)!r}")
        return bad
    site = (TOOLS / "site.py").read_text(encoding="utf-8")
    docs = [("SKILL.md", skill)] + [(f"guides/{g.name}", g.read_text(encoding="utf-8")) for g in sorted((ROOT / "guides").glob("*.md"))]
    if not re.search(r"publish only when (?:they|the user) ask", skill):
        bad.append("SKILL.md: does not say a page is published only when the user asks")
    if "only because the user asked" not in site:
        bad.append("tools/site.py: its publishing steps do not say they run only because the user asked")
    for name, t in docs + [("tools/site.py", site)]:
        for m in DEFAULT_PUBLISH.finditer(t):
            bad.append(f"{name}:{t.count(chr(10), 0, m.start()) + 1}: {m.group(0)!r}")
    return bad


def description_says_what_it_does():
    skill = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    m = re.search(r"^description:\s*(.+)$", skill, re.M)
    desc = (m.group(1) if m else "").lower()
    return [f"SKILL.md description: does not mention {k}" for k, words in CAPABILITIES.items()
            if not any(w in desc for w in words)]


RULES = (("No network access", no_network), ("Only its own programs", own_programs),
         ("Pages change nothing in the browser", pages_change_nothing), ("Honest records", honest_records),
         ("No internal addresses", no_internal_addresses), ("Publishing only on request", publish_on_request),
         ("The description says what the skill does", description_says_what_it_does))


def check():
    """[(rule, [problems])] - an empty list of problems means the rule is kept."""
    return [(name, fn()) for name, fn in RULES]


def main():
    res = check()
    for i, (name, bad) in enumerate(res, 1):
        print(f"{'PASS' if not bad else 'FAIL'}  {i}. {name}" + "".join(f"\n      - {b}" for b in bad[:8])
              + (f"\n      ... and {len(bad) - 8} more" if len(bad) > 8 else ""))
    kept = sum(1 for _, bad in res if not bad)
    print(f"SAFETY RULES {kept}/{len(res)} kept")
    sys.exit(0 if kept == len(res) else 1)


if __name__ == "__main__":
    main()
