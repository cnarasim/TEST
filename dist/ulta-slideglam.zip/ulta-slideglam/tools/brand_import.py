"""Register a new PowerPoint template as a brand profile. Decks, diagrams and infographics then follow its colours,
fonts, master, logo and layouts automatically.

    python tools/brand_import.py New_Template.pptx --name acme [--fonts <dir with .ttf/.otf>] [--logo logo.svg] [--use]

Reads from the template itself:
  - theme colours (accent1-6, dk/lt) and theme fonts; the fonts actually used for headlines and body text
  - the palette the slides use (brand colours, tints, neutrals)
  - slide roles: sample-headline text, cover, closing, a title-only slide for diagrams, a step-flow slide (if any)
  - font metrics for the fit checker (from --fonts files; otherwise a similar bundled font, flagged approximate)
  - the logo (largest picture on the cover or master) unless --logo is given
Writes brands/<name>/ (template.pptx, brand.json, metrics.json, logo, CATALOG.md) to /mnt/data/brands when it
exists (the skill folder is read-only in the sandbox), else to the skill's brands/. Prints what it found: CHECK the roles.
Make it permanent: copy the brands/<name> folder into the skill's brands/ folder and re-upload the skill.
"""
import argparse, collections, hashlib, json, re, shutil, sys, zipfile
from pathlib import Path

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import brand as B   # noqa: E402

NS = {"p": "http://schemas.openxmlformats.org/presentationml/2006/main",
      "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
A = "{%s}" % NS["a"]
NEVER = "\x00no-sample-headline"


def rels(z, part):
    rp = part.rsplit("/", 1)
    path = f"{rp[0]}/_rels/{rp[1]}.rels"
    if path not in z.namelist():
        return {}
    out = {}
    for r in etree.fromstring(z.read(path)):
        t = r.get("Target")
        if r.get("TargetMode") == "External":
            continue
        full = t.lstrip("/") if t.startswith("/") else str(Path(rp[0], t)).replace("\\", "/")
        parts = []
        for seg in full.split("/"):
            if seg == "..":
                parts.pop()
            elif seg and seg != ".":
                parts.append(seg)
        out[r.get("Id")] = ("/".join(parts), r.get("Type").rsplit("/", 1)[-1])
    return out


def slides(z):
    pres = etree.fromstring(z.read("ppt/presentation.xml"))
    pr = rels(z, "ppt/presentation.xml")
    return [pr[s.get("{%s}id" % NS["r"])][0] for s in pres.find("p:sldIdLst", NS)]


def theme(z):
    master = sorted(n for n in z.namelist() if re.match(r"ppt/slideMasters/slideMaster\d+\.xml$", n))[0]
    th = next(t for t, k in rels(z, master).values() if k == "theme")
    x = etree.fromstring(z.read(th))
    cs = x.find(".//a:clrScheme", NS)
    colours = {}
    for el in cs:
        c = el.find("a:srgbClr", NS)
        s = el.find("a:sysClr", NS)
        colours[etree.QName(el).localname] = (c.get("val") if c is not None else (s.get("lastClr") if s is not None else "000000")).upper()
    fonts = {k: x.find(f".//a:fontScheme/a:{k}/a:latin", NS).get("typeface") for k in ("majorFont", "minorFont")}
    return colours, fonts, master


def text_of(el):
    return "".join(t.text or "" for t in el.iter(A + "t")).strip()


def ph_type(sp):
    ph = sp.find(".//p:nvPr/p:ph", NS)
    return None if ph is None else (ph.get("type") or "body")


def run_fonts(el, theme_fonts):
    out = []
    for r in el.iter(A + "r"):
        rpr = r.find(A + "rPr")
        lat = rpr.find(A + "latin") if rpr is not None else None
        tf = lat.get("typeface") if lat is not None else None
        if tf and tf.startswith("+mj"):
            tf = theme_fonts["majorFont"]
        elif tf and tf.startswith("+mn"):
            tf = theme_fonts["minorFont"]
        out.append((tf, rpr is not None and rpr.get("b") == "1", len(r.findtext(A + "t") or "")))
    return out


def analyse(path):
    z = zipfile.ZipFile(path)
    colours, tfonts, master = theme(z)
    sl = slides(z)
    title_texts, head_fonts, body_fonts, used = collections.Counter(), collections.Counter(), collections.Counter(), collections.Counter()
    info = []
    for i, part in enumerate(sl, 1):
        x = etree.fromstring(z.read(part))
        tree = x.find(".//p:cSld/p:spTree", NS)
        shapes = list(tree)
        titles = [sp for sp in shapes if ph_type(sp) is not None and text_of(sp) and len(text_of(sp)) <= 60
                  and not text_of(sp).isdigit()]
        for sp in titles:
            title_texts[text_of(sp)] += 1
        def phkey(sp):
            ph = sp.find(".//p:nvPr/p:ph", NS)
            return f"@ph:{ph.get('type') or 'body'}:{ph.get('idx') or ''}"
        ph_keys = {phkey(sp): sp for sp in titles if ph_type(sp) not in ("sldNum", "ftr", "dt")}
        for sp in shapes:
            if ph_type(sp) in ("title", "ctrTitle"):
                continue
            for f, bold, n in run_fonts(sp, tfonts):
                if f:
                    body_fonts[(f, bold)] += n
        for c in re.findall(rb'srgbClr val="([0-9A-Fa-f]{6})"', z.read(part)):
            used[c.decode().upper()] += 1
        tbl = [sp for sp in shapes if sp.find(".//a:tbl", NS) is not None]
        sizes = collections.Counter()
        for sp in shapes:
            g, e = sp.find("p:spPr/a:prstGeom", NS), sp.find("p:spPr/a:xfrm/a:ext", NS)
            if g is not None and e is not None and g.get("prst") in ("rect", "roundRect") and ph_type(sp) is None:
                sizes[(e.get("cx"), e.get("cy"))] += 1
        boxes = [None] * (sizes.most_common(1)[0][1] if sizes else 0)          # boxes of one repeated size
        info.append({"slide": i, "part": part, "shapes": len(shapes), "titles": [text_of(t) for t in titles],
                     "head_el": {**{text_of(t): t for t in titles}, **ph_keys},
                     "ph_keys": set(ph_keys),
                     "tables": [(sp.find(".//p:cNvPr", NS).get("name"), len(sp.findall(".//a:tr", NS)),
                                 len(sp.findall(".//a:gridCol", NS))) for sp in tbl],
                     "boxes": boxes, "text": [text_of(sp)[:40] for sp in shapes if text_of(sp)][:6]})
    return z, colours, tfonts, master, sl, title_texts, head_fonts, body_fonts, used, info


def inherited_font(z, part, sp, tfonts):
    """Font the template DESIGNS for a placeholder: its layout placeholder (same idx/type), else the master style,
    else what the slide's own runs say (slides sometimes override it with a default font)."""
    own = [f for f, _, _ in run_fonts(sp, tfonts) if f]
    ph = sp.find(".//p:nvPr/p:ph", NS)
    lay = next((t for t, k in rels(z, part).values() if k == "slideLayout"), None)
    def latin_in(el):
        for lat in el.iter(A + "latin"):
            tf = lat.get("typeface")
            if tf:
                return tfonts["majorFont"] if tf.startswith("+mj") else tfonts["minorFont"] if tf.startswith("+mn") else tf
        return None
    if lay:
        lx = etree.fromstring(z.read(lay))
        for lsp in lx.iter("{%s}sp" % NS["p"]):
            lph = lsp.find(".//p:nvPr/p:ph", NS)
            if lph is not None and (lph.get("idx") == ph.get("idx") and ph.get("idx") or
                                    (lph.get("type") == ph.get("type") and ph.get("type"))):
                f = latin_in(lsp)
                if f:
                    return f
        master = next((t for t, k in rels(z, lay).values() if k == "slideMaster"), None)
        if master:
            mx = etree.fromstring(z.read(master))
            style = mx.find(".//p:txStyles/p:" + ("titleStyle" if ph.get("type") in ("title", "ctrTitle") else "bodyStyle"), NS)
            if style is not None:
                f = latin_in(style)
                if f:
                    return f
    return own[0] if own else tfonts["majorFont"]


def find_logo(z, master, sl):
    cands = []
    holders = sorted(n for n in z.namelist() if re.match(r"ppt/(slideMasters/slideMaster|slideLayouts/slideLayout)\d+\.xml$", n))
    uses = collections.Counter()
    for part in [sl[0]] + holders:
        x = etree.fromstring(z.read(part))
        rl = rels(z, part)
        for pic in x.iter("{%s}pic" % NS["p"]):
            blip = pic.find(".//a:blip", NS)
            ext = pic.find(".//a:xfrm/a:ext", NS)
            if blip is None or ext is None:
                continue
            rid = blip.get("{%s}embed" % NS["r"])
            for el in blip.iter():
                if etree.QName(el).localname == "svgBlip":
                    rid = el.get("{%s}embed" % NS["r"]) or rid
            if rid in rl:
                w, h = int(ext.get("cx")), int(ext.get("cy"))
                if w > 1.5 * h:                     # logos are wide; skip photos and square art
                    media = rl[rid][0]
                    cols = re.findall(rb"#([0-9A-Fa-f]{6})", z.read(media)) if media.endswith(".svg") else []
                    light = bool(cols) and all(B.lch(c.decode().upper())[0] > 90 for c in cols)
                    uses[media] += 1
                    cands.append((0 if light else 1, w * h, media))   # a white (reversed) logo is the last choice
    best = max(cands, key=lambda c: (c[0], uses[c[2]], c[1])) if cands else None     # coloured, most used, largest
    return best[2] if best else None


def metrics_from_file(path):
    from fontTools.ttLib import TTFont
    from fontTools.pens.boundsPen import BoundsPen
    f = TTFont(str(path))
    upm = f["head"].unitsPerEm
    hh = f["hhea"]
    cmap = f.getBestCmap()
    gs = f.getGlyphSet()
    hm = f["hmtx"]
    adv, ink = {}, {}
    for cp in list(range(0x20, 0x250)) + [0x2013, 0x2014, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2026, 0x20AC, 0x2192]:
        g = cmap.get(cp)
        if not g:
            continue
        ch = chr(cp)
        a = hm[g][0] / upm
        adv[ch] = round(a, 4)
        bp = BoundsPen(gs)
        gs[g].draw(bp)
        b = bp.bounds or (0, 0, 0, 0)
        ink[ch] = [round(b[0] / upm, 3), round(-b[3] / upm, 3), round(a, 3), round(-b[1] / upm, 3)]
    return {"sha256": hashlib.sha256(Path(path).read_bytes()).hexdigest(), "fileName": Path(path).name,
            "unitsPerEm": upm, "ascent": round(hh.ascent / upm, 4), "descent": round(-hh.descent / upm, 4),
            "lineGap": round(hh.lineGap / upm, 4), "advances": adv, "kerning": {}, "inkBounds": ink,
            "extractionWarnings": ["no kerning pairs read (lines measure slightly long: safe side)"],
            "limitations": "Generated by brand_import.py from the font file."}


def font_names(path):
    from fontTools.ttLib import TTFont
    n = TTFont(str(path))["name"]
    names = {str(r) for r in n.names if r.nameID in (1, 4, 16) and r.platformID in (1, 3)}
    full = n.getDebugName(4) or ""
    return names, full


def alias_for(font, heading):
    """Bundled font measured in place of one without a font file: headings take the widest bundled face
    (Playfair Display Black: shrinks a little early, never overflows); body text by weight."""
    low = font.lower()
    if heading:
        return "Playfair Display Black"
    if "bold" in low or "black" in low or "heavy" in low:
        return "Circular Std Bold"
    if "medium" in low or "semibold" in low or "demi" in low:
        return "Circular Std Medium"
    return "Circular Std Book"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("template"); ap.add_argument("--name", required=True)
    ap.add_argument("--label"); ap.add_argument("--fonts"); ap.add_argument("--logo")
    ap.add_argument("--dest"); ap.add_argument("--use", action="store_true")
    a = ap.parse_args()
    name = re.sub(r"[^a-z0-9-]", "-", a.name.lower())
    src = Path(a.template)
    base = Path(a.dest) if a.dest else (B.RUN_BRANDS if B.RUN_BRANDS.parent.exists() else B.SKILL_BRANDS)
    out = base / name
    out.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, out / "template.pptx")
    z, colours, tfonts, master, sl, title_texts, head_fonts, body_fonts, used, info = analyse(out / "template.pptx")

    # ---- roles: the sample headline is the short placeholder text repeated on the most slides
    marker, n = (title_texts.most_common(1)[0] if title_texts else (NEVER, 0))
    if n < 3:                                  # no repeated sample: real titles -> the title placeholder is the headline
        keys = collections.Counter(k for s in info for k in s["ph_keys"])
        k, c = keys.most_common(1)[0] if keys else (NEVER, 0)
        marker = k if c >= len(info) / 2 else NEVER
    # ---- fonts
    for s in info:
        el = s["head_el"].get(marker)
        if el is not None:
            head_fonts[inherited_font(z, s["part"], el, tfonts)] += 1
            for f, bold, n_ in run_fonts(el, tfonts):          # headline runs are not body text
                if f:
                    body_fonts[(f, bold)] -= n_
    heading = head_fonts.most_common(1)[0][0] if head_fonts else tfonts["majorFont"]
    plain = collections.Counter({f: n for (f, b), n in body_fonts.items() if not b and f != heading and n > 0})
    body = plain.most_common(1)[0][0] if plain else tfonts["minorFont"]
    fam = body.split()[0]
    variants = [f for (f, _b) in body_fonts if f != body and f.startswith(fam)]
    medium = next((f for f in variants if re.search(r"medium|semi|demi", f, re.I)), None)
    bold = next((f for f in variants if re.search(r"bold|black|heavy", f, re.I)), None)
    fonts = {"heading": heading, "body": body, "body_medium": medium, "body_bold": bold,
             "installed_check": sorted({f.split(" ")[0] + (" " + f.split(" ")[1] if len(f.split()) > 1 and
                                        f.split()[1] not in ("Book", "Medium", "Bold", "Black", "Regular", "Light") else "")
                                        for f in (heading, body)}),
             "oldstyle_digits": [heading] if re.search(r"playfair|garamond|caslon|didot", heading, re.I) else []}

    # ---- metrics: measured from font files, else an alias to a bundled font
    metrics, aliases, notes = {}, {}, []
    files = list(Path(a.fonts).rglob("*.[ot]tf")) if a.fonts else []
    try:
        idx, rank = {}, {}
        for f in files:
            names, full = font_names(f)
            italic = bool(re.search(r"italic|oblique", f.name + full, re.I))
            for nm in names | {full}:
                r = (0 if nm == full else 1) + (5 if italic else 0) + (0 if re.search(r"regular|book", f.name, re.I) else 0.5)
                if nm not in rank or r < rank[nm]:
                    idx[nm], rank[nm] = f, r
    except ImportError:
        idx = {}; notes.append("fontTools not installed: font files ignored, metrics aliased")
    import fit_runner
    known = set(fit_runner.load().METRICS)
    for key in ("heading", "body", "body_medium", "body_bold"):
        f = fonts.get(key)
        if not f or f in known or f in metrics:
            continue
        if f in idx:
            src_file = idx[f]
            if key == "heading" and not re.search(r"bold|black|heavy", f, re.I):
                # headlines are usually set bold: measure the family's bold cut (wider = safe side)
                stem = re.sub(r"[-_ ]?(regular|book|roman)?\.(ttf|otf)$", "", src_file.name, flags=re.I)
                bolder = sorted((p for p in files if p.name.lower().startswith(stem.lower()) and
                                 re.search(r"bold|black", p.name, re.I) and not re.search(r"italic|oblique|condensed", p.name, re.I)),
                                key=lambda p: (0 if re.search(r"black", p.name, re.I) else 1, len(p.name)))
                src_file = bolder[0] if bolder else src_file
            metrics[f] = metrics_from_file(src_file); notes.append(f"{f}: measured from {src_file.name}")
        else:
            aliases[f] = alias_for(f, key == "heading")
            notes.append(f"{f}: no font file -> measured as '{aliases[f]}' (APPROXIMATE: pass --fonts to measure it)")
    if metrics:
        (out / "metrics.json").write_text(json.dumps(metrics))

    # ---- palette
    tints, brand_cols, neutrals = [], [], ["000000", "FFFFFF"]
    pool = [c for c in colours.values()] + [c for c, n in used.most_common() if n >= 2]
    for c in dict.fromkeys(pool):
        L, C, _ = B.lch(c)
        if C < 10:
            neutrals.append(c)
        elif L > 85:
            tints.append(c)
        else:
            brand_cols.append(c)
    accents = [colours[k] for k in ("accent1", "accent2", "accent3", "accent4", "accent5", "accent6") if k in colours]
    dark = min((c for c in accents + brand_cols if B.lch(c)[1] >= 10), key=lambda c: B.lch(c)[0], default="404040")
    light = max(tints, key=lambda c: B.lch(c)[0], default="F2F2F2")

    # ---- roles
    if marker == NEVER:
        notes.append("no repeated sample headline found: headline auto-fit is OFF for this brand (set headline_marker by hand)")
        marker = NEVER
    with_head = [s for s in info if (marker in s["ph_keys"] if marker.startswith("@ph:") else marker in s["titles"])
                 and s["slide"] not in (1, len(sl))]
    diagram_base = min(with_head, key=lambda s: (bool(s["tables"]), s["shapes"]))["slide"] if with_head else 1
    flow = next((s for s in info if any(r == 1 and c >= 3 for _, r, c in s["tables"]) and len(s["boxes"]) >= 3), None)
    roles = {"cover": 1, "closing": len(sl), "diagram_base": diagram_base,
             "flow": flow["slide"] if flow else None,
             "flow_table": next((t for t, r, c in flow["tables"] if r == 1), None) if flow else None,
             "flow_boxes": None}
    if flow:
        roles["flow_boxes"] = len(flow["boxes"])
        notes.append(f"step-flow slide detected: {flow['slide']} (table '{roles['flow_table']}') - check it; "
                     "set roles.flow to null if it is not a flow")

    # ---- logo
    logo = None
    if a.logo:
        logo = "logo" + Path(a.logo).suffix.lower(); shutil.copyfile(a.logo, out / logo)
    else:
        lp = find_logo(z, master, sl)
        if lp:
            logo = "logo" + Path(lp).suffix.lower(); (out / logo).write_bytes(z.read(lp))
            notes.append(f"logo taken from {lp} - pass --logo to override")
        else:
            notes.append("no logo found: kit logos are removed from infographics (pass --logo to add one)")

    prof = {"name": name, "label": a.label or src.stem, "template": "template.pptx",
            "sha256": hashlib.sha256((out / "template.pptx").read_bytes()).hexdigest(), "slides": len(sl),
            "headline_marker": marker, "roles": roles, "fonts": fonts,
            "theme": {k: v for k, v in colours.items() if k in ("dk1", "lt1", "dk2", "lt2", "accent1", "accent2",
                                                               "accent3", "accent4", "accent5", "accent6")},
            "palette": {"brand": brand_cols, "tints": tints, "neutrals": list(dict.fromkeys(neutrals)),
                        "status": ["00B050", "FFC000", "FF0000"], "dark_accent": dark, "light_tint": light},
            "logo": logo, "metrics": aliases}
    (out / "brand.json").write_text(json.dumps(prof, indent=1))

    cat = [f"# {prof['label']} - slide catalog\n", "| Slide | Headline sample | Tables (rows x cols) | Boxes | Text sample |", "|---|---|---|---|---|"]
    for s in info:
        cat.append(f"| {s['slide']} | {(s['titles'] or [''])[0][:40]} | "
                   f"{', '.join(f'{r}x{c}' for _, r, c in s['tables'])} | {len(s['boxes'])} | {' / '.join(s['text'][:3])[:80]} |")
    (out / "CATALOG.md").write_text("\n".join(cat) + "\n")

    print(f"brand '{name}' registered: {out}")
    print(f"  template: {len(sl)} slides   headline: {('placeholder ' + marker[4:] if marker.startswith('@ph:') else repr(marker)) if marker != NEVER else '(none)'}")
    print(f"  fonts: heading {heading} | body {body} | medium {medium} | bold {bold}")
    print(f"  theme: " + " ".join(f"{k}={v}" for k, v in prof["theme"].items()))
    print(f"  roles: {roles}")
    for nline in notes:
        print("  NOTE " + nline)
    if a.use:
        B.use(name)
    print("NEXT: python tools/bootstrap.py (checks the new brand), then build as usual. See CATALOG.md for the slides.")


if __name__ == "__main__":
    main()
