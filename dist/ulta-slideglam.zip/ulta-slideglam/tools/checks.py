"""Check evidence: the gates a tool actually ran on a file, bound to that file's content (<file>.checks.json).

The RESULT line's "ULTA Standards Match" comes from this record only. A file that has no record, or has changed
since it was checked, reads "not validated" - never a percentage. 100% means every gate ran on this exact content
and passed (advisory notes, such as a template colour pair just under the contrast target, do not count against it);
a gate that could not run here counts as not passed.

    import checks
    checks.record(path, [("Brand colours", "PASS", ""), ("Sensitive data", "REVIEW", "an e-mail address", True)])
    checks.add(path, [("Storyboard rules", "FAIL", "slide 3: headline is a topic label")])
    checks.summary(path)      # 'ULTA Standards Match 100% (9/9 checks)' or '... not validated'
"""
import hashlib, json, re, zipfile
from pathlib import Path

CONTENT = re.compile(r"(ppt/(slides|notesSlides|charts|media|embeddings|diagrams|slideLayouts|slideMasters|theme)/[^/]+$"
                     r"|ppt/presentation\.xml$"
                     r"|word/(document|styles|numbering|settings|footnotes|endnotes|header\d*|footer\d*)\.xml$"
                     r"|word/(media|charts|theme|embeddings)/[^/]+$"
                     r"|xl/(worksheets|charts|drawings|media|theme)/[^/]+$|xl/(sharedStrings|styles|workbook)\.xml$)")
OFFICE = (".pptx", ".docx", ".xlsx")
RESULTS = ("PASS", "FAIL", "REVIEW", "UNVERIFIED")


def content_hash(path):
    """SHA-256 of what a reader sees. For Office files the slides, pages, charts, pictures, layouts and theme - not
    the file properties, which the version stamp and the privacy clean-up change after the checks."""
    path = Path(path)
    h = hashlib.sha256()
    if path.suffix.lower() in OFFICE and zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            for n in sorted(z.namelist()):
                if CONTENT.match(n):
                    h.update(n.encode()); h.update(z.read(n))
    else:
        h.update(path.read_bytes())
    return h.hexdigest()


def side(path):
    return Path(str(path) + ".checks.json")


def _rows(rows):
    out = []
    for r in rows:
        name, result, detail = r[0], r[1], (r[2] if len(r) > 2 else "")
        if result not in RESULTS:
            raise ValueError(f"check result must be one of {RESULTS}: {result!r}")
        out.append({"check": str(name), "result": result, "detail": str(detail or "")[:240],
                    "advisory": bool(r[3]) if len(r) > 3 else False})
    return out


def record(path, rows, overall=None, info=()):
    """Write the evidence for `path`: rows of (check, PASS|FAIL|REVIEW|UNVERIFIED, detail[, advisory]).
    `info` rows are shown with the record but do not count (a preview render, for instance)."""
    data = {"schema": 1, "file": Path(path).name, "content_sha256": content_hash(path), "overall": overall,
            "rows": _rows(rows), "info": _rows(info)}
    side(path).write_text(json.dumps(data, indent=1), encoding="utf-8")
    return data


def add(path, rows, requires=None):
    """More gates for a file that already has a current record (a builder's own content rules, a page's checks).
    `requires` names the check that should have written that record: when there is none, it is recorded as not run,
    so a few extra gates can never stand in for the full validation."""
    data = load(path)
    if data is None:
        return record(path, ([(requires, "UNVERIFIED", "did not run on this file")] if requires else []) + list(rows))
    data["rows"] += _rows(rows)
    side(path).write_text(json.dumps(data, indent=1), encoding="utf-8")
    return data


def load(path):
    """The record, if there is one for this exact content; else None."""
    p = side(path)
    if not Path(path).is_file() or not p.is_file():
        return None
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return data if data.get("content_sha256") == content_hash(path) else None


def _short(name):
    return re.split(r"\s+-\s|\s*[(:]", name, 1)[0].strip()


def summary(path):
    """'ULTA Standards Match N% (passed/run checks ...)' from the record; 'not validated' without a current one."""
    data = load(path) if path else None
    if not data or not data.get("rows"):
        return "ULTA Standards Match: not validated (no check record for this file)"
    rows = data["rows"]
    ok = [r for r in rows if r["result"] == "PASS" or (r["result"] == "REVIEW" and r.get("advisory"))]
    bad = [r for r in rows if r["result"] == "FAIL" or (r["result"] == "REVIEW" and not r.get("advisory"))]
    unver = [r for r in rows if r["result"] == "UNVERIFIED"]
    pct = 100 if len(ok) == len(rows) else min(99, int(100 * len(ok) / len(rows)))
    text = f"ULTA Standards Match {pct}% ({len(ok)}/{len(rows)} checks"
    if unver:
        text += "; could not run here: " + ", ".join(_short(r["check"]) for r in unver[:3])
    notes = sum(r["result"] == "REVIEW" and r.get("advisory") for r in rows)
    if notes:
        text += f"; {notes} advisory note{'s' if notes > 1 else ''}"
    text += ")"
    if bad:
        text += " - fix: " + ", ".join(_short(r["check"]) for r in bad[:4])
    return text
