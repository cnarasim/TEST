"""Opens clean in PowerPoint and Word: validate the parts this skill writes against the ISO/IEC 29500 schemas.

LibreOffice and chat previews tolerate XML that desktop PowerPoint and Word repair or reject (a table cell after its
row's extLst, Word properties out of order). Those files look right in every preview and break on the user's machine.
This check reads the same schemas Office is built on, so the problem is caught before delivery.

    python tools/ooxml_check.py Deck.pptx | Report.docx      prints PASS or one line per problem; exit 1 on problems

Checked: slides, notes and charts (.pptx); document, styles, numbering, settings, headers and footers (.docx).
The package too, which a schema cannot see and PowerPoint repairs ("found a problem with content"): a file cut off
while it was written (no table of contents), a part stored twice or under two names that differ only in case, parts
without a content type, links to parts that are not there or a link id used twice, slide numbers repeated, master and
layout ids repeated or out of range, shape ids repeated on a slide, chart values that are not numbers (NaN, inf), chart
points numbered twice, chart axes that are not there, chart axis ids above 2147483647 (the schema allows them, Office
reads a signed 32-bit number and repairs the file), table rows with more or fewer cells than the table has columns,
table columns of no width, and a document property longer than Office keeps (255 characters - PowerPoint repairs the
file, Excel crashes on it).
Not checked: masters, layouts and the theme - they are the template's own, verified by hash at startup.
Markup-compatibility blocks are resolved the way Office reads them (Fallback); ignorable extensions are skipped.
Accepted as written by Office itself: whole-number percentages (90000 = 90%, ECMA-376 1st edition) and empty
chart extensions.
"""
import re, sys, zipfile
from pathlib import Path
from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

DIR = Path(__file__).resolve().parent / "ooxml_schemas" / "ISO-IEC29500-4_2016"
MC = "http://schemas.openxmlformats.org/markup-compatibility/2006"
_CACHE = {}
PPTX_PARTS = re.compile(r"ppt/(slides/[^/]+|notesSlides/[^/]+|charts/[^/]*chart\d+)\.xml$")   # renamed (swapped-in) parts too
DOCX_PARTS = re.compile(r"word/(document|styles|numbering|settings|header\w*|footer\w*)\.xml$")


def _schema(name):
    if not (DIR / name).exists():                      # ULTA SlideGlam ships the PowerPoint schemas only
        return None
    if name not in _CACHE:
        _CACHE[name] = etree.XMLSchema(etree.parse(str(DIR / name)))
    return _CACHE[name]


def _resolve_mc(x):
    """Read markup compatibility the way Office does: AlternateContent -> its Fallback (or first Choice);
    elements and attributes in namespaces the part declares Ignorable are dropped."""
    for ac in list(x.iter(f"{{{MC}}}AlternateContent")):
        pick = ac.find(f"{{{MC}}}Fallback")
        if pick is None:
            pick = ac.find(f"{{{MC}}}Choice")
        par = ac.getparent(); i = par.index(ac)
        for k, c in enumerate(list(pick) if pick is not None else []):
            par.insert(i + k, c)
        par.remove(ac)
    ign = x.get(f"{{{MC}}}Ignorable")
    if ign:
        nss = {x.nsmap.get(p) for p in ign.split()} - {None}
        for el in list(x.iter()):
            if not isinstance(el.tag, str):
                continue
            if etree.QName(el).namespace in nss and el.getparent() is not None:
                el.getparent().remove(el); continue
            for a in list(el.attrib):
                if a.startswith("{") and a[1:].split("}")[0] in nss:
                    del el.attrib[a]
        del x.attrib[f"{{{MC}}}Ignorable"]
    return x


def _accepted(err):
    m = err.message
    if "[facet 'pattern']" in m and "%" in m and re.search(r"The value '-?\d+' is not accepted", m):
        return True                                   # 90000 = 90%: what PowerPoint itself writes
    if m.startswith("Element '{http://schemas.openxmlformats.org/drawingml/2006/chart}ext': Missing child"):
        return True                                   # an empty chart extension (the template has one)
    return False


R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
C = "http://schemas.openxmlformats.org/drawingml/2006/chart"
NUMBER = re.compile(r"^\s*-?(\d+\.?\d*|\.\d+)([eE][-+]?\d+)?\s*$")


def _rels(z, part):
    """{rId: target part or None for an external link} of one part."""
    folder, name = part.rsplit("/", 1) if "/" in part else ("", part)
    rp = f"{folder}/_rels/{name}.rels" if folder else f"_rels/{name}.rels"
    if rp not in z.namelist():
        return {}
    out = {}
    for r in etree.fromstring(z.read(rp)):
        tgt = r.get("Target") or ""
        if r.get("TargetMode") == "External":
            out[r.get("Id")] = None; continue
        parts = (tgt[1:] if tgt.startswith("/") else f"{folder}/{tgt}" if folder else tgt).split("/")
        stack = []
        for bit in parts:
            if bit == "..":
                stack = stack[:-1]
            elif bit and bit != ".":
                stack.append(bit)
        out[r.get("Id")] = "/".join(stack)
    return out


def package_problems(path):
    """[(part, 0, message)] for a package PowerPoint or Word would repair: see the module notes."""
    try:
        z = zipfile.ZipFile(str(path))
    except (zipfile.BadZipFile, OSError) as e:
        return [("(file)", 0, f"not a complete Office file ({e}) - it was cut off while being written; build it again "
                              "and wait for the build to finish before copying or sending it")]
    out = []
    with z:
        names = set(z.namelist())
        try:
            bad = z.testzip()
        except Exception as e:
            bad = str(e)
        if bad:
            return [(str(bad), 0, "damaged part (checksum) - the file was changed while being written; build it again")]
        if "[Content_Types].xml" not in names:
            return [("[Content_Types].xml", 0, "missing - not a complete Office file")]
        all_ = z.namelist()
        twice = sorted({n for n in all_ if all_.count(n) > 1})
        if twice:
            out.append((twice[0], 0, "stored twice in the file (a part written again without removing the first)"))
        low = {}
        for n in all_:
            if n.lower() in low and low[n.lower()] != n:
                out.append((n, 0, f"same part name as {low[n.lower()]} but for upper / lower case - Office reads names without case"))
            low[n.lower()] = n
        if "docProps/custom.xml" in names:
            px = etree.fromstring(z.read("docProps/custom.xml"))
            seen_n, seen_p = set(), set()
            for prop in px:
                nm, v = prop.get("name") or "", "".join(prop.itertext())
                units = len(v.encode("utf-16-le")) // 2
                if units > 255:
                    out.append(("docProps/custom.xml", 0, f"document property '{nm[:40]}' is {units} characters - Office keeps a text property "
                                                          "to 255 and PowerPoint offers to repair the file; build it again with this version "
                                                          "(or run python tools/fix_deck.py on it: long properties are split)"))
                if nm in seen_n or prop.get("pid") in seen_p:
                    out.append(("docProps/custom.xml", 0, f"document property '{nm[:40]}' or its number (pid) used twice"))
                seen_n.add(nm); seen_p.add(prop.get("pid"))
        ct = etree.fromstring(z.read("[Content_Types].xml"))
        over = {e.get("PartName", "").lstrip("/") for e in ct if e.get("PartName")}
        exts = {(e.get("Extension") or "").lower() for e in ct if e.get("Extension")}
        for n in names:
            if not n.endswith("/") and n != "[Content_Types].xml" and n not in over and n.rsplit(".", 1)[-1].lower() not in exts:
                out.append((n, 0, "part without a content type"))
        main = [n for n in names if re.match(r"(ppt/(slides/slide|notesSlides/notesSlide|charts/chart)\d+|ppt/presentation|word/document)\.xml$", n)]
        for n in sorted(names):
            if n.endswith(".rels"):
                ids = [r.get("Id") for r in etree.fromstring(z.read(n))]
                if len(ids) != len(set(ids)):
                    out.append((n, 0, f"link id {next(i for i in ids if ids.count(i) > 1)} used twice"))
                folder = n.split("_rels/")[0].rstrip("/")
                src = (folder + "/" if folder else "") + n.split("_rels/")[1][:-5]
                for rid, tgt in _rels(z, src).items():
                    if tgt is not None and tgt not in names:
                        out.append((n, 0, f"link {rid} points to {tgt}, which is not in the file"))
        for n in sorted(main):
            try:
                x = etree.fromstring(z.read(n))
            except etree.XMLSyntaxError as e:
                out.append((n, 0, f"not well-formed XML: {e}")); continue
            rels = _rels(z, n)
            for el in x.iter():
                if not isinstance(el.tag, str):
                    continue
                for k, v in el.attrib.items():
                    if k.startswith(f"{{{R}}}") and v and v not in rels:
                        out.append((n, 0, f"{etree.QName(el).localname} refers to link {v}, which the part does not have"))
            if n == "ppt/presentation.xml":
                ids = [s.get("id") for s in x.iter("{http://schemas.openxmlformats.org/presentationml/2006/main}sldId")]
                if len(ids) != len(set(ids)) or any(not (i or "").isdigit() or not 256 <= int(i) < 2147483648 for i in ids):
                    out.append((n, 0, "slide numbers repeated or out of range (sldId)"))
                lids = [s.get("id") for s in x.iter("{http://schemas.openxmlformats.org/presentationml/2006/main}sldMasterId")]
                for m in sorted(k for k in names if re.match(r"ppt/slideMasters/slideMaster\d+\.xml$", k)):
                    lids += [s.get("id") for s in etree.fromstring(z.read(m)).iter("{http://schemas.openxmlformats.org/presentationml/2006/main}sldLayoutId")]
                if len(lids) != len(set(lids)) or any(not (i or "").isdigit() or int(i) < 2147483648 for i in lids):
                    out.append((n, 0, "master or layout ids repeated or out of range (sldMasterId / sldLayoutId)"))
            if "/slides/slide" in n:
                y = _resolve_mc(etree.fromstring(z.read(n)))
                ids = [c.get("id") for c in y.iter("{http://schemas.openxmlformats.org/presentationml/2006/main}cNvPr")
                       if not any(etree.QName(u).localname == "graphicData" for u in c.iterancestors())]   # an embedded
                # object's own fallback picture carries its frame's id, as PowerPoint writes it
                dup = sorted({i for i in ids if ids.count(i) > 1})
                if dup:
                    out.append((n, 0, f"shape id {', '.join(dup[:3])} used twice on the slide"))
            for tbl in x.iter(f"{{{A}}}tbl"):
                cols = len(tbl.findall(f"{{{A}}}tblGrid/{{{A}}}gridCol"))
                if any(int(g.get("w") or 0) <= 0 for g in tbl.findall(f"{{{A}}}tblGrid/{{{A}}}gridCol")):
                    out.append((n, 0, "a table column of no width"))
                for k, tr in enumerate(tbl.findall(f"{{{A}}}tr"), 1):
                    if len(tr.findall(f"{{{A}}}tc")) != cols:
                        out.append((n, 0, f"table row {k} has {len(tr.findall(f'{{{A}}}tc'))} cells for {cols} columns")); break
            if "/charts/" in n:
                for cache in list(x.iter(f"{{{C}}}numCache")) + list(x.iter(f"{{{C}}}numLit")):
                    pc = cache.find(f"{{{C}}}ptCount")
                    pts = cache.findall(f"{{{C}}}pt")
                    if pc is not None and pts and max(int(p.get("idx", 0)) for p in pts) >= int(pc.get("val", 0)):
                        out.append((n, 0, "chart point beyond its point count")); break
                    odd = [p.findtext(f"{{{C}}}v") for p in pts if not NUMBER.match(p.findtext(f"{{{C}}}v") or "")]
                    if odd:
                        out.append((n, 0, f"chart value {odd[0]!r} is not a number (empty or NaN data) - leave the point out")); break
                for cache in list(x.iter(f"{{{C}}}numCache")) + list(x.iter(f"{{{C}}}strCache")):
                    idx = [p.get("idx") for p in cache.findall(f"{{{C}}}pt")]
                    if len(idx) != len(set(idx)):
                        out.append((n, 0, "a chart point numbered twice")); break
                pa = x.find(f".//{{{C}}}plotArea")
                if pa is not None:
                    used = {a.get("val") for ch in pa for a in ch.findall(f"{{{C}}}axId")}
                    have = {ax.find(f"{{{C}}}axId").get("val") for ax in pa
                            if etree.QName(ax).localname in ("catAx", "valAx", "dateAx", "serAx") and ax.find(f"{{{C}}}axId") is not None}
                    cross = {a.get("val") for a in pa.iter(f"{{{C}}}crossAx")}
                    if (used | cross) - have:
                        out.append((n, 0, "the chart refers to an axis that is not there"))
                    big = sorted(v for v in used | have | cross if v and not (v.isdigit() and int(v) <= 2147483647))
                    if big:                              # ISO allows any unsignedInt; Office reads a signed 32-bit number
                        out.append((n, 0, f"chart axis id {big[0]} is beyond what PowerPoint reads (0 to 2147483647) - "
                                          "python tools/fix_deck.py <deck> renumbers it"))
                    sers = [s_.find(f"{{{C}}}idx").get("val") for s_ in pa.iter(f"{{{C}}}ser") if s_.find(f"{{{C}}}idx") is not None]
                    if len(sers) != len(set(sers)):
                        out.append((n, 0, "two chart series with the same number (idx)"))
    return out


def problems(path):
    """[(part, line, message)] for every schema error in the parts this skill writes, and every package problem."""
    path = Path(path)
    kind = path.suffix.lower()
    out = package_problems(path)
    if out and out[0][0] in ("(file)", "[Content_Types].xml") or any("checksum" in m for _, _, m in out):
        return out
    with zipfile.ZipFile(str(path)) as z:
        for n in z.namelist():
            if kind == ".pptx" and PPTX_PARTS.match(n):
                sc = _schema("dml-chart.xsd" if "/charts/" in n else "pml.xsd")
            elif kind == ".docx" and DOCX_PARTS.match(n):
                sc = _schema("wml.xsd")
            else:
                continue
            if sc is None:
                continue
            try:
                x = _resolve_mc(etree.fromstring(z.read(n)))
            except etree.XMLSyntaxError as e:
                out.append((n, 0, f"not well-formed XML: {e}")); continue
            if not sc.validate(x.getroottree()):
                out += [(n, e.line, e.message) for e in sc.error_log if not _accepted(e)]
    return out


def summary(path, limit=3):
    """Short lines for a report: '<part>: <what>' - one per distinct problem."""
    seen, lines = set(), []
    for n, line, msg in problems(path):
        what = re.sub(r"\{[^}]+\}", "", msg)
        what = re.sub(r"Expected is .*", "", what).strip().rstrip(".")
        key = (n.rsplit("/", 1)[-1].rstrip("0123456789.xml"), what)
        if key in seen:
            continue
        seen.add(key); lines.append(f"{n}: {what[:140]}")
    return lines[:limit] + ([f"... and {len(lines) - limit} more"] if len(lines) > limit else [])


def main():
    bad = 0
    for p in sys.argv[1:]:
        s = summary(p, limit=20)
        print(("PASS  " if not s else "FAIL  ") + f"opens clean in Office (ISO/IEC 29500 schema and package): {p}")
        for line in s:
            print("      - " + line)
        bad += bool(s)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
