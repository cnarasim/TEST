"""The Ulta template's 40 curated layouts (assets/templates): the reference every deck is built from.

The 40-slide file holds 20 layouts that are the 33-slide template's own slides (byte-identical: they keep their numbers)
and 20 more: four covers, a gradient agenda, three dividers, paired columns, four pillars, an agenda list, recap and
today, focus areas, objectives and scope, team, headline metrics, a period scorecard, two big notes and a photo quote.
Decks use one reference that holds both: the 33 template slides, then the 20 new layouts as sources 34-53. It is put
together at run time from the two pinned files, the same bytes every time, and checked against its own pin.

    python tools/full_template.py list                                  # every layout: source, name, what it is for
    python tools/full_template.py show --out /mnt/data/out/layouts.png  # one picture of all 40 (pre-drawn)
    python tools/full_template.py show --sources 34,43,48 --out /mnt/data/out/some.png   # rendered now (LibreOffice)

In a storyboard, "source" takes the number or the name: {"source": "four-pillars", "headline": "...", "slots": {...}}.
python tools/build_deck.py inventory 43 48 lists a layout's slots and sample text.
"""
import argparse, hashlib, json, os, re, shutil, sys, tempfile, zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
FOLDER = ROOT / "assets" / "templates"
COLLECTION = FOLDER / "collection.json"
SHEET = ROOT / "modules" / "ultabranddeliverables" / "references" / "gallery" / "sheets" / "layouts-40.png"
BUILDER = "1"                                   # bump when the way the reference is put together changes
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
SECTION_ID = "{6D1E4F0A-2B7C-4C1E-9E10-40A1A7E5B0C4}"
STAMP = (1980, 1, 1, 0, 0, 0)
_MEMO = {}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def collection():
    return json.loads(COLLECTION.read_text(encoding="utf-8"))


def template():
    """The 40-slide file, after checking its pin."""
    c = collection()
    path = FOLDER / c["file"]
    if not path.is_file() or sha(path) != c["sha256"]:
        raise SystemExit(f"FAIL the 40-layout template is missing or changed ({path.name}): reinstall the skill")
    return path


def names():
    """{name: source number} for all 40 layouts."""
    return {r["name"]: r["source"] for r in collection()["slides"]}


ALIASES = {"cover": 1, "divider": 5}               # the 33-slide template's own cover and numbered divider


def resolve(src):
    """A storyboard "source": a number, a numeric string or a layout name -> the source number (else unchanged)."""
    if isinstance(src, str):
        s = src.strip().lower()
        if s.isdigit():
            return int(s)
        return names().get(s, ALIASES.get(s, src))
    return src


LEGACY = {"cover": {1}, "agenda": {2}, "divider": {5, 23, 27}, "statement": set(), "closing": {32, 33}}


def kind(k):
    """Sources of one kind (cover, agenda, divider, statement, closing, content): the 33-slide template's own plus the
    40-layout collection's."""
    try:
        rows = collection()["slides"]
    except (OSError, ValueError):
        rows = []
    return set(LEGACY.get(k, set())) | {r["source"] for r in rows if r.get("kind") == k}


def display_sources():
    """Covers, agendas, dividers, statements and closings: the type the template set for them, no headline."""
    return set().union(*(kind(k) for k in ("cover", "agenda", "divider", "statement", "closing")))


def full_bleed_sources():
    """Slides whose own design runs to the edges (no logo and footer band to keep clear)."""
    return set().union(*(kind(k) for k in ("cover", "divider", "statement", "closing"))) | {2, 38}


def component_sources():
    """The added content layouts: like the template's components they keep the sizes the template designed."""
    return {r["source"] for r in collection()["slides"] if r.get("new") and r.get("kind") == "content"}


def _order(files):
    pres, rels = files["ppt/presentation.xml"].decode("utf-8"), files["ppt/_rels/presentation.xml.rels"].decode("utf-8")
    tgt = {re.search(r'Id="([^"]+)"', r).group(1): re.search(r'Target="([^"]+)"', r).group(1)
           for r in re.findall(r"<Relationship [^>]*/>", rels)}
    return ["ppt/" + tgt[r].lstrip("/") for r in re.findall(r'<p:sldId [^>]*r:id="([^"]+)"', pres)]


def _read(path):
    with zipfile.ZipFile(path) as z:
        return [i.filename for i in z.infolist()], {i.filename: z.read(i.filename) for i in z.infolist()}


def build(base, curated, rows):
    """bytes of the reference: base slides 1-33, then each new layout (rows: source order) as slide<source>.xml."""
    order, out = _read(base)
    _, cur = _read(curated)
    cur_slides = _order(cur)
    added, slide_ids, rel_ids, overrides = [], [], [], []
    pres = out["ppt/presentation.xml"].decode("utf-8")
    prels = out["ppt/_rels/presentation.xml.rels"].decode("utf-8")
    ct = out["[Content_Types].xml"].decode("utf-8")
    next_id = max(int(v) for v in re.findall(r'<p:sldId id="(\d+)"', pres)) + 1
    by_bytes = {out[n]: n for n in order if n.startswith("ppt/media/")}
    for r in rows:
        n = r["source"]
        src = cur_slides[r["index"] - 1]
        dst = f"ppt/slides/slide{n}.xml"
        if dst in out:
            raise SystemExit(f"FAIL reference build: {dst} already exists")
        rels = cur["ppt/slides/_rels/" + src.rsplit("/", 1)[1] + ".rels"].decode("utf-8")

        def retarget(m):
            rel = m.group(0)
            kind = re.search(r'Type="([^"]+)"', rel).group(1).rsplit("/", 1)[-1]
            if 'TargetMode="External"' in rel:
                return rel
            t = re.search(r'Target="([^"]+)"', rel).group(1)
            part = os.path.normpath(os.path.join("ppt/slides", t)).replace(os.sep, "/")
            if kind == "slideLayout":                  # the same layout, byte for byte, in both files
                lr = part.replace("slideLayouts/", "slideLayouts/_rels/") + ".rels"
                if out.get(part) != cur.get(part) or out.get(lr) != cur.get(lr):
                    raise SystemExit(f"FAIL reference build: layout {part} differs between the two templates")
                return rel
            if kind != "image":
                raise SystemExit(f"FAIL reference build: slide {n} has an unexpected {kind} part")
            blob = cur[part]
            name = by_bytes.get(blob)
            if name is None:
                name = f"ppt/media/layout{n}-{part.rsplit('/', 1)[1]}"
                out[name] = blob; added.append(name); by_bytes[blob] = name
            return rel.replace(f'Target="{t}"', f'Target="../media/{name.rsplit("/", 1)[1]}"')

        out[dst] = cur[src]
        out[f"ppt/slides/_rels/slide{n}.xml.rels"] = re.sub(r"<Relationship [^>]*/>", retarget, rels).encode("utf-8")
        added += [dst, f"ppt/slides/_rels/slide{n}.xml.rels"]
        slide_ids.append(next_id); rel_ids.append(f"rIdLayout{n}"); next_id += 1
        overrides.append(f'<Override PartName="/{dst}" ContentType="application/vnd.openxmlformats-officedocument.'
                         f'presentationml.slide+xml"/>')
    if any(f'Id="{r}"' in prels for r in rel_ids):
        raise SystemExit("FAIL reference build: relationship id clash")
    pres = pres.replace("</p:sldIdLst>", "".join(f'<p:sldId id="{i}" r:id="{r}"/>' for i, r in zip(slide_ids, rel_ids))
                        + "</p:sldIdLst>", 1)
    if "</p14:sectionLst>" in pres:                   # every slide sits in a section, as PowerPoint expects
        pres = pres.replace("</p14:sectionLst>", f'<p14:section name="5. More layouts" id="{SECTION_ID}"><p14:sldIdLst>'
                            + "".join(f'<p14:sldId id="{i}"/>' for i in slide_ids) + "</p14:sldIdLst></p14:section>"
                            "</p14:sectionLst>", 1)
    prels = prels.replace("</Relationships>", "".join(
        f'<Relationship Id="{r}" Type="{REL}/slide" Target="slides/slide{row["source"]}.xml"/>'
        for r, row in zip(rel_ids, rows)) + "</Relationships>", 1)
    for ext, typ in (("jpg", "image/jpeg"), ("jpeg", "image/jpeg"), ("png", "image/png"), ("svg", "image/svg+xml"),
                     ("emf", "image/x-emf")):
        if any(a.endswith("." + ext) for a in added) and f'Extension="{ext}"' not in ct:
            ct = ct.replace("<Default ", f'<Default Extension="{ext}" ContentType="{typ}"/><Default ', 1)
    ct = ct.replace("</Types>", "".join(overrides) + "</Types>", 1)
    out["ppt/presentation.xml"], out["ppt/_rels/presentation.xml.rels"] = pres.encode("utf-8"), prels.encode("utf-8")
    out["[Content_Types].xml"] = ct.encode("utf-8")
    import io
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED) as w:   # stored, fixed dates and order: the same bytes every time
        for name in order + added:
            zi = zipfile.ZipInfo(name, date_time=STAMP)
            zi.create_system, zi.external_attr = 3, 0o644 << 16
            w.writestr(zi, out[name])
    return buf.getvalue()


def combined(brand=None):
    """Path of the reference (33 template slides + the 20 new layouts), built once and checked against its pin."""
    if brand is None:
        import brand as _B
        brand = _B.current()
    lay = brand.get("layouts") or {}
    want = lay.get("combined_sha256")
    if not want:
        return brand.base_template
    if want in _MEMO:
        return _MEMO[want]
    cache = Path(tempfile.gettempdir()) / "ulta-slideglam" / f"Ulta Beauty PPT Standard-40-{want[:12]}.pptx"
    if cache.is_file() and sha(cache) == want:
        _MEMO[want] = cache
        return cache
    base = brand.base_template
    if not base.is_file() or sha(base) != brand["sha256"]:
        raise SystemExit(f"FAIL template for brand '{brand.name}' with pinned SHA-256 not found ({base})")
    rows = sorted((r for r in collection()["slides"] if r["new"]), key=lambda r: r["source"])
    data = build(base, template(), rows)
    got = hashlib.sha256(data).hexdigest()
    if got != want:
        raise SystemExit(f"FAIL the 40-layout reference did not rebuild byte-identical ({got[:12]} != {want[:12]}); "
                         "reinstall the skill")
    cache.parent.mkdir(parents=True, exist_ok=True)
    tmp = cache.with_name(cache.name + f".{os.getpid()}.tmp")
    tmp.write_bytes(data)
    os.replace(tmp, cache)
    _MEMO[want] = cache
    return cache


def listing():
    c = collection()
    lines = ["40 Ulta template layouts - storyboard \"source\": number or name (sources 34-53 are the 20 added from the "
             "full template; the others are the 33-slide template's own)"]
    for r in sorted(c["slides"], key=lambda r: r["source"]):
        lines.append(f"  {r['source']:>2}  {r['name']:<18} {r['use']}" + ("  [new]" if r["new"] else ""))
    lines.append("Slots and sample text: python tools/build_deck.py inventory <sources>. Picture: full_template.py show.")
    return "\n".join(lines)


def show(out, sources=None):
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if not sources:
        if not SHEET.is_file():
            raise SystemExit(f"FAIL the pre-drawn layouts picture is missing ({SHEET.name})")
        shutil.copyfile(SHEET, out)
        print(f"PICTURE {out}  (all 40 layouts with their source numbers and names)")
        return out
    import brand as _B
    from pptx import Presentation
    ref = combined(_B.current())
    import atomic
    work = atomic.scratch()
    prs = Presentation(str(ref))
    keep = {resolve(s) for s in sources}
    bad = sorted(str(s) for s in keep if not isinstance(s, int) or not 1 <= s <= len(prs.slides))
    if bad:
        raise SystemExit(f"unknown layout(s): {', '.join(bad)} - see full_template.py list")
    lst = prs.slides._sldIdLst
    for k, sid in reversed(list(enumerate(list(lst), 1))):
        if k not in keep:
            prs.part.drop_rel(sid.rId); lst.remove(sid)
    deck = work / "layouts.pptx"
    import atomic
    atomic.save(prs, deck)
    import lo
    lo.convert(deck, work, "pdf", timeout=240)
    pdf = work / "layouts.pdf"
    if not pdf.exists() or not shutil.which("pdftoppm"):
        raise SystemExit("rendering is not available here - use full_template.py show without --sources (pre-drawn picture)")
    lo.rasterize(pdf, work / "p", 48)
    from PIL import Image, ImageDraw
    pngs = sorted(work.glob("p-*.png"))
    order = sorted(keep)
    cols = min(3, len(pngs)); w, h = 640, 360
    sheet = Image.new("RGB", (cols * (w + 20) + 20, ((len(pngs) + cols - 1) // cols) * (h + 50) + 20), "white")
    d = ImageDraw.Draw(sheet)
    rev = {v: k for k, v in names().items()}
    for i, p in enumerate(pngs):
        im = Image.open(p).convert("RGB"); im.thumbnail((w, h))
        x, y = 20 + (i % cols) * (w + 20), 20 + (i // cols) * (h + 50)
        sheet.paste(im, (x, y + 28))
        d.text((x, y + 6), f"{order[i]}  {rev.get(order[i], '')}", fill=(0, 0, 0))
    sheet.save(out)
    print(f"PICTURE {out}")
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("list")
    s = sub.add_parser("show"); s.add_argument("--out", required=True); s.add_argument("--sources")
    sub.add_parser("check")
    a = ap.parse_args()
    sys.path.insert(0, str(TOOLS))
    if a.cmd == "list":
        print(listing())
    elif a.cmd == "show":
        show(a.out, [x.strip() for x in a.sources.split(",")] if a.sources else None)
    else:
        import brand as _B
        p = combined(_B.current())
        print(f"READY | 40-layout reference {p.name} ({sha(p)[:12]}) | 53 sources")


if __name__ == "__main__":
    main()
