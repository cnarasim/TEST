"""People one-pagers from a spreadsheet: RACI matrix, team / org chart, onboarding sheet.

    python tools/people.py raci  raci.csv|.xlsx   --title "Portal launch RACI" --out /mnt/data/out/RACI
        Either a matrix (Activity | Ana | Raj | ...  with R/A/C/I in the cells) or rows
        (Activity | Responsible | Accountable | Consulted | Informed, names comma-separated).
        Checks: exactly one A per activity, at least one R. -> deck slide with a native table (+ .xlsx copy)
    python tools/people.py org   team.csv --title "Customer Ops team" --out /mnt/data/out/Org
        Name | Title | Reports to   -> org chart (diagram engine, tree style), editable in PowerPoint and draw.io
    python tools/people.py onboard onboarding.csv --title "Welcome to Customer Ops" --out /mnt/data/out/Onboarding
        Section | Item | Detail       (sections such as Key terms, First week, Tools, Who to ask) -> one-pager
All outputs: brand, accessibility, sensitive-data scan (contact details are flagged for review), stamp.
"""
import argparse, collections, json, re, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import data_slides as DS   # noqa: E402
import brand as B           # noqa: E402

ROLE_COLS = {"responsible": "R", "accountable": "A", "consulted": "C", "informed": "I"}


def raci_matrix(rows):
    head = [str(h).strip() for h in rows[0]]
    low = [h.lower() for h in head]
    if any(h in ROLE_COLS for h in low):                       # row form -> matrix
        people, acts = [], []
        for r in rows[1:]:
            cells = {}
            for k, h in enumerate(low):
                if h in ROLE_COLS:
                    for name in re.split(r"[,;/]\s*", str(r[k] or "")):
                        if name.strip():
                            cells[name.strip()] = (cells.get(name.strip(), "") + ROLE_COLS[h])
                            if name.strip() not in people:
                                people.append(name.strip())
            acts.append((str(r[0]).strip(), cells))
        return [[head[0]] + people] + [[a] + [cells.get(p, "") for p in people] for a, cells in acts]
    return [[str(c).strip() for c in r] for r in rows]


def raci_checks(m):
    issues = []
    for r in m[1:]:
        letters = "".join(r[1:]).upper()
        if letters.count("A") != 1:
            issues.append(f"'{r[0]}': {letters.count('A')} Accountable (needs exactly 1)")
        if "R" not in letters:
            issues.append(f"'{r[0]}': nobody Responsible")
    return issues


def build_story(slides, out, classification=None, owner=None):
    work = out.parent / (out.name + "_data"); work.mkdir(parents=True, exist_ok=True)
    sp = work / "storyboard.json"
    sp.write_text(json.dumps({"classification": classification, "owner": owner, "slides": slides}))
    r = subprocess.run([sys.executable, str(TOOLS / "build_deck.py"), "build", str(sp), "--out", str(out.with_suffix(".pptx")), "--verbose"],
                       capture_output=True, text=True)
    return next((l.split(":", 1)[1].strip().split(" -")[0] for l in r.stdout.splitlines() if l.startswith("OVERALL")),
                "build failed: " + (r.stdout + r.stderr)[-300:])


def cmd_raci(a):
    m = raci_matrix(DS.read_table(a.file, a.sheet))
    issues = raci_checks(m)
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = Workbook(); ws = wb.active; ws.title = "RACI"
    fills = {"A": "FDE1D2", "R": "FFE8EE", "C": "F9E3DE", "I": "F2F2F2"}      # template tints only (zero deviation)
    for r in m:
        ws.append(r)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor=B.current().ui("dark_accent"))
    for row in ws.iter_rows(min_row=2, min_col=2):
        for c in row:
            v = str(c.value or "")
            if v[:1] in fills:
                c.fill = PatternFill("solid", fgColor=fills[v[:1]])
            c.alignment = Alignment(horizontal="center")
    ws.column_dimensions["A"].width = 44
    wb.save(f"{out}.xlsx")
    import brand_colours
    for x in brand_colours.summary(f"{out}.xlsx", 3):
        print(f"  FAIL colour in the workbook: {x}")
    import typeset as TS
    acc = {}
    for row in m[1:]:
        for c, v in enumerate(row[1:], 1):
            if str(v).strip().upper().startswith("A"):
                acc[m[0][c]] = acc.get(m[0][c], 0) + 1
    top = max(acc, key=acc.get) if acc else None
    n_act = len(m) - 1
    cands = ([f"{len(issues)} RACI gap{'s' * (len(issues) > 1)} to resolve before sign-off"] if issues else
             [f"{top} is accountable for {acc[top]} of {n_act} activities" if top and acc[top] > 1 else "",
              f"Each of {n_act} activities has one accountable owner"])
    head = next((c for c in cands if c and TS.fits_headline(c)), f"{n_act} activities, one owner each")
    notes = "R = Responsible (does the work), A = Accountable (one per activity, signs off), C = Consulted, I = Informed." + \
            (" Gaps: " + "; ".join(issues) if issues else "")
    res = build_story([{"table": {"rows": m}, "headline": head, "notes": notes}], out, a.classification, a.owner)
    print(f"RACI {res} | {out}.pptx | {out}.xlsx" + (f" | {len(issues)} gap(s): " + "; ".join(issues[:4]) if issues else " | every activity has one A and an R"))


def cmd_org(a):
    rows = DS.read_table(a.file, a.sheet)
    head = [str(h).strip().lower() for h in rows[0]]
    ni = next(i for i, h in enumerate(head) if h in ("name", "person", "employee"))
    ti = next((i for i, h in enumerate(head) if h in ("title", "role", "job title", "position")), None)
    mi = next(i for i, h in enumerate(head) if h in ("reports to", "manager", "reports_to", "line manager"))
    people = {str(r[ni]).strip(): (str(r[ti]).strip() if ti is not None else "") for r in rows[1:] if str(r[ni]).strip()}
    ids = {n: f"p{k}" for k, n in enumerate(people)}
    links = [(str(r[mi]).strip(), str(r[ni]).strip()) for r in rows[1:] if str(r[mi]).strip() in people and str(r[ni]).strip()]
    flows = {"title": a.title, "nodes": [{"id": ids[n], "label": n, "sub": t, "items": []} for n, t in people.items()],
             "flows": [{"source": ids[m], "target": ids[n], "label": ""} for m, n in links]}
    if not links:
        sys.exit("no reporting lines found (Reports to must name someone in the Name column)")
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    import typeset as TS
    mgr = {n: str(r[mi]).strip() for r in rows[1:] for n in [str(r[ni]).strip()] if n}
    depth = lambda n, seen=(): 0 if mgr.get(n) not in people or n in seen else 1 + depth(mgr[n], seen + (n,))
    levels = 1 + max(depth(n) for n in people)
    root = next((n for n in people if mgr.get(n) not in people), next(iter(people)))
    cands = [f"{root} leads {len(people) - 1} people across {levels} levels", f"{len(people)} people in {levels} levels"]
    res = build_story([{"diagram": flows, "style": "tree",
                        "headline": next((c for c in cands if TS.fits_headline(c)), f"{len(people)} people"),
                        "notes": f"{len(people)} people. Source: {Path(a.file).name}"}], out, a.classification, a.owner)
    print(f"ORG {res} | {out}.pptx (+ {out.name}-slide1.drawio) | {len(people)} people, {len(links)} reporting lines")


def cmd_onboard(a):
    rows = DS.read_table(a.file, a.sheet)
    groups = collections.OrderedDict()
    for r in rows[1:]:
        groups.setdefault(str(r[0]).strip() or "General", []).append([str(x).strip() for x in r[1:3]])
    md = [f"# {a.title}", f"Topic: {a.topic or a.title}", f"For: {a.audience or 'New joiners'}", f"Updated: {a.updated or '—'}", ""]
    for sec, items in groups.items():
        low = sec.lower()
        md.append(f"## {sec}")
        if re.search(r"term|glossary|tool|system|shortcut|contact|who", low):
            md += [f"| {'Term' if 'term' in low else 'Item'} | {'Meaning' if 'term' in low else 'Detail'} |", "|---|---|",
                   *[f"| {i[0]} | {i[1] if len(i) > 1 else ''} |" for i in items]]
        elif re.search(r"step|week|day|how", low):
            md += [f"{k}. {i[0]}: {i[1] if len(i) > 1 else ''}".rstrip(": ") for k, i in enumerate(items, 1)]
        else:
            md += [f"- {i[0]}" + (f": {i[1]}" if len(i) > 1 and i[1] else "") for i in items]
        md.append("")
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    mdp = Path(f"{out}.md"); mdp.write_text("\n".join(md))
    import audience
    res = audience.build_onepager(mdp, out, template="cheatsheet")
    print(f"ONBOARDING {res} | {out}.pptx | source {mdp} (edit and re-run: audience-style rebuild)")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("raci", "org", "onboard"):
        p = sub.add_parser(name); p.add_argument("file"); p.add_argument("--title", required=True)
        p.add_argument("--out", required=True); p.add_argument("--sheet"); p.add_argument("--classification")
        p.add_argument("--owner")
        if name == "onboard":
            p.add_argument("--topic"); p.add_argument("--audience"); p.add_argument("--updated")
    a = ap.parse_args()
    {"raci": cmd_raci, "org": cmd_org, "onboard": cmd_onboard}[a.cmd](a)


if __name__ == "__main__":
    main()
