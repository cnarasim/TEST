"""Template infographics: the Ulta template's own infographic slides, filled with the user's content.

100% the template's look - its shapes, fills, outlines, icons and type stay exactly as designed; only the text, the
position of repeated items (bars, events, pins) and chart data change. validate_deck.py proves it per slide
(every shape on the slide is one of the template slide's shapes, styled identically).

Storyboard keys (each picks its template slide):
  {"quad": ["$4.6M\\nNet sales", "31.5%\\nConversion", "6.2 min\\nHandle time", "1.6%\\nShrink"]}     slide 13: four big numbers
  {"funnel": ["Awareness: 1.2M site visits", "Consideration: 310K product views", ...3-4]}         slide 26: a 3-4 stage funnel
  {"donut": {"items": [["Stores", 72], ["Online", 28]], "unit": "%", "center": "Net sales",
             "details": ["Stores: 72% of sales, flat on last year", "Online: 28%, up 4 pts"]}}      slide 8: share + two call-outs
  {"journey": ["2024: Foundation - one guest view in stores", "2025: Scale - ...", "2026: Lead - ..."]}  slide 18: 3 stages that grow
  {"results": [{"group": "Stores", "result": "Sales +4% vs plan", "learning": "Weekend hours lift conversion",
               "actions": [["Extend hours", "green", "RP"], ["Retrain leads", "amber"]]}, ...1-5]}   slide 11: results / learnings / actions
  {"scorecard": {"columns": ["Prior", "Target", "Actual"], "note": "vs target",
                 "groups": [{"name": "Sales", "kpis": [["Net sales", "$4.2M", "$4.5M", "$4.6M", "green"], ...]}],
                 "lowlights": ["..."], "highlights": ["..."]}}                                         slide 21: KPI scorecard (13 KPIs max)
  {"priorities": {"vision": "...", "goals": [0-3], "strategies": [{"name", "text", "kpis": [0-2]} x 3-6]}}
                                                                    slide 24: the vision house (vision, goals, pillars, KPIs)
  {"ogsm": {"objective": "...", "goals": [1-3], "strategies": [{"title", "text"} x 1-3],
            "measures": [{"title", "value", "text"} x 1-3]}}                                           slide 25: OGSM
  {"map": [{"place": "Dallas, TX", "text": "42 stores; sales +6%"}, ...1-4]}                         slide 22: US map with pins
Timeline styles ({"timeline": {...}, "style": ...}): template-gantt (15), template-roadmap (16), template-milestones
(17), template-callouts (19), journey (18); dated-flow becomes the template's flow slide (20).
"""
import copy, re
from datetime import date, timedelta

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
from pptx.util import Emu

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # run on its own (python -I too): its sibling modules
import native_draw as ND
from ulta_text import set_text

IN = 914400
A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
TEMPLATE_STYLES = {("timeline", "template-gantt"): 15, ("timeline", "template-roadmap"): 16,
                   ("timeline", "template-milestones"): 17, ("timeline", "template-callouts"): 19,
                   ("timeline", "journey"): 18}
FLOW_STYLE = ("timeline", "dated-flow")
KEYS = {"donut": 8, "results": 11, "quad": 13, "journey": 18, "scorecard": 21, "map": 22, "priorities": 24,
        "ogsm": 25, "funnel": 26}
BIG = re.compile(r"^[~<>≈]?[-+]?[$€£]?\d[\d,.]*\s?(%|x|k|m|bn|b|pts?|min|h|hrs|days?|wks?|weeks?|months?|mos?|years?|yrs?|M|K|B)?$|^\d+\s?(of|/)\s?\d+$", re.I)
STATUS_FILL = {"green": "00B050", "done": "00B050", "on track": "00B050", "complete": "00B050",
               "amber": "FFC000", "at risk": "FFC000", "watch": "FFC000",
               "red": "FF0000", "late": "FF0000", "off track": "FF0000", "blocked": "FF0000"}


def key_of(spec):
    return next((k for k in KEYS if isinstance(spec, dict) and spec.get(k) is not None), None)


# ------------------------------------------------------------------------------------------- shape helpers
def _table(sl, name=None):
    return next(s for s in sl.shapes if s.has_table and (name is None or s.name == name))


def _remove(sh):
    el = sh._element
    el.getparent().remove(el)


def _clone(sh):
    """A copy of a template shape right after it (new unique id); returns the new shape proxy."""
    el = copy.deepcopy(sh._element)
    tree = sh._element.getparent()
    ids = [int(x.get("id")) for x in tree.getroottree().iter(P + "cNvPr") if str(x.get("id", "")).isdigit()]
    for c in el.iter(P + "cNvPr"):
        c.set("id", str(max(ids) + 1))
        ids.append(max(ids) + 1)
    sh._element.addnext(el)
    from pptx.shapes.shapetree import SlideShapeFactory
    return SlideShapeFactory(el, sh._parent)


def _move(sh, x=None, y=None, w=None, h=None):
    if x is not None:
        sh.left = Emu(int(x))
    if y is not None:
        sh.top = Emu(int(y))
    if w is not None:
        sh.width = Emu(int(w))
    if h is not None:
        sh.height = Emu(int(h))


def _respread(shapes, n):
    """A row of repeated template items (goal boxes, KPI boxes, cards): keep the first n, spread over the row's full width
    with the template's own gap between them; the others are removed. Works in the items' own coordinates (a group's
    child space included). Returns the kept items, left to right."""
    row = sorted(shapes, key=lambda s: s.left)
    if n >= len(row):
        return row
    x0, x1 = row[0].left, max(s.left + s.width for s in row)
    gap = max(0, row[1].left - (row[0].left + row[0].width)) if len(row) > 1 else 0
    w = (x1 - x0 - gap * (n - 1)) / n
    for s in row[n:]:
        _remove(s)
    for i, s in enumerate(row[:n]):
        _move(s, x=x0 + i * (w + gap), w=w)
    return row[:n]


def _respread_tables(tabs, n, fixed_first=False):
    """Small template tables in a row (OGSM goals, measures): keep the first n, spread over the row; inside each, the
    first column keeps its width (a number cell) when fixed_first, else every column grows in proportion."""
    row = sorted(tabs, key=lambda s: s.left)
    if n >= len(row):
        return row
    kept = _respread(row, n)
    for t in kept:
        cols = t.table.columns
        old = [int(c.width) for c in cols]
        total = int(t.width)
        if fixed_first and len(old) > 1:
            cols[0].width = Emu(old[0])
            rest = sum(old[1:]) or 1
            for c, w in zip(list(cols)[1:], old[1:]):
                c.width = Emu(int((total - old[0]) * w / rest))
        else:
            for c, w in zip(cols, old):
                c.width = Emu(int(total * w / max(1, sum(old))))
    return kept


def _keep_cols(tshape, keep):
    """Keep a template table's columns at the indices in keep, widened to the table's full width (each keeps its own
    cell style)."""
    tbl = tshape._element.find(f".//{A}tbl")
    grid = tbl.find(A + "tblGrid")
    cols = grid.findall(A + "gridCol")
    if len(keep) >= len(cols):
        return
    total = sum(int(c.get("w")) for c in cols)
    for k, c in enumerate(cols):
        if k not in keep:
            grid.remove(c)
    for tr in tbl.findall(A + "tr"):
        for k, tc in enumerate(tr.findall(A + "tc")):
            if k not in keep:
                tr.remove(tc)
    n = len(keep)
    w = total // n
    for k, c in enumerate(grid.findall(A + "gridCol")):
        c.set("w", str(w if k < n - 1 else total - w * (n - 1)))


# The vision house's six pillar colours run berry to light orange; fewer pillars keep both ends and distinct steps.
PILLARS = {3: (0, 3, 5), 4: (0, 1, 3, 5), 5: (0, 1, 3, 4, 5), 6: (0, 1, 2, 3, 4, 5)}


def _pt2(el, default=12.0):
    """(lead size, body size): the first two runs' sizes in a text body (the template's own), in points."""
    sz = [int(r.get("sz")) / 100 for r in el.iter(A + "rPr") if r.get("sz")]
    return (sz[0] if sz else default), (sz[1] if len(sz) > 1 else (sz[0] if sz else default))


def _pt(el, default=12.0):
    """The size of the first run in a text body (the template's own), in points."""
    for r in el.iter(A + "rPr"):
        if r.get("sz"):
            return int(r.get("sz")) / 100
    for r in el.iter(A + "defRPr"):
        if r.get("sz"):
            return int(r.get("sz")) / 100
    return default


def _bold(el):
    r = next(iter(el.iter(A + "rPr")), None)
    return r is not None and r.get("b") == "1"


def _nlines(text, width, pt, bold):
    import brand as _B
    b = _B.current()
    M = _B.metrics_for(b)
    face = ND.BOLD if bold else ND.BODY
    n, cur = 0, ""
    for para in str(text).split("\n"):
        n, cur = n + 1, ""
        for word in para.split():
            trial = (cur + " " + word).strip()
            ems = _B.width_of(trial, face, M) or len(trial) * 0.55
            if ems * pt * 12700 > width and cur:
                n, cur = n + 1, word
            else:
                cur = trial
    return n


def _long_word(text, width, pt, bold):
    """A word wider than the box: the renderer breaks it mid-word ('Inventor / y'), whatever the box's height."""
    import brand as _B
    M = _B.metrics_for(_B.current())
    face = ND.BOLD if bold else ND.BODY
    for word in str(text).split():
        if (_B.width_of(word, face, M) or len(word) * 0.55) * pt * 12700 > width:
            return word
    return None


def _insets(el):
    """(left, top, right, bottom) text insets of a shape's bodyPr or a table cell's tcPr (OOXML defaults)."""
    bp = el.find(f".//{A}bodyPr")
    if bp is not None and etree.QName(el).localname != "tc":
        g = lambda k, d: int(bp.get(k, d))
        return g("lIns", 91440), g("tIns", 45720), g("rIns", 91440), g("bIns", 45720)
    pr = el.find(A + "tcPr")
    g = lambda k, d: int(pr.get(k, d)) if pr is not None else d
    return g("marL", 91440), g("marT", 45720), g("marR", 91440), g("marB", 45720)


def _fit(text, w, h, pt, bold=False, body_pt=None, el=None):
    """Lead line at pt (bold), the other lines at body_pt, inside the box minus its insets (8% tolerance)."""
    l_, t_, r_, b_ = _insets(el) if el is not None else (91440, 45720, 91440, 45720)
    room_w, room_h = int(w) - l_ - r_, (int(h) - t_ - b_) * 1.08
    lines = str(text).split("\n")
    if any(_long_word(ln, room_w, pt if k == 0 else (body_pt or pt), bold if k == 0 else False) for k, ln in enumerate(lines)):
        return False
    if len(lines) == 1 and _nlines(lines[0], room_w, pt, bold) == 1:
        return True                                         # one line: the template centres it in its box
    need = 0
    for k, ln in enumerate(lines):
        size = pt if k == 0 else (body_pt or pt)
        need += _nlines(ln, room_w, size, bold if k == 0 else False) * size * 1.2 * 12700 if ln.strip() else size * 0.6 * 12700
    return need <= room_h


def _put(sh, text, what, problems, w=None, h=None, pt=None):
    """Text into a template shape (its own formatting) and a fit check at the template's size."""
    lead, body = _pt2(sh._element)
    set_text(sh.text_frame, text)
    size = pt or lead
    if text and not _fit(text, w or sh.width, h or sh.height, size, _bold(sh._element), body, sh._element):
        l_, _, r_, _ = _insets(sh._element)
        long_ = _long_word(text.split("\n")[0], int(w or sh.width) - l_ - r_, size, _bold(sh._element))
        problems.append(f"{what} '{long_}' is wider than its box at the template's {size:g} pt and would break mid-word - "
                        "use a shorter word or a number" if long_ else
                        f"{what} '{text[:40]}' is too long for its box at the template's {size:g} pt - shorten it")


def _cell(tbl, r, c, text, what, problems, pt=None):
    cell = tbl.cell(r, c)
    lead, body = _pt2(cell._tc)
    set_text(cell.text_frame, text)
    if text:
        w = sum(int(tbl.columns[c + k].width) for k in range(max(1, int(cell._tc.get("gridSpan") or 1))))
        h = sum(int(tbl.rows[r + k].height) for k in range(max(1, int(cell._tc.get("rowSpan") or 1))))
        size = pt or lead
        if not _fit(text, w, max(h, int(size * 1.25 * 12700) + 91440), size, _bold(cell._tc), body, cell._tc):
            problems.append(f"{what} '{text[:40]}' is too long for its cell at the template's {size:g} pt - shorten it")


def _split(t):
    """'Lead: detail' -> (lead, detail)."""
    m = re.match(r"\s*([^:–—]{1,48}?)\s*(?::|\s[–—-]\s)\s*(\S.*)$", str(t or ""))
    return (m.group(1).strip(), m.group(2).strip()) if m else (str(t or "").strip(), "")


def _words(t):
    return len(str(t or "").split())


# ------------------------------------------------------------------------------------------- dates / axis
def _date(v):
    import modern_charts as MC
    return MC._date(v)


def _items(data):
    """Timeline items -> [{name, group, start, end, milestone, text, status}] sorted by start; plus problems."""
    raw, probs = list((data or {}).get("items") or []), []
    if (data or {}).get("data"):
        import data_slides as DS
        import modern_charts as MC
        raw += [{"name": t["task"], "group": t["group"], "start": t["start"], "end": t["end"], "milestone": t["milestone"]}
                for t in MC.read_plan(str(DS.resolve(data["data"])))]
    out = []
    for it in raw:
        if isinstance(it, str):
            it = {"name": it}
        name = str(it.get("name") or it.get("task") or "").strip()
        s, e = it.get("start") or it.get("date"), it.get("end") or it.get("date") or it.get("start")
        try:
            s, e = _date(s), _date(e)
        except Exception:
            probs.append(f"timeline item '{name[:30]}' needs a date (start / end, or date for a milestone) like 2026-03-15")
            continue
        if e < s:
            s, e = e, s
        out.append({"name": name, "group": str(it.get("group") or "").strip(), "start": s, "end": e,
                    "milestone": bool(it.get("milestone")) or (s == e and not it.get("end")),
                    "text": str(it.get("text") or "").strip(), "status": str(it.get("status") or "").strip().lower()})
    return sorted(out, key=lambda i: (i["start"], i["end"])), probs


def _add_months(d, n):
    y, m = divmod(d.month - 1 + n, 12)
    return date(d.year + y, m + 1, 1)


def _axis(items, n, data=None):
    """n equal periods covering the items: weeks, months or quarters. Returns (starts[n+1], labels[n], unit) or None."""
    d0 = min(i["start"] for i in items)
    d1 = max(i["end"] for i in items)
    if (data or {}).get("start"):
        d0 = min(d0, _date(data["start"]))
    if (data or {}).get("end"):
        d1 = max(d1, _date(data["end"]))
    unit = (data or {}).get("unit")
    months = (d1.year - d0.year) * 12 + d1.month - d0.month + 1
    if unit == "week" or (not unit and (d1 - d0).days < 7 * n and months <= 2):
        s = d0 - timedelta(days=d0.weekday())
        starts = [s + timedelta(weeks=k) for k in range(n + 1)]
        if starts[-1] <= d1:
            return None
        return starts, [f"{x:%b} {x.day}" for x in starts[:n]], "week"
    if unit in (None, "month") and months <= n:
        s = date(d0.year, d0.month, 1)
        pad = (n - months) // 2 if (data or {}).get("center", False) else 0
        s = _add_months(s, -pad)
        starts = [_add_months(s, k) for k in range(n + 1)]
        return starts, [f"{x:%b}" for x in starts[:n]], "month"
    q0 = date(d0.year, 3 * ((d0.month - 1) // 3) + 1, 1)
    starts = [_add_months(q0, 3 * k) for k in range(n + 1)]
    if starts[-1] <= d1:
        return None
    return starts, [f"Q{(x.month - 1) // 3 + 1} {x:%y}" for x in starts[:n]], "quarter"


def _x(d, starts, x0, widths):
    """x (EMU) of date d on a column grid whose periods start at starts[]."""
    for i in range(len(widths)):
        a, b = starts[i], starts[i + 1]
        if d < b or i == len(widths) - 1:
            frac = max(0.0, min(1.0, (d - a).days / max(1, (b - a).days)))
            return x0 + sum(widths[:i]) + frac * widths[i]
    return x0 + sum(widths)


def _grid(tbl_shape):
    return int(tbl_shape.left), [int(c.width) for c in tbl_shape.table.columns]


def _labels_into_header(tbl, labels, upper=False):
    for c, lab in enumerate(labels):
        set_text(tbl.cell(0, c).text_frame, lab.upper() if upper else lab)
    for r in range(1, len(tbl.rows)):
        for c in range(len(tbl.columns)):
            if tbl.cell(r, c).text_frame.text.strip():
                set_text(tbl.cell(r, c).text_frame, "")


def _groups(items, limit):
    order = []
    for i in items:
        g = i["group"] or i["name"]
        if g not in order:
            order.append(g)
    return order[:limit], len(order) > limit


# ------------------------------------------------------------------------------------------- fixed-structure slides
def _quad(sl, spec, P_):
    vals = list(spec["quad"])
    if len(vals) != 4:
        return [f"quad (slide 13) takes 4 big numbers (2-3 go on the headline-metrics row by themselves), got {len(vals)} - "
                "one number: big-note or \"modern\": \"kpi\"; 5 or more: the kpi chart or two slides"]
    tbl = _table(sl).table
    for k, v in enumerate(vals):
        num, _, lab = str(v).partition("\n")
        if not BIG.match(num.strip()):
            P_.append(f"quad: '{num[:20]}' is not a number - each card is a number, a new line, then a 2-6 word label")
        if not lab.strip():
            P_.append(f"quad: '{num[:12]}' has no label - write \"74%\\nfewer returns\"")
        elif not 1 <= _words(lab) <= 6:
            P_.append(f"quad: label '{lab[:30]}' - keep it to 2-6 words")
        _cell(tbl, k // 2, k % 2, f"{num.strip()}\n{lab.strip()}", "quad", P_)
    return P_


def _funnel(sl, spec, P_):
    stages = [(_split(x) if isinstance(x, str) else (str(x.get("stage") or x.get("name") or ""), str(x.get("text") or "")))
              for x in spec["funnel"]]
    if not 3 <= len(stages) <= 4:
        return [f"funnel (slide 26) takes 3-4 stages, got {len(stages)} (5-6 stages are drawn as a funnel graphic "
                "automatically)"]
    layers = sorted((s for s in sl.shapes if s.name.startswith("Freeform")), key=lambda s: s.top)
    arrows = sorted((s for s in sl.shapes if s.name.startswith("Right Arrow")), key=lambda s: s.top)
    if len(stages) == 3:                                  # the funnel's narrow tip goes; the rest moves to the middle
        step = layers[1].top - layers[0].top
        for sh in (layers.pop(), arrows.pop()):
            _remove(sh)
        for sh in layers + arrows:
            _move(sh, y=sh.top + step // 2)
    for k, ((lead, det), lay, arr) in enumerate(zip(stages, layers, arrows)):
        if _words(lead) > 3:
            P_.append(f"funnel stage '{lead[:24]}' - the stage name is 1-3 words (the detail goes after a colon)")
        room = lay.width * (0.53 if k == 3 else 0.8)                  # the funnel narrows: the tip is a triangle, its
        _put(lay, lead, "funnel stage", P_, w=room)                     # width at the text line about half its top
        if not det.strip():                                             # (1u)
            P_.append(f"funnel stage '{lead[:24]}' has no detail for the box beside it - write 'Stage: detail'")
        if _words(det) > 14:
            P_.append(f"funnel detail '{det[:30]}...' is {_words(det)} words - keep it to 14")
        bp = arr._element.find(f".//{A}bodyPr")                        # the detail wraps in the arrow part right of the
        if bp is not None:                                              # funnel, never under it
            bp.set("lIns", str(int(lay.left + lay.width - arr.left + 0.1 * IN)))
        _put(arr, det, "funnel detail", P_)
    return P_


def _journey_parts(spec):
    raw = spec.get("journey")
    if raw is None and spec.get("timeline") is not None:
        its, _ = _items(spec["timeline"])
        raw = [{"title": i["name"], "text": i["text"]} for i in its]
    out = []
    for x in raw or []:
        if isinstance(x, str):
            t, d = _split(x)
        else:
            t, d = str(x.get("title") or x.get("name") or ""), str(x.get("text") or "")
        out.append((t, d))
    return out


def _journey(sl, spec, P_):
    parts = _journey_parts(spec)
    if len(parts) != 3:
        return [f"journey (slide 18) takes exactly 3 stages (then -> now -> next), got {len(parts)}"]
    heads = sorted((s for s in sl.shapes if s.name.startswith("TextBox")), key=lambda s: s.left)
    bodies = sorted((s for s in sl.shapes if s.name.startswith("Obdélník")), key=lambda s: s.left)
    for (t, d), hd, bd in zip(parts, heads, bodies):
        _put(hd, t, "journey stage title", P_)
        _put(bd, d, "journey stage text", P_)
    return P_


def _ogsm(sl, spec, P_):
    o = spec["ogsm"]
    goals, strats, meas = list(o.get("goals") or []), list(o.get("strategies") or []), list(o.get("measures") or [])
    if not o.get("objective") or not (1 <= len(goals) <= 3 and 1 <= len(strats) <= 3 and 1 <= len(meas) <= 3):
        return ["ogsm (slide 25) takes an objective and 1-3 each of goals, strategies {title, text} and measures "
                f"{{title, value, text}} - got {len(goals)} goals, {len(strats)} strategies, {len(meas)} measures"]
    big = _table(sl, "Table 6").table
    _cell(big, 0, 1, str(o["objective"]), "ogsm objective", P_)
    small = [s for s in sl.shapes if s.has_table and s.name == "Table 8"]
    gtabs = _respread_tables([s for s in small if s.top < 3 * IN], len(goals), fixed_first=True)   # fewer: the rest
    mtabs = _respread_tables([s for s in small if s.top > 5 * IN], len(meas))                     # spread over the row
    for g, tb in zip(goals, gtabs):
        _cell(tb.table, 0, 1, str(g), "ogsm goal", P_)
    grp = next(s for s in sl.shapes if s.shape_type is not None and "GROUP" in str(s.shape_type))
    bars = _respread([c for c in grp.shapes if c.height < 0.5 * IN], len(strats))
    texts = _respread([c for c in grp.shapes if c.height >= 0.5 * IN], len(strats))
    for ic in sorted((s for s in sl.shapes if s.name.startswith("Obrázek")), key=lambda s: s.left)[len(strats):]:
        _remove(ic)                                       # each kept strategy keeps its own icon
    xfrm = grp._element.find(f"{P}grpSpPr/{A}xfrm")
    off, ext = xfrm.find(A + "off"), xfrm.find(A + "ext")
    choff, chext = xfrm.find(A + "chOff"), xfrm.find(A + "chExt")
    sx = int(ext.get("cx")) / max(1, int(chext.get("cx")))
    to_slide = lambda cx: int(off.get("x")) + (cx - int(choff.get("x"))) * sx
    icons = sorted((s for s in sl.shapes if s.name.startswith("Obrázek")), key=lambda s: s.left)
    import brand as _B
    M = _B.metrics_for(_B.current())
    for k, (s, bar, tx) in enumerate(zip(strats, bars, texts), 1):
        s = s if isinstance(s, dict) else dict(zip(("title", "text"), _split(s)))
        title = f"{k}. {s.get('title', '')}"
        _put(bar, title, "ogsm strategy title", P_)
        _put(tx, str(s.get("text", "")), "ogsm strategy", P_)
        if k <= len(icons):                                # the template's icon sits just left of its title
            ic = icons[k - 1]
            tw = (_B.width_of(title, ND.BOLD, M) or len(title) * 0.55) * _pt(bar._element, 14) * 12700
            centre = to_slide(bar.left + bar.width / 2)
            left_edge = to_slide(bar.left) + 0.12 * IN
            x = centre - tw / 2 - ic.width - 0.08 * IN
            if x < left_edge:
                P_.append(f"ogsm strategy title '{title}' is too long to sit beside its icon - keep it to 2 short words")
            _move(ic, x=max(x, left_edge))
    for m, tb in zip(meas, mtabs):
        m = m if isinstance(m, dict) else {"title": m[0], "value": m[1], "text": m[2] if len(m) > 2 else ""}
        _cell(tb.table, 0, 0, str(m.get("title", "")), "ogsm measure", P_)
        _cell(tb.table, 0, 1, f"{m.get('value', '')}\n{m.get('text', '')}".strip(), "ogsm measure", P_)
    return P_


def _priorities(sl, spec, P_):
    o = spec["priorities"]
    goals = [str(g) for g in (o.get("goals") or []) if str(g).strip()]
    strats = [st if isinstance(st, dict) else {"name": st} for st in (o.get("strategies") or o.get("pillars") or [])]
    if not o.get("vision") or not len(goals) <= 3 or not 3 <= len(strats) <= 6:
        return ["priorities (slide 24, the vision house) takes a vision, 0-3 goals and 3-6 strategies (pillars) "
                f"{{name, text, kpis: 0-2}} - got {len(goals)} goals, {len(strats)} strategies (two pillars: use "
                "four-pillars or paired-columns)"]
    n = len(strats)
    vis = next(s for s in sl.shapes if s.name == "Rectangle 93")
    _put(vis, str(o["vision"]), "priorities vision", P_, h=0.62 * IN)
    if _words(o["vision"]) > 22:
        P_.append(f"priorities vision is {_words(o['vision'])} words - keep it to 22")
    groups = [s for s in sl.shapes if s.shape_type is not None and "GROUP" in str(s.shape_type)]
    gl = next(g for g in groups if len(g.shapes) == 3)
    tshape = _table(sl, "Table 2")
    head_h = int(tshape.table.rows[0].height)
    icons = sorted((s for s in sl.shapes if "PICTURE" in str(s.shape_type) and tshape.top - 0.2 * IN < s.top < tshape.top + head_h),
                   key=lambda s: s.left)
    if goals:
        for g, sh in zip(goals, _respread(list(gl.shapes), len(goals))):   # fewer goals: wider boxes across the band
            _put(sh, g, "priorities goal", P_)
    else:                                                 # no goals: their band goes and the pillars rise into its place
        band = next(x for x in sl.shapes if x.name == "Obdélník 3")
        lift = int(band.height)
        for sh in [gl, band] + [x for x in sl.shapes if x.name == "Rectangle 11"]:   # the boxes, the band, its 'GOALS'
            _remove(sh)
        _move(tshape, y=int(tshape.top) - lift)
        for ic in icons:
            _move(ic, y=int(ic.top) - lift)
        rows_ = tshape.table.rows                         # the pillars grow by the band's height: same floor as before
        rows_[1].height = Emu(int(rows_[1].height) + lift // 2)
        rows_[2].height = Emu(int(rows_[2].height) + lift - lift // 2)
        tshape.height = Emu(sum(int(r.height) for r in rows_))
    keep = PILLARS[n]
    _keep_cols(tshape, keep)                              # fewer pillars: they share the house's width
    widths = [int(c.width) for c in tshape.table.columns]
    for i, ic in enumerate(icons):                        # each pillar keeps its own icon, centred over its column
        if i not in keep:
            _remove(ic)
        else:
            j = keep.index(i)
            _move(ic, x=int(tshape.left) + sum(widths[:j]) + widths[j] // 2 - int(ic.width) // 2)
    tbl = tshape.table
    for c, st in enumerate(strats):
        _cell(tbl, 1, c, str(st.get("name", "")), "priorities strategy", P_)
        _cell(tbl, 2, c, str(st.get("text", "")), "priorities strategy text", P_)
    kps = [[str(v) for v in (st.get("kpis") or []) if str(v).strip()] for st in strats]
    for st, kp in zip(strats, kps):
        if len(kp) > 2:
            P_.append(f"priorities strategy '{str(st.get('name', ''))[:20]}' has {len(kp)} KPIs - the house holds 2 a pillar")
    nk = min(2, max(len(kp) for kp in kps))
    kg = next(g for g in groups if len(g.shapes) == 12)
    kids = list(kg.shapes)
    y0 = min(k.top for k in kids)
    rows = [[k for k in kids if k.top < y0 + 0.1 * IN], [k for k in kids if k.top >= y0 + 0.1 * IN]]
    if nk == 0:                                           # no KPIs: the KPI band goes, the pillars reach the house's floor
        floor = int(kg.top) + int(kg.height)
        grow = floor - (int(tshape.top) + sum(int(r.height) for r in tbl.rows))
        for name in ("Rectangle 66", "Rectangle 3"):      # the KPI band and its 'KPIs' label
            for sh in [x for x in sl.shapes if x.name == name]:
                _remove(sh)
        _remove(kg)
        last = tbl.rows[len(tbl.rows) - 1]
        last.height = Emu(int(last.height) + max(0, grow))
        tshape.height = Emu(sum(int(r.height) for r in tbl.rows))
        _strategies_label(sl, tshape)
        return P_
    if nk == 1:                                           # one KPI a pillar: one row, centred in the band
        mid = (min(k.top for k in rows[0]) + max(k.top + k.height for k in rows[1])) // 2
        for k in rows[1]:
            _remove(k)
        for k in rows[0]:
            _move(k, y=mid - k.height // 2)
    for r, row in enumerate(rows[:nk]):
        for c, box in enumerate(_respread(row, n)):
            _put(box, kps[c][r] if r < len(kps[c]) else "-", "priorities KPI", P_)
    _strategies_label(sl, tshape)
    return P_


def _strategies_label(sl, tshape):
    """The house's turned 'STRATEGIES' label stays centred on the pillars when they move or grow."""
    lab = next((x for x in sl.shapes if x.name == "Rectangle 10"), None)
    if lab is not None:
        _move(lab, y=int(tshape.top) + int(tshape.height) // 2 - int(lab.height) // 2)


def _donut(sl, spec, P_):
    d = spec["donut"]
    items = [(str(a), float(b)) for a, b in (d.get("items") or [])]
    if not 2 <= len(items) <= 5:
        return [f"donut (slide 8) takes 2-5 parts, got {len(items)}"]
    gf = next(s for s in sl.shapes if getattr(s, "has_chart", False) and s.has_chart)
    from pptx.chart.data import CategoryChartData
    cd = CategoryChartData()
    cd.categories = [a for a, _ in items]
    unit = str(d.get("unit") or "")
    cd.add_series(str(d.get("series") or "Share"), [b for _, b in items], number_format='0"%"' if unit == "%" else "General")
    gf.chart.replace_data(cd)
    import data_slides as DS
    DS.fix_axis_ids(gf)
    ser = gf.chart._chartSpace.find(".//{http://schemas.openxmlformats.org/drawingml/2006/chart}ser")
    C = "{http://schemas.openxmlformats.org/drawingml/2006/chart}"
    pts = ser.findall(C + "dPt")
    order = ["accent2", "tx2", "accent4", "accent1", "accent3"]       # the template's colour order; part 1 keeps its tint
    for i in range(len(pts), len(items)):                              # extra parts: copy a template point, theme colour
        np_ = copy.deepcopy(pts[-1])
        np_.find(C + "idx").set("val", str(i))
        clr = np_.find(f".//{A}schemeClr")
        for ch in list(clr):
            clr.remove(ch)
        clr.set("val", order[i % len(order)])
        for ext in np_.findall(C + "extLst"):
            np_.remove(ext)
        pts[-1].addnext(np_)
        pts.append(np_)
    hexa = next(s for s in sl.shapes if s.name.startswith("Hexagon"))
    _put(hexa, str(d.get("center") or ""), "donut centre", P_, w=hexa.width * 0.66)   # the hole inside the ring
    det = list(d.get("details") or [])
    cards = sorted([s for s in sl.shapes if s.name.startswith("Rounded Rectangle")] +
                   [c for g in sl.shapes if g.shape_type is not None and "GROUP" in str(g.shape_type) for c in g.shapes
                    if c.name.startswith("Rounded Rectangle")], key=lambda s: s.left)
    if len(det) > 2:
        P_.append(f"donut takes up to 2 details (one per call-out card: 'Title: one line'), got {len(det)}")
    if len(det) < 2:                                      # fewer call-outs: their cards and leader lines go
        drop = cards[len(det):]
        for card in drop:
            grp = next((g for g in sl.shapes if g.shape_type is not None and "GROUP" in str(g.shape_type)
                        and card._element in list(g._element.iter())), None)
            if grp is not None:
                _remove(grp)
            else:
                line = min((x for x in sl.shapes if x.name.startswith("Přímá spojnice")),
                           key=lambda x: abs((x.left + x.width / 2) - (card.left + card.width / 2)), default=None)
                _remove(card)
                if line is not None:
                    _remove(line)
        cards = cards[:len(det)]
    for t, card in zip(det, cards):
        lead, rest = _split(t)
        if _words(rest) > 22:
            P_.append(f"donut detail '{lead[:20]}' is {_words(rest)} words - keep it to 22")
        _put(card, f"{lead}\n\n{rest}" if rest else lead, "donut detail", P_)
    return P_


def _results(sl, spec, P_):
    rows = list(spec["results"])
    if not 1 <= len(rows) <= 5:
        return [f"results (slide 11) takes 1-5 groups, got {len(rows)}"]
    tshape = _table(sl)
    tbl = tshape.table
    chips = sorted((s for s in sl.shapes if s.name.startswith("Obdélník")), key=lambda s: (s.top, s.left))
    per = [chips[i * 3:(i + 1) * 3] for i in range(5)]
    tint = {"green": "00B050", "on track": "00B050", "done": "00B050", "amber": "ACCENT_1", "at risk": "ACCENT_1",
            "watch": "ACCENT_1", "red": "TEXT_2", "late": "TEXT_2", "off track": "TEXT_2", "blocked": "TEXT_2"}
    for r, row in enumerate(rows, 1):
        _cell(tbl, r, 0, str(row.get("group", "")), "results group", P_)
        _cell(tbl, r, 1, str(row.get("result", "")), "results result", P_)
        _cell(tbl, r, 2, str(row.get("learning", "")), "results learning", P_)
        acts = [a if isinstance(a, (list, tuple)) else [a] for a in (row.get("actions") or [])][:3]
        if len(row.get("actions") or []) > 3:
            P_.append(f"results '{row.get('group', '')}': 3 actions per group at most")
        _cell(tbl, r, 3, "\n".join(str(a[0]) for a in acts), "results actions", P_)
        for k, chip in enumerate(per[r - 1]):
            if k < len(acts):
                st = str(acts[k][1]).lower() if len(acts[k]) > 1 else ""
                tag = str(acts[k][2]) if len(acts[k]) > 2 else ""
                set_text(chip.text_frame, tag[:3])
                if st in tint:
                    ND._set_fill(chip.fill, tint[st])
            else:
                _remove(chip)
    for r in range(len(rows) + 1, 6):                                   # unused groups: their rows and chips go
        for chip in per[r - 1]:
            _remove(chip)
    trs = tshape._element.findall(f".//{A}tr")
    for tr in trs[len(rows) + 1:]:
        tr.getparent().remove(tr)
    return P_


# ------------------------------------------------------------------------------------------- timeline slides
def _bars_on_axis(items, data, ncols, P_, what):
    ax = _axis(items, ncols, data) if items else None
    if not ax:
        P_.append(f"{what}: the plan spans more than {ncols} months / quarters - use the 'lanes' timeline style "
                  "(any span) or split the plan")
    return ax


def _gantt15(sl, spec, P_):
    items, probs = _items(spec["timeline"])
    P_ += probs
    tasks = [i for i in items if not i["milestone"]]
    if [i for i in items if i["milestone"]]:
        P_.append("template-gantt shows bars only - milestones need 'template-milestones', 'template-callouts' or 'lanes'")
    groups, over = _groups(tasks, 3)
    if over or not tasks:
        return P_ + ["template-gantt holds 1-3 workstreams with 1-2 bars each - use the 'lanes' style for more"]
    per = {g: [t for t in tasks if (t["group"] or t["name"]) == g] for g in groups}
    if any(len(v) > 2 for v in per.values()):
        P_.append("template-gantt: 2 bars per workstream at most - merge tasks or use the 'lanes' style")
    ax = _bars_on_axis(tasks, spec["timeline"], 6, P_, "template-gantt")
    if not ax:
        return P_
    starts, labels, _ = ax
    tshape = _table(sl)
    _labels_into_header(tshape.table, labels, upper=True)
    x0, widths = _grid(tshape)
    body_top = tshape.top + tshape.table.rows[0].height
    body_h = tshape.height - tshape.table.rows[0].height
    labs = sorted((s for s in sl.shapes if s.name in ("Rounded Rectangle 10", "Rounded Rectangle 3", "Rounded Rectangle 4")),
                  key=lambda s: s.top)
    bars = sorted((s for s in sl.shapes if s.name in ("Rounded Rectangle 7", "Rounded Rectangle 8", "Rounded Rectangle 9")),
                  key=lambda s: s.top)
    n = len(groups)
    rh = body_h / n
    for i, (lab, bar) in enumerate(zip(labs, bars)):
        if i >= n:
            _remove(lab); _remove(bar); continue
        g = groups[i]
        cy = body_top + rh * (i + 0.5)
        _move(lab, y=cy - lab.height / 2)
        _put(lab, g, "workstream", P_)
        ts = per[g][:2]
        bh = bar.height
        ys = [cy - bh / 2] if len(ts) == 1 else [cy - bh - 0.05 * IN, cy + 0.05 * IN]
        for t, y, b in zip(ts, ys, [bar] + ([_clone(bar)] if len(ts) > 1 else [])):
            xa = _x(t["start"], starts, x0, widths)
            xb = _x(t["end"] + timedelta(days=1), starts, x0, widths)
            w = max(xb - xa, 0.55 * IN)
            _move(b, x=min(xa, x0 + sum(widths) - w), y=y, w=w)
            _put(b, t["name"], "bar", P_, pt=_pt(b._element, 12))
    return P_


def _roadmap16(sl, spec, P_):
    items, probs = _items(spec["timeline"])
    P_ += probs
    secs, over = _groups(items, 4)
    if over or not items:
        return P_ + ["template-roadmap holds 1-4 sections with up to 4 events each - use the 'lanes' style for more"]
    ax = _bars_on_axis(items, spec["timeline"], 7, P_, "template-roadmap")
    if not ax:
        return P_
    starts, labels, _ = ax
    tshape = _table(sl)
    _labels_into_header(tshape.table, labels)
    x0, widths = _grid(tshape)
    labs = sorted((s for s in sl.shapes if s.name.startswith("Rounded Rectangle")), key=lambda s: s.top)
    pills = sorted((s for s in sl.shapes if s.name.startswith("Zaoblený")), key=lambda s: (s.top, s.left))
    rows = [pills[i * 4:(i + 1) * 4] for i in range(4)]
    top0, bot = labs[0].top, labs[-1].top + labs[-1].height
    n = len(secs)
    pitch = (bot - top0) / n
    for i, lab in enumerate(labs):
        if i >= n:
            _remove(lab)
            for p in rows[i]:
                _remove(p)
            continue
        y = top0 + pitch * i + (pitch - lab.height) / 2
        _move(lab, y=y)
        _put(lab, secs[i], "section", P_)
        evs = [e for e in items if (e["group"] or e["name"]) == secs[i]]
        if len(evs) > 4:
            P_.append(f"template-roadmap: section '{secs[i][:20]}' has {len(evs)} events - 4 at most")
        lanes_end = [None, None]
        pool = list(rows[i])
        ph = pool[0].height
        for e in evs[:4]:
            xa = _x(e["start"], starts, x0, widths)
            xb = _x(e["end"] + timedelta(days=1), starts, x0, widths)
            w = max(xb - xa, 1.0 * IN)
            xa = min(xa, x0 + sum(widths) - w)
            lane = next((k for k in (0, 1) if lanes_end[k] is None or xa >= lanes_end[k] + 0.05 * IN), None)
            if lane is None:
                P_.append(f"template-roadmap: more than 2 overlapping events in '{secs[i][:20]}' - 2 at a time at most")
                continue
            lanes_end[lane] = xa + w
            p = pool.pop(0)
            _move(p, x=xa, y=lab.top + lab.height / 2 - ph - 0.03 * IN + lane * (ph + 0.06 * IN), w=w)
            _put(p, e["name"], "event", P_)
        for p in pool:
            _remove(p)
    return P_


def _milestones17(sl, spec, P_):
    items, probs = _items(spec["timeline"])
    P_ += probs
    if not 2 <= len(items) <= 9:
        return P_ + [f"template-milestones takes 2-9 events, got {len(items)}"]
    ax = _bars_on_axis(items, spec["timeline"], 7, P_, "template-milestones")
    if not ax:
        return P_
    starts, labels, _ = ax
    tshape = _table(sl)
    _labels_into_header(tshape.table, labels)
    x0, widths = _grid(tshape)
    shapes = list(sl.shapes)
    axis_y = next(s for s in shapes if s.width > 12 * IN and s.height < 0.05 * IN).top
    dots = [s for s in shapes if 0.15 * IN < s.width < 0.25 * IN and abs(s.top + s.height / 2 - axis_y) < 0.1 * IN]
    stems = [s for s in shapes if s.width < 0.05 * IN and s.height > 0.5 * IN]
    circles = [s for s in shapes if 0.8 * IN < s.width < 1.3 * IN and abs(s.width - s.height) < 0.05 * IN   # (1z) by shape
               and s.has_text_frame and s.text_frame.text.strip() in ("Event", "")]
    years = sorted((s for s in shapes if s.has_text_frame and s.text_frame.text.strip() in ("YEAR", "")
                    and 0.8 * IN < s.width < 1.0 * IN and s.height < 0.35 * IN), key=lambda s: s.left)
    up_st = sorted((s for s in stems if s.top < axis_y), key=lambda s: s.left)
    dn_st = sorted((s for s in stems if s.top > axis_y), key=lambda s: s.left)
    up_c = sorted((s for s in circles if s.top < axis_y), key=lambda s: -s.width)
    dn_c = sorted((s for s in circles if s.top > axis_y), key=lambda s: -s.width)
    dots = sorted(dots, key=lambda s: s.left)
    used = []
    ups = [e for k, e in enumerate(items) if k % 2 == 0]
    dns = [e for k, e in enumerate(items) if k % 2 == 1]
    if len(ups) > len(up_c) or len(dns) > len(dn_c):
        return P_ + ["template-milestones: 9 events at most (5 above, 4 below the line)"]
    for evs, sts, cs in ((ups, up_st, up_c), (dns, dn_st, dn_c)):
        by_len = sorted(evs, key=lambda e: -len(e["name"]))
        circle_of = {id(e): c for e, c in zip(by_len, cs)}             # longer names get the larger circles
        for e, st in zip(evs, sts):
            cx = _x(e["start"], starts, x0, widths) + (0 if e["milestone"] else 0)
            c = circle_of[id(e)]
            d = dots.pop(0)
            _move(d, x=cx - d.width / 2)
            _move(st, x=cx - st.width / 2)
            _move(c, x=cx - c.width / 2)
            _put(c, e["name"], "event", P_, w=c.width * 0.72, h=c.height * 0.72)
            used += [d, st, c]
    for s in dots + [s for s in up_st + dn_st + up_c + dn_c if s not in used]:
        _remove(s)
    y0, y1 = items[0]["start"].year, items[-1]["start"].year
    for s, v in zip(years, (str(y0), str(y1))):
        set_text(s.text_frame, v)
    return P_


def _callouts19(sl, spec, P_):
    items, probs = _items(spec["timeline"])
    P_ += probs
    tasks = [i for i in items if not i["milestone"]]
    notes = [i for i in items if i["milestone"] or i["text"]][:2]
    groups, over = _groups(tasks, 3)
    if over or not tasks:
        return P_ + ["template-callouts holds 1-3 workstreams (one bar each) and up to 2 call-outs - use 'lanes' for more"]
    tshape = _table(sl)
    starts = [date(min(i["start"] for i in items).year, 1, 1)]
    starts = [_add_months(starts[0], k) for k in range(13)]
    if max(i["end"] for i in items) >= starts[-1]:
        return P_ + ["template-callouts shows one calendar year (Jan-Dec) - use 'lanes' for a longer plan"]
    _labels_into_header(tshape.table, [f"{d:%b}" for d in starts[:12]])
    x0, widths = _grid(tshape)
    labs = sorted((s for s in sl.shapes if s.name.startswith("Rounded Rectangle")), key=lambda s: s.top)
    bars = sorted((s for s in sl.shapes if s.name.startswith("Zaoblený")), key=lambda s: s.top)
    callouts = sorted((s for s in sl.shapes if s.shape_type is not None and "GROUP" in str(s.shape_type)), key=lambda s: s.left)
    for i, (lab, bar) in enumerate(zip(labs, bars)):
        if i >= len(groups):
            _remove(lab); _remove(bar); continue
        t = next(x for x in tasks if (x["group"] or x["name"]) == groups[i])
        _put(lab, groups[i], "workstream", P_)
        xa, xb = _x(t["start"], starts, x0, widths), _x(t["end"] + timedelta(days=1), starts, x0, widths)
        w = max(xb - xa, 0.9 * IN)
        _move(bar, x=min(xa, x0 + sum(widths) - w), w=w)
        _put(bar, t["name"], "bar", P_)
    rows = {}
    for i, g in enumerate(groups):
        bar_i = bars[i]
        rows[g] = bar_i
    for k, grp in enumerate(callouts):
        if k >= len(notes):
            _remove(grp); continue
        n = notes[k]
        host = rows.get(n["group"]) or next((b for b in bars if b._element.getparent() is not None and
                                             _span_has(b, _x(n["start"], starts, x0, widths))), None) or bars[min(k, len(groups) - 1)]
        _place_callout(grp, _x(n["start"], starts, x0, widths), host,
                       [b for b in bars[:len(groups)] if b is not host], x0, x0 + sum(widths), P_, n["name"], n["text"])
        box = max(grp.shapes, key=lambda s: s.width * s.height)
        _put(box, f"{n['name']}\n\n{n['text']}" if n["text"] else n["name"], "call-out", P_)
    return P_


def _span_has(bar, x):
    return bar.left <= x <= bar.left + bar.width


def _place_callout(grp, x, host, others, gx0, gx1, P_, name, text=""):
    """Re-lay the template call-out (dot, stem, detail box) for date x on bar `host`: the box sized to its text and put
    in the first free spot - under the host row, over it, or under a lower row; centred on the date or shifted - so
    it never covers a bar. Works in slide coordinates (the group becomes scale 1)."""
    xfrm = grp._element.find(f"{P}grpSpPr/{A}xfrm")
    off, ext = xfrm.find(A + "off"), xfrm.find(A + "ext")
    choff, chext = xfrm.find(A + "chOff"), xfrm.find(A + "chExt")
    sx = int(ext.get("cx")) / max(1, int(chext.get("cx")))
    sy = int(ext.get("cy")) / max(1, int(chext.get("cy")))
    kids = list(grp.shapes)
    stem = next(s for s in kids if "LINE" in str(s.shape_type) or s.width == 0 or s.height == 0)
    box = max((s for s in kids if s is not stem), key=lambda s: s.width * s.height)
    oval = next(s for s in kids if s is not stem and s is not box)
    ow, oh = oval.width * sx, oval.height * sy
    l_, t_, r_, b_ = _insets(box._element)
    lead, body = _pt2(box._element)
    import brand as _B
    M = _B.metrics_for(_B.current())
    tw = (_B.width_of(name, ND.BOLD, M) or len(name) * 0.55) * lead * 12700
    bw = int(min(box.width * sx, max(2.0 * IN, tw + l_ + r_ + 0.1 * IN)))
    lines = (_nlines(text, bw - l_ - r_, body, False) if text else 0)
    bh = int(t_ + b_ + lead * 1.25 * 12700 + (0.5 * body * 12700 + lines * body * 1.25 * 12700 if text else 0) + 0.06 * IN)
    cy = host.top + host.height / 2
    gap = 0.18 * IN
    def free(r):
        return not any(r[0] < o.left + o.width + 0.05 * IN and o.left - 0.05 * IN < r[0] + r[2] and
                       r[1] < o.top + o.height + 0.05 * IN and o.top - 0.05 * IN < r[1] + r[3] for o in others + [host]) \
            and r[1] >= 1.55 * IN and r[1] + r[3] <= ND.SAFE_BOTTOM
    ys = [host.top + host.height + gap, host.top - gap - bh] + sorted(
        o.top + o.height + gap for o in others if o.top > host.top)
    xs = [x - bw / 2, x - bw + 0.35 * IN, x - 0.35 * IN]
    pick = next(((cx_, cy_, bw, bh) for cy_ in ys for cx_ in (max(gx0, min(v, gx1 - bw)) for v in xs)
                 if free((cx_, cy_, bw, bh))), None)
    if pick is None:
        P_.append(f"template-callouts: the call-out '{name[:24]}' has no free space beside the bars - use one call-out "
                  "or the 'template-milestones' style")
        pick = (max(gx0, min(x - bw / 2, gx1 - bw)), host.top + host.height + gap, bw, bh)
    oval_r = (x - ow / 2, cy - oh / 2, ow, oh)
    if pick[1] > cy:
        stem_r = (x, cy + oh / 2, 0, pick[1] - (cy + oh / 2))
    else:
        stem_r = (x, pick[1] + bh, 0, (cy - oh / 2) - (pick[1] + bh))
    allr = [oval_r, stem_r, pick]
    gx, gy = min(r[0] for r in allr), min(r[1] for r in allr)
    gw = max(r[0] + r[2] for r in allr) - gx
    gh = max(r[1] + r[3] for r in allr) - gy
    for e_ in (off, choff):
        e_.set("x", str(int(gx))); e_.set("y", str(int(gy)))
    for e_ in (ext, chext):
        e_.set("cx", str(int(gw))); e_.set("cy", str(int(gh)))
    for s, r in ((oval, oval_r), (stem, stem_r), (box, pick)):
        _move(s, x=r[0], y=r[1], w=max(r[2], 0), h=max(r[3], 0))


# ------------------------------------------------------------------------------------------- KPI scorecard (slide 21)
def _tc_text(tc, text):
    """Text into a raw table cell element, keeping its template run style."""
    from pptx.table import _Cell
    set_text(_Cell(tc, None).text_frame, text)


def _scorecard(sl, spec, P_):
    s = spec["scorecard"]
    cols = list(s.get("columns") or [])
    groups = [g for g in (s.get("groups") or []) if g.get("kpis")]
    n = sum(len(g["kpis"]) for g in groups)
    if len(cols) != 3 or not 1 <= n <= 13 or len(groups) > 5:
        return [f"scorecard (slide 21) takes 3 value columns (e.g. Prior, Target, Actual), 1-5 groups and 1-13 KPIs - "
                f"got {len(cols)} columns, {len(groups)} groups, {n} KPIs"]
    tshape = next(x for x in sl.shapes if x.has_table and len(x.table.rows) > 20)
    tbl_el = tshape._element.find(f".//{A}tbl")
    trs = tbl_el.findall(A + "tr")
    tmpl = {k: copy.deepcopy(trs[k]) for k in (2, 3, 4, 5, 6, 8)}
    start_cell = {0: copy.deepcopy(trs[2].findall(A + "tc")[0]), 1: copy.deepcopy(trs[8].findall(A + "tc")[0])}
    cont_cell = {0: copy.deepcopy(trs[6].findall(A + "tc")[0]), 1: copy.deepcopy(trs[4].findall(A + "tc")[0])}
    avail = sum(int(tr.get("h")) for tr in trs[2:])
    for tr in trs[2:]:
        tbl_el.remove(tr)
    hdr = trs[0].findall(A + "tc")
    for c, title in zip((2, 4, 6), cols):
        _tc_text(hdr[c], str(title))
        if len(str(title)) > 14:
            P_.append(f"scorecard column '{title}' - keep column titles to 14 characters")
    _tc_text(trs[1].findall(A + "tc")[1], str(s.get("note") or ""))
    vh = min(int(0.42 * IN), int(avail * 0.62 / n))
    sh_ = min(int(0.2 * IN), max(int(0.11 * IN), int(avail * 0.38 / n)))
    j = 0
    status_fill = {"green": "0BA03E", "on track": "0BA03E", "done": "0BA03E", "amber": "FFC000", "at risk": "FFC000",
                   "watch": "FFC000", "red": "FF0000", "late": "FF0000", "off track": "FF0000"}
    for g in groups:
        for q, k in enumerate(g["kpis"]):
            band = j % 2
            vr = copy.deepcopy(tmpl[2 if band == 0 else 4])
            sr = copy.deepcopy(tmpl[3 if band == 0 else 5])
            vtc = vr.findall(A + "tc")
            first = copy.deepcopy(start_cell[band] if q == 0 else cont_cell[band])
            vr.replace(vtc[0], first)
            vtc = vr.findall(A + "tc")
            if q == 0:
                first.set("rowSpan", str(2 * len(g["kpis"])))
                _tc_text(first, str(g.get("name", "")))
            row = list(k) + [""] * 5
            _tc_text(vtc[1], str(row[0]))
            for c, v in zip((2, 4, 6), row[1:4]):
                _tc_text(vtc[c], str(v))
                if len(str(v)) > 8:
                    P_.append(f"scorecard value '{v}' - keep values to 8 characters ($4.6M, 31.5%, 6.2 min)")
            if len(str(row[0])) > 18:
                P_.append(f"scorecard KPI '{row[0][:24]}' - keep KPI names to 18 characters")
            stc = sr.findall(A + "tc")[7]
            fill = stc.find(f"{A}tcPr/{A}solidFill")
            st = status_fill.get(str(row[4]).strip().lower())
            if fill is not None:
                clr = fill[0]
                if st:
                    for ch in list(clr):
                        clr.remove(ch)
                    clr.tag = A + "srgbClr"
                    clr.attrib.clear()
                    clr.set("val", st)
                else:                                           # no status: the cell takes its band colour
                    band_fill = sr.findall(A + "tc")[2].find(f"{A}tcPr/{A}solidFill")
                    fill.getparent().replace(fill, copy.deepcopy(band_fill))
            vr.set("h", str(vh))
            sr.set("h", str(sh_))
            tbl_el.append(vr)
            tbl_el.append(sr)
            j += 1
        if len(str(g.get("name", ""))) > 14:
            P_.append(f"scorecard group '{g.get('name')}' - keep group names to 14 characters")
    tshape.height = Emu(sum(int(tr.get("h")) for tr in tbl_el.findall(A + "tr")))
    lists = sorted((x for x in sl.shapes if x.has_table and len(x.table.rows) == 5), key=lambda x: x.top)
    heads = sorted((x for x in sl.shapes if x.name in ("TextBox 5", "TextBox 6")), key=lambda x: x.top)
    icons = sorted((x for x in sl.shapes if x.shape_type is not None and "PICTURE" in str(x.shape_type)), key=lambda x: x.top)
    gap = heads[1].top - (lists[0].top + lists[0].height) if len(heads) == 2 else int(0.08 * IN)
    for lst, vals in zip(lists, (s.get("lowlights") or [], s.get("highlights") or [])):
        vals = [str(v) for v in vals][:5]
        if not vals:
            P_.append("scorecard needs at least one lowlight and one highlight (what is not working / what is)")
            vals = [""]
        el = lst._element.find(f".//{A}tbl")
        rows = el.findall(A + "tr")
        for r, v in zip(rows, vals):
            _tc_text(r.findall(A + "tc")[0], v)
            if _words(v) > 12:
                P_.append(f"scorecard note '{v[:30]}…' is {_words(v)} words - keep each to 12")
        for r in rows[len(vals):]:
            el.remove(r)
        lst.height = Emu(sum(int(r.get("h")) for r in el.findall(A + "tr")))     # template row height, no stretching
    if len(heads) == 2 and len(icons) >= 2:                                        # highlights follow the lowlights
        dy = (lists[0].top + lists[0].height + gap) - heads[1].top
        for x in (heads[1], icons[-1], lists[1]):
            _move(x, y=x.top + dy)
    return P_


# ------------------------------------------------------------------------------------------- US map (slide 22)
STATES = {"AL": (32.8, -86.8), "AZ": (34.2, -111.7), "AR": (34.9, -92.4), "CA": (37.2, -119.5), "CO": (39.0, -105.5),
          "CT": (41.6, -72.7), "DE": (39.0, -75.5), "FL": (28.6, -82.4), "GA": (32.7, -83.4), "ID": (44.4, -114.6),
          "IL": (40.0, -89.2), "IN": (39.9, -86.3), "IA": (42.1, -93.5), "KS": (38.5, -98.4), "KY": (37.5, -85.3),
          "LA": (31.0, -92.0), "ME": (45.4, -69.2), "MD": (39.0, -76.8), "MA": (42.3, -71.8), "MI": (43.6, -84.7),
          "MN": (46.3, -94.3), "MS": (32.7, -89.7), "MO": (38.4, -92.5), "MT": (47.0, -109.6), "NE": (41.5, -99.8),
          "NV": (39.3, -116.6), "NH": (43.7, -71.6), "NJ": (40.2, -74.7), "NM": (34.4, -106.1), "NY": (42.9, -75.5),
          "NC": (35.6, -79.4), "ND": (47.5, -100.5), "OH": (40.3, -82.8), "OK": (35.6, -97.5), "OR": (43.9, -120.6),
          "PA": (40.9, -77.8), "RI": (41.7, -71.5), "SC": (33.9, -80.9), "SD": (44.4, -100.2), "TN": (35.9, -86.4),
          "TX": (31.5, -99.3), "UT": (39.3, -111.7), "VT": (44.1, -72.7), "VA": (37.5, -78.9), "WA": (47.4, -120.5),
          "WV": (38.6, -80.6), "WI": (44.6, -89.9), "WY": (43.0, -107.6), "DC": (38.9, -77.0)}
CITIES = {"new york": (40.71, -74.0), "los angeles": (34.05, -118.24), "chicago": (41.88, -87.63), "houston": (29.76, -95.37),
          "phoenix": (33.45, -112.07), "philadelphia": (39.95, -75.17), "san antonio": (29.42, -98.49),
          "san diego": (32.72, -117.16), "dallas": (32.78, -96.8), "austin": (30.27, -97.74), "jacksonville": (30.33, -81.66),
          "fort worth": (32.76, -97.33), "columbus": (39.96, -83.0), "charlotte": (35.23, -80.84), "indianapolis": (39.77, -86.16),
          "san francisco": (37.77, -122.42), "seattle": (47.61, -122.33), "denver": (39.74, -104.99), "nashville": (36.16, -86.78),
          "washington": (38.91, -77.04), "boston": (42.36, -71.06), "las vegas": (36.17, -115.14), "portland": (45.52, -122.68),
          "detroit": (42.33, -83.05), "memphis": (35.15, -90.05), "louisville": (38.25, -85.76), "baltimore": (39.29, -76.61),
          "milwaukee": (43.04, -87.91), "albuquerque": (35.08, -106.65), "tucson": (32.22, -110.97), "atlanta": (33.75, -84.39),
          "kansas city": (39.1, -94.58), "miami": (25.76, -80.19), "orlando": (28.54, -81.38), "tampa": (27.95, -82.46),
          "minneapolis": (44.98, -93.27), "cleveland": (41.5, -81.69), "new orleans": (29.95, -90.07), "st. louis": (38.63, -90.2),
          "saint louis": (38.63, -90.2), "pittsburgh": (40.44, -80.0), "cincinnati": (39.1, -84.51), "salt lake city": (40.76, -111.89),
          "raleigh": (35.78, -78.64), "sacramento": (38.58, -121.49), "oklahoma city": (35.47, -97.52), "omaha": (41.26, -95.93),
          "bolingbrook": (41.7, -88.07), "romeoville": (41.65, -88.09), "phoenix area": (33.45, -112.07),
          "greenwood": (39.61, -86.11), "fresno": (36.74, -119.79), "dayton": (39.76, -84.19), "jackson": (32.3, -90.18),
          "birmingham": (33.52, -86.8), "richmond": (37.54, -77.44), "boise": (43.62, -116.2), "spokane": (47.66, -117.43),
          "honolulu": None, "anchorage": None}
MAP_COEF = [[1392.643, -90.745], [-50.106, -1398.53], [522.191, 348.312]]   # Albers -> template map pixels (1000 x 644)


def _albers(lat, lon, lat1=29.5, lat2=45.5, lat0=37.5, lon0=-96.0):
    import math
    r = math.radians
    n = (math.sin(r(lat1)) + math.sin(r(lat2))) / 2
    C = math.cos(r(lat1)) ** 2 + 2 * n * math.sin(r(lat1))
    rho = lambda la: math.sqrt(C - 2 * n * math.sin(r(la))) / n
    th = n * r(lon - lon0)
    return rho(lat) * math.sin(th), rho(lat0) - rho(lat) * math.cos(th)


def locate(place):
    """(lat, lon) for 'Dallas, TX', 'Texas', 'TX', or {"lat", "lon"}; None when unknown or outside the lower 48."""
    if isinstance(place, dict) and "lat" in place:
        return float(place["lat"]), float(place["lon"])
    s = str(place or "").strip()
    city, _, st = s.partition(",")
    key = city.strip().lower()
    if key in CITIES:
        return CITIES[key]
    names = {"alabama": "AL", "arizona": "AZ", "arkansas": "AR", "california": "CA", "colorado": "CO", "connecticut": "CT",
             "delaware": "DE", "florida": "FL", "georgia": "GA", "idaho": "ID", "illinois": "IL", "indiana": "IN", "iowa": "IA",
             "kansas": "KS", "kentucky": "KY", "louisiana": "LA", "maine": "ME", "maryland": "MD", "massachusetts": "MA",
             "michigan": "MI", "minnesota": "MN", "mississippi": "MS", "missouri": "MO", "montana": "MT", "nebraska": "NE",
             "nevada": "NV", "new hampshire": "NH", "new jersey": "NJ", "new mexico": "NM", "new york state": "NY",
             "north carolina": "NC", "north dakota": "ND", "ohio": "OH", "oklahoma": "OK", "oregon": "OR", "pennsylvania": "PA",
             "rhode island": "RI", "south carolina": "SC", "south dakota": "SD", "tennessee": "TN", "texas": "TX", "utah": "UT",
             "vermont": "VT", "virginia": "VA", "washington state": "WA", "west virginia": "WV", "wisconsin": "WI", "wyoming": "WY"}
    for cand in (st.strip().upper(), key.upper(), names.get(key, ""), names.get(st.strip().lower(), "")):
        if cand in STATES:
            return STATES[cand]
    return None


def _map(sl, spec, P_):
    places = list(spec["map"])
    if not 1 <= len(places) <= 4:
        return [f"map (slide 22) takes 1-4 locations, got {len(places)} - more than 4 is a table or a chart by region"]
    pic = max((s for s in sl.shapes if s.shape_type is not None and "PICTURE" in str(s.shape_type)), key=lambda s: s.width)
    pins = sorted((s for s in sl.shapes if s.shape_type is not None and "GROUP" in str(s.shape_type)), key=lambda s: s.left)
    labels = sorted((s for s in sl.shapes if s.name.startswith("Pentagon")), key=lambda s: s.left)
    texts = sorted((s for s in sl.shapes if s.name.startswith("TextBox")), key=lambda s: s.left)
    spots = []
    for p in places:
        p = p if isinstance(p, dict) else {"place": p}
        ll = locate(p if "lat" in p else p.get("place"))
        if ll is None:
            P_.append(f"map: '{p.get('place')}' is not a known US city or state - write 'City, ST' (e.g. 'Dallas, TX') "
                      "or give lat / lon; Alaska and Hawaii are not on the template map")
            continue
        X, Y = _albers(*ll)
        px = X * MAP_COEF[0][0] + Y * MAP_COEF[1][0] + MAP_COEF[2][0]
        py = X * MAP_COEF[0][1] + Y * MAP_COEF[1][1] + MAP_COEF[2][1]
        spots.append((pic.left + px / 1000 * pic.width, pic.top + py / 644 * pic.height, p))
    spots.sort(key=lambda t: t[0])
    for k, (pin, lab, txt) in enumerate(zip(pins, labels, texts)):
        if k >= len(spots):
            _remove(pin); _remove(lab); _remove(txt); continue
        x, y, p = spots[k]
        xfrm = pin._element.find(f"{P}grpSpPr/{A}xfrm")
        off, ext = xfrm.find(A + "off"), xfrm.find(A + "ext")
        off.set("x", str(int(x - int(ext.get("cx")) / 2)))
        off.set("y", str(int(y - int(ext.get("cy")))))                  # the pin's tip sits on the place
        lx = min(max(int(x - 0.3 * IN), int(0.4 * IN)), int(12.9 * IN) - lab.width - int(0.1 * IN))
        name = str(p.get("label") or str(p.get("place", "")).split(",")[0])
        _put(lab, name, "map label", P_)
        _put(txt, str(p.get("text") or ""), "map text", P_)
        l_, t_, r_, b_ = _insets(txt._element)                  # the text block shrinks to its lines
        need = _nlines(str(p.get("text") or ""), txt.width - l_ - r_, _pt(txt._element, 12), False) * 12 * 1.2 * 12700 + t_ + b_
        th = max(int(need), int(0.3 * IN))
        block = lab.height + 0.06 * IN + th
        pin_h = int(ext.get("cy"))
        top = y + 0.08 * IN if y + 0.08 * IN + block <= ND.SAFE_BOTTOM else y - pin_h - 0.06 * IN - block   # below the pin, else above
        _move(lab, x=lx, y=top)
        _move(txt, x=lx + 0.08 * IN, y=top + lab.height + 0.06 * IN, h=th)
        if _words(p.get("text")) > 12:
            P_.append(f"map text for '{name}' is {_words(p.get('text'))} words - keep it to 12")
    for a, b in zip(spots, spots[1:]):
        if b[0] - a[0] < 1.55 * IN and abs(b[1] - a[1]) < 1.5 * IN:
            P_.append(f"map: '{a[2].get('place')}' and '{b[2].get('place')}' are too close for their labels - pick places "
                      "further apart or show regions in a chart")
    return P_


def reroute(spec):
    """A count the template slide cannot hold goes on the nearest layout that can (said in a note) instead of failing:
    2-3 big numbers on the headline-metrics row, 5-6 funnel stages as the drawn funnel."""
    if not isinstance(spec, dict):
        return spec
    q = spec.get("quad")
    if isinstance(q, list) and 2 <= len(q) <= 3:
        print(f"note: {len(q)} big numbers go on the headline-metrics row (the four-number slide holds exactly 4)")
        return {k: v for k, v in spec.items() if k != "quad"} | {"source": "headline-metrics", "table": [list(q)]}
    f = spec.get("funnel")
    if isinstance(f, list) and 5 <= len(f) <= 6:
        items = [x if isinstance(x, str) else f"{x.get('stage') or x.get('name') or ''}: {x.get('text') or ''}" for x in f]
        print(f"note: a {len(f)}-stage funnel is drawn as a funnel graphic (the template's funnel holds 3-4 stages)")
        return {k: v for k, v in spec.items() if k != "funnel"} | {"graphic": "funnel", "items": items}
    return spec


# ------------------------------------------------------------------------------------------- dispatch
FILLERS = {"quad": _quad, "funnel": _funnel, "journey": _journey, "ogsm": _ogsm, "priorities": _priorities,
           "donut": _donut, "results": _results, "scorecard": _scorecard, "map": _map}
TIMELINE_FILL = {"template-gantt": _gantt15, "template-roadmap": _roadmap16, "template-milestones": _milestones17,
                 "template-callouts": _callouts19, "journey": _journey}


def _headline(slide, text):
    """The slide title: the template's top placeholder (some infographic slides carry a sample title such as 'OGSM
    Template' instead of the 'Insert headline' marker), widened to the content width like every content slide."""
    phs = [s for s in slide.shapes if s.is_placeholder and s.has_text_frame and (s.top or 0) < 1.2 * IN]
    if not phs:
        return []
    h = min(phs, key=lambda s: s.top or 0)
    if text:
        set_text(h.text_frame, str(text))
    W = slide.part.package.presentation_part.presentation.slide_width
    left, top, hh = h.left, h.top, h.height
    wide = W - 2 * left
    band = int(0.50 * IN)                                  # the one-line title's own height, not its tall box (a frame
    clash = [s for s in slide.shapes if s is not h and s.top is not None and s.top < top + band and s.top + s.height > top
             and s.left < left + wide and s.left + s.width > left + h.width]   # starting just under it, like a chart's, is clear)
    h.left, h.top, h.height, h.width = left, top, hh, (h.width if clash else wide)   # never over the template's art
    if clash and text:                                     # the art beside the title (the vision house's roof) stays clear
        import brand as _B
        import typeset as _T
        face, pt = _T.spec()["headline"][:2]
        if not _T.headline_fits(str(text), int(h.width), pt, face, _B.current()):
            return [f"the title sits left of the slide's artwork and holds about 20 characters: '{str(text)[:40]}' is too "
                    "long - use a short name such as '2026 Priorities' and let the slide's own text carry the message"]
    return []


def fill(slide, fam, style, spec):
    """Fill template slide `slide`: fam 'timeline' (style = a TEMPLATE_STYLES name) or 'infographic' (style = a KEYS key)."""
    P_ = _headline(slide, spec.get("headline"))
    try:
        return (TIMELINE_FILL[style] if fam == "timeline" else FILLERS[style])(slide, spec, P_)
    except (KeyError, IndexError, TypeError, ValueError, StopIteration, AttributeError) as e:
        return P_ + [f"{style}: the content is not in the expected shape ({type(e).__name__}: {str(e)[:80]}) - "
                     "see the keys in python tools/template_infographics.py"]


def lint(fam, style, spec):
    """Pre-build checks for the template styles (fill() measures every text against the template boxes)."""
    if fam == "timeline" and style in TIMELINE_FILL and style != "journey":
        items, probs = _items(spec.get("timeline") or {})
        return probs + ([] if items else [f"{style}: the timeline has no dated items"])
    return []


def as_flow(spec):
    """A dated-flow timeline as the template's flow slide (20): 3-5 dated steps, the date as each step's label."""
    items, _ = _items(spec.get("timeline") or {})
    steps = [{"label": f"{i['start']:%b} {i['start'].day}", "text": i["name"]} for i in items]
    return {k: v for k, v in spec.items() if k not in ("timeline", "style")} | {"source": 20, "steps": steps}


def sample(fam):
    """One storyboard slide per template style (gallery decks: build_deck.py timelines / infographics)."""
    if fam == "timeline":
        return [
            {"timeline": {"items": [
                {"name": "Design and build", "group": "Digital", "start": "2026-01-12", "end": "2026-03-20"},
                {"name": "App release", "group": "Digital", "start": "2026-03-30", "end": "2026-05-15"},
                {"name": "Pilot in 40 stores", "group": "Stores", "start": "2026-02-16", "end": "2026-04-24"},
                {"name": "Associate training", "group": "People", "start": "2026-03-02", "end": "2026-05-29"}]},
             "style": "template-gantt", "headline": "Pilot Feb-Apr; app ships in May",
             "notes": "Template slide 15 (workstream Gantt)."},
            {"timeline": {"items": [
                {"name": "Vendor shortlist", "group": "Sourcing", "start": "2026-01-05", "end": "2026-02-13"},
                {"name": "Contracts", "group": "Sourcing", "start": "2026-03-02", "end": "2026-04-17"},
                {"name": "Data model", "group": "Platform", "start": "2026-01-19", "end": "2026-03-27"},
                {"name": "Integration tests", "group": "Platform", "start": "2026-04-06", "end": "2026-06-26"},
                {"name": "Store comms", "group": "Change", "start": "2026-05-04", "end": "2026-07-10"},
                {"name": "Go-live support", "group": "Change", "start": "2026-06-15", "end": "2026-07-24"}]},
             "style": "template-roadmap", "headline": "Six workstreams converge on a July go-live",
             "notes": "Template slide 16 (section roadmap)."},
            {"timeline": {"items": [
                {"name": "Kick-off", "date": "2026-01-15"}, {"name": "Design sign-off", "date": "2026-02-26"},
                {"name": "Build done", "date": "2026-04-10"}, {"name": "Pilot", "date": "2026-05-14"},
                {"name": "Go / no-go", "date": "2026-06-04"}, {"name": "Launch", "date": "2026-06-25"},
                {"name": "Review", "date": "2026-07-23"}]},
             "style": "template-milestones", "headline": "Seven milestones; launch on June 25",
             "notes": "Template slide 17 (milestones on a line)."},
            {"timeline": {"items": [
                {"name": "Loyalty app refresh", "group": "Digital", "start": "2026-01-12", "end": "2026-06-26"},
                {"name": "Store rollout", "group": "Stores", "start": "2026-04-06", "end": "2026-11-20"},
                {"name": "Holiday readiness", "group": "Supply", "start": "2026-07-06", "end": "2026-10-30"},
                {"name": "Beta to 50K members", "date": "2026-03-16", "milestone": True,
                 "text": "Gate: crash-free rate above 99.5%"},
                {"name": "All stores live", "date": "2026-09-14", "milestone": True,
                 "text": "1,400 stores before peak season"}]},
             "style": "template-callouts", "headline": "All stores live by mid-September, ahead of peak",
             "notes": "Template slide 19 (year Gantt with call-outs)."},
            {"timeline": {"items": [
                {"name": "2024", "date": "2024-01-01", "text": "One guest view: loyalty, ulta.com and stores share one profile."},
                {"name": "2025 Scale", "date": "2025-01-01", "text": "Personal offers in every channel; 40% of sales from members who shop two channels."},
                {"name": "2026 Lead", "date": "2026-01-01", "text": "Predictive replenishment and services booking in the app; the guest plans the visit."}]},
             "style": "journey", "headline": "Three years to a guest-led visit",
             "notes": "Template slide 18 (three stages that grow)."},
            {"timeline": {"items": [
                {"name": "Scope agreed with store ops", "date": "2026-03-02"}, {"name": "Pilot stores trained", "date": "2026-03-09"},
                {"name": "Pilot live in 12 stores", "date": "2026-03-16"}, {"name": "Results to steering group", "date": "2026-03-30"}]},
             "style": "dated-flow", "headline": "Four weeks from scope to pilot results",
             "notes": "Template slide 20 (dated flow)."}]
    if fam == "infographic":
        return [
            {"quad": ["$4.6M\nnet sales in October", "31.5%\nconversion, best this year", "6.2 min\naverage handle time",
                      "1.6%\nshrink, above plan"], "headline": "Sales and conversion up; shrink needs attention",
             "notes": "Template slide 13 (four big numbers)."},
            {"funnel": ["Visit: 1.2M site and app sessions", "Consider: 310K product page views",
                        "Basket: 96K carts started", "Buy: 41K orders, 3.4% conversion"],
             "headline": "One in three baskets is lost before checkout", "notes": "Template slide 26 (funnel)."},
            {"donut": {"items": [["Stores", 72], ["Online", 28]], "unit": "%", "center": "Net sales",
                       "details": ["Stores: 72% of sales, flat on last year", "Online: 28% of sales, up 4 pts on last year"]},
             "headline": "Online is 28% of sales and growing 4 pts a year", "notes": "Template slide 8 (share and call-outs)."},
            {"results": [
                {"group": "Stores", "result": "Sales +4% vs plan", "learning": "Weekend hours lift conversion",
                 "actions": [["Extend Sunday hours", "green", "RP"], ["Retrain closing leads", "amber", "SK"]]},
                {"group": "Digital", "result": "App orders +12%", "learning": "Push offers beat e-mail 2 to 1",
                 "actions": [["Move offers to push", "green", "MC"], ["Fix checkout crash", "red", "TL"]]},
                {"group": "Supply", "result": "On-shelf 97.8%", "learning": "Fragrance runs out on Fridays",
                 "actions": [["Friday top-up", "amber", "LP"]]}],
             "headline": "Stores and app beat plan; one fix is late", "notes": "Template slide 11."},
            {"scorecard": {"columns": ["Prior", "Target", "Actual"], "note": "vs target",
                           "groups": [{"name": "Sales", "kpis": [["Net sales", "$4.2M", "$4.5M", "$4.6M", "green"],
                                                                 ["Conversion", "30.7%", "32.0%", "31.5%", "amber"]]},
                                      {"name": "Service", "kpis": [["Handle time", "6.8 min", "6.0 min", "6.2 min", "amber"],
                                                                   ["NPS", "61", "65", "67", "green"]]},
                                      {"name": "Ops", "kpis": [["Shrink", "1.4%", "1.4%", "1.6%", "red"],
                                                               ["On-shelf", "97.1%", "98.0%", "97.8%", "amber"]]}],
                           "lowlights": ["Shrink 0.2 pts over target", "Conversion 0.5 pts under target"],
                           "highlights": ["Net sales $4.6M, 2% ahead", "NPS 67, best in two years", "Handle time down 9%"]},
             "headline": "Sales and NPS ahead; shrink is the one red KPI", "notes": "Template slide 21 (KPI scorecard)."},
            {"priorities": {"vision": "Be the guest's first choice for beauty, in store and online",
                            "goals": ["Grow member sales 8%", "Lead in services", "Run lean and safe"],
                            "strategies": [
                                {"name": "Personal offers", "text": "Offers from purchase history in every channel", "kpis": ["Offer use 25%", "Member sales +8%"]},
                                {"name": "Services", "text": "Book any salon service in the app", "kpis": ["Bookings +15%", "Rebook 60%"]},
                                {"name": "Assortment", "text": "Local ranges for 300 stores", "kpis": ["Sell-through +5%", "Markdowns -10%"]},
                                {"name": "Fulfilment", "text": "Same-day pickup in every store", "kpis": ["Pickup in 2 h", "Cancels < 2%"]},
                                {"name": "People", "text": "Beauty advisor career paths", "kpis": ["Turnover -5 pts", "Training 95%"]},
                                {"name": "Efficiency", "text": "Automate store reporting", "kpis": ["Hours saved 6/wk", "Cost -3%"]}]},
             "headline": "2026 priorities", "notes": "Template slide 24 (priorities house)."},
            {"ogsm": {"objective": "Make Ulta the first choice for beauty services by 2027",
                      "goals": ["Grow services sales 15%", "Rebook 60% of guests", "NPS 70 for services"],
                      "strategies": [{"title": "Book anywhere", "text": "App and web booking for every service, with reminders."},
                                     {"title": "Grow talent", "text": "Stylist career paths and education in every region."},
                                     {"title": "Bundle", "text": "Pair services with products in member offers."}],
                      "measures": [{"title": "Bookings", "value": "+15%", "text": "vs last year"},
                                   {"title": "Rebook", "value": "60%", "text": "of guests"},
                                   {"title": "NPS", "value": "70", "text": "services"}]},
             "headline": "One objective, three goals, measured monthly", "notes": "Template slide 25 (OGSM)."},
            {"map": [{"place": "Seattle, WA", "text": "Pilot: 12 stores, same-day pickup"},
                     {"place": "Dallas, TX", "text": "Largest region: 140 stores"},
                     {"place": "Chicago, IL", "text": "Distribution centre opens May"},
                     {"place": "Orlando, FL", "text": "Services growth +18%"}],
             "headline": "Four regions lead the rollout", "notes": "Template slide 22 (map with pins)."}]
    return []


# ------------------------------------------------------------------------------------------- fidelity gate
STATUSLIKE = {"00B050", "0BA03E", "FFC000", "FF0000", "accent1", "accent3", "tx2"}


def _norm(el):
    """A shape's design without its content: text, position / size, text insets, ids and alt text removed; status fills
    tokenised."""
    e = copy.deepcopy(el)
    for tx in list(e.iter(A + "p")):
        tx.getparent().remove(tx)
    for x in list(e.iter(A + "xfrm")) + list(e.iter(P + "xfrm")):
        x.getparent().remove(x)
    for bp in e.iter(A + "bodyPr"):                       # text insets: where the text sits in its shape, like position
        for k in ("lIns", "tIns", "rIns", "bIns"):
            bp.attrib.pop(k, None)
    for tr in list(e.iter(A + "tr")):
        tr.getparent().remove(tr)
    for c in e.iter(P + "cNvPr"):
        for k in ("id", "descr", "title"):
            c.attrib.pop(k, None)
        for x in list(c):
            c.remove(x)                                   # creation ids, the accessibility 'decorative' flag
    R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    for x in e.iter():
        for k in [k for k in x.attrib if k.startswith(R)]:
            del x.attrib[k]                               # picture / chart links are renumbered on every copy
    for tp in e.iter(A + "tblPr"):
        for k in ("firstRow", "bandRow", "firstCol", "lastRow", "lastCol", "bandCol"):
            tp.attrib.pop(k, None)
    for clr in list(e.iter(A + "srgbClr")) + list(e.iter(A + "schemeClr")):
        if clr.get("val") in STATUSLIKE:                  # a status mark may take any of the template's status colours
            tok = etree.Element(A + "statusClr")
            clr.getparent().replace(clr, tok)
    for g in list(e.iter(A + "tblGrid")):                  # a table may keep fewer of its columns (each cell is checked)
        for c in list(g):
            g.remove(c)
    if etree.QName(e).localname == "grpSp":                # a group: its own frame; its shapes are checked one by one
        for c in list(e):
            if etree.QName(c).localname in ("sp", "grpSp", "graphicFrame", "pic", "cxnSp"):
                e.remove(c)
    etree.cleanup_namespaces(e)
    return etree.tostring(e, method="c14n")


def _shapes_in(tree):
    """Every shape of a slide tree, group members included, with its name."""
    out = []
    for el in tree:
        if etree.QName(el).localname in ("sp", "grpSp", "graphicFrame", "pic", "cxnSp"):
            out.append((next((c.get("name") for c in el.iter(P + "cNvPr")), ""), el))
            if etree.QName(el).localname == "grpSp":
                out += _shapes_in(el)
    return out


def fidelity(deck, mapping, slides):
    """Problems for template infographic slides: a shape that is not one of its template slide's shapes, or one whose
    design (fill, outline, effects, type style) changed. Text, position, size and status fills may change."""
    import zipfile
    import brand as _B
    probs = []
    z, rz = zipfile.ZipFile(str(deck)), zipfile.ZipFile(str(_B.current().template))

    def parts(zz):
        import re as _re
        pres = zz.read("ppt/presentation.xml").decode()
        rels = zz.read("ppt/_rels/presentation.xml.rels").decode()
        rid = {}
        for m in _re.finditer(r"<Relationship\b([^>]*)/?>", rels):
            a = m.group(1)
            i_, t_ = _re.search(r'Id="([^"]+)"', a), _re.search(r'Target="([^"]+)"', a)
            if i_ and t_:
                rid[i_.group(1)] = "ppt/" + t_.group(1).lstrip("/").replace("ppt/", "")
        return [rid[r] for r in _re.findall(r'<p:sldId [^>]*r:id="([^"]+)"', pres)]
    built, ref = parts(z), parts(rz)
    for i in slides:
        src = mapping[i - 1]
        bx = etree.fromstring(z.read(built[i - 1])).find(f".//{P}cSld/{P}spTree")
        rx = etree.fromstring(rz.read(ref[src - 1])).find(f".//{P}cSld/{P}spTree")
        pool = {}
        for nm, el in _shapes_in(rx):
            pool.setdefault(nm, set()).add(_norm(el))
        for nm, el in _shapes_in(bx):
            if nm in ("ULTA summary", "ULTA decision", "ULTA takeaway") or nm.startswith("ULTA icon "):   # overlays: summary layer, Studio takeaway, pictograms
                continue
            if nm not in pool:
                probs.append(f"slide {i}: '{nm}' is not a shape of template slide {src} - template infographics only use "
                             "the template's own shapes")
            elif _norm(el) not in pool[nm]:
                probs.append(f"slide {i}: '{nm}' looks different from template slide {src} (fill, outline or type style "
                             "changed)")
    return probs


if __name__ == "__main__":
    print(__doc__)
