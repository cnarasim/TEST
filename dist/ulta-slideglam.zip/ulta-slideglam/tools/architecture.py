"""Interactive HTML + editable draw.io architecture (modules/ultaarchitecturebuilder), in the active brand.

    python tools/architecture.py input.json --out /mnt/data/out/<Name> [--overview overview.json]
        -> <Name>.html (interactive: search, filters, focused flow views) and <Name>.drawio, both on brand

The module's scripts are run unchanged (they stay hash-pinned); this tool then re-themes their output:
- flow status line colours get a deliberate brand mapping (documented = dark accent, observed = brand orange,
  draft/proposed = berry dashed, historical = grey dashed, disabled = status red dashed) so they stay distinct;
- every other colour goes to the nearest brand colour (ulta_conform), fonts become the brand fonts;
- the HTML gets the brand's gradient bar and logo.
Input format: modules/ultaarchitecturebuilder/references/schema.md.
"""
import argparse, base64, re, subprocess, sys
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
ROOT = TOOLS.parent
sys.path.insert(0, str(TOOLS))
import brand as B   # noqa: E402

MOD = ROOT / "modules" / "ultaarchitecturebuilder" / "scripts"
KIT_LOGO = ROOT / "modules" / "ultabranddeliverables" / "scripts" / "kit" / "infographic" / "ulta-logo.svg"

# the module's own status colours (html + overview) and draw.io accent -> brand roles
STATUS = {"286080": "dark", "347466": "orange", "865EAD": "berry", "8A6A3D": "grey", "B04444": "red", "0057A8": "dark"}


def brand_colours(b):
    pal = b.get("palette") or {}
    brand = [c.upper() for c in pal.get("brand") or []]
    pick = lambda want, fb: next((c for c in brand if c.upper() == want), fb)
    return {"dark": b.ui("dark_accent"), "orange": pick("E0531B", brand[0] if brand else "E0531B"),
            "berry": pick("C10060", brand[-1] if brand else "C10060"), "grey": "404040",
            "red": (pal.get("status") or ["", "", "FF0000"])[-1] or "FF0000"}


def retheme(path, b, logo=True):
    t = path.read_text(encoding="utf-8")
    roles = brand_colours(b)
    for src, role in STATUS.items():
        t = re.sub("#" + src, "#" + roles[role], t, flags=re.I)
    head, body = b.font("heading"), b.font("body")
    fam = lambda f: re.sub(r"\s+(Book|Regular|Black|Bold|Medium|Light)$", "", f)
    t = t.replace("font-family:Arial,sans-serif", f"font-family:'{fam(body)}',Arial,sans-serif")
    t = t.replace("Georgia,serif", f"'{fam(head)}',Georgia,serif")
    t = re.sub(r'fontFamily=Helvetica', f"fontFamily={fam(body)}", t)
    if path.suffix == ".drawio":                         # the module draws neutral boxes: give them the brand look
        dark, tint = b.ui("dark_accent"), b.ui("light_tint")
        t = re.sub(r"fillColor=#FAFAFA", f"fillColor=#{tint}", t, flags=re.I)
        t = re.sub(r"strokeColor=#777777", f"strokeColor=#{dark}", t, flags=re.I)
        t = re.sub(r"strokeColor=#333333", f"strokeColor=#{roles['orange']}", t, flags=re.I)
        t = re.sub(r"fontColor=#202020(;fontSize=2\d;[^\"]*fontStyle=1)", f"fontColor=#{dark}\\1", t)
        t = re.sub(r"fontColor=#202020", "fontColor=#404040", t, flags=re.I)
    if path.suffix == ".html" and logo:
        pal = [c.upper() for c in (b.get("palette") or {}).get("brand") or []] or ["F26923", "E8275A", "C10060"]
        grad = ",".join("#" + c for c in (pal[5] if len(pal) > 5 else pal[0], pal[1] if len(pal) > 1 else pal[0], pal[-1]))
        lg = brand_logo(b)
        css = (f"body{{border-top:8px solid transparent;border-image:linear-gradient(90deg,{grad}) 1}}"
               "header{position:relative;padding-right:150px}"
               ".brand-logo{position:absolute;top:14px;right:8px;height:42px;width:104px;object-fit:contain}"
               "h1{color:#" + b.ui("dark_accent") + "}")
        if "</style>" in t:                                  # the module's own style block (it has no </head>)
            t = t.replace("</style>", css + "</style>", 1)
        else:
            t = t.replace("<body", "<style>" + css + "</style><body", 1)
        if lg:
            t = re.sub(r"(<header[^>]*>)", r"\1" + f'<img class="brand-logo" alt="{b.name.title()} logo" src="{lg}">', t, count=1)
    path.write_text(t, encoding="utf-8")


def brand_logo(b):
    cand = sorted((ROOT / "brands" / b.name).glob("logo*.svg")) + sorted((ROOT / "brands" / b.name).glob("logo*.png"))
    p = cand[0] if cand else (KIT_LOGO if b.name == "ulta" and KIT_LOGO.exists() else None)
    if not p:
        return None
    mime = "image/svg+xml" if p.suffix == ".svg" else "image/png"
    return f"data:{mime};base64," + base64.b64encode(p.read_bytes()).decode()


LIMITS = (("title", 72), ("scope", 195))           # what the pinned draw.io builder keeps before cutting with '…'


def too_long(path):
    """FAIL lines for text the (hash-pinned, unchanged) builder would cut: shorten it instead of shipping '…'."""
    import json
    try:
        d = json.loads(Path(path).read_text(encoding="utf-8"))
    except Exception:
        return []
    out = [f"FAIL {k} is {len(str(d.get(k)))} characters (the diagram keeps {n}) - shorten it"
           for k, n in LIMITS if len(str(d.get(k) or "")) > n]
    out += [f"FAIL system '{str(x.get('label'))[:40]}' is {len(str(x.get('label')))} characters (keeps 110) - shorten it"
            for x in d.get("nodes") or [] if len(str(x.get("label") or "")) > 110]
    out += [f"FAIL flow {x.get('id')} label is {len(str(x.get('label')))} characters (keeps 72) - shorten it"
            for x in d.get("flows") or [] if len(str(x.get("label") or "")) > 72]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input"); ap.add_argument("--out", required=True); ap.add_argument("--overview")
    a = ap.parse_args()
    out = Path(a.out); out.parent.mkdir(parents=True, exist_ok=True)
    b = B.current()
    extra = ["--overview", a.overview] if a.overview else []
    html, drawio = out.with_suffix(".html"), out.with_suffix(".drawio")
    for script, dst in (("ulta_architecture_html.py", html), ("ulta_architecture_xml.py", drawio)):
        r = subprocess.run([sys.executable, "-I", str(MOD / script), a.input, str(dst), *extra,
                            "--report", str(out.parent / (out.name + f"-{dst.suffix[1:]}-build.json"))],
                           capture_output=True, text=True)
        if not dst.exists():
            sys.exit(f"{script} failed: {(r.stdout + r.stderr).strip()[-500:]}")
    import plain                                         # plain punctuation: no em dashes in what a reader sees
    for f in (html, drawio):
        retheme(f, b); plain.clean(f)
    import htmlpdf
    htmlpdf.ensure(html)                                 # every delivered HTML can be saved as a PDF
    c = subprocess.run([sys.executable, str(TOOLS / "ulta_conform.py"), str(html), str(drawio), "--keep-sizes"],
                       capture_output=True, text=True)
    res = next((l for l in c.stdout.splitlines() if l.startswith("RESULT")), "RESULT: conform did not run")
    import compliance
    found = compliance.scan([html, drawio])
    blk = [x for x in found if x["severity"] == "BLOCK"]
    rev = [f"{x.get('kind', '')}: {x.get('masked', '')}" for x in found if x["severity"] == "REVIEW"]
    long_ = too_long(a.input)
    status = "NEEDS CORRECTION" if blk or long_ or "FAIL" in res else "READY"
    import checks                                        # the evidence the RESULT line's score is computed from
    checks.record(html, [("Template conformance (brand colours and fonts, page and draw.io)",
                          "FAIL" if "FAIL" in res else "UNVERIFIED" if "did not run" in res else "PASS", res.split(":", 1)[-1].strip()),
                         ("Sensitive data", "FAIL" if blk else "REVIEW" if rev else "PASS",
                          "; ".join([f"{x.get('kind', '')}: {x.get('masked', '')}" for x in blk][:2] or rev[:2]), not blk and bool(rev)),
                         ("Label length (nothing cut with an ellipsis)", "FAIL" if long_ else "PASS", "; ".join(long_[:2]))], status)
    print(f"{status} | {html} | {drawio} | brand {b.name} | {res.split(':', 1)[1].strip()}")
    for x in long_[:6]:
        print("  " + x)
    for x in blk[:5]:
        print(f"  BLOCK {x.get('kind', '')}: {x.get('masked', '')}")
    import tokens as TK
    print(TK.report_page([MOD / "ulta_architecture_html.py", MOD / "ulta_architecture_xml.py"],
                         Path(a.input).read_text(encoding="utf-8"), res, "architecture", out=html))


if __name__ == "__main__":
    main()
