"""v6.37 Studio visuals that stay editable — SmartArt-style, on the Studio's own engines.

A drawn visual (a process flow, a timeline, a swimlane, a retail diagram) is native PowerPoint shapes in one group. The {family, style,
data} it was drawn from is kept with that group in the .pptx as a PowerPoint tag (p:custDataLst → /ppt/tags/tagN.xml), the mechanism
add-ins use, which PowerPoint keeps when the deck is edited and saved there. The slide editor reads it back and draws the visual again
after any change — its words in the text pane, a step added or moved, another layout — in the box the group now covers, at its place in
the slide's order. A copied slide or shape keeps it (copy_fix); a group without it is still an ordinary group.

    draw(slide, box, family, style, data)  -> (group element, problems)     the visual drawn and tagged
    read(slide, el) -> spec | None                                          the spec kept with a group
    redraw(slide, el, style=None, data=None) -> (new element, problems)     drawn again in place (raises ValueError when it cannot)
    ungroup(slide, el)                                                      its shapes as free shapes (the spec is dropped)
    steps_from_lines(lines) -> data                                         a text box's lines as process steps
"""
import copy
import importlib
import json
import os
import re
import sys
from xml.sax.saxutils import quoteattr

from lxml import etree

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path: sys.path.insert(0, HERE)

P_NS = 'http://schemas.openxmlformats.org/presentationml/2006/main'
A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main'
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
NS = {'p': P_NS, 'a': A_NS, 'r': R_NS}
P, A, R = '{%s}' % P_NS, '{%s}' % A_NS, '{%s}' % R_NS
TAG = 'ULTA_VISUAL'
CT_TAGS = 'application/vnd.openxmlformats-officedocument.presentationml.tags+xml'
RT_TAGS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/tags'
SHAPES = ('sp', 'grpSp', 'cxnSp', 'pic', 'graphicFrame')

# family: (engine module, what it is called, the data key the engine reads)
FAMILIES = {
    'process': ('flows', 'Process', 'process'),
    'timeline': ('timelines', 'Timeline', 'timeline'),
    'swimlane': ('swimlanes', 'Swimlane', 'swimlane'),
    'retail': ('retail', 'Retail diagram', 'retail'),
}


def _ln(el): return etree.QName(el).localname


def engine(family):
    if family not in FAMILIES: raise ValueError(f'unknown visual family {family}')
    return importlib.import_module(FAMILIES[family][0])


def styles(family):
    """[(style, what it shows)] in the engine's own order."""
    return [(k, str(v)) for k, v in engine(family).STYLES.items()]


def samples(family):
    """{style: data} — each engine's own sample content, one per style (the Insert ▸ Visual gallery starts from these)."""
    out = {}
    key = FAMILIES[family][2]
    for s in engine(family).sample():
        st = s.get('style')
        if st and key in s and st not in out: out[st] = s[key]
    return out


# ------------------------------------------------------------------------------------------------ the tag kept with a group
def _nvpr(el):
    nv = el.find('p:nvGrpSpPr', NS) if _ln(el) == 'grpSp' else next((c for c in el if _ln(c).startswith('nv')), None)
    return nv.find('p:nvPr', NS) if nv is not None else None


def _tag_rids(el):
    nvpr = _nvpr(el)
    if nvpr is None: return []
    return [t.get(R + 'id') for t in nvpr.findall('p:custDataLst/p:tags', NS) if t.get(R + 'id')]


def tag(slide, el, spec):
    """Keep spec with the group: a tags part of its own, related from the slide, named in the group's custDataLst."""
    from pptx.opc.package import Part
    from pptx.opc.packuri import PackURI
    pkg = slide.part.package
    blob = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<p:tagLst xmlns:p="%s"><p:tag name="%s" val=%s/></p:tagLst>'
            % (P_NS, TAG, quoteattr(json.dumps(spec, ensure_ascii=False, separators=(',', ':'))))).encode('utf-8')
    part = Part(PackURI(str(pkg.next_partname('/ppt/tags/tag%d.xml'))), CT_TAGS, pkg, blob)
    rid = slide.part.relate_to(part, RT_TAGS)
    nvpr = _nvpr(el)
    if nvpr is None: raise ValueError('this shape cannot keep a tag')
    for old in nvpr.findall('p:custDataLst', NS): nvpr.remove(old)
    cdl = etree.Element(P + 'custDataLst'); t = etree.SubElement(cdl, P + 'tags'); t.set(R + 'id', rid)
    ext = nvpr.find('p:extLst', NS)
    (ext.addprevious(cdl) if ext is not None else nvpr.append(cdl))
    return rid


def _tag_value(part):
    try:
        x = etree.fromstring(part.blob)
        t = next((t for t in x.findall('p:tag', NS) if t.get('name') == TAG), None)
        return json.loads(t.get('val')) if t is not None else None
    except Exception:  # noqa: BLE001  a tag that is not ours, or damaged: not a Studio visual
        return None


def read(slide, el):
    """The spec kept with this group, or None."""
    for rid in _tag_rids(el):
        rel = slide.part.rels.get(rid)
        if rel is None or rel.is_external or not rel.reltype.endswith('/tags'): continue
        v = _tag_value(rel.target_part)
        if isinstance(v, dict) and v.get('family') in FAMILIES: return v
    return None


def untag(slide, el):
    """Drop the group's tags (and the slide's relationship to them when nothing else uses it)."""
    nvpr = _nvpr(el)
    rids = _tag_rids(el)
    if nvpr is not None:
        for c in nvpr.findall('p:custDataLst', NS): nvpr.remove(c)
    for rid in rids:
        try: slide.part.drop_rel(rid)
        except Exception:  # noqa: BLE001
            pass


def copy_fix(src_slide, dst_slide, el):
    """A shape copied from src_slide to dst_slide (another slide, maybe another deck): a Studio visual's tag goes with it (a copy of
    the tag, so each visual keeps its own); any other tag reference that would point at nothing is removed (PowerPoint reports a file
    with one as damaged)."""
    from pptx.opc.package import Part
    from pptx.opc.packuri import PackURI
    for t in list(el.iter(P + 'tags')):
        rid = t.get(R + 'id'); ok = None
        if rid and dst_slide.part.rels.get(rid) is not None and dst_slide.part.rels[rid].reltype.endswith('/tags') and src_slide is dst_slide: continue
        rel = src_slide.part.rels.get(rid) if rid else None
        v = _tag_value(rel.target_part) if rel is not None and not rel.is_external and rel.reltype.endswith('/tags') else None
        if isinstance(v, dict) and v.get('family') in FAMILIES:
            pkg = dst_slide.part.package
            part = Part(PackURI(str(pkg.next_partname('/ppt/tags/tag%d.xml'))), CT_TAGS, pkg, rel.target_part.blob)
            ok = dst_slide.part.relate_to(part, RT_TAGS)
        if ok: t.set(R + 'id', ok)
        else:
            cdl = t.getparent(); cdl.remove(t)
            if not len(cdl): cdl.getparent().remove(cdl)


# ------------------------------------------------------------------------------------------------ drawing
def _shape_of(slide, el):
    return next((s for s in slide.shapes if s._element is el), None)


def draw(slide, box, family, style, data, density=None, name=None, lint=True):
    """Draw the visual into box (x, y, w, h EMU) on slide and keep its spec with it. Returns (the group's element or None, problems).
    Nothing drawn (no steps, a style that cannot show this content) raises ValueError with the engine's reason."""
    m = engine(family); key = FAMILIES[family][2]
    data = copy.deepcopy(data)
    spec = {key: data, 'style': m.auto_style(data) if not style or style == 'auto' else style}   # 'auto': the style the engine picks for this content
    if density: spec['density'] = density
    tree = slide.shapes._spTree; n0 = len(tree)
    probs = list(m.lint(spec) or []) if lint else []
    drawn = list(m.draw(slide, tuple(int(v) for v in box), spec) or [])
    new = [e for e in list(tree)[n0:] if _ln(e) in SHAPES]
    if not new: raise ValueError((drawn or probs or ['nothing to draw'])[0])
    if len(new) > 1:   # an engine that left loose shapes: one group, so the visual moves and redraws as one
        import native_draw as ND
        g = ND.group(slide, [_shape_of(slide, e) for e in new], name=f'{FAMILIES[family][1]} ({spec["style"]})')
        el = g._element
    else: el = new[0]
    if name: el.find('.//p:cNvPr', NS).set('name', name)
    tag(slide, el, {'v': 1, 'family': family, 'style': spec['style'], 'data': data, 'density': density, 'box': [int(v) for v in box]})
    return el, list(dict.fromkeys(probs + drawn))


def box_now(el, spec):
    """The box the visual is drawn into now: the box it was drawn into, carried by the group's move / resize since (its off / ext
    against its chOff / chExt), so a visual the person moved or resized is drawn again where it now is, at its new size."""
    b = spec.get('box')
    xf = el.find('p:grpSpPr/a:xfrm', NS) if _ln(el) == 'grpSp' else None
    if not b: raise ValueError('this visual does not say where it was drawn')
    if xf is None or xf.find('a:chOff', NS) is None: return tuple(int(v) for v in b)
    g = lambda t, a: int(xf.find('a:' + t, NS).get(a))
    ox, oy, cx, cy = g('off', 'x'), g('off', 'y'), g('ext', 'cx'), g('ext', 'cy')
    chx, chy, chcx, chcy = g('chOff', 'x'), g('chOff', 'y'), g('chExt', 'cx'), g('chExt', 'cy')
    sx = cx / chcx if chcx else 1.0; sy = cy / chcy if chcy else 1.0
    return (int(ox + (b[0] - chx) * sx), int(oy + (b[1] - chy) * sy), int(b[2] * sx), int(b[3] * sy))


def redraw(slide, el, style=None, data=None, density=None):
    """Draw a Studio visual again with a new style and / or data, where it is now, at its place in the slide's order. Returns
    (the new element, problems). The old group goes (and its tag); on failure nothing changes and ValueError says why."""
    spec = read(slide, el)
    if spec is None: raise ValueError('this group is not a Studio visual')
    box = box_now(el, spec)
    tree = el.getparent(); at = list(tree).index(el)
    name = el.find('.//p:cNvPr', NS).get('name') or ''
    keep_name = None if re.match(r'^(Process|Timeline|Swimlane|Retail diagram|Retail|swimlane|timeline)\b', name, re.I) or ' (' in name else name
    old = copy.deepcopy(el)
    untag(slide, el); tree.remove(el)
    try:
        new, probs = draw(slide, box, spec['family'], style if style else spec.get('style'), spec.get('data') if data is None else data,
                          density=spec.get('density') if density is None else density, name=keep_name)
    except Exception:
        tree.insert(at, old)
        raise
    tree.remove(new); tree.insert(at, new)
    return new, probs


def ungroup(slide, el):
    """The group's shapes as free shapes where they are on the slide (its move and resize applied to each), in its place in the order."""
    if _ln(el) != 'grpSp': raise ValueError('only a group can be ungrouped')
    xf = el.find('p:grpSpPr/a:xfrm', NS)
    if xf is not None and int(xf.get('rot') or 0): raise ValueError('a turned group: ungroup it in PowerPoint')
    def T(x, y, w, h):
        if xf is None or xf.find('a:chOff', NS) is None: return x, y, w, h
        g = lambda t, a: int(xf.find('a:' + t, NS).get(a))
        sx = g('ext', 'cx') / (g('chExt', 'cx') or 1); sy = g('ext', 'cy') / (g('chExt', 'cy') or 1)
        return int(g('off', 'x') + (x - g('chOff', 'x')) * sx), int(g('off', 'y') + (y - g('chOff', 'y')) * sy), int(w * sx), int(h * sy)
    untag(slide, el)
    tree = el.getparent(); at = list(tree).index(el); kids = [c for c in el if _ln(c) in SHAPES]
    for c in kids:
        cxf = c.find('p:grpSpPr/a:xfrm', NS) if _ln(c) == 'grpSp' else (c.find('p:xfrm', NS) if _ln(c) == 'graphicFrame' else c.find('p:spPr/a:xfrm', NS))
        if cxf is not None and cxf.find('a:off', NS) is not None:
            o, e = cxf.find('a:off', NS), cxf.find('a:ext', NS)
            x, y, w, h = T(int(o.get('x')), int(o.get('y')), int(e.get('cx')), int(e.get('cy')))
            o.set('x', str(x)); o.set('y', str(y)); e.set('cx', str(w)); e.set('cy', str(h))
    tree.remove(el)
    for k, c in enumerate(kids): tree.insert(at + k, c)
    return kids


# ------------------------------------------------------------------------------------------------ from text
def steps_from_lines(lines):
    """A text box's lines as process steps: "Title: detail" (or "Title — detail") keeps its split; a short line is a title; a long one
    takes its first words as the title and the rest as the detail. Bullets and numbering marks go."""
    out = []
    for raw in lines:
        x = re.sub(r'^[\s•◦▪✓→–\-*·\d.)]+', '', str(raw)).strip()
        if not x: continue
        m = re.match(r'^(.{2,48}?)\s*(?::|\s[—–-]\s)\s*(.+)$', x)
        if m and len(m.group(1).split()) <= 6: out.append({'title': m.group(1).strip(), 'text': m.group(2).strip()})
        elif len(x.split()) <= 5: out.append({'title': x.rstrip('.'), 'text': ''})
        else:
            w = x.split(); out.append({'title': ' '.join(w[:3]).rstrip(',;:'), 'text': ' '.join(w[3:])})
    return {'steps': out[:12]}


def texts(data):
    """Every string in a visual's data with its path (the text pane edits these; the slide's words map back to them)."""
    out = []
    def walk(v, path):
        if isinstance(v, str): out.append((path, v))
        elif isinstance(v, dict):
            for k, x in v.items(): walk(x, path + [k])
        elif isinstance(v, list):
            for i, x in enumerate(v): walk(x, path + [i])
    walk(data, [])
    return out


TEXT_KEYS = ('title', 'text', 'label', 'name', 'sub', 'note', 'outcome', 'center', 'purpose', 'detail', 'description')


def words(data):
    """The visual's words a rewrite may touch: (path, text) for its titles, texts, labels and names — never ids, dates, lanes, kinds or
    numbers, which hold it together."""
    return [(p, t) for p, t in texts(data) if t.strip() and p and isinstance(p[-1], str) and p[-1] in TEXT_KEYS]


def set_path(data, path, value):
    d = data
    for k in path[:-1]: d = d[k]
    d[path[-1]] = value
    return data


# ------------------------------------------------------------------------------------------------ v6.37.1 the gallery's reasons in plain words
# The engines' lint is written for the model that writes a visual's data ("give 1-5 suppliers in 'sipoc': {...}"). The layout gallery shows a
# person why a layout does not suit their words: the same finding, said plainly, once.
NOUN = {'phase': 'a phase', 'phases': 'phases (the stages, in order)', 'duration': 'a duration', 'system': 'a system', 'value': 'a number',
        'sipoc': 'suppliers, inputs, outputs and customers', 'owner': 'an owner', 'lane': 'a lane', 'date': 'a date', 'dates': 'dates'}
PLAIN = [
    (r"is wider than its box|does not fit its (?:box|diamond)|is \d+ words - (?:keep|the)|its text is \d+ words|keep its detail to|are long for their cards",
     lambda m: 'some words are too long for this layout - shorten them'),
    (r"^no status on ", lambda m: 'each row needs a status (done, on track, at risk or late)'),
    (r"^(?:converge|diverge) needs the \"(\w+)\" ([^:{]+)", lambda m: f"needs the {m.group(1)} {m.group(2).strip()}"),
    (r"runs outside the content frame", lambda m: 'too much to fit this layout - fewer steps or shorter words'),
    (r"^step '[^']*' has no '(\w+)'", lambda m: f"each step needs {NOUN.get(m.group(1), m.group(1))}"),
    (r"^phase '[^']*' has 0 (\w+) - list (\d+-\d+)", lambda m: f"each phase needs {m.group(2)} {m.group(1)}"),
    (r"^every (\w+) stage needs its \"value\"", lambda m: 'needs a number for each stage (from your data)'),
    (r"^0 (\w+) - (?:the [\w-]+ style lists|an? [\w-]+ shows) (\d+-\d+)", lambda m: f"needs {m.group(2)} {m.group(1)}"),
    (r"^(\d+) ([a-z]+)(?: \([\w ]+\))? [-—] the ([\w-]+)(?: style)? shows (\d+-\d+)", lambda m: f"shows {m.group(4)} {m.group(2)} - this has {m.group(1)}"),
    (r"^the process has (\d+) steps; a SIPOC shows (\d+-\d+)", lambda m: f"shows {m.group(2)} steps - this has {m.group(1)}"),
    (r"^(\d+) activities do not fit one matrix \((\d+) max\)", lambda m: f"fits {m.group(2)} activities - this has {m.group(1)}"),
    (r"^the flow needs (\d+) steps side by side; the \w+ view fits (\d+)", lambda m: f"fits {m.group(2)} steps side by side - this needs {m.group(1)}"),
    (r"^the dates span (\d+) months - a year-at-a-glance calendar shows 12", lambda m: f"shows one year - these dates span {m.group(1)} months"),
    (r"^the [\w-]+ style needs (\d+-\d+) '(\w+)'", lambda m: f"needs {m.group(1)} {m.group(2)}"),
    (r"^the [\w-]+ style needs steps with '(\w+)'", lambda m: f"each step needs {NOUN.get(m.group(1), m.group(1))}"),
    (r"^the [\w-]+ style sizes steps by '(\w+)'", lambda m: f"each step needs {NOUN.get(m.group(1), m.group(1))}"),
    (r"^the [\w-]+ style needs '(\w+)'", lambda m: f"needs {NOUN.get(m.group(1), m.group(1))}"),
    (r"^sipoc '(\w+)' is empty", lambda m: 'needs suppliers, inputs, outputs and customers'),
    (r"^(?:retail diagram not drawn: )?it has no (\w+)", lambda m: f"needs {m.group(1)}"),
    (r"^decision '[^']*' has 1 branch", lambda m: 'a decision needs two branches (yes and no)'),
    (r"^no (?:room|free spot)", lambda m: 'too crowded at this size - fewer steps side by side'),
]


def plain(probs, most=2):
    """The engines' findings as a person reads them: each said once, plainly; at most `most`."""
    out = []
    for p in probs or []:
        t = str(p).strip(); said = None
        for rx, fn in PLAIN:
            m = re.search(rx, t)
            if m: said = fn(m); break
        if said is None:   # no rule: the model's notation goes (JSON keys and samples), the finding stays
            said = re.sub(r"\s*\([^()]*[\"'\[{][^()]*\)", '', t)
            said = re.sub(r"\s*(?:in\s+)?'[a-z_]+':\s*\{.*?\}", '', said)
            said = re.sub(r"\s*[:-]?\s*(?:give|mark|set)?[^.;]*\{.*$", '', said) or said   # a JSON sample ends the sentence
            said = re.sub(r"^EXC\s+|^[\w ]+ not drawn:\s*", '', said)
            said = re.sub(r'\s*(?:with\s+)?\(?\"\w+\":\s*(?:true|false)\)?', '', said)
            said = re.sub(r"'([a-z_]+)'|\"([a-z_]+)\"", lambda m: NOUN.get(m.group(1) or m.group(2), m.group(1) or m.group(2)), said)
            said = re.sub(r"\s+", ' ', said).strip(' -;')
        said = said[:1].upper() + said[1:]
        if said and said not in out: out.append(said)
        if len(out) >= most: break
    return out
