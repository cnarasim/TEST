"""Modern infographic charts for deck slides - native, editable PowerPoint shapes on the Ulta palette.

    {"modern": "<type>", "headline": "...", ...data...}       (a storyboard slide; build_deck.py draws it)

Types and their data (python tools/modern_charts.py shows this list):
  kpi       KPI cards: number, change badge, sparkline     items: [{label, value, delta, trend:[n,...]}]   (2-4)
  bento     bento grid: mixed tiles                         tiles: [{kind: big|kpi|ring|note|bars, ...}]    (3-6)
  ring      progress rings with the % in the middle         items: [{label, value(0-100)}]                  (1-4)
  gauge     half-dial score against a target               value, target, label, unit
  bullet    actual vs target bars (bullet chart)            items: [{label, value, target, max}]            (2-6)
  lollipop  ranked values, the leader highlighted           items: [[label, value], ...], unit              (3-10)
  dumbbell  before -> after per item                        from, to, items: [[label, before, after], ...]  (3-8)
  slope     change between two points in time               from, to, items: [[label, a, b], ...], highlight (2-7)
  waffle    a share as 100 squares                          value(0-100), label
  stack100  mix per item, 100% bars                         series: [..], items: [[label, v1, v2, ...], ...] (2-6 rows, 2-4 parts)
  treemap   share of a total as nested tiles                items: [[label, value], ...]                    (3-10)
  trend     native line chart with one called-out point    x: [..], y: [..], at: index, note, unit (value, format)
  sankey    flows between 2-4 stages as curved bands         flows: [[from, to, value], ...]                (3-20)
  sunburst  groups (inner ring) and their parts (outer)      items: [[group, part, value], ...], center      (3-16)
  butterfly two groups back to back, row by row              left, right, items: [[label, l, r], ...]       (3-12)
  stream    layered soft waves over time                     x: [..], series: {name: [values per x]}        (2-6 series)
  radialbar race-track rings, one per item                   items: [[label, 0-100], ...]                   (2-6)
  radar     spider web over 3-8 axes                         axes: [..], series: {name: [..]}, max          (1-3 series)
  bubbles   packed circles sized by value                    items: [[label, value], ...]                   (3-14)
  rose      polar wedges, length = value                     items: [[label, value], ...]                   (5-12)
  usmap     US states shaded by value (4 steps), leaders     items: [[state, value], ...] (code, name or 'City, ST'), title
  pointmap  locations as circles on the US map               items: [[name, latitude, longitude, value], ...], title
  gantt     roadmap: grouped bars, milestones, today line   tasks: [{task, group, start, end, milestone}] or data: plan.xlsx
                                                            (columns Task, Start, End, Group, Milestone), today (max 18 rows)
  swimlane  process map: one lane per role, steps in order  lanes: [..], steps: [{id, lane, text, after: id|[ids],
                                                            kind: start|task|decision|end, label: Yes/No}]  (max 6 lanes)
Colour rules (dataviz method, validated): berry C10060 leads, orange F26923 second, plum 5D0F43 third (template
palette only; they pass colour-blind separation and contrast - plum is darker than ideal, so every series is labelled); everything else is neutral grey context. Up/down badges carry ▲/▼ and a sign,
never colour alone. Text is ink or grey, never the series colour.
"""
import math, re

from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.util import Pt
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I

SERIES = ["D01381", "F16A1C", "5D0F43"]          # the template's theme magenta and orange lead, Berry Bliss plum third
CONTEXT, TRACK, GRID = "8A8C8F", "D9D9D9", "D9D9D9"   # context marks read at 3:1 on the page; tracks stay visible
INK, MUTED, SURFACE, TINT = "000000", "404040", "FFFFFF", "FFF5F3"
UP, DOWN = "00B050", "FF0000"                      # status colours: on the arrow only, the text stays black
BODY, BOLD, DISPLAY = "Circular Std Book", "Circular Std Bold", "Playfair Display Black"
IN = 914400

TYPES = {"kpi": "KPI cards with sparklines", "bento": "Bento grid", "ring": "Progress rings", "gauge": "Gauge",
         "bullet": "Bullet chart (actual vs target)", "lollipop": "Lollipop ranking", "dumbbell": "Dumbbell (before / after)",
         "slope": "Slope chart", "waffle": "Waffle (share of 100)", "stack100": "100% stacked bars",
         "treemap": "Treemap", "trend": "Annotated trend line",
         "sankey": "Sankey flows", "sunburst": "Sunburst", "butterfly": "Butterfly (back-to-back bars)",
         "stream": "Streamgraph", "radialbar": "Radial bars", "radar": "Radar / spider", "bubbles": "Bubble pack",
         "rose": "Polar rose", "gantt": "Roadmap / Gantt", "swimlane": "Swimlane process map",
         "usmap": "US map by state", "pointmap": "Locations on a US map"}


# ---------------------------------------------------------------- primitives
def rgb(h):
    return RGBColor.from_string(h)


def _noline(sh):
    sh.line.fill.background()


def rect(sl, x, y, w, h, fill, radius=None, line=None, name="modern shape"):
    shp = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE, int(x), int(y), int(max(w, 1)), int(max(h, 1)))
    if radius:
        shp.adjustments[0] = min(0.5, radius / max(1, min(w, h)))
    if fill:
        shp.fill.solid(); shp.fill.fore_color.rgb = rgb(fill)
    else:
        shp.fill.background()
    if line:
        shp.line.color.rgb = rgb(line); shp.line.width = Pt(1)
    else:
        _noline(shp)
    shp.shadow.inherit = False
    shp.name = name
    return shp


def oval(sl, cx, cy, d, fill, ring=None, name="modern dot"):
    shp = sl.shapes.add_shape(MSO_SHAPE.OVAL, int(cx - d / 2), int(cy - d / 2), int(d), int(d))
    shp.fill.solid(); shp.fill.fore_color.rgb = rgb(fill)
    if ring:
        shp.line.color.rgb = rgb(ring); shp.line.width = Pt(2)
    else:
        _noline(shp)
    shp.shadow.inherit = False; shp.name = name
    return shp


def line(sl, x1, y1, x2, y2, color, width=2.0, name="modern line", dash=False):
    c = sl.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, int(x1), int(y1), int(x2), int(y2))
    c.line.color.rgb = rgb(color); c.line.width = Pt(width)
    if dash:
        from pptx.enum.dml import MSO_LINE
        c.line.dash_style = MSO_LINE.DASH
    c.name = name
    return c


def polyline(sl, pts, color, width=2.0, name="modern sparkline"):
    fb = sl.shapes.build_freeform(int(pts[0][0]), int(pts[0][1]), scale=1.0)
    fb.add_line_segments([(int(x), int(y)) for x, y in pts[1:]], close=False)
    shp = fb.convert_to_shape()
    shp.fill.background(); shp.line.color.rgb = rgb(color); shp.line.width = Pt(width)
    shp.shadow.inherit = False; shp.name = name
    return shp


def text(sl, x, y, w, h, s, size=12, color=INK, font=BODY, align="l", anchor="t", bold=False, name="modern text"):
    tb = sl.shapes.add_textbox(int(x), int(y), int(max(w, 1)), int(max(h, 1)))
    tf = tb.text_frame; tf.word_wrap = True
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = {"t": MSO_ANCHOR.TOP, "m": MSO_ANCHOR.MIDDLE, "b": MSO_ANCHOR.BOTTOM}[anchor]
    lines = str(s).split("\n")
    for i, ln in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        p.alignment = {"l": PP_ALIGN.LEFT, "c": PP_ALIGN.CENTER, "r": PP_ALIGN.RIGHT}[align]
        r = p.add_run(); r.text = ln
        r.font.size = Pt(size); r.font.name = font; r.font.bold = bold or None
        r.font.color.rgb = rgb(color)
    tb.name = name
    return tb


ANG = lambda deg: deg * 60000 / 100000      # OOXML angles are 60000ths of a degree; python-pptx scales by 1/100000


def arc(sl, cx, cy, d, frac, color, thick=0.16, name="modern ring"):
    """A progress arc from 12 o'clock, clockwise; frac 0-1."""
    frac = max(0.0, min(1.0, frac))
    if frac >= 0.999:
        shp = sl.shapes.add_shape(MSO_SHAPE.DONUT, int(cx - d / 2), int(cy - d / 2), int(d), int(d))
        shp.adjustments[0] = thick
    else:
        shp = sl.shapes.add_shape(MSO_SHAPE.BLOCK_ARC, int(cx - d / 2), int(cy - d / 2), int(d), int(d))
        start = 270.0; end = (270.0 + 360.0 * max(frac, 0.002)) % 360
        shp.adjustments[0] = ANG(start); shp.adjustments[1] = ANG(end); shp.adjustments[2] = thick
    shp.fill.solid(); shp.fill.fore_color.rgb = rgb(color); _noline(shp)
    shp.shadow.inherit = False; shp.name = name
    return shp


def num(v):
    try:
        return float(str(v).replace(",", "").replace("%", "").replace("$", "").strip())
    except ValueError:
        return 0.0


_UNIT = [""]                                              # the chart's own unit ("$M", "K"), set by draw()


def fmt(v, unit=None):
    """A value with its unit: 1.6 with '$B' reads $1.6B, 40.5 with '%' reads 40.5%, 12 with 'days' reads 12 days.
    With no unit given, the unit of the chart being drawn."""
    unit = _UNIT[0] if unit is None else unit
    v = float(v)
    s = f"{v:,.0f}" if abs(v) >= 100 or v == int(v) else f"{v:,.1f}"
    if unit in ("%",):
        return s + "%"
    if unit[:1] in ("$", "€", "£"):
        return ("-" if v < 0 else "") + unit[0] + s.lstrip("-") + unit[1:]
    if unit in ("K", "M", "B"):
        return s + unit
    return s + ((" " + unit) if unit else "")


def delta_badge(sl, x, y, delta, size=11, good_when_up=True):
    """A change badge: grey pill, black text with the sign and an arrow, a small green / red triangle (never colour alone)."""
    d = str(delta).strip()
    up = not d.startswith("-") and not d.startswith("−")
    good = up == good_when_up
    n_ = re.search(r"\d+(\.\d+)?", d)
    flat = bool(n_) and float(n_.group()) == 0                 # 0.0 pts: no arrow and no sign, it did not move
    lab = d.lstrip("+-−") if flat else ("+" if up else "−") + d.lstrip("+-−")
    tri = int(size * 0.75 * 12700)
    w = int((len(lab) * 0.6 * size + 22) * 12700) + tri
    h = int((size * 1.9) * 12700)
    rect(sl, x, y, w, h, "F2F2F2", radius=h / 2, name="modern delta badge")
    if flat:
        rect(sl, x + 0.09 * IN, y + (h - tri * 0.3) / 2, tri, tri * 0.3, MUTED, name="modern delta flat")
        text(sl, x + 0.09 * IN + tri, y, w - tri - 0.09 * IN, h, lab, size, INK, BOLD, "c", "m", name="modern delta")
        return w, h
    t = sl.shapes.add_shape(MSO_SHAPE.ISOSCELES_TRIANGLE, int(x + 0.09 * IN), int(y + (h - tri) / 2), tri, tri)
    if not up:
        t.rotation = 180
    t.fill.solid(); t.fill.fore_color.rgb = rgb(UP if good else DOWN); _noline(t); t.name = "modern delta arrow " + ("up" if up else "down")
    text(sl, x + 0.09 * IN + tri, y, w - tri - 0.09 * IN, h, lab, size, INK, BOLD, "c", "m", name="modern delta")
    return w, h


# ---------------------------------------------------------------- charts
def kpi_cards(sl, box, items, title_size=12):
    x, y, w, h = box
    n = max(1, min(4, len(items)))
    gap = int(0.25 * IN); cw = (w - gap * (n - 1)) / n
    ch = min(h, int((3.6 if any(len(it.get('trend') or []) >= 2 for it in items[:n]) else 2.6) * IN))   # (1aa)
    y0 = y + (h - ch) / 2
    for i, it in enumerate(items[:n]):
        cx = x + i * (cw + gap)
        kpi_tile(sl, (cx, y0, cw, ch), it, i, title_size)


def kpi_tile(sl, box, it, i=0, title_size=12):
    x, y, w, h = box
    rect(sl, x, y, w, h, SURFACE, radius=0.18 * IN, line=GRID, name="modern card")
    rect(sl, x, y + 0.25 * IN, 0.07 * IN, 0.45 * IN, SERIES[i % 3], name="modern card accent")
    pad = 0.28 * IN
    text(sl, x + pad, y + 0.22 * IN, w - 2 * pad, 0.35 * IN, it.get("label", ""), title_size, MUTED, BOLD)
    vs = 40 if w > 2.6 * IN else 32
    text(sl, x + pad, y + 0.6 * IN, w - 2 * pad, 0.8 * IN, it.get("value", ""), vs, INK, DISPLAY)
    by = y + 1.5 * IN
    if it.get("delta"):
        bw, bh = delta_badge(sl, x + pad, by, it["delta"], good_when_up=it.get("good", "up") == "up")
        if it.get("vs"):
            text(sl, x + pad + bw + 0.1 * IN, by, w - 2 * pad - bw, bh, it["vs"], 10, MUTED, BODY, "l", "m")
    elif it.get("vs"):                                  # (1aa) the words around the number, under it
        text(sl, x + pad, by, w - 2 * pad, 0.6 * IN, it["vs"], 12, MUTED, BODY, "l", "t")
    tr = [num(v) for v in (it.get("trend") or [])]
    if len(tr) >= 2 and h > 2.4 * IN:
        sx0, sx1 = x + pad, x + w - pad; sy0, sy1 = y + h - 0.35 * IN, by + 0.55 * IN
        lo, hi = min(tr), max(tr); rng = (hi - lo) or 1
        pts = [(sx0 + (sx1 - sx0) * k / (len(tr) - 1), sy0 - (v - lo) / rng * (sy0 - sy1)) for k, v in enumerate(tr)]
        polyline(sl, pts, SERIES[i % 3], 2.25)
        oval(sl, pts[-1][0], pts[-1][1], 0.13 * IN, SERIES[i % 3], ring=SURFACE, name="modern sparkline end")


def rings(sl, box, items):
    x, y, w, h = box
    n = max(1, min(4, len(items)))
    cw = w / n; d = min(cw * 0.62, h * 0.62)
    for i, it in enumerate(items[:n]):
        cx = x + cw * i + cw / 2; cy = y + h * 0.42
        v = num(it.get("value"))
        arc(sl, cx, cy, d, 1.0, TRACK)
        arc(sl, cx, cy, d, v / 100, SERIES[i % 3])
        text(sl, cx - d / 2, cy - 0.35 * IN, d, 0.7 * IN, f"{v:.0f}%", 30 if d > 1.8 * IN else 24, INK, DISPLAY, "c", "m")
        text(sl, cx - cw / 2 + 0.15 * IN, cy + d / 2 + 0.18 * IN, cw - 0.3 * IN, 0.7 * IN, it.get("label", ""), 14, INK, BOLD, "c")


def ring_poly(sl, cx, cy, r_out, r_in, a0, a1, fill, name="modern arc", steps=96):
    """A ring sector as a freeform (degrees, 0 = 3 o'clock, clockwise): its frame is exactly the visible arc, never a
    full circle hanging off the slide."""
    n = max(8, int(steps * abs(a1 - a0) / 360) + 2)
    ang = [math.radians(a0 + (a1 - a0) * k / (n - 1)) for k in range(n)]
    pts = [(cx + r_out * math.cos(a), cy + r_out * math.sin(a)) for a in ang] + \
          [(cx + r_in * math.cos(a), cy + r_in * math.sin(a)) for a in reversed(ang)]
    return polygon(sl, pts, fill, name=name)


def gauge(sl, box, spec):
    x, y, w, h = box
    v, t = num(spec.get("value")), num(spec.get("target") or 0)
    mx = num(spec.get("max") or 100) or 100
    r = min(w * 0.28, h - 1.2 * IN); d = 2 * r
    cx = x + w / 2; cy = y + 0.3 * IN + r                 # the half ring sits in the box with room for the label
    ring_poly(sl, cx, cy, r, r * 0.8, 180.0, 360.0, TRACK, "modern gauge track")
    ring_poly(sl, cx, cy, r, r * 0.8, 180.0, 180.0 + 180.0 * max(0.003, min(v / mx, 1.0)), SERIES[0], "modern gauge")
    if t:
        a = math.pi * (1 + t / mx)
        r1, r2 = d / 2 * 0.74, d / 2 * 1.06
        line(sl, cx + r1 * math.cos(a), cy + r1 * math.sin(a), cx + r2 * math.cos(a), cy + r2 * math.sin(a), INK, 2.5, "modern gauge target")
        lx, ly = cx + d / 2 * 1.12 * math.cos(a), cy + d / 2 * 1.12 * math.sin(a)
        right = math.cos(a) >= 0
        text(sl, lx if right else lx - 1.4 * IN, ly - 0.2 * IN, 1.4 * IN, 0.4 * IN,
             f"Target {fmt(t, spec.get('unit', ''))}", 12, INK, BOLD, "l" if right else "r", "m")
    text(sl, cx - d / 2, cy - 0.85 * IN, d, 0.7 * IN, fmt(v, spec.get("unit", "")), 40, INK, DISPLAY, "c", "b")
    text(sl, cx - d / 2, cy + 0.08 * IN, d, 0.4 * IN, spec.get("label", ""), 14, MUTED, BOLD, "c")


def bullet(sl, box, items):
    x, y, w, h = box
    items = items[:6]; n = len(items)
    lw = 2.4 * IN; px = x + lw; pw = w - lw - 0.9 * IN
    rh = min(0.8 * IN, h / max(n, 1))
    for i, it in enumerate(items):
        ry = y + i * rh + (h - rh * n) / 2
        mx = num(it.get("max")) or max(num(it.get("value")), num(it.get("target"))) * 1.15 or 1
        v, t = num(it.get("value")), num(it.get("target"))
        text(sl, x, ry, lw - 0.2 * IN, rh, it.get("label", ""), 14, INK, BOLD, "r", "m")
        bh = rh * 0.5; by = ry + (rh - bh) / 2
        rect(sl, px, by, pw, bh, TRACK, name="modern bullet range")
        rect(sl, px, by + bh * 0.25, pw * min(v / mx, 1), bh * 0.5, SERIES[0] if v >= t else SERIES[1], name="modern bullet value")
        tx = px + pw * min(t / mx, 1)
        line(sl, tx, by - 0.04 * IN, tx, by + bh + 0.04 * IN, INK, 2.5, "modern bullet target")
        text(sl, px + pw + 0.12 * IN, ry, 0.9 * IN, rh, fmt(v, it.get("unit", "")), 14, INK, BOLD, "l", "m")
    text(sl, px, y + h - 0.02 * IN, pw, 0.3 * IN, "▮ actual    ┃ target    shaded = range", 10, MUTED, BODY, "r")


def lollipop(sl, box, items, unit="", highlight=None):
    x, y, w, h = box
    rows = sorted([(str(a), num(b)) for a, b in items[:10]], key=lambda r: -r[1])
    lw = 2.4 * IN; px = x + lw; pw = w - lw - 1.0 * IN
    mx = max(r[1] for r in rows) or 1
    rh = min(0.62 * IN, h / len(rows)); top = y + (h - rh * len(rows)) / 2
    hl = highlight or rows[0][0]
    line(sl, px, top - 0.05 * IN, px, top + rh * len(rows), GRID, 1.0, "modern baseline")
    for i, (lab, v) in enumerate(rows):
        cy = top + i * rh + rh / 2; col = SERIES[0] if lab == hl else CONTEXT
        text(sl, x, cy - rh / 2, lw - 0.2 * IN, rh, lab, 14, INK if lab == hl else MUTED, BOLD if lab == hl else BODY, "r", "m")
        ex = px + pw * v / mx
        line(sl, px, cy, ex, cy, col, 2.5, "modern stem")
        oval(sl, ex, cy, 0.2 * IN, col, ring=SURFACE)
        text(sl, ex + 0.16 * IN, cy - rh / 2, 1.0 * IN, rh, fmt(v, unit), 13, INK, BOLD if lab == hl else BODY, "l", "m")


def dumbbell(sl, box, spec):
    x, y, w, h = box
    rows = [(str(r[0]), num(r[1]), num(r[2])) for r in spec["items"][:8]]
    lw = 2.4 * IN; px = x + lw; pw = w - lw - 0.5 * IN
    lo = min(min(a, b) for _, a, b in rows); hi = max(max(a, b) for _, a, b in rows)
    lo = 0 if lo >= 0 and lo < hi * 0.5 else lo - (hi - lo) * 0.1; rng = (hi - lo) or 1
    X = lambda v: px + pw * (v - lo) / rng
    rh = min(0.6 * IN, (h - 0.5 * IN) / len(rows)); top = y + 0.5 * IN
    oval(sl, px, y + 0.15 * IN, 0.16 * IN, CONTEXT); text(sl, px + 0.15 * IN, y + 0.02 * IN, 1.4 * IN, 0.28 * IN, str(spec.get("from", "Before")), 12, MUTED, BOLD)
    oval(sl, px + 1.7 * IN, y + 0.15 * IN, 0.16 * IN, SERIES[0]); text(sl, px + 1.85 * IN, y + 0.02 * IN, 1.4 * IN, 0.28 * IN, str(spec.get("to", "After")), 12, INK, BOLD)
    for i, (lab, a, b) in enumerate(rows):
        cy = top + i * rh + rh / 2
        text(sl, x, cy - rh / 2, lw - 0.2 * IN, rh, lab, 14, INK, BOLD, "r", "m")
        line(sl, px, cy, px + pw, cy, GRID, 0.75, "modern guide")
        line(sl, X(a), cy, X(b), cy, SERIES[0] if b >= a else SERIES[1], 3.5, "modern dumbbell bar")
        oval(sl, X(a), cy, 0.2 * IN, CONTEXT, ring=SURFACE); oval(sl, X(b), cy, 0.22 * IN, SERIES[0], ring=SURFACE)
        lx = X(b) + (0.16 * IN if b >= a else -1.0 * IN)
        text(sl, lx, cy - rh / 2, 0.85 * IN, rh, fmt(b, spec.get("unit", "")), 12, INK, BOLD, "l" if b >= a else "r", "m")


def slope(sl, box, spec):
    x, y, w, h = box
    rows = [(str(r[0]), num(r[1]), num(r[2])) for r in spec["items"][:7]]
    hl = spec.get("highlight") or max(rows, key=lambda r: abs(r[2] - r[1]))[0]
    x1, x2 = x + w * 0.3, x + w * 0.7; ty, by = y + 0.55 * IN, y + h - 0.2 * IN
    allv = [v for _, a, b in rows for v in (a, b)]; lo, hi = min(allv), max(allv); rng = (hi - lo) or 1
    Y = lambda v: by - (v - lo) / rng * (by - ty)
    for xx, lab in ((x1, spec.get("from", "Before")), (x2, spec.get("to", "After"))):
        line(sl, xx, ty - 0.1 * IN, xx, by + 0.1 * IN, GRID, 1.0, "modern axis")
        text(sl, xx - 0.8 * IN, y, 1.6 * IN, 0.35 * IN, str(lab), 14, MUTED, BOLD, "c")
    for lab, a, b in sorted(rows, key=lambda r: r[0] == hl):
        col = SERIES[0] if lab == hl else CONTEXT; wt = 3.0 if lab == hl else 1.75
        line(sl, x1, Y(a), x2, Y(b), col, wt, "modern slope")
        oval(sl, x1, Y(a), 0.16 * IN, col, ring=SURFACE); oval(sl, x2, Y(b), 0.16 * IN, col, ring=SURFACE)
        fc, ff = (INK, BOLD) if lab == hl else (MUTED, BODY)
        text(sl, x, Y(a) - 0.15 * IN, x1 - x - 0.18 * IN, 0.3 * IN, f"{lab}  {fmt(a, spec.get('unit', ''))}", 12, fc, ff, "r", "m")
        text(sl, x2 + 0.18 * IN, Y(b) - 0.15 * IN, x + w - x2 - 0.2 * IN, 0.3 * IN, f"{fmt(b, spec.get('unit', ''))}  {lab}", 12, fc, ff, "l", "m")


def waffle(sl, box, spec):
    x, y, w, h = box
    v = int(round(num(spec.get("value"))))
    side = min(h, w * 0.5); cell = side / 10; gap = cell * 0.14
    gx = x + 0.2 * IN
    for k in range(100):
        r, c = divmod(k, 10)
        on = k < v
        rect(sl, gx + c * cell, y + (h - side) / 2 + (9 - r) * cell, cell - gap, cell - gap, SERIES[0] if on else TRACK,
             radius=(cell - gap) * 0.22, name="modern waffle cell")
    tx = gx + side + 0.6 * IN
    text(sl, tx, y + h * 0.22, x + w - tx, 1.4 * IN, f"{v}%", 72, INK, DISPLAY, "l", "b")
    text(sl, tx, y + h * 0.22 + 1.5 * IN, x + w - tx, 1.2 * IN, spec.get("label", ""), 18, INK, BOLD)
    if spec.get("note"):
        text(sl, tx, y + h * 0.22 + 2.3 * IN, x + w - tx, 1.0 * IN, spec["note"], 12, MUTED, BODY)


def stack100(sl, box, spec):
    x, y, w, h = box
    ser = spec.get("series") or []
    rows = spec["items"][:6]
    lw = 2.2 * IN; px = x + lw; pw = w - lw
    ly = y; lx = px
    for j, s in enumerate(ser[:4]):
        col = SERIES[j] if j < 3 else CONTEXT
        rect(sl, lx, ly + 0.06 * IN, 0.18 * IN, 0.18 * IN, col, radius=0.03 * IN)
        text(sl, lx + 0.26 * IN, ly, 1.8 * IN, 0.3 * IN, s, 12, INK, BOLD); lx += 0.4 * IN + len(s) * 0.09 * IN + 0.3 * IN
    top = y + 0.55 * IN; rh = min(0.75 * IN, (h - 0.55 * IN) / len(rows)); bh = rh * 0.62
    for i, r in enumerate(rows):
        vals = [num(v) for v in r[1:1 + len(ser)]]; tot = sum(vals) or 1
        cy = top + i * rh
        text(sl, x, cy, lw - 0.2 * IN, bh, str(r[0]), 14, INK, BOLD, "r", "m")
        cx = px
        for j, v in enumerate(vals):
            sw = pw * v / tot
            col = SERIES[j] if j < 3 else CONTEXT
            rect(sl, cx, cy, max(sw - 0.03 * IN, 1), bh, col, name="modern stack part")
            if sw > 0.55 * IN:
                text(sl, cx, cy, sw - 0.03 * IN, bh, f"{100 * v / tot:.0f}%", 12, "FFFFFF" if j in (0, 2) else INK, BOLD, "c", "m")
            cx += sw


def treemap(sl, box, items):
    x, y, w, h = box
    rows = sorted([(str(a), num(b)) for a, b in items[:10]], key=lambda r: -r[1])
    tot = sum(v for _, v in rows) or 1
    cols = [SERIES[0], SERIES[1], SERIES[2], "E8275A", "FF893F", "E4C8DB", "FAD3DB", "FDE1D2", "D9D9D9", "F2F2F2"]

    def lay(items_, x, y, w, h):          # slice-and-dice by the longer side, largest first (readable, stable)
        if not items_:
            return []
        if len(items_) == 1:
            return [(items_[0], x, y, w, h)]
        s = sum(v for _, v in items_); half, acc, k = s / 2, 0, 0
        while k < len(items_) - 1 and acc + items_[k][1] <= half:
            acc += items_[k][1]; k += 1
        k = max(1, k); a, b = items_[:k], items_[k:]
        fa = sum(v for _, v in a) / s
        if w >= h:
            return lay(a, x, y, w * fa, h) + lay(b, x + w * fa, y, w * (1 - fa), h)
        return lay(a, x, y, w, h * fa) + lay(b, x, y + h * fa, w, h * (1 - fa))

    for i, ((lab, v), rx, ry, rw, rh) in enumerate(lay(rows, x, y, w, h)):
        col = cols[rows.index((lab, v)) % len(cols)]
        rect(sl, rx, ry, rw - 0.04 * IN, rh - 0.04 * IN, col, name="modern treemap tile")
        dark = col in ("C10060", "5D0F43", "E8275A")
        tc = "FFFFFF" if dark else INK
        if rw > 0.9 * IN and rh > 0.55 * IN:
            text(sl, rx + 0.12 * IN, ry + 0.1 * IN, rw - 0.25 * IN, rh - 0.2 * IN, f"{lab}\n{100 * v / tot:.0f}%",
                 16 if rw > 2.2 * IN and rh > 1.2 * IN else 12, tc, BOLD)


def _label_dates(labels):
    """'Apr 6', '6 Apr', '2026-04-06', '4/6' as dates (the year carried on, Dec -> Jan rolls over); None when any is not."""
    import datetime as _dt
    fmts = ("%Y-%m-%d", "%b %d %Y", "%d %b %Y", "%b %d %y", "%d %b %y", "%m/%d/%Y", "%b %d", "%d %b", "%B %d", "%d %B", "%m/%d")
    out, year, last = [], _dt.date.today().year, None
    for t in labels:
        t = str(t).strip().rstrip(".")
        for f in fmts:
            try:
                d = _dt.datetime.strptime(t, f).date()
                break
            except ValueError:
                continue
        else:
            return None
        if "%Y" not in f and "%y" not in f:               # no year written: this year, carried over the new year
            d = d.replace(year=year)
            if last and d < last:
                year += 1; d = d.replace(year=year)
        out.append(d); last = d
    return out if all(a < b for a, b in zip(out, out[1:])) else None


def trend(sl, box, spec):
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE
    x, y, w, h = box
    import datetime as _dt
    cd = CategoryChartData(); cd.categories = [str(c) for c in spec["x"]]
    dates = None
    if len(spec["x"]) > 13:                                # 26 weeks: a date axis labels the months
        try:
            dates = ([_dt.date.fromisoformat(str(d)[:10]) for d in spec["dates"]]
                     if len(spec.get("dates") or []) == len(spec["x"]) else _label_dates(spec["x"]))
        except ValueError:
            dates = None
        if dates:
            cd.categories = dates
    cd.add_series(spec.get("series", "Value"), [num(v) for v in spec["y"]])
    if spec.get("target") is not None:                     # the target as a flat dashed line: the gap is visible
        cd.add_series(spec.get("target_label") or "Target", [num(spec["target"])] * len(spec["y"]))
    gf = sl.shapes.add_chart(XL_CHART_TYPE.LINE, int(x), int(y + 0.2 * IN), int(w * 0.72), int(h - 0.2 * IN), cd)
    import data_slides as _DS
    _DS.fix_axis_ids(gf)                                  # schema-valid axis ids (python-pptx writes negative ones)
    ch = gf.chart; ch.has_legend = False; ch.has_title = False; ch.font.size = Pt(11); ch.font.name = BODY; ch.font.color.rgb = rgb(MUTED)
    s = ch.plots[0].series[0]; s.smooth = bool(spec.get("smooth", False))   # straight segments: no invented values
    s.format.line.color.rgb = rgb(SERIES[0]); s.format.line.width = Pt(3)
    from pptx.enum.chart import XL_MARKER_STYLE
    s.marker.style = XL_MARKER_STYLE.NONE
    at = int(spec.get("at", len(spec["y"]) - 1))
    if spec.get("target") is not None:
        tg = ch.plots[0].series[1]; tg.smooth = False; tg.marker.style = XL_MARKER_STYLE.NONE
        tg.format.line.color.rgb = rgb(MUTED); tg.format.line.width = Pt(1.5)
        from pptx.enum.dml import MSO_LINE_DASH_STYLE
        tg.format.line.dash_style = MSO_LINE_DASH_STYLE.DASH
        lp = tg.points[len(spec["y"]) - 1].data_label
        lp.has_text_frame = True; lp.text_frame.text = spec.get("target_label") or "Target"
        from pptx.enum.chart import XL_LABEL_POSITION
        lp.position = XL_LABEL_POSITION.ABOVE
        lp.text_frame.paragraphs[0].runs[0].font.size = Pt(11); lp.text_frame.paragraphs[0].runs[0].font.color.rgb = rgb(MUTED)
    pt = s.points[at]; pt.marker.style = XL_MARKER_STYLE.CIRCLE; pt.marker.size = 11
    pt.marker.format.fill.solid(); pt.marker.format.fill.fore_color.rgb = rgb(SERIES[0])
    pt.marker.format.line.color.rgb = rgb(SURFACE)
    va = ch.value_axis; va.has_major_gridlines = True
    if spec.get("format"):                                 # the KPI's own units on the axis ($, %, min)
        va.tick_labels.number_format = spec["format"]; va.tick_labels.number_format_is_linked = False
    va.major_gridlines.format.line.color.rgb = rgb(GRID); va.major_gridlines.format.line.width = Pt(0.75)
    va.format.line.fill.background(); va.tick_labels.font.size = Pt(11)
    ca = ch.category_axis; ca.format.line.color.rgb = rgb(GRID); ca.tick_labels.font.size = Pt(11)
    if dates:
        _DS.date_axis(ca._element, dates)
        if not spec.get("dates") and not re.search(r"\d{4}", str(spec["x"][0])):
            nf = ca._element.find("{http://schemas.openxmlformats.org/drawingml/2006/chart}numFmt")
            if nf is not None:
                nf.set("formatCode", "mmm")                # 'Apr 6' names no year: label months only, never a guessed year
    elif len(spec["x"]) > 13:                              # 26 names side by side overlap: label every 2nd or 3rd, level
        _DS.skip_labels(ca._element, math.ceil(len(spec["x"]) / 12))
        bp = ca._element.find(".//{http://schemas.openxmlformats.org/drawingml/2006/main}bodyPr")
        if bp is not None:
            bp.set("rot", "0"); bp.set("vert", "horz")
    gf.name = "modern trend chart"
    nx = x + w * 0.75
    v = spec["y"][at]
    text(sl, nx, y + 0.5 * IN, w * 0.25, 1.0 * IN, spec.get("value") or fmt(num(v), spec.get("unit", "")), 40, INK, DISPLAY)
    rect(sl, nx, y + 1.55 * IN, 0.06 * IN, 1.4 * IN, SERIES[0], name="modern note accent")
    text(sl, nx + 0.2 * IN, y + 1.5 * IN, w * 0.25 - 0.2 * IN, 2.2 * IN, f"{spec['x'][at]}\n{spec.get('note', '')}", 14, INK, BOLD)


def bento(sl, box, tiles):
    """3-6 tiles: the first one big (2 rows tall), the rest a 2 x 2 or 2 x 3 grid beside it."""
    x, y, w, h = box
    tiles = tiles[:6]; gap = 0.18 * IN
    bw = w * 0.36
    rest = tiles[1:]; cols = 2 if len(rest) <= 4 else 3; rows_ = max(1, math.ceil(len(rest) / cols))
    cw = (w - bw - gap * cols) / cols; ch = (h - gap * (rows_ - 1)) / rows_
    boxes = [(x, y, bw, h)] + [(x + bw + gap + (i % cols) * (cw + gap), y + (i // cols) * (ch + gap), cw, ch) for i in range(len(rest))]
    for i, (t, b) in enumerate(zip(tiles, boxes)):
        tile(sl, b, t, i)


def tile(sl, b, t, i):
    x, y, w, h = b
    kind = t.get("kind", "note")
    if kind == "big":
        rect(sl, x, y, w, h, SERIES[0], radius=0.2 * IN, name="modern bento hero")
        text(sl, x + 0.35 * IN, y + 0.35 * IN, w - 0.7 * IN, 0.4 * IN, t.get("label", ""), 14, "FFFFFF", BOLD)
        text(sl, x + 0.35 * IN, y + h * 0.3, w - 0.7 * IN, 1.4 * IN, t.get("value", ""), 66, "FFFFFF", DISPLAY)
        if t.get("note"):
            text(sl, x + 0.35 * IN, y + h - 1.2 * IN, w - 0.7 * IN, 0.9 * IN, t["note"], 13, "FFFFFF", BODY, "l", "b")
    elif kind == "kpi":
        kpi_tile(sl, b, t, i % 3, 11)
    elif kind == "ring":
        rect(sl, x, y, w, h, SURFACE, radius=0.2 * IN, line=GRID, name="modern card")
        d = min(w, h) * 0.55; cx = x + w * 0.3; cy = y + h / 2
        arc(sl, cx, cy, d, 1.0, TRACK); arc(sl, cx, cy, d, num(t.get("value")) / 100, SERIES[i % 3])
        text(sl, cx - d / 2, cy - 0.25 * IN, d, 0.5 * IN, f"{num(t.get('value')):.0f}%", 18, INK, DISPLAY, "c", "m")
        text(sl, x + w * 0.56, y + 0.2 * IN, w * 0.4, h - 0.4 * IN, t.get("label", ""), 13, INK, BOLD, "l", "m")
    elif kind == "bars":
        rect(sl, x, y, w, h, SURFACE, radius=0.2 * IN, line=GRID, name="modern card")
        text(sl, x + 0.25 * IN, y + 0.18 * IN, w - 0.5 * IN, 0.3 * IN, t.get("label", ""), 11, MUTED, BOLD)
        its = t.get("items") or []; mx = max([num(v) for _, v in its] or [1]) or 1
        n = len(its); bw = (w - 0.5 * IN) / max(n, 1)
        for k, (lab, v) in enumerate(its):
            bh = (h - 1.05 * IN) * num(v) / mx; bx = x + 0.25 * IN + k * bw
            rect(sl, bx + bw * 0.18, y + h - 0.4 * IN - bh, bw * 0.64, bh, SERIES[0] if k == n - 1 else CONTEXT,
                 radius=min(0.05 * IN, bw * 0.2), name="modern bar")
            text(sl, bx, y + h - 0.36 * IN, bw, 0.25 * IN, str(lab), 9, MUTED, BODY, "c")
    else:                                  # the note's text lives in the card itself (keeps the tile's full size)
        card = rect(sl, x, y, w, h, TINT, radius=0.2 * IN, name="modern note card")
        tf = card.text_frame; tf.word_wrap = True; tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf.margin_left = tf.margin_right = int(0.3 * IN); tf.margin_top = tf.margin_bottom = int(0.25 * IN)
        from pptx.enum.text import MSO_AUTO_SIZE
        tf.auto_size = MSO_AUTO_SIZE.NONE
        p = tf.paragraphs[0]; p.alignment = PP_ALIGN.LEFT; r = p.add_run(); r.text = t.get("text", "")
        r.font.size = Pt(14); r.font.name = BOLD; r.font.color.rgb = rgb(INK)


# ---------------------------------------------------------------- points: a list as tiles (no text slide)
TILE_ACCENTS = ["C10060", "E8275A", "F26923", "5D0F43"]   # brand palette fallbacks
TILE_THEME = ["ACCENT_2", "TEXT_2", "ACCENT_4", "ACCENT_1"]   # the template's action-table row colours (slide 12)
LEAD_PT, DETAIL_PT, PLAIN_PT = 18, 14, 16                  # the template's own card type: sub-headline 18, card text 14
STATEMENT_PT = 20                                           # one row of plain sentences: statements (typeset.py "statement")


def split_point(t):
    """'Lead: detail' (lead of 1-5 words, before ':' or a dash) -> (lead, detail); otherwise ('', text). Words unchanged."""
    import re as _re
    t = str(t).strip()
    m = _re.match(r"([^:–—]{2,48}?)\s*(?::|\s[–\u2014-]\s)\s*(\S.*)$", t)
    if m and 1 <= len(m.group(1).split()) <= 5 and not _re.search(r"\d:\d", m.group(0)[:len(m.group(1)) + 2]):
        det = m.group(2).strip()
        if det[:1].islower() and not _re.match(r"[a-z]+[A-Z0-9]", det):   # a sentence after the lead starts upper case
            det = det[0].upper() + det[1:]                                  # (keeps eBay / iPhone / x2 as written)
        return m.group(1).strip(), det
    return "", t


def as_points(bullets):
    """A bullets list -> [(lead, detail)] when it can be shown as 2-6 tiles; sub-points join their point's detail.
    None when it cannot (1 or more than 6 points)."""
    items = []
    for it in bullets or []:
        if isinstance(it, dict) and str(it.get("lead") or "").strip():          # {"lead": title, "text": detail}
            items.append((str(it["lead"]).strip(), str(it.get("text") or "").strip()))
            continue
        lvl, txt = (it[0], str(it[1])) if isinstance(it, (list, tuple)) and len(it) == 2 and isinstance(it[0], int) else \
                   (int(it.get("level", 0)), str(it.get("text", ""))) if isinstance(it, dict) else (0, str(it))
        if not txt.strip():
            continue
        first, _, rest = txt.strip().partition("\n")
        if not lvl and rest.strip() and 1 <= len(first.split()) <= 10:   # "title, new line, detail": the title leads
            items.append((" ".join(first.split()), " ".join(rest.split())))
            continue
        if lvl and items:
            lead, det = items[-1]
            items[-1] = (lead, (det + "; " if det else "") + txt.strip())
        else:
            items.append(split_point(txt))
    return items if 2 <= len(items) <= 6 else None


def _lines(text, font, pt, width, measure):
    """Lines `text` takes at `pt` in `width` EMU (greedy word wrap with the brand's metrics)."""
    if not text:
        return 0
    n, cur = 1, ""
    for w_ in str(text).split():
        trial = (cur + " " + w_).strip()
        if cur and measure(trial, font) * pt * 12700 > width * 0.9:      # 10% slack: PowerPoint and substitute fonts wrap earlier
            n += 1; cur = w_
        else:
            cur = trial
    return n


def points(sl, box, items, measure, numbered=True, start=1):
    """2-6 points as tiles in a grid (3 = one row, 4 = 2 x 2, 5-6 = 3 + rest) in the middle of the space under the
    headline: the template's own card (white, 4% corners, no outline, no effects), a numbered badge in a template colour
    (none when numbered is False), the lead in Circular Bold 18 pt and the detail in Circular 14 pt - the template's card
    type. One row of plain sentences (no leads) is a row of statements, set at 20 pt. The text lives in the tile
    (editable, moves with it). Returns [] or a list of problems (text that cannot fit)."""
    x, y, w, h = box
    n = len(items)
    cols = n if n <= 3 else 2 if n == 4 else 3
    rows = math.ceil(n / cols)
    gap = 0.3 * IN; pad = 0.32 * IN; badge = 0.5 * IN
    tw = (w - gap * (cols - 1)) / cols
    inner = tw - 2 * pad

    def need(lead, det, dpt):
        hh = pad + (badge + 0.2 * IN if numbered else 0)
        if lead:
            hh += _lines(lead, BOLD, LEAD_PT, inner, measure) * LEAD_PT * 1.18 * 12700 + 0.06 * IN
        hh += _lines(det, BODY, dpt, inner, measure) * dpt * 1.25 * 12700
        return hh + pad + 0.08 * IN

    room = (h - gap * (rows - 1)) / rows
    # one body size on every tile (the template's 14 pt card text); a single row of sentences without leads would
    # sit as small print in a wide band, so it is set as statements first
    statements = rows == 1 and not any(l for l, _ in items)
    dpt = DETAIL_PT
    for dpt in ((STATEMENT_PT, 18, 16) if statements else ()) + (DETAIL_PT, 13, 12):
        sizes = [need(l, d, dpt) for l, d in items]
        if max(sizes) <= room:
            break
    th = min(room, max(max(sizes), 1.45 * IN))           # sized to the content: no half-empty cards
    probs = [] if max(sizes) <= room else [f"{n} points do not fit as tiles even at 12 pt - cut each to one short line"]
    grid_h = rows * th + gap * (rows - 1)
    y0 = y + max(0, h - grid_h) * 0.45                   # in the middle of the free space (a touch high: the optical centre),
                                                         # not stuck under the headline over an empty lower half
    for i, (lead, det) in enumerate(items):
        r, c = divmod(i, cols)
        in_row = min(cols, n - r * cols)
        x0 = x + (w - (in_row * tw + gap * (in_row - 1))) / 2          # a short last row is centred
        tx, ty = x0 + c * (tw + gap), y0 + r * (th + gap)
        acc = TILE_THEME[i % len(TILE_THEME)]                    # the template's row colours, as theme references
        card = rect(sl, tx, ty, tw, th, SURFACE, radius=0.04149 * min(tw, th), line=None, name=f"Point {i + 1}")
        tf = card.text_frame; tf.word_wrap = True; tf.vertical_anchor = MSO_ANCHOR.TOP
        from pptx.enum.text import MSO_AUTO_SIZE
        tf.auto_size = MSO_AUTO_SIZE.NONE
        tf.margin_left = tf.margin_right = int(pad); tf.margin_bottom = int(pad)
        tf.margin_top = int(pad + badge + 0.2 * IN) if numbered else int(pad)
        from pptx.enum.dml import MSO_THEME_COLOR
        paras = ([(lead, BOLD, LEAD_PT, acc, True)] if lead else []) + [(det, BODY, dpt, "000000", None)]
        for k, (txt, font, pt, col, bold) in enumerate(paras):
            p = tf.paragraphs[0] if k == 0 else tf.add_paragraph()
            p.alignment = PP_ALIGN.LEFT
            if k:
                p.space_before = Pt(4)
            run = p.add_run(); run.text = txt
            run.font.name = font; run.font.size = Pt(pt); run.font.bold = bold
            if col in TILE_THEME:
                run.font.color.theme_color = getattr(MSO_THEME_COLOR, col)   # the lead in its badge's colour (template cards)
            else:
                run.font.color.rgb = rgb(col)
        if not numbered:                                 # unordered points: the coloured lead carries the accent
            continue
        b = oval(sl, tx + pad + badge / 2, ty + pad + badge / 2, badge, "FFFFFF", name=f"Point {i + 1} number")
        b.fill.fore_color.theme_color = getattr(MSO_THEME_COLOR, acc)
        bt = b.text_frame; bt.margin_left = bt.margin_right = bt.margin_top = bt.margin_bottom = 0
        bt.vertical_anchor = MSO_ANCHOR.MIDDLE
        bp = bt.paragraphs[0]; bp.alignment = PP_ALIGN.CENTER
        br = bp.add_run(); br.text = f"{start + i}"                # a list carried over from the slide before: 6, 7...
        br.font.name = BOLD; br.font.size = Pt(16); br.font.bold = True; br.font.color.rgb = rgb("FFFFFF")
    return probs


# ---------------------------------------------------------------- fancy charts (flows, radial, packed)
MANY = ["D01381", "F16A1C", "5D0F43", "EA0B59", "F14C24", "FF893F", "C10060", "DE7445"]   # theme colours first, then the wheel
LIGHT_FILLS = ("F26923", "FF893F", "DE7445")          # text on these is black; on the rest white


def _alpha(shp, a):
    """Fill transparency (a = 0..1 opacity) - same colour, so it stays on palette."""
    from lxml import etree
    etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
    sf = shp.fill._xPr.find("{http://schemas.openxmlformats.org/drawingml/2006/main}solidFill")
    if sf is not None and len(sf):
        clr = sf[0]
        for old in clr.findall("{http://schemas.openxmlformats.org/drawingml/2006/main}alpha"):
            clr.remove(old)
        etree.SubElement(clr, "{http://schemas.openxmlformats.org/drawingml/2006/main}alpha").set("val", str(int(a * 100000)))


def polygon(sl, pts, fill, alpha=1.0, outline=None, width=1.5, name="modern area"):
    fb = sl.shapes.build_freeform(int(pts[0][0]), int(pts[0][1]), scale=1.0)
    fb.add_line_segments([(int(x), int(y)) for x, y in pts[1:]], close=True)
    shp = fb.convert_to_shape()
    shp.fill.solid(); shp.fill.fore_color.rgb = rgb(fill)
    if alpha < 1:
        _alpha(shp, alpha)
    if outline:
        shp.line.color.rgb = rgb(outline); shp.line.width = Pt(width)
    else:
        _noline(shp)
    shp.shadow.inherit = False; shp.name = name
    return shp


def _smooth(pts, n=10):
    """Catmull-Rom through the points - the soft curves of a modern area / stream chart."""
    if len(pts) < 3:
        return pts
    P = [pts[0]] + list(pts) + [pts[-1]]
    out = []
    for i in range(1, len(P) - 2):
        p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
        for k in range(n):
            t = k / n; t2, t3 = t * t, t * t * t
            out.append(tuple(0.5 * (2 * p1[j] + (-p0[j] + p2[j]) * t + (2 * p0[j] - 5 * p1[j] + 4 * p2[j] - p3[j]) * t2
                                    + (-p0[j] + 3 * p1[j] - 3 * p2[j] + p3[j]) * t3) for j in (0, 1)))
    out.append(pts[-1])
    return out


def wedge(sl, cx, cy, r_out, r_in, a0, a1, fill, name="modern segment"):
    """A ring segment from angle a0 to a1 (degrees, 0 = 3 o'clock, clockwise)."""
    if r_in <= 0:
        shp = sl.shapes.add_shape(MSO_SHAPE.PIE, int(cx - r_out), int(cy - r_out), int(2 * r_out), int(2 * r_out))
        shp.adjustments[0] = ANG(a0 % 360); shp.adjustments[1] = ANG(a1 % 360)
    else:
        shp = sl.shapes.add_shape(MSO_SHAPE.BLOCK_ARC, int(cx - r_out), int(cy - r_out), int(2 * r_out), int(2 * r_out))
        shp.adjustments[0] = ANG(a0 % 360); shp.adjustments[1] = ANG(a1 % 360 if (a1 - a0) < 359.9 else (a0 + 359.9) % 360)
        shp.adjustments[2] = (r_out - r_in) / (2 * r_out)
    shp.fill.solid(); shp.fill.fore_color.rgb = rgb(fill)
    shp.line.color.rgb = rgb(SURFACE); shp.line.width = Pt(1.5)
    shp.shadow.inherit = False; shp.name = name
    return shp


def sankey(sl, box, flows):
    """Flows between 2-4 stages as curved bands; node height = its total."""
    x, y, w, h = box
    flows = [(str(a), str(b), num(v)) for a, b, v in flows if num(v) > 0]
    nodes = []
    for a, b, _ in flows:
        for n in (a, b):
            if n not in nodes:
                nodes.append(n)
    col = {n: 0 for n in nodes}
    for _ in range(len(nodes)):
        for a, b, _v in flows:
            col[b] = max(col[b], col[a] + 1)
    ncol = max(col.values()) + 1
    size = {n: max(sum(v for a, _, v in flows if a == n), sum(v for _, b, v in flows if b == n)) for n in nodes}
    colw = 0.22 * IN; labw = 1.5 * IN
    gapy = 0.14 * IN
    stacks = {c: [n for n in nodes if col[n] == c] for c in range(ncol)}
    scale = min((h - gapy * (len(s) - 1)) / (sum(size[n] for n in s) or 1) for s in stacks.values())
    span = w - labw * 2 - colw
    X = {c: x + labw + span * c / max(ncol - 1, 1) for c in range(ncol)}
    pos = {}
    for c, s in stacks.items():
        tot = sum(size[n] for n in s) * scale + gapy * (len(s) - 1); yy = y + (h - tot) / 2
        for n in s:
            pos[n] = [yy, yy]; yy += size[n] * scale + gapy        # [next out offset, next in offset]
    # Colours (Studio v6.31): every node its own colour, in column order; a band out of a node that splits takes the colour of where it
    # goes, a band out of a node that does not split keeps its source's colour - so each branch keeps one colour from the split to where
    # it rejoins. (Before: only the first column's nodes had colours and everything after inherited them, so a flow with one start - an
    # order, a PO - drew every band and node in the same magenta, and the overlaps stacked into one dark smear.)
    order = sorted(nodes, key=lambda n: (col[n], -size[n], nodes.index(n)))
    outs = {n: sum(1 for a_, _b, _v in flows if a_ == n) for n in nodes}
    trunk = {n for n in stacks[0] if len(stacks[0]) == 1 and outs[n] >= 2}   # one start that splits: neutral, the colours are its branches'
    colour = {n: MANY[i % len(MANY)] for i, n in enumerate([n for n in order if n not in trunk])}
    colour.update({n: MUTED for n in trunk})
    for a, b, v in sorted(flows, key=lambda f: (col[f[0]], nodes.index(f[0]))):
        th = v * scale
        x0, x1 = X[col[a]] + colw, X[col[b]]
        ya, yb = pos[a][0], pos[b][1]; pos[a][0] += th; pos[b][1] += th
        steps = 24; top, bot = [], []
        for k in range(steps + 1):
            t = k / steps; s_ = t * t * (3 - 2 * t)
            xx = x0 + (x1 - x0) * t
            top.append((xx, ya + (yb - ya) * s_)); bot.append((xx, ya + th + (yb - ya) * s_))
        polygon(sl, top + bot[::-1], colour[b] if outs[a] >= 2 else colour[a], 0.55, name="modern flow band")
    for n in nodes:
        c = col[n]; yy = pos[n][0] - size[n] * scale if pos[n][0] > pos[n][1] - 1 else pos[n][1] - size[n] * scale
        top_ = min(pos[n][0], pos[n][1]) - size[n] * scale if c else pos[n][0] - size[n] * scale
        top_ = (pos[n][0] if c == 0 else pos[n][1]) - size[n] * scale
        rect(sl, X[c], top_, colw, max(size[n] * scale, 0.04 * IN), colour.get(n, MANY[0]), name="modern flow node")
        left = c == 0
        lx = X[c] - labw - 0.08 * IN if left else X[c] + colw + 0.1 * IN
        text(sl, lx, top_ + size[n] * scale / 2 - 0.25 * IN, labw, 0.5 * IN, f"{n}\n{fmt(size[n])}", 12, INK, BOLD,
             "r" if left else "l", "m")


def sunburst(sl, box, items, center=""):
    """Inner ring = groups, outer ring = their parts; items [[group, part, value], ...]."""
    x, y, w, h = box
    rows = [(str(g), str(p), num(v)) for g, p, v in items]
    groups = []
    for g, _, _ in rows:
        if g not in groups:
            groups.append(g)
    tot = sum(v for *_, v in rows) or 1
    R = min(h, w * 0.6) / 2; cx, cy = x + R + 0.3 * IN, y + h / 2
    r0, r1, r2 = R * 0.34, R * 0.66, R
    a = -90.0
    legend = []
    for gi, g in enumerate(groups):
        gv = sum(v for gg, _, v in rows if gg == g); sweep = 360 * gv / tot; col = MANY[gi % len(MANY)]
        wedge(sl, cx, cy, r1, r0, a, a + sweep, col)
        b = a
        for k, (gg, p, v) in enumerate([r for r in rows if r[0] == g]):
            sw = 360 * v / tot
            sh = wedge(sl, cx, cy, r2, r1 + 0.04 * IN, b, b + sw, col)
            _alpha(sh, 0.88 - 0.18 * (k % 3))
            b += sw
        legend.append((g, gv, col)); a += sweep
    text(sl, cx - r0, cy - 0.3 * IN, 2 * r0, 0.6 * IN, center or fmt(tot), 22, INK, DISPLAY, "c", "m")   # the data's own total
    lx = cx + R + 0.6 * IN; ly = y + (h - len(legend) * 0.75 * IN) / 2
    for g, gv, col in legend:
        rect(sl, lx, ly + 0.08 * IN, 0.22 * IN, 0.22 * IN, col, radius=0.04 * IN)
        parts = ", ".join(p for gg, p, _ in rows if gg == g)
        text(sl, lx + 0.35 * IN, ly, x + w - lx - 0.35 * IN, 0.7 * IN, f"{g}  {100 * gv / tot:.0f}%\n{parts}", 12, INK, BOLD)
        ly += 0.75 * IN


def butterfly(sl, box, spec):
    """Back-to-back bars: two groups compared row by row (population-pyramid style)."""
    x, y, w, h = box
    rows = [(str(r[0]), num(r[1]), num(r[2])) for r in spec["items"][:12]]
    mid = x + w / 2; lab = 1.3 * IN; half = w / 2 - lab / 2 - 0.7 * IN
    mx = max(max(a, b) for _, a, b in rows) or 1
    top = y + 0.45 * IN; rh = (h - 0.45 * IN) / len(rows); bh = rh * 0.66
    text(sl, mid - lab / 2 - half, y, half, 0.3 * IN, str(spec.get("left", "Left")), 14, INK, BOLD, "r")
    text(sl, mid + lab / 2, y, half, 0.3 * IN, str(spec.get("right", "Right")), 14, INK, BOLD, "l")
    for i, (l, a, b) in enumerate(rows):
        cy = top + i * rh + (rh - bh) / 2
        text(sl, mid - lab / 2, cy, lab, bh, l, 12, MUTED, BOLD, "c", "m")
        wa, wb = half * a / mx, half * b / mx
        rect(sl, mid - lab / 2 - wa, cy, wa, bh, SERIES[0], name="modern bar left")
        rect(sl, mid + lab / 2, cy, wb, bh, SERIES[1], name="modern bar right")
        text(sl, mid - lab / 2 - wa - 0.75 * IN, cy, 0.7 * IN, bh, fmt(a, spec.get("unit", "")), 11, INK, BODY, "r", "m")
        text(sl, mid + lab / 2 + wb + 0.06 * IN, cy, 0.7 * IN, bh, fmt(b, spec.get("unit", "")), 11, INK, BODY, "l", "m")


def stream(sl, box, spec):
    """Streamgraph: layered soft waves around a centre line, one per series."""
    x, y, w, h = box
    xs = [str(v) for v in spec["x"]]; ser = list(spec["series"].items())[:6]
    n = len(xs); lw = 1.6 * IN; pw = w - lw
    tot = [sum(num(s[1][i]) for s in ser) for i in range(n)]; mx = max(tot) or 1
    sc = (h - 0.5 * IN) / mx; X = lambda i: x + pw * i / (n - 1); midy = y + (h - 0.5 * IN) / 2
    base = [midy - tot[i] * sc / 2 for i in range(n)]
    labels = []
    for k, (name, vals) in enumerate(ser):
        top = [(X(i), base[i]) for i in range(n)]
        bot = [(X(i), base[i] + num(vals[i]) * sc) for i in range(n)]
        col = MANY[k % len(MANY)]
        polygon(sl, _smooth(top) + _smooth(bot)[::-1], col, 0.9, name="modern stream layer")
        labels.append([base[-1] + num(vals[-1]) * sc / 2, name])
        base = [base[i] + num(vals[i]) * sc for i in range(n)]
    gap = 0.3 * IN                                   # thin layers at the right edge: spread their labels
    for i in range(1, len(labels)):
        labels[i][0] = max(labels[i][0], labels[i - 1][0] + gap)
    for cy, name in labels:
        text(sl, x + pw + 0.15 * IN, cy - 0.15 * IN, lw - 0.2 * IN, 0.3 * IN, name, 12, INK, BOLD, "l", "m")
    for i, lab in enumerate(xs):
        text(sl, X(i) - 0.5 * IN, y + h - 0.35 * IN, 1.0 * IN, 0.3 * IN, lab, 11, MUTED, BODY, "c")


def radialbar(sl, box, items):
    """Race-track rings: one concentric ring per item; 100% = three quarters of a circle (12 o'clock round to 9),
    so the top-left quarter stays free for the labels."""
    x, y, w, h = box
    rows = [(str(a), num(b)) for a, b in items[:6]]
    R = min(h, w * 0.55) / 2; cx, cy = x + w / 2 + R * 0.15, y + h / 2
    band = R * 0.7 / len(rows)
    for i, (lab, v) in enumerate(rows):
        r_out = R - i * band; r_in = r_out - band * 0.72
        wedge(sl, cx, cy, r_out, r_in, -90, 180, TRACK, name="modern ring track")
        if v > 0:
            wedge(sl, cx, cy, r_out, r_in, -90, -90 + 270 * min(v, 100) / 100, MANY[i % len(MANY)], name="modern ring value")
        text(sl, cx - 2.6 * IN, cy - r_out, 2.5 * IN, r_out - r_in, f"{lab}  {fmt(v, '%')}", 12, INK, BOLD, "r", "m")   # 40.5% vs 39.8%


def radar(sl, box, spec):
    """Spider chart: one polygon per series over 3-8 axes, on a 0-max web."""
    x, y, w, h = box
    axes = [str(a) for a in spec["axes"]][:8]; n = len(axes); mx = num(spec.get("max", 100)) or 100
    R = min(h * 0.42, w * 0.3); cx, cy = x + w * 0.42, y + h / 2
    P = lambda i, f: (cx + R * f * math.cos(-math.pi / 2 + 2 * math.pi * i / n), cy + R * f * math.sin(-math.pi / 2 + 2 * math.pi * i / n))
    for f in (0.25, 0.5, 0.75, 1.0):
        pts = [P(i, f) for i in range(n)]
        polyline(sl, pts + [pts[0]], GRID, 0.75, "modern web")
    for i, a in enumerate(axes):
        line(sl, cx, cy, *P(i, 1.0), GRID, 0.75, "modern spoke")
        px, py = P(i, 1.14)
        text(sl, px - 0.9 * IN, py - 0.2 * IN, 1.8 * IN, 0.4 * IN, a, 12, INK, BOLD, "c", "m")
    for k, (name, vals) in enumerate(list(spec["series"].items())[:3]):
        pts = [P(i, max(0, min(num(vals[i]) / mx, 1))) for i in range(n)]
        polygon(sl, pts, SERIES[k], 0.22, outline=SERIES[k], width=2.25, name="modern radar area")
        for p_ in pts:
            oval(sl, p_[0], p_[1], 0.12 * IN, SERIES[k], ring=SURFACE)
        ly = y + 0.4 * IN + k * 0.45 * IN
        rect(sl, x + w * 0.78, ly + 0.06 * IN, 0.22 * IN, 0.22 * IN, SERIES[k], radius=0.04 * IN)
        text(sl, x + w * 0.78 + 0.32 * IN, ly, w * 0.2, 0.35 * IN, name, 13, INK, BOLD, "l", "m")


def bubbles(sl, box, items):
    """Packed circles, area = value; the biggest first, each placed as close to the centre as it fits."""
    x, y, w, h = box
    rows = sorted([(str(a), num(b)) for a, b in items[:14]], key=lambda r: -r[1])
    mx = rows[0][1] or 1
    rmax = min(w - 3.6 * IN, h) * 0.26
    cx0, cy0 = x + (w - 1.8 * IN) / 2, y + h / 2

    def pack(rmax):
        """Every circle placed beside the others, or None when one does not fit (then all are drawn smaller)."""
        placed = []
        for r in (rmax * math.sqrt(max(v, 0) / mx) for _, v in rows):
            if not placed:
                placed.append((cx0, cy0, r)); continue
            best = None
            for (px, py, pr) in placed:
                for k in range(72):
                    a = 2 * math.pi * k / 72
                    qx, qy = px + (pr + r + 0.03 * IN) * math.cos(a), py + (pr + r + 0.03 * IN) * math.sin(a)
                    if qx - r < x or qx + r > x + w - 1.9 * IN or qy - r < y or qy + r > y + h:
                        continue
                    if any(math.hypot(qx - ox, qy - oy) < orr + r + 0.02 * IN for ox, oy, orr in placed):
                        continue
                    d = math.hypot(qx - cx0, (qy - cy0) * 1.6)
                    if best is None or d < best[0]:
                        best = (d, qx, qy)
            if best is None:
                return None
            placed.append((best[1], best[2], r))
        return placed

    for k in range(16):                                  # near-equal values: five big circles need more room than one
        placed = pack(rmax * 0.9 ** k)
        if placed:
            break
    else:
        placed = pack(rmax * 0.9 ** 16) or [(cx0, cy0, rmax * 0.1)] * len(rows)
    small = []
    for i, ((lab, v), (px, py, r)) in enumerate(zip(rows, placed)):
        col = MANY[i % len(MANY)]
        sh = oval(sl, px, py, 2 * r, col, ring=SURFACE, name="modern bubble")
        if r > 0.42 * IN:
            text(sl, px - r, py - 0.3 * IN, 2 * r, 0.6 * IN, f"{lab}\n{fmt(v)}", 13 if r > 0.8 * IN else 10,
                 INK if col in LIGHT_FILLS else "FFFFFF", BOLD, "c", "m")
        else:                                   # too small for its label: listed in a key at the right edge
            small.append((lab, v, col))
    ky = y + h - len(small) * 0.34 * IN
    for lab, v, col in small:
        oval(sl, x + w - 1.75 * IN, ky + 0.15 * IN, 0.2 * IN, col)
        text(sl, x + w - 1.55 * IN, ky, 1.55 * IN, 0.3 * IN, f"{lab}  {fmt(v)}", 11, INK, BOLD, "l", "m")
        ky += 0.34 * IN


def rose(sl, box, items):
    """Polar 'rose': equal angles, wedge length = value - a softer pie for 5-12 items."""
    x, y, w, h = box
    rows = [(str(a), num(b)) for a, b in items[:12]]; n = len(rows); mx = max(v for _, v in rows) or 1
    R = min(h * 0.46, w * 0.3); cx, cy = x + w * 0.4, y + h / 2
    for f in (0.5, 1.0):
        sh = sl.shapes.add_shape(MSO_SHAPE.OVAL, int(cx - R * f), int(cy - R * f), int(2 * R * f), int(2 * R * f))
        sh.fill.background(); sh.line.color.rgb = rgb(GRID); sh.line.width = Pt(0.75); sh.name = "modern polar grid"
    step = 360 / n
    for i, (lab, v) in enumerate(rows):
        a0 = -90 + i * step
        r = R * (0.25 + 0.75 * v / mx)
        wedge(sl, cx, cy, r, 0, a0 + 0.8, a0 + step - 0.8, MANY[i % len(MANY)], name="modern rose petal")
        am = math.radians(a0 + step / 2); lr = r + 0.3 * IN
        lx, ly = cx + lr * math.cos(am), cy + lr * math.sin(am)
        text(sl, lx - 0.8 * IN, ly - 0.22 * IN, 1.6 * IN, 0.44 * IN, f"{lab}\n{fmt(v)}", 11, INK, BOLD, "c", "m")


# ---------------------------------------------------------------- plans and processes
def _date(v):
    import datetime as dt
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    s = str(v).strip()
    for f in ("%Y-%m-%d", "%m/%d/%Y", "%d %b %Y", "%b %d %Y", "%b %d, %Y", "%Y/%m/%d", "%b %Y", "%B %Y"):
        try:
            return dt.datetime.strptime(s, f).date()
        except ValueError:
            pass
    raise ValueError(f"'{s}' is not a date (use 2026-03-15)")


def read_plan(path, sheet=None):
    """Tasks from an Excel / CSV plan: columns Task, Start, End (+ Group / Phase / Workstream, Milestone, Date)."""
    import csv
    rows = []
    if str(path).lower().endswith(".csv"):
        rows = list(csv.DictReader(open(path, encoding="utf-8-sig")))
    else:
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True); ws = wb[sheet] if sheet else wb.active
        it = ws.iter_rows(values_only=True); head = [str(h or "").strip() for h in next(it)]
        rows = [dict(zip(head, r)) for r in it if any(c not in (None, "") for c in r)]
    pick = lambda r, *ks: next((r[k] for k in r if str(k).strip().lower() in ks and r[k] not in (None, "")), None)
    out = []
    for r in rows:
        t = pick(r, "task", "activity", "name", "deliverable", "milestone name")
        if not t:
            continue
        ms = str(pick(r, "milestone", "type") or "").strip().lower() in ("yes", "y", "true", "1", "milestone", "x")
        s, e = pick(r, "start", "start date", "begin"), pick(r, "end", "end date", "finish", "due", "date")
        out.append({"task": str(t), "group": str(pick(r, "group", "phase", "workstream", "stream", "lane") or ""),
                    "start": s or e, "end": e or s, "milestone": ms or (s and e and _date(s) == _date(e))})
    return out


def gantt(sl, box, spec):
    """Roadmap / Gantt: grouped task bars on a week, month or quarter axis, milestone diamonds, a today line."""
    import datetime as dt
    x, y, w, h = box
    tasks = spec.get("tasks") or read_plan(spec["data"], spec.get("sheet"))
    for t in tasks:
        t["_s"] = _date(t.get("start") or t.get("date")); t["_e"] = _date(t.get("end") or t.get("date") or t.get("start"))
    lo = min(t["_s"] for t in tasks); hi = max(t["_e"] for t in tasks)
    span = max((hi - lo).days, 1)
    if span <= 75:
        lo = lo - dt.timedelta(days=lo.weekday()); unit = "week"
    elif span <= 550:
        lo = lo.replace(day=1); unit = "month"
    else:
        lo = lo.replace(day=1, month=(lo.month - 1) // 3 * 3 + 1); unit = "quarter"
    hi = hi + dt.timedelta(days=7 if unit == "week" else 31 if unit == "month" else 92)
    days = (hi - lo).days
    groups = []
    for t in tasks:
        if t.get("group", "") not in groups:
            groups.append(t.get("group", ""))
    rows = []
    for g in groups:
        if g:
            rows.append(("group", g))
        rows += [("task", t) for t in tasks if t.get("group", "") == g]
    lw = 2.7 * IN; px = x + lw; pw = w - lw - 0.1 * IN; head = 0.42 * IN
    rh = min(0.42 * IN, (h - head - 0.32 * IN) / max(len(rows), 1)); fs = 12 if rh > 0.33 * IN else 10
    X = lambda d: px + pw * ((d - lo).days / days)
    # time axis
    ticks, d = [], lo
    while d < hi:
        ticks.append(d)
        if unit == "week":
            d = d + dt.timedelta(days=7)
        else:
            m = d.month + (1 if unit == "month" else 3); d = d.replace(year=d.year + (m - 1) // 12, month=(m - 1) % 12 + 1)
    for i, t in enumerate(ticks):
        nx = X(ticks[i + 1]) if i + 1 < len(ticks) else px + pw
        if i % 2 == 0:
            rect(sl, X(t), y + head, nx - X(t), rh * len(rows), "F8F5F5", name="modern period band")
        lab = (t.strftime("%d %b") if unit == "week" else t.strftime("%b") + (f" {t.year}" if t.month == 1 or i == 0 else "")
               if unit == "month" else f"Q{(t.month - 1) // 3 + 1} {t.year}")
        text(sl, X(t), y, nx - X(t), head - 0.06 * IN, lab, 11, MUTED, BOLD, "c", "b")
    line(sl, px, y + head, px + pw, y + head, CONTEXT, 1.0, "modern axis")
    gi = -1
    for r, (kind, it) in enumerate(rows):
        ry = y + head + r * rh
        if kind == "group":
            gi += 1
            text(sl, x, ry, lw - 0.15 * IN, rh, it, fs + 1, INK, BOLD, "l", "m")
            continue
        col = MANY[max(gi, 0) % len(MANY)]
        text(sl, x + (0.2 * IN if it.get("group") else 0), ry, lw - 0.35 * IN, rh, it["task"], fs, MUTED, BODY, "l", "m")
        if it.get("milestone"):
            d_ = 0.24 * IN; cx = X(it["_e"])
            sh = sl.shapes.add_shape(MSO_SHAPE.DIAMOND, int(cx - d_ / 2), int(ry + (rh - d_) / 2), int(d_), int(d_))
            sh.fill.solid(); sh.fill.fore_color.rgb = rgb(INK); _noline(sh); sh.name = "modern milestone"
            text(sl, cx + d_ / 2 + 0.06 * IN, ry, 1.4 * IN, rh, it["_e"].strftime("%d %b"), fs - 1, INK, BOLD, "l", "m")
        else:
            bx, bw = X(it["_s"]), max(X(it["_e"]) - X(it["_s"]), 0.08 * IN)
            rect(sl, bx, ry + rh * 0.18, bw, rh * 0.64, col, radius=rh * 0.2, name="modern gantt bar")
    if spec.get("today"):
        td = _date(spec["today"])
        if lo <= td <= hi:
            tx = X(td)
            bot = y + head + rh * len(rows)
            line(sl, tx, y + head, tx, bot, SERIES[0], 1.75, "modern today line", dash=True)
            tag = rect(sl, tx - 0.32 * IN, bot + 0.04 * IN, 0.64 * IN, 0.24 * IN, SERIES[0], radius=0.1 * IN, name="modern today tag")
            tf = tag.text_frame; tf.margin_top = tf.margin_bottom = tf.margin_left = tf.margin_right = 0
            tf.vertical_anchor = MSO_ANCHOR.MIDDLE; pp = tf.paragraphs[0]; pp.alignment = PP_ALIGN.CENTER
            rr = pp.add_run(); rr.text = "Today"; rr.font.size = Pt(10); rr.font.name = BOLD; rr.font.color.rgb = rgb("FFFFFF")
    if len(rows) > 18:
        raise ValueError(f"{len(rows)} rows do not fit one slide (18 max) - split the plan by phase")


def _arrow(conn):
    from lxml import etree
    etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
    ln = conn.line._get_or_add_ln()
    for tag in ("tailEnd",):
        e = ln.find("{http://schemas.openxmlformats.org/drawingml/2006/main}" + tag)
        if e is None:
            e = etree.SubElement(ln, "{http://schemas.openxmlformats.org/drawingml/2006/main}" + tag)
        e.set("type", "triangle"); e.set("w", "med"); e.set("len", "med")


def swimlane(sl, box, spec):
    """Swimlane process map: one lane per role or team, steps left to right in order, decisions as diamonds,
    start / end as pills; connectors are glued to the shapes, so moving a box drags its arrows."""
    x, y, w, h = box
    lanes = [str(l) for l in spec["lanes"]][:6]
    steps = spec["steps"]; by = {s["id"]: s for s in steps}
    for s in steps:
        a = s.get("after") or []
        s["_after"] = [a] if isinstance(a, str) else list(a)
    col = {}
    def depth(s, seen=()):
        if s["id"] in col:
            return col[s["id"]]
        d = 0 if not s["_after"] else 1 + max(depth(by[p], seen + (s["id"],)) for p in s["_after"] if p in by and p not in seen)
        col[s["id"]] = d; return d
    for s in steps:
        depth(s)
    used = set()
    for s in sorted(steps, key=lambda s: col[s["id"]]):        # two steps in one cell: the later one moves right
        c = col[s["id"]]
        while (s["lane"], c) in used:
            c += 1
        col[s["id"]] = c; used.add((s["lane"], c))
    ncol = max(col.values()) + 1
    lw = 1.45 * IN; lh = h / len(lanes); cw = (w - lw) / ncol
    for i, l in enumerate(lanes):
        ly = y + i * lh
        rect(sl, x, ly, w, lh, "F8F5F5" if i % 2 == 0 else SURFACE, name="modern lane")
        hd = rect(sl, x, ly, lw - 0.06 * IN, lh, MANY[i % len(MANY)], name="modern lane header")
        tf = hd.text_frame; tf.word_wrap = True; tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER; r = p.add_run(); r.text = l
        r.font.size = Pt(13); r.font.name = BOLD; r.font.color.rgb = rgb(INK if MANY[i % len(MANY)] in LIGHT_FILLS else "FFFFFF")
    line(sl, x, y + h, x + w, y + h, CONTEXT, 0.75, "modern lane edge")
    bw, bh = min(cw * 0.78, 2.1 * IN), min(lh * 0.62, 0.85 * IN)
    shapes = {}
    for s in steps:
        li = lanes.index(s["lane"]); cx = x + lw + cw * (col[s["id"]] + 0.5); cy = y + lh * (li + 0.5)
        kind = s.get("kind", "task")
        if kind == "decision":
            d = min(bh * 1.35, cw * 0.7)
            sh = sl.shapes.add_shape(MSO_SHAPE.DIAMOND, int(cx - d * 0.75), int(cy - d / 2), int(d * 1.5), int(d))
            fill, tc = TINT, INK
            sh.line.color.rgb = rgb(SERIES[0]); sh.line.width = Pt(1.75)
        else:
            sh = sl.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, int(cx - bw / 2), int(cy - bh / 2), int(bw), int(bh))
            sh.adjustments[0] = 0.5 if kind in ("start", "end") else 0.16
            fill, tc = (INK, "FFFFFF") if kind in ("start", "end") else (SURFACE, INK)
            if kind not in ("start", "end"):
                sh.line.color.rgb = rgb(CONTEXT); sh.line.width = Pt(1)
            else:
                _noline(sh)
        sh.fill.solid(); sh.fill.fore_color.rgb = rgb(fill); sh.shadow.inherit = False; sh.name = f"modern step {s['id']}"
        tf = sh.text_frame; tf.word_wrap = True; tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf.margin_left = tf.margin_right = int(0.06 * IN)
        p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER; r = p.add_run(); r.text = s["text"]
        r.font.size = Pt(11 if len(s["text"]) > 22 else 12); r.font.name = BOLD; r.font.color.rgb = rgb(tc)
        shapes[s["id"]] = sh
    for s in steps:                           # connectors: right side -> left side, or down / up between lanes
        for p_ in s["_after"]:
            if p_ not in shapes:
                continue
            a, b = shapes[p_], shapes[s["id"]]
            same_col = col[p_] == col[s["id"]]
            down = lanes.index(by[p_]["lane"]) < lanes.index(s["lane"])
            c = sl.shapes.add_connector(MSO_CONNECTOR.ELBOW, 0, 0, 1, 1)
            other_lane = by[p_]["lane"] != s["lane"]
            from_decision = by[p_].get("kind") == "decision"
            if same_col:
                c.begin_connect(a, 2 if down else 0); c.end_connect(b, 0 if down else 2)
            elif from_decision and other_lane:               # a branch to another lane leaves from the bottom / top
                c.begin_connect(a, 2 if down else 0); c.end_connect(b, 1)
            else:
                c.begin_connect(a, 3); c.end_connect(b, 1)
            c.line.color.rgb = rgb(MUTED); c.line.width = Pt(1.5); _arrow(c); c.name = "modern flow"
            lab = s.get("label") if by[p_].get("kind") == "decision" else None
            if lab:
                if other_lane or same_col:                   # beside the bottom / top point of the diamond
                    ax, ay = a.left + a.width / 2 + 0.06 * IN, (a.top + a.height + 0.02 * IN) if down else (a.top - 0.28 * IN)
                else:                                        # above the right-hand exit
                    ax, ay = a.left + a.width + 0.04 * IN, a.top + a.height / 2 - 0.3 * IN
                text(sl, ax, ay, 0.5 * IN, 0.26 * IN, lab, 11, SERIES[0], BOLD, "l", "m", name="modern flow label")


# ---------------------------------------------------------------- US maps (state shapes: Natural Earth, public domain)
_UM = []


def _usmap():
    """The kit's usmap module (shapes, projection, colour steps), loaded by path: the page and the deck share it."""
    if not _UM:
        import importlib.util
        p = Path(__file__).resolve().parent.parent / "modules" / "ultabranddeliverables" / "scripts" / "kit" / "data" / "usmap.py"
        sp = importlib.util.spec_from_file_location("ulta_usmap", p); m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m)
        _UM.append(m)
    return _UM[0]


def _state(sl, rings_, ox, oy, s, fill, edge, name):
    """One state as one freeform (islands and the Upper Peninsula are further contours of the same shape)."""
    pt = lambda x_, y_: (int(ox + x_ * s), int(oy + y_ * s))
    fb = sl.shapes.build_freeform(*pt(*rings_[0][0]), scale=1.0)
    for k, r in enumerate(rings_):
        if k:
            fb.move_to(*pt(*r[0]))
        fb.add_line_segments([pt(*q) for q in r[1:]], close=True)
    shp = fb.convert_to_shape()
    shp.fill.solid(); shp.fill.fore_color.rgb = rgb(fill)
    shp.line.color.rgb = rgb(edge); shp.line.width = Pt(0.75)
    shp.shadow.inherit = False; shp.name = name
    return shp


def _map_frame(box, rows):
    """(map left, top, scale, list left, list width): the map as large as the box allows, the list of leaders beside it."""
    x, y, w, h = box
    lw = min(3.7 * IN, w * 0.3) if rows else 0
    mh = h - 0.5 * IN; s = min((w - lw - 0.35 * IN) / 975, mh / 610)
    return x, y + (mh - 610 * s) / 2, s, x + 975 * s + 0.35 * IN, lw


def _leaders(sl, x, y, w, h, title, rows):
    """'Leading states' beside the map: a swatch, the name and the value, largest first (at most 8)."""
    text(sl, x, y, w, 0.4 * IN, title, 13, MUTED, BOLD, name="modern map list title")
    rh = min(0.46 * IN, (h - 0.5 * IN) / max(1, len(rows)))
    for i, (name_, v, fill) in enumerate(rows):
        cy = y + 0.5 * IN + i * rh + rh / 2
        rect(sl, x, cy - 0.08 * IN, 0.16 * IN, 0.16 * IN, fill, radius=0.03 * IN, line=EDGE_ if fill == "FFFFFF" else None, name="modern map key")
        text(sl, x + 0.26 * IN, cy - rh / 2, w - 1.5 * IN, rh, name_, 13, INK if i == 0 else MUTED, BOLD if i == 0 else BODY, "l", "m")
        text(sl, x + w - 1.2 * IN, cy - rh / 2, 1.2 * IN, rh, fmt(v), 13, INK, BOLD if i == 0 else BODY, "r", "m")


EDGE_ = "D9D9D9"


def usmap(sl, box, spec):
    """States shaded by value in four steps from light to dark (quartiles), states without data white with a grey
    outline, the steps under the map and the leading states beside it. items: [[state, value], ...] - a state is a
    code (TX), a name (Texas) or 'Dallas, TX'."""
    U = _usmap(); G = U.geometry()["states"]
    vals = {}
    for k, v in spec["items"]:
        c = U.state_of(k)
        if c and c in G:
            vals[c] = vals.get(c, 0.0) + num(v)
    if len(vals) < 2:
        raise ValueError("a US map takes at least two states")
    br = U.breaks(list(vals.values())); n = len(br) + 1
    order = sorted(vals.items(), key=lambda kv: -kv[1])
    ox, oy, s, lx, lw = _map_frame(box, order)
    x, y, w, h = box
    for code, st in G.items():                                   # no data first: the shaded states' white borders sit on top
        if code not in vals:
            _state(sl, U.rings(st["d"]), ox, oy, s, U.NO_DATA, EDGE_, f"modern map {code} (no data)")
    fill = {}
    for code, v in order:
        fill[code] = U.colour(U.step_of(v, br), n)
        _state(sl, U.rings(G[code]["d"]), ox, oy, s, fill[code], "FFFFFF", f"modern map {code}")
    lo, hi = order[-1][1], order[0][1]
    ky = oy + 610 * s + 0.12 * IN; kx = ox
    items = []
    for j in range(n):
        a = br[j - 1] if j else lo; b = br[j] if j < len(br) else hi
        fa, fb = (re.sub(r"(\d)\.0(?!\d)", r"\1", fmt(v)) for v in (a, b))        # $10K, not $10.0K
        items.append((U.colour(j, n), fa if fa == fb else f"{fa}-{fb}"))
    if len(vals) < len(G):
        items.append(("FFFFFF", "No data"))
    for f_, t_ in items:
        tw = (len(t_) * 0.085 + 0.2) * IN
        rect(sl, kx, ky + 0.06 * IN, 0.16 * IN, 0.16 * IN, f_, radius=0.03 * IN, line=EDGE_ if f_ == "FFFFFF" else None, name="modern map step")
        text(sl, kx + 0.22 * IN, ky, tw, 0.28 * IN, t_, 11, MUTED, BODY, "l", "m", name="modern map step label")
        kx += 0.22 * IN + tw + 0.15 * IN
    _leaders(sl, lx, y, lw, h, spec.get("title") or "Leading states", [(U.US_STATES[c], v, fill[c]) for c, v in order[:8]])


def pointmap(sl, box, spec):
    """Locations as circles sized by value (area) on the states in grey, the largest in magenta and named beside the
    map. items: [[name, latitude, longitude, value], ...]; places outside the US map are left out."""
    U = _usmap(); G = U.geometry()["states"]
    pts = []
    for it in spec["items"]:
        q = U.project(it[1], it[2])
        if q:
            pts.append((str(it[0]), q, num(it[3])))
    if len(pts) < 2:
        raise ValueError("a location map takes at least two places inside the US")
    pts.sort(key=lambda p: -p[2])
    ox, oy, s, lx, lw = _map_frame(box, pts)
    x, y, w, h = box
    for code, st in G.items():
        _state(sl, U.rings(st["d"]), ox, oy, s, U.LAND, "FFFFFF", f"modern map {code}")
    mx = max(p[2] for p in pts) or 1; R = 975 * s / 34
    for i, (name_, (px, py), v) in enumerate(pts[:150]):
        d = 2 * max(0.03 * IN, R * math.sqrt(max(0.0, v) / mx))
        dot = oval(sl, ox + px * s, oy + py * s, d, SERIES[0] if i == 0 else SERIES[1], name=f"modern map place {i + 1}")
        dot.line.color.rgb = rgb(SURFACE); dot.line.width = Pt(0.75)
        if i:
            _alpha(dot, 0.75)
    _leaders(sl, lx, y, lw, h, spec.get("title") or "Largest locations",
             [(p[0], p[2], SERIES[0] if i == 0 else SERIES[1]) for i, p in enumerate(pts[:8])])


def draw(sl, spec, box):
    """Draw spec['modern'] into box (x, y, w, h in EMU). Returns a list of problems (empty when fine)."""
    t = spec.get("modern")
    _UNIT[0] = "" if t in ("treemap", "stack100", "radialbar", "ring", "waffle") else str(spec.get("unit", "") or "")
    try:
        if t == "kpi": kpi_cards(sl, box, spec["items"])
        elif t == "bento": bento(sl, box, spec["tiles"])
        elif t == "ring": rings(sl, box, spec["items"])
        elif t == "gauge": gauge(sl, box, spec)
        elif t == "bullet": bullet(sl, box, spec["items"])
        elif t == "lollipop": lollipop(sl, box, spec["items"], spec.get("unit", ""), spec.get("highlight"))
        elif t == "dumbbell": dumbbell(sl, box, spec)
        elif t == "slope": slope(sl, box, spec)
        elif t == "waffle": waffle(sl, box, spec)
        elif t == "stack100": stack100(sl, box, spec)
        elif t == "treemap": treemap(sl, box, spec["items"])
        elif t == "trend": trend(sl, box, spec)
        elif t == "sankey": sankey(sl, box, spec["flows"])
        elif t == "sunburst":
            tot = sum(num(v) for *_, v in spec["items"])
            c_ = str(spec.get("center", "")).strip()
            if re.fullmatch(r"[\d,.]+", c_) and abs(num(c_) - tot) > max(1.0, 0.005 * tot):
                return [f"sunburst: the centre says {c_} but the parts add up to {fmt(tot)} - leave 'center' out (the total is "
                        "computed) or correct the numbers"]
            sunburst(sl, box, spec["items"], spec.get("center", ""))
        elif t == "butterfly": butterfly(sl, box, spec)
        elif t == "stream": stream(sl, box, spec)
        elif t == "radialbar": radialbar(sl, box, spec["items"])
        elif t == "radar": radar(sl, box, spec)
        elif t == "bubbles": bubbles(sl, box, spec["items"])
        elif t == "rose": rose(sl, box, spec["items"])
        elif t == "gantt": gantt(sl, box, spec)
        elif t == "swimlane": swimlane(sl, box, spec)
        elif t == "usmap": usmap(sl, box, spec)
        elif t == "pointmap": pointmap(sl, box, spec)
        else:
            return [f"modern chart '{t}' does not exist - one of: {', '.join(TYPES)}"]
    except (KeyError, IndexError, TypeError, ValueError, FileNotFoundError) as e:
        return [f"modern chart '{t}': the data is not in the expected shape ({e}) - see python tools/modern_charts.py"]
    finally:
        _UNIT[0] = ""                                    # the unit belongs to this chart only
    return []


if __name__ == "__main__":
    print(__doc__)
