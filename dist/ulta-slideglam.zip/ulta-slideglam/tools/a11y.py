"""Accessibility (Section 508 / WCAG 2.1 AA) for generated decks: fix what can be fixed, report the rest.

    python tools/a11y.py fix   Deck.pptx        # in place
    python tools/a11y.py check Deck.pptx        # exit 1 on FAIL

fix:   alt text on every picture, chart, table and connector, or marks it decorative (PowerPoint's own
       "Mark as decorative" flag) - logos get "<brand> logo", glued flow connectors "Flow: A to B", tables
       "Table: <header cells>", photos/icons/lines/empty shapes are decorative; table header rows are flagged
       as headers (screen readers announce them).
check: FAIL  a picture/chart/table with neither alt text nor the decorative flag; a table without a header row
       REVIEW text below 4.5:1 contrast on its own fill (3:1 for large text); two slides with the same title;
              text under 9 pt
Slide titles: the Ulta template's headline is a body placeholder, so PowerPoint's checker may still list
"missing slide title". That is a template property; the headline text is present and unique.
"""
import argparse, json, re, sys, zipfile
from pathlib import Path

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import brand as B   # noqa: E402

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
C = "{http://schemas.openxmlformats.org/drawingml/2006/chart}"
DEC_URI = "{C183D7F6-B498-43B3-948B-1728B52AA6E4}"
DEC_NS = "http://schemas.microsoft.com/office/drawing/2017/decorative"
EMU_IN = 914400


def text_of(el):
    return " ".join("".join(t.text or "" for t in p.iter(A + "t")) for p in el.iter(A + "p")).strip()


def cnvpr(el):
    return el.find(".//" + P + "cNvPr")


def is_decorative(nv):
    return any(e.get("val") == "1" for e in nv.iter("{%s}decorative" % DEC_NS))


def mark_decorative(nv):
    if is_decorative(nv):
        return
    lst = nv.find(A + "extLst")
    if lst is None:
        lst = etree.SubElement(nv, A + "extLst")
    ext = etree.SubElement(lst, A + "ext", uri=DEC_URI)
    etree.SubElement(ext, "{%s}decorative" % DEC_NS, nsmap={"adec": DEC_NS}, val="1")


def colour_hex(c, theme):
    """The colour a DrawingML colour element shows: srgbClr or a theme slot, with its tint/shade and luminance
    adjustments applied (a "tx2 at 20% + 80%" label is pale pink, not the full brand red)."""
    import colorsys
    if c.tag == A + "srgbClr":
        base = (c.get("val") or "").upper()
    elif c.tag == A + "schemeClr":
        base = theme.get({"bg1": "lt1", "tx1": "dk1", "bg2": "lt2", "tx2": "dk2"}.get(c.get("val"), c.get("val")))
    else:
        return None
    if not base or len(base) != 6:
        return base
    r, g, b_ = (int(base[i:i + 2], 16) / 255 for i in (0, 2, 4))
    for m in c:
        k, v = etree.QName(m).localname, int(m.get("val") or 0) / 100000
        if k == "tint":
            r, g, b_ = (x + (1 - x) * (1 - v) for x in (r, g, b_))
        elif k == "shade":
            r, g, b_ = (x * v for x in (r, g, b_))
        elif k in ("lumMod", "lumOff"):
            h, l, s_ = colorsys.rgb_to_hls(r, g, b_)
            l = min(1.0, max(0.0, l * v if k == "lumMod" else l + v))
            r, g, b_ = colorsys.hls_to_rgb(h, l, s_)
    return "".join(f"{round(min(1, max(0, x)) * 255):02X}" for x in (r, g, b_))


def fill_hex(el, theme):
    f = el.find(f"{P}spPr/{A}solidFill")
    if f is None or not len(f):
        return None
    return colour_hex(f[0], theme)


def run_hex(rpr, theme):
    if rpr is None:
        return None
    f = rpr.find(A + "solidFill")
    if f is None or not len(f):
        return None
    return colour_hex(f[0], theme)


def slide_ids(z):
    pres = etree.fromstring(z.read("ppt/presentation.xml"))
    return [s.get("id") for s in pres.find(P + "sldIdLst")]


def slide_parts(z):
    pres = etree.fromstring(z.read("ppt/presentation.xml"))
    rels = {r.get("Id"): r.get("Target") for r in etree.fromstring(z.read("ppt/_rels/presentation.xml.rels"))}
    return ["ppt/" + rels[s.get(R + "id")].lstrip("/").replace("ppt/", "") for s in pres.find(P + "sldIdLst")]


def media_names(z, part):
    rp = part.replace("slides/", "slides/_rels/") + ".rels"
    if rp not in z.namelist():
        return {}
    return {r.get("Id"): r.get("Target") for r in etree.fromstring(z.read(rp))}


def fix_tree(tree, rels, brand_label, chart_titles, touched=None):
    n = 0
    touched = touched if touched is not None else []
    ids = {}
    for el in tree.iter(P + "sp", P + "pic", P + "cxnSp", P + "graphicFrame", P + "grpSp"):
        nv = cnvpr(el)
        if nv is not None:
            ids[nv.get("id")] = text_of(el) or nv.get("name", "")
    for el in tree.iter(P + "pic", P + "cxnSp", P + "graphicFrame", P + "sp"):
        nv = cnvpr(el)
        if nv is None or nv.get("descr") or is_decorative(nv):
            continue
        kind = etree.QName(el).localname
        if kind == "pic":
            blip = el.find(".//" + A + "blip")
            targets = " ".join(rels.get(e.get(R + "embed"), "") for e in el.iter() if e.get(R + "embed"))
            if "logo" in (targets + nv.get("name", "")).lower():
                nv.set("descr", f"{brand_label} logo")
            else:
                mark_decorative(nv)                                  # photos, pictograms
        elif kind == "cxnSp":
            st = el.find(f".//{A}stCxn"); en = el.find(f".//{A}endCxn")
            if st is not None and en is not None and ids.get(st.get("id")) and ids.get(en.get("id")):
                nv.set("descr", f"Flow: {ids[st.get('id')]} to {ids[en.get('id')]}")
            else:
                mark_decorative(nv)
        elif kind == "graphicFrame":
            tbl = el.find(f".//{A}tbl")
            if tbl is not None:
                head = [text_of(tc) for tc in (tbl.find(A + "tr") if tbl.find(A + "tr") is not None else [])][:6]
                nv.set("descr", "Table: " + (", ".join(h for h in head if h) or "data"))
            elif el.find(f".//{C}chart") is not None:
                rid = el.find(f".//{C}chart").get(R + "id")
                nv.set("descr", chart_titles.get(rels.get(rid, ""), "Chart"))
            else:
                mark_decorative(nv)
        elif kind == "sp" and not text_of(el):
            mark_decorative(nv)                                      # cards, bands, dots, rules
        else:
            continue
        touched.append(nv.get("id"))
        n += 1
    for tbl in tree.iter(A + "tbl"):                                 # header row announced as header
        pr = tbl.find(A + "tblPr")
        if pr is None:
            pr = etree.Element(A + "tblPr"); tbl.insert(0, pr)
        if len(tbl.findall(A + "tr")) > 1 and pr.get("firstRow") != "1":
            pr.set("firstRow", "1"); n += 1
    return n


def chart_titles(z):
    out = {}
    for n in z.namelist():
        if re.match(r"ppt/charts/chart\d+\.xml$", n):
            x = etree.fromstring(z.read(n))
            t = text_of(x.find(f".//{C}title")) if x.find(f".//{C}title") is not None else ""
            kind = next((etree.QName(e).localname.replace("Chart", "") for e in x.find(f".//{C}plotArea")
                         if etree.QName(e).localname.endswith("Chart")), "chart")
            series = [s.text for s in x.iter(f"{C}v") if s.getparent().getparent().tag == f"{C}tx"][:4]
            out["../charts/" + n.split("/")[-1]] = f"{kind} chart: {t or 'data'}" + (f" ({', '.join(series)})" if series else "")
    return out


OWN_SHAPES = ("ULTA", "modern")                         # names the skill gives the shapes it draws


def flat_effects(tree, every=False):
    """No phantom shadows in previews. A shape drawn with python-pptx links the theme's effect style (a drop shadow)
    and switches it off with an empty <a:effectLst/>; PowerPoint honours the switch, LibreOffice - which draws ChatGPT's
    previews and the PNG/PDF when the kit's renderer is missing - does not, so cards, chips, circles and diagram boxes
    came out raised and shadowed there. Pointing the skill's own shapes at no effect style (idx 0) looks the same in
    PowerPoint and flat everywhere. The template's own objects keep their style untouched (the template check compares
    it); every=True (the one-pager kit, drawn flat from SVG, no template objects): every shape."""
    n = 0
    for st in tree.iter(f"{P}style"):
        ref = st.find(f"{A}effectRef")
        if ref is None or ref.get("idx", "0") == "0":
            continue
        shape = st.getparent()
        nv = shape.find(f".//{P}cNvPr")
        if not every and (nv is None or not nv.get("name", "").startswith(OWN_SHAPES)):
            continue
        sp_pr = shape.find(f"{P}spPr")
        eff = sp_pr.find(f"{A}effectLst") if sp_pr is not None else None
        if (eff is not None and len(eff)) or (sp_pr is not None and sp_pr.find(f"{A}effectDag") is not None):
            continue                                    # the shape's own effects stay
        ref.set("idx", "0")
        n += 1
    return n


def fix(path, brand=None, flat_all=False):
    b = brand or B.current()
    label = (b.get("label") or b.name).split(" PPT")[0]
    z = zipfile.ZipFile(path)
    items = {n: z.read(n) for n in z.namelist()}
    infos = {n: z.getinfo(n) for n in z.namelist()}
    titles = chart_titles(z)
    total = 0
    side = Path(str(path) + ".ulta.json")
    meta = json.loads(side.read_text()) if side.exists() else {}
    done = recorded(path, meta)                    # {sldId: [shape ids]} - slide ids survive reordering
    approved = {e["slide"] for e in meta.get("library_slides") or []}   # approved library slides stay byte-identical
    native = set(meta.get("infographic_slides") or [])  # template infographics: the template's own colours stay as designed
    drawn = set(meta.get("diagram_slides") or []) - approved   # slides the tools drew: every word readable on its block
    base = {k: v.upper() for k, v in (b.get("theme") or {}).items()}
    sids = slide_ids(z)
    for i, part in enumerate(slide_parts(z), 1):
        if i in approved:
            continue
        x = etree.fromstring(items[part])
        ids = done.setdefault(sids[i - 1], [])
        tree = x.find(f".//{P}cSld/{P}spTree")
        total += fix_tree(tree, media_names(z, part), label, titles, ids)
        flat_effects(tree, flat_all)                    # no phantom shadows in previews; PowerPoint looks the same
        if i not in native:
            total += unblend(tree, b)
            total += recolour_text(tree, {k: v.upper() for k, v in (b.get("theme") or {}).items()})
        if i in drawn:
            th = slide_theme(z, part, base)
            total += readable_drawn(tree, th, background(z, part, th))
        items[part] = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
    z.close()
    import atomic
    with atomic.zip_out(path) as w:
        for n, d in items.items():
            w.writestr(infos[n], d)
    meta["a11y"] = {k: sorted(set(v)) for k, v in done.items() if v}
    side.write_text(json.dumps(meta))
    import docprops                                # the record travels inside the file too (uploads have no sidecar)
    docprops.write_props(path, custom={"A11yAdded": json.dumps(meta["a11y"], separators=(",", ":"))})
    return total


def recorded(path, meta=None):
    """{sldId: [cNvPr ids]} that a11y.py annotated: from the sidecar, else from the file's own properties."""
    if meta is None:
        side = Path(str(path) + ".ulta.json")
        meta = json.loads(side.read_text()) if side.exists() else {}
    rec = meta.get("a11y")
    if not rec:
        import docprops
        _, custom = docprops.read_props(path)
        try:
            rec = json.loads(custom.get("A11yAdded") or "{}")
        except ValueError:
            rec = {}
    return {k: list(v) for k, v in (rec or {}).items() if not k.isdigit() or int(k) > 255}   # old slide-number keys are not ids


def stripped_copy(path, dest):
    """Copy without the alt text / decorative flags a11y.py added (recorded in <deck>.ulta.json), so the
    template-structure checks compare layout only. Returns dest, or path itself when nothing was added."""
    import compliance
    added = recorded(path)
    if added:
        src = stripped_copy_alt(path, dest, added)
    else:                                          # no record (older file): drop what the template itself never has
        src = stripped_copy_alt(path, dest, None)
    compliance.unlabel(src, B.current().template)   # a classification footer is metadata too
    return src


def stripped_copy_alt(path, dest, added):
    z = zipfile.ZipFile(path)
    parts, sids = slide_parts(z), slide_ids(z)
    keep_descr = template_descrs() if added is None else set()
    import atomic
    with atomic.zip_out(dest) as w:
        for n in z.namelist():
            d = z.read(n)
            if n in parts and (added is None or sids[parts.index(n)] in added):
                ids = set(added[sids[parts.index(n)]]) if added is not None else None
                x = etree.fromstring(d)
                for nv in x.iter(P + "cNvPr"):
                    if (ids is not None and nv.get("id") in ids) or (ids is None and nv.get("descr") not in keep_descr):
                        nv.attrib.pop("descr", None)
                        for ext in list(nv.iter(A + "ext")):
                            if ext.get("uri") == DEC_URI:
                                lst = ext.getparent(); lst.remove(ext)
                                if not len(lst):
                                    nv.remove(lst)
                d = etree.tostring(x, xml_declaration=True, encoding="UTF-8", standalone=True)
            w.writestr(z.getinfo(n), d)
    return Path(dest)


def template_descrs():
    """Alt texts the brand template itself carries (kept when comparing an older file without an a11y record)."""
    z = zipfile.ZipFile(B.current().template)
    out = set()
    for n in z.namelist():
        if re.match(r"ppt/slides/slide\d+\.xml$", n):
            out |= {nv.get("descr") for nv in etree.fromstring(z.read(n)).iter(P + "cNvPr") if nv.get("descr")}
    return out


def rects(tree, theme):
    """(x0, y0, x1, y1, fill hex, label) of every directly placed filled shape and table cell, in z-order."""
    out = []
    for el in tree:
        tag = el.tag.split("}")[-1]
        xf = el.find(f"{P}spPr/{A}xfrm") if tag == "sp" else el.find(f"{P}xfrm")
        if xf is None or xf.find(f"{A}off") is None or xf.find(f"{A}ext") is None:
            continue
        off, ext = xf.find(f"{A}off"), xf.find(f"{A}ext")
        x, y, w, h = (int(off.get("x", 0)), int(off.get("y", 0)), int(ext.get("cx", 0)), int(ext.get("cy", 0)))
        if tag == "sp":
            f = fill_hex(el, theme)
            if f:
                out.append((x, y, x + w, y + h, f, text_of(el)[:30], el))
        elif tag == "graphicFrame":
            tbl = el.find(f".//{A}tbl")
            if tbl is None:
                continue
            cols = [int(g.get("w", 0)) for g in tbl.findall(f"{A}tblGrid/{A}gridCol")]
            yy = y
            for tr in tbl.findall(f"{A}tr"):
                rh = int(tr.get("h", 0)); xx = x
                for k, tc in enumerate(tr.findall(f"{A}tc")):
                    cw = cols[k] if k < len(cols) else 0
                    f = tc.find(f"{A}tcPr/{A}solidFill")
                    if f is not None and len(f):
                        c = f[0]
                        hexv = (c.get("val").upper() if c.tag == A + "srgbClr" else
                                theme.get({"bg1": "lt1", "tx1": "dk1", "bg2": "lt2", "tx2": "dk2"}.get(c.get("val"), c.get("val"))))
                        if hexv:
                            out.append((xx, yy, xx + cw, yy + rh, hexv, "table cell", None))
                    xx += cw
                yy += rh
    return out


def blends(tree, theme):
    """Filled text boxes the same colour as what lies under their centre: the box disappears into it."""
    rs = rects(tree, theme)
    hits = []
    for k, (x0, y0, x1, y1, f, label, el) in enumerate(rs):
        if not label or label == "table cell":
            continue
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        under = [r for r in rs[:k] if r[0] <= cx <= r[2] and r[1] <= cy <= r[3] and (r[2] - r[0]) * (r[3] - r[1]) > (x1 - x0) * (y1 - y0)]
        if under:
            bf = under[-1][4]
            d = sum((a - b) ** 2 for a, b in zip(B.lab(f), B.lab(bf))) ** 0.5
            if d < 12 and B.lab(f)[0] < 85:                  # pale tints on white are a deliberate design (pills, badges)
                hits.append((label, f, bf, d, el))
    return hits


def _alpha(el):
    """How opaque a shape's solid fill is (1 when it is not see-through)."""
    a = el.find(f"{P}spPr/{A}solidFill/*/{A}alpha") if el is not None else None
    return int(a.get("val")) / 100000 if a is not None and a.get("val") else 1.0


def placed(tree, theme, tf=None):
    """Every shape, picture and table cell in drawing order, groups opened: (x0, y0, x1, y1, fill or None, element, kind).
    A shape filled with a gradient, a picture or a pattern counts as a picture: what lies on it is not judged."""
    tf = tf or (lambda x, y: (x, y))
    out = []
    for el in tree:
        if not isinstance(el.tag, str):
            continue
        tag = etree.QName(el).localname
        if tag == "grpSp":
            xf = el.find(f"{P}grpSpPr/{A}xfrm")
            parts = [xf.find(A + k) if xf is not None else None for k in ("off", "ext", "chOff", "chExt")]
            if any(x is None for x in parts):
                out += placed(el, theme, tf)
                continue
            off, ext, cho, che = parts
            g = (int(off.get("x", 0)), int(off.get("y", 0)), int(cho.get("x", 0)), int(cho.get("y", 0)),
                 int(ext.get("cx", 0)) / max(1, int(che.get("cx", 0))), int(ext.get("cy", 0)) / max(1, int(che.get("cy", 0))))
            out += placed(el, theme, lambda x, y, g=g, tf=tf: tf(g[0] + (x - g[2]) * g[4], g[1] + (y - g[3]) * g[5]))
        elif tag in ("sp", "pic"):
            xf = el.find(f"{P}spPr/{A}xfrm")
            if xf is None or xf.find(A + "off") is None or xf.find(A + "ext") is None:
                continue
            off, ext = xf.find(A + "off"), xf.find(A + "ext")
            x, y = int(off.get("x", 0)), int(off.get("y", 0))
            (x0, y0), (x1, y1) = tf(x, y), tf(x + int(ext.get("cx", 0)), y + int(ext.get("cy", 0)))
            f = fill_hex(el, theme) if tag == "sp" else None
            pr = el.find(f"{P}spPr")
            odd = tag == "sp" and f is None and pr is not None and any(pr.find(A + k) is not None for k in ("gradFill", "blipFill", "pattFill"))
            out.append((x0, y0, x1, y1, f, el, "pic" if odd else tag))
        elif tag == "graphicFrame":
            for x0, y0, x1, y1, f, _, _ in rects([el], theme):
                (u0, v0), (u1, v1) = tf(x0, y0), tf(x1, y1)
                out.append((u0, v0, u1, v1, f, None, "cell"))
    return out


def _in_path(cg, fx, fy):
    """Whether a point (as fractions of the box) is inside a freeform shape's outline (its points, curves by their points)."""
    for path in cg.iter(A + "path"):
        w, h = int(path.get("w") or 0), int(path.get("h") or 0)
        pts = [(int(pt.get("x", 0)), int(pt.get("y", 0))) for pt in path.iter(A + "pt")]
        if not w or not h or len(pts) < 3:
            return True                                    # an outline we cannot read: its box
        inside, j = False, len(pts) - 1
        for i in range(len(pts)):
            (xi, yi), (xj, yj) = (pts[i][0] / w, pts[i][1] / h), (pts[j][0] / w, pts[j][1] / h)
            if (yi > fy) != (yj > fy) and fx < (xj - xi) * (fy - yi) / ((yj - yi) or 1e-9) + xi:
                inside = not inside
            j = i
        if inside:
            return True
    return False


def _covers(r, px, py):
    """Whether a placed shape covers the point: its box, its ellipse, a ring's band, a wedge or arc band's sweep, or a
    freeform outline (a donut's hole, or the space beside a wedge, is not on the shape)."""
    import math
    x0, y0, x1, y1, _, el, kind = r
    if not (min(x0, x1) <= px <= max(x0, x1) and min(y0, y1) <= py <= max(y0, y1)):
        return False
    if el is None or kind != "sp":
        return True
    w, h = max(1, abs(x1 - x0)), max(1, abs(y1 - y0))
    rx, ry = w / 2, h / 2
    dx, dy = px - min(x0, x1) - rx, py - min(y0, y1) - ry
    inside = (dx / rx) ** 2 + (dy / ry) ** 2 <= 1
    g = el.find(f"{P}spPr/{A}prstGeom")
    if g is None:
        cg = el.find(f"{P}spPr/{A}custGeom")
        return _in_path(cg, (px - min(x0, x1)) / w, (py - min(y0, y1)) / h) if cg is not None else True
    prst = g.get("prst")
    av = {gd.get("name"): (gd.get("fmla") or "").split() for gd in g.iter(A + "gd")}
    num = lambda k, d: int(av[k][1]) if len(av.get(k) or []) == 2 and av[k][0] == "val" else d
    def band(t):
        return inside and (dx / max(1, rx - t)) ** 2 + (dy / max(1, ry - t)) ** 2 >= 1
    def sweep(st, en):
        a = math.degrees(math.atan2(dy, dx)) % 360
        s, e = st / 60000 % 360, en / 60000 % 360
        return (a - s) % 360 <= ((e - s) % 360 or 360)
    if prst == "ellipse":
        return inside
    if prst == "donut":
        return band(num("adj", 25000) / 100000 * min(w, h))
    if prst == "pie":
        return inside and sweep(num("adj1", 0), num("adj2", 16200000))
    if prst == "blockArc":
        return band(num("adj3", 25000) / 100000 * min(w, h)) and sweep(num("adj1", 10800000), num("adj2", 0))
    if prst in ("arc", "line", "straightConnector1", "bracketPair", "bracePair", "leftBracket", "rightBracket"):
        return False                                       # strokes, not areas
    return True


def colour_at(items, k, px, py, bg):
    """The colour a point shows below the k-th placed item: the topmost filled shape under it that covers the point,
    blended with what it sits on when it is see-through (a Venn circle); the slide's background when nothing does;
    None over a picture (its colours are unknown)."""
    return _at(items, k, px, py, bg)[0]


def _at(items, k, px, py, bg):
    """(colour, index of the shape that gives it - None on the background) for colour_at."""
    for j in range(k - 1, -1, -1):
        r = items[j]
        if (r[4] or r[6] == "pic") and _covers(r, px, py):
            if r[6] == "pic":
                return None, j
            f, a = r[4], _alpha(r[5])
            if a >= 1:
                return f, j
            u = colour_at(items, j, px, py, bg)
            if u is None:
                return None, j
            return "".join(f"{round(int(f[i:i + 2], 16) * a + int(u[i:i + 2], 16) * (1 - a)):02X}" for i in (0, 2, 4)), j
    return bg, None


def background(z, part, theme):
    """A slide's background colour: its own, else its layout's, else its master's (white when none is solid)."""
    import posixpath
    for _ in range(3):
        bg = etree.fromstring(z.read(part)).find(f"{P}cSld/{P}bg")
        if bg is not None:
            f = bg.find(f"{P}bgPr/{A}solidFill")
            if f is None:
                f = bg.find(f"{P}bgRef")
            return (colour_hex(f[0], theme) if f is not None and len(f) else None) or "FFFFFF"
        d, name = part.rsplit("/", 1)
        rels = f"{d}/_rels/{name}.rels"
        nxt = [r.get("Target") for r in etree.fromstring(z.read(rels)) if r.get("Type", "").endswith(("/slideLayout", "/slideMaster"))] \
            if rels in z.namelist() else []
        if not nxt:
            break
        part = posixpath.normpath(posixpath.join(d, nxt[0]))
    return "FFFFFF"


def slide_theme(z, part, fallback):
    """The colour scheme a slide is drawn with - its master's theme (slide, layout, master, theme): a template can carry
    more than one, and theme-bound colours mean what that one says."""
    import posixpath
    cur = part
    for want in ("/slideLayout", "/slideMaster", "/theme"):
        d, name = cur.rsplit("/", 1)
        rels = f"{d}/_rels/{name}.rels"
        nxt = [r.get("Target") for r in etree.fromstring(z.read(rels)) if r.get("Type", "").endswith(want)] \
            if rels in z.namelist() else []
        if not nxt:
            return fallback
        cur = posixpath.normpath(posixpath.join(d, nxt[0]))
    cs = etree.fromstring(z.read(cur)).find(f".//{A}clrScheme")
    out = {}
    for c in (cs if cs is not None else []):
        v = c[0] if len(c) else None
        if v is not None:
            out[etree.QName(c).localname] = (v.get("val") if v.tag == A + "srgbClr" else v.get("lastClr") or "").upper()
    return out or fallback


MARKS = ("\u25cf", "\u25a0", "\u25b2", "\u25bc", "\u25c6", "\u2022", "\u2192")   # a status dot, a bullet or an arrow is a mark, not words


def drawn_text(path, slides, brand=None):
    """(text runs checked, [problem]) on the slides the tools drew: each run against what it sits on - its own box's fill,
    else the topmost filled shape under it (see-through ones blended), else the slide - at 4.5:1, or 3:1 from 18 pt; and
    dark words on a ground people see as dark, where white reads, are a problem too. Bold earns no allowance: a viewer
    without the template's font draws it regular. The template's own boxes (placeholders) are its design; text over a
    picture is not judged."""
    b = brand or B.current()
    base = {k: v.upper() for k, v in (b.get("theme") or {}).items()}
    z = zipfile.ZipFile(path)
    n, low = 0, []
    for i, part in enumerate(slide_parts(z), 1):
        if i not in slides:
            continue
        theme = slide_theme(z, part, base)
        items = placed(etree.fromstring(z.read(part)).find(f".//{P}cSld/{P}spTree"), theme)
        bg = background(z, part, theme)
        for k, r in enumerate(items):
            runs = _text_runs(r, theme)
            if not runs:
                continue
            under = colour_at(items, k + 1 if r[4] else k, (r[0] + r[2]) / 2, (r[1] + r[3]) / 2, bg)
            if under is None:
                continue
            for rp, t in runs:
                fg, need = run_hex(rp, theme), (3.0 if int(rp.get("sz") or 1800) >= 1800 else 4.5)
                n += 1
                if B.contrast(fg, under) < need:
                    low.append(f"slide {i}: '{t[:30]}' #{fg} on #{under} = {B.contrast(fg, under):.1f}:1 (needs {need}:1)")
                elif B.light_better(under) and B.apca(fg, under) > 0 and B.contrast("FFFFFF", under) >= need:
                    low.append(f"slide {i}: '{t[:30]}' dark #{fg} on #{under}, a ground seen as dark (white reads)")
    return n, low


def _text_runs(r, theme):
    """The coloured text runs of a placed shape the tools drew (a placeholder is the template's own box): [(rPr, text)]."""
    if r[6] != "sp" or r[5].find(f"{P}nvSpPr/{P}nvPr/{P}ph") is not None:
        return []
    runs = [(rp, (rp.getparent().findtext(A + "t") or "").strip()) for rp in r[5].iter(A + "rPr")]
    return [(rp, t) for rp, t in runs if t and t not in MARKS and run_hex(rp, theme)]


def _paint(rp, hexv):
    f = rp.find(A + "solidFill")
    for c in list(f):
        f.remove(c)
    etree.SubElement(f, A + "srgbClr").set("val", hexv)


DEEP_TEXT = {"pink": ("C10060", "DB0058", "D01381"), "orange": (), "neutral": ("404040",)}   # template colours that read on a light ground
STATUS_TEXT = {"00B050", "0BA03E", "FFC000", "FF0000"}                   # status colours mark a dot, never words


def _family(h):
    r, g, b_ = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    if max(r, g, b_) - min(r, g, b_) < 25:
        return "neutral"
    return "pink" if b_ > g + 10 else "orange"


def readable_colour(colour, under, need):
    """The text colour to use on `under` (as the infographic engine chooses, info.py readable_text_color): kept when it
    reads; white when white reads at least as well as black; on a light ground a deep template colour of the same hue
    (raspberry for the pinks), then plum, then black - so a coloured label keeps its colour cue."""
    colour = colour.upper()
    if colour not in STATUS_TEXT and B.contrast(colour, under) >= need:
        return colour
    cw, ci = B.contrast("FFFFFF", under), B.contrast("000000", under)
    if cw >= need and cw >= ci:
        return "FFFFFF"
    if cw < ci:
        for c in (() if colour in STATUS_TEXT else DEEP_TEXT.get(_family(colour), ()) + ("5D0F43",)) + ("000000",):
            if B.contrast(c, under) >= need:
                return c
        return "000000"
    return "FFFFFF"


def _deepen(items, q):
    """Give the drawn shape items[q] the deep colour of its hue (brand.DEEPEN), where white words reach 4.5:1, and the
    parts drawn with it too (a shape of the same colour touching it: a step's square foot); returns that colour, or None
    for a shape that cannot take it (a picture, a gradient, a colour with no deep counterpart)."""
    x0, y0, x1, y1, f = items[q][:5]
    f = (f or "").upper()
    new = B.DEEPEN.get(f)
    if not new or not _repaint(items, q, new):
        return None
    tol = 12700                                         # 1 pt: parts drawn edge to edge
    for j, it in enumerate(items):
        if j != q and (it[4] or "").upper() == f and it[0] <= x1 + tol and x0 - tol <= it[2] and it[1] <= y1 + tol and y0 - tol <= it[3]:
            _repaint(items, j, new)
    return new


def _repaint(items, q, new):
    """A drawn shape's solid fill set to `new` (its record in items too); False for a picture or a shape without one."""
    x0, y0, x1, y1, f, el, kind = items[q]
    sf = el.find(f"{P}spPr/{A}solidFill") if el is not None and kind == "sp" else None
    if sf is None:
        return False
    for c in list(sf):
        sf.remove(c)
    etree.SubElement(sf, A + "srgbClr").set("val", new)
    items[q] = (x0, y0, x1, y1, new, el, kind)
    return True


def readable_drawn(tree, theme, bg):
    """On a slide the tools drew, every word readable on what it sits on (4.5:1, 3:1 from 18 pt; bold earns no
    allowance). Words on a colour people see as dark are white (v130): where white falls short there - small type on Ulta
    orange or pink - the shape under them takes the deep colour of its hue instead of the words turning black. Elsewhere a
    run under the bar takes white, a deep template colour of its hue, plum or black, whichever reads first; when a block's
    white words had to turn black, its other white words follow, so one block never mixes the two. Returns the runs
    changed."""
    items = placed(tree, theme)
    n, on, dark = 0, {}, set()
    for k, r in enumerate(items):
        runs = _text_runs(r, theme)
        if not runs:
            continue
        under, q = _at(items, k + 1 if r[4] else k, (r[0] + r[2]) / 2, (r[1] + r[3]) / 2, bg)
        if under is None:
            continue
        for rp, _ in runs:
            fg, need = run_hex(rp, theme), (3.0 if int(rp.get("sz") or 1800) >= 1800 else 4.5)
            if B.light_better(under) and (fg == "FFFFFF" or B.apca(fg, under) > 0):   # words on a ground seen as dark: white
                if B.contrast("FFFFFF", under) < need and q is not None:
                    under = _deepen(items, q) or under
                if B.contrast("FFFFFF", under) >= need:
                    if fg != "FFFFFF":
                        _paint(rp, "FFFFFF")
                        n += 1
                    on.setdefault(q, []).append((rp, under, need))
                    continue
            on.setdefault(q, []).append((rp, under, need))
            if B.contrast(fg, under) >= need:
                continue
            new = readable_colour(fg, under, need)
            _paint(rp, new)
            n += 1
            if new == "000000" and fg == "FFFFFF" and q is not None:
                dark.add(q)
    for q in dark:                                         # one voice per block
        for rp, under, need in on.get(q, []):
            if run_hex(rp, theme) == "FFFFFF" and B.contrast("000000", under) >= need:
                _paint(rp, "000000")
                n += 1
    return n


def unblend(tree, b):
    """Give a box that has the colour of what lies behind it the brand colour that stands out most there."""
    theme = {k: v.upper() for k, v in (b.get("theme") or {}).items()}
    pal = [c.upper() for c in (b.get("palette") or {}).get("brand") or []] + [b.ui("dark_accent")]
    n = 0
    for label, f, bf, d, el in blends(tree, theme):
        pick = max((c for c in pal if B.contrast("FFFFFF", c) >= 3.0), key=lambda c: sum((u - v) ** 2 for u, v in zip(B.lab(c), B.lab(bf))), default=None)
        sp = el.find(f"{P}spPr/{A}solidFill") if el is not None else None
        if pick and sp is not None:
            for c in list(sp):
                sp.remove(c)
            etree.SubElement(sp, A + "srgbClr").set("val", pick)
            n += 1
    return n


def recolour_text(tree, theme):
    """Text that is clearly unreadable on its box (under 3:1, e.g. white on light orange) switches to the brand's
    dark berry or dark grey - whichever reads best. Borderline brand pairings (white on Ulta red, ~4.2:1) stay."""
    n = 0
    for sp in tree.iter(P + "sp"):
        bg = fill_hex(sp, theme)
        if not bg:
            continue
        for r in sp.iter(A + "rPr"):
            fg = run_hex(r, theme)
            if not fg or B.contrast(fg, bg) >= 3.0 or not (r.getparent().findtext(A + "t") or "").strip():
                continue
            best = max(("5D0F43", "404040", "FFFFFF"), key=lambda c: B.contrast(c, bg))
            if B.contrast(best, bg) > B.contrast(fg, bg):
                for old in r.findall(A + "solidFill"):
                    r.remove(old)
                sf = etree.Element(A + "solidFill")
                etree.SubElement(sf, A + "srgbClr", val=best)
                ln = r.find(A + "ln")                  # solidFill goes before latin/ea/cs, after ln
                r.insert(list(r).index(ln) + 1 if ln is not None else 0, sf)
                n += 1
    return n


def check(path, brand=None):
    b = brand or B.current()
    theme = {k: v.upper() for k, v in (b.get("theme") or {}).items()}
    z = zipfile.ZipFile(path)
    fails, reviews, small = [], [], 0
    heads = {}
    try:                                           # template infographics: a box on a same-coloured panel is the design
        native = set(json.loads(Path(str(path) + ".ulta.json").read_text()).get("infographic_slides") or [])
    except Exception:
        native = set()
    for i, part in enumerate(slide_parts(z), 1):
        x = etree.fromstring(z.read(part))
        tree = x.find(f".//{P}cSld/{P}spTree")
        for el in tree.iter(P + "pic", P + "graphicFrame"):
            nv = cnvpr(el)
            if nv is not None and not nv.get("descr") and not is_decorative(nv):
                fails.append(f"slide {i}: '{nv.get('name')}' has no alt text")
        for tbl in tree.iter(A + "tbl"):
            pr = tbl.find(A + "tblPr")
            if len(tbl.findall(A + "tr")) > 1 and (pr is None or pr.get("firstRow") != "1"):
                fails.append(f"slide {i}: a table has no header row")
        for label, f, bf, d, _ in ([] if i in native else blends(tree, theme)):
            fails.append(f"slide {i}: the box '{label}' is the same colour as what is behind it (#{f} on #{bf}) - "
                         "it disappears; give it a contrasting fill")
        for sp in tree.iter(P + "sp"):
            if b.is_headline(sp) and text_of(sp):
                heads.setdefault(text_of(sp).lower(), []).append(i)
            bg = fill_hex(sp, theme)
            for r in sp.iter(A + "rPr"):
                sz = int(r.get("sz") or 1800)
                txt = (r.getparent().findtext(A + "t") or "").strip()
                if sz < 900 and txt and not re.search(r"proprietary|confidential|internal use", txt, re.I):   # the template's own footer is small by design
                    small += 1
                fg = run_hex(r, theme)
                if bg and fg:
                    lat = r.find(A + "latin")
                    bold = r.get("b") == "1" or bool(lat is not None and re.search(r"bold|black|heavy", lat.get("typeface") or "", re.I))
                    need = 3.0 if sz >= 1800 or (sz >= 1400 and bold) else 4.5
                    if B.contrast(fg, bg) < need:
                        t = (r.getparent().findtext(A + "t") or "")[:25]
                        reviews.append(f"slide {i}: '{t}' #{fg} on #{bg} = {B.contrast(fg, bg):.1f}:1 (needs {need}:1)")
    for t, sl in heads.items():
        if len(sl) > 1:
            reviews.append(f"slides {sl} share the title '{t[:40]}' - screen-reader users navigate by title")
    if small:
        reviews.append(f"{small} text run(s) under 9 pt (dense one-pager layouts; fine for print, hard on screen)")
    return fails, sorted(set(reviews))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["fix", "check"]); ap.add_argument("deck")
    a = ap.parse_args()
    if a.cmd == "fix":
        print(f"a11y: {fix(Path(a.deck))} object(s) given alt text, marked decorative or given a header row")
    f, r = check(Path(a.deck))
    for x in f:
        print("FAIL   " + x)
    for x in r[:15]:
        print("REVIEW " + x)
    print(f"ACCESSIBILITY: {'FAIL' if f else 'REVIEW' if r else 'PASS'} - {len(f)} fail, {len(r)} to review")
    sys.exit(1 if f else 0)


if __name__ == "__main__":
    main()
