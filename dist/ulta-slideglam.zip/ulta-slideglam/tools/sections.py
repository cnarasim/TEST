"""PowerPoint sections (the slide groups in the thumbnail pane) - kept consistent with the slides that exist.

    normalize(path)                              drop ids of deleted slides, put unlisted slides in a section, drop empty ones
    set_sections(path, [("Main", [1,2,3]), ("Appendix", [4,5])])
    problems(path) -> ["section 'X' lists a slide that does not exist", ...]    (used by the validator)
Templates carry sections for their own sample slides; a built deck must not keep pointing at slides it removed.
"""
import uuid, zipfile

from lxml import etree
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

P = "http://schemas.openxmlformats.org/presentationml/2006/main"
P14 = "http://schemas.microsoft.com/office/powerpoint/2010/main"
URI = "{521415D9-36F7-43E2-AB2F-B90AF26B5E84}"


def _load(path):
    z = zipfile.ZipFile(path)
    items = {n: z.read(n) for n in z.namelist()}; infos = {n: z.getinfo(n) for n in z.namelist()}
    z.close()
    return items, infos, etree.fromstring(items["ppt/presentation.xml"])


def _save(path, items, infos, pres):
    items["ppt/presentation.xml"] = etree.tostring(pres, xml_declaration=True, encoding="UTF-8", standalone=True)
    import atomic
    with atomic.zip_out(path) as w:
        for n, d in items.items():
            w.writestr(infos[n], d)


def _ids(pres):
    return [s.get("id") for s in pres.find(f"{{{P}}}sldIdLst")]


def _seclst(pres):
    return pres.find(f".//{{{P14}}}sectionLst")


def problems(path):
    _, _, pres = _load(path)
    ids, sl = set(_ids(pres)), _seclst(pres)
    if sl is None:
        return []
    out = []
    listed = set()
    for sec in sl:
        for s in sec.iter(f"{{{P14}}}sldId"):
            listed.add(s.get("id"))
            if s.get("id") not in ids:
                out.append(f"section '{sec.get('name')}' lists a slide that does not exist")
    if ids - listed:
        out.append(f"{len(ids - listed)} slide(s) in no section")
    return sorted(set(out))


def set_sections(path, groups):
    items, infos, pres = _load(path)
    ids = _ids(pres)
    sl = _seclst(pres)
    if sl is None:
        ext_lst = pres.find(f"{{{P}}}extLst")
        if ext_lst is None:
            ext_lst = etree.SubElement(pres, f"{{{P}}}extLst")
        ext = etree.SubElement(ext_lst, f"{{{P}}}ext", uri=URI)
        sl = etree.SubElement(ext, f"{{{P14}}}sectionLst", nsmap={"p14": P14})
    for c in list(sl):
        sl.remove(c)
    for name, nums in groups:
        if not nums:
            continue
        sec = etree.SubElement(sl, f"{{{P14}}}section", name=name, id="{%s}" % str(uuid.uuid4()).upper())
        lst = etree.SubElement(sec, f"{{{P14}}}sldIdLst")
        for n in nums:
            if 1 <= n <= len(ids):
                etree.SubElement(lst, f"{{{P14}}}sldId", id=ids[n - 1])
    _save(path, items, infos, pres)


def normalize(path):
    items, infos, pres = _load(path)
    sl = _seclst(pres)
    if sl is None:
        return 0
    ids = _ids(pres)
    pos = {i: k for k, i in enumerate(ids, 1)}
    groups = []
    for sec in sl:
        nums = [pos[s.get("id")] for s in sec.iter(f"{{{P14}}}sldId") if s.get("id") in pos]
        groups.append((sec.get("name"), nums))
    listed = {n for _, ns in groups for n in ns}
    rest = [n for n in range(1, len(ids) + 1) if n not in listed]
    groups = [(n, ns) for n, ns in groups if ns]
    if rest:
        if groups:
            groups[-1] = (groups[-1][0], groups[-1][1] + rest)
        else:
            groups = [("Slides", rest)]
    if len(groups) == 1 and groups[0][0] in ("Default Section",):
        groups = [("Slides", groups[0][1])]
    before = problems(path)
    set_sections(path, groups)
    return len(before)
