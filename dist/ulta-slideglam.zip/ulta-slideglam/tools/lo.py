"""LibreOffice conversions with a private profile per call.

Two LibreOffice runs that share the default profile block each other (the second exits without writing anything),
which silently drops a render or PDF. Every tool converts through convert(), so builds can run side by side.

    import lo; pdf = lo.convert("Deck.pptx", out_dir, "pdf")      # path of the written file, or None
"""
import os, shutil, subprocess, tempfile
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I

FONTS = Path(__file__).resolve().parent.parent / "fonts"     # bundled OFL fonts (Playfair Display, the display face)


SYSTEM_CONF = Path("/etc/fonts/fonts.conf")


def font_env():
    """Environment for LibreOffice (and fc-list) that adds the bundled fonts through a private fontconfig file in the
    temp folder, so renders and PDFs use the real display face instead of a substitute. Nothing is installed into the
    user's home folder. Without a system fontconfig the environment is left as it is."""
    env = dict(os.environ)
    if not SYSTEM_CONF.exists():
        return env
    d = Path(tempfile.gettempdir()) / "ulta-slideglam" / "fontconfig"
    conf = d / "fonts.conf"
    text = ('<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig>'
            f'<include ignore_missing="yes">{SYSTEM_CONF}</include><dir>{FONTS}</dir>'
            f'<cachedir>{d / "cache"}</cachedir></fontconfig>')
    try:
        if not conf.exists() or conf.read_text() != text:
            d.mkdir(parents=True, exist_ok=True)
            conf.write_text(text)
        env["FONTCONFIG_FILE"] = str(conf)
    except OSError:
        pass
    return env


def allowed():
    """LibreOffice may be used (the Studio's gate, as a skill sees it: on unless ULTA_NO_LIBREOFFICE=1)."""
    return os.environ.get("ULTA_NO_LIBREOFFICE", "").strip().lower() not in ("1", "true", "yes")


def soffice():
    if not allowed():   # ULTA_NO_LIBREOFFICE=1: no render (batch builds); the gate then says UNVERIFIED, never PASS
        return None
    return shutil.which("soffice") or shutil.which("libreoffice")


def convert(src, out_dir, fmt="pdf", timeout=300):
    exe = soffice()
    if not exe:
        return None
    src, out_dir = Path(src), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    prof = Path(tempfile.mkdtemp(prefix="lo-profile-"))
    run, clean = src, None
    try:                                           # a PDF shows the file's author: render a copy without the template's people
        import privacy
        if privacy.findings(src):
            clean = Path(tempfile.mkdtemp(prefix="lo-src-")); run = clean / src.name
            shutil.copy2(src, run); privacy.scrub(run)
    except Exception:
        run = src
    try:
        subprocess.run([exe, f"-env:UserInstallation=file://{prof}", "--headless", "--convert-to", fmt,
                        "--outdir", str(out_dir), str(run)], capture_output=True, timeout=timeout, env=font_env())
    except subprocess.TimeoutExpired:
        return None
    finally:
        shutil.rmtree(prof, ignore_errors=True)
        if clean:
            shutil.rmtree(clean, ignore_errors=True)
    out = out_dir / (src.stem + "." + fmt.split(":")[0])
    return out if out.exists() else None


def page_count(pdf):
    """Pages in a PDF (pdfinfo), 0 when it cannot tell."""
    exe = shutil.which("pdfinfo")
    if not exe:
        return 0
    r = subprocess.run([exe, str(pdf)], capture_output=True, text=True, timeout=60)
    return next((int(l.split()[-1]) for l in r.stdout.splitlines() if l.startswith("Pages:")), 0)


def cpus():
    """The processors this run may use (a container's share, not the whole machine's)."""
    try:
        return len(os.sched_getaffinity(0)) or 1
    except (AttributeError, OSError):
        return os.cpu_count() or 1


def rasterize(pdf, prefix, dpi=96, timeout=300):
    """Every page of a PDF as prefix-01.png, prefix-02.png ... (pdftoppm), three pages at a time on up to four
    processors: each takes the next three pages when it is free, so a photo-heavy stretch does not hold the rest up.
    An 11-slide deck in a quarter of the time of one pass, a 25-slide deck in under a third; the same files. Returns the
    PNGs in page order."""
    exe = shutil.which("pdftoppm")
    if not exe:
        return []
    pdf, prefix = Path(pdf), Path(prefix)
    n = page_count(pdf)
    parts = [(a, min(n, a + 2)) for a in range(1, n + 1, 3)]
    k = max(1, min(4, cpus(), len(parts)))
    def one(part):
        rng = ["-f", str(part[0]), "-l", str(part[1])] if part else []
        subprocess.run([exe, "-png", "-r", str(dpi), *rng, str(pdf), str(prefix)], capture_output=True, timeout=timeout)
    if k == 1:
        one(None)                                      # one processor (or one short range): a single pass
    else:
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(k) as ex:
            list(ex.map(one, parts))
    import re
    return sorted(prefix.parent.glob(prefix.name + "-*.png"), key=lambda p: int(re.sub(r"\D", "", p.stem.rsplit("-", 1)[-1]) or 0))


def render_async(deck, out_dir, dpi=96, timeout=300):
    """convert() a deck to PDF and rasterize() its pages as out_dir/slide-NN.png in a worker thread, so the caller's
    own checks run meanwhile (they only read the deck): job.result() -> (pdf or None, [pngs]). The same files as
    converting first and checking after."""
    from concurrent.futures import ThreadPoolExecutor
    def work():
        pdf = convert(deck, out_dir, "pdf", timeout=timeout)
        return pdf, (rasterize(pdf, Path(out_dir) / "slide", dpi, timeout) if pdf else [])
    ex = ThreadPoolExecutor(1)
    job = ex.submit(work)
    ex.shutdown(wait=False)                            # the thread ends with the work; the run waits for it before exit
    return job
