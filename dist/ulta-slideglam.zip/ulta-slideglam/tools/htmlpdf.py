"""Every HTML the skill delivers can be saved as a PDF: pages without their own print button get one ("Export PDF",
top right, hidden in the printout) and landscape print settings. Pages that already print (dashboard, whiteboard,
infographic) are left as they are.

Every page also works inside the chat's file preview: the preview shows it in a frame, which may block saving and
printing. A small script (only when the page runs in a frame) tells the user, after Save, Export PDF or a download,
what to do if nothing happened. Outside a frame it does nothing."""
import re
from pathlib import Path

BUTTON = ('<button id="ultaPdf" onclick="window.print()" title="Save this page as a PDF (print → Save as PDF)" '
          'style="position:fixed;top:12px;right:12px;z-index:9999;background:#E8275A;color:#fff;border:0;'
          'border-radius:999px;padding:8px 16px;font:600 13px Arial,sans-serif;cursor:pointer">Export PDF</button>')
CSS = ('<style>@media print{@page{size:landscape;margin:10mm}#ultaPdf{display:none!important}'
       '*{-webkit-print-color-adjust:exact;print-color-adjust:exact}}</style>')


FRAME = ('<script id="ultaFrame">/* in a frame (the chat\'s preview, a site\'s preview pane): after a click on Save, Export, PDF, Print or'
         ' Download, say what to do if the frame blocked it. It only listens to clicks; it changes nothing in the page or the browser. */'
         '(function(){var f;try{f=window.self!==window.top}catch(e){f=true}if(!f)return;var n=0;'
         'function hint(){if(n++)return;var d=document.createElement("div");d.setAttribute("role","status");'
         'd.style.cssText="position:fixed;left:50%;bottom:16px;transform:translateX(-50%);z-index:2147483647;background:#000000;'
         'color:#FFFFFF;font:13px/1.4 Arial,sans-serif;padding:10px 14px;border-radius:8px;max-width:90vw";'
         'd.textContent="Nothing saved or printed? This view may block it: open the page in its own browser tab (or download the file from the chat) and try again.";'
         '(document.body||document.documentElement).appendChild(d);setTimeout(function(){d.remove()},9000)}'
         'document.addEventListener("click",function(e){var b=e.target&&e.target.closest&&e.target.closest("button,a,[role=button]");if(!b)return;'
         'var t=((b.textContent||"")+" "+(b.title||"")+" "+(b.getAttribute("aria-label")||"")+(b.hasAttribute("download")?" download":"")).toLowerCase();'
         'if(/save|export|pdf|print|download|png|svg/.test(t))setTimeout(hint,600)},true)})();</script>')


FRAME_RE = re.compile(r'<script id="ultaFrame">.*?</script>', re.S)


def framed(t):
    """t with the preview-frame helper once, right before </body>. The place is found in t itself, never in t.lower():
    a page whose font tables hold "\u0130" grows by a character per one when lowercased, which put the helper inside
    the closing tag ("</b" + script + "ody>") and showed its code as text under the page (v118-v119). Any earlier copy
    goes first, wherever it landed, so such a page is mended."""
    t = FRAME_RE.sub("", t)
    m = None
    for m in re.finditer(r"</body\s*>", t, re.I):
        pass
    return t[:m.start()] + FRAME + t[m.start():] if m else t + FRAME


def frame(path):
    """The preview-frame helper, once, before </body>; True when the file changed."""
    p = Path(path)
    t = p.read_text(encoding="utf-8")
    new = framed(t)
    if new == t:
        return False
    p.write_text(new, encoding="utf-8")
    return True


def ensure(path):
    """An Export PDF button when the page has no way to print, then the preview-frame helper; True when a button was added."""
    p = Path(path)
    t = p.read_text(encoding="utf-8")
    added = False
    if "window.print" not in FRAME_RE.sub("", t):
        t = t.replace("</style>", "</style>" + CSS, 1) if "</style>" in t else CSS + t
        t = re.sub(r"(<body[^>]*>)", r"\1" + BUTTON, t, count=1) if re.search(r"<body[^>]*>", t) else BUTTON + t
        p.write_text(t, encoding="utf-8"); added = True
    frame(p)
    return added


if __name__ == "__main__":
    import sys
    for f in sys.argv[1:]:
        print(f, "button added" if ensure(f) else "already printable")
