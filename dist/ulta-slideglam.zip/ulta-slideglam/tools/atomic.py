"""Writes that never leave a half-written file behind.

A .pptx, .docx or .xlsx is a zip whose table of contents is written last. A step that rewrites the file in place and
is stopped part-way (the chat's cell time limit, a second build of the same file started meanwhile) leaves a file
without it: PowerPoint then says it "found a problem with content" and offers to repair it. Every write here goes to
a hidden file beside the target and is swapped in with one rename when it is complete, so the target is always a
whole file - the old one or the new one, never a mix.

    with atomic.zip_out(path) as w: w.writestr(...)     instead of  zipfile.ZipFile(path, "w", ZIP_DEFLATED)
    atomic.save(prs_or_doc_or_workbook, path)          instead of  obj.save(path)
    with atomic.build_lock(out): ...                   one build of a file at a time
    with atomic.staged(out) as work: build(work)        a deck and its records made out of sight, put in place together
"""
import atexit, contextlib, copy, glob, hashlib, json, os, re, shutil, tempfile, time, zipfile
from pathlib import Path

RECORDS = (".ulta.json", ".checks.json", ".audit.json")    # what a build writes beside its deck, besides diagrams and _validation
PACKED = (".png", ".jpg", ".jpeg", ".jfif", ".gif", ".wdp", ".hdp", ".jxr",            # pictures and media that are
          ".mp3", ".m4a", ".wma", ".mp4", ".m4v", ".mov", ".wmv")                       # compressed already


class ZipOut(zipfile.ZipFile):
    """A zip writer (deflated) that stores pictures and media as they are: deflating them again was most of the time
    every rewrite of a deck took (a 3.4 MB deck: 90 ms against 15 ms) and made them under 1% smaller. The parts
    themselves are the same bytes; a compression the caller asks for by name is kept."""

    def writestr(self, zinfo_or_arcname, data, compress_type=None, compresslevel=None):
        name = zinfo_or_arcname.filename if isinstance(zinfo_or_arcname, zipfile.ZipInfo) else str(zinfo_or_arcname)
        if compress_type is None and name.lower().endswith(PACKED):
            compress_type = zipfile.ZIP_STORED
            if isinstance(zinfo_or_arcname, zipfile.ZipInfo):
                zinfo_or_arcname = copy.copy(zinfo_or_arcname)    # the record of the file it was read from stays as it was
        return super().writestr(zinfo_or_arcname, data, compress_type, compresslevel)

    def write(self, filename, arcname=None, compress_type=None, compresslevel=None):
        if compress_type is None and str(arcname or filename).lower().endswith(PACKED):
            compress_type = zipfile.ZIP_STORED
        return super().write(filename, arcname, compress_type, compresslevel)


def _tmp(path):
    p = Path(path)
    return p.with_name(f".{p.name}.{os.getpid()}.part")


@contextlib.contextmanager
def replacing(path):
    """with replacing(p) as tmp: write tmp - p is replaced by tmp only when the block completes; on an error p stays."""
    tmp = _tmp(path)
    try:
        yield tmp
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


@contextlib.contextmanager
def zip_out(path, compression=zipfile.ZIP_DEFLATED):
    """A ZipFile to write `path` from scratch (pictures stored as they are), swapped in when it is closed."""
    with replacing(path) as tmp:
        with ZipOut(tmp, "w", compression) as w:
            yield w


def save(obj, path):
    """python-pptx Presentation, python-docx Document or openpyxl Workbook: saved whole, then swapped in."""
    with replacing(path) as tmp:
        obj.save(str(tmp))


def _alive(pid):
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ValueError):
        return False


def out_folder(out):
    """The output file's folder, made before any work: one this sandbox cannot make stops the run at once, with where to
    write instead (a path from another platform's instructions, such as /mnt/data on Claude)."""
    try:
        Path(out).parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise SystemExit(f"--out {out}: its folder cannot be made here ({e.strerror or e}) - nothing was built. Write "
                         "into a folder this sandbox can write: ChatGPT /mnt/data/out/, Claude your working folder "
                         "(then copy the files to /mnt/user-data/outputs/)")


@contextlib.contextmanager
def build_lock(out):
    """One build of a file at a time: a second build started while the first still runs (a cell timed out and the
    request was sent again) is refused instead of writing the same file at once."""
    lock = Path(out).with_name(f".{Path(out).name}.building")
    if lock.exists():
        try:
            info = json.loads(lock.read_text())
        except Exception:
            info = {}
        fresh = time.time() - float(info.get("started") or 0) < 1800    # a lock over 30 minutes old is a leftover, whoever has its pid now
        if info.get("pid") and info["pid"] != os.getpid() and fresh and _alive(int(info["pid"])):
            raise SystemExit(f"BUSY | {Path(out).name} is still being built (process {info['pid']}, started "
                             f"{int(time.time() - info.get('started', time.time()))} s ago) - wait for it to finish "
                             "(tools/job.py wait <name>), do not start it again")
    out_folder(out)
    lock.write_text(json.dumps({"pid": os.getpid(), "started": time.time()}))
    try:
        yield
    finally:
        try:
            if json.loads(lock.read_text()).get("pid") == os.getpid():
                lock.unlink()
        except Exception:
            pass


def scratch(prefix="ulta-"):
    """A private working folder in the temp folder, removed when this run ends (errors included): builds leave nothing
    behind there, however many run in one session. Its name carries the run's process number, so the folders of a run
    that was stopped before it could clean up (a cell's time limit) are removed by the next one."""
    tmp = Path(tempfile.gettempdir())
    for old in tmp.glob("ulta-run-*"):
        m = re.match(r"ulta-run-(\d+)-", old.name)
        if m and int(m.group(1)) != os.getpid() and not _alive(int(m.group(1))):
            shutil.rmtree(old, ignore_errors=True)
    d = Path(tempfile.mkdtemp(prefix=f"ulta-run-{os.getpid()}-{prefix}"))
    atexit.register(shutil.rmtree, d, True)
    return d


def stage_for(out, pid=None):
    """The private folder a build of `out` works in: outside the deliverables folder, one per output path and process
    (a step a cut-off build left running can never write into the next build's folder)."""
    key = hashlib.sha256(str(Path(out).resolve()).encode()).hexdigest()[:12]
    return Path(tempfile.gettempdir()) / f"ulta-stage-{key}-{pid or os.getpid()}"


def clear(out, keep=()):
    """Remove what an earlier build left at `out`: the deck, its records, its .drawio diagrams and its _validation
    folder - never a file in keep (the input of this build)."""
    out, keep = Path(out).resolve(), [Path(k).resolve() for k in keep]
    for p in [out, *(Path(str(out) + r) for r in RECORDS), *out.parent.glob(glob.escape(out.stem) + "-slide*.drawio"),
              *out.parent.glob(glob.escape(f".{out.name}.") + "*.part")]:
        if (p.is_file() or p.is_symlink()) and p.resolve() not in keep:
            p.unlink()
    vd = out.parent / (out.stem + "_validation")
    if not any(k.is_relative_to(vd) for k in keep):
        shutil.rmtree(vd, ignore_errors=True)


@contextlib.contextmanager
def staged(out, keep=(), fresh=True):
    """with staged(out, keep=[input]) as work: build work - the deck and its files are made in a private folder and
    copied beside `out` only when the block completes, the deck last. A build stopped part-way (the chat's cell time
    limit, an error) leaves no deck at `out` to be handed over unchecked; fresh: nor the deck of an earlier build,
    which would be taken for this one. (fresh=False when `out` is the input being fixed in place.)"""
    out = Path(out).resolve()
    if out.is_dir():
        raise SystemExit(f"--out {out} is a folder: give the file's name, e.g. {out / 'Deck.pptx'}")
    out_folder(out)
    stage = stage_for(out)
    for old in stage.parent.glob(stage.name.rsplit("-", 1)[0] + "-*"):    # left by builds of this file that were cut off
        pid = old.name.rsplit("-", 1)[1]
        try:
            gone = old == stage or not pid.isdigit() or not _alive(int(pid)) or time.time() - old.stat().st_mtime > 1800
        except OSError:
            continue
        if gone:
            shutil.rmtree(old, ignore_errors=True)
    stage.mkdir(parents=True)
    if fresh:
        clear(out, keep)
    try:
        yield stage / out.name
        out.parent.mkdir(parents=True, exist_ok=True)
        for p in sorted(stage.iterdir(), key=lambda p: p.name == out.name):     # the deck last: there means finished
            dst = out.parent / p.name
            if p.is_dir():
                shutil.rmtree(dst, ignore_errors=True)
                shutil.copytree(p, dst)
            else:
                with replacing(dst) as tmp:
                    shutil.copyfile(p, tmp)
    finally:
        shutil.rmtree(stage, ignore_errors=True)
