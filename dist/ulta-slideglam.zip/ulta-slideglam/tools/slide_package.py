"""Office-package plumbing for swapping one slide (tools/slide_options.py): bounded reading, slide text, and a
surgical replacement that leaves every other slide byte-identical. No shell, no network.

    parts = read(path)                      # {part name: bytes}, after zip safety checks
    info = inspect(parts, 5)                # text, notes, pictures, charts, links of slide 5
    new, receipt = replace(parts, 5, read(candidate))   # candidate: a one-slide deck
"""
import collections, copy, hashlib, posixpath, re, unicodedata, uuid, zipfile
from pathlib import Path, PurePosixPath
from lxml import etree as E
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))   # its sibling modules, also under python -I

P = "http://schemas.openxmlformats.org/presentationml/2006/main"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
REL = "http://schemas.openxmlformats.org/package/2006/relationships"
CT = "http://schemas.openxmlformats.org/package/2006/content-types"
NS = {"p": P, "a": A, "r": R}
FOOTER = re.compile(r"(?i)ulta beauty\s*\||proprietary\s*&\s*confidential")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def xml(data):
    if re.search(br"<!\s*(?:DOCTYPE|ENTITY)\b", data, re.I):
        raise ValueError("DTD/entity declarations are not supported")
    return E.fromstring(data, E.XMLParser(resolve_entities=False, load_dtd=False, no_network=True, huge_tree=False))


def serial(root):
    return E.tostring(root, encoding="UTF-8", xml_declaration=True, standalone=True)


def read(path):
    """{part: bytes} of an Office file, refusing unsafe archives (traversal, symlinks, duplicates, encryption, bombs)."""
    with zipfile.ZipFile(path) as z:
        entries = z.infolist()
        if len(entries) > 30000 or sum(i.file_size for i in entries) > 512 * 1024 ** 2:
            raise ValueError("Office package exceeds the size limits")
        names = [i.filename for i in entries]
        if len(set(names)) != len(names):
            raise ValueError("Duplicate archive entries")
        for i in entries:
            p = PurePosixPath(i.filename)
            if p.is_absolute() or ".." in p.parts or "\\" in i.filename or i.flag_bits & 1:
                raise ValueError("Unsafe archive entry")
            if (i.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Archive symlink")
        return {i.filename: z.read(i) for i in entries if not i.is_dir()}


def write(parts, path):
    import atomic
    with atomic.zip_out(path) as z:
        for name in ["[Content_Types].xml"] + [n for n in parts if n != "[Content_Types].xml"]:
            z.writestr(name, parts[name])


def relpath(part):
    d, n = posixpath.split(part)
    return posixpath.join(d, "_rels", n + ".rels")


def target(part, name):
    out = posixpath.normpath(name.lstrip("/") if name.startswith("/") else posixpath.join(posixpath.dirname(part), name))
    if out == ".." or out.startswith("../") or "\\" in out:
        raise ValueError("Relationship escapes the package")
    return out


def rels(parts, part):
    data = parts.get(relpath(part))
    return list(xml(data)) if data else []


def slides(parts):
    lookup = {r.get("Id"): target("ppt/presentation.xml", r.get("Target"))
              for r in rels(parts, "ppt/presentation.xml") if r.get("TargetMode") != "External"}
    return [lookup[s.get("{" + R + "}id")] for s in xml(parts["ppt/presentation.xml"]).findall("p:sldIdLst/p:sldId", NS)]


def slide_ids(parts):
    """PowerPoint's own id of each slide (p:sldId/@id), in order."""
    return [s.get("id") for s in xml(parts["ppt/presentation.xml"]).findall("p:sldIdLst/p:sldId", NS)]


def selected(parts, number):
    ordered = slides(parts)
    if number < 1 or number > len(ordered):
        raise ValueError(f"Slide must be between 1 and {len(ordered)}")
    return ordered[number - 1]


def words(text):
    """Comparable tokens: numbers keep their sign, decimals and unit; case and punctuation are not facts."""
    text = unicodedata.normalize("NFKC", text).casefold().replace(" ", " ").replace("−", "-")
    return re.findall(r"[+-]?\$?\d+(?:[.,]\d+)*(?:%|[kmb]\b)?|[^\W\d_]+", text, re.UNICODE)


def text_lines(root):
    out = []
    for para in root.iter("{" + A + "}p"):
        line = "".join(t.text or "" for t in para.iter("{" + A + "}t")
                       if not any(E.QName(a).localname == "fld" and a.get("type") == "slidenum" for a in t.iterancestors()))
        if line.strip():
            out.append(line.strip())
    return out


def inspect(parts, number):
    """What a slide holds: its visible text (footer chrome left out), notes, pictures, charts, links, and anything
    an automatic swap cannot carry over (animations, embedded objects)."""
    part = selected(parts, number)
    root = xml(parts[part])
    visible = [t for t in text_lines(root) if not FOOTER.search(t)]
    images, charts, links, notes, unsupported = [], [], [], [], []
    if root.find("p:timing", NS) is not None:
        unsupported.append("animations")
    for r in rels(parts, part):
        kind, dest = r.get("Type", "").rsplit("/", 1)[-1], r.get("Target")
        if r.get("TargetMode") == "External":
            links.append((kind, dest)); continue
        dest = target(part, dest)
        if kind == "notesSlide":
            notes.extend(text_lines(xml(parts[dest])))
        elif kind == "image":
            images.append(hashlib.sha256(parts[dest]).hexdigest())
        elif kind == "chart":
            charts.append(dest)
        elif kind in ("hyperlink", "slide"):
            links.append((kind, dest))
        elif kind in ("oleObject", "package", "control", "video", "audio", "media"):
            unsupported.append(kind)
    return {"part": part, "text": visible, "notes": notes, "images": sorted(images), "charts": charts,
            "links": sorted(links), "unsupported": sorted(set(unsupported)),
            "tokens": dict(collections.Counter(words(" ".join(visible))))}


FOOTER_PHRASES = ("Public", "Internal Use Only", "Proprietary & Confidential", "Restricted - Do Not Forward")   # compliance.LEVELS
_FOOTER_RX = re.compile(rb"(\|\s*)(?:" + b"|".join(re.escape(f.replace("&", "&amp;").encode()) for f in FOOTER_PHRASES) + rb")(?=<)")


def _canon_loose(parts, part):
    """A layout or master as a swap compares it: the footer's classification phrase and the width of a placeholder in
    the top band (the headline box, full width on the deck's layouts since v109) left out. An option built for a deck
    classified differently, or a deck built before v109, differs from the option only there."""
    if part not in parts:
        return None
    x = xml(parts[part])
    for sp in x.iter("{" + P + "}sp"):
        xf = sp.find("p:spPr/a:xfrm", NS)
        if sp.find(".//p:nvPr/p:ph", NS) is None or xf is None:
            continue
        off, ext = xf.find("a:off", NS), xf.find("a:ext", NS)
        if off is not None and ext is not None and int(off.get("y") or 0) < 914400:
            ext.set("cx", "0")
    return _FOOTER_RX.sub(rb"\1#", E.tostring(x, method="c14n"))


def _layout_name(parts, part):
    m = re.search(rb'<p:cSld[^>]*\bname="([^"]*)"', parts.get(part, b""))
    return m.group(1) if m else None


def replace(base, number, candidate):
    """Put the candidate's only slide in place of slide `number`. Keeps the slide's position, id, notes and
    transition; reuses the deck's own layout when it is the same one (same name and content, apart from the footer's
    classification phrase and the headline box's width), so no second copy of the template comes in; copies new pictures
    and charts under fresh names. Every other part of the deck stays byte-identical (checked)."""
    original = inspect(base, number)
    if original["unsupported"]:
        raise ValueError("This slide holds " + ", ".join(original["unsupported"]) + " - an automatic swap would lose them")
    if len(slides(candidate)) != 1:
        raise ValueError("Each option must be a one-slide deck")
    cand = inspect(candidate, 1)
    if cand["unsupported"]:
        raise ValueError("The option holds " + ", ".join(cand["unsupported"]))
    if xml(base["ppt/presentation.xml"]).find("p:sldSz", NS).attrib != xml(candidate["ppt/presentation.xml"]).find("p:sldSz", NS).attrib:
        raise ValueError("Slide sizes differ")
    out = dict(base)
    dst, src = original["part"], cand["part"]
    mapping = {src: dst}
    added_types = {}
    ct = xml(candidate["[Content_Types].xml"])
    overrides = {c.get("PartName").lstrip("/"): c.get("ContentType") for c in ct if E.QName(c).localname == "Override"}
    defaults = {c.get("Extension"): c.get("ContentType") for c in ct if E.QName(c).localname == "Default"}
    prefix = "option-" + uuid.uuid4().hex[:10] + "-"
    base_layouts = [n for n in base if re.match(r"ppt/slideLayouts/[^/]+\.xml$", n)]

    def same_layout(part):
        """The deck's own copy of a candidate layout: the same name, the same XML and the same master XML (footer
        classification phrase and headline width aside: the swapped slide then shows the deck's own footer)."""
        name, canon = _layout_name(candidate, part), _canon_loose(candidate, part)
        cm = [target(part, r.get("Target")) for r in rels(candidate, part) if r.get("Type", "").endswith("/slideMaster")]
        for b in base_layouts:
            if _layout_name(base, b) == name and _canon_loose(base, b) == canon:
                bm = [target(b, r.get("Target")) for r in rels(base, b) if r.get("Type", "").endswith("/slideMaster")]
                if [_canon_loose(candidate, m) for m in cm] == [_canon_loose(base, m) for m in bm]:
                    return b
        return None

    def import_part(part):
        if part in mapping:
            return mapping[part]
        if part.startswith("ppt/slideLayouts/"):
            reuse = same_layout(part)
            if reuse:
                mapping[part] = reuse
                return reuse
        if part not in candidate:
            raise ValueError(f"Missing relationship target: {part}")
        new = posixpath.join(posixpath.dirname(part), prefix + posixpath.basename(part))
        mapping[part] = new
        out[new] = candidate[part]
        added_types[new] = overrides.get(part) or defaults.get(part.rsplit(".", 1)[-1].lower())
        if not added_types[new]:
            raise ValueError(f"Unknown content type: {part}")
        rs = rels(candidate, part)
        if rs:
            tree = E.Element("{" + REL + "}Relationships", nsmap={None: REL})
            for rel in rs:
                rr = copy.deepcopy(rel)
                if rr.get("TargetMode") != "External":
                    rr.set("Target", posixpath.relpath(import_part(target(part, rr.get("Target"))), posixpath.dirname(new)))
                tree.append(rr)
            out[relpath(new)] = serial(tree)
        return new

    tree = E.Element("{" + REL + "}Relationships", nsmap={None: REL})
    for rel in rels(candidate, src):
        if rel.get("Type", "").endswith("/notesSlide"):
            continue
        rr = copy.deepcopy(rel)
        if rr.get("TargetMode") != "External":
            rr.set("Target", posixpath.relpath(import_part(target(src, rr.get("Target"))), posixpath.dirname(dst)))
        tree.append(rr)
    used = {r.get("Id") for r in tree}
    for rel in rels(base, dst):                            # the slide keeps its own speaker notes
        if rel.get("Type", "").endswith("/notesSlide"):
            rr = copy.deepcopy(rel)
            while rr.get("Id") in used:
                rr.set("Id", rr.get("Id") + "n")
            used.add(rr.get("Id")); tree.append(rr)
    root = xml(candidate[src])
    old_transition = xml(base[dst]).find("p:transition", NS)
    transition = root.find("p:transition", NS)
    if transition is not None:
        root.remove(transition)
    if old_transition is not None:                         # CT_Slide: cSld, clrMapOvr?, transition?, timing?, extLst?
        at = next((i for i, c in enumerate(root) if E.QName(c).localname in ("timing", "extLst")), len(root))
        root.insert(at, copy.deepcopy(old_transition))
    out[dst], out[relpath(dst)] = serial(root), serial(tree)
    pres = xml(out["ppt/presentation.xml"])                # a master that came with the option is registered
    presrels = xml(out[relpath("ppt/presentation.xml")])
    masters = pres.find("p:sldMasterIdLst", NS)
    master_ids = [int(el.get("id")) for el in masters] if masters is not None else []
    changed = False
    for old, new in mapping.items():
        if old.startswith("ppt/slideMasters/") and old.endswith(".xml") and new != old:
            rid = "rId" + prefix.replace("-", "") + str(len(master_ids))
            E.SubElement(presrels, "{" + REL + "}Relationship", Id=rid, Type=R + "/slideMaster",
                         Target=posixpath.relpath(new, "ppt"))
            mid = max(master_ids + [2147483647]) + 1; master_ids.append(mid)
            E.SubElement(masters, "{" + P + "}sldMasterId", {"id": str(mid), "{" + R + "}id": rid})
            changed = True
    if changed:
        out["ppt/presentation.xml"], out[relpath("ppt/presentation.xml")] = serial(pres), serial(presrels)
    if added_types:
        types = xml(base["[Content_Types].xml"])
        for part, typ in added_types.items():
            E.SubElement(types, "{" + CT + "}Override", PartName="/" + part, ContentType=typ)
        out["[Content_Types].xml"] = serial(types)
    allowed = {dst, relpath(dst), "[Content_Types].xml", "ppt/presentation.xml", relpath("ppt/presentation.xml")}
    if slides(out) != slides(base):
        raise ValueError("Slide order changed")
    unexpected = [n for n in base if n not in allowed and base[n] != out.get(n)]
    if unexpected:
        raise ValueError(f"Other parts changed: {unexpected[:5]}")
    if original["notes"] != inspect(out, number)["notes"]:
        raise ValueError("Speaker notes changed")
    return out, {"replaced_part": dst, "added_parts": sorted(set(out) - set(base)),
                 "reused_layout": any(v in base_layouts for v in mapping.values()),
                 "other_slides_byte_identical": True, "notes_kept": True}
