"""Make generated slides edit like a hand-built PowerPoint.

    python tools/nativize.py deck.pptx [--slides 2,3] [--out fixed.pptx]

1. Text into shapes: a text box lying on top of an empty shape (system box, label pill, card) is moved
   INSIDE that shape, with insets set so the text stays exactly where it was. Click the box and type;
   move the box and its text moves with it.
2. Glued connectors: a flow drawn as 1-3 loose line segments between two boxes becomes ONE PowerPoint
   connector (straight or elbow) glued to the boxes' connection points, keeping its arrowheads and line
   style. Move a box and its arrows follow.
Anything that does not match these patterns is left exactly as it was. Prints what it changed.
"""
import argparse, copy, sys
from pathlib import Path

from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
from pptx import Presentation

A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
P = "{http://schemas.openxmlformats.org/presentationml/2006/main}"
TOL = 12700 * 3          # 3 pt
FILL_TAGS = ("solidFill", "gradFill", "blipFill", "pattFill")


def xf(el):
    for path in ("p:spPr/a:xfrm", "p:grpSpPr/a:xfrm"):
        x = el.find(path.replace("p:", P).replace("a:", A))
        if x is not None:
            return x
    return None


def box_of(el):
    x = xf(el)
    if x is None or x.find(A + "off") is None:
        return None
    o, e = x.find(A + "off"), x.find(A + "ext")
    return int(o.get("x")), int(o.get("y")), int(e.get("cx")), int(e.get("cy"))


def text_of(el):
    return "".join(t.text or "" for t in el.iter(A + "t")).strip()


def geom(el):
    g = el.find(f"{P}spPr/{A}prstGeom")
    return g.get("prst") if g is not None else None


def has_fill_or_line(el):
    sp = el.find(P + "spPr")
    if sp is None:
        return False
    if any(sp.find(A + t) is not None for t in FILL_TAGS):
        return True
    ln = sp.find(A + "ln")
    return ln is not None and ln.find(A + "noFill") is None


# ---------------------------------------------------------------------------------------- 1. text into shapes
def text_rect_inset(el, w, h):
    """(dx, dy) the preset geometry's own text rectangle sits inside the shape, or None for geometries we
    do not model (text is then left in its own box)."""
    g = geom(el)
    if g == "rect":
        return 0, 0
    if g in ("roundRect", "round2SameRect", "snipRoundRect"):
        gd = el.find(f"{P}spPr/{A}prstGeom/{A}avLst/{A}gd")
        adj = int(gd.get("fmla", "val 16667").split()[-1]) if gd is not None else 16667
        d = int(min(w, h) * adj / 100000 * 0.29289)
        return d, d
    if g == "ellipse":
        return int(w * 0.14645), int(h * 0.14645)
    return None


def merge_text(tree):
    shapes = [el for el in tree if etree.QName(el).localname == "sp"]
    holders = [el for el in shapes if not text_of(el) and geom(el) and has_fill_or_line(el)
               and el.find(f".//{P}ph") is None]
    texts = [el for el in shapes if text_of(el) and el.find(f".//{P}ph") is None]
    def inside(t, h):
        tb, hb = box_of(t), box_of(h)
        if tb is None or hb is None:
            return False
        cx, cy = tb[0] + tb[2] / 2, tb[1] + tb[3] / 2
        return hb[0] <= cx <= hb[0] + hb[2] and hb[1] <= cy <= hb[1] + hb[3]
    # a shape that carries SEVERAL texts (a table-like row card) is a container: leave its texts as they are
    holders = [h for h in holders if sum(1 for t in texts if inside(t, h)) == 1]
    merged = 0
    for t in texts:
        tb = box_of(t)
        if tb is None:
            continue
        cx, cy = tb[0] + tb[2] / 2, tb[1] + tb[3] / 2
        cands = [h for h in holders if box_of(h) and
                 box_of(h)[0] - TOL <= tb[0] and box_of(h)[1] - TOL <= tb[1] and
                 tb[0] + tb[2] <= box_of(h)[0] + box_of(h)[2] + TOL and tb[1] + tb[3] <= box_of(h)[1] + box_of(h)[3] + TOL
                 and box_of(h)[0] <= cx <= box_of(h)[0] + box_of(h)[2] and box_of(h)[1] <= cy <= box_of(h)[1] + box_of(h)[3]]
        if not cands:
            continue
        h = min(cands, key=lambda e: box_of(e)[2] * box_of(e)[3])
        hb = box_of(h)
        inset = text_rect_inset(h, hb[2], hb[3])
        if inset is None:
            continue
        dx, dy = inset
        src_body = t.find(P + "txBody")
        body = copy.deepcopy(src_body)
        bp = body.find(A + "bodyPr")
        ins = {k: int(bp.get(k, d)) for k, d in (("lIns", 91440), ("tIns", 45720), ("rIns", 91440), ("bIns", 45720))}
        new = {"lIns": tb[0] - hb[0] + ins["lIns"] - dx, "tIns": tb[1] - hb[1] + ins["tIns"] - dy,
               "rIns": hb[0] + hb[2] - tb[0] - tb[2] + ins["rIns"] - dx, "bIns": hb[1] + hb[3] - tb[1] - tb[3] + ins["bIns"] - dy}
        for a_, b_ in (("lIns", "rIns"), ("rIns", "lIns"), ("tIns", "bIns"), ("bIns", "tIns")):
            if new[a_] < 0:                       # keep the full text width: shift by the shortfall instead
                new[b_] += new[a_]; new[a_] = 0
        if min(new.values()) < 0:                 # the shape's text area is narrower than the text: leave it
            continue
        for k, v in new.items():
            bp.set(k, str(max(0, v)))
        for fit in bp.findall(A + "spAutoFit"):     # the shape keeps its own size: never shrink a card or tile to its text
            bp.remove(fit)
        if bp.find(A + "normAutofit") is None and bp.find(A + "noAutofit") is None:
            bp.append(etree.Element(A + "noAutofit"))
        old = h.find(P + "txBody")
        if old is not None:
            h.remove(old)
        h.append(body)
        tree.remove(t)
        holders.remove(h)
        merged += 1
    return merged


# ------------------------------------------------------------------------------------ 2. glued connectors
def seg_points(el):
    b = box_of(el)
    x = xf(el)
    x0, y0, x1, y1 = b[0], b[1], b[0] + b[2], b[1] + b[3]
    if x.get("flipH") == "1":
        x0, x1 = x1, x0
    if x.get("flipV") == "1":
        y0, y1 = y1, y0
    return (x0, y0), (x1, y1)


def ends(el):
    ln = el.find(f"{P}spPr/{A}ln")
    h = ln.find(A + "headEnd") if ln is not None else None
    t = ln.find(A + "tailEnd") if ln is not None else None
    arrow = lambda e: e is not None and e.get("type", "none") != "none"
    return arrow(h), arrow(t)


def near(p, q):
    return abs(p[0] - q[0]) <= TOL and abs(p[1] - q[1]) <= TOL


def side_of(pt, el):
    """Connection-site index on a rect/roundRect for the side the point touches: 0 top, 1 left, 2 bottom, 3 right."""
    x, y, w, h = box_of(el)
    d = {0: abs(pt[1] - y), 1: abs(pt[0] - x), 2: abs(pt[1] - (y + h)), 3: abs(pt[0] - (x + w))}
    k = min(d, key=d.get)
    inside = x - TOL <= pt[0] <= x + w + TOL and y - TOL <= pt[1] <= y + h + TOL
    return k if inside and d[k] <= TOL else None


SITE_TOL = 54864                                   # 0.06 in: an end this close to a side's midpoint sits on its connection site


def on_site(pt, el, k):
    """True when pt is the connection site itself (the side's midpoint). Gluing anywhere else makes PowerPoint keep the
    drawn line until the box moves, then jump to the midpoint - and LibreOffice / PDF draw the jumped line at once."""
    x, y, w, h = box_of(el)
    mid = {0: (x + w / 2, y), 1: (x, y + h / 2), 2: (x + w / 2, y + h), 3: (x + w, y + h / 2)}[k]
    return abs(pt[0] - mid[0]) <= SITE_TOL and abs(pt[1] - mid[1]) <= SITE_TOL


def glue_flows(tree):
    kids = list(tree)
    boxes = [el for el in kids if etree.QName(el).localname == "sp" and geom(el) in ("rect", "roundRect", "snipRoundRect", "round2SameRect")
             and has_fill_or_line(el) and el.find(f".//{P}ph") is None and box_of(el) and box_of(el)[2] > 0 and box_of(el)[3] > 0]
    segs = [el for el in kids if etree.QName(el).localname == "cxnSp" and geom(el) == "line"]
    # chain consecutive segments whose end meets the next one's start (the order the engine draws them)
    chains, cur = [], []
    for s in segs:
        if cur and near(seg_points(cur[-1])[1], seg_points(s)[0]) and len(cur) < 3:
            cur.append(s)
        else:
            if cur:
                chains.append(cur)
            cur = [s]
    if cur:
        chains.append(cur)
    made = 0
    next_id = max(int(e.get("id")) for e in tree.iter(P + "cNvPr")) + 1
    for ch in chains:
        start, end = seg_points(ch[0])[0], seg_points(ch[-1])[1]
        sb = next((b for b in boxes if side_of(start, b) is not None), None)
        eb = next((b for b in boxes if b is not sb and side_of(end, b) is not None), None)
        if sb is None or eb is None:
            continue
        pts = [seg_points(c)[0] for c in ch] + [end]
        straight = len(ch) == 1
        hvh = len(ch) == 3 and pts[0][1] == pts[1][1] and pts[1][0] == pts[2][0] and pts[2][1] == pts[3][1]
        if not (straight or hvh):
            continue
        head = ends(ch[0])[0]
        tail = ends(ch[-1])[1]
        cx = copy.deepcopy(ch[0])
        nv = cx.find(f"{P}nvCxnSpPr/{P}cNvPr")
        nv.set("id", str(next_id)); nv.set("name", "ULTA connector " + str(made + 1)); next_id += 1
        cnv = cx.find(f"{P}nvCxnSpPr/{P}cNvCxnSpPr")
        for c in list(cnv):
            cnv.remove(c)
        sid = box_of(sb) and sb.find(f".//{P}cNvPr").get("id")
        eid = eb.find(f".//{P}cNvPr").get("id")
        if on_site(start, sb, side_of(start, sb)):     # glue only where the drawn end is the connection site:
            etree.SubElement(cnv, A + "stCxn", id=sid, idx=str(side_of(start, sb)))   # every viewer then shows one line
        if on_site(end, eb, side_of(end, eb)):
            etree.SubElement(cnv, A + "endCxn", id=eid, idx=str(side_of(end, eb)))
        x = xf(cx)
        for k in ("flipH", "flipV"):
            x.attrib.pop(k, None)
        x.find(A + "off").set("x", str(min(start[0], end[0]))); x.find(A + "off").set("y", str(min(start[1], end[1])))
        x.find(A + "ext").set("cx", str(abs(end[0] - start[0]))); x.find(A + "ext").set("cy", str(abs(end[1] - start[1])))
        if end[0] < start[0]:
            x.set("flipH", "1")
        if end[1] < start[1]:
            x.set("flipV", "1")
        g = cx.find(f"{P}spPr/{A}prstGeom")
        av = g.find(A + "avLst")
        if straight:
            g.set("prst", "straightConnector1")
        else:
            g.set("prst", "bentConnector3")
            dx = end[0] - start[0]
            frac = int(round((pts[1][0] - start[0]) / dx * 100000)) if dx else 50000
            for c in list(av):
                av.remove(c)
            etree.SubElement(av, A + "gd", name="adj1", fmla=f"val {frac}")
        ln = cx.find(f"{P}spPr/{A}ln")
        for tag, on in (("headEnd", head), ("tailEnd", tail)):
            old = ln.find(A + tag)
            if old is not None:
                ln.remove(old)
            if on:
                arrow = copy.deepcopy((ch[0] if tag == "headEnd" else ch[-1]).find(f"{P}spPr/{A}ln/{A}{tag}"))
                ln.append(arrow)
        ch[0].addprevious(cx)
        for c in ch:
            tree.remove(c)
        made += 1
    return made, len(chains)


def nativize(path, slides=None, out=None):
    prs = Presentation(str(path))
    total_t = total_c = total_chains = 0
    for i, s in enumerate(prs.slides, 1):
        if slides and i not in slides:
            continue
        tree = s.shapes._spTree
        t = merge_text(tree)
        c, n = glue_flows(tree)
        total_t += t; total_c += c; total_chains += n
        if t or c:
            print(f"  slide {i}: {t} text box(es) moved into their shapes, {c}/{n} flow(s) made glued connectors")
    import atomic
    atomic.save(prs, out or path)
    print(f"nativize: {total_t} text boxes merged into shapes, {total_c} of {total_chains} flows glued")
    return total_t, total_c, total_chains


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("deck"); ap.add_argument("--slides"); ap.add_argument("--out")
    a = ap.parse_args()
    sl = {int(x) for x in a.slides.split(",")} if a.slides else None
    nativize(Path(a.deck), sl, Path(a.out) if a.out else None)


if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent))   # run on its own (python -I too): its sibling modules
    main()
