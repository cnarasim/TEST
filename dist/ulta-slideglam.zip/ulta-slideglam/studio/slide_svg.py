#!/usr/bin/env python3
"""A built slide as SVG, drawn by the Studio itself (v6.32) — no LibreOffice, no other program.

The live preview (the HTML twin, the storyboard) shows Presentation Central's slides — timelines, swimlanes, retail diagrams, process
flows, KPI cards, Sankey … — as a picture of the built slide. This draws that picture from the slide's own XML: the background, the
template's logo and footer (layout and master), every shape (rectangles, rounded rectangles, ellipses, chevrons, arrows, diamonds,
triangles, elbow connectors, lines with arrowheads, freeform paths), pictures and SVG icons, groups, tables and text — paragraphs,
sizes, bold, colours, alignment, insets, vertical anchoring and shrink-on-overflow, with placeholder styles inherited from the layout
and master. Text is HTML inside the SVG (foreignObject), so the browser wraps it with the twin's own fonts.

    import slide_svg
    svg = slide_svg.render(prs, prs.slides[3], drop=lambda el: …)     # one slide; drop: shapes to leave out (e.g. the headline)
    python slide_svg.py deck.pptx 4 > slide4.svg

What it does not draw: native charts (a frame with the chart's title), SmartArt, 3-D effects, gradients beyond their first colour.
"""
import base64, colorsys, copy, html, os, re, sys
from lxml import etree

NS = {'p': 'http://schemas.openxmlformats.org/presentationml/2006/main', 'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships', 'mc': 'http://schemas.openxmlformats.org/markup-compatibility/2006',
      'asvg': 'http://schemas.microsoft.com/office/drawing/2016/SVG/main', 'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart'}
P, A, R = '{%s}' % NS['p'], '{%s}' % NS['a'], '{%s}' % NS['r']
W_PX = 1280.0
SCHEME = {'tx1': 'dk1', 'bg1': 'lt1', 'tx2': 'dk2', 'bg2': 'lt2'}
SERIF = re.compile(r'chronicle|georgia|times|playfair|serif|garamond|baskerville|didot|bodoni|cambria', re.I)


def esc(s): return html.escape(str(s), quote=True)


class Ctx:
    """What a slide needs from its deck: the scale, the theme's colours, its layout and master, their pictures."""
    def __init__(self, prs, slide):
        self.prs, self.slide = prs, slide
        self.k = W_PX / prs.slide_width                     # px per EMU
        self.H = prs.slide_height * self.k
        self.layout = slide.slide_layout; self.master = self.layout.slide_master
        th = next((rel.target_part for rel in self.master.part.rels.values() if rel.reltype.endswith('/theme')), None)
        self.theme = {}
        if th is not None:
            t = etree.fromstring(th.blob)
            cs = t.find('.//a:clrScheme', NS)
            for el in (cs if cs is not None else []):
                c = el.find('a:srgbClr', NS); s_ = el.find('a:sysClr', NS)
                self.theme[etree.QName(el).localname] = (c.get('val') if c is not None else (s_.get('lastClr') if s_ is not None else '000000')).upper()
        self.clrmap = dict(self.master._element.find('p:clrMap', NS).attrib) if self.master._element.find('p:clrMap', NS) is not None else {}
        self.defs = []; self.uid = 0; self.used = set()

    def px(self, emu): return float(emu or 0) * self.k

    def scheme(self, name):
        name = self.clrmap.get(name, SCHEME.get(name, name))
        return self.theme.get(name, '000000')

    def next_id(self, p='m'):
        self.uid += 1; return f'{p}{self.uid}'


# ------------------------------------------------------------------------------------------------ colour
def _mods(hexv, el):
    r, g, b = (int(hexv[i:i + 2], 16) / 255 for i in (0, 2, 4)); alpha = 1.0
    for m in el:
        t = etree.QName(m).localname; v = int(m.get('val', '0')) / 100000
        if t == 'alpha': alpha = v
        elif t in ('lumMod', 'lumOff'):
            h, l, s = colorsys.rgb_to_hls(r, g, b)
            l = l * v if t == 'lumMod' else min(1, l + v)
            r, g, b = colorsys.hls_to_rgb(h, l, s)
        elif t == 'shade': r, g, b = r * v, g * v, b * v
        elif t == 'tint': r, g, b = r + (1 - r) * (1 - v), g + (1 - g) * (1 - v), b + (1 - b) * (1 - v)
    return '#%02X%02X%02X' % tuple(max(0, min(255, round(x * 255))) for x in (r, g, b)), alpha


def colour(ctx, el, ph=None):
    """A:srgbClr / schemeClr / sysClr / prstClr inside el → ('#RRGGBB', alpha) or None."""
    if el is None: return None
    for c in el:
        t = etree.QName(c).localname
        if t == 'srgbClr': return _mods(c.get('val', '000000').upper(), c)
        if t == 'schemeClr':
            v = c.get('val')
            base = ph if (v == 'phClr' and ph) else ctx.scheme(v)
            return _mods(base.lstrip('#'), c)
        if t == 'sysClr': return _mods((c.get('lastClr') or '000000').upper(), c)
        if t == 'prstClr': return _mods({'black': '000000', 'white': 'FFFFFF', 'red': 'FF0000'}.get(c.get('val'), '000000'), c)
    return None


def fill_of(ctx, spPr, style=None):
    if spPr is not None:
        if spPr.find('a:noFill', NS) is not None: return None
        sf = spPr.find('a:solidFill', NS)
        if sf is not None: return colour(ctx, sf)
        gf = spPr.find('a:gradFill', NS)
        if gf is not None:
            gs = gf.find('.//a:gs', NS)
            return colour(ctx, gs) if gs is not None else None
    if style is not None:
        fr = style.find('a:fillRef', NS)
        if fr is not None and fr.get('idx', '0') not in ('0',): return colour(ctx, fr)
    return None


def line_of(ctx, spPr, style=None, connector=False):
    """(colour, alpha, width px, dash, head, tail) or None."""
    ln = spPr.find('a:ln', NS) if spPr is not None else None
    col = None; w = None
    if ln is not None:
        if ln.find('a:noFill', NS) is not None: return None
        sf = ln.find('a:solidFill', NS)
        if sf is not None: col = colour(ctx, sf)
        if ln.get('w'): w = ctx.px(int(ln.get('w')))
    if col is None and style is not None:
        lr = style.find('a:lnRef', NS)
        if lr is not None and lr.get('idx', '0') != '0': col = colour(ctx, lr); w = w or ctx.px(12700) * int(lr.get('idx', '1'))
    if col is None:
        if not connector: return None
        col = ('#000000', 1.0)   # a connector with no line of its own: the default thin black line
    dash = None
    if ln is not None:
        pd = ln.find('a:prstDash', NS)
        if pd is not None and pd.get('val') not in (None, 'solid'): dash = {'dash': '6 4', 'sysDash': '4 3', 'dot': '1.5 3', 'sysDot': '1.5 2', 'lgDash': '10 5', 'dashDot': '6 3 1.5 3'}.get(pd.get('val'), '5 4')
    head = ln.find('a:headEnd', NS) if ln is not None else None; tail = ln.find('a:tailEnd', NS) if ln is not None else None
    arrow = lambda e: e is not None and e.get('type') not in (None, 'none')
    return col + (w if w is not None else 1.0, dash, arrow(head), arrow(tail))


# ------------------------------------------------------------------------------------------------ geometry
def _adj(geom, name, default):
    for gd in geom.findall('a:avLst/a:gd', NS):
        if gd.get('name') == name:
            m = re.match(r'val\s+(-?\d+)', gd.get('fmla', ''))
            if m: return int(m.group(1))
    return default


def path_of(geom_el, w, h):
    """('path', d) | ('rect', rx) | ('ellipse', None) | ('line', None) in local px coordinates 0..w × 0..h."""
    if geom_el is None: return ('rect', 0)
    t = etree.QName(geom_el).localname
    if t == 'custGeom':
        d = []
        for pth in geom_el.findall('a:pathLst/a:path', NS):
            pw = float(pth.get('w') or 0) or None; phh = float(pth.get('h') or 0) or None
            sx = (w / pw) if pw else 1; sy = (h / phh) if phh else 1
            # without w/h the path is in the shape's own EMU: the caller passes the scale through w/h of the shape
            for cmd in pth:
                c = etree.QName(cmd).localname
                pts = [(float(pt.get('x')) * sx, float(pt.get('y')) * sy) for pt in cmd.findall('a:pt', NS)]
                if c == 'moveTo' and pts: d.append('M%.2f %.2f' % pts[0])
                elif c == 'lnTo' and pts: d.append('L%.2f %.2f' % pts[0])
                elif c == 'cubicBezTo' and len(pts) == 3: d.append('C' + ' '.join('%.2f %.2f' % p for p in pts))
                elif c == 'quadBezTo' and len(pts) == 2: d.append('Q' + ' '.join('%.2f %.2f' % p for p in pts))
                elif c == 'close': d.append('Z')
        return ('path', ' '.join(d)) if d else ('rect', 0)
    prst = geom_el.get('prst', 'rect'); ss = min(w, h)
    if prst == 'rect' or prst.startswith('flowChartProcess'): return ('rect', 0)
    if prst in ('roundRect', 'flowChartAlternateProcess'): return ('rect', ss * _adj(geom_el, 'adj', 16667) / 100000)
    if prst in ('ellipse', 'flowChartConnector'): return ('ellipse', None)
    if prst in ('line', 'straightConnector1'): return ('line', None)
    if prst == 'chevron':
        x1 = ss * _adj(geom_el, 'adj', 50000) / 100000
        return ('path', f'M0 0 L{w - x1:.2f} 0 L{w:.2f} {h / 2:.2f} L{w - x1:.2f} {h:.2f} L0 {h:.2f} L{x1:.2f} {h / 2:.2f} Z')
    if prst == 'homePlate':
        x1 = ss * _adj(geom_el, 'adj', 50000) / 100000
        return ('path', f'M0 0 L{w - x1:.2f} 0 L{w:.2f} {h / 2:.2f} L{w - x1:.2f} {h:.2f} L0 {h:.2f} Z')
    if prst in ('diamond', 'flowChartDecision'): return ('path', f'M{w / 2:.2f} 0 L{w:.2f} {h / 2:.2f} L{w / 2:.2f} {h:.2f} L0 {h / 2:.2f} Z')
    if prst == 'triangle':
        ax = w * _adj(geom_el, 'adj', 50000) / 100000
        return ('path', f'M{ax:.2f} 0 L{w:.2f} {h:.2f} L0 {h:.2f} Z')
    if prst == 'rtTriangle': return ('path', f'M0 0 L{w:.2f} {h:.2f} L0 {h:.2f} Z')
    if prst in ('rightArrow', 'leftArrow'):
        a1, a2 = _adj(geom_el, 'adj1', 50000) / 100000, ss * _adj(geom_el, 'adj2', 50000) / 100000
        y1, y2 = h / 2 - h * a1 / 2, h / 2 + h * a1 / 2; x1 = w - a2
        if prst == 'rightArrow':
            return ('path', f'M0 {y1:.2f} L{x1:.2f} {y1:.2f} L{x1:.2f} 0 L{w:.2f} {h / 2:.2f} L{x1:.2f} {h:.2f} L{x1:.2f} {y2:.2f} L0 {y2:.2f} Z')
        return ('path', f'M{w:.2f} {y1:.2f} L{a2:.2f} {y1:.2f} L{a2:.2f} 0 L0 {h / 2:.2f} L{a2:.2f} {h:.2f} L{a2:.2f} {y2:.2f} L{w:.2f} {y2:.2f} Z')
    if prst == 'hexagon':
        x1 = ss * _adj(geom_el, 'adj', 25000) / 100000
        return ('path', f'M{x1:.2f} 0 L{w - x1:.2f} 0 L{w:.2f} {h / 2:.2f} L{w - x1:.2f} {h:.2f} L{x1:.2f} {h:.2f} L0 {h / 2:.2f} Z')
    if prst == 'parallelogram':
        x1 = ss * _adj(geom_el, 'adj', 25000) / 100000
        return ('path', f'M{x1:.2f} 0 L{w:.2f} 0 L{w - x1:.2f} {h:.2f} L0 {h:.2f} Z')
    if prst == 'pentagon': return ('path', f'M{w / 2:.2f} 0 L{w:.2f} {h * 0.38:.2f} L{w * 0.81:.2f} {h:.2f} L{w * 0.19:.2f} {h:.2f} L0 {h * 0.38:.2f} Z')
    if prst.startswith('bentConnector'):
        x1 = w * _adj(geom_el, 'adj1', 50000) / 100000
        return ('open', f'M0 0 L{x1:.2f} 0 L{x1:.2f} {h:.2f} L{w:.2f} {h:.2f}')
    if prst.startswith('curvedConnector'): return ('open', f'M0 0 C{w / 2:.2f} 0 {w / 2:.2f} {h:.2f} {w:.2f} {h:.2f}')
    if prst in ('donut', 'blockArc', 'arc', 'pie', 'chord'): return ('ellipse', None)
    if prst in ('plus', 'mathPlus'):
        t3 = ss * 0.25
        return ('path', f'M{w / 2 - t3 / 2:.2f} 0 h{t3:.2f} v{h / 2 - t3 / 2:.2f} h{w / 2 - t3 / 2:.2f} v{t3:.2f} h-{w / 2 - t3 / 2:.2f} v{h / 2 - t3 / 2:.2f} h-{t3:.2f} v-{h / 2 - t3 / 2:.2f} h-{w / 2 - t3 / 2:.2f} v-{t3:.2f} h{w / 2 - t3 / 2:.2f} Z')
    return ('rect', 0)


# ------------------------------------------------------------------------------------------------ text
def _lvl_props(lst, lvl):
    if lst is None: return None
    return lst.find(f'a:lvl{lvl}pPr', NS)


class TextStyle:
    """The chain a paragraph's look comes from: its own, the shape's list style, the layout's and master's placeholder, the master's text styles."""
    def __init__(self, ctx, sp, ph_kind):
        self.chain = []
        txb = sp.find('p:txBody', NS)
        if txb is None: txb = sp.find('a:txBody', NS)
        self.chain.append(txb.find('a:lstStyle', NS) if txb is not None else None)
        ph = sp.find('.//p:nvPr/p:ph', NS)
        self.ph = ph
        if ph is not None:
            for owner in (ctx.layout, ctx.master):
                m = _find_ph(owner, ph)
                if m is not None:
                    tb = m.find('p:txBody', NS); self.chain.append(tb.find('a:lstStyle', NS) if tb is not None else None)
            tx = ctx.master._element.find('p:txStyles', NS)
            t = ph.get('type', 'body')
            key = 'p:titleStyle' if t in ('title', 'ctrTitle') else ('p:bodyStyle' if t in ('body', 'subTitle', 'obj') or ph.get('idx') else 'p:otherStyle')
            self.chain.append(tx.find(key, NS) if tx is not None else None)
        else:
            tx = ctx.master._element.find('p:txStyles', NS)
            self.chain.append(tx.find('p:otherStyle', NS) if tx is not None else None)

    def get(self, lvl, getter):
        for lst in self.chain:
            pp = _lvl_props(lst, lvl)
            if pp is not None:
                v = getter(pp)
                if v is not None: return v
        return None


def _find_ph(owner, ph):
    t = ph.get('type'); idx = ph.get('idx')
    for sp in owner.shapes._spTree.iter(P + 'sp'):
        q = sp.find('.//p:nvPr/p:ph', NS)
        if q is None: continue
        if idx is not None and q.get('idx') == idx: return sp
    for sp in owner.shapes._spTree.iter(P + 'sp'):
        q = sp.find('.//p:nvPr/p:ph', NS)
        if q is not None and (q.get('type') or 'body') == (t or 'body') and (idx is None or q.get('idx') is None): return sp
    return None


def _text_model(ctx, sp, txb, scale_font=1.0):
    """The text body as paragraphs of runs, every property resolved (its own, the list style, layout, master): what both the HTML
    (the live views) and the drawn text (pictures, the layout check) are made from. None: no words."""
    if txb is None: return None
    paras = txb.findall('a:p', NS)
    if not any((''.join(t.text or '' for t in p.iter(A + 't'))).strip() for p in paras): return None
    st = TextStyle(ctx, sp, None)
    bp = txb.find('a:bodyPr', NS); bp = bp if bp is not None else etree.Element(A + 'bodyPr')
    ins = [ctx.px(int(bp.get(k, d))) for k, d in (('tIns', 45720), ('rIns', 91440), ('bIns', 45720), ('lIns', 91440))]
    anchor = bp.get('anchor') or st.get(1, lambda pp: None) or 't'
    na = bp.find('a:normAutofit', NS)
    fs_scale = scale_font * ((int(na.get('fontScale', '100000')) / 100000) if na is not None else 1.0)
    ln_red = (int(na.get('lnSpcReduction', '0')) / 100000) if na is not None else 0
    wrap = bp.get('wrap', 'square') != 'none'
    out = []
    for p in paras:
        pPr = p.find('a:pPr', NS); lvl = int(pPr.get('lvl', '0')) + 1 if pPr is not None else 1
        algn = (pPr.get('algn') if pPr is not None and pPr.get('algn') else st.get(lvl, lambda pp: pp.get('algn'))) or 'l'
        def rp(getter, run_rpr):
            if run_rpr is not None:
                v = getter(run_rpr)
                if v is not None: return v
            if pPr is not None:
                d = pPr.find('a:defRPr', NS)
                if d is not None and getter(d) is not None: return getter(d)
            return st.get(lvl, lambda pp: getter(pp.find('a:defRPr', NS)) if pp.find('a:defRPr', NS) is not None else None)
        runs = []; first_sz = None
        bullet = None
        bu = pPr.find('a:buChar', NS) if pPr is not None else None
        if bu is None and (pPr is None or pPr.find('a:buNone', NS) is None):
            bu = st.get(lvl, lambda pp: False if pp.find('a:buNone', NS) is not None else pp.find('a:buChar', NS)) if st.ph is not None and st.ph.get('type') not in ('title', 'ctrTitle') else None
            if bu is False: bu = None   # a layout's "no bullet" ends the search (the master's body bullets do not come through)
        if bu is not None and bu.get('char'): bullet = bu.get('char')
        for r in p:
            t = etree.QName(r).localname
            if t == 'br': runs.append(None); continue
            if t not in ('r', 'fld'): continue
            txt = ''.join(x.text or '' for x in r.iter(A + 't'))
            if not txt: continue
            rpr = r.find('a:rPr', NS)
            sz = rp(lambda e: int(e.get('sz')) if e is not None and e.get('sz') else None, rpr) or 1800
            first_sz = first_sz or sz
            bv = rp(lambda e: e.get('b') if e is not None and e.get('b') is not None else None, rpr)
            b = bv in ('1', 'true') if bv is not None else bool(getattr(ctx, 'cell_bold', None))   # a table style's bold header
            it = rp(lambda e: e.get('i') if e is not None and e.get('i') is not None else None, rpr) in ('1', 'true')
            col = rp(lambda e: colour(ctx, e.find('a:solidFill', NS)) if e is not None and e.find('a:solidFill', NS) is not None else None, rpr) or getattr(ctx, 'cell_color', None) or ('#000000', 1)
            face = rp(lambda e: e.find('a:latin', NS).get('typeface') if e is not None and e.find('a:latin', NS) is not None else None, rpr) or ''
            if face.startswith('+mj'): face = 'serif-major'
            serif = bool(SERIF.search(face) or face == 'serif-major' and st.ph is not None and st.ph.get('type') in ('title', 'ctrTitle'))
            runs.append({'text': txt, 'px': sz / 100 * 96 / 72 * fs_scale, 'color': col, 'serif': serif, 'bold': b, 'italic': it})
        sz0 = (first_sz or rp(lambda e: int(e.get('sz')) if e is not None and e.get('sz') else None, None) or 1800) / 100 * 96 / 72 * fs_scale
        lh = 1.18
        if pPr is not None and pPr.find('a:lnSpc/a:spcPct', NS) is not None: lh = 1.18 * int(pPr.find('a:lnSpc/a:spcPct', NS).get('val')) / 100000
        lh = max(0.8, lh * (1 - ln_red))
        sb = int(pPr.find('a:spcBef/a:spcPts', NS).get('val')) / 100 * 96 / 72 if pPr is not None and pPr.find('a:spcBef/a:spcPts', NS) is not None else 0
        sa = int(pPr.find('a:spcAft/a:spcPts', NS).get('val')) / 100 * 96 / 72 if pPr is not None and pPr.find('a:spcAft/a:spcPts', NS) is not None else 0
        marL = ctx.px(int(pPr.get('marL'))) if pPr is not None and pPr.get('marL') else (ctx.px(int(st.get(lvl, lambda pp: pp.get('marL')) or 0)))
        indent = ctx.px(int(pPr.get('indent'))) if pPr is not None and pPr.get('indent') else (ctx.px(int(st.get(lvl, lambda pp: pp.get('indent')) or 0)))
        out.append({'runs': runs, 'bullet': bullet, 'align': algn, 'lh': lh, 'sb': sb, 'sa': sa, 'marL': marL, 'indent': indent, 'px': sz0})
    return {'paras': out, 'ins': ins, 'anchor': anchor, 'wrap': wrap}


def text_html(ctx, sp, txb, w, h, scale_font=1.0, origin=(0.0, 0.0)):
    """The text body as HTML for a foreignObject of w × h px (ctx.text == 'svg': drawn as SVG text instead, see text_svg)."""
    m = _text_model(ctx, sp, txb, scale_font)
    if m is None: return ''
    if getattr(ctx, 'text', 'html') == 'svg': return text_svg(ctx, m, w, h, origin)
    out = []
    for pa in m['paras']:
        spans = []
        for r in pa['runs']:
            if r is None: spans.append('<br/>'); continue
            fam = 'var(--serif,Georgia,serif)' if r['serif'] else 'var(--sans,Inter,Arial,sans-serif)'
            css = f"font-size:{r['px']:.2f}px;color:{r['color'][0]};font-family:{fam};" + ('font-weight:700;' if r['bold'] else '') + ('font-style:italic;' if r['italic'] else '')
            if r['color'][1] < 1: css += f"opacity:{r['color'][1]:.2f};"
            spans.append(f'<span style="{css}">{esc(r["text"])}</span>')
        ta = {'l': 'left', 'ctr': 'center', 'r': 'right', 'just': 'justify', 'dist': 'justify'}.get(pa['align'], 'left')
        body = ''.join(spans) or '&#8203;'
        if pa['bullet'] and spans: body = f'<span class="bu" contenteditable="false" style="display:inline-block;width:{max(10, -pa["indent"]):.1f}px;margin-left:{pa["indent"]:.1f}px">{esc(pa["bullet"])}</span>' + body
        out.append(f'<p style="margin:{pa["sb"]:.1f}px 0 {pa["sa"]:.1f}px {pa["marL"]:.1f}px;text-align:{ta};line-height:{pa["lh"]:.2f};font-size:{pa["px"]:.2f}px;'
                   + ('white-space:nowrap;' if not m['wrap'] else 'overflow-wrap:anywhere;') + f'">{body}</p>')
    ins = m['ins']
    jc = {'t': 'flex-start', 'ctr': 'center', 'b': 'flex-end', 'just': 'center', 'dist': 'center'}.get(m['anchor'], 'flex-start')
    return (f'<foreignObject x="0" y="0" width="{w:.2f}" height="{h:.2f}" overflow="visible"><div xmlns="http://www.w3.org/1999/xhtml" '
            f'style="box-sizing:border-box;width:{w:.2f}px;height:{h:.2f}px;padding:{ins[0]:.1f}px {ins[1]:.1f}px {ins[2]:.1f}px {ins[3]:.1f}px;'
            f'display:flex;flex-direction:column;justify-content:{jc};overflow:visible">{"".join(out)}</div></foreignObject>')


# ------------------------------------------------------------------------------------------------ v6.33 drawn text (pictures, layout check)
FONT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'fonts')
FONTS = {(True, True): 'PlayfairDisplay-Black.ttf', (True, False): 'PlayfairDisplay-Black.ttf', (False, True): 'Inter-Bold.otf', (False, False): 'Inter-Regular.otf'}
SVG_FACE = {True: ('Playfair Display', 900), False: ('Inter', None)}
_FONT_CACHE = {}


def font_files():
    return [os.path.join(FONT_DIR, f) for f in sorted(set(FONTS.values())) if os.path.isfile(os.path.join(FONT_DIR, f))]


def _font(serif, bold, px):
    """The font the picture is drawn with (Playfair Display Black for the display face, Inter for the body: the template's stand-ins)."""
    key = (serif, bold, round(px * 4) / 4)
    f = _FONT_CACHE.get(key)
    if f is None:
        from PIL import ImageFont
        try: f = ImageFont.truetype(os.path.join(FONT_DIR, FONTS[(serif, bold)]), max(1, int(round(key[2] * 4))))   # 4× for sub-pixel widths
        except Exception: f = ImageFont.load_default()
        if len(_FONT_CACHE) > 400: _FONT_CACHE.clear()
        _FONT_CACHE[key] = f
    return f


def _w(run, s):
    try: return _font(run['serif'], run['bold'], run['px']).getlength(s) / 4
    except Exception: return len(s) * run['px'] * 0.52


def _lines(pa, width, wrap):
    """A paragraph broken into lines that fit width: [[(run, text), …], …] with each line's width; words wider than the line break
    anywhere (as the browser does with overflow-wrap) and are reported."""
    tokens = []   # (run, piece) — words with their trailing space, line breaks as None
    for r in pa['runs']:
        if r is None: tokens.append(None); continue
        for piece in re.findall(r'\S+\s*|\s+', r['text']): tokens.append((r, piece))
    lines, cur, cw, too_wide = [], [], 0.0, []
    for tk in tokens:
        if tk is None: lines.append((cur, cw)); cur, cw = [], 0.0; continue
        r, piece = tk; word = piece.rstrip(); pw = _w(r, piece); ww = _w(r, word)
        if not wrap or not cur or cw + ww <= width + 0.5:
            if wrap and not cur and ww > width + 0.5 and word:   # one word wider than the box: broken by characters
                too_wide.append(word); buf = ''
                for ch in piece:
                    if buf and _w(r, buf + ch) > width:
                        lines.append(([(r, buf)], _w(r, buf))); buf = ''
                    buf += ch
                cur, cw = [(r, buf)], _w(r, buf); continue
            cur.append((r, piece)); cw += pw
        else:
            lines.append((cur, cw)); cur, cw = [(r, piece)], pw
            if ww > width + 0.5 and word: too_wide.append(word)
    lines.append((cur, cw))
    return lines, too_wide


def text_svg(ctx, m, w, h, origin=(0.0, 0.0)):
    """The text drawn as SVG <text> (resvg draws it with the same font files it was measured with): the slide's picture without a
    browser or LibreOffice. Each line's box goes to ctx.lines (slide px) for the layout check."""
    ins = m['ins']; inner = max(1.0, w - ins[1] - ins[3])
    blocks, total = [], 0.0
    for pa in m['paras']:
        x0 = pa['marL']; avail = max(1.0, inner - x0)
        lines, wide = _lines(pa, avail, m['wrap'])
        for wd in wide: getattr(ctx, 'wide', []).append(wd)
        laid = []
        for k, (ln, lw) in enumerate(lines):
            sizes = [r['px'] for r, _ in ln] or [pa['px']]
            lh = max(sizes) * pa['lh']
            laid.append((ln, lw, lh, max(sizes)))
        hgt = pa['sb'] + sum(x[2] for x in laid) + pa['sa']
        blocks.append((pa, laid, hgt)); total += hgt
    room = h - ins[0] - ins[2]
    y = ins[0] + {'ctr': (room - total) / 2, 'just': (room - total) / 2, 'dist': (room - total) / 2, 'b': room - total}.get(m['anchor'], 0)
    out = []; ox, oy = origin
    for pa, laid, hgt in blocks:
        y += pa['sb']
        for k, (ln, lw, lh, big) in enumerate(laid):
            lw_trim = lw - (_w(ln[-1][0], ln[-1][1]) - _w(ln[-1][0], ln[-1][1].rstrip()) if ln else 0)
            left = ins[3] + pa['marL']
            if pa['align'] == 'ctr': x = left + (inner - pa['marL'] - lw_trim) / 2
            elif pa['align'] == 'r': x = left + (inner - pa['marL'] - lw_trim)
            else: x = left
            base = y + (lh - big) / 2 + big * 0.80   # the baseline: the line's half-leading, then the ascent
            if k == 0 and pa['bullet'] and ln:
                r0 = ln[0][0]
                out.append(f'<text x="{x + pa["indent"]:.2f}" y="{base:.2f}" font-family="Inter" font-size="{r0["px"]:.2f}" fill="{r0["color"][0]}">{esc(pa["bullet"])}</text>')
            spans = []
            for r, piece in ln:
                fam, wt = SVG_FACE[r['serif']]
                weight = wt or (700 if r['bold'] else 400)
                spans.append(f'<tspan font-family="{fam}" font-weight="{weight}" font-size="{r["px"]:.2f}" fill="{r["color"][0]}"'
                             + (f' fill-opacity="{r["color"][1]:.2f}"' if r['color'][1] < 1 else '') + (' font-style="italic"' if r['italic'] else '') + f'>{esc(piece)}</tspan>')
            if spans: out.append(f'<text x="{x:.2f}" y="{base:.2f}" xml:space="preserve">{"".join(spans)}</text>')
            txt = ''.join(pc for _, pc in ln).strip()
            if txt and hasattr(ctx, 'lines'):
                sx, sy, tx, ty, rot = getattr(ctx, 'tf', (1, 1, 0, 0, False))
                if not rot:
                    ax, ay = sx * (ox + x) + tx, sy * (oy + y) + ty
                    ctx.lines.append((ax, ay, ax + sx * lw_trim, ay + sy * lh, txt))
            y += lh
        y += pa['sa']
    return ''.join(out)


# ------------------------------------------------------------------------------------------------ shapes
def _xfrm(el):
    x = el.find('a:off', NS) if el is not None else None; e = el.find('a:ext', NS) if el is not None else None
    if x is None or e is None: return None
    return (int(x.get('x')), int(x.get('y')), int(e.get('cx')), int(e.get('cy')), int(el.get('rot', '0')) / 60000, el.get('flipH') == '1', el.get('flipV') == '1')


_IMG = {}


def _image(part, rid, w=None, h=None):
    """A picture as a data URI — a photo or a large PNG made no bigger than it is drawn (twice, for sharp screens), once per deck."""
    try:
        tp = part.rels[rid].target_part
    except Exception: return None
    ct = tp.content_type or 'image/png'
    if 'svg' in ct: ct = 'image/svg+xml'
    if ct in ('image/x-emf', 'image/x-wmf', 'image/emf', 'image/wmf'): return None   # a picture no browser draws
    key = (str(tp.partname), id(tp.package), round(w or 0), round(h or 0))
    if key in _IMG: return _IMG[key]
    blob = tp.blob
    if ct in ('image/png', 'image/jpeg') and len(blob) > 60000 and w and h:
        try:
            import io
            from PIL import Image
            im = Image.open(io.BytesIO(blob)); big = w >= 0.8 * W_PX   # a full-slide background: sharp enough at the slide's own size
            tw, th = max(1, round(w * (1 if big else 2))), max(1, round(h * (1 if big else 2)))
            opaque = im.mode in ('RGB', 'L') or (im.mode in ('RGBA', 'LA') and im.getchannel('A').getextrema()[0] >= 250)
            if im.width > tw * 1.1 or im.height > th * 1.1 or (opaque and len(blob) > 150000):
                if im.width > tw or im.height > th: im = im.resize((min(im.width, tw), min(im.height, th)), Image.LANCZOS)
                buf = io.BytesIO()
                if opaque: im.convert('RGB').save(buf, 'JPEG', quality=84, optimize=True); ct = 'image/jpeg'
                else: im.save(buf, 'PNG', optimize=True)
                if len(buf.getvalue()) < len(blob): blob = buf.getvalue()
        except Exception: pass  # noqa: BLE001  the picture as it is
    _IMG[key] = 'data:%s;base64,%s' % (ct, base64.b64encode(blob).decode())
    if len(_IMG) > 400: _IMG.clear()
    return _IMG[key]


def _marker(ctx, col):
    mid = ctx.next_id('arr')
    ctx.defs.append(f'<marker id="{mid}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">'
                    f'<path d="M0 0 L10 5 L0 10 Z" fill="{col}"/></marker>')
    return mid


def shape(ctx, el, part, drop, inherit_xfrm=None):
    t = etree.QName(el).localname
    if drop and drop(el): return ''
    if t == 'AlternateContent':
        alt = el.find('mc:Fallback', NS)
        if alt is None: alt = el.find('mc:Choice', NS)
        return ''.join(shape(ctx, c, part, drop) for c in (alt if alt is not None else []))
    if t == 'grpSp':
        x = _xfrm(el.find('p:grpSpPr/a:xfrm', NS))
        ch = el.find('p:grpSpPr/a:xfrm/a:chOff', NS); ce = el.find('p:grpSpPr/a:xfrm/a:chExt', NS)
        sx = (x[2] / int(ce.get('cx'))) if x is not None and ce is not None and int(ce.get('cx') or 0) else 1
        sy = (x[3] / int(ce.get('cy'))) if x is not None and ce is not None and int(ce.get('cy') or 0) else 1
        tf0 = getattr(ctx, 'tf', None)
        if tf0 is not None and x is not None and ch is not None:   # the group's own mapping, for the text lines' slide positions
            a, b, c, d, r0 = tf0; gx = ctx.px(x[0]) - sx * ctx.px(int(ch.get('x'))); gy = ctx.px(x[1]) - sy * ctx.px(int(ch.get('y')))
            ctx.tf = (a * sx, b * sy, a * gx + c, b * gy + d, r0 or bool(x[4]))
        try: inner = ''.join(shape(ctx, c, part, drop) for c in el if etree.QName(c).localname in ('sp', 'cxnSp', 'pic', 'grpSp', 'graphicFrame', 'AlternateContent'))
        finally:
            if tf0 is not None: ctx.tf = tf0
        if x is None or ch is None or ce is None: return f'<g>{inner}</g>'
        tr = (f'translate({ctx.px(x[0]):.2f} {ctx.px(x[1]):.2f}) scale({sx:.5f} {sy:.5f}) translate({-ctx.px(int(ch.get("x"))):.2f} {-ctx.px(int(ch.get("y"))):.2f})')
        if x[4]: tr = f'rotate({x[4]:.2f} {ctx.px(x[0] + x[2] / 2):.2f} {ctx.px(x[1] + x[3] / 2):.2f}) ' + tr
        return f'<g transform="{tr}">{inner}</g>'
    if t == 'pic':
        x = _xfrm(el.find('p:spPr/a:xfrm', NS)) or inherit_xfrm
        if x is None: return ''
        blip = el.find('.//a:blip', NS)
        if blip is None: return ''
        svg_b = blip.find('.//asvg:svgBlip', NS)
        X, Y, W, H = ctx.px(x[0]), ctx.px(x[1]), ctx.px(x[2]), ctx.px(x[3])
        href = (_image(part, svg_b.get(R + 'embed')) if svg_b is not None else None) or _image(part, blip.get(R + 'embed'), W, H)
        if not href: return ''
        tr = f' transform="rotate({x[4]:.2f} {X + W / 2:.2f} {Y + H / 2:.2f})"' if x[4] else ''
        return f'<image x="{X:.2f}" y="{Y:.2f}" width="{W:.2f}" height="{H:.2f}" preserveAspectRatio="none" href="{href}"{tr}/>'
    if t == 'graphicFrame':
        x = _xfrm(el.find('p:xfrm', NS))
        if x is None: return ''
        tbl = el.find('.//a:tbl', NS)
        if tbl is not None: return table(ctx, el, tbl, x, part)
        pic = el.find('.//p:pic', NS)
        if pic is not None: return shape(ctx, pic, part, drop, inherit_xfrm=x)
        if el.find('.//c:chart', NS) is not None:
            X, Y, W, H = ctx.px(x[0]), ctx.px(x[1]), ctx.px(x[2]), ctx.px(x[3])
            try: return chart(ctx, part, el.find('.//c:chart', NS).get(R + 'id'), X, Y, W, H)
            except Exception: return f'<rect x="{X:.2f}" y="{Y:.2f}" width="{W:.2f}" height="{H:.2f}" rx="6" fill="#FFFFFF" stroke="#D9D9D9"/>'  # noqa: BLE001
        return ''
    if t not in ('sp', 'cxnSp'): return ''
    spPr = el.find('p:spPr', NS); style = el.find('p:style', NS)
    x = _xfrm(spPr.find('a:xfrm', NS) if spPr is not None else None)
    ph = el.find('.//p:nvPr/p:ph', NS)
    if x is None and ph is not None:   # a placeholder without a position takes its layout's (or master's)
        for owner in (ctx.layout, ctx.master):
            m = _find_ph(owner, ph)
            if m is not None:
                x = _xfrm(m.find('p:spPr/a:xfrm', NS))
                if x is not None: break
    if x is None: return ''
    X, Y, W, H, rot, fh, fv = ctx.px(x[0]), ctx.px(x[1]), ctx.px(x[2]), ctx.px(x[3]), x[4], x[5], x[6]
    geom = spPr.find('a:prstGeom', NS) if spPr is not None else None
    if geom is None and spPr is not None: geom = spPr.find('a:custGeom', NS)
    kind, arg = path_of(geom, W, H)
    fill = None if kind in ('line', 'open') else fill_of(ctx, spPr, style)
    ln = line_of(ctx, spPr, style, connector=(t == 'cxnSp'))
    attrs = f'fill="{fill[0]}"' + (f' fill-opacity="{fill[1]:.2f}"' if fill and fill[1] < 1 else '') if fill else 'fill="none"'
    marks = ''
    if ln:
        attrs += f' stroke="{ln[0]}" stroke-width="{max(0.5, ln[2]):.2f}"' + (f' stroke-opacity="{ln[1]:.2f}"' if ln[1] < 1 else '') + (f' stroke-dasharray="{ln[3]}"' if ln[3] else '')
        if kind in ('line', 'open'):
            if ln[5]: marks += f' marker-end="url(#{_marker(ctx, ln[0])})"'
            if ln[4]: marks += f' marker-start="url(#{_marker(ctx, ln[0])})"'
    if kind == 'rect': g = f'<rect x="0" y="0" width="{W:.2f}" height="{H:.2f}" rx="{arg:.2f}" {attrs}/>'
    elif kind == 'ellipse': g = f'<ellipse cx="{W / 2:.2f}" cy="{H / 2:.2f}" rx="{W / 2:.2f}" ry="{H / 2:.2f}" {attrs}/>'
    elif kind == 'line': g = f'<path d="M0 0 L{W:.2f} {H:.2f}" {attrs}{marks}/>'
    else: g = f'<path d="{arg}" {attrs}{marks}/>'
    if not fill and not ln: g = ''
    sh = spPr.find('a:effectLst/a:outerShdw', NS) if spPr is not None else None
    if g and sh is not None and fill:
        if 'shadow' not in ctx.used:
            ctx.used.add('shadow'); ctx.defs.append('<filter id="shadow" x="-10%" y="-10%" width="130%" height="140%"><feDropShadow dx="0" dy="2.5" stdDeviation="4" flood-color="#000" flood-opacity="0.16"/></filter>')
        g = g.replace('/>', ' filter="url(#shadow)"/>', 1)
    tr = f'translate({X:.2f} {Y:.2f})'
    if rot: tr += f' rotate({rot:.2f} {W / 2:.2f} {H / 2:.2f})'
    flip = ''
    if fh or fv: flip = f' transform="translate({W if fh else 0:.2f} {H if fv else 0:.2f}) scale({-1 if fh else 1} {-1 if fv else 1})"'
    tf_saved = getattr(ctx, 'tf', None)
    if rot and tf_saved is not None: ctx.tf = tf_saved[:4] + (True,)   # a turned box: its lines are not checked (positions would be off)
    txt = text_html(ctx, el, el.find('p:txBody', NS), W, H, origin=(X, Y))
    if tf_saved is not None: ctx.tf = tf_saved
    if not g and not txt: return ''
    return f'<g transform="{tr}"><g{flip}>{g}</g>{txt}</g>'


# ------------------------------------------------------------------------------------------------ v6.33 charts (PowerPoint's own)
def _cache(el):
    """A series' categories or values from the chart's own cache (what PowerPoint shows until the data is edited)."""
    if el is None: return []
    c = None
    for t in ('numRef/c:numCache', 'strRef/c:strCache', 'numLit', 'strLit', 'multiLvlStrRef/c:multiLvlStrCache/c:lvl'):
        c = el.find('c:' + t, NS)
        if c is not None: break
    if c is None: return []
    n = int((c.find('c:ptCount', NS) if c.find('c:ptCount', NS) is not None else etree.Element('x', val='0')).get('val', '0') or 0)
    got = {int(pt.get('idx', '0')): pt.findtext('c:v', '', NS) for pt in c.findall('c:pt', NS)}
    return [got.get(i) for i in range(max(n, (max(got) + 1) if got else 0))]


def _num(v):
    try: return float(v)
    except (TypeError, ValueError): return None


def _fmt(v, code=''):
    if v is None: return ''
    if '%' in (code or ''): return f'{v * 100:.0f}%' if abs(v) <= 1.5 else f'{v:.0f}%'
    if float(v).is_integer(): return f'{int(v):,}'
    return f'{v:,.1f}'


def chart(ctx, part, rid, X, Y, W, H):
    """A PowerPoint chart drawn from its own XML and data cache: doughnut and pie, column and bar (clustered, stacked, 100%), line and
    area — the colours the chart sets, else the theme's accents. Enough for the slide's picture (previews, the AI's visual review)."""
    root = etree.fromstring(part.rels[rid].target_part.blob)
    plot = root.find('.//c:plotArea', NS)
    kinds = [c for c in plot if etree.QName(c).localname in ('pieChart', 'pie3DChart', 'doughnutChart', 'barChart', 'bar3DChart', 'lineChart', 'line3DChart', 'areaChart')]
    if not kinds: return ''
    ct = kinds[0]; kind = etree.QName(ct).localname; accents = [ctx.scheme(f'accent{i}') for i in range(1, 7)]
    tx = root.find('c:txPr', NS); dr = tx.find('.//a:defRPr', NS) if tx is not None else None
    fpx = (int(dr.get('sz')) / 100 * 96 / 72) if dr is not None and dr.get('sz') else 13.0
    tcol = (colour(ctx, dr.find('a:solidFill', NS)) or ('#404040', 1))[0] if dr is not None and dr.find('a:solidFill', NS) is not None else '#404040'
    out = []
    bg = fill_of(ctx, root.find('c:spPr', NS)) if root.find('c:spPr', NS) is not None else None
    if bg: out.append(f'<rect x="{X:.2f}" y="{Y:.2f}" width="{W:.2f}" height="{H:.2f}" fill="{bg[0]}"/>')
    ml = plot.find('c:layout/c:manualLayout', NS)
    if ml is not None and ml.find('c:x', NS) is not None and ml.find('c:w', NS) is not None:
        px_, py_ = X + W * float(ml.find('c:x', NS).get('val')), Y + H * float(ml.find('c:y', NS).get('val'))
        pw, ph = W * float(ml.find('c:w', NS).get('val')), H * float(ml.find('c:h', NS).get('val'))
    else: px_, py_, pw, ph = X + W * 0.06, Y + H * 0.08, W * 0.88, H * 0.80
    sers = []
    for k, se in enumerate(ct.findall('c:ser', NS)):
        sp = se.find('c:spPr', NS); col = fill_of(ctx, sp) if sp is not None else None
        if col is None and sp is not None and sp.find('a:ln/a:solidFill', NS) is not None: col = colour(ctx, sp.find('a:ln/a:solidFill', NS))
        dpts = {int(d.find('c:idx', NS).get('val')): fill_of(ctx, d.find('c:spPr', NS)) for d in se.findall('c:dPt', NS) if d.find('c:spPr', NS) is not None}
        vals = [_num(v) for v in _cache(se.find('c:val', NS))]
        fmt = se.find('c:val//c:formatCode', NS); fmt = fmt.text if fmt is not None else ''
        sers.append({'cats': _cache(se.find('c:cat', NS)), 'vals': vals, 'col': (col or (accents[k % 6], 1))[0], 'dpts': dpts, 'fmt': fmt,
                     'labels': bool(se.find('c:dLbls/c:showVal[@val="1"]', NS) is not None or ct.find('c:dLbls/c:showVal[@val="1"]', NS) is not None),
                     'pct': bool(se.find('c:dLbls/c:showPercent[@val="1"]', NS) is not None)})
    if not sers: return ''
    dl = ct.find('.//c:dLbls/c:txPr//a:defRPr', NS)   # the data labels' own size, weight and colour
    lpx = (int(dl.get('sz')) / 100 * 96 / 72) if dl is not None and dl.get('sz') else fpx
    lcol = colour(ctx, dl.find('a:solidFill', NS))[0] if dl is not None and dl.find('a:solidFill', NS) is not None else tcol
    lbold = dl is not None and dl.get('b') == '1'
    lab = lambda x, y, t, anchor='middle', size=None, fill=None, bold=False: (f'<text x="{x:.2f}" y="{y:.2f}" text-anchor="{anchor}" font-family="Inter" font-size="{size or fpx:.1f}"'   # noqa: E731
                                                                          + (' font-weight="700"' if bold else '') + f' fill="{fill or tcol}">{esc(t)}</text>')
    if kind in ('pieChart', 'pie3DChart', 'doughnutChart'):
        se = sers[0]; vals = [max(0.0, v or 0) for v in se['vals']]; tot = sum(vals) or 1
        cx, cy, r = px_ + pw / 2, py_ + ph / 2, min(pw, ph) / 2
        hole = (int(ct.find('c:holeSize', NS).get('val')) / 100 if ct.find('c:holeSize', NS) is not None else 0.5) if kind == 'doughnutChart' else 0
        a0 = (int(ct.find('c:firstSliceAng', NS).get('val')) if ct.find('c:firstSliceAng', NS) is not None else 0) - 90
        import math
        for i, v in enumerate(vals):
            if v <= 0: continue
            a1 = a0 + 360 * v / tot; big = 1 if a1 - a0 > 180 else 0
            c = (se['dpts'].get(i) or (accents[i % 6], 1))[0]
            p = lambda a, rr: (cx + rr * math.cos(math.radians(a)), cy + rr * math.sin(math.radians(a)))   # noqa: E731
            (x1, y1), (x2, y2) = p(a0, r), p(min(a1, a0 + 359.99), r)
            if hole:
                (x3, y3), (x4, y4) = p(min(a1, a0 + 359.99), r * hole), p(a0, r * hole)
                d = f'M{x1:.2f} {y1:.2f}A{r:.2f} {r:.2f} 0 {big} 1 {x2:.2f} {y2:.2f}L{x3:.2f} {y3:.2f}A{r * hole:.2f} {r * hole:.2f} 0 {big} 0 {x4:.2f} {y4:.2f}Z'
            else: d = f'M{cx:.2f} {cy:.2f}L{x1:.2f} {y1:.2f}A{r:.2f} {r:.2f} 0 {big} 1 {x2:.2f} {y2:.2f}Z'
            out.append(f'<path d="{d}" fill="{c}"/>')
            if se['labels'] or se['pct']:
                mx, my = p((a0 + a1) / 2, r * (1 + hole) / 2)
                out.append(lab(mx, my + lpx * 0.35, (f'{v / tot * 100:.0f}%' if se['pct'] else _fmt(v, se['fmt'])), size=lpx, fill=lcol, bold=lbold))
            a0 = a1
        return '<g>' + ''.join(out) + '</g>'
    cats = max((s_['cats'] for s_ in sers), key=len) or [str(i + 1) for i in range(max(len(s_['vals']) for s_ in sers))]
    n = max(1, max(len(cats), max(len(s_['vals']) for s_ in sers)))
    grouping = (ct.find('c:grouping', NS).get('val') if ct.find('c:grouping', NS) is not None else 'clustered')
    stacked = grouping in ('stacked', 'percentStacked')
    if grouping == 'percentStacked':
        tots = [sum(abs(s_['vals'][i] or 0) for s_ in sers if i < len(s_['vals'])) or 1 for i in range(n)]
        for s_ in sers: s_['vals'] = [(v or 0) / tots[i] for i, v in enumerate(s_['vals'])]
    tops = [sum(max(0, s_['vals'][i] or 0) for s_ in sers if i < len(s_['vals'])) for i in range(n)] if stacked else [v or 0 for s_ in sers for v in s_['vals']]
    vmax = max([0.0] + tops); vmin = min([0.0] + [v or 0 for s_ in sers for v in s_['vals']])
    sc = plot.find('c:valAx/c:scaling', NS)   # the value axis' own range when the chart sets one (a trend line is not squashed at the top)
    if sc is not None:
        if sc.find('c:min', NS) is not None: vmin = float(sc.find('c:min', NS).get('val'))
        if sc.find('c:max', NS) is not None: vmax = float(sc.find('c:max', NS).get('val'))
    elif kind in ('lineChart', 'line3DChart') and vmin >= 0 and tops:
        lo = min(v for s_ in sers for v in s_['vals'] if v is not None); vmin = max(0.0, lo - (vmax - lo) * 0.25) if vmax > lo else 0.0
    span = (vmax - vmin) or 1
    horiz = kind.startswith('bar') and (ct.find('c:barDir', NS) is not None and ct.find('c:barDir', NS).get('val') == 'bar')
    gap = (int(ct.find('c:gapWidth', NS).get('val')) / 100) if ct.find('c:gapWidth', NS) is not None else 1.5
    labw = pw * 0.18 if horiz else 0; labh = 0 if horiz else fpx * 1.8
    ax, ay, aw, ah = px_ + labw, py_, pw - labw, ph - labh
    val_xy = (lambda v: ax + aw * ((v - vmin) / span)) if horiz else (lambda v: ay + ah * (1 - (v - vmin) / span))
    out.append(f'<path d="M{ax:.2f} {val_xy(0) if not horiz else ay:.2f}' + (f'H{ax + aw:.2f}' if not horiz else f'M{val_xy(0):.2f} {ay:.2f}V{ay + ah:.2f}') + '" stroke="#BFBFBF" stroke-width="1" fill="none"/>')
    band = (ah if horiz else aw) / n
    for i in range(n):
        c0 = (ay if horiz else ax) + band * i
        if i < len(cats) and cats[i] is not None:
            out.append(lab(ax - 6, c0 + band / 2 + fpx * 0.35, str(cats[i])[:28], 'end') if horiz else lab(c0 + band / 2, ay + ah + fpx * 1.3, str(cats[i])[:20]))
    if kind.startswith('bar'):
        m = 1 if stacked else len(sers); bw = band / (m + gap); acc = [0.0] * n
        for k, s_ in enumerate(sers):
            for i, v in enumerate(s_['vals'][:n]):
                if v is None: continue
                b0 = acc[i] if stacked else 0.0; b1 = b0 + v
                c0 = (ay if horiz else ax) + band * i + bw * gap / 2 + (0 if stacked else bw * k)
                col = (s_['dpts'].get(i) or (s_['col'], 1))[0]
                if horiz: x0, x1 = sorted((val_xy(b0), val_xy(b1))); out.append(f'<rect x="{x0:.2f}" y="{c0:.2f}" width="{max(0.5, x1 - x0):.2f}" height="{bw:.2f}" fill="{col}"/>')
                else: y0, y1 = sorted((val_xy(b1), val_xy(b0))); out.append(f'<rect x="{c0:.2f}" y="{y0:.2f}" width="{bw:.2f}" height="{max(0.5, y1 - y0):.2f}" fill="{col}"/>')
                if s_['labels'] and not stacked:
                    out.append(lab(val_xy(b1) + 4, c0 + bw / 2 + fpx * 0.35, _fmt(v, s_['fmt']), 'start') if horiz else lab(c0 + bw / 2, val_xy(b1) - 4, _fmt(v, s_['fmt'])))
                if stacked: acc[i] = b1
        return '<g>' + ''.join(out) + '</g>'
    for k, s_ in enumerate(sers):   # line, area
        ptsxy = [(ax + band * (i + 0.5), val_xy(v)) for i, v in enumerate(s_['vals'][:n]) if v is not None]
        if not ptsxy: continue
        d = 'M' + ' L'.join(f'{x_:.2f} {y_:.2f}' for x_, y_ in ptsxy)
        if kind == 'areaChart': out.append(f'<path d="{d} L{ptsxy[-1][0]:.2f} {val_xy(0):.2f} L{ptsxy[0][0]:.2f} {val_xy(0):.2f}Z" fill="{s_["col"]}" fill-opacity="0.35"/>')
        out.append(f'<path d="{d}" fill="none" stroke="{s_["col"]}" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>')
        if s_['labels']: out += [lab(x_, y_ - 6, _fmt(v, s_['fmt'])) for (x_, y_), v in zip(ptsxy, [v for v in s_['vals'][:n] if v is not None])]
    return '<g>' + ''.join(out) + '</g>'


def _tbl_style(ctx, tbl):
    """v6.32 the table's style from the deck's tableStyles.xml (PowerPoint's own "Medium Style 2 - Accent 1" and the rest) and its
    header / banding switches."""
    if not hasattr(ctx, 'tbl_styles'):
        ctx.tbl_styles = {}
        try:
            from pptx.opc.constants import RELATIONSHIP_TYPE as RT
            root = etree.fromstring(ctx.prs.part.part_related_by(RT.TABLE_STYLES).blob)
            for st in root.findall('a:tblStyle', NS): ctx.tbl_styles[st.get('styleId')] = st
            ctx.tbl_styles['__def__'] = ctx.tbl_styles.get(root.get('def'))
        except Exception: pass  # noqa: BLE001  no styles part: the cells' own fills only
    pr = tbl.find('a:tblPr', NS); sid = pr.find('a:tableStyleId', NS) if pr is not None else None
    st = ctx.tbl_styles.get(sid.text.strip()) if sid is not None and sid.text else ctx.tbl_styles.get('__def__')
    flags = {k: pr is not None and pr.get(k) in ('1', 'true') for k in ('firstRow', 'lastRow', 'firstCol', 'lastCol', 'bandRow', 'bandCol')}
    return st, flags


def _cell_style(ctx, st, fl, r, c, nr, nc):
    """(fill, text colour, bold) a table style gives cell (r, c) — PowerPoint's order: whole table, bands, columns, rows."""
    if st is None: return None, None, None
    parts = ['wholeTbl']
    head, foot = fl['firstRow'] and r == 0, fl['lastRow'] and r == nr - 1
    if fl['bandRow'] and not head and not foot: parts.append('band1H' if (r - (1 if fl['firstRow'] else 0)) % 2 == 0 else 'band2H')
    if fl['bandCol'] and not (fl['firstCol'] and c == 0) and not (fl['lastCol'] and c == nc - 1): parts.append('band1V' if (c - (1 if fl['firstCol'] else 0)) % 2 == 0 else 'band2V')
    if fl['lastCol'] and c == nc - 1: parts.append('lastCol')
    if fl['firstCol'] and c == 0: parts.append('firstCol')
    if foot: parts.append('lastRow')
    if head: parts.append('firstRow')
    fill = col = bold = None
    for name in parts:
        el = st.find('a:' + name, NS)
        if el is None: continue
        f = el.find('a:tcStyle/a:fill', NS)
        if f is not None:
            fill = 'none' if f.find('a:noFill', NS) is not None else (colour(ctx, f.find('a:solidFill', NS)) if f.find('a:solidFill', NS) is not None else fill)
        tx = el.find('a:tcTxStyle', NS)
        if tx is not None:
            col = colour(ctx, tx) or col
            if tx.get('b') in ('on', 'off'): bold = tx.get('b') == 'on'
    return fill, col, bold


def table(ctx, gf, tbl, x, part):
    X, Y = ctx.px(x[0]), ctx.px(x[1])
    cols = [ctx.px(int(c.get('w'))) for c in tbl.findall('a:tblGrid/a:gridCol', NS)]
    out = []; yy = Y
    st, fl = _tbl_style(ctx, tbl); rows = tbl.findall('a:tr', NS); hs = [ctx.px(int(tr.get('h', '0'))) for tr in rows]
    for ri, tr in enumerate(rows):
        rh = hs[ri]; xx = X; ci = 0
        for tc in tr.findall('a:tc', NS):
            span = int(tc.get('gridSpan', '1'))
            if tc.get('hMerge') == '1': continue   # the column a cell to its left spans: already counted by that cell's gridSpan
            if tc.get('vMerge') == '1': xx += sum(cols[ci:ci + span]); ci += span; continue   # under a cell that spans rows: its column, drawn above
            cw = sum(cols[ci:ci + span]); tcPr = tc.find('a:tcPr', NS)
            rh = sum(hs[ri:ri + max(1, int(tc.get('rowSpan', '1')))])
            sf, ctx.cell_color, ctx.cell_bold = _cell_style(ctx, st, fl, ri, ci, len(rows), len(cols))
            own = tcPr is not None and any(tcPr.find(t, NS) is not None for t in ('a:noFill', 'a:solidFill', 'a:gradFill', 'a:blipFill', 'a:pattFill'))
            f = fill_of(ctx, tcPr) if own else (sf if sf and sf != 'none' else None)
            if f: out.append(f'<rect x="{xx:.2f}" y="{yy:.2f}" width="{cw:.2f}" height="{rh:.2f}" fill="{f[0]}"' + (f' fill-opacity="{f[1]:.2f}"' if f[1] < 1 else '') + '/>')
            lnB = tcPr.find('a:lnB', NS) if tcPr is not None else None
            if lnB is not None and lnB.find('a:solidFill', NS) is not None:
                c = colour(ctx, lnB.find('a:solidFill', NS)); out.append(f'<path d="M{xx:.2f} {yy + rh:.2f} h{cw:.2f}" stroke="{c[0]}" stroke-width="1"/>')
            body = text_html(ctx, tc, tc.find('a:txBody', NS), cw, rh, origin=(xx, yy))
            if body: out.append(f'<g transform="translate({xx:.2f} {yy:.2f})">{body}</g>')
            xx += cw; ci += span
        yy += hs[ri]
    ctx.cell_color = ctx.cell_bold = None
    return ''.join(out)


def background(ctx):
    for owner in (ctx.slide, ctx.layout, ctx.master):
        bg = owner._element.find('p:cSld/p:bg', NS)
        if bg is None: continue
        bp = bg.find('p:bgPr', NS)
        if bp is not None:
            bf = bp.find('a:blipFill/a:blip', NS)
            if bf is not None:
                href = _image(owner.part, bf.get(R + 'embed'), W_PX, ctx.H)
                if href: return f'<image x="0" y="0" width="{W_PX:.0f}" height="{ctx.H:.0f}" preserveAspectRatio="none" href="{href}"/>'
            f = fill_of(ctx, bp)
            if f: return f'<rect width="{W_PX:.0f}" height="{ctx.H:.0f}" fill="{f[0]}"/>'
        br = bg.find('p:bgRef', NS)
        if br is not None:
            c = colour(ctx, br)
            if c: return f'<rect width="{W_PX:.0f}" height="{ctx.H:.0f}" fill="{c[0]}"/>'
    return f'<rect width="{W_PX:.0f}" height="{ctx.H:.0f}" fill="#FFFFFF"/>'


def _not_placeholder(el):
    return etree.QName(el).localname in ('sp', 'cxnSp', 'pic', 'grpSp', 'graphicFrame', 'AlternateContent') and el.find('.//p:nvPr/p:ph', NS) is None


def _full_bleed(ctx, el):
    """A picture of the layout or master that covers the whole slide: the template's background texture."""
    if etree.QName(el).localname != 'pic': return False
    x = _xfrm(el.find('p:spPr/a:xfrm', NS))
    return bool(x) and ctx.px(x[2]) >= 0.95 * W_PX and ctx.px(x[3]) >= 0.95 * ctx.H


def render(prs, slide, drop=None, background_fill=True, ids=False, text='html', report=None):
    """The slide as one SVG (viewBox 1280 × 720 for 16:9). background_fill=False: no background (the page behind shows through — the
    twin's own slide colour), the logo, footer and every shape still drawn. ids=True: each of the slide's own shapes in a
    <g data-sid="…"> (the slide editor moves it while it is dragged). text='svg' (v6.33): the words drawn as SVG text, for a
    picture without a browser; report (a dict) then gets every text line's box ('lines', slide px) and words too wide for their box."""
    ctx = Ctx(prs, slide); ctx.text = text; body = [background(ctx)] if background_fill else []
    if report is not None: ctx.lines, ctx.wide, ctx.tf = [], [], (1.0, 1.0, 0.0, 0.0, False)
    show_master = ctx.layout._element.get('showMasterSp', '1') != '0' and slide._element.get('showMasterSp', '1') != '0'
    if show_master:
        body += [shape(ctx, el, ctx.master.part, None) for el in ctx.master.shapes._spTree if _not_placeholder(el) and (background_fill or not _full_bleed(ctx, el))]
    if slide._element.get('showMasterSp', '1') != '0':
        body += [shape(ctx, el, ctx.layout.part, None) for el in ctx.layout.shapes._spTree if _not_placeholder(el) and (background_fill or not _full_bleed(ctx, el))]
    for el in slide.shapes._spTree:
        if etree.QName(el).localname not in ('sp', 'cxnSp', 'pic', 'grpSp', 'graphicFrame', 'AlternateContent'): continue
        g = shape(ctx, el, slide.part, drop); nv = el.find('.//p:cNvPr', NS) if ids else None
        body.append(f'<g data-sid="{nv.get("id")}">{g}</g>' if nv is not None and g else g)
    if report is not None: report.update(lines=ctx.lines, wide=ctx.wide, w=W_PX, h=ctx.H)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 {W_PX:.0f} {ctx.H:.0f}">'
            + (f'<defs>{"".join(ctx.defs)}</defs>' if ctx.defs else '') + ''.join(body) + '</svg>')


def picture(prs, slide, zoom=1.0):
    """v6.33 The slide as a PNG (bytes) with its text lines (for the layout check) — drawn by resvg with the template's stand-in fonts;
    no browser, no LibreOffice. None when resvg is not installed."""
    rep = {}; svg = render(prs, slide, text='svg', report=rep)
    try:
        import resvg_py
    except Exception:
        return None, rep
    out = resvg_py.svg_to_bytes(svg_string=svg, zoom=float(zoom), font_files=font_files(), font_family='Inter', sans_serif_family='Inter', serif_family='Playfair Display', background='#FFFFFF')
    return (bytes(out) if not isinstance(out, (bytes, bytearray)) else out), rep


def deck_pictures(pptx_path, out_dir, zoom=1.0, slides=None):
    """Every slide as slide-N.png in out_dir, and [(n, w, h, [(x0, y0, x1, y1, text, 0)])] — the shape tools/look.py checks (overlapping
    text, text off the slide, dense slides), the same as a LibreOffice render gave it."""
    from pptx import Presentation
    prs = Presentation(pptx_path); os.makedirs(out_dir, exist_ok=True); pages, pngs, wide = [], [], []
    for n, sl in enumerate(prs.slides, 1):
        if slides and n not in slides: continue
        png, rep = picture(prs, sl, zoom)
        if png is None: return None, None, None
        pth = os.path.join(out_dir, f'slide-{n}.png'); open(pth, 'wb').write(png); pngs.append(pth)
        pages.append((n, rep['w'], rep['h'], [(x0, y0, x1, y1, t, 0) for x0, y0, x1, y1, t in rep['lines']]))
        wide += [(n, wd) for wd in rep['wide']]
    return pngs, pages, wide


if __name__ == '__main__':
    from pptx import Presentation
    prs = Presentation(sys.argv[1]); n = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    sys.stdout.write(render(prs, prs.slides[n - 1]))
