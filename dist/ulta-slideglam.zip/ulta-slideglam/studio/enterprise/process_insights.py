#!/usr/bin/env python3
"""Process insights from an event log (v6.31) — what really happens in order-to-cash, procure-to-pay, returns or any process,
from the system's own timestamps. No model, no LibreOffice.

    python enterprise/process_insights.py events.xlsx --out Out/O2C [--title "Order-to-cash"] [--case Order --activity Step --time When]
            [--team Team] [--by Region] [--reference "Order created > Delivery created > Goods issued > Invoice created"] [--target-days 5]
    python enterprise/process_insights.py --sample order-to-cash --out Out/O2C          # a realistic sample log, then its insights

An event log is one row per step that happened to a case: the case (order, PO, return, ticket), the step (activity) and when.
Optional: who did it (team, role, user) and a case attribute (region, channel, plant, category). The columns are found by their
names and values; --case / --activity / --time / --team / --by name them when the guess is wrong. A date column and a separate
time-of-day column (as SAP extracts have) are combined.

Measures: cases and events; the variants (paths) and their share; cycle time per case (median, 90th percentile); every hand-off
(step → next step) with how often and how long it waits; rework (a step done twice); deviations from the main path — the
reference you give, else the most common path: a skipped step, an extra step, steps out of order; cycle time and conformance by
the attribute; with --target-days, the share of cases finished in time.

Files: <Out>.pptx   the insights on the template — KPI cards, the main path as a pipeline, who does what (swimlane), where cases
                    flow (Sankey), the slowest hand-offs, the variants, the deviations, by attribute, what to look at
       <Out>.xlsx   Summary, Variants, Hand-offs, Cases, Steps, Deviations (filterable tables) — the numbers behind every slide
       <Out>-insights.md   the same story in words
"""
import argparse, collections, datetime, os, random, re, statistics, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402

CASE_RX = re.compile(r'case|order|document|\bdoc\b|ticket|incident|\bpo\b|purchase|invoice|delivery|shipment|request|return|claim|\bid\b|number|no\.?$|vbeln|ebeln|belnr', re.I)
ACT_RX = re.compile(r'activity|step|event|status|stage|action|task|milestone|transaction|operation|process', re.I)
TIME_RX = re.compile(r'time|date|when|timestamp|\bat$|created|start|posted|erdat|budat|cpudt', re.I)
TEAM_RX = re.compile(r'team|role|resource|user|owner|department|dept|group|performer|agent|\bby$|ernam|usnam', re.I)


# ------------------------------------------------------------------------------------------------ the log
def guess(header, rows, a):
    n = len(rows)
    col = lambda k: [r[k] for r in rows]
    distinct = {k: len({str(v).strip() for v in col(k) if v not in (None, '')}) for k in range(len(header))}
    filled = {k: sum(1 for v in col(k) if v not in (None, '')) for k in range(len(header))}
    by_name = lambda name: next((k for k, h in enumerate(header) if h.strip().lower() == str(name).strip().lower()), None)
    def need(name, what):
        k = by_name(name)
        if k is None: raise ValueError(f'no column called "{name}" for the {what} (the columns are: {", ".join(header)})')
        return k
    day_first = False
    def dt_share(k):
        vals = [v for v in col(k)[:400] if v not in (None, '')]
        return sum(1 for v in vals if C.to_datetime(v) is not None) / max(1, len(vals)) if vals else 0
    t = need(a.time, 'time') if a.time else None
    if t is None:
        cands = sorted(((dt_share(k) + (0.3 if TIME_RX.search(header[k]) else 0), k) for k in range(len(header)) if filled[k] >= 0.8 * n), reverse=True)
        t = next((k for s, k in cands if s >= 0.9), None)
        if t is None: raise ValueError('no column of dates and times found — name it with "Time column"')
    tod = next((k for k in range(len(header)) if k != t and filled[k] >= 0.8 * n and (all(C.is_time_of_day(v) for v in col(k)[:200] if v not in (None, ''))
                or (re.search(r'time|zeit|erzet|uzeit|cputm|hour', header[k], re.I) and all(re.fullmatch(r'\d{6}', str(v).strip()) for v in col(k)[:200] if v not in (None, ''))))), None)
    vals = [str(v) for v in col(t)[:400] if isinstance(v, str)]
    day_first = any(re.match(r'^(1[3-9]|2\d|3[01])/\d{1,2}/\d{2,4}', v) for v in vals)
    c = need(a.case, 'case') if a.case else None
    if c is None:
        cands = []
        for k in range(len(header)):
            if k == t or k == tod or not distinct[k]: continue
            per = filled[k] / distinct[k]
            if 1.3 <= per <= 200 and distinct[k] >= 3: cands.append(((2 if CASE_RX.search(header[k]) else 0) + min(distinct[k], 1000) / 1000, k))
        if not cands: raise ValueError('no case column found (an order, document or ticket number repeated on each step) — name it with "Case column"')
        c = max(cands)[1]
    act = need(a.activity, 'activity') if a.activity else None
    if act is None:
        cands = [((2 if ACT_RX.search(header[k]) else 0) - abs(distinct[k] - 8) / 40, k) for k in range(len(header)) if k not in (t, c, tod) and 2 <= distinct[k] <= 80]
        if not cands: raise ValueError('no step column found (the activity: "Order created", "Goods issued" ...) — name it with "Activity column"')
        act = max(cands)[1]
    team = need(a.team, 'team') if a.team else next((k for k in range(len(header)) if k not in (t, c, act, tod) and TEAM_RX.search(header[k]) and 2 <= distinct[k] <= 40), None)
    by = need(a.by, 'attribute') if a.by else None
    if by is None:   # a case attribute: the same value on every step of a case, 2 to 20 values
        for k in range(len(header)):
            if k in (t, c, act, tod, team) or not 2 <= distinct[k] <= 20: continue
            per_case = collections.defaultdict(set)
            for r in rows[:3000]:
                if r[k] not in (None, ''): per_case[str(r[c])].add(str(r[k]))
            if per_case and sum(1 for s in per_case.values() if len(s) == 1) >= 0.95 * len(per_case): by = k; break
    return dict(case=c, activity=act, time=t, tod=tod, team=team, by=by, day_first=day_first)


def events(header, rows, g):
    """{case: [(time, activity, team, attribute, order)]} sorted by time; and how many rows were set aside (no case, step or time)."""
    out = collections.defaultdict(list); skipped = 0
    for i, r in enumerate(rows):
        cid, act = r[g['case']], r[g['activity']]
        ts = C.to_datetime(r[g['time']], g['day_first'])
        if ts is not None and g['tod'] is not None:
            tm = C.time_of_day(r[g['tod']])
            if tm and ts.hour == ts.minute == 0: ts = datetime.datetime.combine(ts.date(), tm)
        if cid in (None, '') or act in (None, '') or ts is None: skipped += 1; continue
        out[str(cid).strip()].append((ts, str(act).strip(), str(r[g['team']]).strip() if g['team'] is not None and r[g['team']] not in (None, '') else '',
                                      str(r[g['by']]).strip() if g['by'] is not None and r[g['by']] not in (None, '') else '', i))
    for k in out: out[k].sort(key=lambda e: (e[0], e[4]))
    return out, skipped


def match_reference(ref, acts):
    """'Order created > Delivery > Invoice' → the log's own step names (exact, then by words)."""
    names = [x.strip() for x in re.split(r'\s*(?:>|→|->|,|;|\n)\s*', ref or '') if x.strip()]
    low = {a.lower(): a for a in acts}; out, miss = [], []
    words = lambda s: set(re.findall(r'[a-z0-9]+', s.lower()))
    for nm in names:
        if nm.lower() in low: out.append(low[nm.lower()]); continue
        best = max(acts, key=lambda a: len(words(a) & words(nm)) / max(1, len(words(nm))), default=None)
        if best and words(best) & words(nm): out.append(best)
        else: miss.append(nm)
    return out, miss


def p(values, q):
    v = sorted(values)
    if not v: return None
    k = (len(v) - 1) * q; f = int(k)
    return v[f] + (v[min(f + 1, len(v) - 1)] - v[f]) * (k - f)


def analyse(ev, reference=None, target=None):
    days = lambda a, b: (b - a).total_seconds() / 86400
    cases = {}
    for cid, es in ev.items():
        trace = [e[1] for e in es]
        cases[cid] = {'trace': trace, 'start': es[0][0], 'end': es[-1][0], 'days': days(es[0][0], es[-1][0]), 'attr': next((e[3] for e in es if e[3]), ''),
                      'rework': len(set(trace)) < len(trace), 'events': es}
    var = collections.Counter(tuple(c['trace']) for c in cases.values())
    variants = []
    for k, (tr, n) in enumerate(var.most_common(), 1):
        ds = [c['days'] for c in cases.values() if tuple(c['trace']) == tr]
        variants.append({'id': f'V{k}', 'path': list(tr), 'cases': n, 'share': n / len(cases), 'median': statistics.median(ds), 'mean': statistics.mean(ds)})
    vid = {tuple(v['path']): v['id'] for v in variants}
    for c in cases.values(): c['variant'] = vid[tuple(c['trace'])]
    acts = sorted({a for c in cases.values() for a in c['trace']})
    if reference:
        main, missing = match_reference(reference, acts); ref_given = True
    else:
        main = list(dict.fromkeys(variants[0]['path'])); missing = []; ref_given = False
    hand = collections.defaultdict(list)
    for c in cases.values():
        es = c['events']
        for a_, b_ in zip(es, es[1:]): hand[(a_[1], b_[1])].append(days(a_[0], b_[0]))
    handoffs = sorted(({'from': a_, 'to': b_, 'count': len(w), 'median': statistics.median(w), 'p90': p(w, 0.9), 'total': sum(w)} for (a_, b_), w in hand.items()),
                      key=lambda h: -h['total'])
    steps = []
    for a_ in acts:
        cs = [c for c in cases.values() if a_ in c['trace']]
        steps.append({'step': a_, 'events': sum(c['trace'].count(a_) for c in cs), 'cases': len(cs), 'share': len(cs) / len(cases),
                      'repeated': sum(1 for c in cs if c['trace'].count(a_) > 1),
                      'team': collections.Counter(e[2] for c in cs for e in c['events'] if e[1] == a_ and e[2]).most_common(1)[0][0]
                      if any(e[2] for c in cs for e in c['events'] if e[1] == a_) else ''})
    dev = []; counts = collections.Counter()
    for cid, c in cases.items():
        tr = c['trace']; kinds = []
        skipped = [s for s in main if s not in tr]
        extra = sorted({s for s in tr if s not in main})
        seen = [s for s in dict.fromkeys(tr) if s in main]
        order = seen != [s for s in main if s in seen]
        rep = sorted({s for s in tr if tr.count(s) > 1})
        if skipped: kinds.append('skipped'); dev.append((cid, 'Skipped a step', ', '.join(skipped)))
        if extra: kinds.append('extra'); dev.append((cid, 'Extra step', ', '.join(extra)))
        if order: kinds.append('order'); dev.append((cid, 'Out of order', ' → '.join(dict.fromkeys(tr))))
        if rep: kinds.append('repeat'); dev.append((cid, 'Repeated a step', ', '.join(rep)))
        c['conform'] = not kinds; c['deviations'] = kinds
        for k in kinds: counts[k] += 1
    N = len(cases); ds = [c['days'] for c in cases.values()]
    by = collections.defaultdict(list)
    for c in cases.values():
        if c['attr']: by[c['attr']].append(c)
    by_attr = sorted(({'value': k, 'cases': len(v), 'median': statistics.median(x['days'] for x in v), 'conform': sum(1 for x in v if x['conform']) / len(v)}
                      for k, v in by.items()), key=lambda x: -x['median'])
    return {'cases': cases, 'variants': variants, 'handoffs': handoffs, 'steps': steps, 'main': main, 'missing_ref': missing, 'ref_given': ref_given,
            'deviations': dev, 'dev_counts': counts, 'N': N, 'events': sum(len(c['trace']) for c in cases.values()), 'median': statistics.median(ds), 'p90': p(ds, 0.9),
            'rework': sum(1 for c in cases.values() if c['rework']) / N, 'conform': sum(1 for c in cases.values() if c['conform']) / N,
            'target': target, 'on_time': (sum(1 for d in ds if d <= target) / N) if target else None, 'by_attr': by_attr,
            'first': min(c['start'] for c in cases.values()), 'last': max(c['end'] for c in cases.values())}


# ------------------------------------------------------------------------------------------------ the story
def noun(header, g, n):
    """'orders' / 'POs' / 'cases' — what a case is, from the case column's name."""
    h = header[g['case']].lower()
    for rx, w in ((r'sales order|order|vbeln', 'orders'), (r'purchase|\bpo\b|ebeln', 'POs'), (r'return|claim', 'returns'), (r'ticket|incident', 'tickets'),
                  (r'invoice|belnr', 'invoices'), (r'delivery|shipment', 'deliveries'), (r'request', 'requests')):
        if re.search(rx, h): return w if n != 1 else w[:-1]
    return 'cases' if n != 1 else 'case'


def plural(n, w):
    return f'{C.num(n)} {w}' + ('' if n == 1 else 's')


def cap(w):
    return w[:1].upper() + w[1:]


def fit(*options, n=58):
    """The first headline that stays on one line (the template's headline holds about 58 characters at its size)."""
    return next((o for o in options if len(o) <= n), options[-1])


def storyboard(A, title, header, g, attr_name):
    N, unit_n = A['N'], noun(header, g, A['N'])
    main = A['main']; lines = [f'# {title}', '']
    span = f"{A['first']:%b %-d, %Y} – {A['last']:%b %-d, %Y}" if os.name != 'nt' else f"{A['first']:%b %d, %Y} – {A['last']:%b %d, %Y}"
    path_word = 'reference' if A['ref_given'] else 'main'
    lines += ['## ' + fit(f"{C.num(N)} {unit_n}, {plural(len(A['variants']), 'path')}: {C.pct(A['conform'])} follow the {path_word} path",
                          f"{C.pct(A['conform'])} of {C.num(N)} {unit_n} follow the {path_word} path"), 'Layout: kpi cards',
              f"- {cap(unit_n)}: {C.num(N)}", f"- Median cycle time: {C.duration(A['median'], 'days')}", f"- On the {path_word} path: {C.pct(A['conform'])}",
              (f"- Within {C.num(A['target'], 0)} days: {C.pct(A['on_time'])}" if A['on_time'] is not None else f"- Rework: {C.pct(A['rework'])}")]
    lines += ['', f'Narration: {span}; {C.num(A["events"])} events. 90% of {unit_n} finish within {C.duration(A["p90"], "days")}; rework (a step done twice) in {C.pct(A["rework"])}.', '']
    reach = {s['step']: s['cases'] for s in A['steps']}
    lines += ['## ' + fit(f"The {path_word} path: {len(main)} steps, {C.pct(reach.get(main[-1], 0) / N)} reach the last", f"The {path_word} path in {len(main)} steps"), 'Layout: process pipeline']
    lines += [f"- {s}: {C.num(reach.get(s, 0))} ({C.pct(reach.get(s, 0) / N)})" for s in main[:8]] + ['']
    team = {s['step']: s['team'] for s in A['steps'] if s['team']}
    if team and len({team.get(s) for s in main if team.get(s)}) >= 2 and all(team.get(s) for s in main):
        hand = sum(1 for a_, b_ in zip(main, main[1:]) if team[a_] != team[b_])
        nteams = len({team[s] for s in main})
        lines += [f"## Who does what: {hand} hand-offs between {nteams} teams", 'Layout: swimlane ' + ('handoffs' if nteams <= 5 and len(main) <= 7 else 'lanes')]
        lines += [f'- {team[s]}: {s}' for s in main[:10]] + ['']
    flows = branches(A)
    if len(flows) >= 3:   # where cases leave the main path: one split, two stages (a Sankey needs three flows)
        src = flows[0]['from']; nxt = main[main.index(src) + 1] if src in main and main.index(src) + 1 < len(main) else None
        off = sum(h['count'] for h in flows if h['to'] != nxt); tot = sum(h['count'] for h in flows)   # anything but the next main-path step: a detour, a skip, out of order
        lines += ['## ' + fit(f"After {src}, {C.pct(off / max(1, tot))} of {unit_n} leave the {path_word} path", f"Where {unit_n} leave the {path_word} path"), 'Layout: sankey']
        lines += [f"- {h['from']} → {h['to']}: {h['count']}" for h in flows] + ['']
    slow = sorted([h for h in A['handoffs'] if h['count'] >= max(3, 0.02 * N) and h['from'] != h['to']], key=lambda h: -h['median'])[:6]
    if len(slow) >= 3:
        u = 'hours' if slow[0]['median'] < 2 else 'days'
        share = slow[0]['total'] / max(1e-9, sum(h['total'] for h in A['handoffs']))
        lines += ['## ' + fit(f"The longest wait: {slow[0]['from']} → {slow[0]['to']}, {C.duration(slow[0]['median'], u)}", f"Longest wait: before {slow[0]['to']}, {C.duration(slow[0]['median'], u)}",
                              f"The longest wait is {C.duration(slow[0]['median'], u)} (median)"), 'Layout: ranking']
        lines += [f"- {h['from']} → {h['to']}: {C.duration(h['median'], u)}" for h in slow]
        lines += ['', f"Narration: this hand-off holds {C.pct(share)} of all waiting time across the {unit_n}.", '']
    top = A['variants'][:3]   # the template's table slide holds three rows: the rest are in the workbook
    lines += [f"## {plural(len(A['variants']), 'path')}; the top {len(top)} cover {C.pct(sum(v['cases'] for v in top) / N)}", '',
              f"Narration: every path, with its {unit_n} and cycle times, is on the Variants sheet of the workbook.", '',
              '| Path | ' + cap(unit_n) + ' | Share | Median days | Steps |', '|---|---|---|---|---|']
    for v in top:
        steps_ = ' → '.join(v['path']); steps_ = steps_ if len(steps_) <= 90 else steps_[:87] + '…'
        lines.append(f"| {v['id']} | {C.num(v['cases'])} | {C.pct(v['share'])} | {v['median']:.1f} | {steps_} |")
    lines.append('')
    dc = A['dev_counts']
    if sum(dc.values()):
        lines += [f"## {C.pct(1 - A['conform'])} of {unit_n} leave the {'reference' if A['ref_given'] else 'main'} path", 'Layout: kpi cards',
                  f"- Skipped a step: {C.pct(dc['skipped'] / N)}", f"- Extra step: {C.pct(dc['extra'] / N)}", f"- Out of order: {C.pct(dc['order'] / N)}",
                  f"- Repeated a step: {C.pct(dc['repeat'] / N)}", '']
    if len(A['by_attr']) >= 2:
        b = A['by_attr']; u = 'hours' if b[0]['median'] < 2 else 'days'
        lines += ['## ' + fit(f"By {attr_name}: {b[0]['value']} slowest at {C.duration(b[0]['median'], u)}, {b[-1]['value']} {C.duration(b[-1]['median'], u)}",
                              f"By {attr_name}: {b[0]['value']} is slowest at {C.duration(b[0]['median'], u)}"), 'Layout: ranking']
        lines += [f"- {x['value']}: {C.duration(x['median'], u)}" for x in b[:10]] + ['']
    look = looks(A, unit_n, attr_name)
    if len(look) == 3:
        lines += ['## What to look at first', 'Layout: cards'] + [f'- {t}: {d}' for t, d in look] + ['']
    return '\n'.join(lines) + '\n', look


def branches(A, limit=6):
    """Where cases leave the main path: the main-path step that sends the most cases off it and every way out of it (3% of cases or more)
    - two stages, so no band has to cross a column of nodes. Where the detours go next is on the waits slide and in the workbook."""
    N = A['N']; main = set(A['main']); by_from = collections.defaultdict(list)
    for h in A['handoffs']:
        if h['from'] != h['to']: by_from[h['from']].append(h)
    splits = [(sum(h['count'] for h in hs if h['to'] not in main), s) for s, hs in by_from.items()
              if s in main and sum(1 for h in hs if h['count'] >= 0.03 * N) >= 2 and any(h['to'] not in main and h['count'] >= 0.03 * N for h in hs)]
    if not splits: return []
    s = max(splits)[1]
    return sorted((h for h in by_from[s] if h['count'] >= 0.03 * N), key=lambda h: -h['count'])[:limit]


def looks(A, unit_n, attr_name):
    """Three things to look at, each from the numbers: the hand-off that holds the most waiting, the most common deviation, the
    rework hotspot or the slowest attribute value."""
    out = []
    H = [h for h in A['handoffs'] if h['from'] != h['to']]
    if H:
        h = max(H, key=lambda x: x['total']); share = h['total'] / max(1e-9, sum(x['total'] for x in A['handoffs']))
        out.append(('The biggest wait', f"{h['from']} → {h['to']}: {C.pct(share)} of all waiting time, {C.duration(h['median'])} median over {C.num(h['count'])} hand-offs"))
    dc = A['dev_counts']
    if sum(dc.values()):
        k, n = max(dc.items(), key=lambda x: x[1]); what = {'skipped': 'skip a step', 'extra': 'take an extra step', 'order': 'run steps out of order', 'repeat': 'repeat a step'}[k]
        ex = collections.Counter(d[2] for d in A['deviations'] if d[1].lower().startswith({'skipped': 'skipped', 'extra': 'extra', 'order': 'out', 'repeat': 'repeated'}[k])).most_common(1)
        out.append(('The most common detour', f"{C.pct(n / A['N'])} of {unit_n} {what}" + (f" — most often {ex[0][0][:70]}" if ex and k != 'order' else '')))
    rep = sorted(A['steps'], key=lambda s: -s['repeated'])
    if rep and rep[0]['repeated']:
        out.append(('Rework', f"{rep[0]['step']} is done twice or more in {C.num(rep[0]['repeated'])} {unit_n} ({C.pct(rep[0]['repeated'] / A['N'])})"))
    elif len(A['by_attr']) >= 2:
        b = A['by_attr']; out.append((f'By {attr_name}', f"{b[0]['value']} takes {C.duration(b[0]['median'])} against {C.duration(b[-1]['median'])} in {b[-1]['value']}"))
    if len(out) < 3 and len(A['by_attr']) >= 2 and not any(t.startswith('By ') for t, _ in out):
        b = A['by_attr']; out.append((f'By {attr_name}', f"{b[0]['value']} takes {C.duration(b[0]['median'])} against {C.duration(b[-1]['median'])} in {b[-1]['value']}"))
    return out[:3]


def workbook(A, path, title, unit_n, attr_name, g, header):
    from openpyxl import Workbook
    wb = Workbook(); C.workbook_props(wb, title, 'Process insights from an event log')
    summ = [('Cases', A['N']), ('Events', A['events']), ('Paths (variants)', len(A['variants'])), ('Median cycle time (days)', round(A['median'], 2)),
            ('90th percentile cycle time (days)', round(A['p90'], 2)), ('On the ' + ('reference' if A['ref_given'] else 'main') + ' path', round(A['conform'], 4)),
            ('Rework (a step done twice)', round(A['rework'], 4)), ('First event', A['first']), ('Last event', A['last']),
            ('Reference path', ' > '.join(A['main'])), ('Columns read', f"case = {header[g['case']]}, step = {header[g['activity']]}, time = {header[g['time']]}"
             + (f" + {header[g['tod']]}" if g['tod'] is not None else '') + (f", team = {header[g['team']]}" if g['team'] is not None else '')
             + (f", {attr_name} = {header[g['by']]}" if g['by'] is not None else ''))]
    if A['on_time'] is not None: summ.insert(7, (f"Within {A['target']:g} days", round(A['on_time'], 4)))
    ws = C.sheet(wb, 'Summary', ['Measure', 'Value'], [list(x) for x in summ], widths={0: 38, 1: 70}, first=True,
                 note=f'{title} — process insights. Cycle time = first to last event of a case. Every number is from the event log; nothing is estimated.')
    for row in ws.iter_rows(min_row=4, max_row=3 + len(summ)):
        if isinstance(row[1].value, float) and row[1].value <= 1 and ('path' in str(row[0].value) or 'Rework' in str(row[0].value) or 'Within' in str(row[0].value)): row[1].number_format = '0.0%'
        if isinstance(row[1].value, datetime.datetime): row[1].number_format = 'yyyy-mm-dd hh:mm'
    C.sheet(wb, 'Variants', ['Variant', cap(unit_n), 'Share', 'Median days', 'Mean days', 'Steps', 'Path'],
            [[v['id'], v['cases'], v['share'], round(v['median'], 2), round(v['mean'], 2), len(v['path']), ' → '.join(v['path'])] for v in A['variants']],
            formats={2: '0.0%', 3: '0.00', 4: '0.00'}, widths={6: 100})
    C.sheet(wb, 'Hand-offs', ['From', 'To', 'Count', 'Median wait (days)', '90th pct wait (days)', 'Total wait (days)', 'Share of all waiting'],
            [[h['from'], h['to'], h['count'], round(h['median'], 3), round(h['p90'], 3), round(h['total'], 2), h['total'] / max(1e-9, sum(x['total'] for x in A['handoffs']))] for h in A['handoffs']],
            formats={3: '0.00', 4: '0.00', 5: '0.0', 6: '0.0%'})
    rows = [[cid, c['start'], c['end'], round(c['days'], 3), len(c['trace']), c['variant'], 'yes' if c['conform'] else 'no', ', '.join(c['deviations']), 'yes' if c['rework'] else 'no']
            + ([c['attr']] if g['by'] is not None else []) + ([('yes' if c['days'] <= A['target'] else 'no')] if A['target'] else [])
            for cid, c in sorted(A['cases'].items(), key=lambda x: x[1]['start'])]
    C.sheet(wb, 'Cases', ['Case', 'Start', 'End', 'Cycle days', 'Events', 'Variant', 'On path', 'Deviations', 'Rework'] + ([attr_name] if g['by'] is not None else [])
            + ([f"Within {A['target']:g} days"] if A['target'] else []), rows, formats={1: 'yyyy-mm-dd hh:mm', 2: 'yyyy-mm-dd hh:mm', 3: '0.00'})
    C.sheet(wb, 'Steps', ['Step', 'Events', 'Cases', 'Share of cases', 'Cases repeating it', 'Team (most often)'],
            [[s['step'], s['events'], s['cases'], s['share'], s['repeated'], s['team']] for s in sorted(A['steps'], key=lambda s: -s['cases'])], formats={3: '0.0%'})
    C.sheet(wb, 'Deviations', ['Case', 'Kind', 'Detail'], [list(d) for d in A['deviations'][:50000]], widths={2: 90})
    if A['by_attr']:
        C.sheet(wb, 'By ' + attr_name[:25], [attr_name, 'Cases', 'Median days', 'On path'], [[b['value'], b['cases'], round(b['median'], 2), b['conform']] for b in A['by_attr']],
                formats={2: '0.00', 3: '0.0%'})
    wb.save(path)


# ------------------------------------------------------------------------------------------------ samples
SAMPLES = {   # (case column, attribute, steps with team and typical wait in hours to the next step, detours)
    'order-to-cash': dict(case='Sales order', attr='Region', values=['West', 'East', 'South', 'Midwest'], slow='Midwest',
                          steps=[('Order created', 'Sales', 2), ('Delivery created', 'DC', 20), ('Picked', 'DC', 6), ('Goods issued', 'DC', 30), ('Invoice created', 'Billing', 240),
                                 ('Payment received', 'Finance', 0)],
                          detours=[('Credit check', 'Finance', 1, 0.28, 30), ('Price changed', 'Sales', 1, 0.07, 10)], repeat=('Delivery created', 0.06), skip=('Picked', 0.05), stop=0.12),
    'procure-to-pay': dict(case='PO', attr='Category', values=['Beauty', 'Fragrance', 'Store supplies', 'Services'], slow='Services',
                           steps=[('Requisition created', 'Requester', 6), ('Requisition approved', 'Manager', 20), ('PO created', 'Buying', 120), ('Goods received', 'DC', 30),
                                  ('Invoice received', 'Accounts payable', 50), ('Invoice paid', 'Treasury', 0)],
                           detours=[('PO changed', 'Buying', 3, 0.15, 24), ('Invoice blocked', 'Accounts payable', 5, 0.12, 70)], repeat=('Requisition approved', 0.04),
                           skip=('Requisition approved', 0.06), swap=(('Goods received', 'Invoice received'), 0.07), stop=0.05),
    'returns': dict(case='Return', attr='Channel', values=['Store', 'Online', 'Marketplace'], slow='Marketplace',
                    steps=[('Return requested', 'Guest services', 8), ('Return authorized', 'Guest services', 60), ('Item received', 'DC', 20), ('Item inspected', 'DC', 30),
                           ('Restocked', 'DC', 10), ('Refund issued', 'Finance', 0)],
                    detours=[('Escalated', 'Guest services', 1, 0.08, 40)], repeat=('Item inspected', 0.05), skip=('Return authorized', 0.1), alt=('Restocked', 'Liquidated', 0.22), stop=0.03),
}


def sample(kind, path, n=600, seed=7):
    """A realistic event log for a demo (deterministic): the main path, its detours, rework, skipped steps, a slow attribute value."""
    S = SAMPLES[kind]; R = random.Random(seed); rows = []
    t0 = datetime.datetime(2026, 7, 1, 8, 0)
    for i in range(n):
        attr = R.choice(S['values']); slow = 1.8 if attr == S['slow'] else 1.0
        t = t0 + datetime.timedelta(hours=R.uniform(0, 24 * 90)); cid = f"{ {'order-to-cash': 'SO', 'procure-to-pay': 'PO', 'returns': 'RT'}[kind] }-{40000 + i}"
        steps = list(S['steps'])
        if S.get('alt') and R.random() < S['alt'][2]:
            steps = [(S['alt'][1], tm, h) if s == S['alt'][0] else (s, tm, h) for s, tm, h in steps]
        if S.get('skip') and R.random() < S['skip'][1]: steps = [x for x in steps if x[0] != S['skip'][0]]
        if S.get('swap') and R.random() < S['swap'][1]:
            a_, b_ = S['swap'][0]; ia = next((k for k, x in enumerate(steps) if x[0] == a_), None); ib = next((k for k, x in enumerate(steps) if x[0] == b_), None)
            if ia is not None and ib is not None: steps[ia], steps[ib] = steps[ib], steps[ia]
        for name, team, after, share, wait in sorted(S['detours'], key=lambda d: -d[2]):   # the later detour first: positions stay true
            if R.random() < share * (1.4 if attr == S['slow'] else 1): steps.insert(min(after, len(steps)), (name, team, wait))
        if S.get('repeat') and R.random() < S['repeat'][1]:
            k = next((k for k, x in enumerate(steps) if x[0] == S['repeat'][0]), None)
            if k is not None: steps.insert(k + 1, (steps[k][0], steps[k][1], steps[k][2] * 0.6))
        if R.random() < S.get('stop', 0): steps = steps[:-1]
        for name, team, hrs in steps:
            rows.append([cid, name, t.strftime('%Y-%m-%d %H:%M'), team, attr])
            t += datetime.timedelta(hours=max(0.2, R.gauss(hrs, hrs * 0.35) * slow))
    import csv
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh); w.writerow([S['case'], 'Activity', 'Timestamp', 'Team', S['attr']]); w.writerows(rows)
    return path


# ------------------------------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('log', nargs='?'); ap.add_argument('--out', required=True); ap.add_argument('--title'); ap.add_argument('--sheet')
    ap.add_argument('--case'); ap.add_argument('--activity'); ap.add_argument('--time'); ap.add_argument('--team'); ap.add_argument('--by')
    ap.add_argument('--reference'); ap.add_argument('--target-days', type=float); ap.add_argument('--sample', choices=list(SAMPLES)); ap.add_argument('--template', default='STANDARD33')
    a = ap.parse_args()
    out = a.out; os.makedirs(os.path.dirname(os.path.abspath(out)) or '.', exist_ok=True)
    if a.sample and not a.log:
        a.log = sample(a.sample, out + f'-sample-{a.sample}.csv')
        a.title = a.title or {'order-to-cash': 'Order-to-cash', 'procure-to-pay': 'Procure-to-pay', 'returns': 'Returns'}[a.sample] + ': process insights'
    if not a.log: print('FAIL | give an event log (.csv / .xlsx) or pick a sample'); sys.exit(2)
    try:
        header, rows = C.read_table(a.log, a.sheet)
        g = guess(header, rows, a)
        ev, skipped = events(header, rows, g)
    except ValueError as e:
        print(f'FAIL | {e}'); sys.exit(2)
    if len(ev) < 3: print(f'FAIL | only {len(ev)} case(s) with a step and a time — check the columns (case = {header[g["case"]]}, step = {header[g["activity"]]}, time = {header[g["time"]]})'); sys.exit(2)
    A = analyse(ev, a.reference, a.target_days)
    title = a.title or (os.path.splitext(os.path.basename(a.log))[0].replace('_', ' ').replace('-', ' ').strip().capitalize() + ': process insights')
    attr_name = header[g['by']] if g['by'] is not None else 'attribute'
    unit_n = noun(header, g, A['N'])
    md, look = storyboard(A, title, header, g, attr_name)
    ok, warns, _ = C.md_to_deck(md, out + '.pptx', a.template)
    workbook(A, out + '.xlsx', title, unit_n, attr_name, g, header)
    rep = [f'# {title}', '', f"**{C.num(A['N'])} {unit_n}**, {C.num(A['events'])} events, {A['first']:%Y-%m-%d} to {A['last']:%Y-%m-%d}. "
           f"Median cycle time **{C.duration(A['median'], 'days')}**, 90% within {C.duration(A['p90'], 'days')}. "
           f"**{C.pct(A['conform'])}** follow the {'reference' if A['ref_given'] else 'main'} path ({' → '.join(A['main'])}); rework in {C.pct(A['rework'])}."
           + (f" {C.pct(A['on_time'])} finish within {A['target']:g} days." if A['on_time'] is not None else ''), '',
           f"Columns read: case **{header[g['case']]}**, step **{header[g['activity']]}**, time **{header[g['time']]}**" + (f" + {header[g['tod']]}" if g['tod'] is not None else '')
           + (f", team **{header[g['team']]}**" if g['team'] is not None else '') + (f", {attr_name}" if g['by'] is not None else '') + (f"; {skipped} row(s) without a case, step or time set aside" if skipped else '') + '.', '',
           '## What to look at first', ''] + [f'- **{t}** — {d}' for t, d in look] + ['', '## Paths', ''] + \
          [f"- {v['id']} · {C.num(v['cases'])} ({C.pct(v['share'])}) · median {v['median']:.1f} days · {' → '.join(v['path'])}" for v in A['variants'][:8]]
    if A['missing_ref']: rep += ['', f"Reference steps not in the log: {', '.join(A['missing_ref'])}"]
    open(out + '-insights.md', 'w', encoding='utf-8').write('\n'.join(rep) + '\n')
    status = 'READY' if ok else 'NEEDS CORRECTION'
    print(f"{status} | {os.path.basename(out)}.pptx, .xlsx, -insights.md | {C.num(A['N'])} {unit_n}, {plural(len(A['variants']), 'path')}, median {C.duration(A['median'], 'days')}, "
          f"{C.pct(A['conform'])} on the {'reference' if A['ref_given'] else 'main'} path")
    if A['missing_ref']: print(f"warning: reference steps not found in the log: {', '.join(A['missing_ref'])}")
    if skipped: print(f'note: {skipped} row(s) without a case, step or time were set aside')
    for w in warns[:6]:
        if not re.search(r'widened|set to \d+ pt|first column header', str(w)): print(f'note: {w}')
    sys.exit(0 if ok else 1)


if __name__ == '__main__':
    main()
