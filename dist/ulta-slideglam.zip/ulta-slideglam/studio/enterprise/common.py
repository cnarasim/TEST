"""Shared helpers for the Studio's enterprise workflows (v6.31): read a table, build a deck from a storyboard, style a workbook.

The workflows run as their own programs (the Workflows job, POST /api/v1/workflow, the MCP tool run_workflow), in a fresh folder,
with the Studio's own builders: page_to_spec.py reads a Markdown storyboard ("Layout: gantt", "Layout: sankey" ... - Presentation
Central's layouts), build_from_storyboard.py writes the PowerPoint on the template. Nothing here calls a model or LibreOffice.
"""
import csv, datetime, io, json, os, re, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__)); KIT = os.path.dirname(HERE)
PY = sys.executable
ORANGE, BERRY, DEEP, INK, MUTED, TINT, LINE = 'F26923', 'DB0058', '5D0F43', '000000', '404040', 'FFF5F3', 'D9D9D9'   # the template's colours only


# ------------------------------------------------------------------------------------------------ reading
def read_table(path, sheet=None):
    """A CSV or Excel sheet as (header, rows) with values as written: Excel dates and times stay datetimes (a time of day is kept).
    The header is the first row with three or more filled cells (title rows above it are skipped)."""
    ext = os.path.splitext(path)[1].lower()
    if ext in ('.xlsx', '.xlsm'):
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        ws = wb[sheet] if sheet and sheet in wb.sheetnames else wb[wb.sheetnames[0]]
        raw = [list(r) for r in ws.iter_rows(values_only=True)]
    else:
        txt = open(path, 'rb').read().decode('utf-8-sig', errors='replace')
        try: dialect = csv.Sniffer().sniff(txt[:4096], delimiters=',;\t|')
        except csv.Error: dialect = csv.excel
        raw = [r for r in csv.reader(io.StringIO(txt), dialect)]
    start = next((i for i, r in enumerate(raw) if sum(1 for c in r if str(c if c is not None else '').strip()) >= 3), None)
    if start is None: raise ValueError(f'{os.path.basename(path)}: no table found (a header row with three or more columns)')
    head = [str(c).strip() if c is not None and str(c).strip() else f'Column {k + 1}' for k, c in enumerate(raw[start])]
    rows = []
    for r in raw[start + 1:]:
        r = list(r) + [None] * (len(head) - len(r))
        if any(str(c if c is not None else '').strip() for c in r[:len(head)]): rows.append(r[:len(head)])
    return head, rows


DT_FORMATS = ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%Y-%m-%d', '%m/%d/%Y %H:%M:%S', '%m/%d/%Y %H:%M', '%m/%d/%Y %I:%M %p', '%m/%d/%Y', '%m/%d/%y %H:%M',
              '%m/%d/%y', '%d.%m.%Y %H:%M:%S', '%d.%m.%Y %H:%M', '%d.%m.%Y', '%Y%m%d%H%M%S', '%Y%m%d', '%d-%b-%Y %H:%M', '%d-%b-%Y', '%b %d, %Y %H:%M', '%b %d, %Y')
DAY_FIRST = ('%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M', '%d/%m/%Y', '%d/%m/%y')


def to_datetime(v, day_first=False):
    """A cell as a datetime, or None: Excel datetimes, ISO text, US (or day-first) dates with or without a time, SAP's 20260105,
    an Excel serial number."""
    if v is None or v == '': return None
    if isinstance(v, datetime.datetime): return v.replace(tzinfo=None)
    if isinstance(v, datetime.date): return datetime.datetime(v.year, v.month, v.day)
    if isinstance(v, (int, float)) and 20000 < float(v) < 80000:   # an Excel serial date (with its fraction of a day)
        return datetime.datetime(1899, 12, 30) + datetime.timedelta(days=float(v))
    s = str(v).strip()
    if not s: return None
    try: return datetime.datetime.fromisoformat(s.replace('Z', '')).replace(tzinfo=None)
    except ValueError: pass
    for f in (DAY_FIRST + DT_FORMATS) if day_first else DT_FORMATS:
        try: return datetime.datetime.strptime(s, f)
        except ValueError: continue
    return None


def is_time_of_day(v):
    if isinstance(v, datetime.time): return True
    return bool(re.fullmatch(r'\s*\d{1,2}:\d{2}(:\d{2})?\s*([AaPp][Mm])?\s*', str(v or '')))


def time_of_day(v):
    if isinstance(v, datetime.time): return v
    m = re.fullmatch(r'\s*(\d{1,2}):(\d{2})(?::(\d{2}))?\s*([AaPp][Mm])?\s*', str(v or '')) or re.fullmatch(r'\s*(\d{2})(\d{2})(\d{2})()\s*', str(v or ''))   # 09:15, 9:15 AM, SAP's 091500
    if not m: return None
    h, mi, se = int(m.group(1)), int(m.group(2)), int(m.group(3) or 0)
    if m.group(4): h = h % 12 + (12 if m.group(4).lower() == 'pm' else 0)
    return datetime.time(min(h, 23), min(mi, 59), min(se, 59))


# ------------------------------------------------------------------------------------------------ numbers in words
def num(n, d=0):
    """1,240 · 4.2 · 71% style numbers for slides."""
    if n is None: return '–'
    if d == 0: return f'{int(round(n)):,}'
    return f'{n:,.{d}f}'


def pct(x, d=0):
    return f'{100 * x:.{d}f}%' if x is not None else '–'


def duration(days, unit=None):
    """Days as words with one unit for a whole chart: hours under two days, else days."""
    if days is None: return '–'
    u = unit or ('hours' if days < 2 else 'days')
    v = days * 24 if u == 'hours' else days
    return f'{v:,.1f} {u if round(v, 1) != 1 else u[:-1]}'


def safe(s, n=60):
    return re.sub(r'[^A-Za-z0-9._-]+', '-', str(s or '')).strip('-')[:n] or 'file'


# ------------------------------------------------------------------------------------------------ deck
def md_to_deck(md, out_pptx, template='STANDARD33'):
    """A Markdown storyboard → a PowerPoint on the template, through the Studio's own builders. Returns (ok, warnings, spec)."""
    base = os.path.splitext(out_pptx)[0]
    open(base + '.md', 'w', encoding='utf-8').write(md)
    sp = base + '.spec.json'
    r = subprocess.run([PY, os.path.join(KIT, 'page_to_spec.py'), base + '.md', '--out', sp, '--storyboard', '--template', template], capture_output=True, text=True, cwd=KIT,
                       env=dict(os.environ, ULTA_NO_LIBREOFFICE='1'))
    if r.returncode or not os.path.isfile(sp): return False, [(r.stderr or r.stdout)[-400:]], None
    spec = json.load(open(sp, encoding='utf-8'))
    r = subprocess.run([PY, os.path.join(KIT, 'build_from_storyboard.py'), sp, '--templates', os.path.join(os.path.dirname(KIT), *'modules/ultabranddeliverables/scripts/kit/templates'.split('/')), '--out', out_pptx], capture_output=True, text=True, cwd=KIT,
                       env=dict(os.environ, ULTA_NO_LIBREOFFICE='1'))
    for f in (base + '.md', sp):
        try: os.remove(f)
        except OSError: pass
    try: res = json.loads(r.stdout)
    except ValueError: res = {}
    return (r.returncode == 0 and os.path.isfile(out_pptx)), (res.get('warnings') or [])[:20] + spec.get('warnings', [])[:10], spec


# ------------------------------------------------------------------------------------------------ workbook
def sheet(wb, title, header, rows, widths=None, formats=None, first=False, note=None):
    """A sheet in the template's colours: an orange header row, frozen, filtered, as an Excel table where it can be one."""
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
    from openpyxl.worksheet.table import Table, TableStyleInfo
    ws = wb.active if first else wb.create_sheet()
    ws.title = title[:31]
    r0 = 1
    if note:
        ws.cell(1, 1, note).font = Font(italic=True, color=MUTED); r0 = 3
    for k, h in enumerate(header, 1):
        c = ws.cell(r0, k, h); c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor=ORANGE); c.alignment = Alignment(vertical='center', wrap_text=True)
    for i, row in enumerate(rows, r0 + 1):
        for k, v in enumerate(row, 1):
            c = ws.cell(i, k, v)
            if formats and formats.get(k - 1): c.number_format = formats[k - 1]
    for k, h in enumerate(header, 1):
        w = (widths or {}).get(k - 1) or min(60, max(10, len(str(h)) + 2, *[len(str(r[k - 1])) + 2 for r in rows[:200] if k - 1 < len(r) and r[k - 1] is not None] or [10]))
        ws.column_dimensions[get_column_letter(k)].width = w
    ws.freeze_panes = ws.cell(r0 + 1, 1)
    if rows:
        ref = f'A{r0}:{get_column_letter(len(header))}{r0 + len(rows)}'
        t = Table(displayName=re.sub(r'[^A-Za-z0-9]', '', title)[:30] or 'Data', ref=ref)
        t.tableStyleInfo = TableStyleInfo(name='TableStyleLight1', showRowStripes=True); ws.add_table(t)
    return ws


def workbook_props(wb, title, subject):
    wb.properties.title = title; wb.properties.subject = subject; wb.properties.creator = 'ULTA Deliverable Studio'
