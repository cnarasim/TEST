#!/usr/bin/env python3
"""Steering committee pack (v6.31): the workstream decks into one pack on the template — no model, no LibreOffice.

    python enterprise/steerco_pack.py Merch.pptx SupplyChain.pptx Stores.pptx --out Out/SteerCo --title "Transformation steering committee"
            [--date "November 3, 2026"] [--status status.xlsx] [--keep-covers] [--classification internal]

The pack: a cover; the agenda; the program summary — every workstream with its status, its headline and the decision it needs;
a divider per workstream followed by that deck's own slides, copied as they are (text, tables, pictures, native charts with
their data, notes); the decisions needed, in one table; the closing slide.

Each deck's cover, agenda and closing slides are left out (--keep-covers keeps the covers). The status, headline and decisions
come from the decks: an "Overall status: At risk" / RAG word, the first content headline, lines that start "Decision", "Ask",
"Approve" (or a slide titled "Decisions" / "Asks"). A status workbook overrides them — columns Workstream | Status | Headline |
Decision | Owner (any order; rows matched to decks by name, else in order).

Decks built on another template keep their own slide size only if it matches; otherwise convert them first ("PDF or non-branded
deck → Ulta template"). Files: <Out>.pptx, <Out>-status.xlsx (the summary as a tracker), <Out>-pack.md.
"""
import argparse, copy, datetime, json, os, re, subprocess, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import common as C  # noqa: E402
from lxml import etree  # noqa: E402

R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
CNS = '{http://schemas.openxmlformats.org/drawingml/2006/chart}'
ANS = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
SKIP_REL = ('/slideLayout', '/notesSlide', '/slide', '/comments', '/commentAuthors', '/tags')   # the template's own, or meaningless in another deck
STATUS = [('Red', r'\b(off[- ]track|red|critical|blocked)\b'), ('Amber', r'\b(at[- ]risk|amber|yellow|delayed|watch)\b'), ('Green', r'\b(on[- ]track|green|complete[d]?|done)\b')]
STATUS_LINE = re.compile(r'^\s*(overall|status|rag|health)\s*(status)?\s*[:\-–=]', re.I)
VERB = re.compile(r'^\s*(approve|confirm|agree|decide|endorse|fund|sign[- ]off|release|accept|choose|select|prioriti[sz]e|extend)\b', re.I)
MARK = {'Green': '0BA03E', 'Amber': 'FFC000', 'Red': 'FF0000', 'Not stated': 'A6A6A6'}
WORDS = {'Green': 'On track', 'Amber': 'At risk', 'Red': 'Off track', 'Not stated': 'Not stated'}


# ------------------------------------------------------------------------------------------------ reading the decks
def texts(slide):
    out = []
    for sh in slide.shapes:
        if sh.has_text_frame:
            out += [p.text.strip() for p in sh.text_frame.paragraphs if p.text.strip()]
        if getattr(sh, 'has_table', False) and sh.has_table:
            for r in sh.table.rows:
                cells = [c.text.strip() for c in r.cells]
                if any(cells): out.append(' | '.join(c for c in cells if c))
        if sh.shape_type == 6:   # a group
            for x in sh.shapes:
                if x.has_text_frame: out += [p.text.strip() for p in x.text_frame.paragraphs if p.text.strip()]
    return out


def title_of(slide):
    """The slide's headline: its title placeholder, else the top-most text on it (the template's headline sits highest)."""
    t = slide.shapes.title
    if t is not None and t.has_text_frame and t.text_frame.text.strip(): return re.sub(r'\s+', ' ', t.text_frame.text).strip()
    cands = [(sh.top or 0, re.sub(r'\s+', ' ', sh.text_frame.text).strip()) for sh in slide.shapes
             if sh.has_text_frame and 3 <= len(sh.text_frame.text.strip()) <= 160 and not re.fullmatch(r'[\d\s./|]+|true|false', sh.text_frame.text.strip(), re.I)]
    return min(cands)[1] if cands else ''


def marker(path):
    """The Studio's marker inside a deck it built: its title and the template slide behind each slide (cover 1, agenda 2, closing 32)."""
    import zipfile
    try:
        with zipfile.ZipFile(path) as z: return json.loads(z.read('ppt/ulta-studio.json').decode('utf-8'))
    except Exception: return {}


def status_of(lines):
    joined = '\n'.join(lines)
    m = re.search(r'(overall|status|rag|health)\s*(status)?\s*[:\-–=]\s*(off[- ]track|on[- ]track|at[- ]risk|red|amber|yellow|green|delayed|blocked|complete[d]?)', joined, re.I)
    if m:
        w = m.group(3).lower()
        return next(k for k, rx in STATUS if re.search(rx, w, re.I))
    found = [k for k, rx in STATUS if re.search(rx, joined, re.I)]
    return found[0] if found else 'Not stated'   # the worst one named wins


def decisions_of(slides):
    out = []
    for s in slides:
        tt = title_of(s); lines = texts(s)
        if re.search(r'\b(decisions?( needed| required)?|asks?|approvals?( needed)?|support needed|help needed|for decision)\b', tt, re.I):
            body = [re.sub(r'^\s*[•\-–\d.)]+\s*', '', l) for l in (lines[lines.index(tt) + 1:] if tt in lines else lines) if len(l) > 8 and not STATUS_LINE.match(l)]
            verbs = [l for l in body if VERB.match(l)]   # a decision is asked as an imperative: approve, confirm, agree, fund …
            out += verbs or body[:1]
        for l in lines:
            m = re.match(r'^\s*(?:[•\-–]\s*)?(decision( needed)?|ask|approve|approval( needed)?|we need|request)\s*[:\-–]\s*(.{6,})$', l, re.I) \
                or re.match(r'^\s*(DECISION( NEEDED)?|ASK|APPROVAL( NEEDED)?)()\s+(.{6,})$', l)   # the Studio's callout: "DECISION  approve …"
            if m: out.append(m.group(m.lastindex).strip())
    seen, uniq = set(), []
    for d in out:
        k = d.lower()[:60]
        if k not in seen: seen.add(k); uniq.append((d[:1].upper() + d[1:])[:160])
    return uniq[:3]


def pretty(name):
    n = os.path.splitext(os.path.basename(name))[0]
    n = re.sub(r'[-_ ]?\d{8}[-_]\d{6}', '', n); n = re.sub(r'^(deck|pptx?|central)[-_]', '', n, flags=re.I)
    return re.sub(r'[-_]+', ' ', n).strip() or 'Workstream'


def read_status(path):
    header, rows = C.read_table(path)
    col = lambda rx: next((k for k, h in enumerate(header) if re.search(rx, h, re.I)), None)
    w, s, h, d, o = col(r'work ?stream|stream|project|team|area|track'), col(r'status|rag|health'), col(r'headline|summary|update|highlight'), col(r'decision|ask|approval'), col(r'owner|lead')
    out = []
    for r in rows:
        g = lambda k: str(r[k]).strip() if k is not None and r[k] not in (None, '') else ''
        out.append({'name': g(w), 'status': g(s), 'headline': g(h), 'decision': g(d), 'owner': g(o)})
    return out


def norm_status(s):
    if not s: return None
    return next((k for k, rx in STATUS if re.search(rx, s, re.I)), None)


# ------------------------------------------------------------------------------------------------ copying slides
def clone_part(part, pkg, cache):
    """A part and everything it points to (a chart's embedded workbook, its style and colours), under fresh names; the r:ids inside
    its XML are rewritten to the new relationships."""
    from pptx.opc.package import Part
    from pptx.opc.packuri import PackURI
    key = str(part.partname)
    if key in cache: return cache[key]
    stem = re.sub(r'\d+(\.\w+)$', r'%d\1', key)
    if '%d' not in stem: stem = key.rsplit('.', 1)[0] + '%d.' + key.rsplit('.', 1)[1]
    name = pkg.next_partname(stem)
    blob = part.blob
    new = Part(PackURI(str(name)), part.content_type, pkg, blob)
    cache[key] = new
    remap = {}
    for rid, rel in sorted(part.rels.items(), key=lambda x: x[0]):
        if rel.is_external: remap[rid] = new.relate_to(rel.target_ref, rel.reltype, is_external=True)
        else: remap[rid] = new.relate_to(clone_part(rel.target_part, pkg, cache), rel.reltype)
    if part.content_type.endswith('+xml') and (remap or 'drawingml.chart' in part.content_type):
        root = etree.fromstring(blob)
        for el in root.iter():
            for at in list(el.attrib):
                if at.startswith('{%s}' % R_NS) and el.attrib[at] in remap: el.attrib[at] = remap[el.attrib[at]]
            if el.tag in (CNS + 'axId', CNS + 'crossAx') and el.get('val', '').startswith('-'):   # a negative axis id (python-pptx writes them): PowerPoint repairs it
                el.set('val', el.get('val')[1:])
        new._blob = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
    return new


def copy_slide(dst, src_slide, layouts, cache):
    """src_slide → a new slide at the end of dst: the same layout (by name, else the blank one), every shape and its pictures,
    charts (with their data) and links, the background, the notes."""
    lay = layouts.get(src_slide.slide_layout.name) or layouts.get('__blank__')
    new = dst.slides.add_slide(lay)
    tree = new.shapes._spTree
    for el in list(tree)[2:]: tree.remove(el)   # keep nvGrpSpPr and grpSpPr; drop the layout's empty placeholders
    remap = {}
    for rid, rel in src_slide.part.rels.items():
        if any(rel.reltype.endswith(x) for x in SKIP_REL): continue
        if rel.is_external: remap[rid] = new.part.relate_to(rel.target_ref, rel.reltype, is_external=True)
        else: remap[rid] = new.part.relate_to(clone_part(rel.target_part, dst.part.package, cache), rel.reltype)
    def fix(el):
        for node in el.iter():
            for at in list(node.attrib):
                if at.startswith('{%s}' % R_NS) and node.attrib[at] in remap: node.attrib[at] = remap[node.attrib[at]]
        return el
    for el in list(src_slide.shapes._spTree)[2:]: tree.append(fix(copy.deepcopy(el)))
    try:   # v6.37 a Studio visual keeps its spec (a copy of its tag); any other tag reference, which would point at nothing, goes
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'tools')); import visual_spec as VS
        for el in list(tree)[2:]: VS.copy_fix(src_slide, new, el)
    except ImportError:
        pass
    for tb in tree.iter('{http://schemas.openxmlformats.org/presentationml/2006/main}txBody', ANS + 'txBody'):   # a text body needs a paragraph (Office repairs one without)
        if tb.find(ANS + 'p') is None: etree.SubElement(tb, ANS + 'p')
    sbg = src_slide._element.cSld.bg
    if sbg is not None:
        cs = new._element.cSld
        if cs.bg is not None: cs.remove(cs.bg)
        cs.insert(0, fix(copy.deepcopy(sbg)))
    if src_slide.has_notes_slide:
        t = src_slide.notes_slide.notes_text_frame.text if src_slide.notes_slide.notes_text_frame is not None else ''
        if t.strip(): new.notes_slide.notes_text_frame.text = t
    return new


# ------------------------------------------------------------------------------------------------ drawing
def table(slide, header, rows, widths, status_col=None, top=None):
    """A native table under the slide's headline in the template's colours: an orange header, light rules, status as a coloured mark."""
    from pptx.dml.color import RGBColor
    from pptx.util import Emu, Pt
    W = slide.part.package.presentation_part.presentation.slide_width; H = slide.part.package.presentation_part.presentation.slide_height
    t = slide.shapes.title
    left = t.left if t is not None else Emu(int(0.5 * 914400))
    y = top or ((t.top + t.height + Emu(int(0.25 * 914400))) if t is not None else Emu(int(1.6 * 914400)))
    width = W - 2 * left; rh = Emu(int(0.5 * 914400))
    shp = slide.shapes.add_table(len(rows) + 1, len(header), left, y, width, rh * (len(rows) + 1))
    tb = shp.table; tot = sum(widths)
    for k, w in enumerate(widths): tb.columns[k].width = Emu(int(width * w / tot))
    tbl = shp._element.graphic.graphicData.tbl
    style = tbl.tblPr.find('{http://schemas.openxmlformats.org/drawingml/2006/main}tableStyleId')
    if style is not None: style.text = '{2D5ABB26-0587-4C30-8999-92F81FD0307C}'   # "No Style, No Grid": our own fills and a light rule under each row
    def cell(r, c, text, bold=False, color='000000', fill=None, mark=None, size=14 if len(rows) <= 6 else 12):
        ce = tb.cell(r, c); ce.text = ''
        tf = ce.text_frame; tf.word_wrap = True; p = tf.paragraphs[0]
        if mark:
            m = p.add_run(); m.text = '● '; m.font.size = Pt(size + 2); m.font.color.rgb = RGBColor.from_string(mark)
        run = p.add_run(); run.text = str(text); run.font.size = Pt(size); run.font.bold = bold; run.font.color.rgb = RGBColor.from_string(color)
        ce.margin_left = ce.margin_right = Emu(int(0.08 * 914400)); ce.margin_top = ce.margin_bottom = Emu(int(0.04 * 914400))
        ce.fill.solid(); ce.fill.fore_color.rgb = RGBColor.from_string(fill or 'FFFFFF')
        tcPr = ce._tc.get_or_add_tcPr()
        for tag in ('lnB',):   # a hairline under the row in the template's light grey
            ln = etree.SubElement(tcPr, ANS + tag, w='9525'); sf = etree.SubElement(ln, ANS + 'solidFill'); etree.SubElement(sf, ANS + 'srgbClr', val=C.LINE)
            tcPr.remove(ln); tcPr.insert(0, ln)
    for c, h in enumerate(header): cell(0, c, h, bold=True, color='FFFFFF', fill=C.ORANGE)
    for r, row in enumerate(rows, 1):
        for c, v in enumerate(row):
            if c == status_col: cell(r, c, WORDS.get(v, v), mark=MARK.get(v, MARK['Not stated']), fill=C.TINT if r % 2 == 0 else None)
            else: cell(r, c, v, bold=(c == 0), fill=C.TINT if r % 2 == 0 else None)
    return shp


# ------------------------------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('decks', nargs='+'); ap.add_argument('--out', required=True); ap.add_argument('--title', default='Steering committee')
    ap.add_argument('--date'); ap.add_argument('--status'); ap.add_argument('--keep-covers', action='store_true'); ap.add_argument('--classification')
    ap.add_argument('--template', default='STANDARD33')
    a = ap.parse_args()
    from pptx import Presentation
    decks = [d for d in a.decks if d.lower().endswith('.pptx')]
    if not decks: print('FAIL | add the workstream decks (.pptx)'); sys.exit(2)
    date = a.date or datetime.date.today().strftime('%B %-d, %Y' if os.name != 'nt' else '%B %d, %Y')
    status_rows = read_status(a.status) if a.status else []
    ws = []
    for k, path in enumerate(decks):
        prs = Presentation(path); slides = list(prs.slides); mk = marker(path)
        cover_lines = sorted((l for l in texts(slides[0]) if 4 <= len(l) <= 60), key=len, reverse=True) if slides else []
        name = mk.get('title') or (cover_lines[0] if cover_lines else '') or pretty(path)
        src = mk.get('sources') if isinstance(mk.get('sources'), list) and len(mk.get('sources')) == len(slides) else None
        ws.append({'path': path, 'prs': prs, 'slides': slides, 'name': name[:60], 'sources': src})
    for k, w in enumerate(ws):   # the status workbook's row for this deck: by name, else in order
        row = next((r for r in status_rows if r['name'] and (r['name'].lower() in w['name'].lower() or w['name'].lower() in r['name'].lower())), None) \
            or (status_rows[k] if k < len(status_rows) and not any(r['name'] for r in status_rows) else None)
        w['row'] = row or {}
        if w['row'].get('name'): w['name'] = w['row']['name']
    # the frame: built on the template first, so its layouts name what a cover, an agenda and a closing slide are
    agenda = ['Program summary'] + [w['name'] for w in ws] + ['Decisions needed']
    spec = {'template': a.template, 'title': a.title, 'slides': [{'source': 1, 'fills': {'title': a.title}, 'notes': f'{a.title} — {date}'}]}
    for i in range(0, len(agenda), 5):
        spec['slides'].append({'source': 2, 'fills': {'text1': 'Agenda', 'table': [[str(i + j + 1), x] for j, x in enumerate(agenda[i:i + 5])]}, 'trim_empty_rows': True})
    blank = lambda t, notes='': {'source': 6, 'fills': {'title': t, 'text1': [''], 'text2': ['']}, 'hide': ['text1', 'text2'], 'notes': notes}
    spec['slides'].append(blank('Program summary', f'{date}. Status, headline and the decision each workstream needs.'))
    for k, w in enumerate(ws, 2):
        spec['slides'].append({'source': 5, 'fills': {'text1': str(k), 'text2': w['name']}})
    spec['slides'].append(blank('Decisions needed'))
    spec['slides'].append({'source': 32, 'fills': {}})
    work = a.out + '-frame'
    json.dump(spec, open(work + '.json', 'w', encoding='utf-8'), ensure_ascii=False)
    r = subprocess.run([C.PY, os.path.join(C.KIT, 'build_from_storyboard.py'), work + '.json', '--templates', os.path.join(os.path.dirname(C.KIT), *'modules/ultabranddeliverables/scripts/kit/templates'.split('/')), '--out', work + '.pptx'],
                       capture_output=True, text=True, cwd=C.KIT, env=dict(os.environ, ULTA_NO_LIBREOFFICE='1'))
    os.remove(work + '.json')
    if r.returncode or not os.path.isfile(work + '.pptx'): print('FAIL | the pack frame did not build: ' + (r.stderr or r.stdout)[-300:]); sys.exit(1)
    pack = Presentation(work + '.pptx'); os.remove(work + '.pptx')
    frame = list(pack.slides)
    cover_l, agenda_l, divider_l, closing_l = frame[0].slide_layout.name, frame[1].slide_layout.name, frame[-2 - len(ws)].slide_layout.name, frame[-1].slide_layout.name
    layouts = {l.name: l for m in pack.slide_masters for l in m.slide_layouts}
    layouts['__blank__'] = next((l for l in layouts.values() if re.search(r'blank', l.name, re.I)), list(layouts.values())[-1])
    warns, cache = [], {}
    # what each workstream says about itself
    for w in ws:
        content = []
        for i, s in enumerate(w['slides']):
            if w['sources']:   # a Studio deck says which template slide each one is
                if w['sources'][i] in (2, 32) or (w['sources'][i] == 1 and not a.keep_covers): continue
            else:
                ln = s.slide_layout.name; tx = texts(s)
                if (i == 0 and not a.keep_covers and (ln == cover_l or len(w['slides']) > 1)) or (i == len(w['slides']) - 1 and ln == closing_l) \
                        or any(re.fullmatch(r'agenda|contents|table of contents', l, re.I) for l in tx[:3]):
                    continue
            content.append(s)
        w['content'] = content
        lines = [l for s in content[:6] for l in texts(s)]
        w['status'] = norm_status(w['row'].get('status')) or status_of(lines)
        st_line = next((l for l in lines if STATUS_LINE.match(l)), '')
        rest = re.sub(r'^.*?(off[- ]track|on[- ]track|at[- ]risk|red|amber|yellow|green|delayed|blocked|complete[d]?)\s*[:\-–—,]*\s*', '', st_line, count=1, flags=re.I) if st_line else ''
        heads = [title_of(s) for s in content]
        heads = [h for h in heads if h and h != w['name'] and len(h.split()) >= 3]   # a one-word label ("Ask") is not a headline
        w['headline'] = w['row'].get('headline') or (rest[:1].upper() + rest[1:] if len(rest.split()) >= 3 else '') or (heads[0] if heads else '')
        w['decisions'] = [w['row']['decision']] if w['row'].get('decision') else decisions_of(content)
        w['owner'] = w['row'].get('owner', '')
        if w['prs'].slide_width != pack.slide_width or w['prs'].slide_height != pack.slide_height:
            warns.append(f"{w['name']}: its slides are a different size — convert the deck to the template first (\"PDF or non-branded deck → Ulta template\")")
        if any(s.slide_layout.name not in layouts for s in content):
            warns.append(f"{w['name']}: built on another template — its slides keep their content on a blank layout")
    # the summary and decisions tables
    summary = frame[1 + (len(agenda) + 4) // 5]
    table(summary, ['Workstream', 'Status', 'Headline', 'Decision needed'], [[w['name'], w['status'], w['headline'][:110] or '—', (w['decisions'][0] if w['decisions'] else '—')[:110]] for w in ws],
          [2.2, 1.4, 4.2, 3.6], status_col=1)
    dec_slide = frame[-2]
    dec_rows = [[d[:140], w['name'], w['owner'] or '—'] for w in ws for d in w['decisions']]
    table(dec_slide, ['Decision', 'Workstream', 'Owner'], dec_rows or [['No decision asked for in the decks', '—', '—']], [6.2, 2.4, 1.8])
    # every workstream's slides, after its divider
    order = list(pack.slides._sldIdLst)
    dividers = frame[-1 - len(ws) - 1:-2]
    copied = 0
    for w, dv in zip(ws, dividers):
        new_ids = []
        for s in w['content']:
            ns = copy_slide(pack, s, layouts, cache); copied += 1
            new_ids.append(pack.slides._sldIdLst[-1])
        dv.notes_slide.notes_text_frame.text = f"{w['name']}: {WORDS[w['status']]}. {w['headline']}" + (f" Decision needed: {w['decisions'][0]}" if w['decisions'] else '')
        w['ids'] = new_ids
    lst = pack.slides._sldIdLst; div_ids = {id(dv): el for dv, el in zip(frame, order)}
    final = order[:-2 - len(ws)]
    for w, dv in zip(ws, dividers):
        final.append(div_ids[id(dv)]); final += w['ids']
    final += order[-2:]
    for el in list(lst): lst.remove(el)
    for el in final: lst.append(el)
    pack.core_properties.title = a.title; pack.core_properties.subject = f'Steering committee pack, {date}'; pack.core_properties.author = 'ULTA Deliverable Studio'
    pack.save(a.out + '.pptx')
    # the status tracker and the story
    from openpyxl import Workbook
    wb = Workbook(); C.workbook_props(wb, a.title, 'Steering committee status')
    C.sheet(wb, 'Status', ['Workstream', 'Status', 'Headline', 'Decision needed', 'Owner', 'Slides', 'Deck'],
            [[w['name'], WORDS[w['status']], w['headline'], '; '.join(w['decisions']), w['owner'], len(w['content']), os.path.basename(w['path'])] for w in ws],
            widths={2: 60, 3: 60}, first=True, note=f'{a.title} — {date}. Status from the decks (or the status workbook given). Edit here and give it back as --status next time.')
    wb.save(a.out + '-status.xlsx')
    worst = 'Red' if any(w['status'] == 'Red' for w in ws) else 'Amber' if any(w['status'] == 'Amber' for w in ws) else 'Green' if all(w['status'] == 'Green' for w in ws) else 'Not stated'
    md = [f'# {a.title}', '', f'{date} · {len(ws)} workstreams · {len(pack.slides)} slides · overall **{WORDS[worst]}**', '', '| Workstream | Status | Headline | Decision needed |', '|---|---|---|---|']
    md += [f"| {w['name']} | {WORDS[w['status']]} | {w['headline']} | {'; '.join(w['decisions']) or '—'} |" for w in ws]
    open(a.out + '-pack.md', 'w', encoding='utf-8').write('\n'.join(md) + '\n')
    if a.classification:
        rr = subprocess.run([C.PY, os.path.join(os.path.dirname(C.KIT), 'tools', 'compliance.py'), 'classify', a.out + '.pptx', '--level', a.classification], capture_output=True, text=True,
                            env=dict(os.environ, ULTA_NO_LIBREOFFICE='1'))
        if rr.returncode: warns.append('classification label not applied: ' + (rr.stdout + rr.stderr).strip()[-160:])
    print(f"READY | {os.path.basename(a.out)}.pptx, -status.xlsx, -pack.md | {len(ws)} workstreams, {copied} slides copied, {len(pack.slides)} in the pack, overall {WORDS[worst]}")
    for w in ws:
        if w['status'] == 'Not stated': print(f"note: {w['name']}: no status found in the deck — add \"Overall status: On track\" or give a status workbook")
    for x in warns: print('warning: ' + x)


if __name__ == '__main__':
    main()
