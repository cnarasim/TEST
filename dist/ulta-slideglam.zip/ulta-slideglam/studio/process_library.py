"""The process library (v6.23; v6.26 Programs and Projects, brand partners, Excel companions): predefined, editable deck templates for Retail, Supply Chain and Finance processes, strategy slides
and infographics, built in Eco (no AI, no tokens, the same deck every time).

Every template is one Markdown page in library/<domain>/<l1>/<id>.md, read by the Studio's own Eco rules (page_to_spec.py):
"Layout: swimlane handoffs", "Layout: retail inventory-count", "Layout: process chevrons", tables, "Today" / "Target" bands …
Its front matter names it in the hierarchy:

    ---
    id: sc-wh-cycle-count
    domain: Supply Chain             Retail · Supply Chain · Finance · Enterprise Architecture · Programs and Projects · Proposals · Strategy · Timelines and Roadmaps · Infographics
    l1: Warehouse & Inventory        the end-to-end process (L1)
    l2: Cycle count                  the sub-process this template covers (L2) - what a person ticks in the picker
    summary: One line on what the deck explains.
    systems: WMS, ERP inventory      the kinds of system the process runs on (application-agnostic: no product names, no transaction codes);
                                     the picker shows them and search finds them. An older "sap:" line is read the same way
    tags: inventory, shrink, ABC     extra search words
    workbook: raid, actions          optional (v6.26): the Excel companion's live trackers (library_workbook.py); every table is a sheet anyway
    order: 403                       optional: picker order in the domain (L1 x 100 + L2), files without it follow
    ---
    # Cycle count                    the template's title (a divider when several templates make one deck)
    ## …                             one slide per H2 section

    import process_library as LIB
    LIB.catalogue()                  {'domains': [{'name', 'icon', 'blurb', 'l1': [{'name', 'items': [{'id', 'l2', 'summary', 'systems', 'slides'}]}]}], 'count'}
    LIB.compose(['sc-wh-cycle-count', 'sc-oc-pricing'], title=None)   -> (markdown, title): one Eco page, a chapter per template
    LIB.search('cycle count')        -> ids whose name, summary, systems, tags or slide titles match
    LIB.vendor_terms(text)           -> product names, transaction codes and table names in a text (the shipped library has none)

A team adds its own template by dropping a .md file with this front matter into library/ (or ULTA_LIBRARY_DIR): the picker lists it on
the next request. Nothing here calls a model.
"""
import os, re

HERE = os.path.dirname(os.path.abspath(__file__))
DIRS = [os.path.join(os.path.dirname(HERE), 'library')] + [p for p in (os.environ.get('ULTA_LIBRARY_DIR') or '').split(os.pathsep) if p]
DOMAINS = [   # picker order; a domain not listed here follows them
    ('Retail', 'stores', 'Merchandising, pricing and promotions, store operations, omnichannel and returns'),
    ('Supply Chain', 'truck', 'Planning, procurement, order to cash, the DC and its inventory, transportation'),
    ('Finance', 'wallet', 'Procure to pay, cash and collections, record to report, planning and margin'),
    ('Enterprise Architecture', 'blocks', 'New application assessment, comparative evaluation, solution options, architecture review, rationalisation'),
    ('Programs and Projects', 'flag', 'Charter to closure: kick-off, plans, RACI, status, steering, RAID, change control, testing, cutover, go-live, hypercare, lessons'),   # v6.26
    ('Proposals', 'proposal', 'Product proposals, process proposals, pilots, pricing, go-to-market, funding and partnership requests'),   # v6.27
    ('Strategy', 'target', 'Vision and priorities, OGSM, market and competition, growth options, OKRs, scorecards, decisions'),
    ('Timelines and Roadmaps', 'timeline', 'Product, multi-year and technology roadmaps, project timelines, sprints, launches, milestones, journeys'),   # v6.27
    ('Infographics', 'bar-chart', 'Big numbers, scorecards, shares, rankings, funnels, maps and plans'),
    ('Technology Operations', 'server', 'Incidents, problems, monitoring, changes and releases, service requests, access and service levels'),   # ULTA SlideGlam
    ('Data and AI', 'database', 'Data governance, quality and master data, analytics products, AI use cases, responsible AI, agent reviews'),
    ('People and Change', 'users', 'Organisation design, roles and skills, workforce plans, change impact, adoption and champions'),
]
FRONT = re.compile(r'^﻿?---\s*\n(.*?)\n---\s*\n', re.S)
_CACHE = {}


def _files():
    for d in DIRS:
        if not os.path.isdir(d): continue
        for root, dirs, fs in os.walk(d):
            dirs.sort()
            for f in sorted(fs):
                if f.endswith('.md') and not f.lower().startswith('readme'): yield os.path.join(root, f)


def parse(path):
    """(meta, body) of one template file; meta None when the file has no front matter with an id, a domain and an l2."""
    text = open(path, encoding='utf-8').read()
    m = FRONT.match(text)
    if not m: return None, text
    meta = {}
    for line in m.group(1).splitlines():
        k, sep, v = line.partition(':')
        if sep and k.strip(): meta[k.strip().lower()] = v.strip()
    if not all(meta.get(k) for k in ('id', 'domain', 'l2')): return None, text
    meta['l1'] = meta.get('l1') or 'General'
    try: meta['order'] = float(meta.get('order') or 999)   # picker order within the domain (L1 first, then L2); files without it follow
    except ValueError: meta['order'] = 999.0
    meta['systems'] = [x.strip() for x in re.split(r'[,;]', meta.get('systems') or meta.get('sap') or '') if x.strip()]   # v6.24: "systems"; "sap" read too
    meta.pop('sap', None)
    meta['tags'] = [x.strip() for x in re.split(r'[,;]', meta.get('tags') or '') if x.strip()]
    body = text[m.end():]
    meta['workbook'] = [x.strip().lower() for x in re.split(r'[,;\s]+', meta.get('workbook') or '') if x.strip()]   # v6.26 the Excel companion's trackers
    meta['tables'] = len(re.findall(r'^\s*\|?\s*:?-{2,}:?\s*\|', body, re.M))   # v6.26 Markdown tables: each one a sheet of the companion
    meta['slides'] = len(re.findall(r'^##\s+\S', body, re.M))
    meta['sections'] = [s.strip() for s in re.findall(r'^##\s+(.+)$', body, re.M)]
    meta['path'] = path
    return meta, body


def templates():
    """{id: (meta, body)} for every template, re-read only when a file changed (the picker asks often)."""
    sig = tuple((p, os.path.getmtime(p)) for p in _files())
    if _CACHE.get('sig') != sig:
        out = {}
        for p, _ in sig:
            try: meta, body = parse(p)
            except Exception: continue   # noqa: BLE001  a broken file is left out, never breaks the picker
            if meta and meta['id'] not in out: out[meta['id']] = (meta, body)
        _CACHE.update(sig=sig, items=out)
    return _CACHE['items']


def catalogue():
    """The picker's tree: domain → L1 → L2 templates, in DOMAINS order, then file order."""
    items = templates(); doms = {}
    for meta, _ in sorted(items.values(), key=lambda mb: (mb[0]['order'], mb[0]['path'])):
        d = doms.setdefault(meta['domain'], {})
        d.setdefault(meta['l1'], []).append({k: meta[k] for k in ('id', 'l2', 'summary', 'systems', 'tags', 'slides', 'sections', 'workbook', 'tables') if k in meta})
    order = [d for d, _, _ in DOMAINS] + sorted(d for d in doms if d not in {x for x, _, _ in DOMAINS})
    info = {d: (i, b) for d, i, b in DOMAINS}
    out = []
    for d in order:
        if d not in doms: continue
        icon, blurb = info.get(d, ('document', ''))
        out.append({'name': d, 'icon': icon, 'blurb': blurb, 'count': sum(len(v) for v in doms[d].values()),
                    'l1': [{'name': k, 'items': v} for k, v in doms[d].items()]})
    return {'domains': out, 'count': len(items)}


def search(q):
    """Ids whose L2 name, L1, summary, systems, tags or slide titles contain every word of q (case-insensitive)."""
    words = [w for w in re.split(r'\s+', str(q or '').lower()) if w]
    hits = []
    for tid, (meta, _) in templates().items():
        hay = ' '.join([meta['l2'], meta['l1'], meta['domain'], meta.get('summary', ''), ' '.join(meta['systems']), ' '.join(meta['tags']),
                        ' '.join(meta['sections'])]).lower()
        if all(w in hay for w in words): hits.append(tid)
    return hits


def compose(ids, title=None):
    """One Eco page from the chosen templates, in the order given: a single template is the page as written (its title the deck's);
    several become chapters - the deck's title, then each template's own "# Title" (a divider and an agenda line each).
    Returns (markdown, title). Unknown ids raise KeyError naming them."""
    items = templates()
    ids = [i for i in dict.fromkeys(str(x) for x in ids or []) if i]
    missing = [i for i in ids if i not in items]
    if missing: raise KeyError('not in the library: ' + ', '.join(missing))
    if not ids: raise KeyError('pick at least one template')
    chosen = [items[i] for i in ids]
    if len(chosen) == 1:
        meta, body = chosen[0]
        t = title or meta['l2']
        body = body.lstrip()
        if title and body.startswith('# '): body = '# ' + title + body[body.index('\n'):]
        return body, t
    doms = list(dict.fromkeys(m['domain'] for m, _ in chosen)); l1s = list(dict.fromkeys(m['l1'] for m, _ in chosen))
    t = title or (l1s[0] + ': ' + ', '.join(m['l2'] for m, _ in chosen[:3]) + (' and more' if len(chosen) > 3 else '') if len(l1s) == 1
                  else doms[0] + ' processes' if len(doms) == 1 else 'Process playbook')
    parts = ['# ' + t]   # the deck's own title first: every template below it is a chapter (a divider and an agenda line each)
    for meta, body in chosen:
        b = body.strip()
        if not b.startswith('# '): b = '# ' + meta['l2'] + '\n\n' + b
        parts.append(b)
    return '\n\n'.join(parts) + '\n', t


VENDOR = re.compile(r"\bSAP\b|S/4\s?HANA|\bHANA\b|\bFiori\b|\bIDocs?\b|\bABAP\b|\bEWM\b|\bIBP\b|\bMDG\b|\bGTS\b|\baATP\b|\bOracle\b|\bNetSuite\b|"
                    r"\bDynamics 365\b|\bWorkday\b|\bBlue Yonder\b|\bManhattan\b|condition (?:technique|type|record|contract)|access sequence|pricing procedure|"
                    r"universal journal|material ledger|GR/IR|stock transport order|/SCWM/|\b(?:ACDOC[AUP]|MATDOC|VBAK|VBAP|VBEP|VBRK|LIKP|LIPS|EKKO|EKPO|"
                    r"EBAN|MARA|MARC|MARD|MBEW|KONP|BKPF|BSEG|RBKP|RSEG|IKPF|ISEG|LFA1|T001W|PRCD_ELEMENTS)\b|\b[A-Z]{2,4}\d{1,3}[A-Z]?\b|\b[A-Z]{1,2}/\d{2}\b|\bF-\d{2}\b")


def vendor_terms(text):
    """v6.24 application-agnostic: product names, transaction codes ("VA01", "F-28", "V/08") and table names in a text. EDI message
    numbers (EDI 850) and plain industry words (goods receipt, ASN, ATP) are not flagged."""
    return [m.group(0) for m in VENDOR.finditer(str(text or '')) if not re.match(r'^(?:Q[1-4]|H[12]|FY\d+|GS1)$', m.group(0))]


def lint(agnostic=False):
    """Library health for the tests and `ulta-kit playbook check`: [(id or path, problem)]. agnostic=True also flags product names,
    transaction codes and table names (the shipped library is application-agnostic)."""
    seen, out = {}, []
    for p in _files():
        meta, body = parse(p)
        if not meta: out.append((os.path.relpath(p, HERE), 'no front matter with id, domain and l2')); continue
        if meta['id'] in seen: out.append((meta['id'], 'id used twice: ' + os.path.relpath(seen[meta['id']], HERE)))
        seen[meta['id']] = p
        if not body.lstrip().startswith('# '): out.append((meta['id'], 'the page does not start with "# Title"'))
        if meta['slides'] < 1: out.append((meta['id'], 'no "## " section: no slide'))
        if not meta.get('summary'): out.append((meta['id'], 'no summary'))
        if agnostic:
            hits = vendor_terms(open(p, encoding='utf-8').read())
            if hits: out.append((meta['id'], 'not application-agnostic: ' + ', '.join(dict.fromkeys(hits))))
    return out


# ---------------------------------------------------------------------------------------------------------------- v6.26 usage log
USAGE_EVENTS = ('search-miss', 'use', 'excel', 'from-excel')


def _usage_load(path):
    try:
        import json
        d = json.load(open(path, encoding='utf-8'))
        return d if isinstance(d, dict) else {}
    except Exception:   # noqa: BLE001  missing or damaged: start again
        return {}


def record_usage(path, event, values):
    """v6.26: what people look for and use, kept on this computer (or this Studio server) only - counts and dates, no deck content:
    'search-miss' (a library search that found nothing: the words typed, which name the missing templates), 'use' (template ids
    built), 'excel' (companion workbooks downloaded), 'from-excel' (decks updated from one). Never raises."""
    if not path or event not in USAGE_EVENTS: return
    try:
        import json, datetime, tempfile
        d = _usage_load(path); today = datetime.date.today().isoformat()
        d.setdefault('since', today); bucket = d.setdefault(event, {})
        for v in (values if isinstance(values, (list, tuple)) else [values]):
            k = re.sub(r'\s+', ' ', str(v or '')).strip().lower()[:80]
            if event == 'search-miss' and len(k) < 3: continue
            if not k: continue
            e = bucket.setdefault(k, {'count': 0, 'first': today}); e['count'] += 1; e['last'] = today
        if len(bucket) > 2000:   # the long tail of one-off words goes first
            for k, _ in sorted(bucket.items(), key=lambda kv: (kv[1]['count'], kv[1].get('last', '')))[:len(bucket) - 2000]: bucket.pop(k, None)
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path) or '.', prefix='.usage-'); os.close(fd)
        json.dump(d, open(tmp, 'w', encoding='utf-8'), indent=1); os.replace(tmp, path)
    except Exception:   # noqa: BLE001  the log never gets in the way of building
        pass


def usage_report(path):
    """{'since', 'searches_without_results': [{q, count, first, last}], 'templates': [{id, l2, domain, count, excel, last}], 'from_excel'}"""
    d = _usage_load(path); items = templates()
    miss = sorted(({'q': k, **v} for k, v in (d.get('search-miss') or {}).items()), key=lambda x: (-x['count'], x['q']))
    ids = set(d.get('use') or {}) | set(d.get('excel') or {})
    tpl = []
    for i in ids:
        u, x = (d.get('use') or {}).get(i, {}), (d.get('excel') or {}).get(i, {})
        meta = items.get(i, ({}, ''))[0]
        tpl.append({'id': i, 'l2': meta.get('l2', i), 'domain': meta.get('domain', ''), 'count': u.get('count', 0), 'excel': x.get('count', 0),
                    'last': max(u.get('last', ''), x.get('last', ''))})
    tpl.sort(key=lambda x: (-x['count'], -x['excel'], x['l2']))
    fx = sum(v.get('count', 0) for v in (d.get('from-excel') or {}).values())
    return {'since': d.get('since'), 'searches_without_results': miss, 'templates': tpl, 'from_excel': fx}


def clear_usage(path):
    try:
        if path and os.path.exists(path): os.remove(path)
    except OSError: pass
