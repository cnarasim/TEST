"""Presentation Central's slide families in the Studio's decks (v6.22: v93's four; v6.23: v140's retail diagrams and process flows).

A Central storyboard slide —
    {"timeline": {...}, "style": "lanes", "headline": "...", "notes": "..."}                  16 timeline styles
    {"swimlane": {...}, "style": "handoffs", "headline": "..."}                                10 cross-functional swimlane styles
    {"modern": "kpi", "items": [...], "headline": "...", "summary": "..."}                     20 modern charts (+ gantt / swimlane)
    {"quad": [...]} / {"funnel": [...]} / {"donut": {...}} / {"scorecard": {...}} / {"ogsm": {...}} / {"priorities": {...}}
    / {"results": [...]} / {"journey": {...}} / {"map": [...]}                                  the template's own infographic slides
    {"retail": {...}, "style": "network", "headline": "..."}                                   v6.23: 5 retail diagrams with trucks, DCs, documents
    {"retail": "inventory-count", "headline": "..."}                                          v6.23: 18 retail process starters (standard steps)
    {"process": {"steps": [...], "icons": "auto"}, "style": "chevrons", "headline": "..."}    v6.23: 11 process flow styles with retail pictograms
— becomes a Studio spec slide for build_from_storyboard.py: a drawn style on the two-box slide with its boxes hidden (the engine draws in
the content area), a template style on the template's own slide (filled in place). build_from_storyboard's add_central() does the drawing.

    import central_slides as CS
    CS.to_spec_slide(central_slide, roles)        # roles: the template's roles (two_col …) from templates/manifest.json
    CS.styles()                                   # {'timeline': [...], 'swimlane': [...], 'modern': [...], 'infographic': [...], 'retail': [...], 'process': [...]}
"""
import copy, os, sys

HERE = os.path.dirname(os.path.abspath(__file__)); TOOLS = os.path.join(os.path.dirname(HERE), 'tools')


def engines():
    if TOOLS not in sys.path: sys.path.insert(0, TOOLS)
    import timelines as TL, swimlanes as SW, modern_charts as MC, template_infographics as TI
    return TL, SW, MC, TI


def retail_engines():
    """v6.23 — Presentation Central v140's retail pack: retail diagrams (tools/retail.py) and process flows (tools/flows.py), both drawn
    with its native retail pictograms (tools/pictograms.py)."""
    engines()
    import retail as RT, flows as FL
    return RT, FL


def styles():
    TL, SW, MC, TI = engines()
    out = {'timeline': list(TL.STYLES) + [s for (f, s) in TI.TEMPLATE_STYLES if f == 'timeline'],
           'swimlane': list(SW.STYLES), 'modern': [t for t in MC.TYPES if t not in ('gantt', 'swimlane')], 'infographic': list(TI.KEYS)}
    try:
        RT, FL = retail_engines(); out.update(retail=list(RT.STYLES), process=list(FL.STYLES), starter=list(RT.STARTERS))
    except Exception:   # a Central without the retail pack (before v133): the four families only
        pass
    return out


def starter(name, headline=None, steps=None):
    """A v140 retail starter ("inventory-count", "order-to-cash" …) as a Central storyboard slide - a retail diagram or a process flow
    with pictograms, standard steps, its own takeaway headline and notes. steps: the section's own lines replace a process starter's
    standard steps (a diagram starter keeps its picture: its notes say what to add). None for an unknown name."""
    RT, FL = retail_engines()
    st = RT.STARTERS.get(str(name or '').strip().lower().replace(' ', '-'))
    if not st: return None
    cs = copy.deepcopy(st)
    if headline: cs['headline'] = headline
    if steps and isinstance(cs.get('process'), dict) and len(steps) >= 3: cs['process']['steps'] = list(steps)
    return cs


def family_of(cs):
    """('timeline' | 'swimlane' | 'modern' | 'infographic', style) for a Central storyboard slide, or (None, None)."""
    if not isinstance(cs, dict): return None, None
    TL, SW, MC, TI = engines()
    if cs.get('retail') is not None or isinstance(cs.get('process'), (dict, list)):   # v6.23: v140's retail pack
        try: RT, FL = retail_engines()
        except Exception: return None, None
        if isinstance(cs.get('retail'), str): return family_of(starter(cs['retail'], cs.get('headline')) or {})
        if isinstance(cs.get('retail'), (dict, list)):
            st = cs.get('style'); return 'retail', st if st in RT.STYLES else RT.auto_style(cs['retail'])
        P = cs['process'] if isinstance(cs['process'], dict) else {'steps': cs['process']}
        st = cs.get('style'); return 'process', st if st in FL.STYLES else FL.auto_style(P)
    if cs.get('modern') == 'swimlane':   # Central v92: "modern": "swimlane" draws through the swimlane family
        return 'swimlane', cs.get('style') if cs.get('style') in SW.STYLES else 'lanes'
    for fam, mod in (('timeline', TL), ('swimlane', SW)):
        if isinstance(cs.get(fam), (dict, list)):
            st = cs.get('style')
            ok = st in mod.STYLES or (fam == 'timeline' and (fam, st) in TI.TEMPLATE_STYLES)
            return fam, st if ok else mod.auto_style(cs[fam])
    if cs.get('modern') in MC.TYPES: return 'modern', cs['modern']
    k = TI.key_of(cs)
    return ('infographic', k) if k else (None, None)


def _template_takes(TI, style, data, head):
    """(1r) True when the template timeline's filler takes the data (tried on a scratch copy of its template slide)."""
    try:
        import brand as _B
        from pptx import Presentation
        sl = Presentation(str(_B.current().template)).slides[TI.TEMPLATE_STYLES[('timeline', style)] - 1]
        probs = TI.fill(sl, 'timeline', style, {'timeline': data, 'style': style, 'headline': head}) or []
    except Exception:                                  # noqa: BLE001  unknown: the filler decides at build time
        return True
    return not probs                                  # any problem (over capacity, a label too long): not taken


def to_spec_slide(cs, roles=None):
    """A Central storyboard slide → a Studio spec slide (None when it is not one of the four families)."""
    roles = roles or {}; two = roles.get('two_col', 6)
    if isinstance(cs, dict) and isinstance(cs.get('retail'), str):   # a named starter: its standard content, the author's headline and notes kept
        st = starter(cs['retail'], cs.get('headline'))
        if not st: return None
        if cs.get('notes'): st['notes'] = str(cs['notes']) + ' — ' + str(st.get('notes') or '')
        cs = st
    fam, style = family_of(cs)
    if not fam: return None
    TL, SW, MC, TI = engines()
    head = str(cs.get('headline') or '').strip(); notes = str(cs.get('notes') or '').strip()
    if fam == 'swimlane' and cs.get('modern') == 'swimlane':   # the older "modern" form: lanes and steps at the top level
        data = {k: cs[k] for k in ('lanes', 'steps', 'phases', 'systems') if k in cs}
    elif fam in ('timeline', 'swimlane'):
        data = cs[fam] if isinstance(cs[fam], dict) else {'items' if fam == 'timeline' else 'steps': cs[fam]}
    elif fam in ('retail', 'process'):
        data = cs[fam] if isinstance(cs[fam], dict) else ({'nodes': cs[fam]} if fam == 'retail' else {'steps': cs[fam]})
    elif fam == 'modern':
        data = {k: v for k, v in cs.items() if k not in ('modern', 'headline', 'notes', 'summary', 'style')}
    else:
        data = {style: cs[style]}
    if fam == 'timeline' and (fam, style) in TI.TEMPLATE_STYLES and not _template_takes(TI, style, data, head):   # (1r)
        notes = (notes + ' - ' if notes else '') + f'drawn as lanes: the plan does not fit the {style.replace("-", " ")} slide'
        style = 'lanes'
    c = {'family': fam, 'style': style, 'data': data, 'headline': head}
    if fam == 'infographic' or (fam == 'timeline' and (fam, style) in TI.TEMPLATE_STYLES):   # the template's own slide, filled in place
        src = TI.KEYS[style] if fam == 'infographic' else TI.TEMPLATE_STYLES[(fam, style)]
        sl = {'source': src, 'fills': {}, 'central': c, 'kind': f'{fam}-{style}'}
    else:
        sl = {'source': two, 'fills': {'title': head, 'text1': [''], 'text2': ['']}, 'hide': ['text1', 'text2'], 'central': c, 'kind': f'{fam}-{style}'}
        if fam == 'modern' and str(cs.get('summary') or '').strip(): sl['takeaway'] = str(cs['summary']).strip()   # one line under the headline
    if notes: sl['notes'] = notes
    return sl


def gallery(roles=None, families=('timeline', 'swimlane', 'infographic', 'modern', 'retail', 'process')):
    """Every style the four families draw, from Presentation Central's own samples (neutral store / order content) — the visual
    library deck's second half."""
    TL, SW, MC, TI = engines()
    out = []
    if 'timeline' in families:
        out += [x for x in (to_spec_slide(s, roles) for s in TL.sample()) if x]
        out += [x for x in (to_spec_slide(s, roles) for s in TI.sample('timeline')) if x]
    if 'swimlane' in families: out += [x for x in (to_spec_slide(s, roles) for s in SW.sample()) if x]
    if 'infographic' in families: out += [x for x in (to_spec_slide(s, roles) for s in TI.sample('infographic')) if x]
    if 'retail' in families or 'process' in families:   # v6.23: every retail style and starter, every process flow style
        try:
            RT, FL = retail_engines()
            if 'retail' in families: out += [x for x in (to_spec_slide(s, roles) for s in RT.sample()) if x]
            if 'process' in families: out += [x for x in (to_spec_slide(s, roles) for s in FL.sample()) if x]
        except Exception:
            pass
    if 'modern' in families:
        import json
        p = os.path.join(os.path.dirname(HERE), 'brands', 'ulta', 'modern-sample.json')
        try: ms = json.load(open(p, encoding='utf-8')).get('slides', [])
        except Exception: ms = []
        out += [x for x in (to_spec_slide(s, roles) for s in ms if s.get('modern') not in ('gantt', 'swimlane')) if x]
    return out


def previews(pptx, spec, work=None, timeout=120):
    """The live preview (HTML twin) of each family slide: the built slide drawn as SVG by the Studio itself (slide_svg.py — v6.32: never
    LibreOffice or any other program). A drawn slide is pictured without its headline and takeaway — the twin writes those itself,
    editable; a template slide keeps its own. Sets spec slide['info_svg'] (the twin's picture slot)."""
    import slide_svg
    from pptx import Presentation
    idx = [k for k, s in enumerate(spec.get('slides', [])) if s.get('central')]
    if not idx: return 0
    prs = Presentation(pptx); slides = list(prs.slides); n = 0
    for k in idx:
        if k >= len(slides): continue
        s = spec['slides'][k]; title = str((s.get('fills') or {}).get('title') or '').strip()
        def drop(el, title=title, has=('title' in s.get('fills', {}))):
            if not has: return False
            nm = el.find('.//{%s}cNvPr' % slide_svg.NS['p'])
            if nm is not None and (nm.get('name') or '') == 'ULTA takeaway': return True
            txt = ' '.join(t.text or '' for t in el.iter('{%s}t' % slide_svg.NS['a'])).strip()
            return bool(title) and txt == title
        try: svg = slide_svg.render(prs, slides[k], drop=drop, background_fill=False)   # the twin's own slide colour behind it
        except Exception: continue  # noqa: BLE001  no picture: the PowerPoint is right either way
        s['info_svg'] = svg
        s['preview_full'] = 'title' not in s.get('fills', {})   # the picture carries its own headline
        n += 1
    return n
