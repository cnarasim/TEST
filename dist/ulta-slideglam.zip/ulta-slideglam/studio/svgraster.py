#!/usr/bin/env python3
"""SVG → PNG and SVG → PDF for the Studio's previews and downloads, with permissively licensed tools only.

  resvg (via the `resvg-py` binding, MIT; resvg itself Apache-2.0 OR MIT) draws the SVG; Pillow (MIT-CMU) writes the PDF.
  v6.6 replaced PyMuPDF (AGPL-3.0) here so the hosted Studio carries no copyleft obligation.

Every function returns True when the file was written and False when the renderer is not installed — callers already treat
a missing PNG / PDF as optional (the SVG and the .pptx are always produced).
"""
import io, os

DEJAVU = '/usr/share/fonts/truetype/dejavu'   # the slim container's only fonts (fonts-dejavu-core): generic families map onto them


def _fonts():
    """Generic families for a machine without Helvetica / Arial (the container): DejaVu, so text never renders blank."""
    if os.path.isdir(DEJAVU):
        return {'font_family': 'DejaVu Sans', 'sans_serif_family': 'DejaVu Sans', 'serif_family': 'DejaVu Serif', 'monospace_family': 'DejaVu Sans Mono'}
    return {}


def available():
    try:
        import resvg_py  # noqa: F401
        return True
    except Exception:
        return False


def png_bytes(svg, zoom=1.0, background=None):
    """The SVG drawn at `zoom` × its own size, as PNG bytes; None when resvg is not installed."""
    try:
        import resvg_py
    except Exception:
        return None
    kw = dict(svg_string=svg, zoom=float(zoom), **_fonts())
    if background: kw['background'] = background
    out = resvg_py.svg_to_bytes(**kw)
    return bytes(out) if not isinstance(out, (bytes, bytearray)) else out


def to_png(svg, path, zoom=1.0, background='#FFFFFF'):   # white, as previews always were (a transparent PNG reads badly on dark viewers)
    b = png_bytes(svg, zoom, background)
    if b is None: return False
    open(path, 'wb').write(b); return True


def to_pdf(svg, path, page=None, dpi=300, svg_size=None):
    """One PDF page of `page` points (w, h) — the format's real size — with the drawing scaled to fit and centred, printed at `dpi`.
    The page is a high-resolution picture (text is not selectable); the editable sources are the .pptx / .svg."""
    try:
        from PIL import Image
    except Exception:
        return False
    sw, sh = svg_size or _svg_size(svg)
    pw, ph = page or (sw * 0.75, sh * 0.75)   # no format given: 1 px = 0.75 pt
    px_w, px_h = int(round(pw / 72 * dpi)), int(round(ph / 72 * dpi))
    zoom = min(px_w / sw, px_h / sh)
    b = png_bytes(svg, zoom, background='#FFFFFF')
    if b is None: return False
    art = Image.open(io.BytesIO(b)).convert('RGB')
    sheet = Image.new('RGB', (px_w, px_h), 'white'); sheet.paste(art, ((px_w - art.width) // 2, (px_h - art.height) // 2))
    sheet.save(path, 'PDF', resolution=float(dpi)); return True


def _svg_size(svg):
    import re
    m = re.search(r'viewBox="\s*[-\d.]+\s+[-\d.]+\s+([\d.]+)\s+([\d.]+)"', svg)
    if m: return float(m.group(1)), float(m.group(2))
    w = re.search(r'\bwidth="([\d.]+)', svg); h = re.search(r'\bheight="([\d.]+)', svg)
    return (float(w.group(1)) if w else 1600.0), (float(h.group(1)) if h else 900.0)
