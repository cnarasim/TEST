"""Rules (no AI): a section's lines → the data of a Presentation Central v93 slide family (v6.22).

    timeline   items with dates: "Discovery: Jan 2026 – Mar 2026 (Digital)", "Code freeze — Nov 6, 2026", "Q2 2026: Pilot in 40 stores"
    swimlane   a process written role by role: "Guest: Place order online", "Store team: All items in stock?", "Store team: If yes, stage
               for pickup", "Store team: If no, offer a substitute", "Guest: Collect the order"
    infographic the template's own slides: quad (4 big numbers), funnel (4 stages), donut (2–4 shares), map (1–4 "City, ST: …"),
               ogsm, priorities, scorecard (labelled lines, see each parser)
    modern     kpi, ring, gauge, bullet, lollipop, treemap, bubbles, rose, radialbar, waffle, dumbbell, slope, sankey
    retail     v6.23 (Presentation Central v140): "Layout: retail network | dc-flow | cross-dock | fulfilment | document-flow" from
               "Title: text (Owner)" lines, or a named starter - "Layout: retail inventory-count", "retail order-to-cash" … (18)
    process    v6.23: "Layout: process chevrons | arrow | numbered | cycle | snake | vertical | phases | pipeline | io | converge |
               diverge" - steps in order with native retail pictograms

Each parser returns the family's data dict (central_slides.to_spec_slide builds the slide) or None when the lines do not have that
shape — the section then keeps its usual layout. auto() is the deterministic router page_to_spec uses with no "Layout:" line: only a
dated list with at least one date range becomes a timeline, only a process section written as "Role: step" lines (a role used twice)
becomes a swimlane, so ordinary decks never change shape.
"""
import re

_MON = r'(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?'
D = (r'(?:\d{4}-\d{2}-\d{2}|' + _MON + r'\s+\d{1,2},?\s+\d{4}|\d{1,2}\s+' + _MON + r'\s+\d{4}|' + _MON + r'\s+\d{4}|Q[1-4]\s*\'?(?:FY)?\s*\d{4}|H[12]\s+\d{4})')
DATE = re.compile(D, re.I)
RANGE = re.compile(r'(' + D + r')\s*(?:–|—|-|to|until|through|thru)\s*(' + D + r')', re.I)
STATUS = {'done': 'done', 'complete': 'done', 'completed': 'done', 'on track': 'on track', 'green': 'on track',
          'at risk': 'at risk', 'amber': 'at risk', 'late': 'late', 'delayed': 'late', 'red': 'late', 'blocked': 'late'}
MILESTONE = re.compile(r'\b(milestone|go[- ]live|launch|freeze|deadline|cut[- ]?over|release|sign[- ]?off|kick[- ]?off|decision|gate)\b', re.I)
PROCESS_HEAD = re.compile(r'\b(process|flow|hand-?offs?|workflow|end[- ]to[- ]end|e2e|journey|how .{0,30}works|procedure|lifecycle|life cycle|'
                          r'swim ?lanes?|cross[- ]functional|steps|order to|request to|procure to|record to|hire to|issue to)\b', re.I)
NUM = re.compile(r'[-+~≈]?[$€£]?\d[\d,.]*(?:\s?(?:%|pts?|points?|minutes?|mins?|hours?|hrs?|days?|weeks?|months?|stores?|bn|x)\b|[kmb]\b|%)?', re.I)   # the longer unit first ("6.2 min", not "6.2 m")


def plain(l):
    l = re.sub(r'^\s*(?:[-*•–◦▪]|\d+[.)])\s*', '', str(l or '')).strip()
    return re.sub(r'\*\*(.+?)\*\*', r'\1', l).strip()


def split_label(l):
    m = re.match(r'^([^:—–|]{1,60}?)\s*(?::|—|–|\|)\s+(.+)$', l)
    return (m.group(1).strip(), m.group(2).strip()) if m else (None, l)


TAIL = re.compile(r'(?:\s+(?:and|or|the|a|an|of|to|in|on|at|for|with|by|from|into|your|our|their))+$', re.I)


def _short(t, n):
    """At most n words, never ending on "at the" / "and"; a question keeps its mark."""
    t = str(t).strip(); q = t.endswith('?'); w = t.rstrip('?').split()
    if len(w) <= n: return t
    out = TAIL.sub('', ' '.join(w[:n])).rstrip(',;:')
    return out + ('?' if q else '')


def _words(t, n):
    w = str(t).split()
    return ' '.join(w[:n]).rstrip('.,;:') if len(w) > n else str(t).rstrip('.')


# ---------------------------------------------------------------- timeline
def timeline(lines, groups=None):
    """Every line dated → {'items': [...]}. A range gives start / end; one date a milestone (or a dated task when the text says so);
    "(Group)" or a sub-heading names the workstream; a status word (done, at risk, late …) becomes the status mark."""
    items = []
    for k, raw in enumerate(lines):
        l = plain(raw)
        if not l: continue
        it = {}
        r = RANGE.search(l)
        if r:
            it['start'], it['end'] = r.group(1).strip(), r.group(2).strip(); rest = (l[:r.start()] + ' ' + l[r.end():]).strip()
        else:
            d = DATE.search(l)
            if not d: return None
            it['date'] = d.group(0).strip(); it['milestone'] = True; rest = (l[:d.start()] + ' ' + l[d.end():]).strip()
        g = re.search(r'\(([^()]{2,30})\)\s*$', rest) or re.search(r'\[([^\[\]]{2,30})\]', rest)
        if g:
            word = g.group(1).strip()
            if word.lower() in STATUS: it['status'] = STATUS[word.lower()]
            else: it['group'] = word
            rest = (rest[:g.start()] + rest[g.end():]).strip()
        st = next((v for kk, v in STATUS.items() if re.search(r'\b' + kk + r'\b', rest, re.I)), None)
        if st and 'status' not in it: it['status'] = st
        rest = re.sub(r'^[\s:—–,-]+|[\s:—–,-]+$', '', rest); rest = re.sub(r'\s*[:—–]\s*[:—–]\s*', ': ', rest)
        lab, body = split_label(rest)
        it['name'] = _words(lab or body, 7)
        if lab and body: it['text'] = body
        if groups and k < len(groups) and groups[k] and 'group' not in it: it['group'] = groups[k]
        items.append(it)
    if len(items) < 3: return None
    return {'items': items}


# ---------------------------------------------------------------- swimlane
ROLE = re.compile(r'^([A-Z][\w&/.\' -]{1,30}?)\s*(?::|—|–)\s+(.+)$')


def swimlane(lines, explicit=False):
    """A process written role by role → {'lanes', 'steps'}. "If yes, …" / "If no, …" after a question make the decision's branches;
    a question without both branches stays a task (a decision needs two). The first step starts, the last ends."""
    rows = []
    for raw in lines:
        l = plain(raw); m = ROLE.match(l)
        if not m: return None
        role, text = m.group(1).strip(), m.group(2).strip()
        if len(role.split()) > 4: return None
        rows.append((role, text))
    if len(rows) < 4: return None
    lanes = list(dict.fromkeys(r for r, _ in rows))
    if not 2 <= len(lanes) <= 6 or len(lanes) > len(rows) or (len(lanes) == len(rows) and not explicit): return None   # asked for: one step per team is a hand-off chain
    steps, last_main, dec = [], None, None
    for k, (role, text) in enumerate(rows):
        sid = f's{k + 1}'; st = {'id': sid, 'lane': role}
        br = re.match(r'^(?:if\s+)?(yes|no|not)\b[,:]?\s*(?:then\s+)?(.+)$', text, re.I)
        if br and dec is not None:
            st['label'] = 'Yes' if br.group(1).lower() == 'yes' else 'No'; st['after'] = dec['id']; text = br.group(2)
            if st['label'] == 'Yes': last_main = sid
            dec.setdefault('_branches', []).append(st['label'])
        elif last_main: st['after'] = last_main
        st['text'] = _short(text[:1].upper() + text[1:], 5)
        if st['text'].endswith('?'): st['kind'] = 'decision'; dec = st
        if 'label' not in st: last_main = sid
        steps.append(st)
    for st in steps:   # a question without a Yes and a No is a task (the engine refuses a one-branch decision)
        if st.get('kind') == 'decision' and set(st.pop('_branches', [])) != {'Yes', 'No'}: st['kind'] = 'task'
        st.pop('_branches', None)
    steps[0].setdefault('kind', 'start')
    if steps[-1].get('kind') != 'decision': steps[-1]['kind'] = 'end'
    return {'lanes': lanes, 'steps': steps}


# ---------------------------------------------------------------- template infographics
def _num_split(t):
    m = NUM.search(t)
    if not m: return None
    return m.group(0).strip(), (t[:m.start()] + t[m.end():]).strip(' :—–-,')


def _unit(v):
    """The template's big-number card reads 2.1 hrs / 6 min / 3 days, not "2.1 hours"."""
    return re.sub(r'\s?(hours?)$', ' hrs', re.sub(r'\s?(minutes?|mins)$', ' min', v, flags=re.I), flags=re.I)


def quad(lines):
    ls = [plain(l) for l in lines if plain(l)]
    if len(ls) != 4: return None
    out = []
    for l in ls:
        lab, body = split_label(l)
        if lab and NUM.match(body.strip()):   # "Net sales: $4.6M in October" → "$4.6M" over "Net sales in October"
            m_ = NUM.match(body.strip()); after = body.strip()[m_.end():]; rest = after.strip(' ,')
            cap = lab + ((', ' if after.lstrip().startswith(',') else ' ') + rest if rest else '')
            if len(cap.split()) > 6: cap = re.split(r',\s*', cap)[0] if len(re.split(r',\s*', cap)[0].split()) >= 2 else cap
            out.append(f'{_unit(m_.group(0).strip())}\n{_short(cap, 6)}'); continue
        ns = _num_split(l)
        if not ns: return None
        out.append(f'{ns[0]}\n{ns[1]}'.strip())
    return {'quad': out}


def funnel(lines):
    ls = [plain(l) for l in lines if plain(l)]
    return {'funnel': [_words(l, 14) for l in ls]} if len(ls) == 4 else None


def donut(lines, center=''):
    items, details = [], []
    for l in (plain(x) for x in lines):
        lab, body = split_label(l); m = re.search(r'(\d+(?:\.\d+)?)\s*%', body or '')
        if not lab or not m: return None
        items.append([lab, float(m.group(1))]); details.append(f'{lab}: {body}')
    if not 2 <= len(items) <= 4: return None
    tails = {re.sub(r'^.*?%\s*(?:of\s+)?', '', body or '').strip().rstrip('.') for body in (d.split(': ', 1)[1] for d in details)}
    if len(tails) == 1 and 0 < len(next(iter(tails))) <= 18: center = next(iter(tails))   # "62% of pickup orders" … → "Pickup orders"
    elif len(center) > 16: center = 'Share'
    return {'donut': {'items': items, 'unit': '%', 'center': center[:1].upper() + center[1:], 'details': details[:2]}}


def us_map(lines):
    pins = []
    for l in (plain(x) for x in lines):
        m = re.match(r'^([A-Z][A-Za-z .\'-]+,\s*[A-Z]{2})\s*(?::|—|–|-)\s*(.+)$', l)
        if not m: return None
        pins.append({'place': m.group(1), 'text': _words(m.group(2), 10)})
    return {'map': pins} if 1 <= len(pins) <= 4 else None


def _labelled(lines):
    out = []
    for l in (plain(x) for x in lines):
        lab, body = split_label(l)
        out.append(((lab or '').lower(), body))
    return out


def ogsm(lines):
    """Objective: … · Goal: … (×3) · Strategy: Title — text (×3) · Measure: Title — value — text (×3)"""
    o, g, s, m = None, [], [], []
    for lab, body in _labelled(lines):
        if lab.startswith('objective'): o = body
        elif lab.startswith('goal'): g.append(body)
        elif lab.startswith('strateg'): t, _, x = body.partition(' — '); s.append({'title': t.strip(), 'text': x.strip() or t.strip()})
        elif lab.startswith('measure'):
            p = [x.strip() for x in re.split(r'\s+—\s+|\s+\|\s+', body)]; m.append({'title': p[0], 'value': p[1] if len(p) > 1 else '', 'text': p[2] if len(p) > 2 else ''})
    if not (o and len(g) == 3 and len(s) == 3 and len(m) == 3): return None
    return {'ogsm': {'objective': o, 'goals': g, 'strategies': s, 'measures': m}}


def priorities(lines):
    """Vision: … · Goal: … (×3) · Strategy: Name — text (KPI; KPI) (×6)"""
    v, g, s = None, [], []
    for lab, body in _labelled(lines):
        if lab.startswith('vision'): v = body
        elif lab.startswith('goal'): g.append(body)
        elif lab.startswith('strateg'):
            k = re.search(r'\(([^()]+)\)\s*$', body); kp = [x.strip() for x in k.group(1).split(';')][:2] if k else []
            body = body[:k.start()].strip() if k else body; n, _, t = body.partition(' — ')
            s.append({'name': n.strip(), 'text': t.strip() or n.strip(), 'kpis': (kp + ['', ''])[:2]})
    if not (v and len(g) == 3 and len(s) == 6): return None
    return {'priorities': {'vision': v, 'goals': g, 'strategies': s}}


def scorecard(lines, groups=None):
    """KPI: prior | target | actual | status, grouped by the sub-heading above (Sales, Service …)."""
    grp, lows, highs = {}, [], []
    for k, l in enumerate(plain(x) for x in lines):
        lab, body = split_label(l)
        if lab in ('lowlight', 'lowlights', 'highlight', 'highlights'):   # (1l) the page's own notes for the two lists
            (lows if lab.startswith('low') else highs).append(body.strip()); continue
        p = [x.strip() for x in body.split('|')] if lab else []
        if len(p) < 4: return None
        g = (groups[k] if groups and k < len(groups) and groups[k] else 'KPIs')
        grp.setdefault(g, []).append([lab] + p[:4])
    n = sum(len(v) for v in grp.values())
    if not 2 <= n <= 13: return None
    if not lows and not highs:                       # (1l) else the KPIs by status: off target -> lowlights, on target -> highlights
        for row in (r for v in grp.values() for r in v):
            name, st = row[0][:1].upper() + row[0][1:], str(row[4]).strip().lower()
            (lows if st in ('red', 'amber', 'at risk', 'off track') else highs if st in ('green', 'on track', 'done') else []).append(f'{name} {row[3]} vs {row[2]} target')
    return {'scorecard': {'columns': ['Prior', 'Target', 'Actual'], 'note': 'vs target', 'groups': [{'name': g, 'kpis': v} for g, v in grp.items()],
                          'lowlights': lows[:5] or ['No measure off target'], 'highlights': highs[:5] or ['No measure on target yet']}}


# ---------------------------------------------------------------- modern charts
def _pairs(lines):
    out = []
    for l in (plain(x) for x in lines):
        lab, body = split_label(l); m = re.search(r'[-+]?\d[\d,]*(?:\.\d+)?', body or '')
        if not lab or not m: return None
        out.append((lab, float(m.group(0).replace(',', '')), body))
    return out


def modern(kind, lines):
    p = _pairs(lines)
    if not p: return None
    if kind == 'kpi' and 2 <= len(p) <= 4:
        its = []
        for lab, _, body in p:
            v = (NUM.search(body) or [body])[0]; d = re.search(r'\(([-+▲▼][^()]+)\)', body)
            its.append({'label': lab, 'value': v.strip(), **({'delta': d.group(1)} if d else {})})
        return {'items': its}
    if kind in ('ring', 'radialbar') and 1 <= len(p) <= 6: return {'items': ([{'label': l, 'value': v} for l, v, _ in p] if kind == 'ring' else [[l, v] for l, v, _ in p])}
    if kind == 'waffle' and len(p) == 1: return {'value': p[0][1], 'label': p[0][0]}
    if kind == 'gauge' and len(p) == 1:
        t = re.search(r'target\s*[:=]?\s*(\d[\d.]*)', p[0][2], re.I)
        return {'value': p[0][1], 'target': float(t.group(1)) if t else None, 'label': p[0][0], 'unit': '%' if '%' in p[0][2] else ''}
    if kind == 'bullet' and 2 <= len(p) <= 6:
        its = []
        for lab, v, body in p:
            nums = [float(x.replace(',', '')) for x in re.findall(r'\d[\d,]*(?:\.\d+)?', body)]
            if len(nums) < 2: return None
            its.append({'label': lab, 'value': nums[0], 'target': nums[1], 'max': max(nums[0], nums[1]) * 1.1})
        return {'items': its}
    if kind in ('dumbbell', 'slope') and 2 <= len(p) <= 8:
        rows = []
        for lab, v, body in p:
            nums = [float(x.replace(',', '')) for x in re.findall(r'\d[\d,]*(?:\.\d+)?', body)]
            if len(nums) < 2: return None
            rows.append([lab, nums[0], nums[1]])
        return {'from': 'Before', 'to': 'After', 'items': rows, **({'unit': '%'} if all('%' in body for _, _, body in p) else {})}
    if kind in ('lollipop', 'treemap', 'bubbles', 'rose') and 3 <= len(p) <= 14: return {'items': [[l, v] for l, v, _ in p]}
    if kind == 'sankey':
        fl = []
        for l in (plain(x) for x in lines):
            m = re.match(r'^(.+?)\s*(?:→|->)\s*(.+?)\s*:\s*([\d,.]+)', l)
            if not m: return None
            fl.append([m.group(1).strip(), m.group(2).strip(), float(m.group(3).replace(',', ''))])
        return {'flows': fl} if len(fl) >= 3 else None
    return None


# ---------------------------------------------------------------- v6.23: Presentation Central v140's retail pack
OWNER = re.compile(r'^(.*?\S)\s*\(([^()]{2,40})\)\s*$')


def retail_items(lines):
    """"Title: text (Owner)" lines → the retail pack's items: a title of up to four words, its line of detail, the owner in brackets."""
    out = []
    for l in lines:
        t = plain(l)
        if not t: continue
        owner = None
        m = OWNER.match(t)
        if m and split_label(m.group(1))[0]: t, owner = m.group(1), m.group(2).strip()
        lab, txt = split_label(t)
        if lab and len(lab.split()) > 4: lab, txt = None, t
        txt = txt[:1].upper() + txt[1:] if lab and txt[:1].islower() and not re.match(r'^[a-z]+[A-Z]', txt) else txt   # 'count list created' → 'Count list created' (eCom, iPad kept)
        d = {'title': lab or _short(t, 4), 'text': txt if lab else ('' if len(t.split()) <= 4 else t)}
        if owner: d['owner'] = owner
        out.append(d)
    return out


ROLE_KEYS = {'result': 'result', 'outcome': 'result', 'source': 'source', 'centre': 'center', 'center': 'center', 'purpose': 'center'}


def process_data(style, its):
    """Process-flow data from labelled lines: "Result: …" (converge), "Source: …" (diverge), "Centre: …" (cycle), "Input: …" / "Output: …"
    (io), "Stage: 1.2M (38%)" (pipeline: the value and the share that moves on), "Phase: a; b; c (Weeks 1-4)" (phases: activities and timing)."""
    P = {'steps': [], 'icons': 'auto'}; ins, outs = [], []
    for d in its:
        k = ROLE_KEYS.get(d['title'].strip().lower())
        if k and d.get('text'):
            t, _, x = d['text'].partition(' - ') if ' - ' in d['text'] else d['text'].partition(': ')
            x = x.strip(); x = x[:1].upper() + x[1:]
            P[k] = {'title': _short(t.strip(), 4), 'text': x or (t.strip() if len(t.split()) > 4 else '')}; continue
        if d['title'].strip().lower() in ('input', 'inputs'): ins.append({'title': _short(d['text'], 4), 'text': ''}); continue
        if d['title'].strip().lower() in ('output', 'outputs'): outs.append({'title': _short(d['text'], 4), 'text': ''}); continue
        s_ = dict(d)
        if style == 'pipeline' and re.match(r'^\d[\d.]*\s*%$', s_.get('owner') or ''): s_['rate'] = s_.pop('owner').replace(' ', '')   # "(38%)": the share that moves on
        if style == 'phases' and s_.get('owner'): s_['when'] = s_.pop('owner')                                                     # "(Weeks 1-4)": the phase's timing
        if style == 'pipeline':
            m = re.match(r'^\s*([$€£]?\d[\d,.]*\s*[kKmMbB%]?)\s*(?:\((\d[\d.]*\s*%)\))?\s*(.*)$', s_.get('text') or '')
            if m: s_.update(value=m.group(1).strip(), rate=(m.group(2) or s_.get('rate') or '').replace(' ', ''), text=m.group(3).strip())
        if style == 'phases' and ';' in (s_.get('text') or ''):
            body = s_['text']; w = re.search(r'\(([^()]{2,30})\)\s*$', body)
            if w: s_['when'] = w.group(1).strip(); body = body[:w.start()]
            body = body[:1].upper() + body[1:]
            s_['items'] = [x.strip() for x in body.split(';') if x.strip()]; s_['text'] = ''
        P['steps'].append(s_)
    if ins: P['inputs'] = ins
    if outs: P['outputs'] = outs
    if style == 'converge' and 'result' not in P and len(P['steps']) >= 3: P['result'] = P['steps'].pop()
    if style == 'diverge' and 'source' not in P and len(P['steps']) >= 3: P['source'] = P['steps'].pop(0)
    return P


def retail(hint, lines, head='', groups=None):
    """'retail <style | starter>' / 'process <style>' → ('retail' | 'process', style, data) or None. A starter with no lines of its own
    keeps its standard steps; a process starter takes the section's lines as its steps. data['_headline'] / data['_notes'] carry a
    starter's takeaway and its "add from your own data" note (page_to_spec uses them when the section's heading is only a label)."""
    import central_slides as CS
    try: RT, FL = CS.retail_engines()
    except Exception: return None
    word, _, rest = hint.partition(' ')
    st = rest.strip().replace(' ', '-')
    its = retail_items(lines)
    if word == 'process':
        P = process_data(st, its)
        if not P['steps'] or (len(P['steps']) < 2 and st != 'io'): return None   # io: one process between its inputs and outputs
        style = st if st in FL.STYLES else FL.auto_style(P)
        if style not in getattr(FL, 'ICON_STYLES', FL.STYLES): P.pop('icons', None)   # pipeline and phases have no room for pictograms
        if FL.lint({'process': P, 'style': style}):   # the content does not fit the style asked for: steps in order, every word kept
            P = {'steps': [d for d in its if d['title'].lower() not in ('result', 'outcome', 'source', 'centre', 'center', 'purpose')], 'icons': 'auto'}
            style = 'chevrons' if len(P['steps']) <= 6 else 'snake'
            if FL.lint({'process': P, 'style': style}): return None
        return 'process', style, P
    if st in RT.STARTERS:
        cs = CS.starter(st, None, its if len(its) >= 3 else None)
        fam = 'retail' if isinstance(cs.get('retail'), (dict, list)) else 'process'
        data = dict(cs[fam]) if isinstance(cs[fam], dict) else {'steps': cs[fam]}
        data['_headline'] = cs.get('headline'); data['_notes'] = cs.get('notes')
        return fam, cs.get('style'), data
    if len(its) < 2: return None
    if not st:   # "Layout: retail": the form its words call for (v140's retail-first reading), else a supply chain network
        r = RT.fit({'headline': head, 'bullets': [f"{d['title']}: {d['text']}" if d['text'] else d['title'] for d in its]})
        sp = (r or {}).get('spec') or {}
        if sp.get('retail') is not None: return 'retail', sp.get('style') or RT.auto_style(sp['retail']), sp['retail']
        if sp.get('process') is not None: return 'process', sp.get('style') or 'chevrons', sp['process']
        st = 'network'
    if st not in RT.STYLES: return None
    if st == 'network': data = {'nodes': its}
    elif st == 'dc-flow': data = {'zones': its}
    elif st == 'document-flow': data = {'documents': its}
    elif st == 'fulfilment': data = {'paths': [dict(d, promise=d.pop('owner')) if d.get('owner') else d for d in its]}
    else:   # cross-dock: sub-headings name the sources and destinations; with none, the lines are the dock's steps
        src, dst, steps = [], [], []
        for d, g in zip(its, (groups or [None] * len(its))):
            g_ = str(g or '').lower()
            (src if re.search(r'source|vendor|inbound|\bin\b', g_) else dst if re.search(r'destination|store|outbound|\bout\b', g_) else steps).append(d)
        base = RT.STARTERS['cross-dock']['retail']
        data = {'sources': src or base['sources'], 'steps': steps or base['steps'], 'destinations': dst or base['destinations'], 'dock': base.get('dock')}
    if RT.lint({'retail': data, 'style': st}): return None   # too many or too few for the style: the section keeps its usual layout
    return 'retail', st, data


def retail_first(head, lines):
    """No "Layout:" line (v140's "retail first"): a list that names vendors, DCs, stores and guests in order, a DC's zones, the documents of
    a process or the ways an order reaches the guest becomes that retail diagram, every word kept. Only labelled lists ("Title: text"),
    3-6 of them, so ordinary decks never change shape. None otherwise."""
    ls = [plain(l) for l in lines if plain(l)]
    if not 3 <= len(ls) <= 6 or not all(split_label(l)[0] for l in ls): return None
    import central_slides as CS
    try: RT, FL = CS.retail_engines()
    except Exception: return None
    try: r = RT.fit({'headline': head, 'bullets': ls})
    except Exception: return None
    sp = (r or {}).get('spec') or {}
    if sp.get('retail') is not None and r.get('form') in RT.STYLES: return 'retail', sp.get('style') or r['form'], sp['retail']
    return None


# ---------------------------------------------------------------- the router
INFO = {'quad': quad, 'big numbers': quad, 'four numbers': quad, 'template funnel': funnel, 'donut': donut, 'share': donut, 'us map': us_map,
        'map': us_map, 'ogsm': ogsm, 'priorities': priorities, 'priorities house': priorities, 'scorecard': scorecard, 'kpi scorecard': scorecard}
MODERN = {'kpi': 'kpi', 'kpi cards': 'kpi', 'rings': 'ring', 'ring': 'ring', 'progress rings': 'ring', 'gauge': 'gauge', 'bullet': 'bullet',
          'bullet chart': 'bullet', 'lollipop': 'lollipop', 'ranking': 'lollipop', 'treemap': 'treemap', 'bubbles': 'bubbles', 'rose': 'rose',
          'radial bars': 'radialbar', 'radialbar': 'radialbar', 'waffle': 'waffle', 'dumbbell': 'dumbbell', 'before after': 'dumbbell',
          'slope': 'slope', 'sankey': 'sankey'}


def from_hint(hint, lines, head='', groups=None):
    """'timeline quarters' / 'gantt' / 'swimlane handoffs' / 'process map' / 'scorecard' / 'kpi cards' … → (family, style, data) or None."""
    import central_slides as CS
    h = re.sub(r'\s+', ' ', str(hint or '').strip().lower())
    if not h: return None
    ST = CS.styles()
    if h == 'retail' or h.startswith(('retail ', 'process ')) or h == 'process':   # v6.23
        return retail(h if ' ' in h else h + ' ', lines, head, groups)
    for fam, words in (('timeline', ('timeline', 'gantt', 'roadmap', 'plan')), ('swimlane', ('swimlane', 'swim lane', 'process map', 'cross-functional', 'cross functional'))):
        w = next((x for x in words if h == x or h.startswith(x + ' ')), None)
        if not w: continue
        style = h[len(w):].strip().replace(' ', '-') or None
        if w == 'gantt': style = style or 'lanes'
        if fam == 'timeline' and w in ('roadmap', 'plan', 'timeline') and not style and not any(RANGE.search(plain(l)) for l in lines): return None   # the Studio's own roadmap / timeline
        if style and style not in ST[fam] and ('template-' + style) not in ST[fam]: style = None
        elif style and style not in ST[fam]: style = 'template-' + style
        data = timeline(lines, groups) if fam == 'timeline' else swimlane(lines, explicit=True)
        return (fam, style, data) if data else None
    if h in INFO:
        f = INFO[h]
        data = f(lines, head) if f is donut else f(lines, groups) if f is scorecard else f(lines)
        return ('infographic', next(iter(data)), data) if data else None
    if h in MODERN:
        data = modern(MODERN[h], lines)
        return ('modern', MODERN[h], data) if data else None
    return None


def auto(head, lines, groups=None):
    """No "Layout:" line: a dated list with a date range → a timeline; a process section written "Role: step" → a swimlane. Else None."""
    ls = [l for l in lines if plain(l)]
    if 3 <= len(ls) <= 14 and any(RANGE.search(plain(l)) for l in ls):
        d = timeline(ls, groups)
        if d: return ('timeline', None, d)
    if 4 <= len(ls) <= 16:
        d = swimlane(ls)   # a process heading, or a long run (6+ steps, 3+ roles) that can only be a cross-functional process
        if d and max(sum(1 for s in d['steps'] if s['lane'] == ln) for ln in d['lanes']) >= 2 \
                and (PROCESS_HEAD.search(head or '') or (len(d['steps']) >= 6 and len(d['lanes']) >= 3)): return ('swimlane', None, d)
    if groups and any(groups): return None   # sub-headed cards stay cards: the shapes below read one plain list
    rf = retail_first(head, ls)   # v6.23: retail first - goods, documents or orders moving through the chain become the retail diagram
    if rf: return rf
    return numbers(head, ls)


def numbers(head, ls):
    """A plain list whose shape is numeric — the deterministic charts (no AI): pins, shares, flows, before → after, big numbers, a ranking."""
    P = [split_label(plain(l)) for l in ls]
    if not all(lab for lab, _ in P): return None
    n = len(P)
    if 1 <= n <= 4 and all(re.match(r'^[A-Z][A-Za-z .\'-]+,\s*[A-Z]{2}$', lab) for lab, _ in P):
        d = us_map(ls); return ('infographic', 'map', d) if d else None
    pct = [re.match(r'^(\d+(?:\.\d+)?)\s*%', b) for _, b in P]
    if 2 <= n <= 4 and all(pct) and 95 <= sum(float(m.group(1)) for m in pct) <= 105:
        d = donut(ls, head); return ('infographic', 'donut', d) if d else None
    if n >= 3 and all(re.search(r'(?:→|->)', lab + ' ' + b) for lab, b in P):
        d = modern('sankey', ls)
        if d: return ('modern', 'sankey', d)
    if 3 <= n <= 8 and all(re.match(r'^[-+]?[$€£]?\d[\d,.]*\s*%?\s*(?:→|->|to)\s*[-+]?[$€£]?\d[\d,.]*\s*%?$', b) for _, b in P):
        d = modern('dumbbell', ls)
        if d: return ('modern', 'dumbbell', dict(d, **{'from': 'Before', 'to': 'Now'}))
    lead = [NUM.match(b.strip()) for _, b in P]
    if all(lead):
        if n == 4: d = quad(ls); return ('infographic', 'quad', d) if d else None
        if n == 2 or (n == 3 and any(len(b) > 24 for _, b in P)):   # three short ones are the template's big-number slide (9)
            d = modern('kpi', ls); return ('modern', 'kpi', d) if d else None
        # no automatic ranking: "Profiles live: 12 / p95 latency: 240 ms / Coverage: 87%" are different measures, not a league table —
        # a lollipop only when the author asks ("Layout: ranking")
    return None


LABEL_HEAD = re.compile(r'^\s*\S+(?:\s+\S+){0,3}\s*$')


def is_label(head):
    """A topic label ("Delivery plan", "Q3 results"): four words or fewer, no number, no verb — Presentation Central v92 asks for the takeaway."""
    h = str(head or '').strip()
    figures = re.sub(r'\b(?:Q[1-4]|H[12]|FY\s?\d{2,4}|(?:19|20)\d{2})\b', '', h, flags=re.I)   # a period (Q3, FY26, 2026) is not a figure
    return bool(LABEL_HEAD.match(h)) and not re.search(r'\d', figures) and not re.search(r'\b(is|are|was|were|will|has|have|grew|fell|rose|leads?|beat|missed|up|down)\b', h, re.I)


def takeaway(fam, style, data, head):
    """A takeaway headline computed from the slide's own data (no AI, no invented fact), kept with the author's words in front:
    "Delivery plan: 2 teams, 5 tasks, go-live Sep 1". None when the data has nothing countable or the headline already says it."""
    if not is_label(head): return None
    h = str(head).strip().rstrip(':'); say = None
    try:
        if fam == 'timeline':
            its = data.get('items') or []; groups = {i.get('group') for i in its if i.get('group')}
            tasks = [i for i in its if not i.get('milestone')]; ms = [i for i in its if i.get('milestone')]
            parts = ([f'{len(groups)} teams'] if len(groups) > 1 else []) + ([f'{len(tasks)} tasks'] if tasks else [])
            if ms:
                when = re.sub(r',? *\d{4}$', '', ms[-1]['date']); what = ms[-1]['name'].lower() if len(ms[-1]['name']) <= 24 else 'milestone'   # Python 3.10/3.11: no backslash inside f-string braces
                parts.append(f'{what} {when}')
            say = ', '.join(parts)
        elif fam == 'swimlane':
            st = data.get('steps') or []; dec = sum(1 for x in st if x.get('kind') == 'decision')
            say = f'{len(st)} steps, {len(data.get("lanes") or [])} teams' + (f', {dec} decision' + ('s' if dec > 1 else '') if dec else '')
        elif fam == 'infographic' and style == 'donut':
            it = max(data['donut']['items'], key=lambda x: x[1]); c = data['donut'].get('center') or ''
            say = f'{it[0]} {"is" if not it[0].endswith("s") else "are"} {it[1]:g}% of {c.lower() or "the total"}'
        elif fam == 'infographic' and style == 'quad':
            c = [x.split('\n', 1) for x in data['quad'][:2]]
            say = ', '.join(f'{v} {re.split(r",", t)[0].strip().lower()}' for v, t in c if t)
        elif fam == 'modern' and style == 'dumbbell':
            it = max(data['items'], key=lambda r: r[2] - r[1]); u = data.get('unit') or ''
            say = f'{it[0]} gained most, {it[1]:g}{u} to {it[2]:g}{u}'
        elif fam == 'modern' and style == 'lollipop':
            it = max(data['items'], key=lambda r: r[1]); say = f'{it[0]} leads at {it[1]:g}'
    except Exception:
        return None
    if not say: return None
    out = f'{h}: {say}'
    return out if len(out) <= 42 else (say[:1].upper() + say[1:] if len(say) <= 42 else None)   # (1o) one line at 36 pt
