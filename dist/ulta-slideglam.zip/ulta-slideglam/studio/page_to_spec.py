#!/usr/bin/env python3
"""Rule-based Confluence page -> storyboard spec (no LLM). Good enough for status/steering decks;
Rovo (or a person) can edit the JSON before building.

  page_to_spec.py page.md  --out spec.json [--template STANDARD33] [--title "Deck title"] [--source-url URL]
  page_to_spec.py page.html --out spec.json          # Confluence storage/export HTML also accepted

Mapping rules (STANDARD33):
  page title          -> slide 1 cover
  H1 list (>1, <=5)   -> slide 2 agenda; each H1 -> slide 5 divider (a single H1 gets neither)
  H2                  -> slide headline; H3/H4 + their text -> "cards" (bold heading + lines) packed into the
                         two boxes of slide 6 (~14 lines each); overflow continues on "(cont.)" slides
  web-UI text ("click the block below…") and boiler-plate ("Proprietary & Confidential") are dropped
  table 3 cols        -> slide 12 (What / Description / When-Who), chunked 4 data rows per slide
  table 2-3 cols, 1 data row -> slide 9 (three metrics)
  other tables <=6 cols -> slide 14, chunked 3 data rows per slide; wider tables -> first 6 columns + warning
  end                 -> slide 32 closing
Every slide gets speaker notes: "Source: <page title> [<url>] — section <heading>".
--max-slides N fits the deck by compaction (LADDER: appendix off, tables packed, small sections as cards, fuller boxes,
no dividers, cells clipped, more merging, two bullets a paragraph) — never a mid-section cut; whole trailing sections are
dropped and named only when every step is exhausted. Every slide carries 'sec' (its outline heading) and 'fill' (0–1).
"""
import argparse, html, json, os, re, sys

_SD_ERR = []   # v6.12: the diagram module failing to load is said out loud (it was skipped silently, and architecture sections vanished)


def _load_sd():
    """diagram/slide_diagram.py, or raise after noting why — the spec's warnings then say diagrams were not drawn."""
    try:
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'diagram')); import slide_diagram
        return slide_diagram
    except Exception as e:   # noqa: BLE001
        if not _SD_ERR: _SD_ERR.append(f'{type(e).__name__}: {e}')
        raise
from html.parser import HTMLParser


# ------------------------------------------------------------------ parse markdown / html into blocks
GLYPHS = ('• ', '– ', '✓ ', '✗ ', '→ ', '◦ ', '▪ ')   # line markers the builder renders as-is (✓ → in the accent colour)


PAGE_CHROME = re.compile(r'^(?:by [A-Z][\w.\- ]{1,40}|\d+ min(?:ute)?s?(?: read)?|listen|\d{1,3}|add a reaction|.*no workflow applied.*|app icon.*|tasks in table view|share|edit|watch|save for later|jump to\.{0,3}|like|comment|\d+ (?:likes?|comments?|views?))$', re.I)
COLUMN_WORDS = re.compile(r'\b(?:name|description|method|calculation|required|data|owner|comments?|role|status|notes?|date|priority|area|type|value|definition|source|target|metric|kpi|relevance|integration|responsibility)\b', re.I)
RECOVERY = {}
META_KEYS = re.compile(r'^(document title|title|author|authors?|owner|prepared by|date|last updated|status|version|reviewers?|approvers?|audience|classification|target systems|systems in scope|scope|page owner)\s*:\s*\S', re.I)
LATEX_ARROW = {r'\rightarrow': '→', r'\to': '→', r'\leftarrow': '←', r'\Rightarrow': '⇒', r'\leftrightarrow': '↔', r'\uparrow': '↑', r'\downarrow': '↓', r'\times': '×'}


TABLE_HEAD = re.compile(COLUMN_WORDS.pattern[:-3] + r'|dimension|option|capability|contribution|platform|system|team|responsibilit\w*|purpose|impact|risk|mitigation|feature|criteria|requirement|step|phase|scope|benefit|today|current|future|target state|pros?|cons?)\b', re.I)


TABLE_CORNER = re.compile(r'\b(dimension|capabilit\w*|source|system|team|platform|area|item|criteri\w*|component|feature|option|aspect|attribute|category|step|phase|risk|role|application|interface|object|process|scenario|requirement|parameter|field|topic|question|domain|layer|stage)s?\b', re.I)


CHAIN_LABEL = re.compile(r'^(.{3,50}?\b(?:path|flow|pipeline|journey|route|lifecycle|process))\s+(?=[A-Z0-9])(.{2,})$')


def unflatten_tables(lines):
    """A table pasted as one cell per line ("Dimension / Option 1 / Option 2 / Inventory Ownership / … / …") is a table again:
    a corner cell, k column headings, then rows of a short label and k values. Only when it repeats cleanly (3+ rows, every label
    short, the values longer than the labels) and ends where the cells end — otherwise the lines stay as written."""
    lab = lambda x: 0 < len(x) <= 45 and len(x.split()) <= 7 and x[:1].isupper() and not x.endswith(('.', ':', ';', ',')) and not re.match(r'^(\d|[-*•|#>`])', x)
    cell = lambda x: bool(x) and len(x) <= 400 and not re.match(r'^(#{1,6}\s|[-*•]\s|\||```)', x) and not re.match(r'^\d+(\.\d+)*\.?\s+[A-Z]', x)
    # a page copied as text puts a blank line between every line: the cells are read on the non-blank lines, the blanks between them are not a break
    nbk = [k for k, l in enumerate(lines) if l.strip()]
    if len(nbk) >= 8 and sum(1 for a_, b_ in zip(nbk, nbk[1:]) if b_ - a_ == 2) >= 0.5 * len(nbk):
        dense = [lines[k] for k in nbk]; got = unflatten_tables(dense)
        if got != dense:   # a table was found: rebuild with the original blank lines kept around everything that is not a table row
            out_, pos_ = [], 0
            for l in got:
                if l.startswith('| ') or l.startswith('|---') or l == '': out_.append(l); continue
                while pos_ < len(lines) and lines[pos_].strip() != l.strip(): pos_ += 1
                out_ += [l, '']; pos_ += 1
            return out_
        return lines
    out, i, n = [], 0, len(lines)
    while i < n:
        s = lines[i].strip(); best = None
        if lab(s) and not any(lines[i - j].strip() == s for j in range(1, 9) if i - j >= 0):   # a heading just above the corner cell is fine (3+ clean rows decide); a header pasted twice (sticky header) is not rebuilt
            for k in (2, 3, 4):
                hdr = [lines[i + 1 + j].strip() for j in range(k) if i + 1 + j < n]
                if len(hdr) < k or not all(cell(h) and len(h) <= 120 and not h.endswith('.') for h in hdr): continue
                rows, p = [], i + 1 + k
                rowlab = lambda x: lab(x) and ',' not in x   # a row label is a name ("Rithum", "SAP S/4HANA"); "Roles, contacts, and governance" is the next heading
                while p + k < n + 0 and p < n and rowlab(lines[p].strip()) and all(p + 1 + j < n and cell(lines[p + 1 + j].strip()) for j in range(k)):
                    rows.append([lines[p].strip()] + [lines[p + 1 + j].strip() for j in range(k)]); p += k + 1
                if len(rows) < 3: continue
                nxt = lines[p].strip() if p < n else ''
                if nxt and rowlab(nxt) and all(p + 1 + j < n and cell(lines[p + 1 + j].strip()) for j in range(k)): continue   # one more whole row would fit: the rhythm is off, not this k
                vals = [len(c) for r in rows for c in r[1:]]; labs_ = [len(r[0]) for r in rows]
                if sum(vals) / len(vals) < 1.3 * sum(labs_) / len(labs_): continue
                heads_ = [s] + hdr
                if not (TABLE_CORNER.search(s) and len(s.split()) <= 4 and not re.match(r'^(define|build|manage|help|create|configure|standardize|ensure|provide|support|own|run|set|use|make|add|review|track|deliver|enable|drive)\b', s, re.I)) or not any(TABLE_HEAD.search(h_) for h_ in hdr + [s]): continue   # the corner names the rows ("Dimension", "Source or platform", "System or team"); a line of content ("Define KPI data lineage") does not
                if any(c.strip().lower() in {h_.strip().lower() for h_ in heads_} for r in rows for c in r): continue   # a row repeating a heading: the columns are misread
                if len({h_.strip().lower() for h_ in heads_}) != len(heads_) or any(PAGE_CHROME.match(h_) or re.match(r'^(edit|share|listen|updated\b|by\s|\d+\s*min)', h_.strip(), re.I) for h_ in heads_): continue   # page furniture, or a repeated heading
                lastv = [len(r[-1]) for r in rows]; hl = sum(len(h_) for h_ in heads_) / len(heads_)
                if sum(lastv) / len(lastv) < 1.3 * hl: continue   # the last column describes (longer than its headings); a list of short items read in fours is not a table
                if best is None or len(rows) > len(best[1]): best = ([s] + hdr, rows, p)
        if best:
            hdr, rows, p = best; esc_ = lambda c: c.replace('|', '/')
            out += ['', '| ' + ' | '.join(esc_(c) for c in hdr) + ' |', '|' + '---|' * len(hdr)] + ['| ' + ' | '.join(esc_(c) for c in r) + ' |' for r in rows] + ['']
            i = p; continue
        out.append(lines[i]); i += 1
    return out


def normalize_paste(text):
    """A document pasted as text from Word, Google Docs, Confluence or an AI chat: LaTeX arrows ($\rightarrow$) become →, link
    syntax keeps its words, the metadata block under the title (Author, Date, Status …) goes to the notes, tables pasted one cell
    per line become tables, and draw.io XML becomes the diagram it draws. Plain Markdown passes through unchanged."""
    def mx(m):
        try:
            _sd = _load_sd()
            d = _sd.from_drawio(m.group(0))
        except Exception: d = None   # noqa: BLE001
        return ('\n```diagram\n' + json.dumps(d, ensure_ascii=False) + '\n```\n') if d else '\n'
    text = re.sub(r'```[ \t]*\n\s*```[ \t]*(?=\n)', '', text)          # empty code fences left around the XML
    text = re.sub(r'(?:```[a-z]*[ \t]*\n\s*)?(?:<\?xml[^>]*>\s*)?<mxfile\b.*?</mxfile>(?:\s*\n```[ \t]*(?=\n))?', mx, text, flags=re.S)
    text = re.sub(r'(?:```[a-z]*[ \t]*\n\s*)?(?:<\?xml[^>]*>\s*)?<mxGraphModel\b.*?</mxGraphModel>(?:\s*\n```[ \t]*(?=\n))?', mx, text, flags=re.S)
    text = re.sub(r'(?m)^.*\b(paste|copy|import) (the|this) (following )?(draw\.io )?(xml|code|json)\b.*$\n?', '', text, flags=re.I)
    for k, v in LATEX_ARROW.items(): text = text.replace('$' + k + '$', v).replace('$ ' + k + ' $', v)
    text = re.sub(r'\[\[([^\]]+)\]\([^)]*\)\]', r'\1', text)            # [[draw.io](http://draw.io/)]
    text = re.sub(r'(?<!!)\[([^\]\n]{1,80})\]\((?:https?://|mailto:)[^)\s]*\)', r'\1', text)   # [ULTA.com](http://ulta.com/) → ULTA.com
    text = re.sub(r'\s*\((?:draw\.io\s*)?XML\)', '', text)
    lines = text.split('\n')
    # the metadata block under the first line: provenance for the notes, not slide text
    nbi = [i for i, l in enumerate(lines) if l.strip()]
    if len(nbi) > 3:
        j = 1
        while j < len(nbi) and META_KEYS.match(lines[nbi[j]].strip()): j += 1
        if j >= 3:
            for i in nbi[1:j]: lines[i] = '> ' + lines[i].strip()
    # one cell per line → table, outside code fences only
    out, buf, fence = [], [], False
    for l in lines:
        if l.strip().startswith('```'):
            if not fence: out += unflatten_tables(buf); buf = []
            fence = not fence; out.append(l); continue
        (out if fence else buf).append(l)
    out += unflatten_tables(buf)
    return '\n'.join(out)


def recover_structure(text):
    """Plain text pasted from a page (Confluence, a wiki, a PDF) has lost its structure: numbered headings read as list items, page
    chrome ("By …", "6 min", "Listen") sits in the body, tables arrive as one cell per line. Deterministic recovery, only when the text
    carries no Markdown headings or tables: chrome dropped; "1. Intro" / "2.1 Detail" / "A. Question" become headings (a numbered
    line followed by the next number is a list, not a heading); the first short line is the title; a run of column labels ("KPI Name /
    Description / Method / Required Data") is dropped; a short title line followed by a long one becomes a card; a lone group word
    ("Governance", "Cost") before such cards becomes a sub-heading; runs of short lines become bullets."""
    lines = [l.rstrip() for l in text.split('\n')]
    hd = next((i for i, l in enumerate(lines) if re.match(r'^#{1,6}\s', l)), None)
    if hd is not None:   # Markdown headings: only a plain-text front (a document whose first sections lost their headings) is recovered
        front = [l for l in lines[:hd] if l.strip()]
        if len(front) < 12 or not any(re.match(r'^\d+(\.\d+)*\.?\s+[A-Z]', l.strip()) for l in front): return text
        return recover_structure('\n'.join(lines[:hd])) + '\n' + '\n'.join(lines[hd:])
    infence = False; keep = set()
    for i, l in enumerate(lines):   # lines recovery never touches: code fences (box art), lists, tables, quotes, art
        if l.strip().startswith('```'): infence = not infence; keep.add(i); continue
        if infence or l.lstrip().startswith(('|', '- ', '* ', '> ', '+ ')) or ART_CH.search(l) or (l[:1].isspace() and l.strip()): keep.add(i)
    nb = [(i, l.strip()) for i, l in enumerate(lines) if l.strip() and i not in keep]
    if len(nb) < 6: return text
    label = lambda t: len(t) <= 40 and len(t.split()) <= 5 and t[0].isupper() and not t.endswith(('.', ':', ';', ',', '?', '!')) and not re.match(r'^\d', t)
    short = lambda t: len(t) <= 60 and len(t.split()) <= 8 and t[0].isupper() and not t.endswith(('.', ';', ',', ':', '?', '!')) and not t.startswith(('•', '-', '–'))
    longl = lambda t: len(t) >= 60 or t.endswith(('.', '!', '?'))
    num_head = re.compile(r'^(\d+(?:\.\d+)*)\.?\s+([A-Z(].{2,104})$'); let_head = re.compile(r'^([A-Z])\.\s+([A-Z].{3,70})$')
    # only a page carries this structure: an essay or a post (no numbered headings, no chrome, no pasted table header) is left exactly as written
    signals = sum(1 for _, t in nb if PAGE_CHROME.match(t)) + sum(1 for _, t in nb if (num_head.match(t) or let_head.match(t)) and len(t.split()) <= 16 and not t.endswith(('.', ',', ';')))
    runs = 0; k = 0
    while k < len(nb):
        r = 0
        while k + r < len(nb) and label(nb[k + r][1]) and COLUMN_WORDS.search(nb[k + r][1]): r += 1
        if r >= 3: runs += 1
        k += max(1, r)
    RECOVERY.update(signals=signals, header_runs=runs, chrome=0, headings=0, cards=0, headers=[])
    if signals + 2 * runs < 2: return text
    out = {}   # index -> replacement text (None = drop)
    k = 0; title_done = False; first_heading_seen = False
    while k < len(nb):
        i, t = nb[k]; nxt = nb[k + 1][1] if k + 1 < len(nb) else ''
        if PAGE_CHROME.match(t): out[i] = None; RECOVERY['chrome'] = RECOVERY.get('chrome', 0) + 1; k += 1; continue
        m = num_head.match(t)
        if m and len(t.split()) <= 16 and not t.endswith(('.', ',', ';')):
            n = m.group(1); parts = n.split('.'); nn = nxt and re.match(r'^(\d+(?:\.\d+)*)\.?\s', nxt)
            near = k + 1 < len(nb) and nb[k + 1][0] - i <= 2   # "1. … / 2. …" on the next line (or after one blank) is a list; a heading's next number comes sections later
            is_list = near and bool(nn and nn.group(1).split('.')[0].isdigit() and len(parts) == 1 and int(nn.group(1).split('.')[0]) == int(parts[0]) + 1 and len(nn.group(1).split('.')) == 1)
            if not is_list: out[i] = ('## ' if len(parts) == 1 else '### ') + m.group(2).strip().rstrip(':'); first_heading_seen = True; k += 1; continue
        m = let_head.match(t)
        if m and short(t) or (m and len(t) <= 70):
            out[i] = '### ' + m.group(2).strip().rstrip(':'); first_heading_seen = True; k += 1; continue
        if not title_done and not first_heading_seen and k == 0 and 12 <= len(t) <= 110 and len(t.split()) <= 14 and t[0].isupper() and not t.endswith(('.', ';', ',', ':')):
            out[i] = '# ' + t; title_done = True; k += 1; continue
        run = []
        while k + len(run) < len(nb) and label(nb[k + len(run)][1]) and COLUMN_WORDS.search(nb[k + len(run)][1]): run.append(nb[k + len(run)])
        if len(run) >= 3:
            for j, _ in run: out[j] = None   # a run of column labels ("KPI Name / Description / Method / Required Data"): the table header pasted as lines
            RECOVERY.setdefault('headers', []).extend(x for _, x in run)
            k += len(run); continue
        nn = nb[k + 2][1] if k + 2 < len(nb) else ''
        gm = re.match(r'^([A-Z][\w &/-]{1,24}):\s+(.{6,60})$', t)
        if gm and not longl(t) and nxt and short(nxt) and nn and (longl(nn) or re.fullmatch(r'\(\w{3,20}\)', nn)):
            out[i] = '### ' + t; k += 1; continue   # "Speed: how quickly we deliver value" above a run of cards: a group heading
        if short(t) and nxt and (longl(nxt) or (re.fullmatch(r'\(\w{3,20}\)', nxt) and nn and longl(nn))):
            adv = ''
            if re.fullmatch(r'\(\w{3,20}\)', nxt): adv = ' ' + nxt; out[nb[k + 1][0]] = None
            out[i] = '#### ' + t + adv; RECOVERY['cards'] = RECOVERY.get('cards', 0) + 1; k += 1 + (1 if adv else 0); continue
        n4 = nb[k + 3][1] if k + 3 < len(nb) else ''
        if len(t.split()) <= 2 and t[0].isupper() and not t.endswith(('.', ':')) and nxt and short(nxt) and nn and (longl(nn) or (short(nn) and n4 and longl(n4))) and not re.match(r'^\d', t) and not gm:
            out[i] = '### ' + t; k += 1; continue   # a group word ("Governance", "Cost") above a card or a task / owner / comment row
        if short(t) and nxt and short(nxt) and nn and longl(nn) and not longl(t):
            out[i] = '#### ' + t; out[nb[k + 1][0]] = nxt; k += 2; continue   # a table row pasted as task / owner / comment: the task is the card, owner and comment its lines
        if short(t) and nxt and short(nxt) and not longl(t):
            j = k
            while j < len(nb) and short(nb[j][1]) and not longl(nb[j][1]) and not num_head.match(nb[j][1]) and not let_head.match(nb[j][1]):
                n2 = nb[j + 1][1] if j + 1 < len(nb) else ''; n3 = nb[j + 2][1] if j + 2 < len(nb) else ''
                if j > k and n2 and (longl(n2) or (short(n2) and n3 and longl(n3))): break   # the next card starts here
                out[nb[j][0]] = '- ' + nb[j][1]; j += 1
            k = j; continue
        k += 1
    # a recovered title with two or more lines under it is a section, not a card ("Scope and operating model", "Operational controls …")
    nbi = [i for i, _ in nb]; promote = []
    for k, i in enumerate(nbi):
        if isinstance(out.get(i), str) and out[i].startswith('#### '):
            body = 0
            for j in nbi[k + 1:]:
                if isinstance(out.get(j), str) and out[j].startswith('#'): break
                if out.get(j, '') is None: continue
                body += 1
            if body >= 2: promote.append(i)
    if len(promote) <= 12:   # a dozen-plus look-alike titles is a catalogue of cards (KPIs, items), not the page's sections
        for i in promote: out[i] = '## ' + out[i][5:]
    # short lines after a line that ends with ':' ("Six principal source streams contribute …:") are its list
    for k, (i, tx) in enumerate(nb):
        if i in out or not tx.endswith(':') or len(tx) > 160: continue
        run = []
        for j, ty in nb[k + 1:]:
            if j in out or len(ty) > 110 or ty.endswith(':') or re.match(r'^[A-Z][\w &/-]{1,30}:\s', ty): break
            run.append(j)
        if len(run) >= 2:
            for j in run: out[j] = '- ' + lines[j].strip()
    res = []
    for i, l in enumerate(lines):
        if i in out:
            if out[i] is None: continue
            if out[i].startswith('- '):
                while res and res[-1] == '' and len(res) >= 2 and res[-2].startswith('- '): res.pop()   # bullets stay one list
                res.append(out[i])
            else: res += ['', out[i], '']
        else: res.append(l)
    return '\n'.join(res)


CONTRAST_A = re.compile(r'\b(today|current|as[- ]is|before|now|problem|challenge|issue|pain|risks?|gaps?|from|old|manual|legacy|recommendation|option a|why)\b', re.I)
CONTRAST_B = re.compile(r'\b(target|future|to[- ]be|after|next|solution|response|mitigations?|fix|to|new|automated|proposed|recommended|option b|how|model)\b', re.I)
DIAGRAM_STYLES = ('bands', 'outline', 'pastel', 'icons', 'midnight', 'numbered', 'cake', 'hub', 'chevron', 'bubbles', 'sequence', 'matrix', 'zones', 'tech', 'radial', 'tree', 'cloud', 'funnel', 'pyramid', 'stairs', 'milestones', 'quadrant', 'venn', 'target', 'honeycomb')
DIAGRAM_NAMES = {'auto': 'auto', 'funnel': 'funnel', 'pyramid': 'pyramid', 'staircase': 'stairs', 'stairs': 'stairs', 'steps up': 'stairs', 'timeline': 'milestones', 'milestones': 'milestones', 'roadmap': 'milestones', 'quadrant': 'quadrant', '2x2': 'quadrant', '2×2': 'quadrant', 'quadrant 2×2': 'quadrant', 'venn': 'venn', 'target': 'target', 'bullseye': 'target', 'honeycomb': 'honeycomb', 'hexagons': 'honeycomb', 'cloud': 'cloud', 'cloud reference': 'cloud', 'reference architecture': 'cloud', 'architecture guide': 'cloud', 'gcp': 'cloud', 'google cloud': 'cloud', 'ulta': 'bands', 'ulta bands': 'bands', 'bands': 'bands', 'outline': 'outline', 'minimal': 'outline', 'pastel': 'pastel', 'soft': 'pastel',
                 'icon cards': 'icons', 'icons': 'icons', 'midnight': 'midnight', 'dark': 'midnight', 'numbered flows': 'numbered', 'numbered': 'numbered',
                 'layer cake': 'cake', 'cake': 'cake', 'layers': 'cake', 'tiers': 'cake', 'hub & spoke': 'hub', 'hub and spoke': 'hub', 'hub': 'hub',
                 'chevron pipeline': 'chevron', 'chevron': 'chevron', 'chevrons': 'chevron', 'pipeline': 'chevron', 'bubbles': 'bubbles', 'circles': 'bubbles',
                 'sequence': 'sequence', 'sequence diagram': 'sequence', 'interface matrix': 'matrix', 'matrix': 'matrix', 'zones': 'zones', 'landscape': 'zones',
                 'technical shapes': 'tech', 'technical': 'tech', 'shapes': 'tech', 'radial': 'radial', 'ring': 'radial', 'fan-out tree': 'tree', 'fan out tree': 'tree', 'tree': 'tree', 'fan-out': 'tree'}
DIAGRAM_STYLE = 'auto'   # the deck's default for diagram slides (--diagram-style); a section's "Diagram style: …" line or Layouts pick overrides it
LAYOUT_KINDS = tuple('diagram-' + s for s in DIAGRAM_STYLES) + ('text', 'cards', 'steps', 'flow', 'table', 'bands', 'funnel', 'pyramid', 'cycle', 'timeline', 'matrix', 'hub', 'roadmap', 'hexagons')
LAYOUT_ALIAS = {'2x2': 'matrix', 'quadrants': 'matrix', 'quadrant': 'matrix', 'process': 'steps', 'phases': 'roadmap', 'milestones': 'timeline',
                'loop': 'cycle', 'hub and spoke': 'hub', 'honeycomb': 'hexagons', 'comparison': 'bands', 'before/after': 'bands', 'two columns': 'bands',
                'three cards': 'cards', 'label table': 'table', 'bullets': 'text', 'auto': 'auto'}


def family_hint(k):
    """Is this "Layout:" value one of Presentation Central's families (timelines, swimlanes, template infographics, modern charts; v6.23:
    retail diagrams and starters, process flows)?"""
    import family_rules as FR
    k = str(k or '').strip().lower()
    if k in FR.INFO or k in FR.MODERN: return True
    if re.match(r'^(retail( [a-z0-9 -]+)?|process (chevrons|arrow|numbered|cycle|snake|vertical|phases|pipeline|io|converge|diverge|list|rows))$', k): return True   # v6.23: v140's retail pack
    return bool(re.match(r'^(gantt|timeline [a-z -]+|roadmap [a-z -]+|swim ?lanes?( [a-z -]+)?|process map|cross[- ]functional( [a-z -]+)?)$', k))


def promote_subheads(blocks):
    """v6.22 — a page with no main headings but two or more sub-headings (an answer engine's "Key Concepts", "Management & Tools"):
    the sub-headings are its sections — a slide each — not cards squeezed under one title."""
    lv = [b[1] for b in blocks if b[0] == 'h']
    if not lv or min(lv) <= 2 or sum(1 for x in lv if x == 3) < 2: return blocks
    return [(b[0], b[1] - 1) + tuple(b[2:]) if b[0] == 'h' else b for b in blocks]


CITE = re.compile(r'\s*\[\s*\d{1,3}(?:\s*[,–-]\s*\d{1,3})*\s*\]')   # "[1]", "[1, 2, 5]", "[3–4]": an answer engine's citation markers


def strip_citations(blocks):
    """v6.22 — citation markers ("… sequence. [1, 2, 3]") are not slide text: they leave every block (the sources stay in the page's notes)."""
    out = []
    for b in blocks:
        if b[0] in ('p', 'h'):
            t = CITE.sub('', b[-1]).strip()
            if t: out.append(b[:-1] + (t,))
        elif b[0] == 'ul':
            its = [CITE.sub('', x).strip() if isinstance(x, str) else x for x in b[1]]
            its = [x for x in its if not isinstance(x, str) or x]
            if its: out.append((b[0], its) + tuple(b[2:]))
        elif b[0] == 'table':
            out.append((b[0], [[CITE.sub('', c).strip() if isinstance(c, str) else c for c in r] for r in b[1]]) + tuple(b[2:]))
        else: out.append(b)
    return out


NARR = {}   # {section headline: narration} from "Narration:" lines, attached to the spec after the build


def layout_lines(blocks):
    """'Layout: funnel' on its own line under a heading — the infographic a storyboard asks for (a person, AI Studio's model, the
    Studio's AI). Taken out of the text and returned as {heading: layout}; the builder still checks that the content fits the shape and
    falls back when it does not."""
    hints, out, head = {}, [], None; NARR.clear()
    for b in blocks:
        if b[0] == 'h':
            head = b[2].strip() if b[1] <= 2 else head; out.append(b); continue
        if b[0] == 'p' and head:
            mn = re.match(r'^\s*(?:\*\*)?(?:narration|voice[- ]?over|script)(?:\*\*)?\s*:\s*(.+)$', b[1], re.I)
            if mn:   # "Narration: …" — what a narrated walkthrough says on this slide (into its talk track), never on the slide itself
                NARR[head] = (NARR.get(head, '') + ' ' + mn.group(1).strip()).strip(); continue
            mdg = re.match(r'^\s*(?:\*\*)?diagram(?:\s+style)?(?:\*\*)?\s*:\s*(?:\*\*)?([A-Za-z &/-]{2,24}?)(?:\*\*)?\s*\.?\s*$', b[1], re.I)
            if mdg and DIAGRAM_NAMES.get(mdg.group(1).strip().lower()) not in (None, 'auto'):   # "Diagram style: Hub & spoke" under the section's heading
                hints[head] = 'diagram-' + DIAGRAM_NAMES[mdg.group(1).strip().lower()]; continue
            m = re.match(r'^\s*(?:\*\*)?(?:layout|visual|infographic)(?:\*\*)?\s*:\s*(?:\*\*)?([A-Za-z0-9 ×/%-]{2,34}?)(?:\*\*)?\s*\.?\s*$', b[1], re.I)
            if m:
                k0 = re.sub(r'\s+', ' ', m.group(1).strip().lower().replace('×', 'x')); k = LAYOUT_ALIAS.get(k0, k0)
                if k in LAYOUT_KINDS: hints[head] = k
                elif family_hint(k0): hints[head] = 'fam:' + k0   # v6.22: a Presentation Central family — "timeline quarters", "swimlane handoffs", "OGSM", "kpi cards"
                continue
        out.append(b)
    return out, hints


ART_CH = re.compile(r'[┌┐└┘│─┬┴├┤┼╔╗╚╝║═▼▲►◄╭╮╰╯]')


def parse_markdown(text):
    """Return list of blocks: ('h', level, text) | ('p', text) | ('ul', [items]) | ('table', [[cells]])"""
    blocks, para, ul, table = [], [], [], []
    text = re.sub(r'<!--.*?-->', '', text, flags=re.S)   # transcription banners / HTML comments are not content
    text = normalize_paste(text)
    text = recover_structure(text)

    art = []   # box-art lines (┌─┐ │ └┘ ▼): kept as drawn, leading spaces and all — the diagram reader needs the grid
    def flush():
        nonlocal para, ul, table, art
        if art: blocks.append(('p', '\n'.join(art).rstrip())); art = []
        if para: blocks.append(('p', ' '.join(para).strip())); para = []
        if ul: blocks.append(('ul', ul)); ul = []
        if table:
            rows = [r for r in table if not re.fullmatch(r'\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?', r)]
            cells = [[html.unescape(c.strip()) for c in r.strip().strip('|').split('|')] for r in rows]
            if len(cells) == 1 and sum(bool(c) for c in cells[0]) > 1: blocks.append(('ul', [c for c in cells[0] if c]))   # header-only table = a row of labels
            elif cells: blocks.append(('table', cells))
            table = []
    fence = None   # inside a ```diagram block: the architecture's fields as JSON (written by the AI step or the outline)
    artfence = False; ALL = text.splitlines()
    for idx, line in enumerate(ALL):
        s = line.rstrip()
        if fence is not None:
            if s.strip().startswith('```'):
                try:
                    d_ = json.loads('\n'.join(fence))
                    if isinstance(d_, dict): blocks.append(('diagram', d_))
                except Exception: pass   # noqa: BLE001  a broken block is dropped, never shown as code
                fence = None
            else: fence.append(line)
            continue
        if re.match(r'^\s*```\s*(diagram|architecture)\s*$', s, re.I): flush(); fence = []; continue
        if s.strip().startswith('```'):          # a code fence around box art: the whole drawing, label lines and blank lines included, is one block
            if artfence: flush(); artfence = False; continue
            j_ = idx + 1
            while j_ < len(ALL) and not ALL[j_].strip().startswith('```'): j_ += 1
            if any(ART_CH.search(x) for x in ALL[idx + 1:j_]): flush(); artfence = True
            continue
        if artfence: art.append(s); continue
        if ART_CH.search(s) and not (s.lstrip().startswith('|') and s.rstrip().endswith('|') and '─' not in s):
            if para or ul or table: flush()
            art.append(s); continue
        if art and not s.strip(): flush(); continue
        if not s.strip():
            flush(); continue
        if re.fullmatch(r'\s*(-{3,}|\*{3,}|_{3,})\s*', s): flush(); continue   # a horizontal rule is page furniture
        m = re.match(r'^(#{1,6})\s+(.*)', s)
        if m:
            flush()
            h_ = re.sub(r'\*\*(.*?)\*\*', r'\1', m.group(2).strip())
            h_ = re.sub(r'^\d+(?:\.\d+)+\.?\s+(?=[A-Z(])', '', h_)   # "7.1 Legal, tax" → "Legal, tax": section numbers are document furniture (never "2026 plan")
            if len(m.group(1)) <= 2: h_ = re.sub(r'^\d+\.\s+(?=[A-Z(])', '', h_)   # "## 7. Key risks" too; a "### 1. Capture" card keeps its number (it makes the steps)
            if h_: blocks.append(('h', len(m.group(1)), h_))
            continue
        if s.lstrip().startswith('>'):                    # blockquote = speaker notes / provenance, not slide text
            flush(); q = s.lstrip()[1:].strip()
            if blocks and blocks[-1][0] == 'quote': blocks[-1] = ('quote', blocks[-1][1] + ' ' + q)
            elif q: blocks.append(('quote', q))
            continue
        if s.lstrip().startswith('|'):
            if para or ul: flush()
            table.append(s); continue
        m = re.match(r'^(\s*)([-*+]|\d+[.)]|[✓✗→◦▪•])\s+(.*)', s)
        if m:
            if para or table: flush()
            body = re.sub(r'\*\*(.*?)\*\*', r'\1', m.group(3)).strip()
            if not body: continue
            g = m.group(2)
            mark = '– ' if len(m.group(1)) >= 2 else (g.rstrip('.)') + '. ' if g[0].isdigit() else (g + ' ' if g in '✓✗→◦▪' else ''))   # ✓ → keep their glyph
            ul.append(mark + body); continue
        if ul and s[:1].isspace():                       # indented line under a list item continues that item
            ul[-1] = ul[-1].rstrip() + ' — ' + s.strip(); continue
        if ul or table: flush()
        if re.match(r'^[A-Za-z][\w &/%().-]{1,40}:\s*\S', s) and (len(s) <= 64 or s.split(':', 1)[0].strip().lower() in TAKEAWAY_LABELS + CALLOUT_LABELS):
            flush(); blocks.append(('p', s.strip())); continue     # 'Label: value' lines are their own paragraphs
        mb = re.fullmatch(r'\s*\*\*([^*]{2,60})\*\*:?\s*', s)
        if mb and not mb.group(1).endswith('.'):
            flush(); blocks.append(('h', 4, mb.group(1).strip())); continue
        para.append(re.sub(r'\*\*(.*?)\*\*', r'\1', s.strip()))
    flush()
    return labelled_runs(merge_art(blocks))


def labelled_runs(blocks):
    """Three or more "Label: text" paragraphs in a row ("Item feed: …", "Normal delivery: …", "Feed generation: …") are one labelled
    list — the shape a Confluence page uses for parallel items — so the layout can make them a label table, not a wall of paragraphs."""
    out, run = [], []
    def push():
        nonlocal run
        if len(run) >= 3: out.append(('ul', [x[1] for x in run]))
        else: out.extend(run)
        run = []
    for b in blocks:
        lb = lead_label(b[1]) if b[0] == 'p' and isinstance(b[1], str) else None
        if lb and len(lb[0].split()) <= 5 and lb[0].strip().lower() not in TAKEAWAY_LABELS + CALLOUT_LABELS and not ART_CH.search(b[1]): run.append(b); continue
        push(); out.append(b)
    push()
    return out


def merge_art(blocks):
    """Box-art lines that arrived as separate paragraphs (a Word or PDF file, blank lines between them) are one drawing again."""
    out = []
    for b in blocks:
        if b[0] == 'p' and ART_CH.search(b[1]) and out and out[-1][0] == 'p' and ART_CH.search(out[-1][1]): out[-1] = ('p', out[-1][1] + '\n' + b[1])
        else: out.append(b)
    return out


ARCH_HEAD = re.compile(r'\b(architecture|integrations?|interfaces?|data ?flows?|system ?flows?|end-to-end (?:data )?flow|landscape|topology|system context|solution design|technical design|data exchange)\b', re.I)
LAYER_WORD = re.compile(r'\b(layers?|tiers?|planes?)\b', re.I)
SYS_TALK = re.compile(r'\b(architecture|integrations?|interfaces?|middleware|api|apis|esb|cpi|btp|kafka|idoc|odata|rest|data flow|system of record|'
                      r'orchestration|gateway|event[- ]driven|publishes|subscribes|sends? .{1,40} to|posts? .{1,40} to|syncs?)\b', re.I)   # systems talking (as the AI step's trigger)


def infer_diagrams(blocks):
    """Architecture the page describes without drawing it: an interface table (Source / Target columns), and — when the page has no
    drawing of its own — an architecture section written as layers, or sentences that say who sends what to whom. Each becomes a
    ('diagram', arch) block right after what it was read from; one architecture gets one diagram."""
    try:
        SD = _load_sd()
    except Exception: return blocks   # noqa: BLE001
    chain1 = lambda x: isinstance(x, str) and '\n' not in x.strip() and len(re.findall(r'→|->|──►|=>', x)) >= 3   # a one-line flow ("A → B → C → D") is drawn too
    drawn = [b for b in blocks if b[0] == 'diagram' or (b[0] == 'p' and (SD.is_art(b[1]) or chain1(b[1]))) or (b[0] == 'ul' and SD.arrow_lines(b[1]))]
    known = []
    for b in drawn:
        try:
            got = SD.build(b[1] if b[0] != 'ul' else SD.arrow_lines(b[1]))
            if got: known.append(got[1])
        except Exception: pass   # noqa: BLE001
    adds = []
    for i, b in enumerate(blocks):
        if b[0] == 'table':
            a = SD.from_table(b[1])
            if a: adds.append((i, a))
    if not drawn:
        for i, b in enumerate(blocks):
            if b[0] != 'h': continue
            j = i + 1
            while j < len(blocks) and not (blocks[j][0] == 'h' and blocks[j][1] <= b[1]): j += 1
            scope = blocks[i + 1:j]; cards = []; cur_ = None
            stext = ' '.join(x[1] if x[0] in ('p', 'quote', 'h') and isinstance(x[1], str) else ' '.join(x[1]) if x[0] == 'ul' else (x[2] if x[0] == 'h' else '') for x in scope)
            if not ARCH_HEAD.search(b[2]) and len(SYS_TALK.findall(stext)) < 5: continue   # an architecture heading, or a section clearly about systems talking
            for x in scope:
                if x[0] == 'h': cur_ = [x[2], []]; cards.append(cur_)
                elif cur_ is not None and x[0] == 'p': cur_[1].append(x[1])
                elif cur_ is not None and x[0] == 'ul': cur_[1].extend(x[1])
            a = None
            if 3 <= len(cards) <= 8 and sum(1 for c in cards if LAYER_WORD.search(c[0])) >= max(2, len(cards) // 2): a = SD.from_layers(cards, b[2])
            if not a: a = SD.from_sentences('\n'.join(x[1] if x[0] in ('p', 'quote') else '\n'.join(x[1]) if x[0] == 'ul' else '' for x in scope), b[2])
            if a: adds.append((j - 1, a))
        if not any(x for x in adds if x[1].get('from') in ('sentences', 'layers')):   # no section qualified (a PDF: no headings): the whole text, if it talks about systems
            txt = [(k, x[1] if x[0] in ('p', 'quote') else '\n'.join(x[1]) if x[0] == 'ul' else '') for k, x in enumerate(blocks)]
            if len(SYS_TALK.findall(' '.join(s for _, s in txt))) >= 5:
                a = SD.from_sentences('\n'.join(s for _, s in txt if s), 'Architecture')
                if a:
                    best = max(txt, key=lambda kv: len(SYS_TALK.findall(kv[1])))[0]
                    adds.append((best, a))
    out = list(blocks)
    for i, a in sorted(adds, key=lambda x: -x[0]):
        if any(SD.overlap(a, k) >= 0.6 for k in known): continue
        known.append(a); out.insert(i + 1, ('diagram', a))
    return out


class HTMLBlocks(HTMLParser):
    def __init__(self):
        super().__init__(); self.blocks = []; self.buf = []; self.mode = None; self.level = 0
        self.table = None; self.row = None; self.ul = None; self.title = None; self.in_title = False
        self.ordered = False; self.li_paras = []; self.li_n = 0
        self.implicit = False; self.skip = 0; self.depth = 0; self.in_a = 0; self.loose_idx = set()   # implicit: loose text (a <div> line, bare text between <br>s — Teams, Outlook, Word pastes) collected as a paragraph; skip: inside page chrome; depth: nested containers
    NEST = ('div', 'section', 'article', 'main', 'body', 'td', 'th', 'li', 'blockquote')
    LOOSE_DEPTH = 4   # loose text is content up to this nesting (a pasted message is one to three containers deep); a web app's tiles and labels sit deeper
    BLOCKS = ('h1', 'h2', 'h3', 'h4', 'p', 'ul', 'ol', 'table', 'div', 'li', 'tr', 'td', 'th', 'blockquote', 'section', 'article', 'header', 'footer', 'nav', 'pre', 'hr')
    CHROME = ('script', 'style', 'select', 'option', 'svg', 'noscript', 'template', 'canvas', 'iframe')   # never content; a <header>, <nav>, <aside> or <button> may still hold the page's own headings and text
    def handle_starttag(self, tag, attrs):
        if tag in self.CHROME: self.skip += 1; return   # page chrome and code: never content, whatever it wraps
        if tag in self.NEST: self.depth += 1
        if tag == 'a': self.in_a += 1   # a bare link (navigation, a breadcrumb) does not start a loose paragraph; a link inside a line of text is kept
        if self.implicit and tag in self.BLOCKS: self.close_p()   # a block starts: the loose line before it is its own paragraph
        if tag in ('strong', 'b') and self.mode in ('p', 'li'): self.bold_open = True; self.buf.append('\x02')
        if tag == 'title':
            if self.title is None: self.in_title = True   # first <title> only
            else: self.skip += 1; self.skip_title = True  # a second <title> (a page wrapped inside another page) is not content
            return
        if tag in ('h1', 'h2', 'h3', 'h4'): self.flush(); self.mode = 'h'; self.level = int(tag[1]); self.buf = []
        elif tag in ('div', 'span', 'p') and dict(attrs).get('role') == 'heading' and self.table is None and self.mode != 'li':   # v6.22: a heading by ARIA role (Google's AI overview, many web apps)
            if self.implicit: self.close_p()
            self.flush(); self.mode = 'h'; lv = str(dict(attrs).get('aria-level') or '3'); self.level = max(2, min(4, int(lv) if lv.isdigit() else 3)); self.buf = []
            self.role_h = (tag, self.depth)
        elif tag == 'p' and self.table is None and self.mode != 'li': self.flush(); self.mode = 'p'; self.buf = []
        elif tag == 'pre' and self.table is None and self.mode is None: self.flush(); self.mode = 'p'; self.buf = []   # a code block: one paragraph, its lines kept
        elif tag == 'p' and self.mode == 'li':
            t = ' '.join(''.join(self.buf).split())
            if t: self.li_paras.append(t)
            self.buf = []
        elif tag in ('ul', 'ol') and self.table is None: self.flush(); self.ul = []; self.ordered = tag == 'ol'; self.li_n = 0
        elif tag == 'li' and self.ul is not None: self.buf = []; self.mode = 'li'; self.li_paras = []; self.li_n += 1
        elif tag == 'table': self.flush(); self.table = []
        elif tag == 'tr' and self.table is not None: self.row = []
        elif tag in ('td', 'th') and self.row is not None: self.buf = []; self.mode = 'cell'
        elif tag == 'br': self.buf.append('\n')
        elif tag == 'span' and any(k == 'data-testid' and str(v or '').startswith('renderer-code-block-line') for k, v in attrs) and self.mode == 'p':
            self.buf.append('\n')   # Confluence's code block: one <span> per line, nothing between them
    def close_p(self):
        """End of a paragraph (</p>, or the loose text of a <div> / between <br>s): bullet-like lines become a list, a short all-bold line a heading."""
        t = ' '.join(''.join(self.buf).split()); loose = self.implicit; self.implicit = False; n0 = len(self.blocks)
        try: return self._close_p(t, loose)
        finally:
            if loose: self.loose_idx.update(range(n0, len(self.blocks)))
    def _close_p(self, t, loose):
        rawt = ''.join(self.buf).replace('\xa0', ' ').replace('\x02', '').replace('\x03', '')
        if ART_CH.search(rawt):   # box art (a Confluence code block, a <div> per line, <br>s): kept as drawn — the diagram reader needs the grid
            art_ = '\n'.join(l.rstrip() for l in rawt.strip('\n').split('\n'))
            if art_.strip(): self.blocks.append(('p', art_))
            self.mode = None; self.buf = []; return
        lines_ = [' '.join(x.split()) for x in ''.join(self.buf).split('\n')]; lines_ = [x for x in lines_ if x]
        LISTY = re.compile(r'^(?:\d{1,2}[.)]|[-•*–])\s+\S')
        if len(lines_) > 1 and (loose or any(LISTY.match(x.replace('\x02', '').replace('\x03', '')) for x in lines_[1:])):   # "brief<br>1. point<br>2. point": each line its own block, numbered lines a list — a plain soft line break in a <p> stays one paragraph; loose lines are lines
            run = []
            for x in lines_:
                x = x.replace('\x02', '').replace('\x03', '')
                if re.match(r'^(?:\d{1,2}[.)]|[-•*–])\s+\S', x): run.append(re.sub(r'^[-•*–]\s+', '', x)); continue
                if run: self.blocks.append(('ul', run)); run = []
                self.blocks.append(('p', x))
            if run: self.blocks.append(('ul', run))
            self.mode = None; self.buf = []; return
        raw = t; t = t.replace('\x02', '').replace('\x03', '')
        # a short paragraph that is entirely bold is a heading (Confluence authors often bold instead of using H3)
        if t and re.fullmatch(r'\s*\x02[^\x02\x03]*\x03[\s:]*', raw) and len(t) <= 60 and not t.endswith('.'):
            self.blocks.append(('h', 4, t.rstrip(':')))
        elif t: self.blocks.append(('p', t))
        self.mode = None; self.buf = []
    def handle_endtag(self, tag):
        if tag in self.CHROME: self.skip = max(0, self.skip - 1); return
        if tag == 'title' and getattr(self, 'skip_title', False): self.skip = max(0, self.skip - 1); self.skip_title = False; return
        rh = getattr(self, 'role_h', None)
        if rh and tag == rh[0] and (tag not in self.NEST or self.depth == rh[1]) and self.mode == 'h':   # the end of a role="heading" element
            t_ = ' '.join(''.join(self.buf).replace('\x02', '').replace('\x03', '').split())
            if t_: self.blocks.append(('h', self.level, t_))
            self.mode = None; self.buf = []; self.role_h = None
            if tag in self.NEST: self.depth = max(0, self.depth - 1)
            return
        if tag in self.NEST: self.depth = max(0, self.depth - 1)
        if tag == 'a': self.in_a = max(0, self.in_a - 1)
        if self.implicit and tag in ('div', 'body', 'html', 'blockquote', 'section', 'article', 'header', 'footer', 'nav', 'pre', 'td', 'th', 'li', 'tr', 'table', 'ul', 'ol'): self.close_p(); return
        t = ' '.join(''.join(self.buf).split())
        if tag == 'title':
            self.in_title = False; self.title = self.title or ''
        elif tag in ('h1', 'h2', 'h3', 'h4') and self.mode == 'h':
            if t.strip(): self.blocks.append(('h', self.level, t))     # an empty <h1></h1> (Confluence leaves them) is not a section — it made an empty agenda row
            self.mode = None
        elif tag in ('strong', 'b') and self.mode in ('p', 'li'): self.buf.append('\x03')
        elif tag in ('p', 'pre') and self.mode == 'p': self.close_p()
        elif tag == 'li' and self.mode == 'li' and self.ul is not None:
            paras = self.li_paras + ([t] if t.strip() else []); self.li_paras = []
            first = paras[0] if paras else ''
            bold_title = re.fullmatch(r'\s*\x02[^\x02\x03]{2,80}\x03[\s:]*', first) and not first.replace('\x02', '').replace('\x03', '').strip().endswith('.')
            if bold_title and len(paras) > 1:
                # a list item that is a bold title + its own paragraph(s): a card, numbered when the list is ordered (Confluence step lists)
                if self.ul: self.blocks.append(('ul', self.ul)); self.ul = []
                title = first.replace('\x02', '').replace('\x03', '').strip().rstrip(':')
                self.blocks.append(('h', 4, (f'{self.li_n}. ' if self.ordered else '') + title))
                self.blocks.append(('p', ' '.join(x.replace('\x02', '').replace('\x03', '') for x in paras[1:])))
            else:
                t = ' '.join(paras).replace('\x02', '').replace('\x03', '').strip()
                if t: self.ul.append((f'{self.li_n}. ' if self.ordered else '') + t)
            self.mode = None
        elif tag in ('ul', 'ol') and self.ul is not None: 
            if self.ul: self.blocks.append(('ul', self.ul))
            self.ul = None
        elif tag in ('td', 'th') and self.row is not None: self.row.append(t.replace('\x02', '').replace('\x03', '')); self.mode = None
        elif tag == 'tr' and self.table is not None and self.row is not None: self.table.append(self.row); self.row = None
        elif tag == 'table' and self.table is not None:
            if self.table: self.blocks.append(('table', self.table))
            self.table = None
    def handle_data(self, data):
        if self.skip: return
        if self.in_title: self.title = (self.title or '') + data; return
        if self.mode in ('h', 'p', 'li', 'cell'): self.buf.append(data)
        elif self.mode is None and self.ul is None and self.table is None and (self.depth <= self.LOOSE_DEPTH or ART_CH.search(data)) and not self.in_a and data.strip():   # box art is content at any depth (Confluence nests its code blocks deep)   # loose text: a <div> line, bare text in the body — a paragraph until the next block
            if not self.implicit: self.buf = [x for x in self.buf if x == '\n'][-1:] if self.buf else []   # keep one pending <br> only
            self.mode = 'p'; self.implicit = True; self.buf.append(data)
    def close(self):
        super().close()
        if self.implicit: self.close_p()
        merged, keep_loose, k = [], set(), 0
        while k < len(self.blocks):
            b = self.blocks[k]
            if b[0] == 'p' and ART_CH.search(b[1]):
                run = [b[1]]; k2 = k + 1
                while k2 < len(self.blocks) and self.blocks[k2][0] == 'p' and ART_CH.search(self.blocks[k2][1]): run.append(self.blocks[k2][1]); k2 += 1
                merged.append(('p', '\n'.join(run))); k = k2; continue
            if k in self.loose_idx: keep_loose.add(len(merged))
            merged.append(b); k += 1
        self.blocks, self.loose_idx = merged, keep_loose
        # a structured page (headings, paragraphs, lists) with a handful of short label-like loose lines: those are chrome (a logo line, a
        # panel label), not content. A pasted message is the other way round — mostly loose lines — and keeps every one of them.
        structured = len(self.blocks) - len(self.loose_idx); loose = [self.blocks[i] for i in sorted(self.loose_idx) if i < len(self.blocks)]
        if structured >= 8 and 0 < len(loose) <= max(4, structured // 4) and all(b[0] == 'p' and len(b[1]) <= 40 and not re.search(r'[.!?:]', b[1]) for b in loose):
            self.blocks = [b for i, b in enumerate(self.blocks) if i not in self.loose_idx]; self.loose_idx = set()
    def flush(self):
        pass


# ------------------------------------------------------------------ blocks -> slides
TABLE_COLS = {'actions': (44, 44, 44), 'grid6': (20, 18, 18, 18, 18, 18)}   # ~chars per line per column at the template's cell widths (slide 12: three 4 in columns, 12 pt)
TABLE_LINES = {'actions': 13, 'grid6': 12}                                  # body lines that fit under the header row
CELL_MAX = 170                                                              # longer cells are cut to a clause; full text goes to the notes
TABLE_SCALE = 1.0                                                           # >1 = fit-to-N packs more rows per table slide
ACTIONS_ROWS, GRID_ROWS = 8, 8                                              # rows per slide when rows are short (templates hold 4 / 3; the builder clones rows); the line budget caps long rows


def row_lines(row, widths):
    return max(1, max(-(-len(c) // max(8, w)) for c, w in zip(row, list(widths) + [18] * len(row))))


def chunk_rows_fit(data, n, kind):
    """chunk_rows at the template's 12 pt; if the same rows need fewer slides at 9 pt, take that and return (groups, 9)."""
    return chunk_rows(data, n, kind, pt=16 if kind == 'actions' else None), None   # ULTA SlideGlam: the template's 16 pt


def chunk_rows(data, n, kind, pt=None):
    """Like chunk() but also keeps each slide's estimated line count within the layout's body height."""
    widths, budget = TABLE_COLS.get(kind, (18,) * 6), TABLE_LINES.get(kind, 12)
    if pt and kind == 'actions': f = 12.0 / pt; widths = tuple(int(w * f) for w in widths); budget = int(budget * f)   # smaller text: more per line, more lines
    if TABLE_SCALE > 1:                             # fit-to-N: more rows per slide, the builder shrinks the font to make them fit
        budget = int(budget * TABLE_SCALE); n = min(n + 2, int(round(n * TABLE_SCALE)))
    if kind == 'grid6' and data:                    # unused columns are removed and the rest widened: ~11.6 in shared by the used ones
        used = max(max((c for c, v in enumerate(r) if str(v).strip()), default=0) + 1 for r in data)
        widths = (max(12, int(11.6 / max(2, used) * 14)),) * 6   # ~14 chars per inch at the grid's 9 pt
    def first_fit(n):
        groups, cur, used = [], [], 0
        for r in data:
            h = row_lines(r, widths)
            if cur and (len(cur) >= n or used + h > budget):
                groups.append(cur); cur, used = [], 0
            cur.append(r); used += h
        if cur: groups.append(cur)
        return groups
    if not data: return []
    n = max(1, -(-len(data) // -(-len(data) // n)))   # fewest slides, then even rows per slide (7 rows, n 6 → 4 + 3, not 6 + 1)
    groups = first_fit(n)
    for _ in range(3):                                 # the line budget may have split unevenly (6 + 2): even the rows out over the slides it took
        even = max(1, -(-len(data) // len(groups)))
        if even >= n: break
        g2 = first_fit(even)
        if len(g2) > len(groups): break
        groups, n = g2, even
    return groups


def trim_cells(rows, warnings, where, limit=None):
    """Cut over-long cells to their first clause; return (rows, overflow text for the notes). limit: a table with fewer, wider cells holds more."""
    out, notes = [], []; CELL_MAX_ = limit or CELL_MAX
    for r in rows:
        nr = []
        for c in r:
            if len(c) > CELL_MAX_:
                nr.append(clause(c, CELL_MAX_)); notes.append(c)   # v6.18: no '…' (the full cell is in the notes)
            else: nr.append(c)
        out.append(nr)
    if notes: warnings.append(f'table under "{where}": {len(notes)} cell(s) longer than {CELL_MAX_} chars cut to a clause — full text in the notes')
    return out, notes


def normalize_table(rows):
    """Drop empty rows and empty columns (Confluence exports blank header rows and trailing empty columns), pad ragged rows.
    Reviewer case: a blank first row became the header and the real header sank into the body."""
    rows = [r for r in rows if any(str(c).strip() for c in r)]
    if not rows: return []
    w = max(len(r) for r in rows); rows = [list(r) + [''] * (w - len(r)) for r in rows]
    keep = [c for c in range(w) if any(str(r[c]).strip() for r in rows)]
    return [[r[c] for c in keep] for r in rows]


def chunk(lst, n):
    """Split into the fewest groups of <= n, balanced (5 rows, n=4 -> 3+2, not 4+1)."""
    if not lst:
        return []
    k = -(-len(lst) // n); size = -(-len(lst) // k)
    return [lst[i:i + size] for i in range(0, len(lst), size)]


BOX_CHARS = 62      # ~chars per wrapped line in a slide-6 box (14 pt Circular, 5.95 in box, measured on renders)
BOX_LINES = 14      # hard capacity of a box (18.8 pt line pitch, 4.2 in box)
PACK_LINES = 11     # lines we aim to put in a box: leaves air on the slide ('--density dense' -> 14)


def est_lines(items):
    """Wrapped-line estimate for a list of paragraphs/bullets in a slide-6 box."""
    return sum(max(1, -(-len(str(x)) // BOX_CHARS)) for x in items)


def split_lines(items, limit):
    """Greedy split of paragraphs into chunks whose estimated wrapped lines stay within limit."""
    chunks, cur = [], []
    for it in items:
        if cur and est_lines(cur + [it]) > limit:
            chunks.append(cur); cur = []
        cur.append(it)
    if cur: chunks.append(cur)
    return chunks


UI_JUNK = re.compile(r'\b(click|tap|hover|drag|scroll|toggle|expand|select)\b.*\b(below|above|block|button|tab|card|panel|stage|here|explore)\b', re.I)
BOILERPLATE = re.compile(r'^(proprietary( & | and )confidential|confidential|internal use only|draft|\[edit\].*|expand source|page \d+ of \d+|powered by atlassian.*|created by .*last updated.*|last updated .*|table of contents|back to top|skip to (main )?content|print this page|share this page|copy link|\d+ min read|no labels|add label|\s*)$', re.I)
H = '## '   # paragraph marker: "heading line" inside a two-column box (builder renders it in the template's bold heading style)


ABBREV_END = re.compile(r'(?:(?<![A-Za-z])(?:[A-Z]\.){1,3}|\b(?:e\.g|i\.e|vs|etc|approx|incl|inc|corp|ltd|co|no|dept|fig|st|dr|mr|mrs|ms|jr|sr)\.)$', re.I)


def sentences(text):
    """Split at . ! ? — but not after an initial or a common abbreviation ("J.P. Morgan", "U.S.", "e.g."): that is one sentence,
    and splitting it made two bullets, "…use J.P" and "Morgan SCF as the primary funding provider…"."""
    out = []
    for s in re.split(r'(?<=[.!?])\s+', text):
        if not s: continue
        if out and (ABBREV_END.search(out[-1]) or s[:1].islower()): out[-1] += ' ' + s
        else: out.append(s)
    return out


MAX_BULLETS = 5     # sentences kept per prose paragraph on the slide; the rest goes to the notes
BULLET_CHARS = 0    # 0 = keep whole sentences; brief mode cuts each bullet to its first clause (<= N chars)
CARDS_PER_BOX = 99  # sub-sections a box may hold (brief: 2)
BULLET_WHOLE = True # brief: a bullet with no clause to cut at is kept whole (two lines) rather than chopped with '…'; fit-to-N densities cut anyway
DENSITY = {         # editor presets: lines per box, bullets per paragraph, chars per bullet, cards per box
    'brief':  {'PACK_LINES': 8,  'MAX_BULLETS': 3, 'BULLET_CHARS': 95, 'CARDS_PER_BOX': 2, 'BULLET_WHOLE': True},
    'normal': {'PACK_LINES': 11, 'MAX_BULLETS': 5, 'BULLET_CHARS': 0,  'CARDS_PER_BOX': 99},
    'dense':  {'PACK_LINES': 14, 'MAX_BULLETS': 6, 'BULLET_CHARS': 0,  'CARDS_PER_BOX': 99, 'TEXT_PT': 12},
    'compact': {'PACK_LINES': 14, 'MAX_BULLETS': 3, 'BULLET_CHARS': 95, 'CARDS_PER_BOX': 99, 'BULLET_WHOLE': False, 'TEXT_PT': 12},   # fit-to-N: brief bullets, full boxes
    'tight':  {'PACK_LINES': 14, 'MAX_BULLETS': 2, 'BULLET_CHARS': 80, 'CARDS_PER_BOX': 99, 'BULLET_WHOLE': False, 'TEXT_PT': 12},    # fit-to-N last resort: two bullets a paragraph
}
# One body size per deck (v3.90): text boxes are 14 pt on every slide (the template's size); a long section continues on a
# "(cont.)" slide instead of shrinking. Dense / compact / tight set one smaller size (TEXT_PT) for EVERY text slide of the deck —
# never a different size section by section, which read as the font jumping between slides.
DECK_PT = None
MERGE_COST = 3      # a section this small (estimated lines) joins the next slide as a card instead of taking a slide of its own


def clause(sentence, limit):
    """Cut a sentence to its first clause within `limit` chars (at , ; : — or ' which/that/because'), else at a word."""
    s = sentence.strip().rstrip('.')
    if limit <= 0 or len(s) <= limit: return s
    s2 = re.sub(r'\s*\([^()]{0,60}\)', '', s).strip()                   # over the limit: a bracketed aside goes first (the notes keep the full line)
    if s2 and s2 != s: s = s2
    if len(s) <= limit: return s
    best = -1
    lead_sub = re.match(r'^(?:to|if|when|while|because|although|though|due to|in order to|as|since|after|before|unless|once|with|given|for)\b[^,;:]*[,;:]', s, re.I)   # "To reduce transit times, …": the opening clause is not the point
    for m in re.finditer(r',|;|:|\s—\s|\s–\s|\s→\s|\s\(|\s(?:which|because|so that|while|whereas|including)\s', s):   # not a bare "that": "validates that …" cut there leaves the verb hanging
        if lead_sub and m.group(0).strip() not in (';', '—', '–'): continue   # inside an opening "To … , … ," list a comma is not a clause end
        if max(20, limit // 3) <= m.start() <= limit: best = m.start()   # a boundary a third of the way in is a clause, not a stub
    tail = re.compile(r'\s+(?:in|of|for|to|and|or|with|by|on|at|as|the|a|an|is|are|from|into|than|but|per|via)$', re.I)
    def trim(x):
        x = x.rstrip(' ,;:(')
        while tail.search(x): x = tail.sub('', x)
        y = re.sub(r'\s+(?:that|which|who|whom|whose|where|when|so|whereby)(?:\s+\S+){0,2}$', '', x, flags=re.I)   # v6.22: never a dangling "… that lets"
        return y if len(y) >= max(20, limit * 0.4) else x
    if best > 0: return trim(s[:best])
    if lead_sub: return s   # no clean place to stop: the whole thought (it wraps) rather than "To reduce transit times, improve scores…"
    for m in (re.finditer(r'\s(?:and|but|so|then)\s', s) if limit <= 80 else ()):   # short lines (steps): a conjunction beats a word cut with '…'
        if max(20, limit // 3) <= m.start() <= limit: best = m.start()
    if best > 0: return trim(s[:best])
    return trim(s[:limit].rsplit(' ', 1)[0])   # v6.18 (v53): never "…" — the phrase ends on a content word (the full line is in the notes)
LABEL = re.compile(r'^([A-Z][\w&/-]*(?:[ -][\w&/-]+){0,2}):\s+([A-Z0-9].{19,})$')   # "Key point: …" -> heading + text (≤3-word label, sentence-case body)


def brief_clause(x):
    """Brief mode shortens a bullet to its first clause; a sentence with no clause to cut at is kept whole (up to a second line)
    rather than chopped mid-thought with '…' — a fragment reads worse than two lines."""
    if BULLET_WHOLE and len(x.strip()) <= BULLET_CHARS * 2: return x.strip().rstrip('.')   # a sentence that fits two lines stays a sentence — no cut at "that" / "which" mid-thought
    c = clause(x, BULLET_CHARS)
    if not c.endswith('…') or not BULLET_WHOLE: return c
    c2 = clause(x, BULLET_CHARS * 2)                      # a clause boundary on the second line beats a word cut on the first
    return c2 if not c2.endswith('…') else c

def slidify(lines, overflow):
    """Prose -> slide text: a 'Label: text' paragraph becomes a heading line + text; a long paragraph (3+ sentences)
    becomes one bullet per sentence, at most MAX_BULLETS (the rest is appended to `overflow` for the notes)."""
    out = []
    for ln in lines:
        if ln.startswith(H) or ln.startswith(GLYPHS) or re.match(r'^\d+\. ', ln) or ln == '':
            out.append(ln); continue
        m = LABEL.match(ln)
        if m and m.group(1).strip().lower() in TAKEAWAY_LABELS + CALLOUT_LABELS: out.append(ln); continue   # lifted out later (takeaway / callout) — whole, never clause-cut
        if m:
            if out and out[-1] != '': out.append('')
            out.append(H + m.group(1)); ln = m.group(2)
        s = sentences(ln)
        brief = BULLET_CHARS > 0
        if len(s) >= 2 or len(ln) > 140:          # two or more sentences, or a long one: bullets are easier to scan
            keep, rest = s[:MAX_BULLETS], s[MAX_BULLETS:]
            out.extend('• ' + brief_clause(x) for x in keep)
            if rest or (brief and any(len(x.rstrip('.')) > BULLET_CHARS for x in keep)): overflow.append(ln)   # full text stays in the notes
        elif brief and len(ln) > BULLET_CHARS + 20 and not (brief_clause(ln) == ln.rstrip('.')):
            out.append(brief_clause(ln)); overflow.append(ln)
        else:
            out.append(ln)
    return out


# ------------------------------------------------------------------ copy hygiene (PPT-ready text)
WEB_NOISE = re.compile(r'\s*\((?:see|click|tap|hover|expand|scroll)[^)]*\)|\s*\[(?:edit|link|source|\d+)\]|\s*\((?:cont(?:inued)?\.?|more)\)', re.I)
HEAD_MAX = 60


def polish_text(s, bullet=False):
    """Normalise a line for a slide: whitespace, quotes/dashes, web-page leftovers, capital first letter,
    no trailing period on bullets/headings, at most one sentence-ending mark."""
    s = str(s)
    marker = ''
    for m in (H,) + GLYPHS:
        if s.startswith(m): marker, s = m, s[len(m):]
    mn = re.match(r'^(\d+\. )', s)
    if mn and not marker: marker, s = mn.group(1), s[mn.end():]
    s = WEB_NOISE.sub('', s)
    s = s.replace('\u00a0', ' ').replace(' ,', ',').replace(' .', '.')
    s = re.sub(r'[ \t\r\f\v]+', ' ', s); s = re.sub(r' *\n *', '\n', s).strip()   # keep intentional line breaks (two-paragraph header cells)
    s = re.sub(r'\s+([,;:!?])', r'\1', s); s = re.sub(r'\(\s+', '(', s); s = re.sub(r'\s+\)', ')', s); s = re.sub(r'(?<=[A-Za-z,.])\((?=\w)', ' (', s)   # "word , word" / "buy( and engage )" → "word, word" / "buy (and engage)"
    s = re.sub(r'(?<=[a-z])([.!?])(?=[A-Z][a-z])', r'\1 ', s); s = re.sub(r'([,;])(?=[A-Za-z])', r'\1 ', s)             # "done.Next" / "one,two" → a space after the mark (numbers, URLs, S/4HANA untouched)
    s = re.sub(r'(\w)- (?=[a-z])', r'\1', s)                                                                       # "inven- tory" (a line-break hyphen) → "inventory"
    s = re.sub(r' *-- *', ' — ', s).replace('...', '…')
    s = re.sub(r'(?<=\w)"(?=\w)', "'", s)
    s = re.sub(r'([.!?…]){2,}$', r'\1', s)
    if s and s[0].islower() and not re.match(r'^(?:e\.g\.|i\.e\.|[a-z]+://|iOS|eCommerce|eCom|[a-z]{1,3}[A-Z])', s): s = s[0].upper() + s[1:]   # "aATP", "eBay", "iPad" keep their case
    if marker in (H,) + GLYPHS or bullet or re.match(r'^\d+\. ', s):
        s = s.rstrip('.').rstrip()
    if marker == H:
        s = s.rstrip(':')
        if len(s) > HEAD_MAX: s = clause(s, HEAD_MAX)
    return marker + s


def polish_fills(fills):
    out = {}
    for k, v in fills.items():
        if isinstance(v, str): out[k] = polish_text(v)
        elif isinstance(v, list) and v and isinstance(v[0], list): out[k] = [[polish_text(c, bullet=True) if isinstance(c, str) else c for c in row] for row in v]
        elif isinstance(v, list): out[k] = [polish_text(x) if isinstance(x, str) else x for x in v]
        else: out[k] = v
    return out


def dedupe_headings(fills):
    """A box heading identical to the slide headline says nothing twice: drop it."""
    title = str(fills.get('title', '')).strip().lower()
    for k in ('text1', 'text2'):
        v = fills.get(k)
        if title and isinstance(v, list) and v and str(v[0]).startswith(H) and v[0][len(H):].strip().lower() == title:
            fills[k] = v[1:] if len(v) > 1 and v[1] != '' else v[2:] if len(v) > 2 else []
            if not fills[k]: fills[k] = ['']
    return fills


ACCENTS = ['orange', 'red', 'pink', 'magenta', 'berry']
TAKEAWAY_LABELS = ('key point', 'takeaway', 'take-away', 'in short', 'key message', 'summary')
CALLOUT_LABELS = ('decision', 'ask', 'asks', 'next step', 'next steps', 'recommendation', 'action', 'action required', 'we need', 'request', 'bottom line', 'so what')
ASK_LABELS = CALLOUT_LABELS[:10]   # only these reach the "What we need from you" slide; a bottom line is a strip on its own slide
PAIRS = [('before', 'after'), ('current', 'future'), ('current state', 'future state'), ('as-is', 'to-be'), ('as is', 'to be'), ('today', 'tomorrow'),
         ('now', 'next'), ('problem', 'solution'), ('pros', 'cons'), ('option a', 'option b'), ('challenge', 'response'), ('old', 'new'), ('from', 'to')]
NUM = re.compile(r'(?<![\w{#/.\-])(\$?\d[\d,]*(?:\.\d+)?(?:\s?(?:%|percent|ms|min|hrs?|hours?|days?|weeks?|months?|k|K|M|B|bn|x|units?|stores?|SKUs?|orders?|customers?|FTEs?))?)(?![\w}])')
DATE = re.compile(r'^(?:Q[1-4]\s?(?:FY)?\s?\d{2,4}|FY\s?\d{2,4}(?:\s?Q[1-4])?|(?:\d{1,2}\s)?(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?(?:\s\d{1,2})?(?:,?\s?\d{4})?|\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}(?:/\d{2,4})?|(?:H[12]|Wave\s?\d+|Phase\s?\d+|Sprint\s?\d+)(?:\s\S+)?)\b', re.I)
# v3.97 "soul" rules: a list's shape picks its infographic before it can fall back to a text box
_MONTHS = r'(?:January|February|March|April|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sept?|Oct|Nov|Dec)\.?(?:\s\d{1,2}(?:st|nd|rd|th)?)?(?:,?\s(?:19|20)\d{2})?|May\s(?:\d{1,2}|(?:19|20)\d{2})'
DATE_IN = re.compile(r'(?:\s*,?\s*\b(?:in|by|during|from|before|until|through|starting|in early|in late|by end of|end of)\s+)?\b((?:Q[1-4]|H[12])(?:\s?(?:FY)?\s?\'?\d{2,4})?|FY\s?\'?\d{2,4}(?:\s?Q[1-4])?|' + _MONTHS + r'|(?:Wave|Phase|Sprint|Week|Month|Day)\s?\d{1,2}|(?:19|20)\d{2})\b')
NUM_LEAD = re.compile(r'^(\$?\d[\d,]*(?:\.\d+)?\s?(?:%|x|[KMB]\b|bn\b|pts?\b|percent\b)?\+?)\s+(\S.{5,60})$')   # "40% of invoices paid early": the figure is the hero
LEAD_LABEL = re.compile(r'^([A-Z][\w &/%().,\'’—–-]{1,44}?):\s+(\S.{11,})$')   # "Option A — Taulia with J.P. Morgan: fastest time to value"
CONCLUDE = re.compile(r'\b(recommend\w*|therefore|so we|we propose|should|must|decision|conclusion|bottom line|in short|overall)\b', re.I)


def hub_label(head, items=None, limit=26):
    """The words in a hub's centre: the name most of the items share ("FIS" in four FIS impacts), else the headline without its
    outline number, cut at a word boundary — a circle holds two or three words, never a clipped sentence."""
    if items:
        toks = [set(re.findall(r'\b(?:[A-Z][A-Z0-9/&.-]{1,9}|[A-Z][a-z]+(?:\s[A-Z][a-z]+)?)\b', re.sub(r'^\W*\w+', '', str(it)))) for it in items]
        common = sorted({t for ts in toks for t in ts if sum(t in x for x in toks) * 2 >= len(toks) and len(toks) >= 3}, key=lambda t: (-sum(t in x for x in toks), -len(t)))
        if common: return common[0]
    h = unnumbered(str(head or '')).strip()
    if len(h) <= limit: return h
    cut = h[:limit + 1].rsplit(' ', 1)[0]
    while ' ' in cut and cut.rsplit(' ', 1)[1].lower() in STORY_TAIL: cut = cut.rsplit(' ', 1)[0]
    return cut.rstrip(',;:—–-')


def enumerated(sentence):
    """'Adopt X, use Y, and retain Z.' → ['Adopt X', 'Use Y', 'Retain Z']: a sentence that lists three or more parts reads as bullets."""
    s = sentence.strip().rstrip('.')
    if '(' in s or ';' in s: return None
    parts = [p.strip() for p in re.split(r',\s+(?:and\s+|or\s+)?', s) if p.strip()]
    if len(parts) < 3 or any(len(p.split()) < 3 or len(p) > 95 for p in parts): return None   # "against effort, adoption, control" is one clause with a list inside, not three points
    if any(re.match(r'(?:which|who|so|but|because|while|although|though|if|when|where|then|however|e\.g\.|i\.e\.|including|such as|etc)\b', p, re.I) for p in parts[1:]): return None
    return [p[0].upper() + p[1:] for p in parts]


def dated_item(text):
    """'Pilot with 50 suppliers in Q3.' → ('Q3', 'Pilot with 50 suppliers.') — one date phrase per item, else None."""
    t = re.sub(r'^\d+[.)]\s*', '', text[2:] if text.startswith(GLYPHS) else text).strip()
    ms = list(DATE_IN.finditer(t))
    if len(ms) != 1: return None
    m = ms[0]; rest = (t[:m.start()] + t[m.end():]).strip(' ,;:—–-')
    rest = re.sub(r'\s+([.,;:])', r'\1', re.sub(r'\s{2,}', ' ', rest)).strip(' ,;:—–-')
    if len(rest) < 6: return None
    return m.group(1).strip(), rest[0].upper() + rest[1:]


LEAD_DASH = re.compile(r'^((?:\d+[.)]\s+)?[A-Z][\w &/%().,\'’-]{1,44}?)\s+[—–]\s+(\S.{11,})$')   # "Inbound Receiving — Space NK product is received…"


def lead_label(text):
    """A list item or paragraph that leads with a short label: (label, body) — at most six words before the colon (or the dash)."""
    m = LEAD_LABEL.match(text[2:] if text.startswith(GLYPHS) else text)
    if not m:
        m = LEAD_DASH.match(text[2:] if text.startswith(GLYPHS) else text)
        if m and (len(m.group(1).split()) > 6 or m.group(1).rstrip().endswith(('.', ',')) or not m.group(2)[:1].isupper()): m = None   # "The team met — and agreed" is a sentence
    elif re.match(r'^[^—–]{1,40}\s[—–]\s\S', m.group(2)):   # "Option 1: ULTA DC — Space NK inventory …": the heading is "Option 1: ULTA DC"
        hd_, bd_ = re.split(r'\s[—–]\s', m.group(2), 1)
        if len(hd_.split()) <= 5 and bd_[:1].isupper(): return m.group(1).strip() + ': ' + hd_.strip(), bd_.strip()
    if not m or len(re.findall(r'\w+', m.group(1).replace('.', ''))) > 7 or m.group(1).strip().lower() in TAKEAWAY_LABELS + CALLOUT_LABELS: return None
    b = m.group(2).strip()
    return m.group(1).strip(), b[0].upper() + b[1:]


def emphasize_numbers(line, accent):
    """Figures in body text get the section colour so the eye lands on them (not in headings or table cells)."""
    if line.startswith(H) or '{' in line: return line
    def rep(m):
        tok = m.group(1)
        tok = tok.strip()
        if re.fullmatch(r'\d{4}', tok) or re.fullmatch(r'\d{1,2}', tok) or re.fullmatch(r'\d+(\.\d+)+', tok): return tok   # years, small counts, versions
        return f'**{tok}**'   # (1k) bold, in the box's own colour
    return NUM.sub(rep, line)


LABEL_ANY = re.compile(r'^([A-Za-z][\w &/%().-]{1,40}):\s*(.+)$')


def split_label(line):
    m = LABEL_ANY.match(str(line).replace('• ', '', 1) if str(line).startswith('• ') else str(line))
    return (m.group(1).strip().lower(), m.group(2).strip()) if m else (None, line)


HEAD_EXTRA = 0.0   # the shrink pass adds half a line per card heading (paragraph spacing that the line count does not see)


def card_cost(card):
    head, lines = card
    return (1 + HEAD_EXTRA if head else 0) + est_lines(lines)


GRAPHIC_KINDS = ('funnel', 'pyramid', 'cycle', 'timeline', 'matrix', 'hub', 'roadmap', 'hexagons')   # drawn on the two-box slide with native shapes
GRAPHIC_N = {'funnel': (3, 8), 'pyramid': (3, 8), 'cycle': (3, 8), 'timeline': (3, 8), 'matrix': (4, 4), 'hub': (3, 8), 'roadmap': (3, 8), 'hexagons': (3, 7)}   # items each can hold


def synth_cards(items, hint):
    """Untitled lines → titled cards so the infographic layouts can show plain text: the label before a colon is the title, else the
    first three or four words; 'steps' numbers them; 'bands' folds everything into two halves; 'cards' keeps three (more become a table
    upstream: the caller's hint is honoured by count)."""
    units = []
    for _, ls in items:
        for l in ls:
            l = l.strip()
            if not l or l.startswith(H): continue
            for m in (GLYPHS + ('◦ ', '▪ ')):
                if l.startswith(m): l = l[len(m):]; break
            l = re.sub(r'^\d+[.)]\s*', '', l).strip()
            if l: units.append(l)
    if len(units) < 3 and hint != 'bands': units = [x for u in units for x in sentences(u)] or units
    if not units: return items, hint
    if hint == 'cards' and len(units) > 3: hint = 'table'          # three cards cannot hold more: the label table takes up to eight rows a slide
    if hint == 'bands' and len(units) > 10: hint = 'table'         # two bands of a long text would overflow
    cap = GRAPHIC_N.get(hint, (3, 8))[1]
    if hint in ('table', 'steps', 'flow') + GRAPHIC_KINDS and len(units) > cap:   # more lines than slots: neighbours share one (the full text stays in the notes)
        per = -(-len(units) // cap); units = [' '.join(units[k:k + per]) for k in range(0, len(units), per)]
    def split(u):
        m = re.match(r'^([^:]{2,28}):\s+(.+)$', u)
        if m: return m.group(1).strip(), m.group(2).strip()          # "Label: text" — the label is the title
        c = clause(u, 40)                                              # else the first clause, if the sentence has one that fits
        if not c.endswith('…') and 10 <= len(c) <= 40 and len(c) < len(u) - 10: return c[0].upper() + c[1:], u.strip()
        words = u.split()
        vm = re.match(r'^((?:\S+\s+){1,5}?)(?:is|are|was|were|has|have|had|will|can|could|must|should|may|might|does|do|did|ensures?|provides?|enables?|validates?|delivers?|requires?|allows?|supports?|drives?|helps?|makes?|gives?|keeps?|runs?|means?|includes?|covers?|uses?|needs?|shows?|remains?|becomes?|reduces?|improves?|creates?|offers?|lets?|brings?)\b', u, flags=re.I)
        if vm and len(vm.group(1).strip()) >= 4: t = vm.group(1).strip().rstrip(',;:.')   # the subject before the verb is the title: "Approved ship schedules", "Capacity"
        else:
            k = 4 if sum(len(w) for w in words[:4]) + 3 <= 30 else 3
            t = ' '.join(words[:k]).rstrip(',;:.').strip()
            if len(t) > 30: t = ' '.join(words[:2]).rstrip(',;:.')
        if t.count('(') > t.count(')'): t = t[:t.rfind('(')].rstrip(' ,;:')   # never end a title on an open bracket
        t = re.sub(r'\s*\([^()]*\)$', '', t).strip()
        TAIL_T = re.compile(r'\s+(?:in|of|for|to|and|or|with|by|on|at|as|the|a|an|is|are|was|were|be|from|into|than|but|per|via|that|which|it|its|against|about|over|under|within|without|across|through|during|between|after|before|up|down|out|off|not|no|also|then|so|if|when|while|both|each|every|all|any|some|this|these|those|their|our|your|\d+|one|two|three|four|five|six|seven|eight|nine|ten)$', re.I)
        while TAIL_T.search(t): t = TAIL_T.sub('', t).strip()                # nor on a function word or a number
        if len(t.split()) == 1 and len(t) < 4 and not (t.isupper() and len(t) >= 2):   # a short acronym ("FIS") is a title; "It" is not
            t = ' '.join(words[:3]).rstrip(',;:.')
            while TAIL_T.search(t) and len(t.split()) > 1: t = TAIL_T.sub('', t).strip()
        return (t[0].upper() + t[1:] if t else 'Point'), u.strip()   # the body keeps the whole sentence — a card should read complete
    if hint == 'bands':
        half = (len(units) + 1) // 2; a, b = units[:half], units[half:] or units[:1]
        ta, _ = split(a[0]); tb, _ = split(b[0])
        return [(ta, ['• ' + x for x in a]), (tb, ['• ' + x for x in b])], hint
    cards = []
    for k, u in enumerate(units, 1):
        t, x = split(u)
        cards.append(((f'{k}. ' if hint == 'steps' else '') + t, [x]))
    return cards, hint


def render(cards):
    """Cards -> paragraph list for one box: heading line (marked), body lines, blank spacer between cards."""
    out = []
    for head, lines in cards:
        if out: out.append('')
        if head: out.append(H + head)
        out.extend(lines)
    plain = lambda l: l and not l.startswith(H) and not l.startswith(GLYPHS) and not re.match(r'^\d{1,2}\. ', l)
    if any(l.startswith('• ') for l in out) and any(plain(l) for l in out):   # a box that mixes bullets and bare lines reads as one list
        out = [('• ' + l) if plain(l) else l for l in out]
    return out


def pack(cards, limit=None):
    limit = limit or PACK_LINES
    """Pack cards (heading, lines) into boxes of <= limit estimated lines, in order.
    A card longer than a box is split across boxes (continuation has no heading)."""
    boxes, cur, used = [], [], 0
    for head, lines in cards:
        cost = card_cost((head, lines)); spacer = 1 if cur else 0
        if cur and (used + spacer + cost > limit or len(cur) >= CARDS_PER_BOX):
            boxes.append(cur); cur, used = [], 0; spacer = 0
        if cost > limit:                       # split one long card across boxes
            rest = list(lines); first = True
            while rest:
                room = limit - used - (1 if cur else 0) - (1 if (first and head) else 0)
                if room < 3 and cur:
                    boxes.append(cur); cur, used = [], 0; continue
                take = split_lines(rest, max(1, room))[0]
                if cur and est_lines(take) > room:            # next paragraph does not fit the room left: close this box
                    boxes.append(cur); cur, used = [], 0; continue
                cur.append((head if first else None, take)); used += card_cost(cur[-1]) + (1 if len(cur) > 1 else 0)
                rest = rest[len(take):]; first = False
            continue
        cur.append((head, lines)); used += spacer + cost
    if cur: boxes.append(cur)
    return boxes


def pack_at(cards, pt):
    """Pack with the box metrics of a smaller font: more characters per line and more lines per box."""
    global BOX_CHARS, BOX_LINES, PACK_LINES, CARDS_PER_BOX, HEAD_EXTRA
    keep = (BOX_CHARS, BOX_LINES, PACK_LINES, CARDS_PER_BOX, HEAD_EXTRA); f = 14.0 / pt
    lines = int(keep[1] * f) - 1                                  # one line of slack: rendered spacing is not proportional to the font size
    BOX_CHARS, BOX_LINES, PACK_LINES, CARDS_PER_BOX, HEAD_EXTRA = int(keep[0] * f), lines, lines, 99, 0.5   # brief's two-cards-a-box cap does not apply when shrinking
    try: return pack(cards, BOX_LINES)
    finally: BOX_CHARS, BOX_LINES, PACK_LINES, CARDS_PER_BOX, HEAD_EXTRA = keep


def balance(cards):
    """Split a short list of cards into two boxes of similar height (both boxes always used)."""
    if len(cards) > 1 and all(h is None for h, _ in cards):
        cards = [(None, [l for _, ls in cards for l in ls])]        # untitled boxes from a first-fit pack are one list: split it evenly by wrapped lines
    if len(cards) == 1:
        head, lines = cards[0]
        if len(lines) == 1 and len(sentences(lines[0])) > 1:
            s = sentences(lines[0]); h = (len(s) + 1) // 2
            return [(head, [' '.join(s[:h])])], [(None, [' '.join(s[h:])])]
        if len(lines) > 1:                                  # split where the estimated wrapped lines balance, not at the middle item
            total = est_lines(lines); acc = 0; h = 1
            for k, l in enumerate(lines[:-1], 1):
                acc += est_lines([l]); h = k
                if acc >= total / 2: break
            # v6.18: a sub-heading never ends a box (its text went to the other box) and no box starts or ends on a blank line
            isH = lambda l: str(l).startswith(H) or not str(l).strip()
            k = h
            while 1 < k < len(lines) and isH(lines[k - 1]): k -= 1
            if 1 <= k < len(lines) and not isH(lines[k - 1]): h = k
            trim = lambda ls: [x for i, x in enumerate(ls) if str(x).strip() or (0 < i < len(ls) - 1 and str(ls[i - 1]).strip())]
            strip_ends = lambda ls: ls[next((i for i, x in enumerate(ls) if str(x).strip()), len(ls)):len(ls) - next((i for i, x in enumerate(reversed(ls)) if str(x).strip()), 0)]
            return [(head, strip_ends(trim(lines[:h])))], [(None, strip_ends(trim(lines[h:])))]
        return [cards[0]], []
    costs = [card_cost(c) for c in cards]
    side = lambda lst: sum(lst) + len(lst) - 1          # cards plus the blank spacer lines between them
    ok = [i for i in range(1, len(cards)) if side(costs[:i]) <= BOX_LINES and side(costs[i:]) <= BOX_LINES and i <= CARDS_PER_BOX and len(cards) - i <= CARDS_PER_BOX]
    cand = ok or list(range(1, len(cards)))
    best = min(cand, key=lambda i: abs(side(costs[:i]) - side(costs[i:])))   # most even halves that still fit
    return cards[:best], cards[best:]


HEADLINE_MAX = 50   # the slide-6 headline box holds two lines at 36 pt; the builder steps long ones to 32 / 30 / 28 pt before clipping


HEADLINE_FIT = 72   # v6.18: up to this many characters a headline fits one line by shrinking (34 → 20 pt); longer ones are cut at a phrase


def card_body(ls):
    """v6.18 — a card's lines as separate paragraphs (they were joined with a space: "…a tight market Reservation fees are…" read as one
    run-on sentence); bullet glyphs and blank lines dropped."""
    out = [(l[2:] if l.startswith(GLYPHS) else l).strip() for l in ls]
    return '\n'.join(l for l in out if l and not l.startswith('#'))


def card_rows(titles, bodies):
    """v6.18 — the cards slide as the template draws it: the titles, then a card's lines one per body row (the template has two body rows:
    a sentence, then a supporting point); a third line joins the second row. Rows nobody fills are trimmed."""
    lines = [[x for x in card_body(ls).split('\n') if x.strip()] for ls in bodies]
    r1 = [ls[0] if ls else '' for ls in lines]; r2 = ['\n'.join(ls[1:]) for ls in lines]
    return [titles, r1] + ([r2] if any(x.strip() for x in r2) else [])


def short_headline(text, limit=None):
    """Cut a long section name to the headline box: prefer the part before ':' / ' — ' / ' - ', then a word boundary."""
    limit = limit or HEADLINE_MAX; s = text.strip()
    if len(s) <= limit: return s
    if len(s) <= HEADLINE_FIT: return s   # v6.18: the builder fits it to one line (down to 20 pt) — no cut, never "…" (v53: no text ends in '…')
    for sep in (':', ' — ', ' – ', ' - ', ' ('):
        head = s.split(sep, 1)[0].strip()
        if 12 <= len(head) <= HEADLINE_FIT: return head
    return story_headline(s, HEADLINE_FIT)   # a phrase boundary, never mid-phrase with "…"


def unnumbered(h):
    """A chapter heading without its own outline number ("1. Integration mechanisms" → "Integration mechanisms"): the agenda and the
    dividers number chapters themselves, so "2 · 1. Integration mechanisms" read as two numbers that disagree."""
    s = re.sub(r'^\s*(?:(?:section|chapter|part)\s+)?(?:\d+(?:\.\d+)+[.):]?|\d+[.):]|[ivxlc]+[.):]|[a-z][.):])\s+(?=\S)', '', str(h), flags=re.I)
    return s if len(s) >= 3 else str(h)


STORY_TAIL = {'a', 'an', 'the', 'of', 'and', 'or', 'to', 'for', 'with', 'by', 'in', 'on', 'at', 'across', 'both', 'from', 'into', 'than', 'rather', 'as', 'is', 'are', 'its', 'their', 'what', 'how', 'who',
              'before', 'after', 'when', 'while', 'they', 'it', 'we', 'you', 'that', 'which', 'so', 'but', 'if', 'until', 'can', 'will', 'must', 'be', 'our', 'your', 'this', 'these'}   # v6.18


def story_headline(text, limit=None):
    """A storyboard headline that is a whole sentence ("Volatility makes unmanaged supply allocation a material business risk"):
    cut it at a phrase boundary, never mid-phrase with "…" — the whole sentence goes on the slide as its key point."""
    limit = limit or HEADLINE_MAX; s = text.strip().rstrip('.')
    if len(s) <= limit: return s
    for sep in (':', ' — ', ' – ', ' - ', ', ', ' (', ' because ', ' so that ', ' while ', ' before ', ' after ', ' when ', ' without ', ' rather than ', ' through ', ' across ', ' by ', ' for ', ' to '):
        head = s.split(sep, 1)[0].strip()
        if 18 <= len(head) <= limit: return head
    words = s[:limit + 1].rsplit(' ', 1)[0].split()
    while len(words) > 3 and words[-1].lower().strip(',;:') in STORY_TAIL: words.pop()
    return ' '.join(words).rstrip(',;:')


DEFAULT_ROLES = {"cover": 1, "agenda": 2, "divider": 5, "two_col": 6, "cards3": 7, "metrics3": 9, "actions": 12, "grid6": 14, "steps4": 20, "closing": 32}


def template_roles(template, tdir=None):
    """Slide numbers per layout role for a template id, from templates/manifest.json (STANDARD33 defaults otherwise)."""
    tdir = tdir or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), *'modules/ultabranddeliverables/scripts/kit/templates'.split('/'))
    try:
        entry = json.load(open(os.path.join(tdir, 'manifest.json'), encoding='utf-8'))['templates'][template]
    except Exception:
        return dict(DEFAULT_ROLES) if template == 'STANDARD33' else {}
    return entry.get('roles') or (dict(DEFAULT_ROLES) if template == 'STANDARD33' else {})


def build(blocks, title, source_url, template='STANDARD33', icons=True, infographics=True, density='brief', roles=None, appendix_slides=True, hints=None,
          dividers=True, merge_cost=3, table_scale=1.0, cell_max=170, labels=None, frame=True, text_pt=None, storyboard=False, soft=None):
    hints = hints or {}
    dhints = {k: str(v)[8:] for k, v in hints.items() if str(v).startswith('diagram-')}   # diagram styles: only the diagram slide reads them
    def _unnum(b):   # section numbers are document furniture on every input (HTML pastes too): "7.1 Legal" → "Legal", "## 7. Risks" → "Risks"; a "### 1." card keeps its number
        if b[0] != 'h': return b
        h_ = re.sub(r'^\d+(?:\.\d+)+\.?\s+(?=[A-Z(])', '', str(b[2]))
        if b[1] <= 2: h_ = re.sub(r'^\d+\.\s+(?=[A-Z(])', '', h_)
        return (b[0], b[1], h_) + tuple(b[3:])
    blocks = [_unnum(b) for b in blocks]
    blocks = merge_art(list(blocks)) if BUDGETED else infer_diagrams(merge_art(list(blocks)))   # architecture described but not drawn (tables, layers, flow sentences) → a diagram block; a slide budget keeps only the drawn ones
    hints = {k: v for k, v in hints.items() if not str(v).startswith('diagram-')}   # frame=False: no cover and no closing slide — content slides only (a one-slide paste the author wants as one slide)   # {heading text: 'text' | 'cards' | 'steps' | 'table'} from the Adjust step
    soft = set(soft or ())   # headings whose layout the AI planner chose (not the author): the variety rule may redraw them
    col_labels = labels or {}   # {heading text: column label for the 'table' layout ("Control", "System"…)}
    global PACK_LINES, MAX_BULLETS, BULLET_CHARS, CARDS_PER_BOX, MERGE_COST, TABLE_SCALE, CELL_MAX, BULLET_WHOLE, DECK_PT
    d = DENSITY.get(density, DENSITY['brief']); DECK_PT = text_pt if text_pt is not None else d.get('TEXT_PT')
    PACK_LINES, MAX_BULLETS, BULLET_CHARS, CARDS_PER_BOX = d['PACK_LINES'], d['MAX_BULLETS'], d['BULLET_CHARS'], d['CARDS_PER_BOX']; BULLET_WHOLE = d.get('BULLET_WHOLE', True)
    MERGE_COST, TABLE_SCALE, CELL_MAX = merge_cost, table_scale, cell_max
    R = roles if roles is not None else template_roles(template)
    if 'two_col' not in R or 'cover' not in R:
        raise SystemExit(f'template {template} has no layout roles (cover, two_col …) in templates/manifest.json — map its slides in Settings → Templates first')
    warnings = []
    src_note = f'Source: {title}' + (f' — {source_url}' if source_url else '')
    slides = [{'source': R['cover'], 'kind': 'cover', 'fills': {'title': title}, 'notes': src_note}] if frame else []
    h1s = [b[2] for b in blocks if b[0] == 'h' and b[1] == 1]
    multi = len(h1s) >= 3                 # chapters (agenda + dividers) need three or more H1 sections; two H1s are simply two slides
    _h1_at = [k for k, b in enumerate(blocks) if b[0] == 'h' and b[1] == 1]
    _chapters = len(_h1_at) == 2 and all(sum(1 for b in blocks[a:z] if b[0] == 'h' and b[1] == 2) >= 2 for a, z in zip(_h1_at, _h1_at[1:] + [len(blocks)]))
    if 1 < len(h1s) < 3 and not _chapters: blocks = [('h', 2, b[2]) if b[0] == 'h' and b[1] == 1 else b for b in blocks]; h1s = []
    # v6.25: two H1s that each hold two or more sections are chapters (two process templates in one deck): kept as H1, so no section
    # of the first spills into the second as a card - two H1 topics without sections are still simply two slides
    if multi and 'agenda' in R:
        if len(h1s) > 10: warnings.append(f'{len(h1s)} H1 sections; the agenda slide holds 10 — first 10 listed')
        ag = {'source': R['agenda'], 'kind': 'agenda', 'fills': {'text1': 'Agenda', 'table': [[str(i), unnumbered(h)] for i, h in enumerate(h1s[:10], 1)]}, 'notes': src_note, 'trim_empty_rows': True}   # fewer than 5 sections: no blank ruled rows
        if len(h1s) > 5: ag['grow_rows'] = True     # builder adds rows (halving the row height) instead of dropping sections
        slides.append(ag)
    # page sub-title lines before the first heading (product line, "Proprietary & Confidential") are cover metadata, not content
    first_h = next((i for i, b in enumerate(blocks) if b[0] == 'h'), len(blocks))
    pre = blocks[:first_h]
    lead = next((i for i, b in enumerate(pre) if b[0] not in ('p', 'ul')), len(pre))   # leading text lines (a table may follow)
    pre_lines = [l for b in pre[:lead] if b[0] in ('p', 'ul') for l in (b[1] if b[0] == 'ul' else [b[1]])]
    if pre_lines and first_h < len(blocks) and len(pre_lines) <= 4 and all(len(l) <= 60 and not re.search(r'[.!?]\s|[.!?]$', l) for l in pre_lines):
        blocks = blocks[lead:]   # only when a heading follows: a paste that is nothing but three short lines or bullets is the slide, not cover metadata

    # an H3 that has H4 children is a sub-section headline (its H4s become cards); a childless H3 is a card
    h3_parent = set()
    for i, b in enumerate(blocks):
        if b[0] == 'h' and b[1] == 3:
            for c in blocks[i + 1:]:
                if c[0] == 'h':
                    if c[1] <= 3: break
                    if c[1] == 4: h3_parent.add(i); break
    section, headline, n_h1 = title, title, 0
    slides_at_headline = len(slides)
    marks = [(len(slides), title)]        # (first slide index, headline) — which outline section each slide came from
    intro, cards, cur = [], [], None     # cur = [heading, lines] being filled
    last_tbl = None                      # (slide index, headline) of the last table slide: a short tail after a table becomes its takeaway line
    quotes = []                          # blockquotes under the current headline → speaker notes
    carry = []                           # tiny segments (<= 3 lines) wait to join the next slide as cards
    accent_of = {}                       # section -> palette accent (chapter colour)
    asks = []                            # (label, text, section) collected for the "What we need from you" slide
    appendix = []                        # (section headline, [full paragraphs]) cut by Brief mode
    def accent():
        # One accent for the whole deck: the box bars, takeaway lines and graphic lead colour are the template orange on every slide.
        # (It cycled orange → red → pink → magenta → berry by chapter, so the same theme showed different bar colours slide to slide.)
        return accent_of.setdefault(section, ACCENTS[0])

    def clean(line):
        s = line.strip()
        if not s or BOILERPLATE.match(s): return None
        if UI_JUNK.search(s):
            warnings.append(f'dropped web-page UI text under "{headline}": "{s[:60]}"'); return None
        return re.sub(r'\*\*(.*?)\*\*', r'\1', s)

    def infographic(items, head, note, hint=None, takeaway=None):
        """Route content that has a visual shape to the template's infographic slides.
        3-4 numbered cards ("1. Title") -> slide 20 process steps; exactly 3 short titled cards -> slide 7 cards.
        hint 'steps' / 'cards' (Adjust step) forces the route when the section has 3–8 / 3 titled cards even without numbers."""
        # an untitled intro before the cards does not block the infographic: one short sentence becomes the takeaway, more goes to the notes
        intro_ls = [l for h, ls in items if not h for l in ls]; items = [(h, ls) for h, ls in items if h] if intro_ls and any(h for h, _ in items) else items
        head, intro_tk = label_headline(head, None); intro_tk = intro_tk or takeaway   # a takeaway lifted from the section's first line stays on the slide, above the drawing
        if intro_ls:
            lines_ = [l[2:] if l.startswith(('• ', '– ')) else l for l in intro_ls]; it = ' '.join(lines_); ss = [x for l in lines_ for x in sentences(l)]   # brief bullets carry no full stop: each is a sentence
            if ss and len(ss[0]) <= 140 and not intro_tk: intro_tk = ss[0].rstrip('.')   # first sentence above the infographic, the rest in the notes
            if len(ss) > 1 or not intro_tk: note = note + ' — intro: ' + it
        titled = [(h, ls) for h, ls in items if h]
        if hint == 'table' and 'actions' in R and 3 <= len(titled) <= 16:   # more than a slide holds: the rows split evenly over two slides
            # titled cards as a label table (coloured label + description): the infographic for 4–8 parallel items
            rows = [[re.sub(r'^\d+[.)]\s*', '', t), ' '.join(l[2:] if l.startswith(('• ', '– ')) else l for l in ls), ''] for t, ls in titled]
            rows, more = trim_cells(rows, warnings, head, limit=(max(CELL_MAX, 420) if len(titled) <= 5 else max(CELL_MAX, 270)) if len(titled) <= 7 and CELL_MAX >= 170 else None)   # a label table's text column is wide: up to 5 rows keep ~420 characters, up to 7 ~270
            parts, tpt = chunk_rows_fit(rows, ACTIONS_ROWS, 'actions')
            for part_i, part in enumerate(parts):
                col = col_labels.get(headline.strip()) or col_labels.get(head.strip()) or 'Item'
                col, col2 = (col.split('|', 1) + ['What it covers'])[:2] if '|' in col else (col, 'What it covers')   # "Parameter|Roadmap view": the source's own header pair
                sl = {'source': R['actions'], 'fills': {'title': head + (' (cont.)' if part_i else ''), 'table': [[col, col2, '']] + part}, 'trim_empty_rows': True, 'trim_empty_cols': True, 'notes': note + (' — full text: ' + ' | '.join(more) if more else ''), 'accent': accent(), 'cards': [t for t, _ in titled]}
                if len(part) > 4: sl['grow_rows'] = True
                if tpt: sl['table_font_pt'] = tpt
                if intro_tk and not part_i: sl['takeaway'] = intro_tk
                slides.append(sl)
            return True
        if hint == 'cards' and 'cards3' in R and len(titled) == 3:
            fills = {'title': head, 'table': card_rows([re.sub(r'^\d+[.)]\s*', '', h) for h, _ in titled], [ls for _, ls in titled])}
            slides.append(dict({'source': R['cards3'], 'fills': fills, 'trim_empty_rows': True, 'notes': note, 'accent': accent(), 'cards': [h for h, _ in titled]}, **({'takeaway': intro_tk} if intro_tk else {})))
            return True
        numbered = [(re.sub(r'^\d+[.)]\s*', '', h), ls, None) for h, ls in items if h and re.match(r'^\d+[.)]\s', h)]
        if hint in ('steps', 'flow') and 3 <= len([1 for h, _ in items if h]) <= 8: numbered = [(re.sub(r'^\d+[.)]\s*', '', h), ls, None) for h, ls in items if h]
        dated = []
        for h, ls in items:
            m = DATE.match(h or '')
            if h and m and len(h) > len(m.group(0)): dated.append((h[m.end():].strip(' —–:-'), ls, m.group(0)))
        steps = numbered if len(numbered) == len(items) else dated if len(dated) == len(items) else []
        if hint in GRAPHIC_KINDS and 'two_col' in R and GRAPHIC_N[hint][0] <= len(titled) <= GRAPHIC_N[hint][1]:   # drawn infographics (opt-in): funnel, pyramid, cycle, timeline, matrix, hub, roadmap, hexagons
            plain = lambda ls: ' '.join((l[len(H):] + ':') if l.startswith(H) else (l[2:] if l.startswith(GLYPHS) else l) for l in ls if l)
            def legend_text(ls):   # the legend beside a shape has room for a whole sentence (two short ones), never a clause cut mid-thought
                ss = sentences(plain(ls)) if ls and plain(ls) else []
                if not ss: return ''
                out = ss[0]
                if len(ss) > 1 and len(out) + len(ss[1]) + 1 <= 200: out = out.rstrip('.') + '. ' + ss[1]
                return out if len(out) <= 220 else clause(out, 220)
            items_g = [{'title': re.sub(r'^\d+[.)]\s*', '', t) if len(t) <= 40 else story_headline(re.sub(r'^\d+[.)]\s*', '', t), 40), 'text': legend_text(ls)} for t, ls in titled]
            full = ' | '.join(f'{k}. {t}: {" ".join(ls)}' for k, (t, ls) in enumerate(titled, 1))
            sl = {'source': R['two_col'], 'fills': {'title': head, 'text1': [''], 'text2': ['']}, 'hide': ['text1', 'text2'], 'graphic': {'kind': hint, 'items': items_g[:GRAPHIC_N[hint][1]], 'hub': hub_label(head, [f"{t} {' '.join(ls)}" for t, ls in titled] if hint == 'hub' else None)}, 'notes': note + ' — full text: ' + full, 'accent': accent(), 'cards': [h for h, _ in items if h]}
            if intro_tk: sl['takeaway'] = intro_tk
            slides.append(sl); return True
        if hint == 'flow' and 'two_col' in R and 5 <= len(steps) <= 8:   # opt-in ("Layout: flow"): 5–8 steps drawn on one slide; otherwise the template's own process slide, split evenly
            plain = lambda ls: ' '.join((l[len(H):] + ':') if l.startswith(H) else (l[2:] if l.startswith(GLYPHS) else l) for l in ls if l)   # no markers on a card
            flow = [{'title': name if len(name) <= 42 else story_headline(name, 42), 'text': clause(sentences(plain(ls))[0], 110) if ls else '', 'when': when} for name, ls, when in steps]
            for f_ in flow:   # a caption that only restates its box ("Invoice approved in SAP" over "Invoice approved in SAP S/4HANA"): say it once
                core_ = f_['title'].rstrip('…').strip(); txt_ = f_['text'].strip()
                if core_ and txt_.lower().startswith(core_.lower()):
                    rest_ = txt_[len(core_):].strip(' —–-:,;')
                    if len(txt_) <= 42: f_['title'], f_['text'] = txt_.rstrip('.'), ''
                    elif len(rest_.split()) >= 3: f_['text'] = rest_[0].upper() + rest_[1:]
            full = ' | '.join(f'{when or k}. {n}: {" ".join(ls)}' for k, (n, ls, when) in enumerate(steps, 1))
            sl = {'source': R['two_col'], 'fills': {'title': head, 'text1': [''], 'text2': ['']}, 'hide': ['text1', 'text2'], 'flow': flow, 'notes': note + ' — full text: ' + full, 'accent': accent(), 'cards': [h for h, _ in items if h]}
            if intro_tk: sl['takeaway'] = intro_tk
            slides.append(sl); return True
        if 'steps4' in R and 3 <= len(steps) <= 8:
            per = -(-len(steps) // -(-len(steps) // 4))   # balanced: 6 → 3 + 3, 7 → 4 + 3, 5 → 3 + 2 (never a slide of one or two after a full one)
            for part_i, part in enumerate(chunk(steps, per)):
                fills = {'title': head + (' (cont.)' if part_i else '')}
                hdr = []
                for k, (name, ls, when) in enumerate(part, 1):
                    ls0 = [l.lstrip('•-–— ').strip() for l in ls if l.strip() and not l.startswith(H)]
                    first = sentences(ls0[0])[0] if ls0 else ''   # the first sentence of the step's first line, bullet or not
                    first = clause(first, 80) if len(first) > 88 else first.rstrip('.')   # v6.18: the band above the step boxes holds ~80 characters; past that it ran behind the boxes (the full text is in the notes)
                    fills[f'text{k}'] = name if len(name) <= 40 else story_headline(name, 40)   # v6.18: a phrase boundary, never "…"
                    if first and first[0].islower() and not re.match(r'^[a-z]{1,3}[A-Z]', first): first = first[0].upper() + first[1:]   # "the Studio builds…" starts a sentence
                    hdr.append(f'{when or "Step " + str(k + per * part_i)}\n{first}')
                fills['table'] = [hdr + [''] * (5 - len(hdr))]
                full = ' | '.join(f'{when or k}. {n}: {" ".join(ls)}' for k, (n, ls, when) in enumerate(part, 1))
                slides.append(dict({'source': R['steps4'], 'fills': fills, 'notes': note + ' — full text: ' + full, 'icons': 'auto', 'accent': accent(), 'cards': [h for h, _ in items if h][per * part_i:per * part_i + per]}, **({'takeaway': intro_tk} if intro_tk and not part_i else {})))
            return True
        # three or more "Label: number" lines -> three-metrics slide (first three), the rest stays as text
        flat = [l for _, ls in items for l in ls]
        metric_lines = [(split_label(l)[0], split_label(l)[1]) for l in flat if split_label(l)[0] and NUM.search(split_label(l)[1] or '') and len(split_label(l)[1]) <= 24]
        if 'metrics3' in R and len(metric_lines) >= 3 and len(metric_lines) >= max(3, len(flat) - 2):
            labels = [l.title() for l, _ in metric_lines[:3]]; values = [v for _, v in metric_lines[:3]]
            slides.append({'source': R['metrics3'], 'fills': {'title': head, 'table': [labels, values]}, 'notes': note, 'accent': accent()})
            return True
        titled = [(h, ls) for h, ls in items if h]
        prev_c = next((s_ for s_ in reversed(slides) if s_.get('kind') != 'divider'), None)   # (1ae) cards after cards: a hub
        if hint != 'cards' and 'cards3' in R and 'two_col' in R and len(titled) == 3 and prev_c is not None \
                and prev_c.get('source') == R['cards3'] and family_slide('fam:process list', ['\u2022 ' + h_ + ': ' + re.sub(r'^[\u2022\u2013]\s*', '', ls_[0]) + (' (' + '; '.join(re.sub(r'^[\u2022\u2013]\s*', '', l_) for l_ in ls_[1:]) + ')' if len(ls_) > 1 else '') for h_, ls_ in titled if ls_], None, head, head, note, takeaway, []):
            warnings.append(f'variety: "{head}" follows three cards - drawn as icon rows ("Layout: cards" keeps the cards)')
            return True
        if 'cards3' in R and len(titled) == 3 and (hint == 'cards' or (len(items) == 3 and all(len(h) <= 28 and est_lines(ls) <= 5 for h, ls in titled))):
            fills = {'title': head, 'table': card_rows([h for h, _ in titled], [ls for _, ls in titled])}
            slides.append(dict({'source': R['cards3'], 'fills': fills, 'trim_empty_rows': True, 'notes': note, 'accent': accent(), 'cards': [h for h, _ in titled]}, **({'takeaway': intro_tk} if intro_tk else {})))
            return True
        return False

    def label_headline(head, tk):
        """'Quality: how resilient and maintainable our systems are' → headline 'Quality', takeaway 'How resilient and maintainable our
        systems are' (when the slide has no takeaway of its own): the label is the headline, the phrase the so-what."""
        src = headline if (head or '').endswith('…') and str(headline).startswith((head or '')[:-1].rstrip()) else (head or '')   # the full section name, not its shortened headline
        m = re.match(r'^([A-Z][\w &/-]{1,28}):\s+([a-z].{6,110})$', src)
        if m and not tk: return m.group(1).strip(), m.group(2).strip()[0].upper() + m.group(2).strip()[1:]
        return head, tk

    def emit_text(items, head, note, takeaway, callouts, bands):
        """Two-column text slides for a list of cards (heading, lines): one wide box, two balanced boxes, or packed boxes over several slides."""
        head, takeaway = label_headline(head, takeaway)
        def deco(sl, cs=None):
            if cs: sl['cards'] = [h for h, _ in cs if h] + [l[len(H):] for _, ls in cs for l in ls if isinstance(l, str) and l.startswith(H)]   # card headings on this slide (carried sections keep theirs as marked lines)
            sl['accent'] = accent()
            if takeaway: sl['takeaway'] = takeaway
            if bands: sl['bands'] = bands
            if callouts:
                sl['callouts'] = {('text2' if 'text2' in sl['fills'] and sl['fills']['text2'] != [''] and 'text2' not in sl.get('hide', []) else 'text1'): f'{callouts[0][0].title()}: {callouts[0][1]}'}
                if len(callouts) > 1: sl['callouts']['text1'] = f'{callouts[1][0].title()}: {callouts[1][1]}'
            return sl
        budget = PACK_LINES - (3 if callouts else 0) - (1 if takeaway else 0)
        fits = lambda cs: sum(card_cost(c) for c in cs) + max(0, len(cs) - 1) <= budget and len(cs) <= CARDS_PER_BOX
        total_cost = sum(card_cost(c) for c in items) + len(items) - 1
        # one wide box when the content is light: a few short bullets (no sub-headings) read better as one list than as
        # two thin columns ("this could have just gone into one" — reviewer feedback), and up to ~4 lines in any case
        plain = all(h is None for h, _ in items)
        wide_lines = sum(max(1, -(-len(str(l)) // (2 * BOX_CHARS))) for _, ls in items for l in ls)   # the single box is twice as wide
        if not bands and not callouts and (total_cost <= 4 or (plain and wide_lines <= 8 and len([l for _, ls in items for l in ls]) <= 8)):
            sl = {'source': R['two_col'], 'fills': {'title': head, 'text1': render(items), 'text2': ['']}, 'notes': note, 'hide': ['text2']}
            slides.append(deco(sl, items)); return
        if bands or (total_cost <= 2 * budget):
            left, right = (items[0:1], items[1:2]) if bands else balance(items)
            if bands or (fits(left) and fits(right)):
                sl = {'source': R['two_col'], 'fills': {'title': head, 'text1': render(left), 'text2': render(right) if right else ['']}, 'notes': note}
                if not right and not bands: sl['hide'] = ['text2']          # one box only: the builder removes the empty box and widens the other
                slides.append(deco(sl, left + right))
                return
        boxes = pack(items, budget)
        dense = pack(items, BOX_LINES)
        if -(-len(dense) // 2) < -(-len(boxes) // 2):   # a fuller box beats one more slide holding a stray sentence
            boxes = dense
        text_pt = DECK_PT                               # the deck's one body size — never a smaller face for this section alone
        if DECK_PT and len(boxes) > 2:                  # a smaller deck size: long sections pack at it (a titled card's bullets read as one short paragraph)
            flat = [(h, [' '.join(l[2:].rstrip('.…') + '.' for l in ls)] if h and ls and all(l.startswith('• ') for l in ls) else ls) for h, ls in items]
            sb = pack_at(flat, DECK_PT)
            if -(-len(sb) // 2) < -(-len(boxes) // 2): boxes = sb
        if len(boxes) > 2:                     # several slides: spread the cards evenly over all their boxes (not full, full, full, two lines)
            k = 2 * -(-len(boxes) // 2); cards_all = [c for b in boxes for c in b]; total = sum(card_cost(c) for c in cards_all) + len(cards_all) - 1
            target = total / k; spread, grp, gused = [], [], 0          # (not 'cur': that is the card being filled, nonlocal to flush)
            for c in cards_all:
                cost = card_cost(c) + (1 if grp else 0)
                if grp and gused + cost > target * 1.08 and len(spread) < k - 1: spread.append(grp); grp, gused = [], 0; cost = card_cost(c)
                grp.append(c); gused += cost
            if grp: spread.append(grp)
            cap = int(BOX_LINES * 14.0 / (text_pt or 14)) - (1 if text_pt else 0)
            if -(-len(spread) // 2) <= -(-len(boxes) // 2) and all(sum(card_cost(c) for c in g) + len(g) - 1 <= cap for g in spread): boxes = spread   # same slide count, every box within capacity
        if len(boxes) % 2:                     # last slide would have an empty right box: re-balance its content
            left, right = balance(boxes[-1]); boxes[-1:] = [left] + ([right] if right else [])
        elif len(boxes) >= 2:                  # last pair: even out the two boxes instead of first-fit (12 vs 2 lines)
            left, right = balance(boxes[-2] + boxes[-1]); boxes[-2:] = [left] + ([right] if right else [])
        for k in range(0, len(boxes), 2):
            pair = boxes[k:k + 2]
            fills = {'title': head + (' (cont.)' if k else ''), 'text1': render(pair[0]), 'text2': render(pair[1]) if len(pair) > 1 else ['']}
            sl = {'source': R['two_col'], 'fills': fills, 'notes': note}
            if len(pair) == 1: sl['hide'] = ['text2']
            if text_pt: sl['text_pt'] = text_pt
            cs = pair[0] + (pair[1] if len(pair) > 1 else [])
            slides.append(deco(sl, cs) if k + 2 >= len(boxes) else dict(deco(dict(sl), cs), takeaway=takeaway) if takeaway and k == 0 else deco(dict(sl), cs))

    def shape_list(raw, head, note, tk, plain_ok, only_dated=None):
        """A section that is one list (3–8 items) with at most a lead and a closing paragraph: the list's shape picks the infographic.
        Dates on every item → timeline; three number-led items → metrics; labelled items → three cards or a label table; numbered
        items → the process steps; a plain list right after a label table → hub (never two label tables in a row). The paragraphs
        give the takeaway (a concluding one first); what the slide cannot say stays in the notes. Returns True when a slide was made."""
        lines = [l for l in raw if l.strip() and split_label(l)[0] not in TAKEAWAY_LABELS
                 and (split_label(l)[0] not in CALLOUT_LABELS or l.startswith('• '))]   # (1t) a bulleted ask is a list item
        is_item = lambda l: l.startswith(GLYPHS) or bool(re.match(r'^\d+[.)]\s', l))
        idx = [i for i, l in enumerate(lines) if is_item(l)]
        if not idx or idx != list(range(idx[0], idx[-1] + 1)): return False
        before, lst, after = lines[:idx[0]], lines[idx[0]:idx[-1] + 1], lines[idx[-1] + 1:]
        lab_n = sum(1 for x in lst if lead_label(re.sub(r'^\d+[.)]\s*', '', x[2:] if x.startswith(GLYPHS) else x)))
        if len(lst) == 2 and lab_n == 2 and len(before) <= 1 and not after and 'two_col' in R and all(len(x) <= 320 for x in lst):
            # v6.22: two labelled points ("Fiori App: …", "Common Use Cases: …") are two cards — a box each, the label its heading
            pr = [lead_label(re.sub(r'^\d+[.)]\s*', '', x[2:] if x.startswith(GLYPHS) else x)) for x in lst]
            sl2 = {'source': R['two_col'], 'fills': {'title': head, 'text1': ['## ' + pr[0][0], pr[0][1]], 'text2': ['## ' + pr[1][0], pr[1][1]]}, 'notes': note + ' — list: ' + ' | '.join(lst)}
            if before and not tk: sl2['takeaway'] = before[0].rstrip(':').rstrip('.')
            if tk: sl2['takeaway'] = tk
            slides.append(sl2); return True
        if len(before) > 1 or len(after) > 1 or not 3 <= len(lst) <= 8 or any(len(x) > (280 if lab_n >= 3 else 170) for x in lst): return False   # labelled rows are cut to their gist: long ones are fine
        ss_b = [s for p in before for s in sentences(p)]; ss_a = [s for p in after for s in sentences(p)]
        if len(ss_b) + len(ss_a) > 3: return False
        numbered = all(re.match(r'^\d+[.)]\s', l) for l in lst)
        items = [re.sub(r'^\d+[.)]\s*', '', l[2:] if l.startswith(GLYPHS) else l).strip() for l in lst]
        if not tk:
            concl = next((s for s in ss_a if CONCLUDE.search(s)), None)
            tk = concl or (ss_b[0] if ss_b else ss_a[0] if ss_a else None)
            if tk: tk = tk.rstrip(':').rstrip('.')
            if tk and len(tk) > 220: tk = clause(tk, 200)
        rest = [s for s in ss_b + ss_a if s.rstrip(':').rstrip('.') != (tk or '')]
        note2 = note + (' — also: ' + ' '.join(rest) if rest else '') + ' — list: ' + ' | '.join(items)
        def put(sl):
            if tk: sl['takeaway'] = tk
            slides.append(sl); return True
        dated = [dated_item(x) for x in items]
        if all(dated) and len({d for d, _ in dated}) == len(dated) and 'two_col' in R:
            g = [{'title': d, 'text': x if len(x) <= 220 else clause(x, 220)} for d, x in dated]
            return put({'source': R['two_col'], 'fills': {'title': head, 'text1': [''], 'text2': ['']}, 'hide': ['text1', 'text2'], 'graphic': {'kind': 'roadmap' if only_dated == 'roadmap' else 'timeline', 'items': g, 'hub': hub_label(head)}, 'notes': note2, 'accent': accent(), 'cards': [d for d, _ in dated]})
        if only_dated: return False
        nums = [NUM_LEAD.match(x) for x in items]
        if len(items) == 3 and all(nums) and not any(re.fullmatch(r'(?:19|20)\d{2}', m.group(1).strip()) for m in nums) and 'metrics3' in R and all(len(m.group(2)) <= 48 for m in nums):
            lab = lambda t: re.sub(r'^(?:of|in|on|for|across)\s+', '', t.rstrip('.'))   # "40% of invoices paid early" → 40% · "Invoices paid early"
            return put({'source': R['metrics3'], 'fills': {'title': head, 'table': [[lab(m.group(2))[0].upper() + lab(m.group(2))[1:] for m in nums], [m.group(1).strip() for m in nums]]}, 'notes': note2, 'accent': accent()})
        labs = [lead_label(x) for x in items]
        nl_ = [k for k, l in enumerate(labs) if l]; k0 = len(labs) - len(nl_)
        if 3 <= len(nl_) and nl_ == list(range(k0, len(labs))) and 1 <= k0 <= 3 and 'actions' in R and all(len(labs[k][0]) <= 36 for k in nl_) and not numbered:
            # plain context lines, then labelled items ("Item feed: …", "Retail price feed: …"): the items are a label table, each row its gist;
            # the first context line is the slide's message, the rest one "Context" row — the full text stays in the notes
            def gist(b_):   # the row's point: its first sentence to a clean clause; no clean place to stop → the whole sentence (never a word cut with '…')
                s0 = (sentences(b_)[0] if sentences(b_) else b_).rstrip('.'); c0 = clause(s0, 95)
                return s0 if c0.endswith('…') and len(s0) <= 160 else c0.rstrip('.')
            rows = ([['Context', '; '.join(gist(x) for x in items[1:k0]), '']] if k0 > 1 else []) + [[labs[k][0], gist(labs[k][1]), ''] for k in nl_]
            if not tk: tk = (sentences(items[0])[0] if sentences(items[0]) else items[0]).rstrip('.')
            sl = {'source': R['actions'], 'fills': {'title': head, 'table': [['Item', 'What it covers', '']] + rows}, 'trim_empty_rows': True, 'trim_empty_cols': True, 'notes': note2, 'accent': accent(), 'cards': [r[0] for r in rows]}
            if len(rows) > 4: sl['grow_rows'] = True
            return put(sl)
        if numbered and all(labs) and all(LEAD_DASH.match(x) for x in items) and 'steps4' in R and 3 <= len(items) <= 8:   # "1. Inbound receiving — …": a numbered sequence is the process steps
            cs, _ = synth_cards([(None, items)], 'steps')
            if tk: cs = [(None, [tk])] + cs
            return infographic(cs, head, note2, 'steps')
        if all(labs) and len(labs) == 3 and len({t.lower() for t, _ in labs}) == 2 and 'two_col' in R:   # (1ad) two boxes
            grp_ = {}
            for t_, b_ in labs: grp_.setdefault(t_, []).append(b_)
            (t1_, b1_), (t2_, b2_) = list(grp_.items())
            bl_ = lambda bs: ['• ' + x for x in bs] if len(bs) > 1 else bs
            return put({'source': R['two_col'], 'fills': {'title': head, 'text1': ['## ' + t1_] + bl_(b1_), 'text2': ['## ' + t2_] + bl_(b2_)}, 'notes': note2})
        prev_l = next((s_ for s_ in reversed(slides) if s_.get('kind') != 'divider'), None)   # (1aj) variety
        if all(labs) and 3 <= len(labs) <= 6 and prev_l is not None and 'two_col' in R and all(len(b) <= 150 for _, b in labs) \
                and prev_l.get('source') == (R.get('cards3') if len(labs) == 3 else R.get('actions')) \
                and family_slide('fam:process list', ['• ' + f'{t}: {b}' for t, b in labs], None, head, head, note2, tk, []):
            warnings.append(f'variety: "{head}" follows the same layout - drawn as icon rows')
            return True
        if all(labs):
            if len(labs) == 3 and 'cards3' in R and all(len(b) <= 220 for _, b in labs):
                return put({'source': R['cards3'], 'fills': {'title': head, 'table': [[t for t, _ in labs], [b for _, b in labs]]}, 'trim_empty_rows': True, 'notes': note2, 'accent': accent(), 'cards': [t for t, _ in labs]})
            if len(labs) >= 4 and 'actions' in R and all(len(t) <= 36 for t, _ in labs):
                rows, more = trim_cells([[t, b, ''] for t, b in labs], warnings, head)
                sl = {'source': R['actions'], 'fills': {'title': head, 'table': [['Item', 'What it covers', '']] + rows}, 'trim_empty_rows': True, 'trim_empty_cols': True, 'notes': note2 + (' — full text: ' + ' | '.join(more) if more else ''), 'accent': accent(), 'cards': []}
                if len(rows) > 4: sl['grow_rows'] = True
                return put(sl)
            return False
        if numbered and 'steps4' in R and 3 <= len(items) <= 8:
            cs, _ = synth_cards([(None, items)], 'steps')
            if tk: cs = [(None, [tk])] + cs
            return infographic(cs, head, note2, 'steps')
        last = next((s for s in reversed(slides) if s.get('kind') != 'divider'), None)   # a chapter divider may yet be left out: look past it
        prev_table = last is not None and last.get('source') == R.get('actions') and last.get('kind') is None
        list_tables = sum(1 for s in slides if s.get('source') == R.get('actions') and 'cards' in s)
        if (prev_table or list_tables >= 2) and len(items) <= 6 and 'two_col' in R:   # variety: a list right after a label table is drawn, not tabled again
            cs, _ = synth_cards([(None, items)], 'hub')
            if not infographic(cs, head, note2, 'hub', tk): return False
            slides[-1]['graphic']['hub'] = hub_label(head, items); return True
        if plain_ok and len(items) == 3 and 'cards3' in R and all(len(x) <= 160 for x in items):
            cs, _ = synth_cards([(None, items)], 'cards')
            if len({str(t).lower() for t, _ in cs}) == 2 and 'two_col' in R:   # (1ad) a repeated label: two boxes
                grp_ = {}
                for t_, ls_ in cs: grp_.setdefault(t_, []).extend(ls_)
                (t1_, b1_), (t2_, b2_) = list(grp_.items())
                bl_ = lambda bs: ['• ' + x for x in bs] if len(bs) > 1 else bs
                return put({'source': R['two_col'], 'fills': {'title': head, 'text1': ['## ' + t1_] + bl_(b1_), 'text2': ['## ' + t2_] + bl_(b2_)}, 'notes': note2})
            return put({'source': R['cards3'], 'fills': {'title': head, 'table': card_rows([t for t, _ in cs], [ls for _, ls in cs])}, 'trim_empty_rows': True, 'notes': note2, 'accent': accent(), 'cards': [t for t, _ in cs]})
        if plain_ok and len(items) >= 4 and 'actions' in R and all(len(x) <= 150 for x in items):
            rows = [[str(k), x, ''] for k, x in enumerate(items, 1)]
            sl = {'source': R['actions'], 'fills': {'title': head, 'table': [['#', 'What it covers', '']] + rows}, 'trim_empty_rows': True, 'trim_empty_cols': True, 'notes': note2, 'accent': accent(), 'cards': [], 'label_col_in': 1.5}
            if len(rows) > 4: sl['grow_rows'] = True
            return put(sl)
        return False

    def family_slide(hint, raw, items, head, headline, note, tk, callouts):
        """v6.22 — Presentation Central v93's families on a Studio deck: a "Layout:" line naming one ("timeline quarters", "swimlane
        handoffs", "OGSM", "kpi cards" …), or with no layout line a dated list with a date range (→ timeline) or a process written
        "Role: step" under a process heading (→ cross-functional swimlane). Sub-headings are the timeline's workstreams / the
        scorecard's groups. Returns True when the slide was made; otherwise the section keeps its usual layout."""
        try:
            import family_rules as FR, central_slides as CS
            CS.engines()
        except Exception:   # a kit without Presentation Central (the standalone skill): the section keeps its usual layout
            return False
        explicit = isinstance(hint, str) and hint.startswith('fam:')
        ai_pick = hint not in (None, 'auto') and (headline.strip() in soft or head.strip() in soft)   # a layout the AI chose: the data's own shape (dates, roles, numbers) wins
        if not explicit and (not infographics or (hint not in (None, 'auto') and not ai_pick) or callouts): return False
        if raw is not None:
            lines_ = [l for l in raw if l.strip()]; groups_ = [None] * len(lines_)
        else:
            lines_, groups_ = [], []
            for h, ls in items:
                for l in ls:
                    if l.strip() and not l.startswith(H): lines_.append(l); groups_.append(h)
        is_item = lambda l: l.startswith(GLYPHS) or bool(re.match(r'^\d+[.)]\s', l))
        bl = [k for k, l in enumerate(lines_) if is_item(l)]
        lead = None
        if bl and len(bl) >= 2 and len(lines_) - len(bl) <= 1:   # one lead sentence above (or carried into) the list is its takeaway
            other = [l for k, l in enumerate(lines_) if k not in bl]; lead = other[0].rstrip(':').rstrip('.') if other else None
            lines_, groups_ = [lines_[k] for k in bl], [groups_[k] for k in bl]
        got = FR.from_hint(hint[4:], lines_, head, groups_) if explicit else FR.auto(headline, lines_, groups_)
        if not got:
            if explicit and not ai_pick: warnings.append(f'"{head}": the content does not have the shape "{hint[4:]}" needs — kept as text (see the Layout help)')   # v6.30 an AI pick that does not fit falls back quietly
            return False
        fam, style, data = got
        if fam in ('retail', 'process'):   # v6.23: a retail starter brings its takeaway and its "add from your data" note
            data = dict(data); st_head = data.pop('_headline', None); st_note = data.pop('_notes', None)
            if st_head and FR.is_label(head): note = note + ' — headline was: ' + head; head = st_head
            if st_note: note = (note + ' — ' if note else '') + st_note
        tk_head = FR.takeaway(fam, style, data, head)   # v92: a topic label becomes a takeaway computed from the data ("Delivery plan: 2 teams, 4 tasks, go-live Sep 1")
        if tk_head: note = note + ' — headline was: ' + head; head = tk_head
        cs = {'headline': head, 'notes': note + ' — ' + ' | '.join(re.sub(r'^[•–]\s*', '', l) for l in lines_)}
        if fam in ('timeline', 'swimlane'): cs.update({fam: data, 'style': style})
        elif fam in ('retail', 'process'): cs.update({fam: data, 'style': style})
        elif fam == 'modern': cs.update(dict(data, modern=style))
        else: cs.update(data)
        sl = CS.to_spec_slide(cs, R)
        if not sl: return False
        tk2 = tk or lead
        if tk2:
            if 'title' in sl.get('fills', {}): sl['takeaway'] = tk2
            else: sl['notes'] = sl.get('notes', '') + ' — key point: ' + tk2   # a template infographic slide has no line for it
        slides.append(sl); return True

    def flush(final=False):
        """Emit slide-6 slides for the current headline: intro + sub-section cards packed into the two boxes."""
        nonlocal intro, cards, cur, headline
        if cur and cur[1]: cards.append(tuple(cur))
        cur = None
        auto_hint = None
        if infographics and not cards and not carry and 2 <= len(intro) <= 4 and not (hints.get(headline.strip()) or hints.get(short_headline(headline).strip())):
            # an executive summary written as bold-labelled paragraphs ("IT recommendation: …", "Recommended target model: …") is a
            # statement slide: two become bands, three titled cards, four a label table — never two grey text boxes
            labs = [lead_label(l) for l in intro]
            if all(labs) and all(len(b) >= 40 for _, b in labs) and not any(l.startswith(GLYPHS) for l in intro) and (len(labs) != 3 or all(len(b) <= 260 for _, b in labs)):
                cards = [(t, ['• ' + x for sen in sentences(b) for x in (enumerated(sen) or [sen.rstrip('.')])]) for t, b in labs]; intro = []   # whole sentences: the summary is never clipped to a clause
                auto_hint = {2: 'bands', 3: 'cards', 4: 'table'}[len(labs)]
                if len(labs) >= 3 and all(re.match(r'^\d+[.)]\s', l) for l in intro): auto_hint = 'steps'   # "1. Inbound receiving — …" numbered: the process steps
        lead_carry = (not cards and len(carry) == 1 and carry[0][0] is None and len(carry[0][1]) == 1 and intro
                      and sum(1 for l in intro if l.startswith(GLYPHS) or re.match(r'^\d+[.)]\s', l)) >= 3)   # v6.22: the page's one-sentence lead before a list section is the list's lead line
        if lead_carry:
            intro = [re.sub(r'^[•–]\s*', '', carry[0][1][0])] + list(intro); carry.clear()
        raw = list(intro) if not cards and not carry else None   # the section as written (before sentences become bullets): its list shape picks the layout
        overflow = []
        whole = (hints.get(headline.strip()) or hints.get(short_headline(headline).strip())) == 'table' and cards   # a label table's text column holds whole sentences: no clause cut
        items = ([(None, slidify(intro, overflow))] if intro else []) + [(h, (list(l) if whole else slidify(l, overflow))) for h, l in cards if l]
        intro, cards = [], []
        if not items and not (final and carry):
            sh_ = hints.get(headline.strip()) or ''
            if isinstance(sh_, str) and sh_.startswith('fam:retail ') and headline:   # v6.23: "Layout: retail inventory-count" alone - the starter's standard steps
                family_slide(sh_, [], [], short_headline(headline), headline, 'Retail starter: ' + sh_[11:] + (' — ' + src_note if src_note else ''), None, [])
            return
        flat0 = [l for _, ls in items for l in ls]
        if last_tbl and last_tbl[1] == headline and items and not carry and all(h is None for h, _ in items) and len(flat0) <= 2 and sum(len(l) for l in flat0) <= 150:
            # a one-liner after a table ("Operational risk: …") is not a slide: it becomes the takeaway line above the table
            tail = ' '.join((l[len(H):] + ':') if l.startswith(H) else (l[2:] if l.startswith(('• ', '– ')) else l) for l in flat0).strip()   # "## Operational risk" + text → "Operational risk: text"
            tsl = slides[last_tbl[0]]
            if 'takeaway' not in tsl: tsl['takeaway'] = tail
            else: tsl['notes'] = tsl.get('notes', '') + ' — ' + tail
            intro, cards = [], []; return
        if last_tbl and last_tbl[1] == headline and raw and not carry and 'takeaway' not in slides[last_tbl[0]] and not any(split_label(l)[0] in CALLOUT_LABELS for l in raw) \
                and (hints.get(headline.strip()) in (None, 'auto', 'table', 'text') or headline.strip() in soft):
            # a short paragraph (1–3 sentences) or up to three short bullets after a table is the table's so-what, not a sparse "(cont.)"
            # slide: the bullets joined (or the first sentence) become the takeaway above the table, the rest goes to the notes
            bl = [l[2:].strip().rstrip('.') for l in raw if l.startswith(GLYPHS)]; pl = [l for l in raw if not l.startswith(GLYPHS)]
            ss = [s for l in pl for s in sentences(l)]
            if bl and len(bl) <= 3 and len(pl) <= 1 and (not pl or pl[0].rstrip().endswith(':')):
                joined = ((pl[0].rstrip() + ' ') if pl else '') + ' · '.join(bl)   # each bullet keeps its own capital
                ss = [joined] if len(joined) <= 220 else [((pl[0].rstrip() + ' ') if pl else '') + bl[0]] + bl[1:]
            elif bl: ss = []
            if 1 <= len(ss) <= 3 and len(ss[0]) <= 220:
                tsl = slides[last_tbl[0]]; tsl['takeaway'] = ss[0].rstrip('.')
                if ss[1:]:
                    tsl['notes'] = tsl.get('notes', '') + ' — also: ' + ' '.join(ss[1:])
                    warnings.append(f'"{short_headline(headline)}": the paragraph after the table became its takeaway ({len(ss) - 1} more sentence(s) in the notes)')
                intro, cards = [], []; return
        is_metrics = 'metrics3' in R and len(flat0) >= 3 and all(split_label(l)[0] and NUM.search(split_label(l)[1] or '') and len(split_label(l)[1]) <= 24 for l in flat0[:3])
        asked = hints.get(headline.strip()) not in (None, 'auto', 'text') and headline.strip() not in soft   # v6.23: the author's "Layout:" line keeps the section a slide of its own
        if not final and items and sum(card_cost(c) for c in items) <= MERGE_COST and not is_metrics and not asked:
            # too small for a slide of its own: becomes a card on the next slide, keeping its name as the heading
            carry.append((None if headline == section else headline, [l for h, ls in items for l in (([H + h] if h else []) + ls)]))
            return
        if carry:
            items = carry + items; carry.clear()
        note = f'{src_note} — section: {headline}' + (' — ' + ' '.join(quotes) if quotes else '')
        if overflow:
            note += ' — not on slide: ' + ' '.join(overflow)
            appendix.append((headline, list(overflow)))
        head = short_headline(headline); story_tk = None
        if head != headline and storyboard:   # a storyboard headline is the slide's message: a clean short headline, the sentence as the key point
            head = story_headline(headline); story_tk = headline.strip().rstrip('.')
        elif head != headline: warnings.append(f'headline shortened: "{headline}" → "{head}" (full name in the notes)')
        # takeaway line (Key point: …) and callout strips (Decision: / Ask: / Next step: …) are lifted out of the body
        takeaway, callouts, kept, lifted = None, [], [], False
        for h, ls in items:
            out = []
            # a list whose items are mostly "Label: text" ("Ask: … / Route: … / Write: … / Build: …") names its items: "Ask" is a step
            # there, not a request for the audience — lifting it dropped step 1 and made a "What we need from you" slide of it
            bl_ = [l for l in ls if l.startswith('• ')]
            named_list = len(bl_) >= 3 and sum(1 for l in bl_ if split_label(l)[0]) >= max(3, len(bl_) - 1)
            for l in ls:
                lab, body = split_label(l.replace(H, '', 1) if l.startswith(H) else l)
                if lab in TAKEAWAY_LABELS and takeaway is None and len(body) <= (180 if storyboard else 140):   # a storyboard's key point is the slide's message: it wraps to a second line rather than becoming a bullet
                    takeaway = sentences(body)[0]; continue
                if lab in CALLOUT_LABELS and len(callouts) < 2 and not (named_list and l.startswith('• ')):
                    callouts.append((lab, body))
                    if lab in ASK_LABELS: asks.append((lab, body, headline))
                    continue
                out.append(l)
            if out or h: kept.append((h, out))
        items = [(h, ls) for h, ls in kept if ls or h]
        if takeaway is None and story_tk: takeaway = story_tk
        if takeaway is None and items and items[0][0] is None and items[0][1]:
            first = items[0][1][0]
            if not first.startswith(GLYPHS + (H,)) and len(first) <= 110 and len(sentences(first)) == 1 and len(items[0][1]) > 1 and not split_label(first)[0]:
                takeaway = first; items[0] = (None, items[0][1][1:]); lifted = True
        rest = [l for _, ls in items for l in ls]
        if callouts and all(split_label(l.replace(H, '', 1) if l.startswith(H) else l)[0] in CALLOUT_LABELS for l in rest):
            # a section that is only asks (two strips would overwrite each other in one box): all of them as the body, in order; they also reach the asks slide
            pairs_ = [(lab, body) for lab, body in callouts] + [split_label(l.replace(H, '', 1) if l.startswith(H) else l) for l in rest]
            if infographics and len(pairs_) in (3, 4) and all(lab and body for lab, body in pairs_) \
                    and len({lab.lower() for lab, _ in pairs_}) == len(pairs_):   # (1t) the asks as cards; (1ad) labels differ
                cards_ = [(lab[:1].upper() + lab[1:], [body]) for lab, body in pairs_]
                if infographic(cards_, head, note, 'cards' if len(cards_) == 3 else 'table', takeaway):
                    if overflow and appendix and appendix[-1][0] == headline: appendix.pop()
                    return
            items = [(None, ([takeaway] if takeaway else []) + [f'**{lab.title()}:** {body}' for lab, body in callouts] + [re.sub(r'^([^:]{2,20}):', r'**\1:**', l) for l in rest])]; takeaway, callouts = None, []
        hint = hints.get(headline.strip()) or hints.get(head.strip()) or auto_hint
        if hint == 'table' and infographics and (headline.strip() in soft or head.strip() in soft):
            # variety: an AI-chosen label table straight after another label table is drawn as a hub instead (the author's choice is kept)
            last = next((s for s in reversed(slides) if s.get('kind') != 'divider'), None)
            if last is not None and last.get('source') == R.get('actions') and last.get('kind') is None and 3 <= len([1 for h, _ in items if h]) <= 6: hint = 'hub'
        if not hint and infographics:   # two sub-headed boxes that contrast ("Today" / "Target", "IT recommendation" / "Recommended target model"): two bands, not two text boxes
            tl = [h for h, _ in items if h]
            if len(tl) == 2 and len(items) == 2 and CONTRAST_A.search(tl[0]) and CONTRAST_B.search(tl[1]): hint = 'bands'
        if family_slide(hint, raw, items, head, headline, note, None if lifted else takeaway, callouts):
            if overflow and appendix and appendix[-1][0] == headline: appendix.pop()
            return
        shaped = infographics and hint in (None, 'auto') and not callouts and raw and len(items) == 1 and items[0][0] is None
        if infographics and hint in ('timeline', 'roadmap', 'steps') and not callouts and raw and len(items) == 1 and items[0][0] is None \
                and shape_list(raw, head, note, None if lifted else takeaway, False, only_dated=hint):   # dates on every item: the dates are the milestones
            if overflow and appendix and appendix[-1][0] == headline: appendix.pop()
            return
        if shaped and shape_list(raw, head, note, None if lifted else takeaway, False):
            if overflow and appendix and appendix[-1][0] == headline: appendix.pop()   # the list's full text is in the notes: no "Detail" slide for it
            return
        # a slide that is only a plain bullet list (4–8 short items, optional one-line intro, nothing else) never renders as a bare box:
        # it becomes the template's label table — the "Label:" part of each bullet, else its number, as the coloured label; the intro as takeaway
        if infographics and hint in (None, 'auto', 'table') and not callouts and len(items) == 1 and items[0][0] is None:
            ls0 = items[0][1]; lead0 = [l for l in ls0 if not l.startswith(GLYPHS)]; bl = [l for l in ls0 if l.startswith('• ')]
            if 4 <= len(bl) <= 8 and len(bl) + len(lead0) == len(ls0) and len(lead0) <= 1 and (not lead0 or ls0[0] == lead0[0]) and all(len(l) <= 130 for l in bl) and (not lead0 or len(lead0[0]) <= 140) and 'actions' in R:   # the one plain line must introduce the list; a closing sentence keeps the box
                rows = []
                all_lab = all(split_label(l)[0] and len(split_label(l)[0]) <= 28 for l in bl)
                for k, l in enumerate(bl, 1):
                    lab, body = split_label(l)
                    if storyboard and not all_lab: lab = None   # a storyboard list is all labels or all numbers — "1, 2, 3, Assumption" reads as a mistake
                    rows.append([lab.title() if lab and len(lab) <= 28 else str(k), body if lab and len(lab) <= 28 else l[2:], ''])
                sl = {'source': R['actions'], 'fills': {'title': head, 'table': [['#' if all(r[0].isdigit() for r in rows) else 'Item', 'What it covers', '']] + rows}, 'trim_empty_rows': True, 'trim_empty_cols': True, 'notes': note, 'accent': accent(), 'cards': []}
                if len(rows) > 4: sl['grow_rows'] = True
                if all(r[0].isdigit() for r in rows): sl['label_col_in'] = 1.5
                tk = (takeaway or (lead0[0] if lead0 else '')).rstrip(': ')
                if tk: sl['takeaway'] = tk
                slides.append(sl); return
        if shaped and shape_list(raw, head, note, None if lifted else takeaway, True):
            if overflow and appendix and appendix[-1][0] == headline: appendix.pop()
            return
        num_cards = [(h, ls) for h, ls in items if h and re.match(r'^\d+[.)]\s', h)]
        rest = [(h, ls) for h, ls in items if not (h and re.match(r'^\d+[.)]\s', h))]
        if hint != 'text' and len(num_cards) >= 3 and rest and sum(card_cost(c) for c in rest) >= 4 and (infographics or hint in ('steps', 'cards')):
            # "Month-end close": eleven bullets plus "three buckets: 1. 2. 3." — the bullets stay a text slide, the buckets become steps / cards with the
            # line that announced them ("…split AP open items into three buckets:") as their takeaway
            lead = None
            if rest[-1][0] is None and rest[-1][1] and rest[-1][1][-1].rstrip().endswith(':'):
                lead = rest[-1][1][-1].rstrip(':'); rest[-1] = (None, rest[-1][1][:-1])
                if not rest[-1][1]: rest = rest[:-1]
            emit_text(rest, head, note, takeaway, callouts, None)
            infographic(([(None, [lead])] if lead else []) + num_cards, head, note, 'steps' if hint in (None, 'auto', 'steps') else hint)
            return
        n_titled = len([1 for h, _ in items if h])
        if hint in ('cards', 'steps', 'flow', 'table', 'bands') + GRAPHIC_KINDS and n_titled == 0:
            if lifted and takeaway: items = [(None, [takeaway] + items[0][1])] + items[1:]; takeaway = None   # plain text shaped into an infographic: the first line is a card like the others, not a takeaway
            items, hint = synth_cards(items, hint)                           # plain text, asked for an infographic: each line becomes a titled card (deterministic, no model); nothing is dropped
        elif hint in ('cards', 'steps', 'flow', 'table', 'bands') + GRAPHIC_KINDS and n_titled < 3:
            # a lone card or two next to bullets, asked for an infographic: each untitled line becomes a titled card, existing cards stay
            merged = []
            for h, ls in items:
                if h: merged.append((h, ls))
                else:
                    made, _ = synth_cards([(None, ls)], hint if hint != 'steps' else 'cards'); merged.extend(made)
            if len(merged) >= 2:
                items = merged
                if hint in ('steps', 'flow'): items = [(re.sub(r'^\d+[.)]\s*', '', h), ls) for h, ls in items]; items = [(f'{k}. {h}', ls) for k, (h, ls) in enumerate(items, 1)]
                elif hint == 'cards' and len(items) > 3: hint = 'table'
                elif hint == 'bands' and len(items) != 2: hint = 'auto'   # two bands need exactly two things; otherwise the section keeps its natural layout
        if hint == 'text': pass                                            # forced two-box text slide
        elif infographics or hint in ('cards', 'steps', 'flow', 'table') + GRAPHIC_KINDS:
            if infographic(items, head, note, hint, takeaway): return
        bands = None
        if hint == 'bands' and len([1 for h, _ in items if h]) == 2:
            titled2 = [(h, ls) for h, ls in items if h]; extra = [ls for h, ls in items if not h]
            bands = {'text1': titled2[0][0], 'text2': titled2[1][0]}; items = [(None, titled2[0][1]), (None, titled2[1][1])]
        if not bands and len(items) == 2 and all(h for h, _ in items):
            a, b = (h.strip().lower().rstrip(':') for h, _ in items)
            for x, y in PAIRS:
                if (a.startswith(x) and b.startswith(y)) or (a == x and b == y):
                    bands = {'text1': items[0][0], 'text2': items[1][0]}; items = [(None, ls) for _, ls in items]; break
        emit_text(items, head, note, takeaway, callouts, bands)

    def add_text(line):
        nonlocal cur
        s = clean(line)
        if s is None: return
        if cur is not None: cur[1].append(s)
        elif cards: cards[-1][1].append(s)
        else: intro.append(s)

    def diagram_slide(content, prefer=None, title_hint=None):
        """Hybrid mode: box art or "A → B" lines in the page become one crisp architecture slide (native shapes, no tokens) — the
        title from a short "Architecture diagram"-style line just before it, else the card or section heading."""
        nonlocal cur, carry
        try:
            SD = _load_sd()
        except Exception: return False   # noqa: BLE001
        DIAG = re.compile(r'\b(diagram|architecture|landscape|integration|data flow|system flow|interfaces?|topology|flow|path|pipeline)\b', re.I)
        ttl = None
        if isinstance(content, dict):   # read from a table, layers, sentences or the AI's fields: its own title, never a line of the text
            t0 = str(content.get('title') or headline or 'Architecture').strip()[:60]
            ttl = t0 if DIAG.search(t0) and not re.search(r'\b(interfaces?|integrations?|flows?)\b$', t0, re.I) else t0 + ' — diagram'
        for pool in ([] if ttl else ([cur[1]] if cur else []) + [cards[-1][1] if cards else [], intro]):
            if pool and len(pool[-1]) <= 60 and DIAG.search(pool[-1]): ttl = pool.pop().strip(' :'); break
        if ttl is None and cur and DIAG.search(cur[0] or ''): ttl = cur[0]
        if isinstance(content, dict) and content.get('title') and not ttl: ttl = str(content['title'])[:70]
        ttl = title_hint or ttl or (headline if headline not in (title,) else 'Architecture')
        mo = re.match(r'^([^:]{2,20}):\s', str(headline or ''))   # "Option 2: Virtual DC …" → "Option 2: End-to-end flow" — two options' flows never share a title
        if mo and not isinstance(content, dict) and mo.group(1).lower() not in ttl.lower() and ttl != headline: ttl = mo.group(1) + ': ' + ttl
        style = dhints.get(str(headline).strip()) or dhints.get(str(ttl).strip()) or dhints.get(str(section).strip()) or (prefer if prefer and DIAGRAM_STYLE == 'auto' else DIAGRAM_STYLE)
        got = SD.build(content, ttl, style=style)
        if not got: return False
        d, arch, dropped = got
        flush()
        tk_ = None; extra_note = ''
        if carry and isinstance(content, dict) and content.get('from') in ('sentences', 'layers'):   # the diagram was read from these lines: they go to its notes
            extra_note = ' — source: ' + ' '.join(l.lstrip('•– ') for _, ls in carry for l in ls if not l.startswith(H)); carry.clear()
        elif carry and isinstance(content, dict): flush(final=True)   # someone else's waiting lines: their own slide first, nothing lost
        if carry:   # a short lead-in waiting for the next slide: on a diagram it is the line under the title (the full text in the notes)
            lead = ' '.join(l.lstrip('•– ') for _, ls in carry for l in ls if not l.startswith(H)).strip()
            if lead and len(lead) <= 160: tk_ = lead; carry.clear()
        import info as _IG
        slides.append({'source': R['two_col'], 'fills': {'title': short_headline(ttl), 'text1': [''], 'text2': ['']}, 'hide': ['text1', 'text2'], 'info': d,
                       'info_svg': _IG.to_svg(d, chrome=False), 'diagram': SD.drawio_spec(arch), 'arch': arch, 'diagram_style': d.get('style'), 'accent': accent(),
                       'notes': f'{src_note} — section: {headline} — ' + SD.notes(arch, dropped) + extra_note, **({'takeaway': tk_} if tk_ else {})})
        if dropped: warnings.append(f'"{ttl}": diagram kept crisp — {len(dropped)} detail(s) moved to the notes')
        if style and style != 'auto' and d.get('style') and d.get('style') != style:   # v6.12: a style that cannot draw this diagram is said, not swapped silently
            warnings.append(f'"{ttl}": diagram style "{style}" needs {SD.STYLE_NEEDS.get(style, "a different shape of diagram")} — drawn as {d.get("style")}')
        return True

    for i, b in enumerate(blocks):
        kind = b[0]
        if kind == 'diagram':
            if 'two_col' in R: diagram_slide(b[1])
            continue
        if kind == 'p' and 'two_col' in R and ('┌' in b[1] or '+--' in b[1] or '→' in b[1] or '->' in b[1] or '►' in b[1] or '▶' in b[1] or '◄' in b[1] or '▼' in b[1]):
            try:
                _SDp = _load_sd()
                if _SDp.is_art(b[1]) and diagram_slide(b[1]): continue
                pairs = _SDp.arrow_lines(str(b[1]).split('\n'))
                if pairs and diagram_slide(pairs): continue
                chain = [x.strip(' .') for x in re.split(r'\s*(?:→|->|──►|=>)\s*', str(b[1]).strip())] if '\n' not in str(b[1]).strip() else []
                lab_ = None
                if chain:   # "Primary product path PIM + SAP → …" (an HTML copy joins the label to its flow): the label is the diagram's title
                    m_ = CHAIN_LABEL.match(chain[0])
                    if m_: lab_, chain[0] = m_.group(1).strip(), m_.group(2).strip()
                under_card = i > 0 and blocks[i - 1][0] == 'h' and blocks[i - 1][1] >= 3   # a card's own text ("Order path: TikTok → Rithum → …") stays the card's words
                if not under_card and len(chain) >= 4 and all(2 <= len(x) <= 48 for x in chain) and len(set(x.lower() for x in chain)) >= 3:   # "PIM + SAP → EI Kafka → Flink → TIBCO → Rithum → TikTok Shop": one line, a flow
                    seen_ = {}; uniq = []
                    for x in chain:   # a name that comes back ("EI Kafka" in, then out after Flink) is its own step: the pipeline stays a line, not a hub
                        seen_[x.lower()] = seen_.get(x.lower(), 0) + 1; uniq.append(x + '\u200b' * (seen_[x.lower()] - 1))
                    if diagram_slide([(uniq[k], uniq[k + 1], '') for k in range(len(uniq) - 1)], prefer='chevron', title_hint=lab_): continue
            except Exception: pass   # noqa: BLE001  not a diagram: the paragraph stays text
        if kind == 'ul' and 'two_col' in R and not str(hints.get(headline.strip()) or '').startswith('fam:'):   # v6.23: "Layout: sankey" over "A → B: 120" lines is a chart, not a system diagram
            try:
                _SDu = _load_sd()
                pairs = _SDu.arrow_lines(b[1])
                if pairs and diagram_slide(pairs): continue
            except Exception: pass   # noqa: BLE001
        if kind == 'h':
            lvl, text = b[1], b[2].strip()
            if lvl == 1:
                flush(final=True); n_h1 += 1; section = headline = text; slides_at_headline = len(slides) + 1   # a section never spills into the next one, however small
                marks.append((len(slides), text))
                if multi and 'divider' in R and dividers:
                    slides.append({'source': R['divider'], 'kind': 'divider', 'fills': {'text1': str(n_h1), 'text2': unnumbered(section)}, 'notes': src_note, 'accent': accent(), 'agenda': [unnumbered(x) for x in h1s[:10]], 'current': n_h1, 'icon': 'auto'})
            elif lvl == 2 or (lvl == 3 and (i in h3_parent or (headline == section and not cards and not intro and cur is None))):
                if headline not in (section, title) and not intro and not cards and cur is None and not carry and len(slides) == slides_at_headline \
                        and not str(hints.get(headline.strip()) or '').startswith('fam:retail '):   # v6.23: a retail starter needs no lines
                    warnings.append(f'"{headline}": heading with no content — no slide made')
                flush(); headline = text; slides_at_headline = len(slides); quotes.clear(); marks.append((len(slides), text))   # H2 (or an H3 with H4 children) names the slide
            else:
                if cur and cur[1]: cards.append(tuple(cur))
                cur = [text, []]                # H3/H4 = a card (bold heading + text) inside a box
        elif kind == 'p':
            add_text(b[1])
        elif kind == 'quote':
            quotes.append(re.sub(r'^notes?:\s*', '', b[1], flags=re.I))
        elif kind == 'ul':
            for x in b[1]: add_text(x if (x.startswith(GLYPHS) or re.match(r'^\d+\. ', x)) else '• ' + x)
        elif kind == 'table':
            if cur and cur[1]: cards.append(tuple(cur)); cur = None
            lead = ''
            if intro and not cards:
                for l in list(intro):                   # Decision: / Ask: lines before a table still reach the asks slide
                    lab, body = split_label(l)
                    if lab in CALLOUT_LABELS: asks.append((lab, body, headline)); intro.remove(l)
            kp_lead = None
            if intro and not cards and len(intro) == 1 and split_label(intro[0])[0] in TAKEAWAY_LABELS:   # "Key point: …" above a table is the table's so-what, on the slide
                kp_lead = split_label(intro[0])[1].rstrip('.'); intro = []
            if intro and not cards and est_lines(intro) <= 4 and len(sentences(' '.join(intro))) <= 2:
                lead = ' '.join(intro); intro = []      # a one-or-two-sentence table intro goes to the notes, not a slide of its own
            flush()
            rows = normalize_table([[c.strip() for c in r] for r in b[1]])
            if not rows: continue
            caption = rows.pop(0)[0] if len(rows) > 1 and sum(bool(c) for c in rows[0]) == 1 and sum(bool(c) for c in rows[1]) > 1 else None
            if caption and headline == section: headline = caption          # a one-cell first row is the table's caption
            if not rows: continue
            header, data = rows[0], rows[1:]
            ncol = max(len(r) for r in rows)
            head_title = short_headline(headline); tbl_tk = None
            if storyboard and head_title != headline: head_title = story_headline(headline); tbl_tk = headline.strip().rstrip('.')   # as for text slides: the sentence becomes the key point
            n_tbl0 = len(slides)
            note = f'{src_note} — section: {headline}' + (f' — {lead}' if lead else '') + (' — ' + ' '.join(quotes) if quotes else '')
            t_hint = hints.get(headline.strip()) or hints.get(section.strip())
            prev_ = next((s_ for s_ in reversed(slides) if s_.get('kind') != 'divider'), None)   # (1ae) variety
            if not t_hint and infographics and 2 <= ncol <= 4 and 3 <= len(data) <= 6 and prev_ is not None \
                    and prev_.get('source') in (R.get('actions'), R.get('grid6')) and 'two_col' in R and all(len(' '.join(r)) <= 150 for r in data):
                t_hint = 'fam:process list'
                warnings.append(f'variety: the table "{head_title}" follows a label table - drawn as icon rows ("Layout: table" keeps a table)')
            if str(t_hint or '').startswith('fam:process') and 3 <= len(data) <= 8 and ncol >= 2:   # (1ai) rows as steps
                def cap_(r):   # the later columns under their headers, one caption (one column when two run long)
                    xs = [(f'{header[j].strip()}: ' if j < len(header) and header[j].strip() else '') + r[j].strip() for j in range(2, len(r)) if r[j].strip()]
                    c = ' · '.join(xs) if len(' · '.join(xs)) <= 60 else (xs[0] if xs else '')
                    return f' ({c})' if c else ''
                raw_ = ['\u2022 ' + f"{r[0].strip()}: {r[1].strip()}" + cap_(r) for r in data if r and r[0].strip()]
                note_t = note + ' — table: ' + ' | '.join(' / '.join(r) for r in rows)
                if family_slide(t_hint, raw_, [(None, raw_)], head_title, headline, note_t, None, []):
                    continue
            if t_hint in ('cards', 'steps', 'bands', 'text') + GRAPHIC_KINDS and 3 <= len(data) <= 8 and ncol >= 2:
                # a table asked to be an infographic: each row becomes a card — first cell the title, the other cells its line (header names kept in the notes)
                row_cards = [((r[0] or f'Row {k}').strip(), [' · '.join(f'{header[j]}: {c}' if 2 <= j < len(header) and header[j] else c for j, c in enumerate(r[1:], 1) if c and c.strip())]) for k, r in enumerate(data, 1)]
                note_t = note + ' — table: ' + ' | '.join(' / '.join(r) for r in rows)
                if t_hint == 'hub' and header and header[0].strip() and len(header[0].strip()) <= 22 and infographic(row_cards, head_title, note_t, t_hint):
                    slides[-1]['graphic']['hub'] = header[0].strip()   # (1ae) the hub's centre names its rows
                    continue
                if t_hint == 'text' or not infographic(row_cards, head_title, note_t, t_hint):
                    emit_text(row_cards, head_title, note_t, None, [], None)
                continue
            metrics = 'metrics3' in R and ncol <= 3 and len(data) == 1 and all(len(c) <= 40 for c in data[0])
            if metrics:
                slides.append({'source': R['metrics3'], 'fills': {'title': head_title, 'table': [header[:3], data[0][:3]]}, 'notes': note, 'accent': accent()})
                last_tbl = (len(slides) - 1, headline)
            elif ncol <= 3 and 'actions' in R:
                data, more = trim_cells(data, warnings, head_title)
                if more: note += ' — full text: ' + ' | '.join(more)
                parts, tpt = chunk_rows_fit(data, ACTIONS_ROWS, 'actions')
                for part in parts:
                    sl = {'source': R['actions'], 'fills': {'title': head_title, 'table': [(header + ['', ''])[:3]] + [(r + ['', ''])[:3] for r in part]}, 'trim_empty_rows': True, 'notes': note, 'accent': accent()}
                    if tpt: sl['table_font_pt'] = tpt
                    if ncol == 2: sl['trim_empty_cols'] = True     # builder removes the unused third column
                    if len(part) > 4: sl['grow_rows'] = True       # more rows than the template has: the builder clones rows (colours cycle) and steps the text down to fit
                    slides.append(sl); last_tbl = (len(slides) - 1, headline)
            elif 'grid6' in R:
                if ncol > 6:
                    warnings.append(f'table under "{head_title}" has {ncol} columns; slide 14 holds 6 — extra columns dropped')
                hdr = [''] + header[1:6]              # slide 14's corner cell is blank by design; column 0 holds the row labels
                if header and header[0].strip():
                    warnings.append(f'table under "{head_title}": first column header "{header[0]}" dropped (slide 14 has a blank corner cell); rows keep it as the row label')
                data, more = trim_cells(data, warnings, head_title)
                if more: note += ' — full text: ' + ' | '.join(more)
                for part in chunk_rows(data, GRID_ROWS, 'grid6'):
                    slides.append(dict({'source': R['grid6'], 'fills': {'title': head_title, 'table': [hdr] + [r[:6] for r in part]}, 'trim_empty_rows': True, 'trim_empty_cols': True, 'notes': note, 'accent': accent()}, **({'grow_rows': True} if len(part) > 3 else {})))
                    last_tbl = (len(slides) - 1, headline)
            else:
                warnings.append(f'table under "{head_title}" skipped: template has no table layout role'); note += ' — table: ' + ' | '.join(' / '.join(r) for r in rows)
            if (kp_lead or tbl_tk) and len(slides) > n_tbl0 and 'takeaway' not in slides[n_tbl0]: slides[n_tbl0]['takeaway'] = kp_lead or tbl_tk
    flush(final=True)
    marks.append((len(slides), None))
    # "What we need from you": every Decision / Ask / Next step collected on one slide before the close
    if asks and 'actions' in R:
        rows = [[lab.title(), body, ''] for lab, body, sec in asks][:8]   # v6.18: the section's name meant nothing to the audience — the column goes (trimmed)
        for part in chunk(rows, 4):
            slides.append({'source': R['actions'], 'fills': {'title': 'What we need from you', 'table': [['Ask', 'What we need', '']] + part}, 'trim_empty_rows': True, 'trim_empty_cols': True,
                           'notes': src_note + ' — asks from: ' + '; '.join(dict.fromkeys(short_headline(s) for _, _, s in asks[:8])), 'accent': 'berry'})
    # appendix: the full paragraphs Brief mode trimmed, for readers who want depth
    if appendix and appendix_slides:
        if multi and 'divider' in R:
            slides.append({'source': R['divider'], 'kind': 'divider', 'fills': {'text1': 'A', 'text2': 'Appendix — detail'}, 'notes': src_note, 'accent': 'berry'})
        save = (PACK_LINES, MAX_BULLETS, BULLET_CHARS, CARDS_PER_BOX)
        globals().update(PACK_LINES=BOX_LINES, MAX_BULLETS=8, BULLET_CHARS=0, CARDS_PER_BOX=99)
        for sec, paras in appendix:
            marks.append((len(slides), sec))
            items = [(None, slidify(paras, []))]
            for k, box in enumerate(chunk(pack(items, BOX_LINES), 2)):
                fills = {'title': short_headline('Detail — ' + (unnumbered(sec) if multi else sec)) + (' (cont.)' if k else ''), 'text1': render(box[0]), 'text2': render(box[1]) if len(box) > 1 else ['']}
                sl = {'source': R['two_col'], 'fills': fills, 'notes': f'{src_note} — appendix for: {sec}', 'accent': 'berry'}
                if len(box) == 1: sl['hide'] = ['text2']
                slides.append(sl)
        globals().update(PACK_LINES=save[0], MAX_BULLETS=save[1], BULLET_CHARS=save[2], CARDS_PER_BOX=save[3])
    for s in slides:
        s['fills'] = dedupe_headings(polish_fills(s['fills']))
        acc = s.get('accent', 'orange')
        for k in ('text1', 'text2'):
            if isinstance(s['fills'].get(k), list): s['fills'][k] = [emphasize_numbers(l, acc) if not l.startswith(H) else l for l in s['fills'][k]]
    if icons:
        # dividers carry the section icon; boxes get icons only in single-section decks (calmer slides)
        for s in slides:
            if s['source'] in {R.get(k) for k in ('metrics3', 'actions', 'grid6')} or (s['source'] == R.get('two_col') and not multi): s['icons'] = 'auto'
    marks.append((len(slides), None))
    if 'closing' in R and frame: slides.append({'source': R['closing'], 'kind': 'closing', 'fills': {'text1': 'Thank you!', 'text2': 'Ulta Beauty | Proprietary & Confidential'}})
    # every slide knows the outline section it came from and how full it is (the Adjust storyboard shows both)
    for i, sl in enumerate(slides):
        sec = next((h for start, h in reversed(marks) if start <= i), None)
        if sec: sl['sec'] = sec
        f = sl['fills']
        if sl['source'] == R.get('two_col'):
            sl['fill'] = round(min(1.0, max(est_lines(f.get(k) or []) for k in ('text1', 'text2')) / BOX_LINES), 2)
        elif isinstance(f.get('table'), list) and sl['source'] in (R.get('actions'), R.get('grid6')):
            cap = (4 if sl['source'] == R.get('actions') else 3) * max(1.0, TABLE_SCALE)
            sl['fill'] = round(min(1.0, max(0, len(f['table']) - 1) / cap), 2)
    # consecutive slides that continue one section carry "(cont.)" — whichever path produced them (boxes, cards, tables, steps)
    prev, run = None, 0
    for sl in slides[1:]:   # the cover may share its title with the first section
        t = sl.get('fills', {}).get('title')
        base = re.sub(r'\s*\(cont\.(?: \d+)?\)$', '', t) if isinstance(t, str) else None
        if base and base == prev:
            run += 1; suffix = ' (cont.)' if run == 1 else f' (cont. {run + 1})'
            sl['fills']['title'] = (base if len(base) <= HEADLINE_MAX else short_headline(base, HEADLINE_MAX - len(suffix))) + suffix   # a headline that fit on the first slide is not clipped for its "(cont.)" (the builder widens and steps the box)
        else:
            run = 0
        prev = base
    if multi:   # the agenda numbers the chapters: a content headline keeps no outline number of its own ("1. Integration mechanisms" is agenda item 2)
        nums = {unnumbered(h) for h in h1s if unnumbered(h) != h}
        for sl in slides:
            t = (sl.get('fills') or {}).get('title')
            if sl.get('kind') is None and isinstance(t, str) and unnumbered(t) != t and re.sub(r'\s*\(cont\.(?: \d+)?\)$', '', unnumbered(t)).rstrip('…') and any(n.startswith(re.sub(r'\s*\(cont\.(?: \d+)?\)$', '', unnumbered(t)).rstrip('…')) for n in nums):
                sl['fills']['title'] = unnumbered(t)
    if multi and dividers and 'divider' in R:
        # restraint: a chapter divider earns its slide only in a long deck, or when chapters run two slides or more on average —
        # six dividers around eight content slides made a third of the deck title cards. The agenda stays either way.
        content = [sl for sl in slides if sl.get('kind') is None]
        chapters = [sl for sl in slides if sl.get('kind') == 'divider' and sl['fills'].get('text1') != 'A']
        if chapters and len(content) < 12 and len(content) < 2 * len(chapters):
            slides[:] = [sl for sl in slides if not (sl.get('kind') == 'divider' and sl['fills'].get('text1') != 'A')]
            warnings.append(f'{len(chapters)} chapter dividers left out: {len(content)} content slides read better with just the agenda')
    if icons:   # the template's icons on every card, band and label table — in chapter decks too
        for s in slides:
            if s['source'] == R.get('cards3') or s.get('bands'): s['icons'] = 'auto'
    if DECK_PT:   # every text slide of a dense deck at the same size, short sections included
        for sl in slides:
            f = sl.get('fills') or {}
            if sl.get('source') == R['two_col'] and isinstance(f.get('text1'), list) and not any(sl.get(k) for k in ('graphic', 'board', 'screen', 'info', 'chart')): sl['text_pt'] = DECK_PT
    return {'template': template, 'title': title, 'slides': slides, 'warnings': warnings}


LADDER = [   # fit-to-N: cumulative compaction steps, lossless first; everything trimmed from a slide face stays in the notes
    ('appendix detail slides removed', {'appendix_slides': False}),
    ('tables packed tighter (smaller font)', {'table_scale': 1.3}),
    ('small sections merged as cards on the next slide', {'merge_cost': 6}),
    ('compact density: short bullets, full boxes', {'density': 'compact'}),
    ('every text slide at 11 pt (one size for the deck)', {'text_pt': 11}),
    ('chapter dividers removed', {'dividers': False}),
    ('long table cells cut to a clause (full text in the notes)', {'cell_max': 100}),
    ('sections up to 10 lines merged', {'merge_cost': 10}),
    ('two bullets per paragraph (rest in the notes)', {'density': 'tight'}),
    ('infographic slides folded back into text boxes', {'infographics': False}),   # a timeline or card set costs a whole slide; as text it merges with its neighbours
    ('every text slide at 10 pt (one size for the deck)', {'text_pt': 10}),   # last step before whole sections would leave the deck
]


def box_load(lines, pt, wide=False):
    """A box's height in 14 pt lines when its text is set at pt: longer wrapped lines and a taller line pitch."""
    per = int(BOX_CHARS * (2.05 if wide else 1.0) * 14.0 / pt); n = 0.0
    for l in lines or []:
        t = re.sub(r'\{[^{}]*\}|\{/\}|\*\*', '', str(l))
        if not t.strip(): n += 0.5; continue
        n += max(1, -(-len(t) // per)) * (1.15 if t.startswith(H) else 1.0)
    return n * pt / 14.0


def scale_up(spec):
    """One body size for the deck, as large as every text slide allows: 18 or 16 pt when all of them still fit their boxes
    (a slide of four short lines at 14 pt leaves two thirds of it empty). Never per slide — one dense slide keeps the deck at 14."""
    R = template_roles(spec.get('template', 'STANDARD33'))
    text = [sl for sl in spec['slides'] if sl.get('source') == R.get('two_col') and sl.get('kind') is None and isinstance((sl.get('fills') or {}).get('text1'), list)
            and not any(sl.get(k) for k in ('graphic', 'board', 'screen', 'info', 'chart', 'charts', 'images', 'flow', 'text_pt'))]
    if not text: return None
    for pt in (18, 16):
        ok = True
        for sl in text:
            f = sl['fills']; wide = 'text2' in (sl.get('hide') or [])
            limit = BOX_LINES - 1.5 - (3 if sl.get('callouts') else 0) - (2 if sl.get('bands') else 0)
            if any(box_load(f.get(k), pt, wide) > limit for k in ('text1', 'text2') if isinstance(f.get(k), list)): ok = False; break
        if ok:
            for sl in text: sl['text_pt'] = pt
            spec['warnings'].append(f'text slides at {pt} pt throughout — every box has room; the deck keeps one body size')
            return pt
    return None


BUDGETED = False   # a slide budget (fit to N): diagrams inferred from prose would take slots the author did not ask for


def fit(blocks, title, source_url, max_slides, **kw):
    """Build, then compact step by step until the deck has <= max_slides slides. Nothing is cut mid-section: text that leaves
    a slide face goes to the notes; only when every step is exhausted are whole trailing sections dropped (and listed)."""
    global BUDGETED; BUDGETED = bool(max_slides)
    spec = build(blocks, title, source_url, **kw)
    if not DENSITY.get(kw.get('density', 'brief'), {}).get('TEXT_PT') and kw.get('text_pt') is None:
        # ONE body size for the whole deck: 14 pt; or 12 / 11 pt on every text slide when that shortens the deck clearly — never per section
        base_n = len(spec['slides']); pick = None
        for pt, need, least in ((12, 0.10, 2), (11, 0.15, 3)):   # the larger size wins whenever it saves enough
            alt = build(blocks, title, source_url, **dict(kw, text_pt=pt))
            if base_n - len(alt['slides']) >= max(least, need * base_n): pick = (pt, alt); break
        if pick:
            pt, alt = pick; alt['warnings'].append(f"text slides at {pt} pt throughout — {base_n - len(alt['slides'])} fewer slides than at 14 pt; the deck keeps one body size"); spec = alt
        else:
            spec = build(blocks, title, source_url, **kw)   # the 14 pt deck (rebuilt: the module's settings follow the last build)
            scale_up(spec)                                   # …or larger, when every text slide has the room
    before = len(spec['slides']); applied = []
    if not max_slides or before <= max_slides:
        spec['fit'] = {'target': max_slides or 0, 'before': before, 'after': before, 'applied': [], 'fits': True}; return spec
    cur = dict(kw)
    for name, over in LADDER:
        cur.update(over); applied.append(name)
        spec = build(blocks, title, source_url, **cur)
        if len(spec['slides']) <= max_slides: break
    n = len(spec['slides']); cut = []
    if n > max_slides:
        dg = digest(blocks, spec, max_slides, kw)
        if dg:   # every topic stays on the deck as a row of an at-a-glance table — nothing cut, the full text in the notes
            dg['warnings'] = dg.get('warnings', []) + [f'fit to {max_slides}: {before} slides of content condensed to an at-a-glance deck — every topic one row (full text in the notes)']
            dg['fit'] = {'target': max_slides, 'before': before, 'after': len(dg['slides']), 'applied': applied + ['every topic condensed to one row (at a glance)'], 'fits': True, 'cut': []}
            return dg
    if n > max_slides:
        slides = spec['slides']; closing = [slides.pop()] if slides and slides[-1]['source'] == template_roles(kw.get('template', 'STANDARD33')).get('closing') else []
        if len(slides) + len(closing) > max_slides and any(s.get('kind') == 'agenda' for s in slides):   # the agenda goes before any topic does
            slides[:] = [s for s in slides if s.get('kind') != 'agenda']; applied.append('agenda removed (a short deck needs the room)')
        while len(slides) + len(closing) > max_slides and len(slides) > 1:
            sec = slides[-1].get('sec')
            if sec is None or len([s for s in slides if s.get('sec') == sec]) == len(slides) - 1:
                slides.pop(); continue
            cut.append(sec); slides[:] = [s for s in slides if s.get('sec') != sec]
        while len(slides) > 1 and slides[-1]['source'] == template_roles(kw.get('template', 'STANDARD33')).get('divider'): slides.pop()   # a chapter with nothing left under it
        spec['slides'] = slides + closing
        cut = list(dict.fromkeys(cut))
        for s in slides:   # an agenda that stayed lists only what the deck still covers
            if s.get('kind') == 'agenda' and isinstance((s.get('fills') or {}).get('table'), list):
                keep = [r for r in s['fills']['table'] if unnumbered(str(r[1] if len(r) > 1 else r[0])).strip().lower() not in {unnumbered(c).strip().lower() for c in cut}]
                s['fills']['table'] = [[str(k), r[1] if len(r) > 1 else r[0]] for k, r in enumerate(keep, 1)]
        if closing: closing[0]['notes'] = 'Not on slides (did not fit in ' + str(max_slides) + '): ' + '; '.join(cut)
        spec['warnings'] = spec.get('warnings', []) + [f'fit to {max_slides}: still {n} slides after full compaction — dropped whole sections: ' + ', '.join(cut) + '. Raise the limit or drop content in Adjust.']
    else:
        spec['warnings'] = spec.get('warnings', []) + [f'fit to {max_slides}: {before} → {len(spec["slides"])} slides by ' + '; '.join(applied)]
    spec['fit'] = {'target': max_slides, 'before': before, 'after': len(spec['slides']), 'applied': applied, 'fits': not cut, 'cut': cut}
    return spec


def digest(blocks, spec, max_slides, kw):
    """The slide budget is smaller than the topics (Eco cannot summarise): one row per topic — its name and its first point — packed
    into label tables that fit the budget, the first drawn diagram kept when there is room, every topic's full text in the notes.
    None when the deck has fewer than 3 topics or the template has no label table."""
    R = template_roles(kw.get('template', 'STANDARD33'))
    if 'actions' not in R: return None
    secs, cur = [], None
    for b in blocks:
        if b[0] == 'h' and b[1] <= 2:
            cur = [unnumbered(str(b[2])).strip(), []]; secs.append(cur); continue
        if cur is None: continue
        if b[0] == 'p' and not ART_CH.search(str(b[1])): cur[1].append(str(b[1]))
        elif b[0] == 'ul': cur[1] += [str(x) for x in b[1]]
        elif b[0] == 'table' and b[1]: cur[1].append('Table: ' + ', '.join(str(c) for c in b[1][0] if str(c).strip()))
        elif b[0] == 'h': cur[1].append(str(b[2]) + ':')
    secs = [s for s in secs if s[1]]
    if spec['slides'] and spec['slides'][0].get('kind') == 'cover' and secs and secs[0][0].lower() == str(spec['slides'][0]['fills'].get('title', '')).lower():
        secs[0][0] = 'Purpose'   # the page's opening text under its own title
    if len(secs) < 3: return None
    first = lambda ls: next((x for x in ls if len(x) > 25 and not x.endswith(':') and len(re.findall(r'→|->|──►', x)) < 2), next((x for x in ls if len(re.findall(r'→|->|──►', x)) < 2), ls[0]))   # a flow line is the diagram's, not the topic's point
    def gist(ls):
        x = re.sub(r'^[A-Z][\w &/-]{1,30}:\s+', '', first(ls).lstrip('•–- ').strip())   # "Purpose: This page explains …" → the explanation
        s0 = (sentences(x)[0] if sentences(x) else x).rstrip('.')
        return s0 if len(s0) <= 160 else clause(s0, 120).rstrip('.')   # the whole first sentence reads; a clause cut clipped "…, known as Project Stopwatch" before its verb
    def points(ls, k):   # the gist, then the next distinct points (flow lines and run-in labels skipped)
        out = [gist(ls)]
        for x in ls:
            if len(out) >= k: break
            if x.endswith(':') or len(x) <= 25 or len(re.findall(r'→|->|──►', x)) >= 2: continue
            g = gist([x])
            if g and not any(g[:40] == o[:40] for o in out): out.append(g)
        return out
    cover = [s for s in spec['slides'][:1] if s.get('kind') == 'cover']; closing = [s for s in spec['slides'][-1:] if s.get('kind') == 'closing']
    diag = next((s for s in spec['slides'] if s.get('arch')), None)
    room = max_slides - len(cover) - len(closing)
    if diag and room >= 3: room -= 1
    else: diag = None
    if room < 1: return None
    ng = min(room, len(secs))   # every slide asked for is used (asked for 8, the deck has 8); smaller groups carry more points a topic
    if -(-len(secs) // ng) > 8: return None   # more than eight topics a slide would not read: compaction / cutting decides
    groups, k0 = [], 0
    for gi in range(ng):   # balanced: 9 topics over 4 slides → 3 + 2 + 2 + 2
        sz = len(secs) // ng + (1 if gi < len(secs) % ng else 0); groups.append(secs[k0:k0 + sz]); k0 += sz
    acc = (spec['slides'][1] if len(spec['slides']) > 1 else spec['slides'][0]).get('accent', 'orange')
    out = []
    for gi, g in enumerate(groups, 1):
        per = 1 if len(g) >= 3 else (3 if len(g) == 2 else 5)   # a slide with one or two topics says more about each
        rows = [[h, (lambda ps: ps[0] if len(ps) == 1 else '\n'.join('• ' + p + '.' for p in ps))(points(ls, per)), ''] for h, ls in g]
        ttl = 'At a glance' + (f' ({gi} of {len(groups)})' if len(groups) > 1 else '')
        notes = ' — '.join(f'{h}: ' + ' '.join(ls) for h, ls in g)
        sl = {'source': R['actions'], 'fills': {'title': ttl, 'table': [['Topic', 'What it covers', '']] + rows}, 'trim_empty_rows': True, 'trim_empty_cols': True,
              'notes': notes[:6000], 'accent': acc, 'cards': [r[0] for r in rows], 'label_col_in': 3.2}
        if len(rows) > 4: sl['grow_rows'] = True
        if any('\n' in r[1] for r in rows): sl['cells_left'] = True
        out.append(sl)
    if diag: out.insert(1 if len(out) > 1 else len(out), diag)
    return dict(spec, slides=cover + out + closing)


def blocks_to_outline(blocks):
    """Parsed blocks → editable outline rows for the UI (kind, level, text, items, rows)."""
    out = []
    for b in blocks:
        if b[0] == 'h': out.append({'kind': 'h', 'level': b[1], 'text': b[2], 'hint': 'auto'})
        elif b[0] == 'p': out.append({'kind': 'p', 'text': b[1]})
        elif b[0] == 'quote': out.append({'kind': 'quote', 'text': b[1]})
        elif b[0] == 'ul': out.append({'kind': 'ul', 'items': list(b[1])})
        elif b[0] == 'table': out.append({'kind': 'table', 'rows': [list(r) for r in b[1]]})
        elif b[0] == 'diagram':
            d_ = b[1]; nm = {n.get('id'): n.get('label') or n.get('name') for n in d_.get('nodes', []) if isinstance(n, dict)}
            summ = '; '.join(f"{nm.get(f.get('source'), f.get('from', '?'))} → {nm.get(f.get('target'), f.get('to', '?'))}" for f in (d_.get('flows') or [])[:6])
            out.append({'kind': 'diagram', 'arch': d_, 'text': 'Diagram: ' + summ})
    return out


def outline_to_blocks(rows):
    blocks = []
    for r in rows:
        k = r.get('kind'); t = str(r.get('text', '')).strip()
        if r.get('drop'): continue
        if k == 'h' and t: blocks.append(('h', max(1, min(4, int(r.get('level', 2)))), t))
        elif k == 'p' and t: blocks.append(('p', t))
        elif k == 'quote' and t: blocks.append(('quote', t))
        elif k == 'ul':
            items = [str(x).strip() for x in r.get('items', []) if str(x).strip()]
            if items: blocks.append(('ul', items))
        elif k == 'table':
            rows_ = [[str(c) for c in row] for row in r.get('rows', []) if any(str(c).strip() for c in row)]
            if rows_: blocks.append(('table', rows_))
        elif k == 'diagram' and isinstance(r.get('arch'), dict): blocks.append(('diagram', r['arch']))
    return blocks


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('page'); ap.add_argument('--out', required=True); ap.add_argument('--template', default='STANDARD33')
    ap.add_argument('--title'); ap.add_argument('--source-url'); ap.add_argument('--no-icons', action='store_true', help='no template icons beside headings / table headers')
    ap.add_argument('--no-infographics', action='store_true', help='keep numbered steps / 3-card sections as text boxes')
    ap.add_argument('--no-appendix', action='store_true', help='do not add Detail slides with the text Brief mode trimmed')
    ap.add_argument('--no-frame', action='store_true', help='no cover and no closing slide: content slides only')
    ap.add_argument('--storyboard', action='store_true', help='the markdown is a storyboard (one ## per slide, written by a person or a model): a short section keeps its own slide instead of joining the next one as a card')
    ap.add_argument('--density', choices=['brief', 'normal', 'dense', 'compact', 'tight'], default='brief', help='brief = 3 short bullets per paragraph, 2 sub-sections per box (default); normal = whole sentences; dense = 14 lines per box')
    ap.add_argument('--outline', action='store_true', help='print the parsed outline (blocks) as JSON and stop — the "Adjust" step')
    ap.add_argument('--blocks', help='build from an edited outline JSON ({"title","blocks":[…]}) instead of parsing the page')
    ap.add_argument('--max-slides', type=int, default=0, help='fit the deck into N slides by compacting (merge small sections, fuller boxes, no dividers …) — never by cutting a section in half')
    ap.add_argument('--diagram-style', default='auto', help='diagram slides (box art / "A → B" lines): auto or one of ' + ', '.join(DIAGRAM_STYLES))
    a = ap.parse_args()
    global DIAGRAM_STYLE
    DIAGRAM_STYLE = a.diagram_style if a.diagram_style in DIAGRAM_STYLES else 'auto'
    if a.blocks:
        ed = json.load(open(a.blocks, encoding='utf-8')); blocks = outline_to_blocks(ed.get('blocks', [])); title = a.title or ed.get('title') or 'Untitled'
        hints = {str(b.get('text', '')).strip(): b.get('hint') for b in ed.get('blocks', []) if b.get('kind') == 'h' and b.get('hint') and b.get('hint') != 'auto'}
        labels = {str(b.get('text', '')).strip(): b.get('shape_label') for b in ed.get('blocks', []) if b.get('kind') == 'h' and b.get('shape_label')}
        soft = [str(b.get('text', '')).strip() for b in ed.get('blocks', []) if b.get('kind') == 'h' and (b.get('ai_visual') or b.get('shape_layout')) and b.get('hint') == (b.get('shape_layout') or b.get('hint'))]
        spec = fit(blocks, title, a.source_url, a.max_slides, template=a.template.upper(), icons=not a.no_icons, infographics=not a.no_infographics, density=a.density, appendix_slides=not a.no_appendix, frame=not a.no_frame, hints=hints, labels=labels, soft=soft, **({'merge_cost': 0, 'storyboard': True} if a.storyboard else {}))
        if _SD_ERR: spec.setdefault('warnings', []).insert(0, 'diagram module did not load (' + _SD_ERR[0] + ') — architecture and flow sections were NOT drawn; install the kit complete')
        json.dump(spec, open(a.out, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
        print(json.dumps({'status': 'OK', 'out': a.out, 'slides': len(spec['slides']), 'mapping': [s['source'] for s in spec['slides']], 'warnings': spec['warnings'], 'fit': spec.get('fit')}, indent=2)); return
    raw = open(a.page, encoding='utf-8', errors='replace').read()
    raw = re.sub(r'^\s*<!--.*?-->\s*', '', raw, count=1, flags=re.S)   # a leading transcription banner does not make it HTML
    if a.page.lower().endswith(('.html', '.htm')) or raw.lstrip().startswith('<'):
        hp = HTMLBlocks(); hp.feed(raw); hp.close(); blocks = promote_subheads(strip_citations(hp.blocks)); title = a.title or (hp.title or '').strip() or 'Untitled'
        if blocks and blocks[0][0] == 'h' and blocks[0][1] == 1 and blocks[0][2].strip() == title.strip():
            blocks = blocks[1:]  # leading H1 repeats the page title
    else:
        blocks = parse_markdown(raw); blocks, md_hints = layout_lines(blocks); blocks = promote_subheads(strip_citations(blocks))
        first_h = next((b[2] for b in blocks if b[0] == 'h'), None)
        first_p = next((b[1] for b in blocks if b[0] == 'p' and b[1].strip()), '') or next((b[1][0] for b in blocks if b[0] == 'ul' and b[1] and str(b[1][0]).strip()), '')   # a paste that is only bullets: the first bullet names it
        from_line = first_p.strip().rstrip('.!:;') if first_p and len(first_p.strip()) <= 70 else (story_headline(first_p, 70) if first_p else '')   # no heading anywhere: the first line names the deck
        mb = re.match(r'^(?:please\s+|can you\s+|i need\s+|i want\s+)?(?:create|make|build|prepare|draft|generate|write|produce|put together)\s+(?:a\s+|an\s+|the\s+)?(?:\w+\s+){0,2}?(?:presentation|deck|ppt|pptx|slides|slide deck|powerpoint|storyboard)\s+(?:on|about|for|covering|around|of)\s+(.+?)(?:[.:!]+(?:\s.*)?)?$', from_line, re.I)
        if mb: from_line = mb.group(1).strip(); from_line = from_line[0].upper() + from_line[1:]   # "create presentation on sap supply protection" — the topic is the title, not the instruction
        title = a.title or first_h or from_line or 'Untitled'; globals()['TITLE_SOURCE'] = 'given' if a.title else 'heading' if first_h else 'line' if from_line else 'none'
        fh = next((i for i, b in enumerate(blocks) if b[0] == 'h'), None)
        h1_at = [i for i, b in enumerate(blocks) if b[0] == 'h' and b[1] == 1]
        def has_body(i):   # content (not a heading) directly under the H1 at i, before the next H1
            nxt = next((j for j in h1_at if j > i), len(blocks)); return any(b[0] != 'h' for b in blocks[i + 1:nxt])
        def body_of(i):
            nxt = next((j for j in h1_at if j > i), len(blocks)); return blocks[i + 1:nxt]
        flat = not any(b[0] == 'h' for i in h1_at for b in body_of(i))   # no H2/H3 under any H1: a flat list of topics, not a titled document with chapters
        peers = fh is not None and fh in h1_at and len(h1_at) >= 2 and flat and has_body(fh) and any(has_body(i) for i in h1_at[1:]) and any(b[0] == 'ul' or len(body_of(fh)) > 1 for b in body_of(fh))   # "# Topic A / bullets / # Topic B / bullets": the first H1 is a section like the others, not the page title over an intro line
        if fh is not None and blocks[fh][1] == 1 and blocks[fh][2].strip() == (first_h or '').strip() and all(b[0] == 'p' and len(b[1]) <= 80 for b in blocks[:fh]) and not peers:
            blocks = blocks[:fh] + blocks[fh + 1:]  # the first H1 is the page title, not a section (a short kicker line may precede it)
    if a.outline:
        ol_blocks = blocks_to_outline(blocks)
        for ob in ol_blocks:   # a "Layout:" line becomes the heading's layout in the Adjust outline (the editor shows and keeps it)
            if ob.get('kind') == 'h' and (locals().get('md_hints') or {}).get(str(ob.get('text', '')).strip()): ob['hint'] = md_hints[str(ob['text']).strip()]
        json.dump({'status': 'OK', 'title': title, 'title_source': globals().get('TITLE_SOURCE', 'heading'), 'blocks': ol_blocks, 'recovery': dict(RECOVERY)}, open(a.out, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
        print(json.dumps({'status': 'OK', 'out': a.out, 'blocks': len(blocks), 'title': title})); return
    spec = fit(blocks, title, a.source_url, a.max_slides, template=a.template.upper(), icons=not a.no_icons, infographics=not a.no_infographics, density=a.density, appendix_slides=not a.no_appendix, frame=not a.no_frame, hints=locals().get('md_hints') or {}, **({'merge_cost': 0, 'storyboard': True} if a.storyboard else {}))
    if NARR:
        import narration; spec['narrated_from_storyboard'] = narration.attach(spec, NARR)
    if _SD_ERR: spec.setdefault('warnings', []).insert(0, 'diagram module did not load (' + _SD_ERR[0] + ') — architecture and flow sections were NOT drawn; install the kit complete')
    json.dump(spec, open(a.out, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
    print(json.dumps({'status': 'OK', 'out': a.out, 'slides': len(spec['slides']),
                      'mapping': [s['source'] for s in spec['slides']], 'warnings': spec['warnings'], 'fit': spec.get('fit')}, indent=2))


if __name__ == '__main__':
    main()
