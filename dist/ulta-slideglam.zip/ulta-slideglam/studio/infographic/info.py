"""Infographics on the Ulta standard: content → a block spec → a deterministic layout → SVG / PNG / PDF / HTML / PowerPoint.

AI generates (or rules read) the spec; Python lays it out. Every position, size and font size is computed here once and every renderer draws
the same geometry. Typography is the template's: Playfair Display Black for display type (titles, big numbers) and Circular Std for body.
The seven infographic themes of the deck builder (themes.py) set how the coloured elements are treated; the page stays light.

spec = {title, subtitle, kicker, source, format: slide|onepager|square, theme, blocks: [{type, title?, ...}]}
Block types — stats {items:[{value, label, icon?}]} · steps {items:[{title, text}]} · timeline {items:[{when, title, text}]} ·
compare {left:{title, items}, right:{title, items}} · bars {items:[{label, value}], unit?} · donut {items:[{value, label}]} ·
list {items:[{title, text, icon?}]} · quote {text, by?} · takeaway {text, icon?}
"""
import copy, html, json, math, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__)); KIT = os.path.dirname(HERE)
sys.path.insert(0, KIT)
try:
    import themes as TH
except Exception:   # the kit layout is fixed; this keeps the module importable on its own
    TH = None

PX = 7620            # EMU per canvas unit: every format is drawn at 120 units per inch
INK, MUTED, LINE, GOLD = '000000', '404040', 'D9D9D9', 'FF893F'
TITLE = 'EE6C37'     # the template's headline colour
PALETTE = ['F26923', 'E8275A', 'D01381', '5D0F43', 'E9341C']   # v6.22: the template's exact colours (Presentation Central v92 zero colour deviation)
GRAD_TO = {'F26923': 'E8275A', 'E8275A': 'D01381', 'D01381': 'C10060', '5D0F43': 'C10060', 'E9341C': 'F26923', 'EE6C37': 'E8275A'}   # v6.14: each brand colour runs toward its neighbour


def bgrad(c, amt=0.55):
    """The Ulta gradient for a solid colour: from the colour toward its neighbour in the brand ramp (orange → pink → magenta → plum),
    part of the way so it stays calm; a colour outside the ramp (a RAG colour) deepens a little instead."""
    c = str(c or '').upper()
    if len(c) != 6: return None
    to = GRAD_TO.get(c)
    return (c, _mix(c, to, amt)) if to else (c, shade(c, 0.22))


def sgrad(c, t=0.86):
    """The soft version for tinted discs and bands: two light tints, the colour's and its neighbour's."""
    c = str(c or '').upper(); to = GRAD_TO.get(c, c)
    return (tint(c, t), tint(to, min(0.95, t + 0.04)))
DISPLAY = "'Playfair Display Black','Playfair Display',Georgia,'Times New Roman',serif"
BODY = "'Circular Std','Circular Std Book',Circular,'Helvetica Neue',Helvetica,Arial,sans-serif"
FONT_PPT = {'display': 'Playfair Display Black', 'body': 'Circular Std Book', 'bold': 'Circular Std Bold'}

FORMATS = {
    'slide':    {'name': 'Slide 16:9', 'blurb': 'One slide on the Ulta template — the headline is the template\'s own', 'w': 1600, 'h': 900, 'body': (60, 174, 1480, 620)},
    'onepager': {'name': 'One-pager', 'blurb': 'Letter portrait — print it or share it as a PDF', 'w': 1020, 'h': 1320, 'margin': 60},
    'square':   {'name': 'Social square', 'blurb': '1:1 for Workplace, Teams or LinkedIn posts', 'w': 1080, 'h': 1080, 'margin': 56},
}
FORMAT_ORDER = ['slide', 'onepager', 'square']
BLOCKS = {
    'stats': 'Big numbers with a label (2–4)', 'steps': 'A process in numbered steps (3–6)', 'timeline': 'Dates or phases on a line (3–7)',
    'compare': 'Before / after, today / target', 'bars': 'A bar chart from label + value pairs', 'donut': 'Percentages as rings (1–3)',
    'list': 'Points with a pictogram each', 'quote': 'A pull quote', 'takeaway': 'The one message to remember',
    'status': 'Status strip: overall RAG, week, phase, lead (2–5 facts)', 'rag': 'Workstreams: RAG, owner, this week, next week', 'risks': 'Risks & support required, with owner and date',
}
WIDE = {'stats', 'steps', 'timeline', 'compare', 'list', 'takeaway', 'status', 'rag', 'risks'}
THEME_ORDER = ['ulta', 'glow', 'velvet', 'frost', 'paper', 'sunset', 'charcoal']


# ------------------------------------------------------------------------------------------------------------------ helpers
def tint(hex_, amount):
    r, g, b = (int(hex_[i:i + 2], 16) for i in (0, 2, 4)); f = lambda c: int(round(c + (255 - c) * amount))
    return f'{f(r):02X}{f(g):02X}{f(b):02X}'


def shade(hex_, amount):
    r, g, b = (int(hex_[i:i + 2], 16) for i in (0, 2, 4)); f = lambda c: int(round(c * (1 - amount)))
    return f'{f(r):02X}{f(g):02X}{f(b):02X}'


TAIL_WORDS = re.compile(r'(?:[\s,;:—–-]+(?:and|or|but|the|a|an|of|to|in|on|for|with|by|as|at|from|into|than|that|which|is|are))+[\s,;:—–-]*$', re.I)


def cut(t, n):
    """At most n characters, cut where a phrase ends — a sentence, a clause, else a whole word — never mid-word, never a trailing
    "and / the / to", never an ellipsis (v6.21: the infographic follows the deck rules: nothing delivered ends in "…")."""
    t = str(t or '').strip()
    if len(t) <= n: return t
    head = t[:n + 1]
    for pat in (r'[.!?](?=\s)', r'[;:](?=\s)', r'\s[—–-](?=\s)', r',(?=\s)'):
        ends = [m.start() for m in re.finditer(pat, head) if m.start() >= n * 0.55]
        if ends: head = head[:ends[-1] + (1 if pat.startswith('[.!?]') else 0)]; break
    else:
        head = head.rsplit(' ', 1)[0] if ' ' in head else head[:n]
    return TAIL_WORDS.sub('', head).rstrip(' ,;:—–-') or t[:n]


def clean(t, n=160):
    t = re.sub(r'\s+', ' ', re.sub(r'[*_`]+', '', str(t or ''))).strip()
    return t if len(t) <= n else cut(t, n)


def bold_lead(t):
    """A bullet that opens with a bold phrase is a titled point: "**Ground the task**Repository rules…" (Word and Confluence often drop
    the space after the bold run) → "Ground the task: Repository rules…", so the bold words become the item's title."""
    m = re.match(r'^\s*(\*\*|__)(.+?)\1\s*[:—–-]?\s*(.*)$', str(t or ''))
    if not m or not re.search(r'\w', m.group(3)) or len(m.group(2)) > 80: return t if not m else m.group(2).strip() + m.group(3).strip()
    return m.group(2).strip().rstrip(':') + ': ' + m.group(3).strip()


def icon_names():
    try: return [i['name'] for i in json.load(open(os.path.join(os.path.dirname(KIT), *'modules/ultabranddeliverables/scripts/kit/icons'.split('/'), 'icons.json'), encoding='utf-8'))['icons']]
    except Exception: return []


def pick_icon(text):
    try:
        from build_from_storyboard import pick_icon as _p
        return _p(text)
    except Exception: return 'idea'


_ICON_CACHE = {}
def icon_svg(name):
    """(viewBox, inner markup) of a template pictogram, ids stripped."""
    if name not in _ICON_CACHE:
        try: s = open(os.path.join(os.path.dirname(KIT), *'modules/ultabranddeliverables/scripts/kit/icons'.split('/'), name + '.svg'), encoding='utf-8').read()
        except Exception: _ICON_CACHE[name] = None; return None
        vb = (re.search(r'viewBox="([^"]+)"', s) or re.search(r'(x)', 'x')).group(1)
        inner = re.sub(r'^.*?<svg[^>]*>|</svg>\s*$', '', s, flags=re.S); inner = re.sub(r'\sid="[^"]*"', '', inner); inner = re.sub(r'<defs>\s*</defs>', '', inner)
        inner = re.sub(r'<style\b.*?</style>', '', inner, flags=re.S); inner = re.sub(r'\sclass="[^"]*"', '', inner)   # half the set colours itself by CSS (fill:#F16A1C) — CSS beats the recoloured fill attribute: an orange icon drawn as "white"
        _ICON_CACHE[name] = (vb, inner)
    return _ICON_CACHE[name]


def icon_sheet():
    """The pictograms for the editor's icon gallery: name → keywords (for search) and the SVG in currentColor (the gallery colours it)."""
    try: cat = json.load(open(os.path.join(os.path.dirname(KIT), *'modules/ultabranddeliverables/scripts/kit/icons'.split('/'), 'icons.json'), encoding='utf-8'))['icons']
    except Exception: return {}   # noqa: BLE001
    out = {}
    for c in cat:
        ic = icon_svg(c['name'])
        if not ic: continue
        vb, inner = ic; inner = re.sub(r'(fill|stroke)="#[0-9A-Fa-f]{3,6}"', r'\1="currentColor"', inner)
        out[c['name']] = {'k': c.get('keywords', []), 'c': c.get('category', ''), 'svg': f'<svg viewBox="{vb}" xmlns="http://www.w3.org/2000/svg">{inner}</svg>'}
    return out


def logo_svg():
    s = open(os.path.join(HERE, 'ulta-logo.svg'), encoding='utf-8').read()
    return re.search(r'viewBox="([^"]+)"', s).group(1), re.sub(r'<style>.*?</style>', '', re.sub(r'^.*?<svg[^>]*>|</svg>\s*$', '', s, flags=re.S), flags=re.S)


CW = {'display': 0.60, 'body': 0.50, 'bold': 0.54}   # average advance per character, as a share of the font size (conservative)


def wrap(text, w, fs, font='body'):
    words = str(text or '').split(); lines = []; cur = ''; cap = max(1, int(w / (fs * CW[font])))
    for wd in words:
        if len(wd) > cap:
            if cur: lines.append(cur); cur = ''
            while len(wd) > cap: lines.append(wd[:cap]); wd = wd[cap:]
        if not cur: cur = wd
        elif len(cur) + 1 + len(wd) <= cap: cur += ' ' + wd
        else: lines.append(cur); cur = wd
    if cur: lines.append(cur)
    return lines or ['']


HALF = {'table', 'list', 'risks', 'timeline', 'stats', 'compare', 'steps', 'donut', 'bars', 'quote'}   # can sit half-width beside another when squeezed
def _fl(): return MIN_FS[0] or 14   # the text floor in force (14 units = 8.4 pt; 13.4 when squeezed onto one slide)


SQUEEZE = [False]   # v6.13: a template squeezed onto one 16:9 slide (smaller floors)
MIN_FS = [0]   # v6.11: a template page sets a floor (14 units = 8.4 pt in the PowerPoint) for every fitted text while it is laid out


def fit(text, w, h, hi, lo, font='body', lh=1.22, max_lines=None, report=True):
    """The largest size in [lo, hi] at which the text wraps inside w × h; (fs, lines)."""
    if MIN_FS[0]:   # a template: never under the floor and never cut — the text takes the lines it needs (the height grows)
        lo = max(lo, MIN_FS[0]); hi = max(hi, lo); h = max(h, len(wrap(text, w, lo, font)) * lo * lh); max_lines = None
    cap_ok = lambda s: max((len(x) for x in str(text or '').split()), default=0) <= max(1, int(w / (s * CW[font])))   # no word broken mid-way ("30-m / in")
    for whole in (True, False):   # first the largest size that keeps every word whole; only if none does, a word may break
        fs = hi
        while fs >= lo:
            ls = wrap(text, w, fs, font)
            if (not whole or cap_ok(fs)) and len(ls) * fs * lh <= h and (not max_lines or len(ls) <= max_lines): return fs, ls
            fs -= 1
    ls = wrap(text, w, lo, font)
    n = max(1, int(h / (lo * lh))) if h else len(ls)
    if max_lines: n = min(n, max_lines)
    if len(ls) > n: ls = ls[:n]; ls[-1] = TAIL_WORDS.sub('', ls[-1]).rstrip('.,;:—–- ') or ls[-1]
    return lo, ls


def style(theme, c, role='card'):
    """How one coloured element looks in a theme: fill (or a gradient), line, and the ink on it."""
    t = theme if theme in THEME_ORDER else 'ulta'
    if t == 'ulta': return {'fill': c, 'grad': bgrad(c), 'stroke': None, 'glow': None, 'text': 'FFFFFF', 'sub': 'FFFFFF', 'head': 'FFFFFF', 'icon': 'FFFFFF', 'r': 14}
    if t == 'glow': return {'fill': 'FFFFFF', 'grad': None, 'stroke': 'EFE4DD', 'glow': tint(c, 0.72), 'text': INK, 'sub': MUTED, 'head': c, 'icon': c, 'r': 18}
    if t == 'velvet': return {'fill': INK, 'grad': (shade(c, 0.05), '231B18'), 'stroke': None, 'glow': None, 'text': 'FFFFFF', 'sub': 'F9E3DE', 'head': 'FFFFFF', 'icon': 'FFFFFF', 'r': 16}
    if t == 'frost': return {'fill': tint(c, 0.8), 'grad': None, 'stroke': 'FFFFFF', 'glow': None, 'text': INK, 'sub': '4A403B', 'head': shade(c, 0.12), 'icon': shade(c, 0.05), 'r': 22}
    if t == 'paper': return {'fill': 'FFFFFF', 'grad': None, 'stroke': c, 'glow': None, 'text': INK, 'sub': MUTED, 'head': c, 'icon': c, 'r': 8}
    if t == 'sunset': return {'fill': c, 'grad': (c, GOLD), 'stroke': None, 'glow': None, 'text': 'FFFFFF', 'sub': 'FFFFFF', 'head': 'FFFFFF', 'icon': 'FFFFFF', 'r': 16}
    return {'fill': '404040', 'grad': None, 'stroke': None, 'glow': None, 'text': 'FFFFFF', 'sub': 'E6DCD6', 'head': 'FFFFFF', 'icon': 'FFFFFF', 'r': 12}   # charcoal


def catalogue():
    th = getattr(TH, 'THEMES', {}) if TH else {}
    return {'formats': [{'id': k, 'name': FORMATS[k]['name'], 'blurb': FORMATS[k]['blurb'], 'w': FORMATS[k]['w'], 'h': FORMATS[k]['h']} for k in FORMAT_ORDER],
            'themes': [{'id': k, 'name': (th.get(k) or {}).get('label', k.title()), 'note': (th.get(k) or {}).get('note', ''), 'swatch': style(k, PALETTE[0])['grad'] or [style(k, PALETTE[0])['fill']]} for k in THEME_ORDER],
            'blocks': [{'type': k, 'what': v} for k, v in BLOCKS.items()], 'icons': icon_names(), 'templates': TEMPLATES}


# ------------------------------------------------------------------------------------------------------------------ spec
def _items(v, keys, n=8):
    out = []
    for it in (v or [])[:n]:
        if isinstance(it, str):
            parts = [p.strip() for p in it.split('|')]; it = {k: (parts[i] if i < len(parts) else '') for i, k in enumerate(keys)}
        if not isinstance(it, dict): continue
        it = {k: clean(it.get(k), 90 if k in ('title', 'when', 'value', 'label') else 170) for k in keys if k != 'icon'} | ({'icon': it['icon']} if it.get('icon') in ICONS else {})
        if any(str(it.get(k) or '').strip() for k in keys if k != 'icon'): out.append(it)
    return out


ICONS = set(icon_names())


def num(v):
    m = re.search(r'-?\d[\d,]*(?:\.\d+)?', str(v or ''))
    try: return float(m.group(0).replace(',', '')) if m else None
    except Exception: return None


ICON_SIZE = {'s': 0.85, 'm': 1.0, 'l': 1.22}


def _ic(b):
    """(size factor, bold, badge) for the pictograms of block b — the infographic's icon options, passed down by layout()."""
    o = b.get('_ic') or {}
    return ICON_SIZE.get(o.get('size'), 1.0), o.get('weight') == 'bold', o.get('badge') or 'auto'


def normalise(spec):
    s = spec if isinstance(spec, dict) else {}
    out = {'title': clean(s.get('title'), 160) or 'Infographic', 'subtitle': clean(s.get('subtitle'), 280), 'kicker': clean(s.get('kicker'), 40).upper(),
           'source': clean(s.get('source'), 160), 'format': s.get('format') if s.get('format') in FORMATS else 'onepager',
           'theme': (TH.resolve(s.get('theme')) if TH else s.get('theme')) if s.get('theme') else 'ulta', 'blocks': []}
    if s.get('template') and re.fullmatch(r'[a-z_]{2,24}', str(s['template'])): out['template'] = s['template']   # free, status, or a templates.py id
    if out['theme'] not in THEME_ORDER: out['theme'] = 'ulta'
    io_ = s.get('icons') if isinstance(s.get('icons'), dict) else None
    if io_:   # how pictograms are drawn: size s | m | l, weight regular | bold, list badge auto | filled | light
        out['icons'] = {'size': io_.get('size') if io_.get('size') in ICON_SIZE else 'm', 'weight': 'bold' if io_.get('weight') == 'bold' else 'regular',
                        'badge': io_.get('badge') if io_.get('badge') in ('auto', 'filled', 'light') else 'auto'}
    for b in (s.get('blocks') or [])[:8]:
        if not isinstance(b, dict) or b.get('type') not in BLOCKS: continue
        t = b['type']; nb = {'type': t, 'title': clean(b.get('title'), 60)}
        if t == 'stats': nb['items'] = _items(b.get('items'), ['value', 'label', 'icon'], 4)
        elif t == 'steps': nb['items'] = _items(b.get('items'), ['title', 'text'], 6)
        elif t == 'timeline': nb['items'] = _items(b.get('items'), ['when', 'title', 'text'], 7)
        elif t == 'list': nb['items'] = _items(b.get('items'), ['title', 'text', 'icon'], 9)
        elif t == 'bars':
            nb['items'] = [it for it in _items(b.get('items'), ['label', 'value'], 8) if num(it.get('value')) is not None]; nb['unit'] = clean(b.get('unit'), 12)
        elif t == 'donut': nb['items'] = [it for it in _items(b.get('items'), ['value', 'label'], 3) if num(it.get('value')) is not None]
        elif t in ('status', 'rag', 'risks'):   # v6.9 status report: fields kept whole (up to 200 characters), RAG words normalised
            keys = {'status': ['label', 'value', 'rag'], 'rag': ['name', 'owner', 'rag', 'now', 'next', 'due', 'support', 'risk', 'ask'], 'risks': ['title', 'text', 'owner', 'due', 'rag']}[t]; nb['items'] = []
            for it in (b.get('items') or [])[:{'status': 5, 'rag': 10, 'risks': 6}[t]]:
                if isinstance(it, str): p_ = [q.strip() for q in it.split('|')]; it = {k_: (p_[i_] if i_ < len(p_) else '') for i_, k_ in enumerate(keys)}
                if not isinstance(it, dict): continue
                o_ = {k_: clean(it.get(k_), 200) for k_ in keys}
                if o_.get('rag'): o_['rag'] = rag_of(o_['rag']) or ''
                if any(o_[k_] for k_ in keys if k_ != 'rag'): nb['items'].append(o_)
            if t == 'rag': nb['cols'] = [clean(c_, 40) for c_ in (b.get('cols') or ['This week', 'Next week'])[:2]] + ['This week', 'Next week'][len((b.get('cols') or [])[:2]):]
        elif t == 'table':   # v6.11 templates: any header + rows (cells kept whole up to 160 characters)
            nb['cols'] = [clean(c_, 40) for c_ in (b.get('cols') or [])[:6]]; n_ = len(nb['cols']); nb['icons'] = bool(b.get('icons'))
            nb['items'] = [[clean(c_, 160) for c_ in (list(r_) + [''] * n_)[:n_]] for r_ in (b.get('items') or [])[:10] if isinstance(r_, (list, tuple)) and any(str(c_).strip() for c_ in r_)]
            if not n_ or not nb['items']: continue
        elif t == 'ragcards':
            nb['items'] = []
            for it in (b.get('items') or [])[:9]:
                if isinstance(it, str): p_ = [q.strip() for q in it.split('|')]; it = dict(zip(('name', 'owner', 'rag', 'text'), p_ + [''] * 4))
                if isinstance(it, dict) and str(it.get('name') or '').strip(): nb['items'].append({k_: clean(it.get(k_), 420 if k_ == 'text' else 200) for k_ in ('name', 'owner', 'text')} | {'rag': rag_of(it.get('rag'))})   # this week + next week fit whole
        elif t == 'compare':
            for side in ('left', 'right'):
                v = b.get(side) if isinstance(b.get(side), dict) else {}
                nb[side] = {'title': clean(v.get('title'), 40) or ('Today' if side == 'left' else 'Target'), 'items': [clean(x, 140) for x in (v.get('items') or [])[:6] if clean(x)]}
            if not nb['left']['items'] and not nb['right']['items']: continue
        elif t == 'quote':
            nb['text'] = clean(b.get('text'), 240); nb['by'] = clean(b.get('by'), 60)
            if not nb['text']: continue
        elif t == 'takeaway':
            nb['text'] = clean(b.get('text'), 220)
            if b.get('icon') in ICONS: nb['icon'] = b['icon']
            if not nb['text']: continue
        if 'items' in nb and not nb['items']: continue
        out['blocks'].append(nb)
    return out


# ------------------------------------------------------------------------------------------------------------------ rules (AI off)
NUMTOK = re.compile(r'(?:[$£€])?\d[\d,]*(?:\.\d+)?\s*(?:%|percent|pts?|k|m|bn|x|\+)?(?![\w])', re.I)
STAT_ICONS = ['trend-up', 'target', 'performance', 'award']
SPARE_ICONS = ['idea', 'target', 'gears', 'puzzle', 'layers', 'star', 'sliders', 'rating', 'trend-up', 'user']   # v6.21: a point no keyword matches still gets a pictogram


def fill_icons(items, heading=''):
    """Every item an icon: its own keyword match, else the heading's, else a spare one not used yet in the block (no bare dots)."""
    used = {it.get('icon') for it in items if it.get('icon')}
    spare = [x for x in SPARE_ICONS if x in ICONS and x not in used] or [x for x in SPARE_ICONS if x in ICONS]
    for k, it in enumerate(items):
        if it.get('icon') in ICONS: continue
        it['icon'] = spare[k % len(spare)] if spare else 'idea'
SEQ_WORDS = re.compile(r'\b(steps?|process|how|phases?|stages?|approach|journey|plan|roadmap|rollout|way forward|next steps)\b', re.I)
TIME_TOK = re.compile(r'^\s*((?:Q[1-4]|H[12])(?:\s*(?:FY)?\s*\d{2,4})?|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s*\d{0,4}|(?:19|20)\d{2}|Week\s*\d+|Wave\s*\d+|Phase\s*\d+|Day\s*\d+)\s*[:\-–—]\s*', re.I)
TAKE_WORDS = re.compile(r'\b(ask|takeaway|key message|bottom line|summary|decision|conclusion|why it matters|so what)\b', re.I)
CMP_WORDS = re.compile(r'\b(before|after|today|target|current|future|as[- ]is|to[- ]be|from|vs\.?|versus)\b', re.I)


def _pct(tok):
    return re.sub(r'\s*percent', '%', tok.strip(), flags=re.I)


def _stat(line):
    toks = [t.strip() for t in NUMTOK.findall(line) if re.search(r'\d', t)]
    if not toks: return None
    if len(toks) >= 2 and re.search(r'\bfrom\b.*\bto\b|→|->', line, re.I): value = f'{_pct(toks[0])} → {_pct(toks[1])}'
    else: value = _pct(toks[0])
    label = line
    if '→' in value: label = re.sub(r'\s*\bfrom\b\s*' + re.escape(toks[0]) + r'.*?\bto\b\s*' + re.escape(toks[1]) + r'\s*', ' ', label, flags=re.I)
    elif label.strip().lower().startswith(toks[0].lower()): label = label.strip()[len(toks[0]):]
    label = re.sub(r'\s+', ' ', label).strip(' ,.;:-–—')
    if len(label.split()) < 2: label = line
    return {'value': value, 'label': clean(cap(label), 120)}


def cap(s):
    s = str(s or '').strip()
    return s[:1].upper() + s[1:] if s else s


def _sections(text):
    lines = [l.rstrip() for l in str(text or '').replace('\r', '').split('\n')]
    title = subtitle = source = ''; secs = []; cur = None; sub = None
    for raw in lines:
        l = raw.strip()
        if not l: continue
        if re.match(r'^(source|sources|data)\s*:', l, re.I): source = re.sub(r'^\w+\s*:\s*', '', l); continue
        hb = re.match(r'^block\s*:\s*([a-z]+)\s*$', l, re.I)
        if hb and cur is not None: cur['hint'] = hb.group(1).lower(); continue   # v6.15: the form names each section's block (a renamed or added section keeps its look)
        m = re.match(r'^(#{1,4})\s+(.*)', l)
        if m:
            lvl, h = len(m.group(1)), clean(m.group(2), 160 if len(m.group(1)) == 1 else 90)
            if lvl == 1 and not title: title = h; continue
            if lvl >= 3 and cur is not None: sub = {'title': h, 'items': []}; cur['subs'].append(sub); continue
            cur = {'title': h, 'bullets': [], 'paras': [], 'rows': [], 'subs': [], 'ordered': False}; secs.append(cur); sub = None; continue
        if not title and not l.startswith('|'): title = clean(re.sub(r'^[-*•]\s*', '', l), 160); continue   # v6.14: a table's header row is never the title
        if cur is None:
            if not subtitle and not re.match(r'^([-*•]|\d+[.)]|\|)', l): subtitle = clean(l, 280); continue
            cur = {'title': '', 'bullets': [], 'paras': [], 'rows': [], 'subs': [], 'ordered': False}; secs.append(cur)
        if l.startswith('|'):
            cells = [c.strip() for c in l.strip('|').split('|')]
            if not all(re.fullmatch(r':?-{2,}:?', c) for c in cells if c): cur['rows'].append(cells)
            continue
        b = re.match(r'^([-*•]|\d+[.)])\s+(.*)', l)
        if b:
            if b.group(1)[0].isdigit(): cur['ordered'] = True
            (sub['items'] if sub is not None else cur['bullets']).append(clean(bold_lead(b.group(2)), 190)); continue
        if l.startswith('>'): cur['paras'].append('> ' + clean(l.lstrip('> '), 240)); continue
        if l.endswith(':') and len(l) < 70: cur = {'title': clean(l[:-1], 90), 'bullets': [], 'paras': [], 'rows': [], 'subs': [], 'ordered': False}; secs.append(cur); sub = None; continue
        (sub['items'] if sub is not None else cur['paras']).append(clean(l, 240))
    return title, subtitle, source, secs


def rules_spec(text, fmt='onepager', theme='ulta', title=''):
    """Headings become blocks; what is under them picks the block: a table with numbers → bars, two sub-headings → compare, numbers in most
    bullets → stats (percentages alone → rings), dated lines → timeline, an ordered list or a process heading → steps, one sentence → takeaway
    or quote, anything else → a list with a pictogram per point."""
    t0, subtitle, source, secs = _sections(text)
    blocks = []
    for i, s in enumerate(secs):
        h, bl, ps, rows = s['title'], s['bullets'], s['paras'], s['rows']
        if len(rows) >= 3 and all(len(r) >= 2 for r in rows[1:]) and sum(num(r[1]) is not None for r in rows[1:]) >= max(2, len(rows[1:]) - 1):
            unit = '%' if all('%' in r[1] for r in rows[1:] if r[1]) else ''
            blocks.append({'type': 'bars', 'title': h or rows[0][1], 'unit': unit, 'items': [{'label': r[0], 'value': r[1]} for r in rows[1:] if num(r[1]) is not None]}); continue
        if len(s['subs']) == 2:
            a, b = s['subs']; blocks.append({'type': 'compare', 'title': h, 'left': {'title': a['title'], 'items': a['items']}, 'right': {'title': b['title'], 'items': b['items']}}); continue
        if bl:
            times = [TIME_TOK.match(x) for x in bl]
            if len(bl) >= 3 and sum(1 for m in times if m) >= len(bl) - 1:
                items = []
                for x, m in zip(bl, times):
                    rest = x[m.end():] if m else x; tt, _, tx = rest.partition(' — ') if ' — ' in rest else rest.partition(': ')
                    items.append({'when': m.group(1) if m else '', 'title': cap(clean(tt, 60)), 'text': cap(clean(tx, 140))})
                blocks.append({'type': 'timeline', 'title': h, 'items': items}); continue
            stats = [_stat(x) for x in bl]
            if 2 <= len(bl) <= 4 and sum(1 for x in stats if x) >= len(bl) - (0 if len(bl) == 2 else 1) and all(len(x) <= 110 for x in bl):
                vals = [x for x in stats if x]
                if len(vals) <= 3 and all(re.fullmatch(r'\d+(?:\.\d+)?%', v['value']) and num(v['value']) <= 100 for v in vals):
                    blocks.append({'type': 'donut', 'title': h, 'items': vals}); continue
                blocks.append({'type': 'stats', 'title': h, 'items': [dict(v, icon=pick_icon(v['label']) or STAT_ICONS[j % 4]) for j, v in enumerate(vals)]}); continue
            if (s['ordered'] or SEQ_WORDS.search(h or '')) and 3 <= len(bl) <= 6:
                items = []
                for x in bl:
                    a, sep, b = x.partition(' | ') if ' | ' in x else (x.partition(': ') if ': ' in x else x.partition(' — '))
                    items.append({'title': cap(clean(a, 50)), 'text': cap(clean(b, 140))} if sep and len(a) <= 50 else {'title': cap(clean(' '.join(x.split()[:4]), 50)), 'text': cap(clean(x, 140))})
                blocks.append({'type': 'steps', 'title': h, 'items': items}); continue
            items = []
            for x in bl[:9]:
                a, sep, b = x.partition(' | ') if ' | ' in x else (x.partition(': ') if ': ' in x else x.partition(' — '))
                items.append({'title': clean(a, 64), 'text': clean(b, 160), 'icon': pick_icon(x)} if sep and len(a) <= 64 else {'title': '', 'text': clean(x, 170), 'icon': pick_icon(x)})
            for it in items:   # a point without its own title: short → it is the title; long → split where its first phrase ends (never at a word count)
                if it['title']: continue
                t_ = it['text']; w = t_.split(); c_ = re.search(r'^(.{12,70}?)(?:,|;| — | – )\s+(.+)$', t_)
                if len(w) <= 11: it['title'], it['text'] = t_.rstrip('.'), ''
                elif c_ and len(c_.group(1).split()) <= 9: it['title'], it['text'] = c_.group(1), cap(c_.group(2))
            fill_icons(items, h)
            blocks.append({'type': 'list', 'title': h, 'items': items}); continue
        if ps:
            p = ps[0]
            if p.startswith('> ') or p[:1] in '“"': blocks.append({'type': 'quote', 'title': h, 'text': p.lstrip('> ').strip('“”"'), 'by': ps[1] if len(ps) > 1 and len(ps[1]) < 60 else ''}); continue
            blocks.append({'type': 'takeaway', 'title': '' if TAKE_WORDS.search(h or '') or i == len(secs) - 1 else h, 'text': clean(' '.join(ps), 260), 'icon': 'target'}); continue
    if not blocks and subtitle: blocks.append({'type': 'takeaway', 'text': subtitle}); subtitle = ''
    return normalise({'title': title or t0, 'subtitle': subtitle, 'source': source, 'format': fmt, 'theme': theme, 'blocks': blocks})


def sample_spec(fmt='onepager', theme='ulta'):
    return normalise({'title': 'Supply protection pilot', 'kicker': 'B2B · Q3 update', 'subtitle': 'Protected stock kept launch SKUs on shelf for priority partners.', 'format': fmt, 'theme': theme,
                      'source': 'Sample content — replace it with yours',
                      'blocks': [{'type': 'stats', 'items': [{'value': '14% → 4%', 'label': 'Shortfalls on launch SKUs', 'icon': 'trend-up'}, {'value': '120', 'label': 'Articles protected across 3 DCs', 'icon': 'package'}, {'value': '400', 'label': 'More articles next wave', 'icon': 'growth-check'}]},
                                 {'type': 'steps', 'title': 'How it works', 'items': [{'title': 'Reserve', 'text': 'Stock is held for priority partners'}, {'title': 'Review', 'text': 'Unused protection is checked weekly'}, {'title': 'Release', 'text': 'Surplus returns to open demand'}]},
                                 {'type': 'takeaway', 'text': 'Extend protection to the next 400 articles before the holiday peak.', 'icon': 'target'}]})


# ------------------------------------------------------------------------------------------------------------------ layout
class Canvas:
    def __init__(self): self.els = []; self.warn = []
    def rect(self, x, y, w, h, fill=None, stroke=None, r=0, sw=1, grad=None, name='box', **kw):
        self.els.append({'k': 'rect', 'x': round(x, 1), 'y': round(y, 1), 'w': round(w, 1), 'h': round(h, 1), 'fill': fill, 'stroke': stroke, 'r': r, 'sw': sw, 'grad': list(grad) if grad else None, 'name': name, **kw})
    def text(self, x, y, w, lines, fs, color, font='body', align='left', lh=1.22, name='text', src=None, **kw):
        h = len(lines) * fs * lh
        self.els.append({'k': 'text', 'x': round(x, 1), 'y': round(y, 1), 'w': round(w, 1), 'h': round(h, 1), 'lines': lines, 't': src if src is not None else ' '.join(lines), 'fs': round(fs, 1), 'color': color, 'font': font, 'align': align, 'lh': lh, 'name': name, **kw})
        return h
    def ellipse(self, x, y, w, h, fill=None, stroke=None, sw=1, name='dot', grad=None, **kw):
        self.els.append({'k': 'ellipse', 'x': round(x, 1), 'y': round(y, 1), 'w': round(w, 1), 'h': round(h, 1), 'fill': fill or (grad[0] if grad else None), 'stroke': stroke, 'sw': sw, 'name': name,
                         'grad': list(grad) if grad else None, **kw})
    def line(self, x1, y1, x2, y2, color, sw=2, dash=False, name='line', **kw):
        self.els.append({'k': 'line', 'x1': round(x1, 1), 'y1': round(y1, 1), 'x2': round(x2, 1), 'y2': round(y2, 1), 'color': color, 'sw': sw, 'dash': dash, 'name': name, **kw})
    def icon(self, name, x, y, s, color, **kw):
        if name and icon_svg(name): self.els.append({'k': 'icon', 'name': name, 'x': round(x, 1), 'y': round(y, 1), 's': round(s, 1), 'color': color, **kw})
    def poly(self, pts, fill, stroke=None, sw=1, name='shape', **kw):
        self.els.append({'k': 'poly', 'pts': [(round(x, 1), round(y, 1)) for x, y in pts], 'fill': fill, 'stroke': stroke, 'sw': sw, 'name': name, **kw})
    def arc(self, cx, cy, r, sw, frac, color, track, **kw):
        self.els.append({'k': 'arc', 'cx': round(cx, 1), 'cy': round(cy, 1), 'r': round(r, 1), 'sw': round(sw, 1), 'frac': max(0.0, min(1.0, frac)), 'color': color, 'track': track, **kw})


def card(cv, x, y, w, h, st, name='card'):
    if st.get('glow'): cv.rect(x + 2, y + 7, w - 4, h, st['glow'], None, st['r'] + 2, name=name + ' glow')
    cv.rect(x, y, w, h, st['fill'], st['stroke'], st['r'], 1.5 if st['stroke'] else 1, st['grad'], name=name)


def block_title(cv, b, x, y, w, k, accent):
    if not b.get('title'): return 0
    cv.rect(x, y + 3 * k, 5 * k, 22 * k, accent, None, 2, grad=bgrad(accent), gv=True, name='title bar')
    fs, ls = fit(b['title'], w - 16 * k, 60 * k, round(21 * k), round(15 * k), 'bold', max_lines=2)
    return cv.text(x + 15 * k, y, w - 16 * k, ls, fs, INK, 'bold', name='block title', src=b['title']) + 12 * k


def draw_stats(cv, b, x, y, w, k, theme, ci):
    its = b['items']; n = len(its); g = 16 * k; cw = (w - g * (n - 1)) / n; pad = 20 * k
    parts = []
    for i, it in enumerate(its):
        c = PALETTE[(ci + i) % len(PALETTE)]; st = style(theme, c)
        vfs, vls = fit(it['value'], cw - 2 * pad, 130 * k, round(54 * k), round(24 * k), 'display', 1.08, 2)
        lfs, lls = fit(it['label'], cw - 2 * pad, 96 * k, round(16 * k), round(12 * k), 'body', 1.3, 4)
        f_, bold_, _ = _ic(b); ih = (40 * k * f_ + 12 * k) if it.get('icon') else 0
        parts.append((c, st, vfs, vls, lfs, lls, ih))
    ch = max(pad * 2 + p[6] + len(p[3]) * p[2] * 1.08 + 8 * k + len(p[5]) * p[4] * 1.3 for p in parts)
    for i, (it, p) in enumerate(zip(its, parts)):
        c, st, vfs, vls, lfs, lls, ih = p; cx = x + i * (cw + g); card(cv, cx, y, cw, ch, st, 'stat card'); yy = y + pad
        if ih: f_, bold_, _ = _ic(b); cv.icon(it['icon'], cx + pad, yy, 40 * k * f_, st['icon'], bold=bold_); yy += ih
        yy += cv.text(cx + pad, yy, cw - 2 * pad, vls, vfs, st['head'] if theme != 'ulta' else 'FFFFFF', 'display', lh=1.08, name='stat value', src=it['value']) + 8 * k
        cv.text(cx + pad, yy, cw - 2 * pad, lls, lfs, st['sub'], 'body', lh=1.3, name='stat label', src=it['label'])
    return ch


def draw_steps(cv, b, x, y, w, k, theme, ci):
    its = b['items']; n = len(its); colw = w / n; d = 58 * k; cy = y + d / 2
    cv.line(x + colw / 2, cy, x + w - colw / 2, cy, tint(PALETTE[ci % 5], 0.55), 4 * k, name='steps line')
    hmax = 0; tex = []
    for i, it in enumerate(its):
        tfs, tls = fit(it['title'], colw - 20 * k, 60 * k, round(17 * k), round(13 * k), 'bold', 1.2, 2)
        xfs, xls = fit(it.get('text', ''), colw - 20 * k, 110 * k, round(14 * k), round(11 * k), 'body', 1.32, 5) if it.get('text') else (0, [])
        tex.append((tfs, tls, xfs, xls)); hmax = max(hmax, len(tls) * tfs * 1.2 + (8 * k + len(xls) * xfs * 1.32 if xls else 0))
    for i, (it, (tfs, tls, xfs, xls)) in enumerate(zip(its, tex)):
        c = PALETTE[(ci + i) % 5]; st = style(theme, c); mx = x + i * colw + colw / 2
        if st.get('glow'): cv.ellipse(mx - d / 2 - 3 * k, y - 3 * k + 5 * k, d + 6 * k, d + 6 * k, st['glow'], name='step glow')
        cv.ellipse(mx - d / 2, y, d, d, st['fill'] if not st['grad'] else st['grad'][0], st['stroke'], 2 if st['stroke'] else 1, name='step dot', grad=st['grad'])
        cv.text(mx - d / 2, y + d / 2 - 13 * k, d, [str(i + 1)], round(24 * k), st['head'] if theme != 'ulta' else 'FFFFFF', 'display', 'center', 1.08, name='step number')
        yy = y + d + 14 * k
        yy += cv.text(x + i * colw + 10 * k, yy, colw - 20 * k, tls, tfs, INK, 'bold', 'center', 1.2, name='step title', src=it['title'])
        if xls: cv.text(x + i * colw + 10 * k, yy + 8 * k, colw - 20 * k, xls, xfs, MUTED, 'body', 'center', 1.32, name='step text', src=it['text'])
    return d + 14 * k + hmax


def draw_timeline(cv, b, x, y, w, k, theme, ci):
    its = b['items']; n = len(its); colw = w / n; wh = 26 * k; ly = y + wh + 12 * k; c0 = PALETTE[ci % 5]
    cv.line(x, ly, x + w, ly, tint(c0, 0.5), 4 * k, name='timeline line'); hmax = 0; tex = []
    for it in its:
        tfs, tls = fit(it.get('title', ''), colw - 16 * k, 44 * k, round(16 * k), round(12 * k), 'bold', 1.2, 2)
        xfs, xls = fit(it.get('text', ''), colw - 16 * k, 100 * k, round(13.5 * k), round(11 * k), 'body', 1.32, 5) if it.get('text') else (0, [])
        tex.append((tfs, tls, xfs, xls)); hmax = max(hmax, len(tls) * tfs * 1.2 + (6 * k + len(xls) * xfs * 1.32 if xls else 0))
    for i, (it, (tfs, tls, xfs, xls)) in enumerate(zip(its, tex)):
        c = PALETTE[(ci + i) % 5]; st = style(theme, c); cx = x + i * colw + 8 * k
        wfs, wls = fit(it.get('when', ''), colw - 16 * k, wh, round(17 * k), round(11 * k), 'bold', 1.1, 1)
        cv.text(cx, y, colw - 16 * k, wls, wfs, c if theme not in ('charcoal',) else INK, 'bold', lh=1.1, name='timeline when', src=it.get('when', ''))
        cv.ellipse(cx, ly - 9 * k, 18 * k, 18 * k, st['fill'] if not st['grad'] else st['grad'][0], 'FFFFFF', 3, name='timeline dot', grad=st['grad'])
        yy = ly + 22 * k
        yy += cv.text(cx, yy, colw - 16 * k, tls, tfs, INK, 'bold', lh=1.2, name='timeline title', src=it.get('title', ''))
        if xls: cv.text(cx, yy + 6 * k, colw - 16 * k, xls, xfs, MUTED, 'body', lh=1.32, name='timeline text', src=it['text'])
    return wh + 12 * k + 22 * k + hmax


def draw_compare(cv, b, x, y, w, k, theme, ci):
    gap = 70 * k; cw = (w - gap) / 2; pad = 20 * k; hh = 46 * k
    sides = [(b['left'], style('charcoal', INK) if theme in ('ulta', 'sunset', 'velvet', 'charcoal') else style('paper', '404040')), (b['right'], style(theme, PALETTE[ci % 5]))]
    lays = []; fs = max(15 * k, MIN_FS[0]); tfs = max(round(17 * k), MIN_FS[0])   # a template's floor applies here too
    for side, st in sides:
        rows = [wrap(t, cw - 2 * pad - 22 * k, fs, 'body') for t in side['items']]; lays.append(rows)
    ih = max(sum(len(r) * fs * 1.32 + 8 * k for r in rows) for rows in lays) if any(lays) else 0
    ch = hh + pad + ih + pad - 8 * k
    for j, ((side, st), rows) in enumerate(zip(sides, lays)):
        cx = x + j * (cw + gap)
        cv.rect(cx, y, cw, ch, 'FFFFFF' if theme != 'frost' else tint(PALETTE[ci % 5], 0.9), LINE, 16, 1.2, name='compare card')
        cv.rect(cx, y, cw, hh, st['fill'], st['stroke'], 16, 1.5 if st['stroke'] else 1, st['grad'], name='compare head')
        cv.text(cx + pad, y + hh / 2 - tfs * 0.6, cw - 2 * pad, [side['title']], tfs, st['head'] if st['fill'] != 'FFFFFF' else st['head'], 'bold', lh=1.2, name='compare title', src=side['title'])
        yy = y + hh + pad; mark = PALETTE[ci % 5] if j else '404040'
        for t, ls in zip(side['items'], rows):
            cv.ellipse(cx + pad, yy + 5 * k, 10 * k, 10 * k, mark, name='compare mark')
            yy += cv.text(cx + pad + 22 * k, yy, cw - 2 * pad - 22 * k, ls, fs, INK, 'body', lh=1.32, name='compare item', src=t) + 8 * k
    ax = x + cw + gap / 2; ay = y + ch / 2; c = PALETTE[ci % 5]
    cv.ellipse(ax - 22 * k, ay - 22 * k, 44 * k, 44 * k, c, 'FFFFFF', 3, name='compare arrow', grad=bgrad(c) if theme == 'ulta' else None)
    cv.text(ax - 22 * k, ay - 14 * k, 44 * k, ['→'], round(22 * k), 'FFFFFF', 'bold', 'center', 1.2, name='compare arrow text')
    return ch


def draw_bars(cv, b, x, y, w, k, theme, ci):
    its = b['items']; vals = [num(it['value']) or 0 for it in its]; mx = max(vals + [1e-9]); lw = w * 0.34; vw = 76 * k; bw = w - lw - vw - 12 * k; rh = 38 * k; c = PALETTE[ci % 5]
    st = style(theme, c)
    for i, (it, v) in enumerate(zip(its, vals)):
        yy = y + i * rh; lfs, lls = fit(it['label'], lw - 12 * k, rh - 6 * k, round(14.5 * k), round(11 * k), 'body', 1.15, 2)
        cv.text(x, yy + (rh - len(lls) * lfs * 1.15) / 2 - 2 * k, lw - 12 * k, lls, lfs, INK, 'body', lh=1.15, name='bar label', src=it['label'])
        cv.rect(x + lw, yy + rh / 2 - 10 * k, bw, 20 * k, tint(c, 0.88), None, 10 * k, name='bar track')
        fw = max(20 * k, bw * (v / mx)) if v > 0 else 0
        if fw: cv.rect(x + lw, yy + rh / 2 - 10 * k, fw, 20 * k, '404040' if theme == 'charcoal' else c, None, 10 * k, grad=st['grad'] if theme in ('sunset', 'velvet', 'ulta') else None, name='bar')
        val = str(it['value']).strip(); val = val if (b.get('unit') or '') in val else val + (b.get('unit') or '')
        cv.text(x + lw + bw + 12 * k, yy + rh / 2 - 10 * k, vw, [val], round(15 * k), shade(c, 0.1) if theme != 'charcoal' else INK, 'bold', lh=1.2, name='bar value', src=val)
    return len(its) * rh


def draw_donut(cv, b, x, y, w, k, theme, ci):
    its = b['items']; m = len(its); colw = w / m; r = min(colw * 0.3, 72 * k); sw = 16 * k; hmax = 0; labs = []
    for it in its:
        lfs, lls = fit(it['label'], colw - 20 * k, 80 * k, round(14.5 * k), round(11 * k), 'body', 1.3, 4); labs.append((lfs, lls)); hmax = max(hmax, len(lls) * lfs * 1.3)
    for i, (it, (lfs, lls)) in enumerate(zip(its, labs)):
        c = PALETTE[(ci + i) % 5]; st = style(theme, c); cx = x + i * colw + colw / 2; cy = y + r + sw / 2; v = num(it['value']) or 0
        cv.arc(cx, cy, r, sw, v / 100.0, st['fill'] if st['fill'] != 'FFFFFF' and not st['grad'] else c, tint(c, 0.86), name='ring')
        vs = str(it['value']).strip(); vs = vs if '%' in vs else vs + '%'
        vfs, vls = fit(vs, (r - sw / 2) * 1.35, r * 0.8, round(32 * k), round(14 * k), 'display', 1.05, 1)
        cv.text(cx - r * 0.75, cy - vfs * 0.55, r * 1.5, vls, vfs, INK, 'display', 'center', 1.05, name='ring value', src=vs)
        cv.text(x + i * colw + 10 * k, y + 2 * r + sw + 12 * k, colw - 20 * k, lls, lfs, MUTED, 'body', 'center', 1.3, name='ring label', src=it['label'])
    return 2 * r + sw + 12 * k + hmax


LIST_FALLBACK = ['idea', 'check', 'star', 'target', 'performance', 'award', 'lightbulb', 'flag']


def list_icon(it, used):
    """The item's icon: its own, else the best keyword match, else a generic one; never empty, never a repeat in the block."""
    p = it.get('icon') or pick_icon(it.get('title', '') + ' ' + it.get('text', ''))
    if not p or p in used or icon_svg(p) is None:
        p = next((x for x in LIST_FALLBACK + STAT_ICONS if x not in used and icon_svg(x) is not None), p or 'idea')
    used.add(p)
    return p


def draw_list(cv, b, x, y, w, k, theme, ci):
    its = b['items']; n = len(its); used = set()
    cols = 3 if (w >= 900 and n >= 3 and n != 4) else (2 if n >= 2 and w >= 440 else 1)
    g = 24 * k; cw = (w - g * (cols - 1)) / cols; isz = 50 * k; rows = math.ceil(n / cols); y0 = y
    for r_ in range(rows):
        row = its[r_ * cols:(r_ + 1) * cols]; hs = []
        for j, it in enumerate(row):
            i = r_ * cols + j; c = PALETTE[(ci + i) % 5]; st = style(theme, c); cx = x + j * (cw + g); tw = cw - isz - 14 * k
            f_, bold_, badge_ = _ic(b); filled = badge_ == 'filled' or (badge_ == 'auto' and theme in ('ulta', 'sunset', 'velvet', 'charcoal'))
            if filled:
                bf = st['grad'][0] if st['grad'] else (c if st['fill'] in ('FFFFFF', None) or theme in ('frost',) else st['fill'])
                cv.ellipse(cx, y, isz, isz, bf, name='list badge', grad=st['grad']); icol = 'FFFFFF'
            else:
                cv.ellipse(cx, y, isz, isz, tint(c, 0.86), st['stroke'] if theme == 'paper' else None, 1.5, name='list badge', grad=sgrad(c) if theme == 'ulta' else None); icol = st['icon'] if st['icon'] != 'FFFFFF' else shade(c, 0.15)
            fr = min(0.78, 0.6 * f_); off = isz * (1 - fr) / 2
            cv.icon(list_icon(it, used), cx + off, y + off, isz * fr, icol, bold=bold_)
            yy = y
            if it.get('title'):
                tfs, tls = fit(it['title'], tw, 48 * k, round(16.5 * k), round(12.5 * k), 'bold', 1.2, 2); yy += cv.text(cx + isz + 14 * k, yy + 2 * k, tw, tls, tfs, INK, 'bold', lh=1.2, name='list title', src=it['title']) + 6 * k
            if it.get('text'):
                xfs, xls = fit(it['text'], tw, 96 * k, round(14 * k), round(11 * k), 'body', 1.32, 5); yy += cv.text(cx + isz + 14 * k, yy + 2 * k, tw, xls, xfs, MUTED, 'body', lh=1.32, name='list text', src=it['text'])
            hs.append(max(isz, yy - y))
        y += max(hs) + 22 * k
    return y - y0 - 22 * k


def draw_quote(cv, b, x, y, w, k, theme, ci):
    c = PALETTE[ci % 5]; pad = 22 * k
    fs, ls = fit(b['text'], w - 2 * pad - 20 * k, 220 * k, round(25 * k), round(15 * k), 'display', 1.25, 6)
    cv.rect(x, y, 6 * k, 10, c, None, 3, grad=bgrad(c), gv=True, name='quote bar')
    cv.text(x + pad, y - 14 * k, 60 * k, ['“'], round(64 * k), c, 'display', lh=1.0, name='quote mark')
    h = 44 * k + cv.text(x + pad, y + 44 * k, w - 2 * pad, ls, fs, INK, 'display', lh=1.25, name='quote text', src=b['text'])
    if b.get('by'): h += 8 * k + cv.text(x + pad, y + h + 8 * k, w - 2 * pad, ['— ' + b['by']], round(14 * k), MUTED, 'body', lh=1.3, name='quote by', src='— ' + b['by'])
    for e in cv.els:
        if e.get('name') == 'quote bar' and e['h'] == 10: e['h'] = round(h, 1)
    return h


def draw_takeaway(cv, b, x, y, w, k, theme, ci):
    c = TITLE if theme in ('ulta', 'charcoal') else PALETTE[ci % 5]; st = style('ulta' if theme == 'charcoal' else theme, c); pad = 24 * k; isz = 42 * k * _ic(b)[0] if b.get('icon') else 0
    tw = w - 2 * pad - (isz + 18 * k if isz else 0)
    fs, ls = fit(b['text'], tw, 140 * k, round(21 * k), round(14 * k), 'bold', 1.3, 4)
    h = max(len(ls) * fs * 1.3, isz) + 2 * pad
    card(cv, x, y, w, h, st, 'takeaway')
    if isz: cv.icon(b['icon'], x + pad, y + (h - isz) / 2, isz, st['icon'], bold=_ic(b)[1])
    cv.text(x + pad + (isz + 18 * k if isz else 0), y + (h - len(ls) * fs * 1.3) / 2, tw, ls, fs, st['head'] if theme != 'ulta' else 'FFFFFF', 'bold', lh=1.3, name='takeaway text', src=b['text'])
    return h


DRAW = {'stats': draw_stats, 'steps': draw_steps, 'timeline': draw_timeline, 'compare': draw_compare, 'bars': draw_bars, 'donut': draw_donut, 'list': draw_list, 'quote': draw_quote, 'takeaway': draw_takeaway}


# ------------------------------------------------------------------------------------------------------------------ v6.9 weekly status report
# Three blocks for a project status one-pager: a status strip (overall RAG, week, lead), workstreams (RAG, owner, this week, next week)
# and risks & support required. RAG is always a colour AND a word (On track / At risk / Off track) — never colour alone.
RAG = {'green': ('2E8B57', 'On track'), 'amber': ('D99100', 'At risk'), 'red': ('C8102E', 'Off track'), '': ('9A8F88', 'Not set')}
RAG_WORDS = [('red', r'^\s*(r|red|off[ -]?track|blocked|critical|high|🔴)(?![a-z])'), ('amber', r'^\s*(a|amber|yellow|y|at[ -]?risk|watch|medium|med|🟠|🟡)(?![a-z])'),
             ('green', r'^\s*(g|green|on[ -]?track|ok|done|complete[d]?|low|🟢)(?![a-z])')]


def rag_of(v):
    s = str(v or '').strip().lower()
    for k, pat in RAG_WORDS:
        if re.match(pat, s): return k
    return ''


# ------------------------------------------------------------------------------------------------------------------ v6.9 status report — the bold Ulta look
# Ulta typography up front (Playfair Display Black section titles in Ulta orange), the brand gradient on table heads, the Studio's own
# icon set throughout: a badge per workstream picked from its name, column icons, icon tiles in the status strip, a warning badge per risk.
STATUS_ICONS = [(r'secur|firewall|access|auth|compliance', 'lock'), (r'integrat|interface|api|connect|delta share|pipeline', 'network'), (r'test|qa|quality|uat|validat', 'verified-badge'),
                (r'\bai\b|data science|model|ml\b|machine learning|forecast', 'idea'), (r'report|\bbi\b|kpi|dashboard|analytics', 'bar-chart'),
                (r'data|requirement|mapping|source', 'laptop-analytics'), (r'design|architect', 'puzzle'), (r'assort|range', 'shelf'), (r'alloc|replen', 'shuffle'),
                (r'store|site', 'stores'), (r'price|pricing|promo', 'tag'), (r'deliver|logist|supply|dc\b|warehouse', 'delivery'), (r'change|train|people|adoption', 'team'),
                (r'vendor|partner|infosys|databricks|o9|sap|accenture|deloitte', 'team-growth'), (r'risk|issue|block', 'warning'), (r'support|help|escalat', 'support'),
                (r'budget|cost|finance', 'wallet'), (r'launch|go[- ]live|cutover|release', 'target'), (r'customer|guest', 'customer-love'), (r'plan|program|project', 'milestones')]
STATUS_FALLBACK = ['performance', 'gears', 'insight', 'layers', 'puzzle', 'cube', 'growth-check', 'focus', 'sliders', 'network']


def status_icon(text, used=None):
    """An icon for a workstream, a risk or a fact, from its words (the Studio's icon set); a different one from those already used in the block."""
    used = used if used is not None else set(); s = str(text or '').lower()
    for pat, ic in STATUS_ICONS:
        if re.search(pat, s) and ic in ICONS and ic not in used: used.add(ic); return ic
    p = pick_icon(text)
    if p and p in ICONS and p not in used: used.add(p); return p
    ic = next((x for x in STATUS_FALLBACK if x in ICONS and x not in used), 'idea'); used.add(ic); return ic


FACT_ICON = {'overall status': 'performance', 'week ending': 'calendar', 'phase': 'milestones', 'project lead': 'person'}
FACT_ICONS = [(r'status|rag|health', 'performance'), (r'lead|owner|sponsor|manager|commander|decision owner', 'person'), (r'budget|cost|price|spend', 'wallet'),
              (r'week|period|date|start|end|go[- ]live|launch|steerco|updated|needed by|due|when', 'calendar'), (r'phase|stage|milestone', 'milestones'),
              (r'audience|for$|team|who', 'team'), (r'impact|severity|priority|risk', 'warning'), (r'duration|time|speed|frequency', 'speed'), (r'system|tool|platform', 'laptop-analytics'),
              (r'trigger|start when', 'pointer'), (r'topic|subject|area', 'idea'), (r'programme|program|project|product', 'layers')]


def fact_icon(label):
    """The status strip's icon for a fact, from its label (owner → person, dates → calendar, budget → wallet …)."""
    l = str(label or '').lower().strip()
    if l in FACT_ICON: return FACT_ICON[l]
    return next((ic for pat, ic in FACT_ICONS if re.search(pat, l) and ic in ICONS), None) or status_icon(label)


def status_title(cv, b, x, y, w, k, accent, icon=None):
    """A status-report section title: Ulta orange Playfair Display Black, with a round brand badge holding the section's icon."""
    if not b.get('title'): return 0
    d = 38 * k; cv.ellipse(x, y, d, d, tint(TITLE, 0.86), None, name='section badge', grad=sgrad(TITLE, 0.84))   # calm: a tinted disc, the icon in Ulta orange
    cv.icon(icon or status_icon(b['title']), x + d * 0.22, y + d * 0.22, d * 0.56, 'E0531B', bold=True)
    fs, ls = fit(b['title'], w - d - 18 * k, 64 * k, round(29 * k), round(21 * k), 'display', 1.05, 2)
    th = len(ls) * fs * 1.05; cv.text(x + d + 14 * k, y + max(0, (d - th) / 2) - 2 * k, w - d - 18 * k, ls, fs, TITLE, 'display', lh=1.05, name='block title', src=b['title'])
    return max(d, th) + 12 * k


def _rag_pill(cv, x, y, w, h, rag, k, word=True):
    """A RAG pill: solid in the RAG colour, the word in white (dark ink on amber, for contrast), a white dot. Returns its width."""
    c, label = RAG.get(rag, RAG['']); ink = shade(c, 0.3); fs = round(max(_fl(), 15 * k))   # calm: a light tint, a dot and the word in the RAG colour
    pw = min(w, (len(label) * fs * CW['bold'] + 44 * k) if word else h)
    cv.rect(x, y, pw, h, tint(c, 0.84), None, h / 2, name='rag pill')
    cv.ellipse(x + 11 * k, y + h / 2 - 6 * k, 12 * k, 12 * k, c, None, name='rag dot')
    if word: cv.text(x + 30 * k, y + (h - fs * 1.15) / 2, pw - 34 * k, [label], fs, ink, 'bold', lh=1.15, name='rag word', src=label)
    return pw


def _head_style(theme, acc):
    """The table head: a deep brand gradient with white words and icons — Ulta orange running into pink on the Ulta theme (v6.14: darker,
    asked for under the Workstreams title; before, a light peach band with orange words)."""
    if theme in ('ulta', 'sunset', 'glow', 'paper', 'frost'): return 'E0531B', ('E0531B', 'DB0058'), 'FFFFFF'
    return shade(acc, 0.05), (shade(acc, 0.05), shade(acc, 0.32)), 'FFFFFF'


def _word_fit(fracs, heads, rows, w, k, pad, fs, hfs, skip, badge, icons, check=False):
    """v6.14: no word is broken in a table. Each column gets at least its longest word (cells and heading); the width comes from the
    columns with room to spare. When even that cannot fit, the widths stay as asked."""
    def need(j):
        if j in skip:   # a status / severity column: its pill keeps the width asked for, and its heading must fit whole too (v6.15: "STAT US")
            return max(fracs[j] * w, max([len(x_) for x_ in str(heads[j] or '').split()] + [1]) * hfs * 1.08 * CW['bold'] * 1.1 + (24 * k if icons[j] else 0) + 6 * k + 2 * pad + 4)
        cw = [max([len(x_) for x_ in str(r[j] if j < len(r) else '').split()] + [1]) * (fs + (1.5 if j == 0 else 0)) * CW['bold' if j == 0 else 'body'] for r in rows]
        hw = max([len(x_) for x_ in str(heads[j] or '').split()] + [1]) * hfs * 1.08 * CW['bold'] * 1.1 + (24 * k if icons[j] else 0) + 6 * k   # caps run wide; a little air before the next icon
        return max(cw + [hw]) + 2 * pad + 4 + (badge if j == 0 else 0)
    ws = [f * w for f in fracs]; nd = [need(j) for j in range(len(ws))]
    if sum(nd) > w: return None if check else fracs
    short = sum(max(0, n_ - v) for n_, v in zip(nd, ws))
    if short <= 0: return fracs
    spare = [max(0, v - n_) for n_, v in zip(nd, ws)]; tot = sum(spare)
    ws = [max(n_, v) if v < n_ else v - short * s_ / tot for n_, v, s_ in zip(nd, ws, spare)]
    return [v / w for v in ws]


def _table(cv, x, y, w, k, theme, ci, heads, fracs, rows, rag_col=None, bar_col=None, name='status', head_icons=None, row_icons=None, fs_max=None):
    """The status table: a brand-gradient head with column icons, rows with an icon badge before the first cell, text wrapped to fit
    (never cut); a RAG column draws a solid pill, a severity column colours the row's badge and left edge. Returns the height."""
    acc = PALETTE[ci % 5]; pad = 10 * k; hfs = round(max(_fl(), 13.5 * k)); fs = round(max(_fl() + 0.5, 15.5 * k)); lh = 1.25; bd = 34 * k
    hfill, hgrad, hink = _head_style(theme, acc)
    wf_ = lambda f_, h_, chk: _word_fit(fracs, heads, rows, w, k, pad, f_, h_, (rag_col, bar_col), bd + 12 * k if row_icons else 0, [bool(i_) for i_ in (head_icons or [None] * len(heads))], check=chk)
    if fs_max: fs = min(fs, fs_max)
    while fs > _fl() + 0.5 and wf_(fs, hfs, True) is None: fs -= 1; hfs = min(hfs, fs - 1)   # v6.14: the type steps down (never under the floor) before a word breaks
    fracs = wf_(fs, hfs, False)
    xs = [x]; [xs.append(xs[-1] + f * w) for f in fracs]
    hls = []   # v6.13: a long heading wraps (two lines) instead of running into the next column
    for j, h_ in enumerate(heads):
        ix = xs[j] + pad + (24 * k if (head_icons or [None] * len(heads))[j] else 0); hls.append(wrap(h_.upper(), max(10, xs[j + 1] - ix - pad - 4), hfs * 1.08, 'bold')[:2] if h_ else [])
    hh = max([len(l_) for l_ in hls] + [1]) * hfs * 1.2 + 2 * pad + 2 * k
    cv.rect(x, y, w, hh, hfill, None, 12 * k, grad=hgrad, name=name + ' head')
    for j, h_ in enumerate(heads):
        if not h_: continue
        ix = xs[j] + pad; hi = (head_icons or [None] * len(heads))[j]
        if hi: cv.icon(hi, ix, y + (hh - 18 * k) / 2, 18 * k, hink, bold=True); ix += 24 * k
        cw = xs[j + 1] - ix - pad; cv.text(ix, y + (hh - len(hls[j]) * hfs * 1.2) / 2, cw, hls[j], hfs, hink, 'bold', lh=1.2, name=name + ' heading', src=h_, spacing=1)
    yy = y + hh + 6 * k
    for i, r in enumerate(rows):
        cells = []
        for j, v in enumerate(r):
            if j in (rag_col, bar_col): cells.append(None); continue
            cw = xs[j + 1] - xs[j] - 2 * pad - (bd + 12 * k if j == 0 and row_icons else 0); f_ = fs + (1.5 if j == 0 else 0)
            cells.append((wrap(v or '—', cw, f_, 'bold' if j == 0 else 'body'), f_))
        rh = max([len(c[0]) * c[1] * lh for c in cells if c] + [bd]) + 2 * pad
        sev = RAG.get(rag_of(r[bar_col]), RAG[''])[0] if bar_col is not None else None
        cv.rect(x, yy, w, rh, 'FFFFFF', LINE, 12 * k, 1.2, name=name + ' row')
        if sev: cv.rect(x, yy, 7 * k, rh, sev, None, 3 * k, grad=bgrad(sev), gv=True, name=name + ' severity')
        for j, c in enumerate(cells):
            if j == rag_col: _rag_pill(cv, xs[j] + pad, yy + (rh - 32 * k) / 2, xs[j + 1] - xs[j] - 2 * pad, 32 * k, rag_of(r[j]), k); continue
            if c is None: continue
            ls, f_ = c; v = r[j] or '—'; tx = xs[j] + pad + (6 * k if sev and j == 0 else 0)
            if j == 0 and row_icons:
                bc = sev or PALETTE[(ci + i) % 5]; cv.ellipse(tx, yy + (rh - bd) / 2, bd, bd, tint(bc, 0.85), None, name=name + ' badge', grad=sgrad(bc, 0.84))
                cv.icon(row_icons[i], tx + bd * 0.2, yy + (rh - bd) / 2 + bd * 0.2, bd * 0.6, shade(bc, 0.15), bold=True); tx += bd + 12 * k
            th = len(ls) * f_ * lh
            cv.text(tx, yy + (rh - th) / 2, xs[j + 1] - tx - pad, ls, f_, INK if v != '—' else MUTED, 'bold' if j == 0 else 'body', lh=lh, name=name + ' cell', src=v)
        yy += rh + 5 * k
    return yy - y - 5 * k


def draw_status(cv, b, x, y, w, k, theme, ci):
    """The status strip: one solid tile per fact — the overall status filled in its RAG colour — with a white icon, the label in small
    caps and the value in Playfair Display."""
    its = b['items']; n = len(its); g = 14 * k; cw = (w - g * (n - 1)) / n; pad = 16 * k; ic = 36 * k; tw = cw - 2 * pad - ic - 20 * k; parts = []
    for i, it in enumerate(its):
        r = rag_of(it.get('rag')) if it.get('rag') else ''
        val = RAG[r][1] if r else it.get('value', '')
        vfs, vls = fit(val, tw, 96 * k, round(28 * k), round(15 * k), 'display', 1.05, 3); parts.append((r, val, vfs, vls))   # never cut: up to three lines
    h = max(pad * 2 + max(ic, 18 * k + 6 * k + len(p[3]) * p[2] * 1.05) for p in parts)
    for i, (it, (r, val, vfs, vls)) in enumerate(zip(its, parts)):
        cx = x + i * (cw + g); lab = str(it.get('label', ''))
        c = RAG[r][0] if r else PALETTE[(ci + i) % 5]; ink = shade(c, 0.25)   # calm: a white tile, a tinted icon disc, the value in the colour's deep shade
        cv.rect(cx, y, cw, h, 'FFFFFF', LINE, 16 * k, 1.2, name='status tile'); cv.rect(cx, y + 14 * k, 5 * k, h - 28 * k, c, None, 2.5 * k, grad=bgrad(c), gv=True, name='status accent')
        cv.ellipse(cx + pad, y + (h - ic) / 2 - 4 * k, ic + 8 * k, ic + 8 * k, tint(c, 0.85), None, name='status icon disc', grad=sgrad(c, 0.84))
        cv.icon(fact_icon(lab), cx + pad + 4 * k + ic * 0.12, y + (h - ic) / 2 + ic * 0.12, ic * 0.76, ink, bold=True); tx = cx + pad + ic + 20 * k
        bh = 18 * k + 6 * k + len(vls) * vfs * 1.05; ty = y + (h - bh) / 2
        cv.text(tx, ty, tw, wrap(lab.upper(), tw, round(max(_fl(), 13 * k)), 'bold')[:1], round(max(_fl(), 13 * k)), MUTED, 'bold', lh=1.2, name='status label', src=lab, spacing=1)
        cv.text(tx, ty + 24 * k, tw, vls, vfs, ink, 'display', lh=1.05, name='status value', src=val)
    return h


def draw_rag(cv, b, x, y, w, k, theme, ci):
    """The workstream table. Workstream, owner, this week and next week always; Product support, Status, Risks/issues, Support required
    and Due date when any row fills them (v6.14: a team's table without a status column, or with a due date, draws as written)."""
    c0, c1 = (b.get('cols') or ['This week', 'Next week'])[:2]; used = set(); its = b['items']
    filled = lambda f: any(str(it.get(f) or '').strip() not in ('', '—', '-') for it in its)
    H = {'name': ('Workstream', 0.18, 'layers'), 'owner': ('Owner', 0.12, 'person'), 'support': ('Product support', 0.11, 'team'), 'rag': ('Status', 0.11, 'performance'),
         'now': (c0, 0.22, 'calendar'), 'next': (c1, 0.22, 'trend-up'), 'risk': ('Risks / issues', 0.17, 'warning'), 'ask': ('Support required', 0.15, 'support'), 'due': ('Due date', 0.09, 'calendar')}
    keep = [f for f in H if f in ('name', 'now', 'next') or (f == 'owner' and (filled(f) or not filled('support'))) or (f != 'owner' and filled(f))]
    its = [dict(it) for it in its]; pad = 10 * k; fs = round(max(_fl() + 0.5, 15.5 * k)); hfs = round(max(_fl(), 13.5 * k))
    j_ = lambda *xs: ' · '.join(x_ for x_ in xs if x_ and str(x_).strip() not in ('—', '-'))
    fmin = max(_fl() + 0.5, round(fs * 0.8))   # columns fold only when the type would have to shrink more than a fifth
    def fits(keep):
        rows_ = [[it.get(f, '') for f in keep] for it in its]; tot_ = sum(H[f][1] for f in keep)
        return _word_fit([H[f][1] / tot_ for f in keep], [H[f][0] for f in keep], rows_, w, k, pad, fmin, min(hfs, fmin - 1), (keep.index('rag') if 'rag' in keep else -1, -1), 46 * k, [True] * len(keep), check=True) is not None
    if not fits(keep) and 'support' in keep:   # a narrow page: product support goes under the owner
        for it in its: it['owner'] = j_(it.get('owner'), (it['support'] + ' (product)') if it.get('support') else '')
        keep = [f for f in keep if f != 'support']; keep = keep if 'owner' in keep else keep[:1] + ['owner'] + keep[1:]
    if not fits(keep) and 'risk' in keep and 'ask' in keep:   # … risks and asks share a column
        for it in its: it['risk'] = j_(it.get('risk'), ('Needs: ' + it['ask']) if it.get('ask') and it['ask'] not in ('—', '-') else '')
        keep = [f for f in keep if f != 'ask']; H['risk'] = ('Risks & support', 0.2, 'warning')
    if not fits(keep) and 'due' in keep:   # … and the due date joins next week
        for it in its: it['next'] = j_(it.get('next'), ('Due ' + it['due']) if it.get('due') else '')
        keep = [f for f in keep if f != 'due']
    tot = sum(H[f][1] for f in keep); rows = [[it.get(f, '') for f in keep] for it in its]
    icons = [status_icon(it.get('name', ''), used) for it in its]
    return _table(cv, x, y, w, k, theme, ci, [H[f][0] for f in keep], [H[f][1] / tot for f in keep], rows, rag_col=keep.index('rag') if 'rag' in keep else None, name='workstream',
                  head_icons=[H[f][2] for f in keep], row_icons=icons)


def draw_risks(cv, b, x, y, w, k, theme, ci):
    its = b['items']; keep = [f for f in ('title', 'text', 'owner', 'due') if f in ('title',) or any(str(it.get(f) or '').strip() not in ('', '—', '-') for it in its)]   # v6.13: empty columns go
    H = {'title': ('Risk or ask', 0.42, 'warning'), 'text': ('Support needed from', 0.25, 'support'), 'owner': ('Owner', 0.17, 'person'), 'due': ('Need by', 0.16, 'calendar')}
    tot = sum(H[f][1] for f in keep); rows = [[it.get(f, '') for f in keep] + [it.get('rag', '')] for it in its]
    return _table(cv, x, y, w, k, theme, ci + 1, [H[f][0] for f in keep] + [''], [H[f][1] / tot for f in keep] + [0.0], rows, bar_col=len(keep), name='risk',
                  head_icons=[H[f][2] for f in keep] + [None], row_icons=['warning'] * len(rows))


DRAW.update({'status': draw_status, 'rag': draw_rag, 'risks': draw_risks})


# the content template: what the team fills in (Word or Markdown); status_spec reads it without AI
STATUS_TEMPLATE_MD = """# Demand Planning — Weekly Status
Week ending: 10/09
Overall status: Green
Project lead: Anand
Phase: Build

## Workstreams
| Workstream | Owner | Status | This week (10/09) | Next week (10/16) | Due date |
|---|---|---|---|---|---|
| Data Requirements | Pranav / Layna | Green | Paper model for inventory & promo data via Ulta Medallion | Data mapping for Item, Loc, Time, Sales, Listing | 10/16 |
| Integration Design | Anand / Anthony | Amber | — | Historical data load KDD & architecture review | 10/14 |
| Testing | Brian / Surekha / Mithun | Green | — | Testing strategy & framework deliverable | 10/23 |
| AI / Data Science | Berg / Anthony | Green | Definition of Done for DP Data Science inputs (draft) | Definition of Done (final) · meeting cadence & agenda | 10/16 |
| Reporting & BI | Lokesh | Green | — | DP reports inventory & new KPI | 10/30 |

## Risks & support required
| Risk or ask | Support needed from | Owner | Need by | Severity |
|---|---|---|---|---|
| Validate 3-year historical data availability & confirm implementation timelines | Databricks & Infosys | Anand | 10/16 | Amber |
| Confirm firewall rules & Delta Share connectivity before data load | Ulta Security & o9 | Anthony | 10/14 | Red |

## Milestones
- 10/09: Paper model for inventory & promo data
- 10/16: Historical data load KDD & architecture review
- 10/23: Testing strategy & framework signed off
- 10/30: Data mapping complete

## Decision needed
Approve Delta Share as the connection for the historical data load by 10/14.
"""

STATUS_KEYS = {'week': r'^(week ending|week of|week|period|reporting period|as of|date)$', 'overall': r'^(overall( status)?|status|overall rag|rag)$',
               'lead': r'^(project lead|lead|owner|pm|project manager|sponsor)$', 'phase': r'^(phase|stage)$', 'project': r'^(project|programme|program)$'}
COLS_RAG = {'name': r'workstream|stream|area|team|track|work ?package', 'support': r'product support|business support|functional support|support lead|\bsmes?\b',
            'owner': r'owner|lead|who|responsible', 'rag': r'status|rag|health',
            'now': r'this week|current|done|completed|progress|now', 'next': r'next week|next|planned|upcoming|coming',
            'risk': r'risks?|issues?|blockers?', 'ask': r'support (required|needed)|help needed|\basks?\b|escalat', 'due': r'due|deadline|target date|by when|need by|eta'}   # v6.14: the team's own columns
RAG_EXTRA = ('support', 'risk', 'ask', 'due')   # v6.14: Product support, Risks/issues, Support required, Due date — drawn when filled


def rag_row(r, cm):
    """One workstream row from a table row and its column map: every field, "—" and n/a read as empty."""
    g = lambda f: (r[cm[f]] if cm.get(f) is not None and cm[f] < len(r) else '').strip()
    o = {f: g(f) for f in ('name', 'owner', 'rag', 'now', 'next') + RAG_EXTRA}; o['owner'] = o['owner'].rstrip(' /')
    for f in RAG_EXTRA:
        if re.fullmatch(r'[\s—–\-.]*|n/?a|none|tbd', o[f], re.I): o[f] = ''
    return o


def is_rag_head(head):
    """A header row of a workstream table: a workstream column and a status, this-week or next-week column."""
    j = ' '.join(head or [])
    return bool(re.search(COLS_RAG['name'], j, re.I) and (re.search(COLS_RAG['rag'], j, re.I) or re.search(COLS_RAG['now'], j, re.I) or re.search(COLS_RAG['next'], j, re.I)))
COLS_RISK = {'title': r'risk|issue|ask|item|blocker|dependency', 'text': r'support|from|need(ed)? from|help|who can', 'owner': r'owner|raised|lead',
             'due': r'need by|due|by when|date|deadline', 'rag': r'severity|rag|impact|priority|status'}


def _detab(text):
    """A table copied out of Word arrives as tab-separated lines: turn them into | rows so the reader sees a table."""
    out = []
    for l in str(text or '').replace('\r', '').split('\n'):
        out.append('| ' + ' | '.join(c.strip() for c in l.split('\t')) + ' |' if l.count('\t') >= 1 and not l.lstrip().startswith(('#', '-', '*', '|')) else l)
    t_ = _unflatten('\n'.join(out)); first = next((l for l in t_.split('\n') if l.strip()), '')
    if first.lstrip().startswith('|') and is_rag_head([c.strip() for c in first.strip().strip('|').split('|')]): t_ = '## Workstreams\n' + t_   # v6.14: a pasted table on the first line is not the title
    return t_


def _unflatten(text):
    """v6.14: a workstream table copied as plain text from Confluence or Word arrives one cell a line (a blank line between cells).
    The header is the run of lines that each name a workstream-table column (Workstream, Owner, …, Due date); the cells after it fill
    rows of that width (an extra blank run is an empty cell; a short last row is padded). Text with a | table is left alone."""
    if re.search(r'^\s*\|.*\|\s*$', text, re.M): return text
    L = text.split('\n'); i = 0
    while i < len(L):
        s = L[i].strip()
        if not (s and re.fullmatch(r'(?i)\W*(' + COLS_RAG['name'] + r')s?\W*', s)): i += 1; continue
        head, taken, j, gaps = [], set(), i, []
        while j < len(L):
            s2 = L[j].strip()
            if not s2: j += 1; continue
            f_ = next((f for f, p in COLS_RAG.items() if f not in taken and len(s2) <= 60 and re.search(p, s2, re.I)), None)
            if f_ is None or (head and f_ == 'name'): break
            if head: gaps.append(j - last - 1)
            head.append(s2); taken.add(f_); last = j; j += 1
        if len(head) < 3 or not ({'now', 'next', 'rag'} & taken): i += 1; continue
        sep = 1 if gaps and min(gaps) >= 1 else 0   # blank lines between cells
        cells, k, prev = [], j, last
        while k < len(L) and not L[k].lstrip().startswith('#'):
            s3 = L[k].strip()
            if s3:
                blanks = k - prev - 1; cells += [''] * max(0, (blanks - sep) // (sep + 1) if cells else 0); cells.append(s3); prev = k
            k += 1
        if not cells: return text
        n = len(head); rows = [cells[r:r + n] + [''] * (n - len(cells[r:r + n])) for r in range(0, len(cells), n)]
        md = ['| ' + ' | '.join(head) + ' |', '|' + '---|' * n] + ['| ' + ' | '.join(c.replace('|', '/') for c in r) + ' |' for r in rows]
        return '\n'.join(L[:i] + md + [''] + L[k:])
    return text


def _map_cols(head, spec):
    """Column index per field, matched on the header words; a field with no column gets None."""
    used = set(); out = {}
    for f, pat in spec.items():
        j = next((i for i, h in enumerate(head) if i not in used and re.search(pat, h or '', re.I)), None)
        out[f] = j
        if j is not None: used.add(j)
    return out


def _week_label(h, default):
    m = re.search(r'\(([^)]+)\)', h or ''); return (default + ' (' + m.group(1) + ')') if m else (h.strip() if h and h.strip() and len(h.strip()) <= 26 else default)   # v6.14: a long heading → This week / Next week


FALLBACK = [None]   # v6.15: templates.py sets the shape reader (a form section by its Block: hint) — info.py cannot import it


def status_spec(text, fmt='slide', theme='ulta', title=''):
    """The weekly status content template → a status-report infographic, by rules (no AI). Lines "Key: value" before the first section
    fill the status strip; a Workstreams table (or bullets "Name — owner — status — this week — next week") the workstream block; a Risks
    table the risks block; dated bullets the milestones; other sections a list or the closing takeaway."""
    text = _detab(text); lines = text.split('\n'); facts = {}; kept = []; seen_h2 = False
    for l in lines:
        s = l.strip()
        if s.startswith('## '): seen_h2 = True
        m = re.match(r'^([A-Za-z][A-Za-z /&]{1,28}):\s*(.*)$', s)
        if not seen_h2 and m and not s.startswith('|'):
            if re.fullmatch(r'[\s—–\-.]*|n/?a|none', m.group(2).strip(), re.I): continue   # v6.13: an empty fact draws nothing
            key = next((k for k, pat in STATUS_KEYS.items() if re.match(pat, m.group(1).strip(), re.I)), None)
            if key and key not in facts: facts[key] = clean(m.group(2), 60); continue
        kept.append(l)
    t0, subtitle, source, secs = _sections('\n'.join(kept))
    blocks = []; strip = []
    if facts.get('overall'): strip.append({'label': 'Overall status', 'value': facts['overall'], 'rag': facts['overall']})
    if facts.get('week'): strip.append({'label': 'Week ending', 'value': facts['week']})
    if facts.get('phase'): strip.append({'label': 'Phase', 'value': facts['phase']})
    if facts.get('lead'): strip.append({'label': 'Project lead', 'value': facts['lead']})
    if strip: blocks.append({'type': 'status', 'items': strip})
    for s in secs:
        h = s['title'] or ''; rows = s['rows']
        if re.search(r'how to (fill|use)|instructions|ignores this', h, re.I): continue   # the template's own guidance
        hk = s.get('hint') or ''
        if hk in ('rag', 'ragcards') or (not hk and (re.search(r'work ?stream|status by|teams?|tracks?|areas?', h, re.I) or (rows and is_rag_head(rows[0])))):
            items = []; cols = ['This week', 'Next week']
            if rows:
                head = rows[0]; cm = _map_cols(head, COLS_RAG)
                if cm['now'] is not None: cols[0] = _week_label(head[cm['now']], 'This week')
                if cm['next'] is not None: cols[1] = _week_label(head[cm['next']], 'Next week')
                for r in rows[1:]:
                    o_ = rag_row(r, cm)
                    if o_['name']: items.append(o_)
            else:
                for x in s['bullets']:
                    p = [q.strip() for q in re.split(r'\s+[—–|]\s+|\s+-\s+', x)]
                    if p and p[0]: items.append({'name': p[0], 'owner': p[1] if len(p) > 1 else '', 'rag': p[2] if len(p) > 2 else '', 'now': p[3] if len(p) > 3 else '', 'next': p[4] if len(p) > 4 else ''})
            if items: blocks.append({'type': 'rag', 'title': h if h and not re.fullmatch(r'work ?streams?', h, re.I) else 'Workstreams', 'cols': cols, 'items': items}); continue
        if hk == 'risks' or (not hk and re.search(r'risk|issue|support|blocker|depend|escalat', h, re.I)):
            items = []
            if rows:
                head = rows[0]; cm = _map_cols(head, COLS_RISK)
                for r in rows[1:]:
                    g = lambda f: (r[cm[f]] if cm[f] is not None and cm[f] < len(r) else '').strip()
                    if g('title') or g('text'): items.append({'title': g('title') or g('text'), 'text': g('text') if g('title') else '', 'owner': g('owner'), 'due': g('due'), 'rag': g('rag')})
            else:
                for x in s['bullets']:
                    a, sep, b2 = x.partition(' — ') if ' — ' in x else x.partition(': ')
                    items.append({'title': b2 if sep else x, 'text': a if sep else '', 'owner': '', 'due': '', 'rag': ''})
            if items: blocks.append({'type': 'risks', 'title': h or 'Risks & support required', 'items': items}); continue
        if hk and hk not in ('timeline', 'takeaway', 'list') and FALLBACK[0]:   # v6.15: a section added in the form (numbers, steps, a table …) draws as its block
            b_ = FALLBACK[0](s, h)
            if b_: blocks.append(b_); continue
        if rows and len(rows) > 1 and (hk == 'timeline' or re.search(r'milestone|timeline|dates|roadmap|upcoming|plan', h, re.I)):   # v6.13: a milestones table
            cm = _map_cols(rows[0], {'when': r'date|when|due|by|target', 'title': r'milestone|what|item|event|deliverable'}); items = []
            for r in rows[1:8]:
                w_ = (r[cm['when']] if cm['when'] is not None and cm['when'] < len(r) else '').strip(); t_ = (r[cm['title']] if cm['title'] is not None and cm['title'] < len(r) else r[0]).strip()
                if w_ or t_: items.append({'when': clean(w_, 18), 'title': clean(t_, 60)})
            if len(items) >= 2: blocks.append({'type': 'timeline', 'title': h, 'items': items}); continue
        if s['bullets'] and (hk == 'timeline' or (not hk and re.search(r'milestone|timeline|dates|roadmap|upcoming|plan', h, re.I))):
            items = []
            for x in s['bullets'][:7]:
                m = re.match(r'^([^:—–]{1,18}?)\s*[:—–]\s*(.+)$', x)
                items.append({'when': m.group(1).strip(), 'title': clean(m.group(2), 60)} if m else {'when': '', 'title': clean(x, 60)})
            blocks.append({'type': 'timeline', 'title': h, 'items': items}); continue
        if s['paras'] and not s['bullets'] and not rows:
            blocks.append({'type': 'takeaway', 'title': '' if re.search(r'decision|ask|summary|bottom line', h, re.I) else h, 'text': (h + ': ' if re.search(r'decision|ask', h, re.I) else '') + ' '.join(s['paras'])[:200], 'icon': 'target'}); continue
        if s['bullets']:
            blocks.append({'type': 'list', 'title': h, 'items': [{'title': clean(x, 50) if len(x) <= 50 else clean(' '.join(x.split()[:5]), 50), 'text': '' if len(x) <= 50 else clean(' '.join(x.split()[5:]), 140), 'icon': pick_icon(x)} for x in s['bullets'][:6]]})
    sub = subtitle or ' · '.join(x for x in (facts.get('project'), ('Week ending ' + facts['week']) if facts.get('week') else '') if x)
    return normalise({'title': title or t0 or 'Weekly status', 'kicker': 'Weekly status report', 'subtitle': sub if not strip else subtitle, 'source': source,
                      'format': fmt, 'theme': theme, 'template': 'status', 'blocks': blocks})


def sample_status_spec(fmt='slide', theme='ulta'):
    return status_spec(STATUS_TEMPLATE_MD, fmt, theme)


TEMPLATES = [{'id': 'free', 'name': 'Free-form', 'blurb': 'Your content picks the blocks: numbers, steps, dates, a takeaway'},
             {'id': 'status', 'name': 'Weekly status report', 'blurb': 'Overall status, workstreams with RAG, risks & support required, milestones — from the status content template'}]


def rows_of(blocks, width):
    """Wide blocks take a row; two narrow ones (bars, rings, quote) share one when there is room."""
    rows = []; i = 0
    while i < len(blocks):
        b = blocks[i]
        pairable = lambda x: x['type'] in HALF   # v6.13 squeezed onto one 16:9 slide: these share a row side by side
        if b['type'] not in WIDE and i + 1 < len(blocks) and blocks[i + 1]['type'] not in WIDE and width >= 880: rows.append([b, blocks[i + 1]]); i += 2
        elif SQUEEZE[0] and width >= 1200 and pairable(b) and i + 1 < len(blocks) and pairable(blocks[i + 1]): rows.append([b, blocks[i + 1]]); i += 2
        else: rows.append([b]); i += 1
    return rows


SECTION_ICON = {'rag': 'team', 'risks': 'warning', 'timeline': 'milestones', 'list': 'idea', 'steps': 'list', 'stats': 'bar-chart'}


def _btitle(cv, b, x, y, w, k, accent):
    """A block's title: the status report's Ulta section title (Playfair, Ulta orange, icon badge), else the standard one."""
    if b.get('_tpl') not in (None, '', 'free'): return status_title(cv, b, x, y, w, k, accent, SECTION_ICON.get(b['type']) if b['type'] in ('rag', 'risks') else None)   # every template: Ulta section titles, an icon from the heading
    return block_title(cv, b, x, y, w, k, accent)


def draw_row(cv, row, x, y, w, k, theme, ci0):
    if len(row) == 1:
        b = row[0]; ht = _btitle(cv, b, x, y, w, k, PALETTE[ci0 % 5]); return ht + DRAW[b['type']](cv, b, x, y + ht, w, k, theme, ci0)
    g = 44 * k; cw = (w - g) / 2; hs = []
    for j, b in enumerate(row):
        ht = _btitle(cv, b, x + j * (cw + g), y, cw, k, PALETTE[(ci0 + j) % 5]); hs.append(ht + DRAW[b['type']](cv, b, x + j * (cw + g), y + ht, cw, k, theme, ci0 + j))
    return max(hs)


def header(cv, spec, fmt, k):
    """The one-pager / square header: gradient rule, kicker, the title in Playfair Display Black, the subtitle. Returns the bottom."""
    F = FORMATS[fmt]; m = F['margin']; W = F['w']; y = m
    cv.rect(0, 0, W, 12, TITLE, None, 0, grad=('EE6C37', 'E8275A'), name='top rule', chrome=False)
    if spec.get('kicker'): y += cv.text(m, y, W - 2 * m, [spec['kicker']], 15, 'E0531B', 'bold', lh=1.2, name='kicker', src=spec['kicker'], spacing=2) + 10
    hi = 64 if fmt == 'onepager' else 58
    fs, ls = fit(spec['title'], W - 2 * m, hi * 2.3, hi, 34, 'display', 1.06, 3)
    if spec.get('template') not in (None, '', 'free'):
        f1, l1 = fit(spec['title'], W - 2 * m, hi * 1.1, hi, 42, 'display', 1.06, 1, report=False)   # a probe: kept only if one line
        if len(wrap(spec['title'], W - 2 * m, f1, 'display')) == 1: fs, ls = f1, l1
    y += cv.text(m, y, W - 2 * m, ls, fs, TITLE, 'display', lh=1.06, name='title', src=spec['title']) + 14
    if spec.get('subtitle'):
        sfs, sls = fit(spec['subtitle'], W - 2 * m, 90, 21, 15, 'body', 1.35, 3); y += cv.text(m, y, W - 2 * m, sls, sfs, MUTED, 'body', lh=1.35, name='subtitle', src=spec['subtitle'])
    return y + 34


def footer(cv, spec, fmt):
    F = FORMATS[fmt]; m = F['margin']; W, H = F['w'], F['h']; y = H - m + 6
    cv.line(m, y - 22, W - m, y - 22, LINE, 1.5, name='footer rule')
    if spec.get('source'):
        fs, ls = fit('Source: ' + spec['source'], W - 2 * m - 170, 36, 12.5, 10, 'body', 1.3, 2); cv.text(m, y - 8, W - 2 * m - 170, ls, fs, MUTED, 'body', lh=1.3, name='source', src='Source: ' + spec['source'])
    cv.els.append({'k': 'logo', 'x': W - m - 118, 'y': y - 10, 'w': 118, 'h': 47.7, 'name': 'logo'})
    return y - 22 - 24


def _relayout(spec, blocks, warn):
    s2 = dict(spec, blocks=[{k: v for k, v in b.items() if k not in ('_ic', '_tpl')} for b in blocks]); d = layout(s2); d['warnings'] = warn + d['warnings']; return d


def layout(spec):
    """(v6.9) A weekly status report on a 16:9 slide is two slides, as status decks are: status and workstreams, then "(cont.)" with
    risks, milestones and the decision — nothing dropped, both at full size. The design is page 1 with `pages` [page 2]; its spec keeps
    every block, so editing works on the whole report."""
    if isinstance(spec, dict) and spec.get('_page') is None:
        n_ = normalise(spec)
        if n_.get('template') not in (None, '', 'free') and n_['format'] == 'slide' and len(n_['blocks']) >= 2 and not _fits1(n_):
            SQUEEZE[0] = True   # v6.13: squeeze onto one slide first — sizes down to 62 %, text down to 8 pt (the PowerPoint's readability floor)
            try: d1 = _layout1(dict(n_, _page=1))
            finally: SQUEEZE[0] = False
            if not [w for w in d1['warnings'] if 'left out' in w]: return d1
            pages = _paginate(n_)   # still too much at 8 pt: continue on "(cont.)" slides, nothing left out   # v6.13: as many slides as the content needs — sections never dropped, a long one split across slides
            if len(pages) > 1 and len(pages[-1]) == 1 and pages[-1][0]['type'] == 'takeaway' and not n_.get('subtitle') and _fits1(dict(n_, blocks=pages[0], subtitle=pages[-1][0]['text'])):
                n_ = dict(n_, subtitle=pages.pop()[0]['text'])   # a lone closing decision: under the title of slide 1, not a slide of its own
            if len(pages) == 1: return _layout1(dict(n_, blocks=pages[0], _page=1)) | {'spec': n_}
            if len(pages) > 1:
                ds = [_layout1(dict(n_, blocks=pg, _page=i + 1, **({} if i == 0 else {'title': n_['title'] + ' (cont.)', 'subtitle': ''}))) for i, pg in enumerate(pages)]
                d1 = ds[0]; d1['spec'] = n_; d1['pages'] = ds[1:]; d1['warnings'] = [w for d_ in ds for w in d_['warnings']]; return d1
    return _layout1(spec)


SPLIT = {'ragcards', 'table', 'rag', 'risks', 'list', 'timeline', 'steps'}   # blocks whose items can continue on the next slide


def _paginate(spec, max_pages=6):
    """16:9 pages for a template: each slide takes sections while they fit at a readable size; a section too long for a slide on its own is
    split by its items ("Workstreams" then "Workstreams (cont.)"). Nothing is left out."""
    queue = [dict(b) for b in spec['blocks']]; pages = []
    while queue and len(pages) < max_pages:
        page = []
        while queue:
            if _fits1(dict(spec, blocks=page + [queue[0]], **({} if not pages else {'subtitle': ''}))): page.append(queue.pop(0)); continue
            if page: break
            b = queue[0]; its = b.get('items') or []
            if b['type'] in SPLIT and len(its) > 1:   # alone it does not fit: half its items now, the rest on the next slide
                h = (len(its) + 1) // 2; queue[0:1] = [dict(b, items=its[:h]), dict(b, items=its[h:], title=(b.get('title') + ' (cont.)') if b.get('title') else '')]; continue
            page.append(queue.pop(0)); break   # cannot split: it goes on its own slide at the smallest readable size
        pages.append(page)
    if queue: pages[-1] += queue
    return pages


def _fits1(spec):
    """A template on one slide at a readable size, nothing left out."""
    d_ = _layout1(dict(spec, _page=1)); return not [w for w in d_['warnings'] if 'left out' in w or 'dense' in w or 'under the title' in w]


def page_svgs(d, flat=False, chrome=True):
    """Every page's SVG: the design, then its continuation pages (a status report on a slide)."""
    return [to_svg(d, chrome=chrome, flat=flat)] + [to_svg(p, chrome=chrome, flat=flat) for p in d.get('pages') or []]


def _layout1(spec):
    """spec → design {spec, w, h, els, warnings}: the body is fitted by shrinking every size in steps (never below 62 %); a block that still
    does not fit is left out and named in the warnings."""
    spec = normalise(spec); fmt = spec['format']; F = FORMATS[fmt]; W, H = F['w'], F['h']; theme = spec['theme']; warn = []
    blocks = list(spec['blocks'])
    for b_ in blocks: b_['_ic'] = spec.get('icons') or {}; b_['_tpl'] = spec.get('template') or ''   # the icon options and the template reach every block's drawing (removed again below)
    if not blocks: blocks = [{'type': 'takeaway', 'text': spec.get('subtitle') or 'Add content: paste a page, a list of numbers, steps or points.'}]
    top = Canvas()
    if fmt == 'slide':
        tfs, tls = fit(spec['title'], 1400, 62, 60, 30, 'display', 0.95, 1)   # v6.12: one line, as on the template — down to 30 px before a second line
        if len(wrap(spec['title'], 1400, tfs, 'display')) > 1: tfs, tls = 40, wrap(spec['title'], 1400, 40, 'display')[:2]
        top.text(73, 53 if len(tls) == 1 else 40, 1400 if len(tls) == 1 else 1100, tls, tfs, TITLE, 'display', lh=0.95, name='title', src=spec['title'], chrome=True)
        top.els.append({'k': 'logo', 'x': 62, 'y': 806, 'w': 130, 'h': 52.6, 'name': 'logo', 'chrome': True})
        top.text(1135, 842, 400, ['Ulta Beauty | Proprietary & Confidential'], 11.5, INK, 'body', 'right', name='footer', chrome=True)
        bx, by, bw, bh = F['body']
        if spec.get('subtitle'):
            sfs, sls = fit(spec['subtitle'], bw, 56, 19, 14, 'body', 1.3, 2); by += top.text(bx, by - 6, bw, sls, sfs, MUTED, 'body', lh=1.3, name='subtitle', src=spec['subtitle']) + 14; bh = F['body'][3] - (by - F['body'][1])
    else:
        by = header(top, spec, fmt, 1); bottom = footer(top, spec, fmt); bx = F['margin']; bw = W - 2 * bx; bh = bottom - by
    tpl_ = spec.get('template') not in (None, '', 'free'); MIN_FS[0] = 14 if tpl_ else 0; body = None; kmin = (0.62 if SQUEEZE[0] else 0.8 if fmt == 'slide' else 0.66) if tpl_ else 0.62   # a template stays readable: on a slide 80 %, a page 70 %
    while blocks:
        rows = rows_of(blocks, bw)
        for k in [x for x in [1.45, 1.36, 1.28, 1.2, 1.12, 1.05, 1.0, 0.94, 0.88, 0.82, 0.8, 0.76, 0.7, 0.66, 0.62] if x >= kmin]:   # sparse content grows (to 145 %) before space is spread
            g = 34 * k; cv = Canvas(); hs = []
            for r in rows:
                t = Canvas(); hs.append(draw_row(t, r, 0, 0, bw, k, theme, sum(len(x) for x in rows[:rows.index(r)])))
            tot = sum(hs) + g * (len(rows) - 1)
            if tot <= bh: body = (rows, hs, k, g, tot); break
        if body: break
        drop = next((i for i in range(len(blocks) - 1, -1, -1) if blocks[i]['type'] in ('timeline', 'list', 'steps')), len(blocks) - 1) if tpl_ else len(blocks) - 1   # the decision stays; milestones go first
        if tpl_ and blocks[drop]['type'] == 'takeaway' and not spec.get('subtitle') and fmt == 'slide':   # the decision moves under the title rather than going
            spec['subtitle'] = blocks[drop]['text']; blocks.pop(drop); warn.append('the decision is shown under the title — the slide has no room for it as a block'); return _relayout(spec, blocks, warn)
        warn.append(f'"{blocks[drop].get("title") or blocks[drop]["type"]}" left out — it does not fit on the {F["name"].lower()}; the one-pager has room for it'); blocks.pop(drop)
    cv = Canvas(); cv.els = top.els
    if body:
        rows, hs, k, g, tot = body; extra = bh - tot; g2 = g + (min(extra / (len(rows) - 1), 46) if len(rows) > 1 else 0)
        y = by + max(0, (bh - (sum(hs) + g2 * (len(rows) - 1))) / 2)   # what is left is shared above and below
        for i, r in enumerate(rows):
            draw_row(cv, r, bx, y, bw, k, theme, sum(len(x) for x in rows[:i])); y += hs[i] + g2
        if k < 0.8: warn.append(f'the content is dense — sizes shrunk to {round(k * 100)} %; ' + ('a shorter section or one fewer gives larger text' if fmt == 'onepager' else 'the one-pager gives it more room'))
    spec['blocks'] = [b for b in spec['blocks'] if b in blocks] if blocks else spec['blocks']
    bg = 'FFFFFF' if fmt == 'slide' else 'F8F5F5'
    for b_ in spec['blocks']: b_.pop('_ic', None); b_.pop('_tpl', None)
    readable_icons(cv.els, bg); MIN_FS[0] = 0
    return {'spec': spec, 'w': W, 'h': H, 'bg': bg, 'els': cv.els, 'warnings': warn}


def _lum(h):
    try: r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    except Exception: return None   # noqa: BLE001
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def _contrast(a, b):
    la, lb = _lum(a), _lum(b)
    if la is None or lb is None: return 21.0
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)


def _under(els, i, px, py, bg):
    """The colour a point of element i sits on: the topmost filled rect / ellipse drawn before it that contains the point, else the page."""
    for e in reversed(els[:i]):
        if e.get('k') not in ('rect', 'ellipse') or not (e.get('fill') or e.get('grad')): continue
        x, y, w, h = e['x'], e['y'], e['w'], e['h']
        if e['k'] == 'rect': inside = x <= px <= x + w and y <= py <= y + h
        else: inside = w > 0 and h > 0 and ((px - x - w / 2) / (w / 2)) ** 2 + ((py - y - h / 2) / (h / 2)) ** 2 <= 1
        if not inside: continue
        if e.get('grad'): return _mix(e['grad'][0], e['grad'][1], max(0.0, min(1.0, (px - x) / w)) if w else 0.5)   # the gradient where the icon sits (it runs left to right)
        return e['fill']
    return bg


def readable_icons(els, bg, report=False):
    """Every pictogram readable on what it actually sits on: under 3:1 against that colour (a dark icon on a dark card, a white icon on a
    light badge — themes, palettes and edited colours combine in ways no single rule covers), it turns white or ink, whichever reads better."""
    low = []
    for i, e in enumerate(els):
        if e.get('k') != 'icon' or not e.get('color'): continue
        under = _under(els, i, e['x'] + e['s'] / 2, e['y'] + e['s'] / 2, bg)
        new = readable_color(e['color'], under)
        if new != e['color']:
            low.append((e.get('name'), e['color'], under, new))
            if not report: e['color'] = new
    return low


def readable_color(color, under):
    """The icon colour to use on `under`: kept when it reads (3:1; white on a brand colour 2.5:1 — the template's own white-on-orange, as
    its text is); on a light ground a darker shade of the same hue (on-brand, not black); on a dark ground white."""
    color = str(color).upper()
    if _contrast(color, under) >= (2.5 if color == 'FFFFFF' else 3.0): return color
    if _contrast('FFFFFF', under) < _contrast(INK, under):   # a light ground
        base = TITLE if (_lum(color) or 0) > 0.6 else color      # a white icon on a light badge: the brand colour, darkened as needed
        for k in (0.0, 0.2, 0.3, 0.4, 0.55):
            s = shade(base, k) if k else base
            if _contrast(s, under) >= 3.0: return s
        return INK
    return 'FFFFFF' if _contrast('FFFFFF', under) >= 3.0 or _contrast('FFFFFF', under) >= _contrast(INK, under) else INK


# ------------------------------------------------------------------------------------------------------------------ renderers
def _esc(t): return html.escape(str(t), quote=True)


def _mix(a, b, f):
    x = [int(a[i:i + 2], 16) for i in (0, 2, 4)]; y = [int(b[i:i + 2], 16) for i in (0, 2, 4)]
    return ''.join(f'{int(round(p + (q - p) * f)):02X}' for p, q in zip(x, y))


def _place(vb, x, y, w, h):
    vx, vy, vw, vh = (float(v) for v in vb.replace(',', ' ').split()); s = min(w / vw, h / vh)
    return f'translate({x + (w - vw * s) / 2:.2f},{y + (h - vh * s) / 2:.2f}) scale({s:.5f}) translate({-vx:.2f},{-vy:.2f})'


def to_svg(d, chrome=True, flat=False):
    """flat=True: no gradients (MuPDF draws them black) — a gradient card becomes left-anchored rounded bands, which keeps its corners."""
    W, H = d['w'], d['h']; defs = []; out = []; gid = {}
    def grad(a, b, v=False):
        key = a + b + ('v' if v else '')
        if key not in gid:
            gid[key] = f'g{len(gid)}'; xy = 'x1="0" y1="0" x2="0" y2="1"' if v else 'x1="0" y1="0" x2="1" y2="0.35"'
            defs.append(f'<linearGradient id="{gid[key]}" {xy}><stop offset="0" stop-color="#{a}"/><stop offset="1" stop-color="#{b}"/></linearGradient>')
        return f'url(#{gid[key]})'
    if chrome: out.append(f'<rect x="0" y="0" width="{W}" height="{H}" fill="#{d["bg"]}"/>')   # without the chrome (the deck twin) the slide shows through
    for e in d['els']:
        if e.get('chrome') and not chrome: continue
        k = e['k']
        if k == 'rect':
            if e['w'] <= 0 or e['h'] <= 0: continue
            stroke = f' stroke="#{e["stroke"]}" stroke-width="{e.get("sw", 1)}"' if e.get('stroke') else ''
            r = min(e.get('r') or 0, e['w'] / 2, e['h'] / 2)
            if e.get('grad') and flat and not e.get('gv'):
                a, b = e['grad']; N = 48; x0, y0, hh = e['x'], e['y'], e['h']
                out.append(f'<rect x="{x0}" y="{y0}" width="{e["w"]}" height="{hh}" rx="{r}" fill="#{_mix(a, b, 1 - max(r, e["w"] / N) / (2 * e["w"]))}"/>')
                for i in range(1, N):   # square-right, round-left strips over the rounded base: straight seams, corners kept
                    bw = e['w'] * (N - i) / N
                    if bw > e['w'] - r or bw < r: continue
                    out.append(f'<path d="M{x0 + r:.1f},{y0} H{x0 + bw:.1f} V{y0 + hh} H{x0 + r:.1f} A{r},{r} 0 0 1 {x0},{y0 + hh - r:.1f} V{y0 + r:.1f} A{r},{r} 0 0 1 {x0 + r:.1f},{y0} Z" fill="#{_mix(a, b, (N - i - 0.5) / N)}"/>')
                if stroke: out.append(f'<rect x="{e["x"]}" y="{e["y"]}" width="{e["w"]}" height="{e["h"]}" rx="{r}" fill="none"{stroke}/>')
                continue
            fill = grad(*e['grad'], v=bool(e.get('gv'))) if e.get('grad') else (f'#{e["fill"]}' if e.get('fill') else 'none')
            out.append(f'<rect x="{e["x"]}" y="{e["y"]}" width="{e["w"]}" height="{e["h"]}" rx="{r}" fill="{fill}"{stroke}/>')
        elif k == 'ellipse':
            stroke = f' stroke="#{e["stroke"]}" stroke-width="{e.get("sw", 1)}"' if e.get('stroke') else ''
            op = (' fill-opacity="' + str(e['alpha']) + '"') if e.get('alpha') else ''   # Venn circles: see-through (kept out of the f-string: Python 3.10/3.11)
            efill = grad(*e['grad'], v=bool(e.get('gv'))) if e.get('grad') else ('#' + e['fill']) if e.get('fill') else 'none'   # kept out of the f-string: Python 3.10/3.11
            out.append(f'<ellipse cx="{e["x"] + e["w"] / 2}" cy="{e["y"] + e["h"] / 2}" rx="{e["w"] / 2}" ry="{e["h"] / 2}" fill="{efill}"{stroke}{op}/>')
        elif k == 'line':
            for end, (ax, ay, bx, by) in (('arrow', (e['x1'], e['y1'], e['x2'], e['y2'])), ('arrow_start', (e['x2'], e['y2'], e['x1'], e['y1']))):
                if e.get(end):   # an arrowhead drawn as a small triangle (renderers without marker support draw it too)
                    L = math.hypot(bx - ax, by - ay) or 1; ux, uy = (bx - ax) / L, (by - ay) / L; al, aw = 5.5 * e['sw'] + 4, 2.4 * e['sw'] + 3
                    p1 = (bx - ux * al + uy * aw, by - uy * al - ux * aw); p2 = (bx - ux * al - uy * aw, by - uy * al + ux * aw)
                    out.append(f'<path d="M{bx:.1f},{by:.1f} L{p1[0]:.1f},{p1[1]:.1f} L{p2[0]:.1f},{p2[1]:.1f} Z" fill="#{e["color"]}"/>')
            out.append(f'<line x1="{e["x1"]}" y1="{e["y1"]}" x2="{e["x2"]}" y2="{e["y2"]}" stroke="#{e["color"]}" stroke-width="{e["sw"]}" stroke-linecap="round"{" stroke-dasharray=" + chr(34) + "6 6" + chr(34) if e.get("dash") else ""}/>')
        elif k == 'poly':   # a closed shape from points (diagram chevrons)
            d_ = 'M' + ' L'.join(f'{px:.1f},{py:.1f}' for px, py in e['pts']) + ' Z'
            st_ = f' stroke="#{e["stroke"]}" stroke-width="{e.get("sw", 1)}"' if e.get('stroke') else ''
            out.append(f'<path d="{d_}" fill="#{e["fill"]}"{st_}/>')
        elif k == 'arc':
            C = 2 * math.pi * e['r']; L = C * e['frac']
            out.append(f'<circle cx="{e["cx"]}" cy="{e["cy"]}" r="{e["r"]}" fill="none" stroke="#{e["track"]}" stroke-width="{e["sw"]}"/>')
            if e['frac'] >= 0.999: out.append(f'<circle cx="{e["cx"]}" cy="{e["cy"]}" r="{e["r"]}" fill="none" stroke="#{e["color"]}" stroke-width="{e["sw"]}"/>')
            elif L > 0.5:   # an arc path from twelve o'clock, clockwise — every renderer draws it (MuPDF ignores dash patterns)
                a = -math.pi / 2 + 2 * math.pi * e['frac']; x1, y1 = e['cx'], e['cy'] - e['r']; x2, y2 = e['cx'] + e['r'] * math.cos(a), e['cy'] + e['r'] * math.sin(a)
                out.append(f'<path d="M{x1:.2f},{y1:.2f} A{e["r"]},{e["r"]} 0 {1 if e["frac"] > 0.5 else 0} 1 {x2:.2f},{y2:.2f}" fill="none" stroke="#{e["color"]}" stroke-width="{e["sw"]}" stroke-linecap="round"/>')
        elif k == 'icon':
            ic = icon_svg(e['name'])
            if not ic: continue
            vb, inner = ic; inner = re.sub(r'fill="#[0-9A-Fa-f]{3,6}"', f'fill="#{e["color"]}"', inner); inner = re.sub(r'stroke="#[0-9A-Fa-f]{3,6}"', f'stroke="#{e["color"]}"', inner)
            if e.get('bold'):   # bold: an outline in the icon's own colour thickens thin line pictograms (a share of the icon's own box)
                vw = max(float(v) for v in vb.split()[2:4]); inner = re.sub(r'\s(?:stroke="none"|stroke-width="[^"]*")', '', inner)   # the UI set's own "no outline" would cancel it
                inner = f'<g stroke="#{e["color"]}" stroke-width="{vw * 0.045:.2f}" stroke-linejoin="round" stroke-linecap="round">{inner}</g>'
            out.append(f'<g transform="{_place(vb, e["x"], e["y"], e["s"], e["s"])}">{inner}</g>')
        elif k == 'logo':
            vb, inner = logo_svg(); out.append(f'<g transform="{_place(vb, e["x"], e["y"], e["w"], e["h"])}">{inner}</g>')
        elif k == 'text':
            fam = DISPLAY if e['font'] == 'display' else BODY; fw = 900 if e['font'] == 'display' else (700 if e['font'] == 'bold' else 400)
            anchor = {'left': 'start', 'center': 'middle', 'right': 'end'}[e.get('align', 'left')]; tx = e['x'] + (e['w'] / 2 if anchor == 'middle' else e['w'] if anchor == 'end' else 0)
            sp = f' letter-spacing="{e["spacing"]}"' if e.get('spacing') else ''
            for i, ln in enumerate(e['lines']):
                ty = e['y'] + e['fs'] * (0.86 + i * e['lh']) + (e['lh'] - 1) * e['fs'] / 2
                out.append(f'<text x="{tx:.1f}" y="{ty:.1f}" font-family="{_esc(fam)}" font-size="{e["fs"]}" font-weight="{fw}" fill="#{e["color"]}" text-anchor="{anchor}"{sp}>{_esc(ln)}</text>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">' + (f'<defs>{"".join(defs)}</defs>' if defs else '') + ''.join(out) + '</svg>')


def _raster():
    """SVG → PNG / PDF with permissive tools (resvg + Pillow) — v6.6 replaced PyMuPDF (AGPL-3.0)."""
    import sys as _s
    _s.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import svgraster
    return svgraster


def to_png(svg, path, zoom=2.0):
    return _raster().to_png(svg, path, zoom)


PDF_PAGE = {'onepager': (612, 792), 'slide': (960, 540), 'square': (648, 648)}   # points: Letter portrait, 13.333 × 7.5 in, 9 × 9 in


def to_pdf_pages(svgs, path, fmt=None):
    """Several pages into one PDF (a status report on a slide is two); one page goes through to_pdf."""
    if len(svgs) == 1: return to_pdf(svgs[0], path, fmt)
    import tempfile as _tf
    from PIL import Image as _Im
    d_ = _tf.mkdtemp(prefix='ulta-pdf-'); parts = []
    try:
        for i, s in enumerate(svgs):
            p = os.path.join(d_, f'{i}.pdf')
            if not to_pdf(s, p, fmt): return False
            parts.append(p)
        R = _raster(); sw, sh = R._svg_size(svgs[0]); f_ = fmt or min(PDF_PAGE, key=lambda k: abs(PDF_PAGE[k][0] / PDF_PAGE[k][1] - sw / max(1, sh)))
        pw, ph = PDF_PAGE.get(f_, (sw * 0.75, sh * 0.75)); px = (int(round(pw / 72 * 300)), int(round(ph / 72 * 300)))
        imgs = []
        for s in svgs:
            b = R.png_bytes(s, min(px[0] / sw, px[1] / sh), background='#FFFFFF'); a = _Im.open(__import__('io').BytesIO(b)).convert('RGB')
            sheet = _Im.new('RGB', px, 'white'); sheet.paste(a, ((px[0] - a.width) // 2, (px[1] - a.height) // 2)); imgs.append(sheet)
        imgs[0].save(path, 'PDF', resolution=300.0, save_all=True, append_images=imgs[1:]); return True
    finally:
        import shutil as _sh; _sh.rmtree(d_, ignore_errors=True)


def to_pdf(svg, path, fmt=None):
    """The art on a page of the format's real size (a one-pager is Letter), scaled to fit and centred, at 300 dpi — at one point per
    pixel the page was 14 × 18 in, so printing it split onto two pages and cut the bottom (the ULTA logo) off page one."""
    R = _raster(); sw, sh = R._svg_size(svg)
    if not fmt: fmt = min(PDF_PAGE, key=lambda k: abs(PDF_PAGE[k][0] / PDF_PAGE[k][1] - sw / max(1, sh)))   # the format whose proportions match the art
    return R.to_pdf(svg, path, PDF_PAGE.get(fmt, (sw * 0.75, sh * 0.75)), 300, (sw, sh))


def to_html(d):
    tpl = open(os.path.join(HERE, 'info-template.html'), encoding='utf-8').read()
    data = json.dumps({'design': d, 'svg': '<div class="pgap"></div>'.join(page_svgs(d)), 'catalogue': catalogue()}, ensure_ascii=False).replace('</', '<\\/')
    return tpl.replace('__TITLE__', _esc(d['spec']['title'])).replace('__DATA__', data)


def to_markdown(d):
    s = d['spec']; L = [f'# {s["title"]}'] + ([s['subtitle']] if s.get('subtitle') else [])
    for b in s['blocks']:
        L.append(''); L.append(f'## {b.get("title") or BLOCKS[b["type"]].split(" (")[0]}')
        if b['type'] == 'compare':
            for side in ('left', 'right'): L.append(f'### {b[side]["title"]}'); L += [f'- {x}' for x in b[side]['items']]
        elif b['type'] in ('quote', 'takeaway'): L.append(b['text'] + (f' — {b["by"]}' if b.get('by') else ''))
        elif b['type'] == 'status': L += [f'{it["label"]}: {it["value"]}' for it in b['items']]
        elif b['type'] == 'table':
            L += ['| ' + ' | '.join(b.get('cols') or []) + ' |', '|' + '---|' * len(b.get('cols') or [])] + ['| ' + ' | '.join(r) + ' |' for r in b['items']]
        elif b['type'] == 'ragcards':
            L += ['| Workstream | Owner | Status | Update |', '|---|---|---|---|'] + [f'| {it["name"]} | {it["owner"]} | {RAG[it.get("rag") or ""][1]} | {it["text"] or "—"} |' for it in b['items']]
        elif b['type'] == 'rag':
            L += ['| Workstream | Owner | Status | ' + ' | '.join(b.get('cols') or ['This week', 'Next week']) + ' |', '|---|---|---|---|---|']
            L += [f'| {it["name"]} | {it["owner"]} | {RAG[it.get("rag") or ""][1]} | {it["now"] or "—"} | {it["next"] or "—"} |' for it in b['items']]
        elif b['type'] == 'risks':
            L += ['| Risk or ask | Support needed from | Owner | Need by | Severity |', '|---|---|---|---|---|']
            L += [f'| {it["title"]} | {it["text"]} | {it["owner"]} | {it["due"]} | {RAG[it.get("rag") or ""][1]} |' for it in b['items']]
        else:
            for it in b.get('items', []): L.append('- ' + ' — '.join(str(it[k]) for k in ('when', 'value', 'title', 'label', 'text') if it.get(k)))
    if s.get('source'): L += ['', f'Source: {s["source"]}']
    return '\n'.join(L) + '\n'


def to_spec(d, template='STANDARD33', frame=True, two_col=6, cover=1, closing=32):
    """A 16:9 infographic as a deck spec: the title in the template's headline, the body drawn in native shapes (build_from_storyboard.add_info)."""
    s = d['spec']; slides = []
    if frame: slides.append({'source': cover, 'kind': 'cover', 'fills': {'title': s['title']}, 'notes': s.get('subtitle', '')})
    for pg in [d] + list(d.get('pages') or []):   # a status report on a slide: a continuation slide too
        ps = pg['spec'] if pg is not d else dict(s, title=s['title'])
        slides.append({'source': two_col, 'fills': {'title': ps['title'], 'text1': [''], 'text2': ['']}, 'hide': ['text1', 'text2'], 'info': pg, 'info_svg': to_svg(pg, chrome=False), 'sec': s['title'],
                       'notes': '\n'.join(x for x in (ps.get('subtitle'), ('Source: ' + s['source']) if s.get('source') else '') if x)})
    if frame: slides.append({'source': closing, 'kind': 'closing', 'fills': {'text1': 'Thank you!', 'text2': 'Ulta Beauty | Proprietary & Confidential'}})
    return {'template': template, 'title': s['title'], 'slides': slides, 'warnings': []}


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('text', nargs='?'); ap.add_argument('--format', default='onepager', choices=FORMAT_ORDER); ap.add_argument('--theme', default='ulta'); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    sp = rules_spec(open(a.text, encoding='utf-8').read(), a.format, a.theme) if a.text else sample_spec(a.format, a.theme)
    d = layout(sp); open(a.out + '.svg', 'w', encoding='utf-8').write(to_svg(d)); to_png(to_svg(d), a.out + '.png')
    print(json.dumps({'status': 'OK', 'blocks': [b['type'] for b in d['spec']['blocks']], 'warnings': d['warnings']}))
