# Exact input and output contract

All JSON must be UTF-8 objects without duplicate keys or nonfinite numbers. JSON inputs are bounded to20MB; source text to20MB each; PPTX/package inputs to250MB and the original native inventory's ZIP limits. Unknown schema versions are UNVERIFIED. Extra metadata is hash-bound but has no validation meaning. Empty/whitespace-only required strings are invalid. Python Unicode character offsets are used, never UTF-8 byte offsets.

## Source bank: `ppt-retained-source-bank/1`

```json
{
  "schema": "ppt-retained-source-bank/1",
  "sources": [{
    "id": "A",
    "path": "captures/A.txt",
    "sha256": "EXACT_CAPTURE_SHA256",
    "url": "https://example.invalid/fictional/A",
    "reference": "Explicitly fictional fixture source A",
    "context": "Design v1, dated 2026-09-01; not production evidence"
  }]
}
```

`path` is relative to the bank JSON's directory and must resolve inside that tree. Absolute paths, backslashes, `..` and symlink escapes are rejected. Retain full relevant rows, headers, qualifying scope and the entire relevant list for list-wide absence claims; the helper cannot discover missing context. Text is decoded without normalizing punctuation. Every source must have its real source URL repeated identically in the canonical inventory.

The separate `--sources` JSON is the existing `reviewed-source-inventory-0.1`: `reviewer_confirmed: true`, a `sources` array of unique `id`, `kind: "direct_content"`, `url`. Its ID set must exactly match the bank. Explicit confirmation is supplied by the actual reviewing agent/human; the helper does not generate it. HTTPS syntax is not accessibility, authority or truth.

## Content spec: `ppt-source-content-spec/1`

Required top-level fields:

- `schema`, `layout_sha256`, `reference_sha256`: exact supplied bytes.
- `slide_mapping`: one integer approved-reference slide number per layout slide, in layout order. Numbers are one-based. Visible native paragraph ordinals must match each mapped source slide. Other strict shape/style constraints stay with the original format/render gates.
- `preparation_stage`: `mapped_template_before_content` or `draft_retrospective`. This is an explicit declaration, not authenticated chronology.
- `review`: `complete: true`, `claims_split: true`, nonempty `reviewer`, `reviewer_kind: "agent"|"human"`, `method`, `recorded_at`. These are reviewer-owned attestations copied into the existing notes manifest. The helper never infers them or authenticates their truth/time.
- `assertions`: nonempty array of unique assertions below.
- `units`: each and only each nonempty native unit from the unchanged layout inventory, including speaker notes and potentially inherited text. Inventory IDs, not a new locator scheme, are used.

### Complete approved reference and selected scope

Always supply the exact full approved reference and its full-file hash. Do not substitute a reduced mapped reference to bypass charts or linked narrative on unused source slides. The original inventory still parses the whole reference. After a valid `slide_mapping` is established, `reference_native_scope` records `full_reference_sha256`, `mapped_source_slides`, `selected_or_unscoped_unsupported`, and `unmapped_unsupported_outside_selected_scope`. Only unsupported findings with a valid slide number that is absent from the mapping go into the last list. Selected findings or missing/invalid slide locations remain UNVERIFIED. Unmapped findings are recorded, not verified. A full-reference parse failure remains incomplete.

This scope rule applies only to successfully inventoried reference linked-content findings. Every layout/final-deck unsupported finding remains blocking. Full-reference hash, mapped source text/shape identity, clear-slot structure, citations and output protection are unchanged. A byte change anywhere in the full reference invalidates the preparation.

### Assertions

Each assertion has unique `id`, nonempty `statement`, `reason`, `scope`, `assessment: "supported"|"proposed"|"unknown"`, arrays `bindings` and `premise_ids`. At least one binding or premise is required. Premises reference other declared assertions, cannot repeat and cannot cycle.

Each binding has `source_id`, zero-based integer `start`, nonempty exact `excerpt`, and nonempty human-readable `locator`. The source's slice at that offset must equal the excerpt exactly. Bind factual premises of proposals and comparisons as separate assertions. Source unions traverse every declared premise. An omitted *real* premise that the reviewer never declares cannot be inferred by this helper.

### Planned authored units

Each ordinary authored unit has the existing inventory `id`, nonempty exact `text`, its `text_sha256`, `spans`, `required_sources` and `citations`. Only the explicit cleared-slot declaration below permits an empty string.

`spans` is a nonempty ordered list (maximum10000/unit). Each item has integer `start/end`, exact `excerpt`, nonempty `reason` and `kind`. The first start is0; each start equals the previous end; every span has positive length; the final end is exactly `len(text)`. No character may be uncovered, duplicated or silently normalized.

- `kind: "assertion"` requires nonempty unique `assertion_ids`.
- `kind: "nonfactual"` requires `classification` from the unchanged notes guard: `title`, `label`, `navigation`, `formatting`, `source_reference`, `explicit_proposal`, `explicit_unknown`; no assertion IDs. These labels do not prove the text is nonfactual. Proposal/unknown factual premises still need reviewer-bound assertion spans.

`required_sources` is a unique list exactly equal to the union of all span assertions and transitive premise bindings. `citations` contains exactly one declaration per required source:

```json
{
  "source_id": "A",
  "notes_paragraph": "s1-notes-p002",
  "rid": "evidenceA",
  "anchor_label": "Source A",
  "association_quote": "Target latency is 200 ms. Source A"
}
```

The declared notes ID must exist on the same slide. Label/association strings must occur in its planned text. Prepare checks the plan; check uses the original guard to resolve the actual hyperlink relationship, label, canonical URL and local notes association. Units without factual spans/source requirements must also supply `nonfactual_reason` from the same enum and a specific `explanation`.

The derived existing notes manifest uses each exact assertion span as a local quote, conservatively associating it with the unit's complete source set. It does not infer minimal semantic support per clause. Semantic classification and irrelevant/insufficient passages remain reviewer responsibilities.

### Exact fixed-template exemption

An unchanged mapped reference unit may instead have:

```json
{
  "id": "s1-visible-p004",
  "text": "Fixed example brand",
  "text_sha256": "EXACT_TEXT_SHA256",
  "fixed_template": {
    "reference_id": "s1-visible-p004",
    "reason": "Unchanged reference brand label, not an authored project claim"
  }
}
```

The referenced ID must be the same native-ID suffix and native paragraph ordinal on the mapped source slide; its exact text must equal both the layout and planned text. Reference and layout file hashes are pinned. An exemption cannot also have spans, required sources or citations. Altered authored text cannot use it. Any newly added notes text needs an ordinary authored-unit declaration. Potential inherited visibility is not automatically decided.

### Explicit cleared template slot

An unused visible placeholder chip may be declared for clearing only when the applicable template/assembly rules permit it. This does not authorize clearing required project content or branded template elements. The reviewer supplies a specific reason; placeholder eligibility and omission adequacy are not inferred by the helper.

```json
{
  "id": "s1-visible-p002",
  "text": "",
  "text_sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
  "cleared_template_slot": {
    "reference_id": "s1-visible-p002",
    "reason": "Unused optional template marker; the approved assembly rule permits blanking its text while retaining its shape."
  }
}
```

Keep the mapped layout unchanged before prepare. The same reference-ID suffix, mapped slide, native paragraph ordinal, original text, XML paragraph/shape tree position and full shape structure/properties must match the approved reference. Only an ordinary visible text shape with exactly one paragraph and retained `a:t` nodes is supported. Fields, explicit breaks, multiparagraph shapes, notes and inherited text are outside this clearing exception. No `fixed_template`, `spans`, `required_sources`, `citations` or `assertion_ids` keys may accompany a clear declaration, even as empty arrays.

Assembly clears only each existing `a:t` node's text value. Preserve the text nodes, runs, paragraph, shape, IDs, properties and tree position; do not remove/recreate the paragraph or shape. Final check compares the complete cleared shape signature, paragraph count and exact native position with the prepared snapshot, allowing only those text values to become exactly empty. Whitespace, hidden residual text, partial clearing, reordered/deleted nodes and property changes do not qualify. The other strict template and rendering gates remain required.

The unchanged inventory numbers nonempty paragraphs. Clearing can therefore renumber later inventory IDs even though native XML paragraphs have not moved. The pack retains the original layout IDs. Final check joins by slide, actual part and native paragraph ordinal, then records `final_inventory_id_map` to translate the derived final notes-guard manifest to the original inventory's actual exported IDs. Cleared units are listed explicitly in `cleared_template_slots` and omitted only from that nonempty manifest. This is not permission to renumber/reorder native paragraphs or invent final IDs during assembly.

## Prepared pack: `ppt-prepared-source-pack/1`

Only `prepare` emits this file after all checks succeed. It has `recorded_at`, a canonical JSON `payload_sha256`, and `payload` containing:

- `helper_sha256` and pinned original script hashes;
- exact layout/reference/bank/canonical-source `input_sha256` values;
- original raw `spec_sha256` and the parsed complete `spec`;
- `prepared_units`, each with existing native `identity {id,part,native_paragraph_ordinal}`, exact `text/text_sha256`, its full `declaration` and computed `required_sources`. A cleared declaration also carries the validated original `cleared_slot` XML-position/structure snapshot, computed by prepare rather than authored by the agent.

Keep the raw original spec and prepare report separately. Check requires `--pack-sha256` from the retained prepare output. It revalidates the embedded spec against the current exact layout/reference/bank/captures, recomputes prepared content and rejects drift. All final native units must match their original positions and exact planned text, including notes; explicitly cleared slots additionally pass the structural check above. Report input hashes bind one snapshot. Do not call later recreations original preparation.

## Failure handling and audit portability

A known hash, excerpt, union, partition, native-content or actual-anchor mismatch is FAIL. Missing captures, incomplete/unsupported schemas, malformed PPTX ZIPs and unsupported linked narrative are UNVERIFIED. Known failures retain precedence over a later missing/unsupported item. The helper writes no pack on failure and refuses an existing pack path. All CLI inputs and execution scripts are reserved before reads. Recognizable capture paths are reserved immediately after the bank parses, even if a later schema check fails. Protected inputs cannot be overwritten by reports/packs, including hard-link aliases and declared missing-capture paths. Unparseable banks cannot expose capture paths; do not choose output paths within a retained-source tree. Check never edits the PPTX.

Archive the exact bank-relative capture tree. Extract into a fresh directory and rerun the unchanged helper/scripts using those extracted bytes and the original prepare pack digest; label this a new portability rerun. Retain original command argv/cwd/stdout/stderr/exits and hashes; disclose missing originals rather than reconstructing them. An exact pack plus a later retrospective timestamp does not prove the builder consumed it before authoring.
