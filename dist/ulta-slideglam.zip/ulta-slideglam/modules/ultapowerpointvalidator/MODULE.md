---
name: ultapowerpointvalidator
description: "Validate every Ulta PowerPoint export against the approved template with the unchanged structure/font-metrics checker, source-relative artwork gate, prepared source-backed content, explicit claim-to-notes hyperlink guard and actual rendered review."
---

# Ulta PowerPoint validator

Use for every Ulta PPTX creation, revision or compliance review before delivering an attachment. This skill prepares the source-backed assembly input and adds separate read-only final-content, structural/text-fit, source-relative picture-intrusion and explicit citation-coverage checks. It does not create a deck or replace source review, the executive reviewer, rendering, or proof of download.

## Verify the complete resource


- Byte length: **88821**
- SHA256: **bcc2f9de8e06f722a279100e873d66522be763269340d1eea96f4e2866d17d4e**

Python's `Path(path).read_bytes()`, `len()` and `hashlib.sha256()` suffice. If the file is absent, truncated, mismatched, or `lxml` is unavailable, report **VALIDATOR UNAVAILABLE** and do not claim this gate ran. Do not rewrite the checker, change its embedded metrics, disable checks, or replace it with an estimated character-count check to obtain a pass.

## Prepare the exact source-backed assembly input

After choosing the source-slide mapping, preserve an unchanged mapped layout and inventory it with `scripts/pptx_source_links.py --inventory-only`. Use its native IDs. Keep all visible source paragraphs/shapes/styles; provision only permitted notes slots. Retain exact source captures as they are read. Review the planned assertion spans and their passage/premise bindings, then use the full schemas in `CONTRACT.md`. This resource is **33221 bytes**, SHA256 **531678023755dd72f87730efc0c79502c6f96613e145c73f9bbe565635e9f12d**; require its manifest match before execution.

Use the exact full approved reference PPTX for both prepare and check, with SHA256 **46e7c3bda4bf611cb7d1903c7c3d7b1ccffc6ddd73246919b5559894110a2c95**. Do not create a reduced or altered reference to avoid unused-slide charts. The helper still parses and hashes the complete file, then scopes successfully inventoried unsupported reference content to the validated source-slide mapping. Selected or unscoped issues remain UNVERIFIED; unused-slide findings remain explicitly reported outside selected scope. All layout/final unsupported checks and selected native/reference/clear-slot identity checks remain unchanged. Inspect `reference_native_scope` in the result; outside-scope findings are not chart-content verification.

```text
```

For an unused marker that the template rules permit leaving blank, use `cleared_template_slot` from CONTRACT.md with the mapped reference ID and a specific reason. Keep the layout unchanged for prepare; assembly blanks only existing `a:t` values, preserving every run, paragraph, shape, property and native position. The supported exception is an ordinary visible single-paragraph text shape without fields or explicit breaks. Other empty-slot patterns remain unsupported; select another suitable complete source layout or report the limitation. The final check translates filtered inventory IDs from retained native positions. Clearing cannot authorize omitting required project content or branded template elements.

Preserve the returned `pack_sha256` and the original command evidence. Assembly must consume `payload.prepared_units` exact text, native identity and citation requirements. An authored draft uses `preparation_stage: "draft_retrospective"`; never invent earlier preparation. After any text or layout repair, prepare a new version and rebuild. A hash or timestamp cannot prove that assembly actually consumed the pack.

```text
```

Use actual paths and the retained digest, not the literal placeholder. Require final inventoried text/notes and actual source anchors to match the same prepared content. The successful check includes the derived reviewed manifest and unchanged notes-link guard report. Exit0 `EXPORTED_CONTENT_BOUND` verifies this declared content binding only; semantic support, atomicity and factual classification remain NOT_CHECKED. Exit1 is FAIL and exit2 UNVERIFIED. Preserve missing captures/unsupported cases, and never invent HTTPS links for supplied-only sources. Archive bank-relative captures unchanged and rerun from a clean extraction, labelled as new portability evidence. Keep original commands, raw reports and hashes separately. This check does not replace the following template, artwork, source-meaning or all-slide render review.

## Run against the actual exported files

1. Locate the full approved reference PPTX and the final candidate PPTX in the runtime. Verify the reference SHA256 is **46e7c3bda4bf611cb7d1903c7c3d7b1ccffc6ddd73246919b5559894110a2c95**. A different reference requires clarification of the approved template; it must not silently become the standard.
2. Obtain the actual source-slide mapping from the deck construction record: one original template slide number per candidate slide, in presentation order. Do not infer a convenient mapping to hide differences. Respect the user's exact slide count. Source numbers refer to the presentation order, not ZIP `slideN.xml` filenames.
3. Run the bundled script with the actual paths and mapping, using the available Python interpreter:

```text
python scripts/ulta_pptx_fit.py reference.pptx candidate.pptx --mapping SOURCE_NUMBERS --report fit-report.json
```

`SOURCE_NUMBERS` is the actual comma-separated mapping, such as `1,7,10,12,10` only when those are the source slides used. Capture the process exit code and read the whole JSON report. Treat script errors separately from validation findings. Record candidate/reference/script hashes and the mapping with the result.

## Resolve findings without changing the standard

- Correct structural failures by restoring the approved source framing, masters, layouts, themes, geometry, fonts, media and styles. If a source layout cannot hold the content, shorten or rephrase within its intended regions, or select another approved source slide and rebuild that slide. Maintain the exact requested slide count and retain essential evidence in notes or another permitted detail channel.
- Triage every reported metric-risk region using its source text, resolved fonts, measured width, estimated lines and neighbouring-object intersections. Correct title/header intrusion, fragmented short labels, card overflow and obscured artwork. Do not shrink source fonts, move source artwork, enlarge original text boxes, hide flags, or alter the checker to pass.
- Render the exact final candidate and inspect every slide. Use actual font-faithful/native rendering when available, and state renderer/font limitations otherwise. Known cover false positives occur because source titles intentionally extend beyond unusually small text frames. Accept such a finding only when the specific candidate render and corresponding source render show readable text with safe clearances and no collision. The cover exemption is not automatic or transferable to new text, other slides, structural failures, or unsupported features. Record each adjudication and its actual evidence. Without adequate rendered evidence, leave the finding unresolved.
- After changing candidate bytes, rerun the checker and review the affected renders; keep the complete all-slide review current for the final exported file.

## Check picture clearance and claim-to-notes links

After the unchanged checker, run both additional complete bundled resources. Do not rewrite, abbreviate or bypass them to obtain a pass:

- `scripts/pptx_artwork_clearance.py`: **7250 bytes**, SHA256 **3a00d9b3b5b6f04e3e2fbe63e409afb129f63938b880c547d7a472a0cf3d605d**.
- `scripts/pptx_source_links.py`: **22270 bytes**, SHA256 **9948d4939fdf547b595467134aee3ad82bf8346a3d577f8a4f5a70d85f530fa8**.

```text
python scripts/pptx_artwork_clearance.py reference.pptx candidate.pptx --mapping SOURCE_NUMBERS --report artwork-clearance.json
python scripts/pptx_source_links.py candidate.pptx --inventory-only --report citation-inventory.json
python scripts/pptx_source_links.py candidate.pptx --manifest reviewed-manifest.json --sources reviewed-sources.json --report source-links.json
```

Use the actual same source-slide mapping. Resolve new picture intrusion using a shorter label or permitted source layout while preserving approved fonts/artwork/geometry. The 0.01 pt² numeric tolerance is not permission for any known rendered overlap. Original metric/font limitations remain; a source-relative no-regression result cannot replace native render review.

For creation/revision, use the manifest derived by the final prepared-pack check. Independently review its visible, notes and potentially inherited text units against the exact final PPTX and retained primary passages. When auditing a pre-existing deck without original preparation, an explicit retrospective manifest is permitted; disclose that preparation and assembly consumption remain unverified. Split material claims and retain explicit evidence sets with actual same-slide notes paragraph, relationship ID, linked label, direct canonical HTTPS target and local association text. Each individual declared source association must match an actual notes anchor. The word “Confluence,” a source name, a displayed URL or an unattached source list does not suffice. Only genuinely nonfactual units can have explained exemptions; never blanket-exempt facts or invent a complete review attestation. Preserve date/status/scope qualifiers in the actual content and review semantic support separately.

If a complete manifest is infeasible or source evidence is unavailable, keep coverage incomplete and explain what remains; do not convert partial checks into a sourced-deck pass. Inventory-only is not a coverage pass. The guard reports unsupported linked narrative as UNVERIFIED and treats navigation/contact links separately, so such links cannot fulfill citation requirements or invalidate otherwise valid source coverage merely for being noncitations. Full schema and limitations are in `references/citation-manifest.md`.

Record literal commands, process exits, complete raw reports and exact final-file/input/script hashes. `PASS_LINK_COVERAGE_FOR_REVIEWED_MANIFEST` means actual-anchor coverage for that declared review only. Source truth and semantic entailment remain NOT_CHECKED. After any final save, rerun the content check and all affected gates against the final bytes; changed text requires an updated plan and new preparation before rebuilding. A prior report cannot certify changed bytes.

## Preserve separate gates and report honestly

For the **original template validator**, exit **2** means structural failure or metric risk; **3** means only unsupported/unverified checks remain; **0** means no modelled risk. None means native visual approval. Keep raw results and distinguish corrected failures, visually adjudicated false positives, unresolved features and checks not performed.

Separately verify every material claim and diagram relation against primary sources, retain date/status/manual/proposed qualifications, validate citation links and the requested content/slide count, and complete the reviewer skill. A structurally matched slide can still be factually wrong. Report the actual generated attachment name, bytes and hash; successful attachment creation does not prove that the user downloaded it. Do not claim delivery or full compliance while required gates remain unresolved.
