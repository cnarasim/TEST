# Proposed package revision 0.2.0

This local replacement retains the original approved template checker unchanged and adds two separate read-only scripts. It has not been installed by this package build. `manifest.json` hashes every resource except itself; the external package report records the ZIP and manifest hashes.

- `pptx_source_links.py` uses Python 3 standard library. It checks reviewer-declared material claims against actual same-slide notes hyperlinks and a separately reviewed canonical source ledger. Full relationship URIs, notes linkage, all supported paragraph coverage, exact final/input/script hashes and structured errors are checked. Source truth/semantic entailment remain NOT_CHECKED. See `references/citation-manifest.md`.
- `pptx_artwork_clearance.py` imports the unchanged checker and requires `lxml`. It catches small source-relative increases in modelled text/picture overlap and preserves the original engine's limits. See `references/artwork-clearance.md`.

48 citation regression cases pass: 19 original logical cases (notes fixtures normalized to real `p:notes` roots) and 29 added CLI boundaries. Five additional artwork/control/error cases pass their expected outcomes. The real unchanged R6 deck has zero actual notes hyperlinks and fails the selected claim bindings. The reviewed roadmap has 54 actual eligible notes anchors and its selected baseline claim binds correctly; a full reviewer manifest was not attempted in this bounded test. Both real-deck checks intentionally use partial manifests and cannot establish full source coverage or semantic correctness.

Bundled fictional relationship fixtures test citation runtime access/behavior only. They are minimal ZIP/XML inputs, not renderable native decks or approved-template examples. Real business candidate files and fonts are not bundled. Use the runtime probe in `examples/README.md`, then validate actual final exports independently.

The retained original checker documentation below remains its own bounded scope and historical evidence. New gates supplement it; none replaces actual rendering, source review, reviewer judgement or proof of client download.

# Validator package and limits

This is a bounded, deterministic PPTX inspection prototype. The complete script is `scripts/ulta_pptx_fit.py`: 88,821 bytes, SHA256 `bcc2f9de8e06f722a279100e873d66522be763269340d1eea96f4e2866d17d4e`. It is byte-for-byte identical to the reviewed `ulta_pptx_fit.py.txt`; the extension alone changed.

Python 3.10+ and `lxml` are required. No network access, installed fonts, Pillow, fontTools, LibreOffice or app connection is needed to run this metrics check. The script embeds numeric glyph advances, kerning and ink bounds, not font binaries. Rendering is a separate requirement.

## Checks and interpretation

The checker reads ZIP/XML, verifies the approved reference hash, follows actual presentation order, and compares the candidate with its declared source slides: dimensions, relationship targets, masters/layouts/themes, object order, shape framing, media hashes, table geometry and source-relative text styles. It estimates wrapping and ink positions from real font glyph advances and PairPos kerning. Every text region reports source text, reference risks, resolved fonts and unsupported features.

It does not implement a complete native Office layout engine. Unsupported or partial cases include contextual shaping/ligatures, script/language feature selection, italic/synthetic bold, bullets/tabs, rotated/vertical/multicolumn text, merged cells, dynamic autofit, arbitrary inheritance and font fallback. Calibri contextual positioning is partly unmodelled. The metrics/native-rendering difference has no mathematically proven bound. The template does not embed a font version, so exact original Playfair version parity remains unverified.

Exit2 indicates structural failures or metric risks; exit3 indicates unverified features only; exit0 indicates no modelled risk. None certifies visual, factual or delivery correctness. Do not suppress or rewrite the findings.

## Evidence already assessed

On two unchanged five-slide candidates, the checker caught known rendered defects: EXT chip wrapping, chips covering system text, fragmented labels, both final-card overflows, titles entering headers/icons, and an Owner/date header touching an icon. R1 mapping `1,11,12,14,6` passed696 structure checks but flagged20 risk regions; R2 mapping `1,7,10,12,10` passed646 structure checks but flagged12 regions. The examples establish useful regression detection, not universal accuracy. Bulky reports and candidate decks are intentionally not included.

Known false-positive/borderline cases include both covers safely using space beyond small source text frames, one R1 title/header boundary and some R2 table/title boundaries. Actual candidate/source rendering is required for per-region adjudication. Never waive a structural mismatch, unknown feature or new overlap merely because an earlier cover was safe.

## Provenance and installation

`metadata.json` records the approved reference hash and original font hashes. Circular Book/Medium/Bold metrics were derived from local Managed OTF files; Playfair Black from the verified static v1.200 candidate. Arial/Calibri metrics cover defaults. No font binary, sensitive source document, credentials or network code is bundled.

Upload this ZIP as a skill in your workspace: a ZIP with SKILL.md at its root and the supporting scripts/resources. Skill activation is orchestrated rather than guaranteed for every turn. A successful installation does not prove all resource bytes reached a fresh runtime: verify script size/hash, imports and execution in a fresh session before relying on the gate. Supporting files can be partially unavailable even when a skill loads.
