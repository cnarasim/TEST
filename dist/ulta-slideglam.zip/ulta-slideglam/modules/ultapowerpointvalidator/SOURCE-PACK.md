# PPT source-backed content pack

This validator includes one additional standard-library helper, `scripts/pptx_source_pack.py`, with `prepare` and `check` modes. It reuses the **unchanged** `pptx_source_links.py` native paragraph inventory and actual notes-anchor guard. It leaves `ulta_pptx_fit.py` and `pptx_artwork_clearance.py` unchanged. The original three checkers remain unchanged.

The pack is an **assembly input**, not an audit invented after delivery. It contains the exact strings to write, explicit reviewer-declared assertions and spans, captured source bindings and complete declared source sets. A wrong interpretation can still pass these mechanics; `semantic_support`, `atomicity` and `classification_truth` always remain `NOT_CHECKED`.

## Workflow

1. Keep the complete approved reference file and verify its full-file hash. Copy the chosen approved reference slides into a mapped layout. Preserve approved visible paragraphs/shapes/styles. Do not add visible boxes or paragraphs to bypass strict template constraints. Provision extra notes slots only where allowed.
2. Run the unchanged inventory on this layout. Use those native IDs (`s1-visible-p001`, `s1-notes-p002`, potentially inherited IDs) in the exact planned content spec; do not invent locators.
3. Retain UTF-8 source text immediately, its reference/context and hashes. Complete the explicit content spec and canonical source inventory, then run `prepare`.
4. Assembly reads `payload.prepared_units`: use each exact `text`, native `identity` and declared citation requirements from that prepared pack. A test-only consumer is in the external test harness; this package is not another presentation builder.
5. Run `check` against the final PPTX, the same prepared pack and its recorded SHA-256, the original layout/reference/source files. Retain the full command outputs and input hashes.
6. Run the existing template/fit/artwork checks and real render review separately. No mechanical result permits skipping them.

If text is shortened, split, added, deleted, reordered or reassigned, update the plan/layout and prepare a new version before rebuilding. Final native text and notes must match exactly. A layout already containing authored draft text is allowed only with `preparation_stage: "draft_retrospective"`; never call that pre-authoring preparation. Neither hashes nor timestamps prove historical ordering. Retain observed prepare/build/check evidence.

For an optional visible marker that the template rules permit leaving blank, use the explicit `cleared_template_slot` declaration in CONTRACT.md. Keep the mapped layout unchanged and clear only the existing text-node values during assembly. The helper checks retained native positions and structure/properties, rejecting absent nodes, changed structure/properties or residual text. A byte-identical reconstruction is observationally indistinguishable; the authoring instruction still requires preserving the original nodes. A clear declaration never authorizes omission of required content or brand elements. Notes, inherited text, fields, breaks and multiparagraph shapes are excluded. Final filtered inventory IDs are translated from original native positions and recorded, while the pack retains layout IDs.

## Full reference scope

Use the complete approved PPTX as `--reference` in both modes. Do not manufacture a reduced reference to work around unused charts. The full-file hash and original full inventory remain bound. Once the mapping is valid, unsupported reference findings on selected slides or without a valid slide location remain UNVERIFIED. Findings on validly located unmapped slides remain visible in `reference_native_scope.unmapped_unsupported_outside_selected_scope`, without claiming those charts/narratives were verified. Layout and final-deck findings still apply to every output slide; native reference/shape identity, clear-slot preservation and all source/citation safeguards remain unchanged.

## Commands

From a directory containing the retained inputs (paths may be absolute):

```sh
python /path/to/scripts/pptx_source_links.py layout.pptx --inventory-only --report layout-inventory.json
python /path/to/scripts/pptx_source_pack.py prepare \
  --layout layout.pptx --reference reference.pptx \
  --bank bank.json --sources sources.json --spec spec.json \
  --pack-out prepared-v1.json --report prepare-v1.report.json
```

The prepare output reports `pack_sha256`. Preserve that value; do not silently replace it with a later modified pack's digest.

```sh
python /path/to/scripts/pptx_source_pack.py check \
  --layout layout.pptx --reference reference.pptx \
  --bank bank.json --sources sources.json \
  --pack prepared-v1.json --pack-sha256 PREPARE_OUTPUT_SHA256 \
  --deck final.pptx --report final-check.report.json
```

`prepare` refuses to overwrite an existing pack: use a new versioned path. Failure never writes a prepared pack. All CLI inputs, the wrapper and the three pinned scripts are protected before reading. Recognizable capture paths are protected as soon as the bank is parsed, before later schema checks. Input/output collisions and hard-link aliases are rejected even on early failure. Reports may be replaced when not inputs; retain originals under distinct names. All reads use byte snapshots; the original notes script is loaded from its pinned snapshot, and native inventory/guard reads private PPTX snapshots. Changed input files are reported as FAIL. This is not a signature, trusted clock or adversarial storage protocol.

## Results

- Exit0 `PREPARED_CONTENT_BOUND`: the declared planned content/evidence passed preparation.
- Exit0 `EXPORTED_CONTENT_BOUND`: final inventoried text/notes match that pack, and the unchanged actual notes-anchor guard passed.
- Exit1 `FAIL`: a known inconsistency, changed input, incomplete declared union, altered fixed text, text drift or broken actual anchor.
- Exit2 `UNVERIFIED`: missing/unsupported evidence or formats. Previously found FAIL takes precedence.

Every result includes hashes for successfully captured inputs; an early incomplete result cannot hash unread files. A completed final check also includes the derived unchanged-schema citation manifest and the unchanged notes guard report. Malformed PPTX ZIPs produce structured UNVERIFIED results, retaining any previously detected FAIL. The report does not attest independent semantic review, correct source interpretation, actual URL accessibility, authentic reviewer identity, template/visual parity, successful download or publication readiness.

## Supported source limitation

The current unchanged notes guard accepts actual labelled **HTTPS direct-content links**. Source capture URLs and the separate canonical inventory must agree. Supplied-only sources without genuine HTTPS links cannot be made supported by inventing URLs: the result remains UNVERIFIED. The example `.invalid` addresses are explicitly fictional fixture targets, never enterprise references and never fetched.

## Tests and examples

`examples/fictional/` contains a real but deliberately plain PPTX fixture, source captures and full spec. `examples/fictional-cleared/` also clears four optional markers, including consecutive and final slots. Neither is an Ulta-compliant user deck or a rendered-layout example. Run prepare using either directory's reference/layout/bank/source/spec files. The fixture final PPTX was produced by the external test harness consuming the exact prepared text.

The external `tests/test_source_pack.py` produced 89 expected outcomes. The original 55 cover correct preparation/check, source/hash/excerpt/union failures, text drift, citations, fixed exemptions, native coverage, cycles, output protection, malformed ZIPs, relocation and a deterministic source-replacement probe. Another 34 cover middle/consecutive/tail slot clears and ID translation, wrong reference/empty-plan declarations, preblank layouts, deleted/reordered paragraphs/shapes, hidden/partial/whitespace leftovers, property changes and unsupported notes/inherited/field/break/multiparagraph clearing. A deliberately false fully declared `240 < 200` comparison still passes with semantic support NOT_CHECKED; that is an intentional limitation test. A separate read-only compatibility check found all 15 `XX` markers on actual approved template slide 11 meet the narrow shape contract; that is not a rendered deck acceptance. The unchanged real R52 deck and legacy records remain UNVERIFIED rather than reconstructed as a preparation pack.

See `CONTRACT.md` for every recognized schema field and root `SKILL.md` for the integrated workflow. Local helper testing does not establish live-agent acceptance.

## Retained local prepared examples

Each fictional example directory includes `prepared-local.json`, `prepare-local.report.json`, `check-local.report.json`, and `local-execution.json`, freshly produced with helper0.1.2 during local packaging. They are historical local fixture evidence, not a live-agent run or business review. Their absolute recorded paths identify the original local run; use paths in the current extraction for a new replay. Do not overwrite these records: choose a new pack/report path. See `examples/prepared-runs.md`.
