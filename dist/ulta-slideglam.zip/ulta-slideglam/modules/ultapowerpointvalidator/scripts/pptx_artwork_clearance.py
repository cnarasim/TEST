"""Read-only source-relative picture-bounds intrusion gate, not a renderer.
Imports the unchanged, hash-pinned template validator. Flags small modelled
increases that its broader text-fit threshold intentionally does not report.
"""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

EXPECTED_FIT_SHA = 'bcc2f9de8e06f722a279100e873d66522be763269340d1eea96f4e2866d17d4e'
NUMERIC_TOLERANCE_PT2 = 0.01  # Rounding tolerance, never a visual clearance allowance.


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def check(reference, candidate, mapping):
    module_path = Path(__file__).with_name('ulta_pptx_fit.py')
    if sha(module_path) != EXPECTED_FIT_SHA:
        raise ValueError('Original template validator absent or hash mismatched')
    spec = importlib.util.spec_from_file_location('approved_ulta_fit', module_path)
    fit = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(fit)
    src, out = fit.Deck(str(reference)), fit.Deck(str(candidate))
    try:
        if len(mapping) != len(out.parts) or any(n < 1 or n > len(src.parts) for n in mapping):
            raise ValueError('One valid declared source-slide number is required per candidate slide')
        missing = fit.missing_targets(out.z)
        if missing:
            raise ValueError('Candidate has missing internal package targets')
        structural_failures = [c for c in fit.structural(src, out, mapping) if not c['passed']]
        if structural_failures:
            return {'result':'UNVERIFIED', 'reason':'Source framing or structure differs; restore template before comparing clearance',
                    'structural_failures':structural_failures}
        slides, risks, unmodelled = [], [], []
        for i, si in enumerate(mapping, 1):
            sr, so, sw = src.regions(si)
            cr, co, cw = out.regions(i)
            source_regions = {r['key']: fit.measure(src, r) for r in sr}
            source_pics = {o['key']:o for o in so if o['kind']=='pic'}
            pairs, limitations = [], []
            for r in cr:
                current = fit.measure(out, r)
                before = source_regions.get(r['key'])
                if before is None:
                    raise ValueError('Unmatched source text region '+r['key'])
                if current['warnings'] or before['warnings']:
                    limitations.append({'region':r['key'], 'warnings':sorted(set(current['warnings']+before['warnings']))})
                for obstacle in co:
                    if obstacle['kind'] != 'pic' or fit.contains(obstacle['rect'], current['rectPt']):
                        continue
                    old_picture = source_pics.get(obstacle['key'])
                    if old_picture is None or old_picture['rect'] != obstacle['rect']:
                        raise ValueError('Unmatched or moved source picture '+obstacle['key'])
                    area = sum(fit.overlap(line['rect'], obstacle['rect']) for line in current.get('lines', []))
                    old_area = sum(fit.overlap(line['rect'], old_picture['rect']) for line in before.get('lines', []))
                    increased = area > NUMERIC_TOLERANCE_PT2 and area-old_area > NUMERIC_TOLERANCE_PT2
                    pair = {'slide':i, 'source_slide':si, 'region':r['key'], 'picture':obstacle['key'],
                            'text':current['text'], 'source_text':before['text'],
                            'candidate_area_pt2':round(area, 6), 'source_area_pt2':round(old_area, 6),
                            'increased_intrusion':increased}
                    if increased:
                        risks.append(pair)
                    if area or old_area or current['text'] != before['text']:
                        pairs.append(pair)
            if cw or sw:
                unmodelled.append({'slide':i, 'features':sorted(set(cw+sw))})
            slides.append({'slide':i, 'source_slide':si, 'pairs':pairs, 'metric_limitations':limitations})
        return {'result':'NEEDS_REVIEW' if risks else ('UNVERIFIED' if unmodelled else 'NO_MODELLED_ARTWORK_REGRESSION'),
                'mapping':mapping, 'increased_picture_intrusions':risks, 'slides':slides,
                'unmodelled_geometry':unmodelled, 'structural_failures':[],
                'numeric_tolerance_pt2':NUMERIC_TOLERANCE_PT2,
                'fit_script_sha256':sha(module_path)}
    finally:
        src.z.close()
        out.z.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference',type=Path)
    parser.add_argument('candidate',type=Path)
    parser.add_argument('--mapping',required=True)
    parser.add_argument('--report',type=Path,required=True)
    args=parser.parse_args()
    provenance={'script_sha256':sha(Path(__file__)), 'script_bytes':Path(__file__).stat().st_size}
    safe=False
    try:
        inputs=[args.reference,args.candidate,Path(__file__),Path(__file__).with_name('ulta_pptx_fit.py')]
        if any(args.report.resolve()==p.resolve() or (args.report.exists() and p.exists() and args.report.samefile(p)) for p in inputs):
            raise ValueError('Report must not overwrite any input/script')
        safe=True
        provenance.update(reference_sha256=sha(args.reference),candidate_sha256=sha(args.candidate))
        mapping=[int(x) for x in args.mapping.split(',')]
        report=check(args.reference,args.candidate,mapping)
        if sha(args.candidate)!=provenance['candidate_sha256'] or sha(args.reference)!=provenance['reference_sha256']:
            raise ValueError('Input changed during validation; rerun stable final files')
    except Exception as exc:
        report={'result':'UNVERIFIED','reason':str(exc)}
    report.update(provenance)
    report.update(schema='ppt-artwork-clearance-report-0.1', candidate_modified=False,
        native_visual_parity='NOT_CHECKED', semantic_correctness='NOT_CHECKED',
        scope='Source-relative text-line rectangles against retained picture rectangles; positive new overlap requires review.',
        limits=['Picture bounds include whitespace, not actual vector/raster ink; false positives require source/candidate render adjudication.',
                'Embedded font metrics estimate text layout; bold selection, contextual shaping, actual Office font parity and other original metric warnings remain unverified.',
                'No regression means only no modelled increase. Existing source collisions, insufficient positive clearance, non-picture shapes, images behind enclosing text regions and unresolved geometry are not certified.',
                'Run the unchanged template validator, this gate, actual render review and the source-link guard separately; never waive a known visual defect.'])
    if safe:
        try:
            args.report.parent.mkdir(parents=True,exist_ok=True)
            args.report.write_text(json.dumps(report,indent=2)+'\n')
        except OSError as exc:
            report['result']='UNVERIFIED';report['report_write_error']=str(exc)
    print(json.dumps(report,indent=2))
    return 2 if report['result']=='UNVERIFIED' else 1 if report['result']=='NEEDS_REVIEW' else 0


if __name__=='__main__':raise SystemExit(main())
