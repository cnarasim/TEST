"""Prepare/check exact declared PPT content and retained evidence; no semantic verdict.

Standard library. Reuses the unchanged pptx_source_links inventory/anchor guard.
The mapped layout already contains the native paragraph slots used by assembly.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import types
from datetime import datetime, timezone
from zipfile import BadZipFile, ZipFile

PINS = {
    'pptx_source_links.py': '9948d4939fdf547b595467134aee3ad82bf8346a3d577f8a4f5a70d85f530fa8',
    'pptx_artwork_clearance.py': '3a00d9b3b5b6f04e3e2fbe63e409afb129f63938b880c547d7a472a0cf3d605d',
    'ulta_pptx_fit.py': 'bcc2f9de8e06f722a279100e873d66522be763269340d1eea96f4e2866d17d4e',
}
LIMITS = [
    'Semantic support, factual classification, atomicity, source authority and reviewer identity authenticity are NOT_CHECKED.',
    'Hashes bind supplied snapshots, not historic preparation order or genuine assembly consumption; retain observed prepare/build/check evidence.',
    'A wrong but completely declared interpretation can pass. No automatic assertion or nonfactual classification is created.',
    'Mapped reference paragraph counts are checked, not shape/style/template parity, inherited visibility, rendering, artwork or font fit.',
    'Only the unchanged inventory native text is covered; unsupported linked narrative is UNVERIFIED; images and binary media need separate review.',
    'Source captures are UTF-8 text. The unchanged notes guard requires actual labelled HTTPS direct-content anchors; do not invent URLs for supplied-only sources.',
    'The full reference hash and package inventory remain bound. Unsupported linked content on validated unmapped reference slides is reported outside the selected scope; selected or unscoped reference issues, and all layout/final issues, remain UNVERIFIED.',
]


class Incomplete(ValueError):
    pass


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def digest(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def parse(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise Incomplete('Duplicate JSON key: ' + key)
            result[key] = value
        return result
    return json.loads(raw, object_pairs_hook=pairs,
                      parse_constant=lambda s: (_ for _ in ()).throw(Incomplete('Nonfinite JSON: ' + s)))


class Session:
    def __init__(self):
        self.inputs, self.failures, self.unverified = {}, [], []
        self.protected = set()
        self.reference_scope = None

    def protect(self, path):
        # Reserve declared inputs even before they can be read or validated.
        self.protected.add(Path(path).absolute())
        try:
            self.protected.add(Path(path).resolve())
        except (OSError, RuntimeError):
            pass

    def read(self, path, maximum=250_000_000):
        self.protect(path)
        path = Path(path).resolve()
        if path not in self.inputs:
            raw = path.read_bytes()
            if len(raw) > maximum:
                raise Incomplete('Input exceeds bounded size: ' + str(path))
            self.inputs[path] = raw
        return self.inputs[path]

    def json(self, path):
        value = parse(self.read(path, 20_000_000))
        if not isinstance(value, dict):
            raise Incomplete('Expected JSON object: ' + str(path))
        return value

    def require(self, condition, code, detail):
        if not condition:
            self.failures.append({'code': code, 'detail': detail})
        return bool(condition)

    def missing(self, code, detail):
        self.unverified.append({'code': code, 'detail': detail})

    def stable(self):
        for path, raw in self.inputs.items():
            try:
                self.require(path.read_bytes() == raw, 'INPUT_CHANGED_DURING_CHECK', str(path))
            except OSError as exc:
                self.require(False, 'INPUT_DISAPPEARED_DURING_CHECK', str(exc))

    def result(self):
        return 'FAIL' if self.failures else ('UNVERIFIED' if self.unverified else 'COMPLETE')


def load_guard(ctx):
    root = Path(__file__).resolve().parent
    for name, expected in PINS.items():
        if not ctx.require(sha(ctx.read(root / name)) == expected, 'CHANGED_ORIGINAL_SCRIPT', name):
            raise Incomplete('Original script identity mismatch')
    path = root / 'pptx_source_links.py'
    module = types.ModuleType('pinned_ppt_links')
    module.__file__ = str(path)
    exec(compile(ctx.read(path), str(path), 'exec'), module.__dict__)
    return module


def inventory_snapshot(ctx, guard, path, directory, label, *, defer_unsupported=False):
    raw = ctx.read(path)
    snapshot = Path(directory) / (label + '.pptx')
    snapshot.write_bytes(raw)
    inv = guard.inventory(snapshot)
    if inv.get('unsupported_content') and not defer_unsupported:
        ctx.missing('UNSUPPORTED_NATIVE_CONTENT', inv['unsupported_content'])
    return raw, inv, snapshot


def check_reference_scope(ctx, reference, mapping):
    selected, unmapped = [], []
    for issue in reference.get('unsupported_content', []):
        slide = issue.get('slide') if isinstance(issue, dict) else None
        if type(slide) is int and 1 <= slide <= len(reference['slides']) and slide not in mapping:
            unmapped.append(issue)
        else:
            # Missing/invalid location is not evidence that an issue is outside scope.
            selected.append(issue)
    ctx.reference_scope = {
        'full_reference_sha256': reference['deck_sha256'],
        'mapped_source_slides': mapping,
        'selected_or_unscoped_unsupported': selected,
        'unmapped_unsupported_outside_selected_scope': unmapped,
    }
    if selected:
        ctx.missing('UNSUPPORTED_SELECTED_REFERENCE_CONTENT', selected)


def units(inv):
    return {u['id']: u for slide in inv['slides'] for kind in ('visible', 'notes', 'inherited') for u in slide[kind]}


def identity(unit):
    return {k: unit[k] for k in ('id', 'part', 'native_paragraph_ordinal')}


def native_key(unit):
    return (unit['id'].split('-')[0], unit['part'], unit['native_paragraph_ordinal'])


def clear_slot(snapshot, unit, guard):
    """Inspect one plain visible paragraph without inventing an inventory ID."""
    if not re.fullmatch(r's[0-9]+-visible-p[0-9]+', unit['id']):
        raise Incomplete('Clearing is supported only for ordinary visible text shapes: ' + unit['id'])
    with ZipFile(snapshot) as z:
        root = guard.xml(z.read(unit['part']), unit['part'])
    paragraphs = root.findall('.//a:p', guard.NS)
    ordinal = unit['native_paragraph_ordinal']
    if not 1 <= ordinal <= len(paragraphs):
        raise Incomplete('Cleared native paragraph is missing: ' + unit['id'])
    paragraph = paragraphs[ordinal - 1]
    parents = {child: parent for parent in root.iter() for child in parent}
    node = paragraph
    while node is not root and node.tag != '{'+guard.NS['p']+'}sp':
        node = parents[node]
    if node is root or node.findall('.//a:p', guard.NS) != [paragraph]:
        raise Incomplete('Clearing requires one paragraph in an ordinary visible text shape: ' + unit['id'])
    if node.find('.//a:fld', guard.NS) is not None or node.find('.//a:br', guard.NS) is not None:
        raise Incomplete('Dynamic fields or line breaks cannot be cleared as template slots: ' + unit['id'])
    texts = paragraph.findall('.//a:t', guard.NS)
    if not texts:
        raise Incomplete('Cleared slot must retain its original text nodes: ' + unit['id'])
    def path(element):
        result = []
        while element is not root:
            parent = parents[element]
            result.append(list(parent).index(element))
            element = parent
        return list(reversed(result))
    def signature(element):
        # Ignore XML indentation and only the text-node value being cleared.
        text = '' if element.tag == '{'+guard.NS['a']+'}t' else (element.text or '').strip()
        return [element.tag, [[key, value] for key, value in sorted(element.attrib.items())], text,
                [signature(child) for child in element]]
    return {'paragraph_path': path(paragraph), 'shape_path': path(node),
            'shape_signature': signature(node), 'paragraph_count': len(paragraphs),
            'text': ''.join(t.text or '' for t in texts)}


def validate_sources(ctx, bank_path, bank, source_inventory, guard):
    if bank.get('schema') != 'ppt-retained-source-bank/1':
        raise Incomplete('Expected ppt-retained-source-bank/1')
    if source_inventory.get('schema') != 'reviewed-source-inventory-0.1':
        raise Incomplete('Expected unchanged reviewed-source-inventory-0.1')
    ctx.require(source_inventory.get('reviewer_confirmed') is True, 'SOURCE_REVIEW_MISSING', 'Explicit canonical-source reviewer attestation required')
    entries = bank.get('sources')
    canonical_entries = source_inventory.get('sources')
    if not isinstance(entries, list) or not entries or not isinstance(canonical_entries, list):
        raise Incomplete('Complete source bank and canonical inventory required')
    ids = [s['id'] for s in entries]
    cids = [s['id'] for s in canonical_entries]
    ctx.require(all(nonempty(x) for x in ids) and len(ids) == len(set(ids)), 'SOURCE_IDS', ids)
    ctx.require(len(cids) == len(set(cids)) and set(ids) == set(cids), 'CANONICAL_SOURCE_SET', {'bank': ids, 'canonical': cids})
    canon = {s['id']: s for s in canonical_entries}
    root = Path(bank_path).resolve().parent
    retained = {}
    for source in entries:
        sid = source['id']
        url = canon.get(sid, {}).get('url')
        if not guard.valid_https_url(url) or canon.get(sid, {}).get('kind') != 'direct_content':
            ctx.missing('UNSUPPORTED_CANONICAL_SOURCE', sid)
        ctx.require(source.get('url') == url, 'SOURCE_URL_BINDING', sid)
        ctx.require(nonempty(source.get('reference')) and nonempty(source.get('context')), 'MISSING_SOURCE_CONTEXT', sid)
        relative = source.get('path')
        if not nonempty(relative) or Path(relative).is_absolute() or '\\' in relative or '..' in Path(relative).parts:
            ctx.require(False, 'UNSAFE_SOURCE_PATH', sid)
            continue
        path = (root / relative).resolve()
        if not path.is_relative_to(root):
            ctx.require(False, 'SOURCE_PATH_ESCAPES_BANK', sid)
            continue
        try:
            raw = ctx.read(path, 20_000_000)
            ctx.require(digest(source.get('sha256')) and sha(raw) == source['sha256'], 'SOURCE_HASH', sid)
            retained[sid] = raw.decode('utf-8')
        except (OSError, UnicodeError) as exc:
            ctx.missing('MISSING_OR_UNSUPPORTED_CAPTURE', {'source': sid, 'reason': str(exc)})
    return retained


def validate_spec(ctx, spec, layout, reference, retained, guard, layout_snapshot, reference_snapshot):
    if spec.get('schema') != 'ppt-source-content-spec/1':
        raise Incomplete('Expected ppt-source-content-spec/1')
    review = spec.get('review', {})
    ctx.require(review.get('complete') is True and review.get('claims_split') is True and nonempty(review.get('reviewer')), 'REVIEW_ATTESTATION', 'Copy an explicit actual reviewer attestation; never infer it')
    ctx.require(review.get('reviewer_kind') in {'agent', 'human'} and nonempty(review.get('method')) and nonempty(review.get('recorded_at')), 'REVIEW_PROVENANCE', review)
    ctx.require(spec.get('preparation_stage') in {'mapped_template_before_content', 'draft_retrospective'}, 'PREPARATION_STAGE', 'Declare actual preparation stage; timestamps do not prove it')
    ctx.require(spec.get('layout_sha256') == layout['deck_sha256'], 'STALE_LAYOUT', layout['deck_sha256'])
    ctx.require(spec.get('reference_sha256') == reference['deck_sha256'], 'STALE_REFERENCE', reference['deck_sha256'])
    mapping = spec.get('slide_mapping')
    if not isinstance(mapping, list) or len(mapping) != len(layout['slides']) or any(type(n) is not int or not 1 <= n <= len(reference['slides']) for n in mapping):
        raise Incomplete('One valid approved reference slide number per mapped-layout slide is required')
    check_reference_scope(ctx, reference, mapping)
    for slide, source_number in zip(layout['slides'], mapping):
        refslide = reference['slides'][source_number - 1]
        ctx.require([u['native_paragraph_ordinal'] for u in slide['visible']] == [u['native_paragraph_ordinal'] for u in refslide['visible']],
                    'VISIBLE_TEMPLATE_PARAGRAPH_STRUCTURE', slide['slide'])
    actual, refunits = units(layout), units(reference)
    declarations = spec.get('units')
    claims = spec.get('assertions')
    if not isinstance(declarations, list) or not isinstance(claims, list) or not claims:
        raise Incomplete('Complete native-unit declarations and assertions required')
    ids, cids = [u['id'] for u in declarations], [c['id'] for c in claims]
    ctx.require(len(ids) == len(set(ids)) and set(ids) == set(actual), 'NATIVE_UNIT_COVERAGE', {'missing': sorted(set(actual)-set(ids)), 'extra': sorted(set(ids)-set(actual))})
    ctx.require(all(nonempty(x) for x in cids) and len(cids) == len(set(cids)), 'ASSERTION_IDS', cids)
    claimmap = {c['id']: c for c in claims}
    for claim in claims:
        cid = claim['id']
        ctx.require(nonempty(claim.get('statement')) and nonempty(claim.get('reason')) and nonempty(claim.get('scope')), 'ASSERTION_REVIEW_FIELDS', cid)
        ctx.require(claim.get('assessment') in {'supported', 'proposed', 'unknown'}, 'ASSERTION_ASSESSMENT', cid)
        bindings, premises = claim.get('bindings'), claim.get('premise_ids')
        if not isinstance(bindings, list) or not isinstance(premises, list):
            raise Incomplete('Assertion bindings and premise_ids must be arrays: ' + str(cid))
        ctx.require(bool(bindings or premises), 'UNBOUND_ASSERTION', cid)
        ctx.require(len(premises) == len(set(premises)), 'DUPLICATE_PREMISE', cid)
        for binding in bindings:
            sid, start, excerpt = binding.get('source_id'), binding.get('start'), binding.get('excerpt')
            ctx.require(type(start) is int and start >= 0 and nonempty(excerpt) and nonempty(binding.get('locator')), 'PASSAGE_FIELDS', cid)
            if sid not in retained:
                ctx.missing('UNAVAILABLE_BOUND_SOURCE', {'claim': cid, 'source': sid})
            elif type(start) is int and isinstance(excerpt, str):
                ctx.require(retained[sid][start:start+len(excerpt)] == excerpt, 'PASSAGE_SLICE', {'claim': cid, 'source': sid})

    memo = {}
    def union(cid, path=()):
        if cid in memo:
            return memo[cid]
        if cid not in claimmap or cid in path:
            ctx.require(False, 'MISSING_OR_CYCLIC_PREMISE', list(path) + [cid])
            return set()
        c = claimmap[cid]
        result = {b.get('source_id') for b in c['bindings']}
        for previous in c['premise_ids']:
            result |= union(previous, path + (cid,))
        memo[cid] = result
        return result
    for cid in cids:
        union(cid)
    prepared = []
    declared = {u['id']: u for u in declarations}
    for unit in declarations:
        pid = unit['id']
        if pid not in actual:
            continue
        text = unit.get('text')
        clearing = unit.get('cleared_template_slot')
        if clearing is not None:
            ctx.require(text == '' and unit.get('text_sha256') == sha(b''), 'CLEARED_TEXT_NOT_EMPTY', pid)
            ctx.require(isinstance(clearing, dict) and nonempty(clearing.get('reason')), 'CLEAR_REASON', pid)
            if not isinstance(clearing, dict):
                continue
            source_slide = mapping[int(pid.split('-')[0][1:]) - 1]
            expected_id = re.sub(r'^s[0-9]+-', 's'+str(source_slide)+'-', pid)
            rid = clearing.get('reference_id')
            ref = refunits.get(rid)
            mapped = ref is not None and rid == expected_id and ref['native_paragraph_ordinal'] == actual[pid]['native_paragraph_ordinal']
            ctx.require(mapped, 'CLEAR_REFERENCE_MAPPING', {'unit': pid, 'expected_reference_id': expected_id})
            ctx.require(ref is not None and actual[pid]['text'] == ref['text'], 'ALTERED_CLEAR_TEMPLATE_TEXT', pid)
            ctx.require(all(key not in unit for key in ('fixed_template', 'spans', 'required_sources', 'citations', 'assertion_ids')), 'MIXED_CLEAR_DECLARATION', pid)
            if mapped:
                slot = clear_slot(layout_snapshot, actual[pid], guard)
                reference_slot = clear_slot(reference_snapshot, ref, guard)
                ctx.require(slot == reference_slot, 'CLEAR_REFERENCE_STRUCTURE', pid)
                prepared.append({'identity': identity(actual[pid]), 'text': '', 'text_sha256': sha(b''),
                                 'declaration': unit, 'required_sources': [], 'cleared_slot': slot})
            continue
        if not nonempty(text):
            ctx.require(False, 'EMPTY_PLANNED_TEXT', pid)
            continue
        ctx.require(unit.get('text_sha256') == sha(text.encode()), 'PLANNED_TEXT_HASH', pid)
        item = {'identity': identity(actual[pid]), 'text': text, 'text_sha256': sha(text.encode()), 'declaration': unit}
        exemption = unit.get('fixed_template')
        if exemption is not None:
            rid = exemption.get('reference_id')
            r = refunits.get(rid)
            source_slide = mapping[int(pid.split('-')[0][1:]) - 1]
            expected_reference_id = re.sub(r'^s[0-9]+-', 's'+str(source_slide)+'-', pid)
            ctx.require(r is not None and rid == expected_reference_id
                        and r['native_paragraph_ordinal'] == actual[pid]['native_paragraph_ordinal'],
                        'EXEMPTION_REFERENCE_MAPPING', {'unit': pid, 'expected_reference_id': expected_reference_id})
            ctx.require(nonempty(exemption.get('reason')), 'EXEMPTION_REASON', pid)
            ctx.require(r is not None and actual[pid]['text'] == text == r['text'], 'ALTERED_FIXED_TEMPLATE_TEXT', pid)
            ctx.require(not unit.get('spans') and not unit.get('required_sources') and not unit.get('citations'), 'MIXED_TEMPLATE_EXEMPTION', pid)
            item['required_sources'] = []
            prepared.append(item)
            continue
        spans = unit.get('spans')
        if not isinstance(spans, list) or not spans or len(spans) > 10000:
            raise Incomplete('Complete exact text spans required: ' + pid)
        position, needed = 0, set()
        for index, span in enumerate(spans):
            start, end = span.get('start'), span.get('end')
            valid = type(start) is int and type(end) is int and start == position and start < end <= len(text)
            ctx.require(valid, 'TEXT_PARTITION', {'unit': pid, 'span': index})
            if valid:
                ctx.require(span.get('excerpt') == text[start:end], 'SPAN_EXCERPT', {'unit': pid, 'span': index})
                position = end
            ctx.require(nonempty(span.get('reason')), 'SPAN_REVIEW_REASON', pid)
            if span.get('kind') == 'assertion':
                refs = span.get('assertion_ids')
                if not isinstance(refs, list) or not refs:
                    raise Incomplete('Assertion IDs required in factual span: ' + pid)
                ctx.require(len(refs) == len(set(refs)), 'DUPLICATE_SPAN_ASSERTION', pid)
                for cid in refs:
                    needed |= union(cid)
            elif span.get('kind') == 'nonfactual':
                ctx.require(span.get('classification') in guard.NONFACTUAL and not span.get('assertion_ids'), 'NONFACTUAL_CLASSIFICATION', pid)
            else:
                ctx.require(False, 'SPAN_KIND', pid)
        ctx.require(position == len(text), 'UNCOVERED_TEXT_SUFFIX', pid)
        req = unit.get('required_sources')
        ctx.require(isinstance(req, list) and len(req) == len(set(req)) and set(req) == needed, 'INCOMPLETE_SOURCE_UNION', pid)
        citations = unit.get('citations')
        if not isinstance(citations, list):
            raise Incomplete('citations must be an array: ' + pid)
        ctx.require(len(citations) == len(needed) and {x.get('source_id') for x in citations} == needed, 'CITATION_SOURCE_UNION', pid)
        if not needed:
            ctx.require(unit.get('nonfactual_reason') in guard.NONFACTUAL and nonempty(unit.get('explanation')), 'NONFACTUAL_UNIT_REASON', pid)
        for cite in citations:
            nid = cite.get('notes_paragraph')
            note = declared.get(nid, {})
            ctx.require(isinstance(nid, str) and nid.startswith(pid.split('-')[0]+'-notes-'), 'PLANNED_NOTES_LOCALITY', pid)
            for key in ('rid', 'anchor_label', 'association_quote'):
                ctx.require(nonempty(cite.get(key)), 'PLANNED_CITATION_FIELDS', {'unit': pid, 'field': key})
            for key in ('anchor_label', 'association_quote'):
                ctx.require(nonempty(cite.get(key)) and cite[key] in note.get('text', ''), 'PLANNED_CITATION_TEXT', {'unit': pid, 'field': key})
        item['required_sources'] = sorted(needed)
        prepared.append(item)
    return prepared


def make_link_manifest(pack, deck_sha, final_ids=None):
    final_ids = final_ids or {}
    paragraphs = []
    for item in pack['payload']['prepared_units']:
        unit, pid = item['declaration'], item['identity']['id']
        if unit.get('cleared_template_slot') is not None:
            continue
        paragraph = {'id': final_ids.get(pid, pid), 'text_sha256': item['text_sha256']}
        if unit.get('fixed_template') is not None:
            paragraph.update(disposition='nonfactual', reason='formatting', explanation=unit['fixed_template']['reason'])
        elif not item['required_sources']:
            paragraph.update(disposition='nonfactual', reason=unit['nonfactual_reason'], explanation=unit['explanation'])
        else:
            # One local association per exact factual span; source union is already
            # recomputed from all declared assertions and transitive premises.
            claims = []
            for index, span in enumerate(unit['spans']):
                if span['kind'] != 'assertion':
                    continue
                # Every unit citation is retained conservatively on each span.
                evidence = [{**cite, 'notes_paragraph': final_ids.get(cite['notes_paragraph'], cite['notes_paragraph'])}
                            for cite in unit['citations']]
                claims.append({'id': pid+'-span'+str(index), 'quote': span['excerpt'], 'evidence': evidence})
            paragraph.update(disposition='claims', claims=claims)
        paragraphs.append(paragraph)
    return {'schema': 'ppt-notes-claim-manifest-0.1', 'deck_sha256': deck_sha,
            'review': pack['payload']['spec']['review'], 'paragraphs': paragraphs}


def write_atomic(path, raw):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name+'.', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def run(args):
    ctx = Session()
    script = Path(__file__).resolve()
    for path in [script, *(script.parent / name for name in PINS),
                 args.layout, args.reference, args.bank, args.sources,
                 *([args.spec] if args.mode == 'prepare' else [args.pack, args.deck])]:
        ctx.protect(path)
    report = {'schema': 'ppt-source-pack-report/1', 'mode': args.mode,
              'semantic_support': 'NOT_CHECKED', 'atomicity': 'NOT_CHECKED',
              'classification_truth': 'NOT_CHECKED', 'limits': LIMITS}
    pending = None
    try:
        bank = ctx.json(args.bank)
        # Capture paths can be recognized before any later schema/pin failure.
        # Reserve even an unsafe declaration; validation below still rejects it.
        entries = bank.get('sources')
        if isinstance(entries, list):
            for entry in entries:
                if isinstance(entry, dict) and nonempty(entry.get('path')):
                    ctx.protect(Path(args.bank).resolve().parent / entry['path'])
        script_raw = ctx.read(Path(__file__))
        report['script_sha256'] = sha(script_raw)
        guard = load_guard(ctx)
        canon = ctx.json(args.sources)
        with tempfile.TemporaryDirectory(prefix='ppt_source_pack_') as temp:
            layout_raw, layout, layout_snapshot = inventory_snapshot(ctx, guard, args.layout, temp, 'layout')
            ref_raw, reference, reference_snapshot = inventory_snapshot(ctx, guard, args.reference, temp, 'reference', defer_unsupported=True)
            if args.mode == 'prepare':
                spec = ctx.json(args.spec)
            else:
                raw = ctx.read(args.pack, 20_000_000)
                ctx.require(digest(args.pack_sha256) and sha(raw) == args.pack_sha256, 'STALE_PREPARED_PACK', 'Use the exact pack SHA retained from prepare')
                pack = parse(raw)
                if pack.get('schema') != 'ppt-prepared-source-pack/1':
                    raise Incomplete('Expected ppt-prepared-source-pack/1')
                payload = pack['payload']
                ctx.require(pack.get('payload_sha256') == sha(canonical(payload)), 'PACK_PAYLOAD_HASH', 'Prepared payload changed')
                ctx.require(payload.get('helper_sha256') == sha(script_raw), 'PREPARER_VERSION_CHANGED', payload.get('helper_sha256'))
                ctx.require(payload.get('original_scripts') == PINS, 'PREPARED_ORIGINAL_SCRIPT_PINS', 'Pack must retain the unchanged original script identities')
                expected = {'layout': sha(layout_raw), 'reference': sha(ref_raw), 'bank': sha(ctx.read(args.bank)), 'sources': sha(ctx.read(args.sources))}
                ctx.require(payload.get('input_sha256') == expected, 'STALE_PREPARATION_INPUT', expected)
                spec = payload['spec']
            retained = validate_sources(ctx, args.bank, bank, canon, guard)
            prepared = validate_spec(ctx, spec, layout, reference, retained, guard, layout_snapshot, reference_snapshot)
            report['counts'] = {'source_captures': len(retained), 'assertions': len(spec.get('assertions', [])), 'prepared_units': len(prepared)}
            if args.mode == 'prepare':
                payload = {'helper_sha256': sha(script_raw), 'original_scripts': PINS,
                           'input_sha256': {'layout': sha(layout_raw), 'reference': sha(ref_raw), 'bank': sha(ctx.read(args.bank)), 'sources': sha(ctx.read(args.sources))},
                           'spec_sha256': sha(ctx.read(args.spec)), 'spec': spec, 'prepared_units': prepared}
                pack = {'schema': 'ppt-prepared-source-pack/1', 'recorded_at': datetime.now(timezone.utc).isoformat(),
                        'payload_sha256': sha(canonical(payload)), 'payload': payload}
                if args.pack_out.exists():
                    raise Incomplete('Refusing to overwrite an existing prepared pack; choose a new versioned path')
                pending = json.dumps(pack, ensure_ascii=False, indent=2).encode() + b'\n'
            else:
                ctx.require(pack['payload'].get('prepared_units') == prepared, 'PREPARED_CONTENT_CHANGED', 'Derived preparation no longer matches pack')
                raw, final, snapshot = inventory_snapshot(ctx, guard, args.deck, temp, 'candidate')
                report['deck_sha256'] = sha(raw)
                final_units = {native_key(u): u for u in units(final).values()}
                expected_units = {native_key(u['identity']): u for u in prepared if u['declaration'].get('cleared_template_slot') is None}
                ctx.require(set(final_units) == set(expected_units), 'EXPORTED_UNIT_COVERAGE', {'missing': sorted(set(expected_units)-set(final_units)), 'extra': sorted(set(final_units)-set(expected_units))})
                final_ids = {}
                for key, item in expected_units.items():
                    pid = item['identity']['id']
                    final_unit = final_units.get(key)
                    if final_unit is None:
                        continue
                    final_ids[pid] = final_unit['id']
                    ctx.require(final_unit['text'] == item['text'], 'EXPORTED_TEXT_DRIFT', pid)
                report['cleared_template_slots'] = []
                for item in prepared:
                    if item['declaration'].get('cleared_template_slot') is None:
                        continue
                    try:
                        slot = clear_slot(snapshot, item['identity'], guard)
                    except Incomplete as exc:
                        ctx.require(False, 'CLEARED_SLOT_STRUCTURE_OR_TEXT', {'unit': item['identity']['id'], 'reason': str(exc)})
                        report['cleared_template_slots'].append({'identity': item['identity'], 'empty': None,
                                                                'structure_matches': False})
                        continue
                    expected = {**item['cleared_slot'], 'text': ''}
                    ctx.require(slot == expected, 'CLEARED_SLOT_STRUCTURE_OR_TEXT', item['identity']['id'])
                    report['cleared_template_slots'].append({'identity': item['identity'], 'empty': slot['text'] == '',
                                                            'structure_matches': slot == expected})
                report['final_inventory_id_map'] = final_ids
                link_manifest = make_link_manifest(pack, sha(raw), final_ids)
                link_report = guard.guard(snapshot, link_manifest, canon)
                report['notes_anchor_guard'] = link_report
                if link_report['result'] == 'FAIL':
                    ctx.require(False, 'NOTES_ANCHOR_GUARD', link_report['failures'])
                elif link_report['result'] == 'UNVERIFIED':
                    ctx.missing('NOTES_ANCHOR_GUARD', link_report.get('unsupported_content'))
                report['derived_link_manifest'] = link_manifest
    except (OSError, ValueError, KeyError, TypeError, AttributeError, RuntimeError, SyntaxError, BadZipFile) as exc:
        ctx.missing('INCOMPLETE_OR_UNSUPPORTED_EVIDENCE', str(exc))
    ctx.stable()
    outputs = [args.report] + ([args.pack_out] if args.mode == 'prepare' else [])
    output_ok = True
    for path in outputs:
        resolved = path.resolve()
        if resolved in ctx.protected or any(path.exists() and p.exists() and path.samefile(p) for p in ctx.protected):
            output_ok = False
            ctx.require(False, 'OUTPUT_INPUT_COLLISION', str(path))
    if len({p.resolve() for p in outputs}) != len(outputs):
        output_ok = False
        ctx.require(False, 'OUTPUT_PATH_COLLISION', str(outputs))
    report.update(result=ctx.result(), failures=ctx.failures, unverified=ctx.unverified,
                  reference_native_scope=ctx.reference_scope,
                  input_sha256={str(p): sha(raw) for p, raw in ctx.inputs.items()}, candidate_modified=False)
    if pending is not None and report['result'] == 'COMPLETE' and output_ok:
        try:
            write_atomic(args.pack_out, pending)
            report.update(result='PREPARED_CONTENT_BOUND', pack_sha256=sha(pending), pack_bytes=len(pending), pack_path=str(args.pack_out))
        except OSError as exc:
            report.update(result='UNVERIFIED', write_error=str(exc))
    elif report['result'] == 'COMPLETE':
        report['result'] = 'EXPORTED_CONTENT_BOUND'
    if output_ok:
        try:
            write_atomic(args.report, json.dumps(report, ensure_ascii=False, indent=2).encode()+b'\n')
        except OSError as exc:
            report.update(result='FAIL' if ctx.failures else 'UNVERIFIED', write_error=str(exc))
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='mode', required=True)
    for mode in ('prepare', 'check'):
        p = sub.add_parser(mode)
        for field in ('layout', 'reference', 'bank', 'sources', 'report'):
            p.add_argument('--'+field, type=Path, required=True)
        if mode == 'prepare':
            p.add_argument('--spec', type=Path, required=True)
            p.add_argument('--pack-out', type=Path, required=True)
        else:
            p.add_argument('--pack', type=Path, required=True)
            p.add_argument('--pack-sha256', required=True)
            p.add_argument('--deck', type=Path, required=True)
    report = run(parser.parse_args())
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 1 if report['result'] == 'FAIL' else (2 if report['result'] == 'UNVERIFIED' else 0)


if __name__ == '__main__':
    raise SystemExit(main())
