"""Read-only PPTX claim-to-notes hyperlink guard. Python 3 standard library.

This verifies package relationships and reviewer-declared local associations.
It does not identify facts, establish semantic entailment or fetch sources.
"""
import argparse
import hashlib
import json
import posixpath
from pathlib import Path
from urllib.parse import urlsplit
from zipfile import ZipFile, BadZipFile
import xml.etree.ElementTree as ET

NS = {'a':'http://schemas.openxmlformats.org/drawingml/2006/main',
      'p':'http://schemas.openxmlformats.org/presentationml/2006/main',
      'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
RNS = 'http://schemas.openxmlformats.org/package/2006/relationships'
NONFACTUAL = {'title','label','navigation','formatting','source_reference','explicit_proposal','explicit_unknown'}
REL = NS['r'] + '/'
STORY_ROOTS = {'slide': 'sld', 'notesSlide': 'notes', 'slideLayout': 'sldLayout',
               'slideMaster': 'sldMaster', 'notesMaster': 'notesMaster'}
INHERITED = {'slideLayout', 'slideMaster', 'notesMaster'}


class Unsupported(ValueError):
    """The bounded checker cannot complete this package/input."""


def xml(raw, part):
    if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
        raise Unsupported('DTD/entity-bearing XML is unsupported: '+part)
    return ET.fromstring(raw)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def valid_https_url(value):
    """Syntax gate shared by actual citations and reviewer canonical targets."""
    if not isinstance(value,str) or not value or '\\' in value:
        return False
    if any(c.isspace() or ord(c)<32 or ord(c)==127 for c in value):
        return False
    try:
        parsed=urlsplit(value)
        if parsed.scheme!='https' or not parsed.hostname or '@' in parsed.netloc:
            return False
        # Accessing port also validates nonnumeric and out-of-range values.
        port=parsed.port
        if (port is not None and not 1<=port<=65535) or parsed.netloc.endswith(':'):
            return False
        if '%' in parsed.hostname:
            return False
        return True
    except ValueError:
        return False


def relationships(z, part):
    relpart = posixpath.join(posixpath.dirname(part), '_rels', posixpath.basename(part)+'.rels')
    if relpart not in z.namelist(): return {}
    result = {}
    root = xml(z.read(relpart), relpart)
    if root.tag != '{'+RNS+'}Relationships':
        raise Unsupported('Unsupported relationships namespace: '+relpart)
    for r in root:
        if r.tag != '{'+RNS+'}Relationship':
            raise Unsupported('Unsupported relationship element: '+relpart)
        rid = r.get('Id')
        if not rid or rid in result: raise Unsupported('Missing/duplicate relationship ID in '+relpart)
        mode = r.get('TargetMode','Internal'); target = r.get('Target','')
        if mode not in {'Internal','External'} or not target:
            raise Unsupported('Missing target or unsupported relationship mode: '+relpart)
        resolved = target if mode == 'External' else posixpath.normpath(posixpath.join(posixpath.dirname(part),target)).lstrip('/')
        if mode != 'External' and resolved.startswith('../'): raise Unsupported('Relationship escapes package')
        full_type = r.get('Type','')
        result[rid] = {'type':full_type, 'mode':mode,'target':target,'resolved':resolved}
    return result


def paragraphs(z, part, prefix):
    doc = xml(z.read(part), part); rels = relationships(z,part); records = []
    for ordinal,p in enumerate(doc.findall('.//a:p',NS),1):
        # Preserve native explicit breaks as well as text; the deck hash pins all
        # non-text bytes, including field instructions and styling.
        text = ''.join((t.text or '') if t.tag=='{'+NS['a']+'}t' else '\n'
                       for t in p.iter() if t.tag in {'{'+NS['a']+'}t','{'+NS['a']+'}br'})
        if not text.strip(): continue
        anchors = []
        for run in list(p):
            label = ''.join(t.text or '' for t in run.findall('.//a:t',NS))
            for h in run.findall('.//a:hlinkClick',NS):
                rid=h.get('{'+NS['r']+'}id',''); r=rels.get(rid)
                valid = False; navigation = None; problem = None
                action = h.get('action','')
                if not r or not label.strip():
                    problem = 'missing_relationship_or_label'
                elif r['type']==REL+'hyperlink' and r['mode']=='External':
                    try:parsed=urlsplit(r['target'])
                    except ValueError:parsed=None
                    if parsed is None:
                        problem='malformed_external_target'
                    elif action:
                        problem='external_link_with_action_unsupported'
                    elif any(c.isspace() or ord(c)<32 or ord(c)==127 for c in r['target']) or '\\' in r['target']:
                        problem='invalid_external_target_characters'
                    elif valid_https_url(r['target']):
                        valid=True
                    elif parsed.scheme=='https':
                        problem='invalid_https_source_target'
                    elif parsed.scheme=='http' and parsed.hostname:
                        navigation='external_http_navigation'
                    elif parsed.scheme=='mailto' and parsed.path and '@' in parsed.path:
                        navigation='mailto_contact'
                    else:
                        problem='unsupported_external_target'
                elif r['type']==REL+'slide' and r['mode']=='Internal' and r['resolved'] in z.namelist():
                    if action not in {'','ppaction://hlinksldjump'} or xml(z.read(r['resolved']),r['resolved']).tag!='{'+NS['p']+'}sld':
                        problem='unsupported_internal_navigation'
                    else:
                        navigation='internal_slide_navigation'
                else:
                    problem='invalid_relationship_type_or_mode'
                anchors.append({'rid':rid,'label':label,'relationship':r,
                    'valid_external_https_anchor':valid,'citation_eligible':valid,
                    'non_citation_navigation':navigation,'problem':problem,'action':action})
        records.append({'id':prefix+'-p'+str(len(records)+1).zfill(3),'part':part,
                        'native_paragraph_ordinal':ordinal,'text':text,'text_sha256':sha(text.encode()),'anchors':anchors})
    return records


def inventory(deck):
    result={'schema':'ppt-notes-inventory-0.1','deck_sha256':sha(deck.read_bytes()),'slides':[],
            'source_truth':'NOT_CHECKED','unsupported_content':[],
            'scope':'Inline slide/notes and potentially inherited layout/master DrawingML text; visibility of inherited text is reviewer-determined.',
            'limits':['Images and binary embedded-media contents are not inspected.','Field calculation and actual inherited-placeholder visibility require rendering.']}
    with ZipFile(deck) as z:
        names=z.namelist()
        if len(names)!=len(set(names)): raise Unsupported('Duplicate ZIP members')
        if len(names)>10000 or sum(x.file_size for x in z.infolist())>250_000_000:
            raise Unsupported('Package exceeds bounded parser limits')
        prs='ppt/presentation.xml'
        doc=xml(z.read(prs),prs)
        if doc.tag!='{'+NS['p']+'}presentation':
            raise Unsupported('Only Transitional PresentationML is supported')
        def expected(part,kind):
            if xml(z.read(part),part).tag!='{'+NS['p']+'}'+STORY_ROOTS[kind]:
                raise Unsupported('Unexpected '+kind+' story root: '+part)
        def inherited_and_unsupported(start, slide_number):
            pending=[start];seen=set();queued={start}; inherited=[]
            while pending:
                part=pending.pop()
                if part in seen:continue
                seen.add(part)
                for relation in relationships(z,part).values():
                    if relation['mode']!='Internal':continue
                    typ=relation['type'];target=relation['resolved']
                    if typ in {REL+'slide',REL+'notesSlide',REL+'hyperlink'}:continue
                    if target not in names:raise Unsupported('Missing related part: '+target)
                    if typ in {REL+k for k in INHERITED}:
                        kind=typ[len(REL):];expected(target,kind)
                        if target not in queued:
                            queued.add(target)
                            pref='s'+str(slide_number)+'-inherited-'+Path(target).stem
                            for record in paragraphs(z,target,pref):
                                record['visibility']='POTENTIALLY_INHERITED_REVIEW_REQUIRED'
                                inherited.append(record)
                            pending.append(target)
                    elif target.endswith('.xml'):
                        related=xml(z.read(target),target)
                        narrative=any(e.tag in {'{'+NS['a']+'}p','{'+NS['a']+'}t',
                            '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t'} for e in related.iter())
                        diagram_type=typ in {REL+'chart',REL+'diagramData',REL+'diagramDrawing'}
                        if narrative or diagram_type:
                            result['unsupported_content'].append({'slide':slide_number,'part':target,
                                'relationship_type':typ,'reason':'Linked narrative is outside the supported inventory; do not treat it as covered.'})
            return inherited
        prs='ppt/presentation.xml'; rels=relationships(z,prs); used_notes=[]
        for i,s in enumerate(doc.findall('.//p:sldId',NS),1):
            r=rels[s.get('{'+NS['r']+'}id')]
            if r['type']!=REL+'slide' or r['mode']!='Internal': raise Unsupported('Invalid slide relationship')
            part=r['resolved']; sr=relationships(z,part)
            expected(part,'slide')
            notes=[x['resolved'] for x in sr.values() if x['type']==REL+'notesSlide' and x['mode']=='Internal']
            row={'slide':i,'part':part,'visible':paragraphs(z,part,'s'+str(i)+'-visible'),
                 'inherited':inherited_and_unsupported(part,i),'notes_parts':notes,'notes':[],'notes_backlink_correct':False}
            if len(notes)==1:
                expected(notes[0],'notesSlide')
                nr=relationships(z,notes[0])
                navigation_ids={h.get('{'+NS['r']+'}id') for h in xml(z.read(notes[0]),notes[0]).findall('.//a:hlinkClick',NS)}
                # Explicit slide-jump links are not additional ownership backlinks.
                back={x['resolved'] for rid,x in nr.items() if x['type']==REL+'slide' and x['mode']=='Internal'
                      and (rid not in navigation_ids or x['resolved']==part)}
                row['notes_backlink_correct']=back=={part}; row['notes']=paragraphs(z,notes[0],'s'+str(i)+'-notes');used_notes.append(notes[0])
                row['inherited']+=inherited_and_unsupported(notes[0],i)
            result['slides'].append(row)
        result['notes_parts_unique']=len(used_notes)==len(set(used_notes))
        if not result['slides']:raise Unsupported('Presentation has no supported slides')
        unit_ids=[p['id'] for s in result['slides'] for p in s['visible']+s['notes']+s['inherited']]
        if len(unit_ids)!=len(set(unit_ids)):
            raise Unsupported('Inventory paragraph ID collision; coverage cannot be certified')
    result['inventory_result']='UNVERIFIED' if result['unsupported_content'] else 'INVENTORY_ONLY'
    return result


def guard(deck, manifest, sources):
    if not isinstance(manifest,dict) or not isinstance(sources,dict):
        raise Unsupported('Manifest and source inventory must be JSON objects')
    inv=inventory(deck); failures=[]; associations=[]
    def require(ok,code,detail):
        if not ok: failures.append({'code':code,'detail':detail})
        return bool(ok)
    require(manifest.get('schema')=='ppt-notes-claim-manifest-0.1','MANIFEST_SCHEMA','Expected ppt-notes-claim-manifest-0.1')
    require(manifest.get('deck_sha256')==inv['deck_sha256'],'STALE_DECK','Reviewer manifest must pin exact final deck bytes')
    review=manifest.get('review',{})
    require(review.get('complete') is True and isinstance(review.get('reviewer'),str) and bool(review['reviewer'].strip()) and review.get('claims_split') is True,'REVIEW_INCOMPLETE','Named reviewer must attest all paragraphs were reviewed and distinct material claims split; no automatic completeness inference')
    require(sources.get('schema')=='reviewed-source-inventory-0.1' and sources.get('reviewer_confirmed') is True,'SOURCE_INVENTORY_UNREVIEWED','Require separate reviewer-confirmed canonical source inventory')
    srcs=sources.get('sources',[]); ids=[s.get('id')for s in srcs]
    require(len(ids)==len(set(ids)),'DUPLICATE_SOURCE_ID','Canonical source IDs must be unique')
    canonical={s.get('id'):s for s in srcs}
    entries=manifest.get('paragraphs',[]); mids=[p.get('id')for p in entries]
    require(len(mids)==len(set(mids)),'DUPLICATE_PARAGRAPH','Each reviewed paragraph occurs once')
    mapped={p.get('id'):p for p in entries}; actual={p['id']:p for s in inv['slides']for p in s['visible']+s['notes']+s['inherited']}
    require(set(mapped)==set(actual),'PARAGRAPH_COVERAGE',{'missing':sorted(set(actual)-set(mapped)),'extra':sorted(set(mapped)-set(actual))})
    require(inv['notes_parts_unique'],'SHARED_NOTES_PART','Used slides must not share a notes part')
    for s in inv['slides']:
        require(len(s['notes_parts'])==1 and s['notes_backlink_correct'],'NOTES_LINKAGE','Slide '+str(s['slide'])+' needs one correctly linked notes part')
        for p in s['notes']:
            for a in p['anchors']:require(a['problem'] is None,'INVALID_ACTUAL_ANCHOR',{'paragraph':p['id'],'rid':a['rid'],'problem':a['problem']})
    claim_ids=[]
    for pid,p in actual.items():
        item=mapped.get(pid)
        if item is None: continue
        require(item.get('text_sha256')==p['text_sha256'],'STALE_PARAGRAPH',pid)
        disposition=item.get('disposition')
        if disposition=='nonfactual':
            require(item.get('reason') in NONFACTUAL and isinstance(item.get('explanation'),str) and bool(item['explanation'].strip()),'UNEXPLAINED_EXEMPTION',pid)
            require(not item.get('claims'),'MIXED_DISPOSITION',pid)
            continue
        if not require(disposition=='claims' and isinstance(item.get('claims'),list) and bool(item['claims']),'UNREVIEWED_PARAGRAPH',pid): continue
        slide_prefix=pid.split('-')[0]+'-notes-'
        for c in item['claims']:
            cid=c.get('id');claim_ids.append(cid)
            require(isinstance(cid,str) and bool(cid.strip()),'MISSING_CLAIM_ID',pid)
            quote=c.get('quote');require(isinstance(quote,str) and bool(quote.strip()) and quote in p['text'],'CLAIM_QUOTE_NOT_LOCAL',{'paragraph':pid,'claim':cid})
            ev=c.get('evidence',[])
            if not require(isinstance(ev,list) and bool(ev),'MISSING_CLAIM_SOURCE',{'paragraph':pid,'claim':cid}): continue
            for e in ev:
                n_id=e.get('notes_paragraph'); n=actual.get(n_id,{}); source=canonical.get(e.get('source_id'),{})
                require(isinstance(n_id,str) and n_id.startswith(slide_prefix) and bool(n),'SOURCE_NOT_LOCAL_TO_SLIDE',{'claim':cid,'notes_paragraph':n_id})
                require(source.get('kind')=='direct_content' and bool(source.get('url')),'SOURCE_NOT_DIRECT_REVIEWED_CONTENT',{'claim':cid,'source_id':e.get('source_id')})
                source_url=source.get('url','')
                require(valid_https_url(source_url) and urlsplit(source_url).path.rstrip('/') not in ('','/wiki'),'GENERIC_OR_INVALID_SOURCE_URL',{'claim':cid,'url':source_url})
                assoc=e.get('association_quote')
                require(isinstance(assoc,str) and bool(assoc.strip()) and assoc in n.get('text',''),'ASSOCIATION_TEXT_NOT_LOCAL',{'claim':cid,'notes_paragraph':n_id})
                anchors=[a for a in n.get('anchors',[]) if a['rid']==e.get('rid') and a['label']==e.get('anchor_label')]
                valid=any(a['valid_external_https_anchor'] and a['relationship']['target']==source.get('url') for a in anchors)
                require(valid,'NO_MATCHING_ACTUAL_SOURCE_ANCHOR',{'claim':cid,'notes_paragraph':n_id,'rid':e.get('rid'),'source_id':e.get('source_id')})
                associations.append({'claim':cid,'paragraph':pid,'notes_paragraph':n_id,'source_id':e.get('source_id'),'actual_anchor_match':valid,'semantic_entailment':'NOT_CHECKED','association_basis':'REVIEWER_DECLARED_LOCAL_TEXT'})
    require(len(claim_ids)==len(set(claim_ids)),'DUPLICATE_CLAIM_ID','Material claims must have unique IDs')
    require(bool(claim_ids),'NO_SOURCE_CLAIMS','A zero-claim manifest cannot certify a sourced deck; use not-applicable review separately')
    result='FAIL' if failures else ('UNVERIFIED' if inv['unsupported_content'] else 'PASS_LINK_COVERAGE_FOR_REVIEWED_MANIFEST')
    navigation=[{'paragraph':p['id'],'rid':a['rid'],'label':a['label'],'kind':a['non_citation_navigation'],'citation_eligible':False}
                for s in inv['slides'] for p in s['notes'] for a in p['anchors'] if a['non_citation_navigation']]
    return {'schema':'ppt-notes-source-guard-report-0.2','result':result,
        'deck_sha256':inv['deck_sha256'],'candidate_modified':False,
        'source_truth':'NOT_CHECKED','manifest_completeness':'REVIEWER_ATTESTED_NOT_INFERRED',
        'semantic_entailment':'NOT_CHECKED','slide_count':len(inv['slides']),
        'paragraph_count':len(actual),'claim_count':len(claim_ids),
        'actual_notes_anchor_count':sum(len(p['anchors'])for s in inv['slides']for p in s['notes']),
        'eligible_notes_source_anchor_count':sum(a['citation_eligible'] for s in inv['slides'] for p in s['notes'] for a in p['anchors']),
        'notes_parts_unique':inv['notes_parts_unique'],'non_citation_navigation':navigation,
        'unsupported_content':inv['unsupported_content'],
        'unsupported_content_status':'UNVERIFIED' if inv['unsupported_content'] else 'NONE_DETECTED_IN_BOUNDED_SCAN',
        'failures':failures,'associations':associations,
        'manifest_canonical_sha256':sha(json.dumps(manifest,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()),
        'sources_canonical_sha256':sha(json.dumps(sources,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()),
        'limits':['The guard cannot decide whether a reviewer misclassified a fact as nonfactual or omitted a distinct claim within a paragraph.',
            'Inherited layout/master text is conservatively inventoried; actual visibility needs reviewer/render confirmation.',
            'A valid actual link and local association do not prove source truth, current deployment, semantic support or URL accessibility.',
            'Images/binary media, rendering and template parity are separate checks.']}


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('deck',type=Path);ap.add_argument('--manifest',type=Path);ap.add_argument('--sources',type=Path);ap.add_argument('--report',type=Path,required=True);ap.add_argument('--inventory-only',action='store_true');args=ap.parse_args()
    provenance={'script_sha256':sha(Path(__file__).read_bytes()),'script_bytes':Path(__file__).stat().st_size}
    writable_report=False
    try:
        inputs=[x for x in [args.deck,args.manifest,args.sources] if x]
        paths=[x.resolve() for x in inputs+[args.report]]
        protected=inputs+[Path(__file__)]
        if len(paths)!=len(set(paths)) or args.report.resolve()==Path(__file__).resolve() or any(args.report.exists() and x.exists() and args.report.samefile(x) for x in protected):
            raise Unsupported('Deck, manifest, sources and report must be different files; report cannot overwrite the script')
        writable_report=True
        raw_inputs={}
        for label,path in [('deck',args.deck),('manifest',args.manifest),('sources',args.sources)]:
            if path is not None:
                raw_inputs[label]=path.read_bytes()
                provenance[label+'_sha256']=sha(raw_inputs[label])
        if args.inventory_only:
            report=inventory(args.deck)
            report['result']=report['inventory_result']
        else:
            if not args.manifest or not args.sources:raise Unsupported('--manifest and --sources are required for a coverage check')
            def no_duplicate_keys(pairs):
                out={}
                for key,value in pairs:
                    if key in out:raise Unsupported('Duplicate JSON key: '+key)
                    out[key]=value
                return out
            report=guard(args.deck,json.loads(raw_inputs['manifest'],object_pairs_hook=no_duplicate_keys),
                         json.loads(raw_inputs['sources'],object_pairs_hook=no_duplicate_keys))
        for label,path in [('deck',args.deck),('manifest',args.manifest),('sources',args.sources)]:
            if path is not None and sha(path.read_bytes())!=provenance[label+'_sha256']:
                raise Unsupported(label+' changed during validation; rerun against final stable inputs')
    except (OSError,ValueError,KeyError,TypeError,AttributeError,RuntimeError,BadZipFile,ET.ParseError) as exc:
        report={'schema':'ppt-notes-source-guard-report-0.2','result':'UNVERIFIED',
                'source_truth':'NOT_CHECKED','semantic_entailment':'NOT_CHECKED',
                'reason':str(exc),'candidate_modified':False}
    report.update(provenance)
    if writable_report:
        try:
            args.report.parent.mkdir(parents=True,exist_ok=True)
            args.report.write_text(json.dumps(report,indent=2)+'\n')
        except OSError as exc:
            report['result']='UNVERIFIED';report['report_write_error']=str(exc)
    # Complete structured output is still available when an unsafe/unwritable report path is rejected.
    print(json.dumps(report,indent=2))
    return 2 if report.get('result')=='UNVERIFIED' else (1 if report.get('result')=='FAIL' else 0)


if __name__=='__main__':raise SystemExit(main())
