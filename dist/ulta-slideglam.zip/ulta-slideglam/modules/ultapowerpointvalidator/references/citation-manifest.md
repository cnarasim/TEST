# Reviewer-owned citation manifest

This guard proves only actual package hyperlink coverage for an explicit, final-file-bound reviewed manifest. Source truth, accessibility, semantic entailment, actual visibility and completeness of a reviewer's judgement remain separate. The guard does not fetch URLs or identify factual claims automatically. Never manufacture a reviewer attestation or label an inconvenient factual claim as a title/proposal to pass.

## Work from the exact final PPTX

```text
python scripts/pptx_source_links.py final.pptx --inventory-only --report inventory.json
python scripts/pptx_source_links.py final.pptx --manifest reviewed-manifest.json --sources reviewed-sources.json --report source-links-report.json
```

The inventory follows actual presentation order and reads inline DrawingML paragraphs in slides and notes, plus potentially inherited slide-layout, slide-master and notes-master paragraphs. Each unit has a stable ID for these exact bytes, source part, native paragraph ordinal, text and text SHA256. Explicit `a:br` is a newline. Paragraph IDs count nonempty units; do not calculate them from a guessed slide filename. The deck hash also pins whitespace, style, relationships and unrepresented package bytes.

Inherited text is deliberately conservative: `POTENTIALLY_INHERITED_REVIEW_REQUIRED` does **not** mean the placeholder/sample is actually visible on the candidate. Review the candidate and source render and explicitly classify each inherited unit. Repeated identical boilerplate may be reviewed as a group by exact part/text, but every returned unit ID still needs an explicit entry. Never exempt a visible inherited fact as generic boilerplate. Actual placeholder resolution remains outside the guard.

Linked chart/SmartArt/diagram/other XML narrative outside the bounded inventory yields `UNVERIFIED`; it cannot silently pass through an inline-only manifest. Images and binary embedded-media contents, source document contents, speaker notes rendering and field calculations are not read semantically. Review these separately and disclose any unverified material content.

## Manifest schema

Top-level schema is `ppt-notes-claim-manifest-0.1`. Use the exact deck SHA256 and all returned paragraph IDs/text hashes:

```json
{
  "schema": "ppt-notes-claim-manifest-0.1",
  "deck_sha256": "SHA256_OF_FINAL_PPTX",
  "review": {"complete": true, "reviewer": "Named actual reviewer", "claims_split": true},
  "paragraphs": [
    {
      "id": "s1-visible-p001",
      "text_sha256": "EXACT_INVENTORY_TEXT_HASH",
      "disposition": "claims",
      "claims": [{
        "id": "claim-unique-001",
        "quote": "Exact local material claim text",
        "evidence": [{
          "source_id": "SRC-1",
          "notes_paragraph": "s1-notes-p001",
          "rid": "rId2",
          "anchor_label": "Exact linked run label",
          "association_quote": "Exact local notes text associating this claim and source"
        }]
      }]
    }
  ]
}
```

This fragment is explanatory, not a complete manifest. `examples/fictional-positive.manifest.json` is a complete fixture example. Review notes claims as well as visible claims. Split distinct material claims; each claim needs one or more explicit evidence associations, and **every** declared association must pass. It is not enough to have one link per slide, a sources paragraph elsewhere, the word “Confluence,” a displayed URL, or an invented relationship ID.

An association must reference actual notes text on the **same slide**, an existing exact relationship ID and exact linked run label, and the exact canonical source URL. The guard checks those strings and relations; it does not prove that the quoted source supports the claim. The same source may legitimately support multiple claims, but claims keep separate IDs and explicit evidence sets. Notes reference paragraphs containing factual statements also require claim review. Use nonfactual `source_reference` only for true labels/URLs with no material factual assertion.

A genuinely nonfactual unit is represented as:

```json
{"id":"s1-visible-p002","text_sha256":"EXACT_HASH","disposition":"nonfactual","reason":"label","explanation":"Reviewer confirmed this is only the navigation label for the next section."}
```

Allowed reasons: `title`, `label`, `navigation`, `formatting`, `source_reference`, `explicit_proposal`, `explicit_unknown`. An explicit proposal/unknown exemption is justified only when the complete unit is a clearly marked proposal/unknown statement, not a documented claim combined with one of those words. A factual headline is not automatically exempt because it is a title. The code cannot detect dishonest or mistaken exemptions. No blanket exemption and no zero-claim certification are allowed. Partial review uses `complete:false` and must remain failed/incomplete; it may still establish a specific missing-anchor defect.

## Independent source inventory

```json
{
  "schema": "reviewed-source-inventory-0.1",
  "reviewer_confirmed": true,
  "sources": [{
    "id": "SRC-1",
    "url": "https://example.invalid/evidence/fictional-01",
    "kind": "direct_content",
    "title": "Fictional example source"
  }]
}
```

Use a separately reviewed ledger of direct primary URLs, with exact strings matching the final hyperlink targets. The illustrated `.invalid` host is fictional and is never fetched. Do not mark a URL reviewed simply because it appeared in generated prose. Generic host and `/wiki` roots are rejected, but the checker cannot recognize every generic landing page; the reviewer owns direct-content classification, source correctness, version/status/date scope and accessibility. An enterprise tenant path must come from actual retrieved evidence, not invention.

## Actual anchor and navigation rules

Source anchors require the complete official Transitional OOXML hyperlink relationship URI, External mode, a syntactically valid HTTPS hostname/port, nonempty exact linked label and no click action. One shared HTTPS syntax function is used for both actual anchors and canonical source URLs: credentials (including empty user information), backslashes, whitespace/control/DEL, missing hosts and invalid/empty/zero/out-of-range ports are rejected. Valid explicit ports and IPv6 literal hosts are supported. Relationship suffixes such as an unrelated URI ending `/hyperlink` are rejected. Notes ownership/backlinks must be correct and used slides cannot share one notes part.

Ordinary supported `mailto:` contact links, HTTP navigation and internal slide-jump links are recorded separately and never satisfy a source requirement. They do not invalidate other correct citations merely for being non-source links. Unsupported or malformed notes links still produce a finding. The guard cannot establish that a URL is safe/reachable or that contact/navigation labels are semantically accurate.

## Outcomes and final-byte provenance

- Exit **0**, `PASS_LINK_COVERAGE_FOR_REVIEWED_MANIFEST`: all declared coverage/link checks passed, with reviewer completeness attested rather than inferred. This is not semantic or visual approval.
- Exit **0**, `INVENTORY_ONLY`: inventory succeeded; no claim coverage was checked.
- Exit **1**, `FAIL`: a known coverage, relationship, stale hash or review requirement failed.
- Exit **2**, `UNVERIFIED`: unsupported/malformed content, incomplete execution or unsafe output path prevented certification. When a known guard failure and unsupported linked content coexist, overall result stays FAIL; unsupported_content_status separately remains UNVERIFIED. Neither finding may be discarded.

CLI reports include exact raw deck/manifest/source/script SHA256 values and script byte length. Guard reports also include canonical-JSON manifest/source hashes. Save the literal command, exit code and raw JSON together. An error before an input could be read has no invented hash for that input. JSON parse errors, duplicate keys and corrupt packages produce structured `UNVERIFIED`; stdout retains the report if a report path is unsafe/unwritable. The tool never overwrites its input files and does not mutate a deck.

After any final save, recompute the inventory and reviewer bindings against the new bytes and rerun. A prior report is stale even when only a hyperlink or styling changed. The manifest/source ledger remain reviewer-owned inputs; their matching hashes establish provenance, not the quality of their claims. `source_truth` and `semantic_entailment` stay `NOT_CHECKED` in every outcome.
