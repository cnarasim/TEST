# Source-relative picture-clearance gate

The original template validator remains byte-for-byte unchanged. This separate gate imports that exact hash-verified module and reuses its geometry and embedded numeric font metrics:

```text
python scripts/pptx_artwork_clearance.py approved-reference.pptx final.pptx --mapping SOURCE_NUMBERS --report artwork-clearance.json
```

Use the actual deck construction mapping, identical to the mapping used for the original validator. Original structural checks must pass before clearance is compared. The gate checks modelled text-line rectangles against retained picture rectangles on the same source-relative geometry. It flags positive overlap greater than source overlap by more than **0.01 pt²**, a rounding tolerance rather than an accepted visual intrusion. It therefore catches small newly introduced picture intrusions hidden by the broader checker's 8/12 pt² thresholds.

`NEEDS_REVIEW` (exit1) requires correction or actual source/candidate render adjudication. `NO_MODELLED_ARTWORK_REGRESSION` (exit0) means only no modelled increase. `UNVERIFIED` (exit2) reports structural differences, unresolved geometry or execution errors. Raw metric warnings are retained per region. Neither the no-regression outcome nor a numeric tolerance permits a known rendered defect to be waived.

The picture rectangle includes transparent whitespace. Line rectangles are metric estimates rather than exact glyph silhouettes. A false positive is possible, and native font parity is unverified. Existing source collisions, small positive clearances, enclosing background pictures, non-picture shape artwork, grouped/rotated geometry the original module cannot model, bold selection and contextual shaping are not certified. The gate cannot prove a minimum native clearance. Preserve the template artwork, fonts and geometry; shorten the label or choose another approved layout, then rerun and render.

Regression evidence: the unchanged R6 slide 5 `Evidence` label has **2.118903 pt²** modelled intrusion into retained picture12, versus **0** for source `Action`. A test-only copy changing just this label back to `Action` has no modelled artwork regression. The source template compared to itself has no increased intrusion, while unresolved source geometry remains `UNVERIFIED`. These are controls for this bounded gate, not certification of arbitrary artwork or the source template's rendering.
