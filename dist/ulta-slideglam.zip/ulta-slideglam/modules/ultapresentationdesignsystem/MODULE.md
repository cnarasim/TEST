---
name: ultapresentationdesignsystem
description: Preserves the exact Ulta Beauty PPT Standard.pptx slide designs, typography, branding and structure. Maps content to source slides and rejects generic substitutes.
---

> v12 NOTE: SKILL.md wins where this conflicts - decks are built with tools/build_deck.py, headlines are full width, autofit.py may reduce font sizes to prevent overflow, and no intake questions are required.

<!-- bic:source=blank -->
# Authority
Use the owner-approved Ulta Beauty PPT Standard.pptx binary as the governing visual standard for every PowerPoint. The pinned reference has 33 slides, dimensions 12192000 x 6858000 EMU, SHA-256 46e7c3bda4bf611cb7d1903c7c3d7b1ccffc6ddd73246919b5559894110a2c95. Agent instructions define source access and version handling. This skill implements the template; it never overrides it.

# Inspect and map
Inspect source slides and their actual masters, layouts, placeholder geometry, text styles, theme, colors, logos, artwork and footer. Map every output slide to a specific source slide. Useful source slides: 1 cover; 2 agenda; 5/23 dividers; 6 two-column content; 7 comparison; 8 chart with supporting details; 9 three metrics; 10 hypothesis/action; 11 results/learnings/actions; 12 what/description/when-who; 13 four metrics; 14 comparison matrix; 15-20 timelines; 21 detailed metrics/status; 22 geography; 24 priorities; 25 OGSM; 26 funnel; 28-31 icons; 32-33 closing. Choose by the actual content need.

# Preserve
Duplicate source slide structures, then replace relevant content in place. Preserve background, geometry, card/table structure, logo, footer and native fonts. Do not strip all source slide content and rebuild a new deck from blank layouts. The source includes Circular Std Book/Medium/Bold, Chronicle Deck Semi and Playfair Display variants plus theme styles. Preserve the selected slide's real font hierarchy; do not normalize it to Calibri or another substitute. Formatting labels on slide 3 are guidance, not permission to overwrite actual source formatting across slides. Likewise use actual template fills and text colors rather than approximating from written RGB labels.

No generic secondary-blue palette, new brand theme, fixed 20/70/10 layout, fixed visual/text percentage, or mandatory icon on every slide. Tables and restrained text layouts from the reference are approved. Retain its light background, orange/magenta/berry accents and branded footer as used by each selected slide. No added red body text or executive lifestyle photos. Preserve approved cover artwork.

# Validation
Compare every exported slide to its mapped reference. Check dimensions, theme/layout relationships, logo, footer, artwork, fonts, colors, spacing and geometry. A similar palette alone is insufficient. If the binary or required rendering/fonts are unavailable, record the actual limitation and do not claim strict template verification.

# Exact typography acceptance
Strict typography is a constraint, not a preference: preserve each mapped source object's actual font family, weight, point size, paragraph spacing and text-box/table geometry. Do not reduce point sizes or use shrink-to-fit to satisfy content density, even when calculated to fit. Inspect per-cell styles instead of assuming one size for an entire table. Source slide 12 specifically uses 18 pt Circular Std Medium headers, 20 pt Playfair Display Black in the What data column, and 16 pt Circular Std Book in the Description and When / Who data columns; retain the actual source run properties. Fit content through supported concise wording and line breaks without losing facts, or choose another suitable source layout/continuation if allowed. If required visible details, fixed slide count and source typography cannot all fit, state that conflict and request the necessary tradeoff; do not quietly change the template. A known point-size deviation is a failed template check, not merely pending visual verification.

Apply exact style checks to EVERY text object, including covers, slide headlines, subtitles, captions and footnotes, not only table cells. Added text boxes cannot bypass the standard: use an appropriate existing source region or speaker notes for metadata. Shorten a headline while preserving meaning instead of reducing its source size. A deviation anywhere in the deck makes overall template acceptance BLOCKED until repaired; passing table checks does not erase a changed headline or other known deviation.

Inspect and copy the full raw source slide shape tree and all relevant relationships, including pictures, grouped objects, SVG/EMF artwork, alternate content and fallback assets. Never restrict copying to tables, text objects or a preprocessor summary. Preserve non-placeholder objects and their source z-order. Source slide 12 includes three header SVG picture objects before What, Description and When / Who; they must remain in each duplicated slide. Verify every source/output picture count, original media hash, placement, size, style and relationship resolution as well as text. A retained master or successful text-only test does not prove source artwork survived. Use measured metrics from the actual fonts for text-fit checks; substitute-font estimates cannot prove that the required fonts will fit or are narrower.