---
name: visualexperience
description: Native layout for PPTX, Word, HTML and editable XML. Preserves exact PowerPoint source design, constructs readable Word tables with matching grids/cells, and prepares exported artifacts for real visual review.
---

> v12 NOTE: SKILL.md wins where this conflicts - decks are built with tools/build_deck.py, headlines are full width, autofit.py may reduce font sizes to prevent overflow, and no intake questions are required.

<!-- bic:source=blank -->
# Scope and priorities
Design the requested PPTX, DOCX, HTML or editable XML in its native format. Use the format-specific rules below. Preserve all required facts, qualifications and editability. User constraints and the owner-approved PowerPoint binary control over generic design preferences.

# Evidence before layout
Use the research ledger. For technical identities, producer ownership, interfaces, process variants or current status, open relevant available primary specifications linked from summaries or illustrative diagrams. Read their bodies and record date, version and supported scope. Correct unsupported secondary-source implications; if retrieval fails, record the attempted source and limit or omit the claim. Keep recommendations, uncertain values and historical practices qualified where they appear.
Place direct clickable source citations beside researched claims, including issue-key links in record tables. Include source title/date/version and scope in a register. The register supplements local citations. In PowerPoint, use an existing source-note region or cited speaker notes without altering the governing layout.

# PowerPoint layout
Map every slide to an actual source slide in Ulta Beauty PPT Standard.pptx. Preserve its full shape tree, masters/layout/theme relationships, geometry, fonts, per-run and per-cell point sizes, colors, spacing, logo, footer and artwork. Use the source layout's native tables, charts, timelines or icons when they express the supported content. Retain source media, including grouped and SVG/EMF objects, with their relationships and z-order.
Preserve the exact requested slide count. Fit content through concise supported wording, a suitable source layout, or an allowed continuation/notes; keep decision-critical details visible. Do not shrink source typography, expand source table rows, invent a theme or flatten the slide to an image. Check covers, headlines, captions and footnotes as carefully as body tables. Return the source-slide mapping and any unresolved fit conflict to assembly.

# Word structure and typography
Use an available native DOCX capability. Create editable text and tables with Word Title, Heading 1 and Heading 2 styles. Keep titles/headings black and remove inherited and direct paragraph borders. Use at least 11pt for body text, headings, captions, references and headers; at least 10pt in tables; footers and page fields may use readable 10pt. This is a Word-specific exception. An explicit controlling Word template may set different typography; PowerPoint rules do not control Word pages.
Lead with the conclusion or decision and use connected explanatory prose. Use tables for repeated comparable records. Set deliberate margins, cell padding, repeated header rows and no-split ordinary rows. Keep headings/captions with the following content. Before allocating narrative width, list the longest short ID, status word and mode token in each column. Give each column enough usable width for those complete tokens in the final font, including cell padding. If the table exceeds usable page width, combine redundant columns or change its native organization while preserving all fields and font floors.

# Word table construction
Calculate widths in twips within the section's usable page width. Set fixed layout rather than autofit. Write the SAME widths to w:tblGrid/w:gridCol and each unmerged cell's w:tcPr/w:tcW; table preferred width must equal the grid total. For merged cells, tcW must equal the sum of columns covered by gridSpan; retain valid merge structure.
With python-docx, set table.autofit = False and matching column and cell widths in Twips. This setter creates or updates the singular w:tblLayout; never append another. For other singular table properties use the library setter/get_or_add method, then update its value. After the final save, run ultawordtableguard on the actual DOCX and verify grid/cell totals and spans. Fix the generator and regenerate on failure; do not silently discard duplicate properties.

# HTML and editable XML
Use sourced components and relationships. Distinguish logical zones and process dependencies from verified boundaries and interfaces. Allocate space for readable labels and routes; avoid connectors through nodes, backtracking, overlapping opposing flows and unreadable edge labels. Keep editable structure and advertised interactions usable. Follow the architecture skill for format-specific implementation.

# Render and refine
Reopen the exact export and render every page/slide or view every diagram state with an appropriate real renderer. Inspect readable text, clipping, overlap, wrapping, table proportions, row breaks, stranded headings and near-empty spill pages. Repair actual defects and render the changed artifact again.
An approximate page target permits extra pages for readable complete content. Make one concise planning pass; do not repeatedly tune word-count or font-width estimates. Without a renderer, finish available structural checks, state actual page count and visual quality as unverified, and stop estimating. Pass the exact file and evidence to the reviewer.

# Word citation and pagination implementation
Build one actual hyperlink per source, with punctuation outside links. Every non-header data row needs its own distinct source links, including homogeneous tables. Derive the required set from all factual clauses and premises, including any separate category/path definition needed to interpret a result; A+B needs two correctly labelled and targeted links. Repeated test facts cite their test source in the same paragraph. Other prose may use only an explicitly permitted immediately following citation note. Supplied packets use real source bookmarks; enterprise sources use exact retrieved URLs. Distinguish a bibliographic caption from a claim that all table content comes from one source: support the latter with the complete source set or use a source-neutral caption. Caption/register links never replace row links. Review every exported unit and classification against the full claim ledger; a citation-coverage PASS leaves semantic support NOT_CHECKED.
Keep each source-entry heading and each table caption with its following text/table: chain keep_with_next through intervening citation paragraphs and avoid blank paragraphs that break the chain. Retain a compact token-fit record for each short-ID/status/mode column: tested token, final font/size, cell width, padding and measured width or rendered line result. Use actual available font metrics or inspect the rendered cells; average-character estimates are not fit evidence. Widen or reorganize a failing column without changing identifiers or shrinking fonts. If neither reliable metrics nor a renderer is available, mark token fit UNVERIFIED; preserve all grid/cell-width checks.
After export, inspect each w:hyperlink label, anchor and relationship target against its claim sources, and every anchor against a real bookmark. Inspect all document/header/footer text and field-result runs with inherited sizes resolved. Render all pages for source-entry breaks, short-token wrapping and spill pages; a schema pass is insufficient.

# Rendered Word text preservation
Run ultawordtableguard's native-text versus rendered-PDF check after the final save/render. Confirm every last-table row as well as earlier text. If a repeated-header/no-split table loses rendered rows at a page boundary, move its section/table start to a new page while preserving those properties; render and check again. Treat extraction ambiguity as unverified pending visual inspection. Never remove required row text or weaken table integrity to get a pass.
