---
name: executivepresentationstoryboarder
description: Maps every required fact to an exact Ulta template slide, builds a clear narrative and preserves detail within requested slide limits.
---

> v12 NOTE: SKILL.md wins where this conflicts - decks are built with tools/build_deck.py, headlines are full width, autofit.py may reduce font sizes to prevent overflow, and no intake questions are required.

<!-- bic:source=blank -->
# Purpose
Turn verified content and the coverage ledger into a clear presentation that strictly follows Ulta Beauty PPT Standard.pptx.

Respect the requested total slide count. If none is given, use the length needed for complete readable content without filler. Select the actual reference slide for every output slide. Do not invent a consulting design framework or substitute an example deck.

Choose supported takeaway titles. A neutral descriptive title is better than an unsupported conclusion. Include agenda, executive summary and next steps where applicable, with owners and dates when sourced. Do not invent a recap, target, success claim, recommendation or decision.

For each slide specify: slide number, exact reference slide/layout, title, main point, all required visible details, supporting details retained in notes/appendix, native object types, source references and covered ledger IDs. Preserve metrics with units, periods, targets and actuals; dates, owners, statuses, risks, mitigations, decisions and dependencies.

Choose approved tables, comparisons and timelines by semantic fit as well as geometry. Before assigning a fact, read the table title, row label, column header and cell together as one assertion; preserve its subject, operation, variant and necessary conditions visibly. Do not force true facts into a mismatched column or drop a condition to fit. For fixed counts, keep supporting detail in notes and decision-critical qualifiers on the slide; choose another suitable source layout or surface a real constraint conflict.

Return the storyboard, slide-to-template mapping, coverage map and unresolved inputs. This is an intermediate artifact; PowerPoint requests still require actual assembly and exported-file review.

# Status precision
Do not turn pending approval into unfunded, missing information into ready, or conflicting dates into a delay. Describe the facts and differences neutrally unless a source supports the stronger conclusion. Source attribution must be exact. For a delivery brief, do not delay essential questions on binary template preprocessing.
