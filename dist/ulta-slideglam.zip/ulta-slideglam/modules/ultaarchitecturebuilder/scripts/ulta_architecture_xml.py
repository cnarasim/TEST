#!/usr/bin/env python3
"""Bounded JSON -> editable draw.io author. Standard library only; no network.

Usage: python3 drawio_author.py.txt input.json output.drawio
Optional --report path.json writes the deterministic build checks.
This is a layout helper, not a source-verification or deployment-status engine.
"""
import argparse
import hashlib
import html
import json
from pathlib import Path
import textwrap
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit

PAGE_W, PAGE_H, MARGIN = 1600, 1100, 48
BODY_FONT, LINE_H = 14, 22
BOTTOM = 1025


def source_url(value):
    """Return supplied HTTPS citations only; never repair or infer a target."""
    if not isinstance(value, str) or '\\' in value or any(c.isspace() or ord(c) < 32 or ord(c) == 127 for c in value):
        return None
    try:
        parsed = urlsplit(value)
        parsed.port  # Reject malformed/out-of-range ports without rewriting the URL.
        if parsed.scheme == 'https' and parsed.hostname and parsed.username is None and parsed.password is None:
            return value
    except ValueError:
        pass
    return None


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def scalar(value):
    if isinstance(value, str):
        return value if value else '""'
    return json.dumps(value, ensure_ascii=False)


def fields(value, prefix=''):
    """Readable lossless values; full original JSON is also embedded separately."""
    if isinstance(value, dict) and value:
        for key, item in value.items():
            yield from fields(item, prefix + '.' + key if prefix else key)
    elif isinstance(value, list) and value and any(isinstance(x, (list, dict)) for x in value):
        for index, item in enumerate(value):
            yield from fields(item, prefix + '[' + str(index) + ']')
    else:
        yield (prefix + ': ' if prefix else '') + scalar(value)


def wrapped(lines, width=146):
    output = []
    for line in lines:
        for paragraph in str(line).split('\n'):
            output.extend(textwrap.wrap(paragraph, width=width, replace_whitespace=False,
                                        drop_whitespace=False, break_long_words=True,
                                        break_on_hyphens=False) or [''])
    return output


def brief(value, limit=110):
    text = str(value).replace('\n', ' ')
    return text if len(text) <= limit else text[:limit-1] + '…'


def validate(data):
    if not isinstance(data, dict):
        raise ValueError('Input must be a JSON object.')
    if not isinstance(data.get('title'), str) or not data['title'].strip():
        raise ValueError('A nonempty title is required.')
    for key in ('nodes', 'flows', 'sources'):
        if not isinstance(data.get(key), list):
            raise ValueError(key + ' must be a list.')
    if not data['nodes']:
        raise ValueError('At least one node is required.')
    if len(data['nodes']) > 60 or len(data['flows']) > 100:
        raise ValueError('Bounded prototype limit: 60 nodes / 100 flows. Split larger inputs explicitly.')
    graph_ids = []
    for kind in ('nodes', 'flows'):
        for row in data[kind]:
            if not isinstance(row, dict) or not isinstance(row.get('id'), str) or not row['id']:
                raise ValueError(kind + ' entries require nonempty string id.')
            if len(row['id']) > 80 or any(ord(c) < 32 for c in row['id']):
                raise ValueError('IDs must be at most80 characters and contain no control characters.')
            if not isinstance(row.get('label'), str) or not row['label'].strip():
                raise ValueError(row['id'] + ': a nonempty label is required.')
            graph_ids.append(row['id'])
            evidence = row.get('evidence')
            state = evidence.get('state') if isinstance(evidence, dict) else evidence
            if not isinstance(state, str) or not state.strip():
                raise ValueError(row['id'] + ': explicit evidence state is required.')
            if not isinstance(row.get('source_ids'), list) or any(not isinstance(x, str) for x in row['source_ids']):
                raise ValueError(row['id'] + ': source_ids must be an explicit list (empty allowed).')
    if len(graph_ids) != len(set(graph_ids)):
        raise ValueError('Node and flow IDs must be globally unique; IDs are never renamed for layout.')
    nodes = {row['id']: row for row in data['nodes']}
    if any(not isinstance(row, dict) for row in data['sources']):
        raise ValueError('Every source must be an object.')
    source_ids = [row.get('id') for row in data['sources']]
    if any(not isinstance(x, str) or not x for x in source_ids) or len(source_ids) != len(set(source_ids)):
        raise ValueError('Source IDs must be nonempty unique strings.')
    if any(not isinstance(row.get('title'), str) or not row['title'].strip() for row in data['sources']):
        raise ValueError('Every source requires a nonempty title.')
    for row in data['nodes'] + data['flows']:
        unknown = set(row['source_ids']) - set(source_ids)
        if unknown:
            raise ValueError(row['id'] + ': unknown source IDs: ' + ', '.join(sorted(unknown)))
    for flow in data['flows']:
        if flow.get('source') not in nodes or flow.get('target') not in nodes:
            raise ValueError(flow['id'] + ': unresolved source/target; supply an explicit logical node if needed.')
        if flow['source'] == flow['target']:
            raise ValueError(flow['id'] + ': self-loops are outside this tested prototype layout.')
        if flow.get('protocol_state') not in ('provided', 'not_provided', 'unverified', 'not_applicable'):
            raise ValueError(flow['id'] + ': explicit protocol_state is required.')
        if 'protocol' not in flow or 'transport' not in flow:
            raise ValueError(flow['id'] + ': protocol and transport keys are required (null allowed).')
        if flow['protocol_state'] == 'provided' and flow['protocol'] in (None, ''):
            raise ValueError(flow['id'] + ': provided protocol must have a value.')
        if flow['protocol_state'] in ('not_provided', 'not_applicable') and flow['protocol'] is not None:
            raise ValueError(flow['id'] + ': absent/inapplicable protocol must be null.')
    return nodes, set(graph_ids)


class Page:
    def __init__(self, name, used):
        self.name, self.used, self.serial = name, set(used), 0
        self.model = ET.Element('mxGraphModel', page='1', pageScale='1', pageWidth=str(PAGE_W),
                               pageHeight=str(PAGE_H), grid='1', gridSize='10', htmlLabels='1')
        self.root = ET.SubElement(self.model, 'root')
        self.root_id, self.layer_id = self.fresh(), self.fresh()
        ET.SubElement(self.root, 'mxCell', id=self.root_id)
        ET.SubElement(self.root, 'mxCell', id=self.layer_id, parent=self.root_id)
        self.vertex_rects = []

    def fresh(self):
        while True:
            self.serial += 1
            value = '__layout_' + str(self.serial)
            if value not in self.used:
                self.used.add(value)
                return value

    def text(self, value, x, y, w, h, size=BODY_FONT, box=False, cell_id=None, metadata=None, bold=False, mono=False, link=None):
        identity = cell_id or self.fresh()
        wrapped_object = metadata is not None or link is not None
        if not wrapped_object:
            parent = self.root
        else:
            parent = ET.SubElement(self.root, 'UserObject', id=identity, label='')
            if metadata is not None:
                parent.set('supplied_json', canonical(metadata))
            if link is not None:
                if source_url(link) is None:
                    raise ValueError('Only a supplied valid HTTPS source URL can be linked.')
                parent.set('link', link)
        style = ('rounded=0;html=1;whiteSpace=wrap;align=left;verticalAlign=top;'
                 'fontFamily=' + ('monospace' if mono else 'Helvetica') + ';fontColor=#202020;fontSize=' + str(size) + ';'
                 'spacingLeft=10;spacingRight=10;spacingTop=7;spacingBottom=7;'
                 + ('fillColor=#FAFAFA;strokeColor=#777777;strokeWidth=1;' if box else 'fillColor=none;strokeColor=none;')
                 + ('fontStyle=1;' if bold else ''))
        label = '<div style="line-height:1.45;white-space:pre-wrap;overflow-wrap:anywhere">' + html.escape(value) + '</div>'
        if link is not None:
            label = ('<a href="' + html.escape(link, quote=True) + '" target="_blank" rel="noopener noreferrer" '
                     'style="color:#0057A8;text-decoration:underline">' + label + '</a>')
        attrs = {'value': label, 'style': style, 'vertex': '1', 'parent': self.layer_id}
        if not wrapped_object:
            attrs['id'] = identity
        else:
            parent.set('label', label)
        cell = ET.SubElement(parent, 'mxCell', attrs)
        ET.SubElement(cell, 'mxGeometry', x=str(x), y=str(y), width=str(w), height=str(h), **{'as': 'geometry'})
        self.vertex_rects.append((identity, x, y, w, h))
        return cell

    def header(self, title, subtitle=''):
        self.text(brief(title, 72), MARGIN, 22, 1504, 48, size=24, bold=True)
        self.text(brief(subtitle, 195), MARGIN, 80, 1504, 48, size=14)

    def edge(self, flow):
        same = flow['source'] == flow['target']
        parent = ET.SubElement(self.root, 'UserObject', id=flow['id'], label=html.escape(flow['id']), supplied_json=canonical(flow))
        style = ('edgeStyle=none;noEdgeStyle=1;rounded=0;html=1;strokeColor=#333333;strokeWidth=2;'
                 'fontFamily=Helvetica;fontSize=14;fontColor=#202020;labelBackgroundColor=#FFFFFF;'
                 'endArrow=block;endFill=1;exitX=1;exitY=' + ('0.25' if same else '0.5') + ';'
                 'entryX=' + ('1' if same else '0') + ';entryY=' + ('0.75' if same else '0.5') + ';')
        cell = ET.SubElement(parent, 'mxCell', edge='1', parent=self.layer_id,
                             source=flow['source'], target=flow['target'], style=style)
        geometry = ET.SubElement(cell, 'mxGeometry', relative='1', **{'as': 'geometry'})
        if same:
            points = ET.SubElement(geometry, 'Array', **{'as': 'points'})
            ET.SubElement(points, 'mxPoint', x='1120', y='240')
            ET.SubElement(points, 'mxPoint', x='1120', y='320')
        return cell


def author(data, overview=None):
    nodes, used = validate(data)
    sources = {source['id']: source for source in data['sources']}
    skipped_source_links = {identity: ('URL not supplied' if source.get('url') in (None, '') else 'URL is not an eligible supplied HTTPS citation')
                            for identity, source in sources.items() if source_url(source.get('url')) is None}
    pages, component_page, flow_page = [], {}, {}
    def new(name, subtitle=''):
        page = Page(name, used)
        page.header(name, subtitle)
        pages.append(page)
        return page

    def citations(page, y, record, source_record=False):
        refs = [record['id']] if source_record else record.get('source_ids', []) if isinstance(record, dict) else []
        for identity in dict.fromkeys(refs):
            source = sources[identity]
            target = source_url(source.get('url'))
            if target is None:
                continue
            lines = wrapped(['Source ' + identity + ' - ' + brief(source['title'], 180)], 132)
            height = len(lines) * LINE_H + 18
            if y + height > BOTTOM:
                page, y = new('Source links - ' + brief(record.get('id', 'record'), 80), 'Links for the immediately preceding supplied record.'), 142
            page.text('\n'.join(lines), MARGIN, y, 1504, height, link=target,
                      metadata={'citation_source_id': identity, 'citation_record_id': record.get('id'), 'citation_url': target})
            y += height + 12
        return page, y

    # Fixed-height overview indices; no unreviewed multi-edge automatic topology.
    component_overviews = [new('Component index ' + str(i//8+1), 'Every component is listed. Complete supplied records and flow pages follow.')
                           for i in range(0, len(data['nodes']), 8)]
    flow_overviews = [new('Directed flow index ' + str(i//18+1), 'Each flow has its own two-endpoint view. Direction is copied from the input without inference.')
                     for i in range(0, len(data['flows']), 18)]

    def record_pages(title, record, first=None, start=142):
        lines = wrapped(fields(record))
        page = first or new(title, 'Complete supplied values; no inferred state or transport. Null remains a literal supplied null.')
        first_page = page
        while lines:
            capacity = max(1, (BOTTOM-start-18)//LINE_H)
            chunk, lines = lines[:capacity], lines[capacity:]
            page.text('\n'.join(chunk), MARGIN, start, 1504, len(chunk)*LINE_H+18, box=True, mono=True)
            end = start + len(chunk)*LINE_H + 30
            if lines:
                page = new(title + ' - continued', 'Continuation of the same supplied record; no content omitted.')
                start = 142
        citations(page, end, record)
        return first_page

    def collection(title, records, source_records=False):
        first_pages, page, y = {}, None, 142
        for identity,record in records:
            lines = wrapped([identity] + list(fields(record)))
            total = len(lines)*LINE_H+18
            if page is None or y+LINE_H+18 > BOTTOM or (total <= BOTTOM-142 and y+total > BOTTOM):
                page, y = new(title, 'Complete supplied records. Continued records retain every field and source reference.'), 142
            first_pages[identity] = page
            while lines:
                capacity = (BOTTOM-y-18)//LINE_H
                if capacity < 1:
                    page, y = new(title + ' - continued'), 142
                    capacity = (BOTTOM-y-18)//LINE_H
                chunk, lines = lines[:capacity], lines[capacity:]
                height = len(chunk)*LINE_H+18
                page.text('\n'.join(chunk), MARGIN, y, 1504, height, box=True, mono=True)
                y += height+18
            page, y = citations(page, y, record, source_records)
        return first_pages

    component_page = collection('Component register', [(node['id'],node) for node in data['nodes']])

    for flow in data['flows']:
        page = new('Flow ' + flow['id'] + ' - ' + flow.get('label', flow['id']),
                   'Source/target IDs are preserved. The line carries direction only; source evidence and protocol are stated below.')
        for identity, x in [(flow['source'], 80), (flow['target'], 1100)]:
            if flow['source'] == flow['target'] and x == 1100:
                continue
            node = nodes[identity]
            node_x = 540 if flow['source'] == flow['target'] else x
            page.text('\n'.join(wrapped([identity, brief(node.get('label', identity), 110)], 42)),
                      node_x, 200, 420, 160, size=14, box=True, cell_id=identity, metadata=node, mono=True)
        page.edge(flow)
        evidence = flow['evidence'] if isinstance(flow['evidence'], str) else flow['evidence']['state']
        page.text(brief('Evidence state: ' + str(evidence) + ' | Protocol state: ' + flow['protocol_state'], 180),
                  MARGIN, 145, 1504, 44, size=14, bold=True)
        flow_page[flow['id']] = record_pages('Flow ' + flow['id'] + ' - full detail', flow, first=page, start=420)

    collection('Source register', [(source['id'],source) for source in data['sources']], source_records=True)
    extras = {key:value for key,value in data.items() if key not in ('nodes', 'flows', 'sources', 'facts', 'actions')}
    record_pages('Supplied context', extras)
    for key in ('facts', 'actions'):
        if key in data:
            record_pages('Supplied ' + key, {key:data[key]})

    number = {id(page):i+1 for i,page in enumerate(pages)}
    for i,node in enumerate(data['nodes']):
        page = component_overviews[i//8]
        x, y = MARGIN+(i%2)*760, 150+((i%8)//2)*200
        label = [node['id'], brief(node.get('label', node['id']), 110), 'Complete record: page ' + str(number[id(component_page[node['id']])])]
        page.text('\n'.join(wrapped(label, 64)), x, y, 720, 172, size=14, box=True, cell_id=node['id'], metadata=node, mono=True)
    for i,flow in enumerate(data['flows']):
        page = flow_overviews[i//18]
        label = flow['id'] + ': ' + flow['source'] + ' → ' + flow['target'] + ' | ' + brief(flow.get('label',''),72) + ' | View: page ' + str(number[id(flow_page[flow['id']])])
        page.text(label, MARGIN, 145+(i%18)*47, 1504, 43, size=14, box=True)
    for i,page in enumerate(pages):
        page.text('Page ' + str(i+1) + ' of ' + str(len(pages)) + ' | Component index: page1 | Directed flow index: page' + str(len(component_overviews)+1),
                  MARGIN, 1044, 1504, 34, size=12)

    root = ET.Element('mxfile', host='local-stdlib-author', version='prototype-1',
                      supplied_input_sha256=hashlib.sha256(canonical(data).encode()).hexdigest(),
                      supplied_input_json=canonical(data))
    for i,page in enumerate(pages):
        diagram = ET.SubElement(root, 'diagram', id='page-'+str(i+1), name=str(i+1)+'. '+brief(page.name,95))
        diagram.append(page.model)
    ET.indent(root)
    raw = ET.tostring(root, encoding='utf-8', xml_declaration=True)
    # Structural acceptance is checked against the actual output, not an outline.
    parsed = ET.fromstring(raw)
    assert json.loads(parsed.get('supplied_input_json')) == data
    edge_rows = []
    issues = []
    for i,(diagram,page) in enumerate(zip(parsed.findall('diagram'),pages),1):
        ids = []
        for entry in diagram.find('mxGraphModel/root'):
            cell = entry if entry.tag == 'mxCell' else entry.find('mxCell')
            identity = entry.get('id') or cell.get('id')
            ids.append(identity)
            if cell.get('edge') == '1':
                edge_rows.append((identity,cell.get('source'),cell.get('target')))
        if len(ids) != len(set(ids)):
            issues.append({'page':i,'failure':'duplicate IDs'})
        for identity,x,y,w,h in page.vertex_rects:
            if min(x,y) < 0 or x+w > PAGE_W or y+h > PAGE_H:
                issues.append({'page':i,'cell':identity,'failure':'geometry outside page'})
    expected = [(f['id'],f['source'],f['target']) for f in data['flows']]
    if sorted(edge_rows) != sorted(expected):
        issues.append({'failure':'flow ID/endpoints not preserved exactly'})
    if issues:
        raise ValueError('Output checks failed: '+json.dumps(issues))
    report = {'status':'STRUCTURE PASS; NATIVE VISUAL REVIEW REQUIRED','pages':len(pages),
              'componentCount':len(nodes),'flowCount':len(edge_rows),'sourceCount':len(data['sources']),
              'inputRoundTrip':'PASS','flowIdsAndEndpoints':'PASS','uniquePageIdsAndGeometryBounds':'PASS',
              'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),
              'sourceLinks': {'native_link_objects': len(parsed.findall('.//UserObject[@link]')),
                              'eligible_source_ids': [identity for identity in sources if identity not in skipped_source_links],
                              'unlinked_sources': skipped_source_links,
                              'target_accessibility': 'NOT_CHECKED', 'semantic_support': 'NOT_CHECKED'},
              'layout':'Component/flow indices, complete records, one directed flow per focused page; no dense topology inference.',
              'limitations':['This helper does not verify source truth or infer missing producers/protocols/statuses.',
                             'Input coordinates/views are preserved as context but not used for geometry.',
                             'Page count grows with nodes/flows/full details; this prototype optimizes reliable layout over compactness.',
                             'Native render/label and editability checks are still required; structure alone is not visual approval.',
                             'Page navigation uses printed page numbers and native page selector; desktop-specific links/extensions untested.']}
    if overview is not None:
        from ulta_architecture_overview import add_overview
        return add_overview(data, raw, report, overview)
    return raw,report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input',type=Path)
    parser.add_argument('output',type=Path)
    parser.add_argument('--report',type=Path)
    parser.add_argument('--overview',type=Path,help='Optional explicit functional-group presentation config; source JSON is unchanged.')
    args = parser.parse_args()
    data = json.loads(args.input.read_text(encoding='utf-8'))
    overview = json.loads(args.overview.read_text(encoding='utf-8')) if args.overview else None
    report_path = args.report or args.output.with_suffix('.build-report.json')
    paths=[args.input.resolve(),args.output.resolve(),report_path.resolve()] + ([args.overview.resolve()] if args.overview else [])
    if len(paths)!=len(set(paths)):raise ValueError('Input, overview, output and report paths must be distinct.')
    raw,report = author(data,overview)
    if args.input.resolve() == args.output.resolve():
        raise ValueError('Output must differ from input.')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_bytes(raw)
    report_path = args.report or args.output.with_suffix('.build-report.json')
    report_path.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
