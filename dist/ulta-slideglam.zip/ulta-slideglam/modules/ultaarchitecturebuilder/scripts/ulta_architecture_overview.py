"""Bounded orthogonal functional-group prototype. No business facts inferred.

Two columns keep all original endpoint ports on the shared corridor. Each
aggregate has its own vertical rail; each incidence its own horizontal port
lane. Source badges sit on the source lane outside the rail corridor, so
another edge cannot cross a badge. The tradeoff is a larger canvas.
"""
import json
import math
import textwrap
import hashlib
import re
import xml.etree.ElementTree as E


def unique(values):
    result=[]
    for value in values:
        if value not in result: result.append(value)
    return result


def status(flow):
    detail=flow.get('details',{})
    return flow.get('status',detail.get('status') if isinstance(detail,dict) else None)


def attributes(flows):
    result={k:unique([status(f) if k=='status' else f.get(k) for f in flows])
            for k in ['evidence','protocol','protocol_state','transport','flow_type','status']}
    result['mixed_fields']=[k for k,v in result.items() if len(v)>1]
    return result


# Classification is a supplied exact-match presentation rule, never NLP or deployment inference.
CLASSES = {'documented','observed','draft','historical','proposed','unknown','unverified'}
FLAGS = {'disabled','proposed','historical','unknown','unverified'}
STYLES = {
 'documented': ('#286080', False, 'Documented design; deployment not inferred'),
 'observed': ('#347466', False, 'Supplied observation; scope/date retained'),
 'draft': ('#865EAD', True, 'Draft design'),
 'historical': ('#8A6A3D', True, 'Historical evidence'),
 'proposed': ('#865EAD', True, 'Proposed'),
 'unknown': ('#686868', True, 'Unknown or unclassified'),
 'unverified': ('#686868', True, 'Unverified'),
 'mixed': ('#555555', False, 'Mixed source fields; inspect member flags'),
 'disabled': ('#B04444', True, 'All members explicitly classified disabled'),
}


def value_at(row, path):
    value=row
    for key in path.split('.'):
        if not isinstance(value,dict) or key not in value:return None
        value=value[key]
    return value


def validate_presentation(config):
    if not isinstance(config,dict):raise ValueError('Overview config must be an object')
    if set(config)-{'presentation_groups','evidence_rules','status_rules'}:raise ValueError('Unknown overview config field')
    for key in ['evidence_rules','status_rules']:
        seen=set()
        if not isinstance(config.get(key,[]),list):raise ValueError(key+' must be a list')
        for rule in config.get(key,[]):
            allowed={'field','equals','class'} if key=='evidence_rules' else {'field','equals','flags'}
            paths={'evidence','evidence.state'} if key=='evidence_rules' else {'status','details.status','flow_type'}
            if not isinstance(rule,dict) or set(rule)!=allowed or rule['field'] not in paths or not isinstance(rule['equals'],str) or not rule['equals']:
                raise ValueError('Rule requires an allowed source path and exact nonempty string equality')
            pair=(rule['field'],rule['equals'])
            if pair in seen:raise ValueError('Duplicate presentation rule')
            seen.add(pair)
            if key=='evidence_rules' and rule['class'] not in CLASSES:raise ValueError('Unsupported evidence class')
            if key=='status_rules' and (not isinstance(rule['flags'],list) or not rule['flags'] or len(set(rule['flags']))!=len(rule['flags']) or not set(rule['flags'])<=FLAGS):raise ValueError('Unsupported status flags')


def classify(flow,config):
    matched=[r for r in config.get('evidence_rules',[]) if value_at(flow,r['field'])==r['equals']]
    classes=unique([r['class'] for r in matched])
    if len(classes)>1:raise ValueError('Conflicting exact evidence classifications for '+flow['id'])
    flags=unique([flag for r in config.get('status_rules',[]) if value_at(flow,r['field'])==r['equals'] for flag in r['flags']])
    return {'evidence_class':classes[0] if classes else 'unknown','status_flags':flags,
            'classification_matched':bool(matched),'source_evidence':flow['evidence'],'source_status':status(flow),'rules_matched':matched+
            [r for r in config.get('status_rules',[]) if value_at(flow,r['field'])==r['equals']]}


def exceptions(flows,config):
    result=[]
    for f in flows:
        c=classify(f,config)
        terms=list(c['status_flags'])
        if not c['classification_matched']:terms.append('unclassified')
        elif c['evidence_class'] in ['draft','historical','proposed','unverified','unknown'] and c['evidence_class'] not in terms:terms.append(c['evidence_class'])
        if terms:result.append({'flow_id':f['id'],'terms':terms,'evidence':f['evidence'],'status':status(f),'classification':c})
    return result


def route_style(members,config):
    cs=[classify(f,config) for f in members]
    evidence=unique([c['evidence_class'] for c in cs])
    flags=unique([sorted(c['status_flags']) for c in cs])
    if len(evidence)>1 or len(flags)>1 or attributes(members)['mixed_fields']:key='mixed'
    elif cs and all('disabled' in c['status_flags'] for c in cs):key='disabled'
    else:key=evidence[0] if evidence else 'unknown'
    color,dashed,meaning=STYLES[key]
    return {'key':key,'color':color,'dashed':dashed,'meaning':meaning,'members':cs}


def overlap(a,b):
    return a['x']<b['x']+b['width'] and b['x']<a['x']+a['width'] and a['y']<b['y']+b['height'] and b['y']<a['y']+a['height']


def segment_hits(a,b,r,pad=0):
    left=r['x']-pad;right=r['x']+r['width']+pad;top=r['y']-pad;bottom=r['y']+r['height']+pad
    if a['x']==b['x']:
        return left<a['x']<right and max(a['y'],b['y'])>top and min(a['y'],b['y'])<bottom
    if a['y']==b['y']:
        return top<a['y']<bottom and max(a['x'],b['x'])>left and min(a['x'],b['x'])<right
    raise ValueError('Non-orthogonal segment')


def layout(data, config, *, max_badge_lines=8):
    if not isinstance(max_badge_lines,int) or isinstance(max_badge_lines,bool) or not 8 <= max_badge_lines <= 16:
        raise ValueError('max_badge_lines must be an integer from 8 to 16')
    validate_presentation(config)
    definitions=config.get('presentation_groups',[])
    if not isinstance(definitions,list) or not 2<=len(definitions)<=8: raise ValueError('Supply 2–8 explicit presentation groups')
    node_ids=[n['id'] for n in data['nodes']]
    if not isinstance(definitions,list) or any(not isinstance(g,dict) or set(g)!={'id','label','node_ids'} or not isinstance(g['id'],str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]{0,19}',g['id']) or not isinstance(g['label'],str) or not g['label'].strip() or len(g['label'])>65 or not isinstance(g['node_ids'],list) or any(not isinstance(n,str) for n in g['node_ids']) for g in definitions):raise ValueError('Groups need short IDs, labels <=65 characters and explicit node IDs')
    group_ids=[g['id'] for g in definitions]
    assigned=[n for g in definitions for n in g['node_ids']]
    if len(set(group_ids))!=len(group_ids) or len(set(assigned))!=len(assigned) or sorted(assigned)!=sorted(node_ids):
        raise ValueError('Each original node must belong to exactly one unique group')
    if any(not g['node_ids'] for g in definitions): raise ValueError('Empty group')
    mapping={n:g['id'] for g in definitions for n in g['node_ids']}
    grouped={};internal={gid:[] for gid in group_ids}
    for flow in data['flows']:
        if flow['source'] not in mapping or flow['target'] not in mapping: raise ValueError('Unresolved endpoint')
        pair=(mapping[flow['source']],mapping[flow['target']])
        if pair[0]==pair[1]: internal[pair[0]].append(flow)
        else: grouped.setdefault(pair,[]).append(flow)
    if len(grouped)>20:
        raise ValueError('Prototype readability limit: at most 20 ordered-pair aggregates; split the functional scope explicitly')
    aggregates=[];incidences={gid:[] for gid in group_ids}
    for i,((source,target),members) in enumerate(grouped.items(),1):
        a={'id':f'AGG{i:02}','source_group':source,'target_group':target,
           'flow_ids':[f['id'] for f in members], 'attributes':attributes(members),
           'material_exceptions':exceptions(members,config), 'members':members,'route_style':route_style(members,config)}
        lines=[a['id']+' '+source+'→'+target+' | '+', '.join(a['flow_ids'])]
        mixed=a['attributes']['mixed_fields']
        states=unique([(f.get('evidence',{}).get('state','not provided') if isinstance(f.get('evidence'),dict) else str(f.get('evidence'))) for f in members])
        lines.append('Evidence: mixed' if len(states)>1 else 'Evidence: '+states[0])
        lines.append('Style: '+a['route_style']['key'])
        dates=unique([f.get('evidence',{}).get('as_of') for f in members if isinstance(f.get('evidence'),dict) and f.get('evidence',{}).get('as_of')])
        if dates: lines.append('As of: '+', '.join(dates))
        lines.append('Protocol: mixed' if len(a['attributes']['protocol'])>1 or len(a['attributes']['protocol_state'])>1 else 'Protocol: '+str(a['attributes']['protocol_state'][0] or 'not provided'))
        if mixed: lines.append('Mixed: '+', '.join(mixed))
        for ex in a['material_exceptions']: lines.append(ex['flow_id']+': '+', '.join(ex['terms']))
        a['badge_lines']=[wrapped for line in lines for wrapped in textwrap.wrap(line,42,break_long_words=True,break_on_hyphens=False)]
        if len(a['badge_lines'])>max_badge_lines: raise ValueError('Aggregate has too much local evidence for this overview; refine explicit grouping')
        a['badge_height']=max(72,22*len(a['badge_lines'])+20)
        aggregates.append(a)
        incidences[source].append((a,'source'));incidences[target].append((a,'target'))
    # Every incidence has a separate band. Taller badges enlarge all bands.
    badge_height=max([a['badge_height'] for a in aggregates] or [64])
    pitch=None
    node_width=420;badge_width=344;rail_gap=24
    left_x=40;left_boundary=left_x+node_width
    rail_left=left_boundary+badge_width+64
    rail_width=max(168,rail_gap*(len(aggregates)+1))
    rail_right=rail_left+rail_width
    right_boundary=rail_right+badge_width+64
    width=right_boundary+node_width+40
    groups=[];by={};y=300
    for row in range(math.ceil(len(definitions)/2)):
        row_defs=definitions[row*2:row*2+2]
        bands={g['id']:[(a['badge_height']+20 if end=='source' else 40) for a,end in incidences[g['id']]] for g in row_defs}
        height=max(300,120+max(sum(bands[g['id']]) for g in row_defs))
        used_y=set()
        for col,g in enumerate(row_defs):
            group={'id':g['id'],'label':g['label'],'member_node_ids':list(g['node_ids']),
                   'internal_flow_ids':[f['id'] for f in internal[g['id']]],
                   'internal_attributes':attributes(internal[g['id']]),'material_exceptions':exceptions(internal[g['id']],config),
                   'x':left_x if col==0 else right_boundary,'y':y,'width':node_width,'height':height,'column':col}
            group_lines=['Members ('+str(len(g['node_ids']))+'): '+', '.join(g['node_ids']),
                         'Internal flows ('+str(len(internal[g['id']]))+'): '+(', '.join(group['internal_flow_ids']) or 'none')]
            for ex in group['material_exceptions']:
                ev=ex.get('evidence',{})
                date=ev.get('as_of') if isinstance(ev,dict) else None
                group_lines.append(ex['flow_id']+': '+', '.join(ex['terms'])+(' | as of '+str(date) if date else ''))
            group['body_lines']=[wrapped for line in group_lines for wrapped in textwrap.wrap(line,42,break_long_words=True,break_on_hyphens=False)]
            if len(group['body_lines'])*22+100>height:raise ValueError('Group member/evidence detail exceeds the readable box; refine grouping')
            groups.append(group);by[group['id']]=group
            cursor=y+48+(13 if col else 0)
            for i,(a,end) in enumerate(incidences[group['id']]):
                band=bands[group['id']][i]
                py=cursor+band/2
                while py in used_y: py+=1
                used_y.add(py)
                cursor+=band
                px=left_boundary if col==0 else right_boundary
                a[end+'_point']={'x':px,'y':py}
                a[end+'_port']={'x':1 if col==0 else 0,'y':(py-y)/height}
        y+=height+72
    for i,a in enumerate(aggregates):
        rail=rail_left+(i+1)*rail_gap
        s=a['source_point'];t=a['target_point']
        a['points']=[s,{'x':rail,'y':s['y']},{'x':rail,'y':t['y']},t]
        a['rail_x']=rail
        source=by[a['source_group']]
        a['badge']={'x':left_boundary+20 if source['column']==0 else rail_right+44,
                    'y':s['y']-a['badge_height']/2,'width':badge_width,'height':a['badge_height'],
                    'aggregate_id':a['id'],'label':'\n'.join(a['badge_lines'])}
    crossings=[]
    for a in aggregates:
        # White gap then horizontal redraw at each interior H/V crossing.
        for first,last in [(a['points'][0],a['points'][1]),(a['points'][2],a['points'][3])]:
            for b in aggregates:
                if b is a:continue
                x=b['rail_x'];yy=first['y'];b0,b1=b['points'][1:3]
                if min(first['x'],last['x'])+2<x<max(first['x'],last['x'])-2 and min(b0['y'],b1['y'])+2<yy<max(b0['y'],b1['y'])-2:
                    crossings.append({'x':x,'y':yy,'over':a['id'],'under':b['id'],'size':10,'orientation':'horizontal'})
    violations=[]
    title={'x':30,'y':16,'width':width-60,'height':262}
    for a in aggregates:
        for start,end in zip(a['points'],a['points'][1:]):
            if start['x']!=end['x'] and start['y']!=end['y']:violations.append({'kind':'nonorthogonal','id':a['id']})
            for g in groups:
                if g['id'] not in [a['source_group'],a['target_group']] and segment_hits(start,end,g):violations.append({'kind':'unrelated-group','id':a['id'],'other':g['id']})
            for b in aggregates:
                if b is not a and segment_hits(start,end,b['badge'],2):violations.append({'kind':'unrelated-badge','id':a['id'],'other':b['id']})
            if segment_hits(start,end,title):violations.append({'kind':'title','id':a['id']})
    for i,a in enumerate(aggregates):
        for b in aggregates[:i]:
            if overlap(a['badge'],b['badge']):violations.append({'kind':'badge-overlap','id':a['id'],'other':b['id']})
    represented=[f for a in aggregates for f in a['flow_ids']]+[f for g in groups for f in g['internal_flow_ids']]
    if sorted(represented)!=sorted(f['id'] for f in data['flows']):raise ValueError('Flow coverage changed')
    return {'schema':'explicit-functional-groups-orthogonal-0.3','title':data['title'],
            'canvas':{'width':width,'height':y+20},'groups':groups,'aggregates':aggregates,'crossings':crossings,
            'checks':{'nodes':len(node_ids),'flows':len(data['flows']),'groups':len(groups),'aggregate_edges':len(aggregates),
                      'internal_flows':sum(len(g['internal_flow_ids']) for g in groups),'violations':violations,'crossings':len(crossings),
                      'badge_height':badge_height,'pitch':pitch,'allOriginalFlowsExactlyOnce':True},
            'notes':['Explicit functional presentation groups only; no security, ownership or deployment boundary inferred.',
                     'Arrows aggregate only actual flows in the same ordered group pair. Opposite directions use separate rails/ports.',
                     'Full member records and evidence remain unchanged. Mixed attributes are neutral; local material exceptions are explicit.',
                     'White gaps at orthogonal crossings indicate no junction. Source badges are integral to their source horizontal lane.',
                     'Bounded layout: 2–8 groups and at most 20 aggregate edges; large evidence badges expand the canvas rather than shrink text.']}


def cell_parts(entry):
    cell=entry if entry.tag=='mxCell' else entry.find('mxCell')
    target=entry if entry.tag!='mxCell' else cell
    return cell,target,'label' if entry.tag!='mxCell' else 'value'


def add_overview(data, raw, helper_report, config):
    """Prepend one optional page. Preserve all helper content/geometry except navigation."""
    from ulta_architecture_xml import Page, canonical, brief
    geometry=layout(data,config)
    if geometry['checks']['violations']:raise ValueError(geometry['checks']['violations'])
    root=E.fromstring(raw)
    pages=root.findall('diagram');count=len(pages)+1
    if not data['flows']:raise ValueError('Optional connected overview requires at least one supplied directed flow')
    flow_index=next(i+2 for i,p in enumerate(pages) if 'Directed flow index' in p.get('name',''))
    changes=[]
    for index,diagram in enumerate(pages,2):
        name=diagram.get('name')
        diagram.set('id','page-'+str(index));diagram.set('name',re.sub(r'^\d+\.',str(index)+'.',name))
        for entry in diagram.find('mxGraphModel/root'):
            cell,target,attribute=cell_parts(entry)
            if cell is None:continue
            before=cell.get('value',target.get(attribute,''));after=before
            if target is not cell and cell.get('value') is not None and target.get(attribute)!=before:
                raise ValueError('Input renderer/wrapper labels disagree')
            shape=cell.find('mxGeometry')
            if shape is not None and shape.get('y')=='1044':
                after=re.sub(r'Page \d+ of \d+',f'Page {index} of {count}',after)
                after=re.sub(r'(page\s*)(\d+)',lambda m:m[1]+str(int(m[2])+1),after)
            if 'Component index' in name or 'Directed flow index' in name:
                after=re.sub(r'(Complete record: page |View: page )(\d+)',lambda m:m[1]+str(int(m[2])+1),after)
            if after!=before:
                target.set(attribute,after)
                if target is not cell and cell.get('value') is not None:cell.set('value',after)
                changes.append({'page':index,'cell':entry.get('id'),'before':before,'after':after})
    semantic_ids=[g['id'] for g in geometry['groups']]+[a['id'] for a in geometry['aggregates']]
    if len(set(semantic_ids))!=len(semantic_ids):raise ValueError('Group ID conflicts with generated aggregate ID')
    pg=Page('Functional grouped overview',set(semantic_ids))
    width=geometry['canvas']['width']
    pg.model.set('pageWidth',str(width));pg.model.set('pageHeight',str(geometry['canvas']['height']))
    pg.text('Functional overview - '+brief(data['title'],90),35,16,width-70,46,size=24,bold=True)
    pg.text('Explicit presentation groups; not security, ownership or deployment boundaries. Each arrow aggregates only its listed flow IDs.\nCrossing gaps mean no junction. Classifications are exact supplied presentation rules; raw evidence remains in badges/registers.\nPage 1 of '+str(count)+' | Component index: page 2 | Directed flow index: page '+str(flow_index)+'. Full source records and exact endpoints remain on focused pages.',35,68,width-70,80,size=15)
    # A visible single mapping applies to overview routes and their attached badges.
    legend_keys=['documented','observed','draft','historical','proposed','unknown','unverified','mixed','disabled']
    legend_w=(width-70)/3
    for i,key in enumerate(legend_keys):
        color,dashed,meaning=STYLES[key]
        c=pg.text(key+': '+meaning,35+(i%3)*legend_w,166+(i//3)*36,legend_w-12,32,size=12,box=True)
        c.set('style',c.get('style')+'strokeColor='+color+';strokeWidth=2;dashed='+str(int(dashed))+';')
    for group in geometry['groups']:
        cell=pg.text('',group['x'],group['y'],group['width'],group['height'],box=True,cell_id=group['id'],metadata=group)
        cell.set('style',cell.get('style')+'rounded=1;arcSize=5;dashed=0;strokeWidth=2;strokeColor=#444444;fillColor=#F8F8F8;')
        previous=pg.layer_id;pg.layer_id=group['id']
        pg.text(group['id']+' - '+group['label'],12,16,group['width']-24,68,size=18,bold=True)
        pg.text('\n'.join(group['body_lines']),12,96,group['width']-24,group['height']-108,size=15)
        pg.layer_id=previous
    for a in geometry['aggregates']:
        obj=E.SubElement(pg.root,'UserObject',id=a['id'],label='',aggregate_json=canonical(a))
        st=a['route_style']
        style='edgeStyle=none;noEdgeStyle=1;rounded=0;html=1;endArrow=block;endFill=1;strokeWidth=2;strokeColor='+st['color']+';dashed='+str(int(st['dashed']))+';exitPerimeter=0;entryPerimeter=0;exitX='+str(a['source_port']['x'])+';exitY='+str(a['source_port']['y'])+';entryX='+str(a['target_port']['x'])+';entryY='+str(a['target_port']['y'])+';'
        edge=E.SubElement(obj,'mxCell',edge='1',parent=pg.layer_id,source=a['source_group'],target=a['target_group'],style=style)
        geom=E.SubElement(edge,'mxGeometry',relative='1',**{'as':'geometry'})
        points=E.SubElement(geom,'Array',**{'as':'points'})
        for point in a['points'][1:-1]:E.SubElement(points,'mxPoint',x=str(point['x']),y=str(point['y']))
    # Decorations only, never extra semantic edges. Regenerate crossings after route edits.
    byagg={a['id']:a for a in geometry['aggregates']}
    for crossing in geometry['crossings']:
        cell=pg.text('',crossing['x']-5,crossing['y']-5,10,10)
        cell.set('style','shape=ellipse;fillColor=#FFFFFF;strokeColor=none;')
        cell=pg.text('',crossing['x']-7,crossing['y'],14,0)
        style=byagg[crossing['over']]['route_style']
        cell.set('style','shape=line;strokeColor='+style['color']+';strokeWidth=2;dashed='+str(int(style['dashed']))+';')
    for a in geometry['aggregates']:
        b=a['badge'];points=a['points']
        total=sum(abs(p['x']-q['x'])+abs(p['y']-q['y']) for p,q in zip(points,points[1:]))
        center={'x':b['x']+b['width']/2,'y':points[0]['y']}
        distance=abs(center['x']-points[0]['x'])
        if not 0<distance<abs(points[1]['x']-points[0]['x']):raise ValueError('Badge anchor must lie inside its own source segment')
        anchor_x=2*distance/total-1
        previous=pg.layer_id;pg.layer_id=a['id']
        cell=pg.text(b['label'],anchor_x,0,b['width'],b['height'],size=14,box=True,
                     metadata={'aggregate_id':a['id'],'flow_ids':a['flow_ids'],'material_exceptions':a['material_exceptions'],
                               'anchor':{'segment':0,'fraction':distance/abs(points[1]['x']-points[0]['x']),'relative_edge_x':anchor_x}})
        pg.layer_id=previous
        st=a['route_style']
        cell.set('style',cell.get('style')+'align=left;spacingLeft=8;spacingTop=4;spacingBottom=4;fillColor=#FFFFFF;strokeColor='+st['color']+';strokeWidth=2;dashed='+str(int(st['dashed']))+';connectable=0;')
        geom=cell.find('mxGeometry');geom.set('relative','1')
        E.SubElement(geom,'mxPoint',x=str(-b['width']/2),y=str(-b['height']/2),**{'as':'offset'})
    diagram=E.Element('diagram',id='page-1',name='1. Functional grouped overview');diagram.append(pg.model);root.insert(0,diagram)
    root.set('overview_presentation_json',canonical(config));root.set('grouped_overview_geometry_json',canonical(geometry))
    E.indent(root);out=E.tostring(root,encoding='utf-8',xml_declaration=True)
    assert json.loads(root.get('supplied_input_json'))==data
    # Actual generated cell graph: wrappers count as IDs, child edge labels resolve to real edges.
    for diagram in root.findall('diagram'):
        entries=list(diagram.find('mxGraphModel/root'));ids=[e.get('id') for e in entries]
        if len(ids)!=len(set(ids)):raise ValueError('Duplicate native cell IDs')
        for entry in entries:
            cell,_,_=cell_parts(entry)
            for key in ['source','target','parent']:
                if cell.get(key) and cell.get(key) not in ids:raise ValueError('Unresolved native '+key)
    report=dict(helper_report)
    report.update({'pages':count,'bytes':len(out),'sha256':hashlib.sha256(out).hexdigest(),
                   'overview':{'geometryChecks':geometry['checks'],'navigationChanges':changes,'config':config,
                               'badgeAttachment':'Native relative edge-child vertices anchored on source segment'},
                   'layout':'Optional explicitly grouped connected overview; unchanged detail pages except corrected printed navigation.'})
    report['limitations']=helper_report['limitations']+[
      'Presentation classifications are supplied exact-match rules, not independent source or deployment verification.',
      'Overview bounds: 2–8 explicit groups, at most20 ordered-pair aggregates, at most8 wrapped badge lines. Inputs outside bounds are rejected.',
      'Large overview needs zoom/scroll. Native badge attachment follows its edge, but node rerouting/crossing marks require regeneration and visual review.',
      'Focused pages retain their neutral direction-only route style; this optional overview legend applies only to its classified aggregate routes.']
    return out,report
