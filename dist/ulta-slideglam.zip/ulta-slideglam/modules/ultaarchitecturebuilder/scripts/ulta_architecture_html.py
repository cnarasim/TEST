#!/usr/bin/env python3
"""Bounded, stdlib-only JSON -> self-contained HTML/SVG architecture helper.

Usage: python ulta_architecture_html.py input.json output.html --report build.json
This is an authoring resource, not a source-truth, browser-fit, or delivery verifier.
Optional --overview config.json uses the shared reviewed functional-group router.
Component indexes and exact per-flow focused views remain available in both modes.
"""
import argparse
import hashlib
import json
from pathlib import Path
from urllib.parse import urlsplit


def validate(data):
    if not isinstance(data, dict):
        raise ValueError('Top-level input must be an object')
    if not isinstance(data.get('title'), str) or not data['title'].strip():
        raise ValueError('title must be non-empty text')
    sets = {}
    for kind in ('nodes', 'flows', 'sources'):
        items = data.get(kind)
        if not isinstance(items, list):
            raise ValueError(kind + ' must be a list')
        ids = [x.get('id') for x in items if isinstance(x, dict)]
        if len(ids) != len(items) or any(not isinstance(x, str) or not x for x in ids):
            raise ValueError(kind + ' IDs must be non-empty strings')
        if len(set(ids)) != len(ids):
            raise ValueError(kind + ' IDs must be unique')
        sets[kind] = set(ids)
    if not data['nodes']:
        raise ValueError('At least one node is required')
    if len(data['nodes']) > 60 or len(data['flows']) > 100:
        raise ValueError('Bounded helper limit: 60 nodes / 100 flows; split larger inputs explicitly')
    if sets['nodes'] & sets['flows']:
        raise ValueError('Node and flow IDs must be globally unique')
    if any(len(x) > 80 or any(ord(c) < 32 for c in x) for x in sets['nodes'] | sets['flows']):
        raise ValueError('Graph IDs must be at most 80 characters without control characters')
    for kind in ('nodes', 'flows'):
        for item in data[kind]:
            if not isinstance(item.get('label'), str) or not item['label'].strip():
                raise ValueError(kind + ' label missing: ' + item['id'])
            ev = item.get('evidence')
            if not (isinstance(ev, str) and ev.strip()) and not (isinstance(ev, dict) and isinstance(ev.get('state'), str) and ev['state'].strip()):
                raise ValueError('Explicit evidence state required: ' + item['id'])
            refs = item.get('source_ids')
            if not isinstance(refs, list) or not all(isinstance(x, str) and x in sets['sources'] for x in refs):
                raise ValueError('Invalid source_ids: ' + item['id'])
    for flow in data['flows']:
        if flow.get('source') not in sets['nodes'] or flow.get('target') not in sets['nodes']:
            raise ValueError('Unknown flow endpoint: ' + flow['id'])
        if flow['source'] == flow['target']:
            raise ValueError('Self-loop focused layout is unsupported: ' + flow['id'])
        if flow.get('protocol_state') not in ('provided', 'not_provided', 'unverified', 'not_applicable'):
            raise ValueError('Explicit protocol_state required: ' + flow['id'])
        if flow.get('protocol_state') == 'provided' and not flow.get('protocol'):
            raise ValueError('Provided interface/protocol must have a value: ' + flow['id'])
        if flow.get('protocol_state') in ('not_provided', 'not_applicable') and flow.get('protocol') is not None:
            raise ValueError('Unknown/inapplicable interface/protocol must be null: ' + flow['id'])
        for field in ('protocol', 'transport'):
            if flow.get(field) is not None and not isinstance(flow[field], str):
                raise ValueError(field + ' must be text or null: ' + flow['id'])
    for source in data['sources']:
        if source.get('url') and urlsplit(source['url']).scheme not in ('http', 'https'):
            raise ValueError('Source URL scheme must be HTTP(S): ' + source['id'])
    return {'nodes': len(data['nodes']), 'flows': len(data['flows']), 'sources': len(data['sources'])}


HTML = r'''<!doctype html>
<html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Architecture</title>
<style>
:root{font-family:Arial,sans-serif;color:#342632;background:#fff6f1;font-size:16px}*{box-sizing:border-box}body{margin:0}header,main,footer{max-width:1600px;margin:auto;padding:20px 24px}h1{font:700 clamp(26px,3vw,38px) Georgia,serif;margin:0 0 12px}h2{font-size:22px;margin:22px 0 12px}h3{font-size:18px}p{line-height:1.5}.muted{color:#645663}.notice{border-left:5px solid #d00078;padding:10px 16px;background:#fff}.toolbar{display:flex;flex-wrap:wrap;gap:10px;align-items:center;background:#fff;padding:12px;border:1px solid #d9ced5}button,input,select{font:inherit;border:1px solid #8d7484;border-radius:4px;background:#fff;color:inherit;padding:8px 10px}button{cursor:pointer}button:hover{background:#fff0e7}button:focus-visible,input:focus-visible,select:focus-visible{outline:3px solid #b40068;outline-offset:3px}label{line-height:1.4}#search{width:240px}fieldset{border:1px solid #d9ced5;padding:10px 12px;display:flex;gap:14px;flex-wrap:wrap;margin:12px 0}fieldset input{accent-color:#b40068}legend{padding:0 5px;font-weight:bold}.workspace{display:grid;grid-template-columns:minmax(0,3fr) minmax(270px,1fr);gap:16px}.canvas{min-width:0;background:#fff;border:1px solid #d9ced5}#diagram{width:100%;height:510px;display:block;touch-action:none;cursor:grab}#diagram:active{cursor:grabbing}#diagram:focus-visible{outline:3px solid #b40068;outline-offset:-3px}.node rect{fill:#fff4ed;stroke:#74204b;stroke-width:2}.node text{pointer-events:none;fill:#342632}.node .identity{font-size:14px;font-weight:bold}.node .label{font-size:18px;font-weight:bold}.node .technical{font-size:13px}.node .state{font-size:12px;fill:#645663}.node,.flow-badge{cursor:pointer}.node:focus rect,.node.selected rect{stroke:#cf0077;stroke-width:4}.node:focus{outline:none}.route{fill:none;stroke:#bc5d20;stroke-width:3;pointer-events:stroke;cursor:pointer}.route.selected{stroke:#d00078;stroke-width:5}.flow-badge rect{fill:#fff;stroke:#88421b;stroke-width:2}.flow-badge text{font-size:15px;font-weight:bold;pointer-events:none;fill:#342632}.flow-badge:focus rect,.flow-badge.selected rect{stroke:#d00078;stroke-width:4}.flow-badge:focus{outline:none}.is-hidden{display:none!important}#inspector{background:#fff;border:1px solid #d9ced5;padding:16px;min-width:0;max-height:620px;overflow:auto}#inspector h2{margin-top:0}#inspector dl{margin:0}dt{font-weight:bold;margin-top:12px}dd{margin:3px 0;overflow-wrap:anywhere;white-space:pre-wrap;font-size:14px;line-height:1.45}.view-help{padding:10px 14px;margin:0;border-top:1px solid #e1d7dd;font-size:14px}.table-wrap{overflow:auto;background:#fff}table{width:100%;border-collapse:collapse;font-size:14px}th,td{text-align:left;vertical-align:top;padding:10px;border:1px solid #dfd3dc;overflow-wrap:anywhere}th{background:#5b1844;color:white}td button{padding:5px 8px;text-align:left}td:first-child{width:90px}.source{border:1px solid #dfd3dc;background:white;padding:12px;margin:8px 0}.source h3{margin:0 0 6px}.source p{margin:4px 0}.extra{background:#fff;border:1px solid #dfd3dc;padding:12px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;font:14px/1.5 Arial,sans-serif}footer{font-size:13px}a{color:#9e0059}#live{position:absolute;left:-10000px;top:auto;width:1px;height:1px;overflow:hidden}@media(max-width:900px){.workspace{grid-template-columns:1fr}#inspector{max-height:none}#diagram{height:430px}}@media print{.toolbar,fieldset,button{display:none}.workspace{display:block}#inspector{max-height:none}#diagram{height:480px}header,main{padding:12px}.table-wrap{overflow:visible}tr{break-inside:avoid}}
#evidenceLegend{display:flex;flex-wrap:wrap;align-items:center;gap:12px;padding:12px;background:white;border:1px solid #d9ced5;margin-bottom:12px}#evidenceLegend span{display:inline-flex;align-items:center;gap:6px;font-size:13px}#evidenceLegend small{flex-basis:100%}.route,.route.selected{stroke:var(--evidence-color,#555555)}.flow-badge rect,.flow-badge:focus rect,.flow-badge.selected rect{stroke:var(--evidence-color,#555555)}
.group-box rect{fill:#fff4ed;stroke:#74204b;stroke-width:2}.group-box text{pointer-events:none;fill:#342632;font-size:17px}.group-box:focus rect,.group-box.selected rect{stroke-width:5;stroke:#cf0077}.group-box{cursor:pointer;outline:none}.aggregate-badge text{font-size:16px;font-weight:normal}.aggregate-badge rect{stroke:var(--evidence-color)!important}.aggregate-route.selected{stroke-width:6}.aggregate-badge:focus rect,.aggregate-badge.selected rect{stroke-width:5}.crossing{pointer-events:none}.member-list{display:flex;gap:6px;flex-wrap:wrap}.member-list button{font-size:13px}.member-item{border-top:1px solid #ddd;padding:10px 0}.overview-note{font-size:14px;margin:0 0 10px}button:disabled{cursor:default;opacity:.55}#overviewFocus{max-width:360px}
</style>
<header><h1 id="title"></h1><p id="scope"></p><p class="notice">This file presents the supplied evidence. __OVERVIEW_NOTICE__ Documentation status does not establish deployment or approval.</p></header>
<main>
<div class="toolbar"><label>View <select id="view"></select></label><label>Search <input id="search" type="search" placeholder="ID, component, flow or detail"></label><button id="clearSearch">Clear search</button><button id="zoomIn" aria-label="Zoom in">+</button><button id="zoomOut" aria-label="Zoom out">−</button><button id="reset">Reset view</button><button id="download">Download source JSON</button></div>
<fieldset id="filters"><legend>Supplied flow categories - no protocol-based inference</legend></fieldset>
<p id="counts" class="muted"></p><div id="evidenceLegend" aria-label="Evidence and status legend"></div>
<div class="workspace"><div class="canvas"><svg id="diagram" role="group" aria-label="Architecture diagram; arrow keys pan when this area is focused" tabindex="0" viewBox="0 0 1120 500"><defs><marker id="arrow" markerWidth="10" markerHeight="8" refX="9" refY="4" orient="auto" markerUnits="userSpaceOnUse"><path d="M0,0 L10,4 L0,8 z" fill="#bc5d20"/></marker></defs><g id="world"></g></svg><p class="view-help" id="viewHelp"></p></div><aside id="inspector" aria-label="Selection inspector"><h2>Inspector</h2><p>Select a component or numbered flow badge. Enter or Space activates the focused control. Escape clears selection. Drag background to pan; arrow keys pan when the diagram area is focused.</p></aside></div>
<h2>Component register</h2><div class="table-wrap"><table id="nodesTable"><thead><tr><th>ID</th><th>Component / exact identifier</th><th>Responsibility</th><th>Evidence</th></tr></thead><tbody></tbody></table></div>
<h2>Directed flow register</h2><div class="table-wrap"><table id="flowsTable"><thead><tr><th>ID</th><th>Direction / purpose</th><th>Interface / transport</th><th>Evidence / category</th></tr></thead><tbody></tbody></table></div>
<h2>Sources</h2><section id="sources"></section><h2>Additional supplied evidence</h2><div id="extra"></div><div id="live" aria-live="polite"></div>
</main><footer>Self-contained styles, scripts and SVG. Source hyperlinks open only when activated. Browser interaction, visual fit, content fidelity and actual client file delivery require independent verification.</footer>
<script id="architecture-data" type="application/json">__DATA__</script>
<script id="presentation-data" type="application/json">__PRESENTATION__</script>
<script id="overview-data" type="application/json">__OVERVIEW__</script>
<script>
'use strict';
const DATA=JSON.parse(document.getElementById('architecture-data').textContent);
const PRESENTATION=JSON.parse(document.getElementById('presentation-data').textContent);
const OVERVIEW=JSON.parse(document.getElementById('overview-data').textContent);
const NS='http://www.w3.org/2000/svg', $=id=>document.getElementById(id);
const nodes=new Map(DATA.nodes.map(x=>[x.id,x])), flows=new Map(DATA.flows.map(x=>[x.id,x]));
const str=x=>x==null?'Not provided':typeof x==='string'?x:JSON.stringify(x,null,2);
const evidence=x=>typeof x==='string'?x:[x.state,x.as_of?'as of '+x.as_of:'',x.note].filter(Boolean).join(' · ');
const category=f=>f.flow_type||'Not provided';
const state={selected:null,query:'',allowed:new Set(DATA.flows.map(category)),tx:0,ty:0,scale:1,view:OVERVIEW?'overview':'index-1'};
const views=[];for(let i=0;i<DATA.nodes.length;i+=8)views.push({id:'index-'+(i/8+1),label:'Component index '+(i/8+1),nodes:DATA.nodes.slice(i,i+8)});
for(const f of DATA.flows)views.push({id:'flow-'+f.id,label:f.id+': '+f.label,flow:f});
if(OVERVIEW)views.unshift({id:'overview',label:'Connected functional overview'});
function element(tag,text,attrs={}){const el=document.createElement(tag);if(text!=null)el.textContent=text;for(const[k,v]of Object.entries(attrs))el.setAttribute(k,v);return el}
function svg(tag,attrs={},text){const el=document.createElementNS(NS,tag);for(const[k,v]of Object.entries(attrs))el.setAttribute(k,v);if(text!=null)el.textContent=text;return el}
function wrap(text,max){let lines=[],line='';for(let word of String(text).split(/\s+/)){while(word.length>max){if(line){lines.push(line);line=''}lines.push(word.slice(0,max));word=word.slice(max)}if((line+' '+word).trim().length>max){lines.push(line);line=word}else line=(line+' '+word).trim()}if(line)lines.push(line);return lines}
function label(group,text,x,y,cls,max=29,limit=2,width){
 const t=svg('text',{x,y,class:cls});t._fullText=String(text);t._lineLimit=limit;t._maxWidth=width;
 const lines=wrap(text,max);for(let i=0;i<Math.min(lines.length,limit);i++)t.append(svg('tspan',{x,dy:i?19:0},lines[i]+(i===limit-1&&lines.length>limit?'…':'')));group.append(t);
}
function fitLabels(world){
 for(const t of world.querySelectorAll('text')){
  const rect=t.parentElement.querySelector(':scope > rect'),x=Number(t.getAttribute('x')||0),center=t.getAttribute('text-anchor')==='middle';
  const width=t._maxWidth||(rect?Number(rect.getAttribute('width'))-(center?12:x+12):null);
  if(!(width>0))continue;
  const full=t._fullText??t.textContent,limit=t._lineLimit||1; t._fullText=full;
  const measure=value=>{t.textContent=value;return t.getComputedTextLength()};
  const lines=[];let line='';const tokens=full.split(/\s+/);
  for(let token of tokens){
   if(line&&measure(line+' '+token)<=width){line+=' '+token;continue}
   if(line){lines.push(line);line=''}
   while(token&&measure(token)>width){let lo=1,hi=token.length;while(lo<hi){const mid=Math.ceil((lo+hi)/2);if(measure(token.slice(0,mid))<=width)lo=mid;else hi=mid-1}lines.push(token.slice(0,lo));token=token.slice(lo)}
   line=token;
  }
  if(line)lines.push(line);
  const visible=lines.slice(0,limit);if(lines.length>limit){let last=visible[limit-1];while(last&&measure(last+'…')>width)last=last.slice(0,-1);visible[limit-1]=last+'…'}
  t.replaceChildren();visible.forEach((line,i)=>t.append(svg('tspan',{x,dy:i?19:0},line)));
  t.setAttribute('aria-label',full);t.setAttribute('data-fitted-width',width);
 }
}
function node(n,x,y,w=260,h=150){let g=svg('g',{class:'node',role:'button',tabindex:0,'aria-label':'Component '+n.id+': '+n.label,'data-kind':'node','data-id':n.id,transform:`translate(${x} ${y})`});g.append(svg('rect',{width:w,height:h,rx:8}));label(g,n.id,14,22,'identity',30,1,w-28);label(g,n.label,14,49,'label',Math.floor((w-28)/10),2,w-28);label(g,n.technical_id||'Technical identifier: not provided',14,91,'technical',Math.floor((w-28)/7.2),2,w-28);label(g,typeof n.evidence==='string'?n.evidence:n.evidence.state,14,135,'state',40,1,w-28);return g}
// Presentation rules classify exact supplied values; they do not infer deployment.
const EVIDENCE_STYLES={
 neutral:{color:'#555555',dash:'',label:'Unmapped evidence (raw value retained)'},
 documented:{color:'#286080',dash:'',label:'Documented'},
 observed:{color:'#347466',dash:'',label:'Observed'},
 draft:{color:'#865EAD',dash:'7 5',label:'Draft'},
 historical:{color:'#8A6A3D',dash:'7 5',label:'Historical'},
 proposed:{color:'#865EAD',dash:'7 5',label:'Proposed'},
 unknown:{color:'#686868',dash:'7 5',label:'Unknown / unresolved'},
 unverified:{color:'#686868',dash:'7 5',label:'Unverified'},
 disabled:{color:'#B04444',dash:'7 5',label:'Explicitly disabled (status override)'}
};
function exactField(object,field){return field.split('.').reduce((value,key)=>value==null?undefined:value[key],object)}
function presentationState(flow){
 const raw=typeof flow.evidence==='string'?flow.evidence:flow.evidence.state;
 const rule=PRESENTATION.evidence_rules.find(r=>exactField(flow,r.field)===r.equals);
 const evidenceClass=rule?rule.class:'neutral';
 const flags=[...new Set(PRESENTATION.status_rules.filter(r=>exactField(flow,r.field)===r.equals).flatMap(r=>r.flags))];
 const styleClass=flags.includes('disabled')?'disabled':evidenceClass;
 return{raw,evidenceClass,flags,styleClass,style:EVIDENCE_STYLES[styleClass]};
}
function attachedPoint(points,hint={}){
 if(Object.keys(hint).some(k=>!['label_segment','label_fraction'].includes(k)))throw new Error('Labels must attach to a route segment; free coordinates are unsupported');
 if(!Array.isArray(points)||points.length<2||points.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)))throw new Error('A route needs at least two finite points');
 const lengths=points.slice(1).map((p,i)=>Math.hypot(p.x-points[i].x,p.y-points[i].y));
 if(!lengths.some(x=>x>0))throw new Error('A route cannot have zero length');
 if(hint.label_segment!==undefined){
  const i=hint.label_segment,t=hint.label_fraction===undefined?.5:hint.label_fraction;
  if(!Number.isInteger(i)||i<0||i>=lengths.length||lengths[i]===0||!Number.isFinite(t)||t<0||t>1)throw new Error('Invalid route-attached label segment/fraction');
  return{x:points[i].x+(points[i+1].x-points[i].x)*t,y:points[i].y+(points[i+1].y-points[i].y)*t};
 }
 if(hint.label_fraction!==undefined)throw new Error('label_fraction requires label_segment');
 let remain=lengths.reduce((a,b)=>a+b,0)/2;
 for(let i=0;i<lengths.length;i++){if(remain<=lengths[i]&&lengths[i]>0){const t=remain/lengths[i];return{x:points[i].x+(points[i+1].x-points[i].x)*t,y:points[i].y+(points[i+1].y-points[i].y)*t};}remain-=lengths[i];}
 return{...points.at(-1)};
}
function drawFlow(world,flow,points,hint={}){
 const state=presentationState(flow),a=attachedPoint(points,hint),markerId='evidence-arrow-'+state.styleClass;
 let defs=$('diagram').querySelector('defs');
 if(!$(markerId)){const marker=svg('marker',{id:markerId,markerWidth:10,markerHeight:8,refX:9,refY:4,orient:'auto',markerUnits:'userSpaceOnUse'});marker.append(svg('path',{d:'M0,0 L10,4 L0,8 z',fill:state.style.color}));defs.append(marker);}
 const route=svg('path',{d:points.map((p,i)=>(i?'L':'M')+p.x+' '+p.y).join(' '),class:'route','marker-end':'url(#'+markerId+')','data-kind':'flow','data-id':flow.id,'data-flow-route':flow.id,'data-evidence-class':state.evidenceClass,'data-style-class':state.styleClass,'data-status-flags':state.flags.join(' '),'aria-hidden':'true'});
 route.style.setProperty('--evidence-color',state.style.color);route.style.strokeDasharray=state.style.dash||'none';
 const badge=svg('g',{class:'flow-badge',role:'button',tabindex:0,'aria-label':'Flow '+flow.id+': '+flow.label+'; evidence: '+state.raw+(state.flags.length?'; status flags: '+state.flags.join(', '):''),'data-kind':'flow','data-id':flow.id,'data-evidence-class':state.evidenceClass,'data-style-class':state.styleClass,'data-status-flags':state.flags.join(' '),transform:`translate(${a.x-32} ${a.y-19})`});
 badge.style.setProperty('--evidence-color',state.style.color);badge.append(svg('rect',{width:64,height:38,rx:7}),svg('text',{x:32,y:24,'text-anchor':'middle'},flow.id));
 world.prepend(route);world.append(badge);return{route,badge,anchor:a,presentation:state};
}
function renderEvidenceLegendBase(){
 const box=$('evidenceLegend');box.replaceChildren(element('strong','Evidence/status line styles'));
 const used=[...new Set(DATA.flows.map(f=>presentationState(f).styleClass))];
 for(const key of used){const style=EVIDENCE_STYLES[key],item=element('span',null,{'data-legend-class':key});const sample=svg('svg',{width:54,height:20,viewBox:'0 0 54 20','aria-hidden':'true'});sample.append(svg('path',{d:'M3 10H51',fill:'none',stroke:style.color,'stroke-width':3,'stroke-dasharray':style.dash||'none'}));item.append(sample,document.createTextNode(style.label));box.append(item);}
 box.append(element('small','Exact original evidence and status flags remain in the inspector and register. Unmatched custom or negated text is neutral; line styling is not deployment or approval evidence.'));
}

function renderBase(){let v=views.find(x=>x.id===state.view),world=$('world');world.replaceChildren();if(v.flow){let f=v.flow;world.append(node(nodes.get(f.source),55,155,300),node(nodes.get(f.target),765,155,300));let rendered=drawFlow(world,f,[{x:355,y:230},{x:765,y:230}]);let text=svg('g',{'aria-hidden':'true'});label(text,f.label,375,290,'identity',48,2,370);label(text,category(f)+' · '+(typeof f.evidence==='string'?f.evidence:f.evidence.state),375,345,'state',50,2,370);world.append(text);$('viewHelp').textContent=f.id+': '+f.source+' → '+f.target+'. '+evidence(f.evidence)+(rendered.presentation.flags.length?' · status flags: '+rendered.presentation.flags.join(', '):'')+' Full exact values remain in the inspector/register.';}else{v.nodes.forEach((n,i)=>world.append(node(n,16+(i%4)*276,45+Math.floor(i/4)*196)));$('viewHelp').textContent='Component index only. Choose an individual flow above to inspect its exact source → target relationship. No security zones are inferred.';}fitLabels(world);reset();applyVisibility();paintSelection()}
function searchable(x){return JSON.stringify(x).toLowerCase()}
function visibility(){let q=state.query.trim().toLowerCase(),fm=new Map(),nm=new Map();for(const f of DATA.flows)fm.set(f.id,state.allowed.has(category(f))&&(!q||searchable([f,nodes.get(f.source),nodes.get(f.target)]).includes(q)));for(const n of DATA.nodes)nm.set(n.id,!q||searchable(n).includes(q)||DATA.flows.some(f=>fm.get(f.id)&&(f.source===n.id||f.target===n.id)));return{flows:fm,nodes:nm}}
function applyVisibilityBase(){const vis=visibility();document.querySelectorAll('[data-kind][data-id]').forEach(el=>{const on=(el.dataset.kind==='flow'?vis.flows:vis.nodes).get(el.dataset.id);el.classList.toggle('is-hidden',!on)});document.querySelectorAll('tr[data-record-kind]').forEach(el=>el.classList.toggle('is-hidden',!(el.dataset.recordKind==='flow'?vis.flows:vis.nodes).get(el.dataset.recordId)));$('counts').textContent=`Visible catalogue: ${[...vis.nodes.values()].filter(Boolean).length}/${DATA.nodes.length} components; ${[...vis.flows.values()].filter(Boolean).length}/${DATA.flows.length} directed flows. Filters and search use the same visibility rule in diagram and registers.`;if(state.selected&&!(state.selected.kind==='flow'?vis.flows:vis.nodes).get(state.selected.id))select(null);}
function paintSelection(){document.querySelectorAll('[data-kind][data-id]').forEach(el=>{const chosen=!!state.selected&&el.dataset.kind===state.selected.kind&&el.dataset.id===state.selected.id;el.classList.toggle('selected',chosen);if(el.getAttribute('role')==='button'||el.tagName==='BUTTON')el.setAttribute('aria-pressed',String(chosen))})}
function selectBase(value){state.selected=value;paintSelection();let box=$('inspector');box.replaceChildren(element('h2',value?(value.kind==='node'?'Component ':'Flow ')+value.id:'Inspector'));if(!value){delete box.dataset.selectedKind;delete box.dataset.selectedId;box.append(element('p','Select a component or numbered flow badge. Enter or Space activates the focused control. Escape clears selection.'));$('live').textContent='Selection cleared';return}let obj=(value.kind==='node'?nodes:flows).get(value.id),dl=element('dl');for(const[k,v]of Object.entries(obj)){dl.append(element('dt',k.replaceAll('_',' ')),element('dd',k==='evidence'?evidence(v):str(v)))}box.append(dl);const citations=element('p','Sources: ');for(const ref of obj.source_ids){citations.append(element('a',ref,{href:'#source-'+encodeURIComponent(ref)}),document.createTextNode(' '))}box.append(citations);box.dataset.selectedKind=value.kind;box.dataset.selectedId=value.id;$('live').textContent=(value.kind==='node'?'Component ':'Flow ')+value.id+' selected';}
function activate(event){let el=event.target.closest('[data-kind][data-id]');if(!el)return;select({kind:el.dataset.kind,id:el.dataset.id})}
document.addEventListener('click',activate);
document.addEventListener('keydown',e=>{if(e.key==='Escape'){select(null);return}let el=e.target.closest('svg [role="button"]');if(el&&(e.key==='Enter'||e.key===' ')){e.preventDefault();select({kind:el.dataset.kind,id:el.dataset.id})}});
function transform(){$('world').setAttribute('transform',`translate(${state.tx} ${state.ty}) scale(${state.scale})`)}
function reset(){state.tx=state.ty=0;state.scale=1;transform()}
function point(clientX,clientY){let pt=$('diagram').createSVGPoint();pt.x=clientX;pt.y=clientY;return pt.matrixTransform($('diagram').getScreenCTM().inverse())}
function zoom(factor,anchor){if(!anchor){const box=$('diagram').viewBox.baseVal;anchor={x:box.x+box.width/2,y:box.y+box.height/2};}let next=Math.min(state.view==='overview'?12:3,Math.max(.5,state.scale*factor));state.tx=anchor.x-(anchor.x-state.tx)/state.scale*next;state.ty=anchor.y-(anchor.y-state.ty)/state.scale*next;state.scale=next;transform()}
let drag=null;$('diagram').addEventListener('pointerdown',e=>{if(e.button!==0||e.target.closest('[data-kind]'))return;drag={p:point(e.clientX,e.clientY),tx:state.tx,ty:state.ty,x:e.clientX,y:e.clientY,moved:false};$('diagram').setPointerCapture(e.pointerId)});
$('diagram').addEventListener('pointermove',e=>{if(!drag)return;const p=point(e.clientX,e.clientY);if(Math.hypot(e.clientX-drag.x,e.clientY-drag.y)>2)drag.moved=true;state.tx=drag.tx+p.x-drag.p.x;state.ty=drag.ty+p.y-drag.p.y;transform()});
$('diagram').addEventListener('pointerup',e=>{if(!drag)return;const moved=drag.moved;drag=null;if($('diagram').hasPointerCapture(e.pointerId))$('diagram').releasePointerCapture(e.pointerId);if(!moved)select(null)});
$('diagram').addEventListener('pointercancel',()=>drag=null);
$('diagram').addEventListener('wheel',e=>{e.preventDefault();zoom(e.deltaY<0?1.1:1/1.1,point(e.clientX,e.clientY))},{passive:false});
$('diagram').addEventListener('keydown',e=>{if(e.target!==$('diagram'))return;let delta={ArrowRight:[-40,0],ArrowLeft:[40,0],ArrowUp:[0,40],ArrowDown:[0,-40]}[e.key];if(delta){e.preventDefault();state.tx+=delta[0];state.ty+=delta[1];transform()}});
function rowButton(kind,item){return element('button',item.id,{'data-kind':kind,'data-id':item.id,'aria-label':'Inspect '+(kind==='node'?'component ':'flow ')+item.id})}
function registers(){for(const n of DATA.nodes){let r=element('tr',null,{'data-record-kind':'node','data-record-id':n.id});let c=element('td');c.append(rowButton('node',n));r.append(c,element('td',n.label+'\n'+(n.technical_id||'Not provided')),element('td',n.role||str(n.details)),element('td',evidence(n.evidence)));$('nodesTable').tBodies[0].append(r)}for(const f of DATA.flows){let r=element('tr',null,{'data-record-kind':'flow','data-record-id':f.id}),c=element('td');c.append(rowButton('flow',f));r.append(c,element('td',f.source+' → '+f.target+'\n'+f.label),element('td','Interface: '+str(f.protocol)+'\nInterface evidence: '+f.protocol_state+'\nTransport: '+str(f.transport)),element('td',evidence(f.evidence)+'\nCategory: '+category(f)+(presentationState(f).flags.length?'\nStatus flags: '+presentationState(f).flags.join(', '):'')));$('flowsTable').tBodies[0].append(r)}}
$('title').textContent=DATA.title;document.title=DATA.title;$('scope').textContent=str(DATA.scope||'Scope not provided');
for(const v of views)$('view').append(element('option',v.label,{value:v.id}));
function selectionInView(value){
 if(!value)return false;
 if(state.view==='overview')return ['group','aggregate'].includes(value.kind);
 const view=views.find(x=>x.id===state.view);
 if(view.flow)return value.kind==='flow'?value.id===view.flow.id:value.kind==='node'&&[view.flow.source,view.flow.target].includes(value.id);
 return value.kind==='node'&&view.nodes.some(n=>n.id===value.id);
}
$('view').addEventListener('change',()=>{state.view=$('view').value;if(state.selected&&!selectionInView(state.selected))select(null);render()});
for(const c of [...state.allowed]){let lab=element('label'),input=element('input',null,{type:'checkbox','data-category':c});input.checked=true;input.addEventListener('change',()=>{if(input.checked)state.allowed.add(c);else state.allowed.delete(c);applyVisibility()});lab.append(input,document.createTextNode(' '+c));$('filters').append(lab)}
$('search').addEventListener('input',()=>{state.query=$('search').value;applyVisibility()});$('clearSearch').onclick=()=>{$('search').value='';state.query='';applyVisibility()};$('zoomIn').onclick=()=>zoom(1.2);$('zoomOut').onclick=()=>zoom(1/1.2);$('reset').onclick=reset;
$('download').onclick=()=>{const blob=new Blob([JSON.stringify(DATA,null,2)+'\n'],{type:'application/json;charset=utf-8'}),url=URL.createObjectURL(blob),a=element('a',null,{href:url,download:'architecture-source.json'});document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000)};
for(const s of DATA.sources){let d=element('article',null,{class:'source',id:'source-'+s.id});d.append(element('h3',s.id+' - '+s.title));for(const k of ['version','date','status'])d.append(element('p',k+': '+str(s[k])));if(s.url)d.append(element('a','Open source',{href:s.url,target:'_blank',rel:'noopener noreferrer'}));else d.append(element('p','External URL: not provided'));$('sources').append(d)}
for(const k of ['notes','facts','actions'])if(DATA[k]!=null){$('extra').append(element('h3',k),element('pre',str(DATA[k]),{class:'extra'}))}
// Native connected view. Exact groups, ports, routes and badge geometry are
// supplied by ulta_architecture_overview.layout; there is no second router.
const groups=new Map((OVERVIEW?.groups||[]).map(x=>[x.id,x]));
const aggregates=new Map((OVERVIEW?.aggregates||[]).map(x=>[x.id,x]));
const focusOverviewButton=element('button','Zoom to overview selection',{id:'focusOverview'});
focusOverviewButton.onclick=()=>{
 if(state.view!=='overview'||!state.selected||!['group','aggregate'].includes(state.selected.kind)){$('live').textContent='Select an overview group or aggregate label first.';return}
 const diagram=$('diagram'),selected=diagramRecord(state.selected.kind,state.selected.id),r=state.selected.kind==='group'?selected:selected.badge,v=diagram.viewBox.baseVal;
 const control=diagram.querySelector(`[role="button"][data-kind="${state.selected.kind}"][data-id="${CSS.escape(state.selected.id)}"]`),matrix=diagram.getScreenCTM();
 const baseFontPx=Math.min(...[...control.querySelectorAll('text')].map(t=>parseFloat(getComputedStyle(t).fontSize)))*Math.hypot(matrix.a,matrix.b);
 const fit=Math.min(v.width/r.width,v.height/r.height),readable=13.1/baseFontPx;
 // Keep the usual 10% fit margin when readable; use up to 98% of the view
 // for the 13px floor. Geometry and source labels remain unchanged.
 state.scale=Math.min(12,.98*fit,Math.max(.5,.90*fit,readable));
 state.tx=v.x+v.width/2-(r.x+r.width/2)*state.scale;state.ty=v.y+v.height/2-(r.y+r.height/2)*state.scale;transform();
 if(baseFontPx*state.scale<13)$('live').textContent='Selection fits the diagram, but its text remains below 13 pixels. Use browser zoom or the inspector for readable details.';
};
const overviewFocus=element('select',null,{id:'overviewFocus','aria-label':'Focus an overview group or flow set'});
if(OVERVIEW){
 overviewFocus.append(element('option','Choose a group or flow set',{value:''}));
 for(const g of groups.values())overviewFocus.append(element('option',g.id+' - '+g.label,{value:'group:'+g.id}));
 for(const a of aggregates.values())overviewFocus.append(element('option',a.id+' '+a.source_group+' → '+a.target_group+' | '+a.flow_ids.join(', '),{value:'aggregate:'+a.id}));
 const label=element('label','Overview focus ');label.append(overviewFocus);document.querySelector('.toolbar').append(label,focusOverviewButton);
 overviewFocus.onchange=()=>{if(!overviewFocus.value)return;const[kind,id]=overviewFocus.value.split(':');if(state.view!=='overview'){state.view='overview';$('view').value=state.view;render()}select({kind,id});focusOverviewButton.onclick()};
}
EVIDENCE_STYLES.mixed={color:'#555555',dash:'',label:'Mixed source fields - inspect every member'};
function aggregatePresentation(a){
 const memberStates=a.members.map(presentationState);
 const classes=[...new Set(memberStates.map(x=>x.evidenceClass))];
 const flags=[...new Set(memberStates.map(x=>JSON.stringify([...x.flags].sort())))];
 let key=a.attributes.mixed_fields.length||classes.length>1||flags.length>1?'mixed':memberStates.every(x=>x.flags.includes('disabled'))?'disabled':classes[0];
 return {key,style:EVIDENCE_STYLES[key],memberStates};
}
function diagramRecord(kind,id){return(kind==='node'?nodes:kind==='flow'?flows:kind==='group'?groups:aggregates).get(id)}
function recordVisible(kind,id,vis){
 if(kind==='node')return vis.nodes.get(id);
 if(kind==='flow')return vis.flows.get(id);
 if(kind==='group')return groups.get(id).member_node_ids.some(x=>vis.nodes.get(x));
 return aggregates.get(id).flow_ids.some(x=>vis.flows.get(x));
}
function applyVisibility(){
 if(!OVERVIEW){applyVisibilityBase();return}
 const vis=visibility();
 document.querySelectorAll('[data-kind][data-id]').forEach(el=>el.classList.toggle('is-hidden',!recordVisible(el.dataset.kind,el.dataset.id,vis)));
 document.querySelectorAll('tr[data-record-kind]').forEach(el=>el.classList.toggle('is-hidden',!recordVisible(el.dataset.recordKind,el.dataset.recordId,vis)));
 document.querySelectorAll('[data-crossing-over]').forEach(el=>el.classList.toggle('is-hidden',!recordVisible('aggregate',el.dataset.crossingOver,vis)||!recordVisible('aggregate',el.dataset.crossingUnder,vis)));
 for(const a of aggregates.values()){const el=$('visible-'+a.id);if(el)el.textContent=`${a.flow_ids.filter(x=>vis.flows.get(x)).length}/${a.flow_ids.length} members visible`;}
 $('counts').textContent=`Visible catalogue: ${[...vis.nodes.values()].filter(Boolean).length}/${DATA.nodes.length} components; ${[...vis.flows.values()].filter(Boolean).length}/${DATA.flows.length} directed flows. Diagram, aggregate visibility and registers use the same source-flow predicate.`;
 if(state.selected&&!recordVisible(state.selected.kind,state.selected.id,vis))select(null);
 else if(state.selected&&['group','aggregate'].includes(state.selected.kind))select(state.selected);
}
function openFlow(id){state.view='flow-'+id;$('view').value=state.view;render();select({kind:'flow',id});$('diagram').querySelector(`[role="button"][data-kind="flow"][data-id="${CSS.escape(id)}"]`).focus()}
function memberFlow(parent,f){
 const section=element('div',null,{class:'member-item','data-member-flow':f.id});
 section.append(element('strong',f.id+': '+f.source+' → '+f.target+' - '+f.label));
 const p=presentationState(f),visible=visibility().flows.get(f.id);
 section.append(element('p',evidence(f.evidence)+' · '+category(f)+(p.flags.length?' · flags: '+p.flags.join(', '):'')+(visible?'':' · hidden by current search/filter')));
 const button=element('button','Open focused flow '+f.id,{'data-open-flow':f.id});button.onclick=()=>{if(!visible){$('search').value='';state.query='';state.allowed.add(category(f));document.querySelectorAll('#filters input').forEach(x=>x.checked=state.allowed.has(x.dataset.category));}openFlow(f.id)};section.append(button);parent.append(section);
}
function select(value){
 if(!value||['node','flow'].includes(value.kind)){selectBase(value);return}
 state.selected=value;paintSelection();const box=$('inspector'),obj=diagramRecord(value.kind,value.id);
 box.replaceChildren(element('h2',(value.kind==='group'?'Presentation group ':'Aggregate ')+obj.id));box.dataset.selectedKind=value.kind;box.dataset.selectedId=value.id;
 if(value.kind==='group'){
  box.append(element('h3',obj.label),element('p','Functional presentation only; no ownership, security or deployment boundary is inferred.'));
  const list=element('div',null,{class:'member-list'});for(const id of obj.member_node_ids){const b=element('button','Inspect component '+id);b.onclick=()=>select({kind:'node',id});list.append(b)}box.append(list);
  box.append(element('h3','Internal flows ('+obj.internal_flow_ids.length+')'));for(const id of obj.internal_flow_ids)memberFlow(box,flows.get(id));
  const cross=DATA.flows.filter(f=>obj.member_node_ids.includes(f.source)!==obj.member_node_ids.includes(f.target));box.append(element('h3','Cross-group flows ('+cross.length+')'));for(const f of cross)memberFlow(box,f);
 }else{
  box.append(element('p',obj.source_group+' → '+obj.target_group+'; exact members: '+obj.flow_ids.join(', ')),element('p','This arrow aggregates the listed original flows. It does not imply a new interface. Aggregate style uses all original member fields, including members hidden by filters.'));
  const ap=aggregatePresentation(obj);box.append(element('p','Overview style: '+ap.key+'; mixed fields: '+(obj.attributes.mixed_fields.join(', ')||'none')));
  for(const f of obj.members)memberFlow(box,f);
 }
 $('live').textContent=(value.kind==='group'?'Presentation group ':'Aggregate ')+obj.id+' selected';
}
function renderEvidenceLegend(){
 if(!OVERVIEW){renderEvidenceLegendBase();return}
 const box=$('evidenceLegend');box.replaceChildren(element('strong',state.view==='overview'?'Overview aggregate evidence/status':'Focused flow evidence/status'));
 const used=[...new Set(state.view==='overview'?(OVERVIEW?.aggregates||[]).map(a=>aggregatePresentation(a).key):DATA.flows.map(f=>presentationState(f).styleClass))];
 for(const key of used){const style=EVIDENCE_STYLES[key],item=element('span',null,{'data-legend-class':key});const sample=svg('svg',{width:54,height:20,viewBox:'0 0 54 20','aria-hidden':'true'});sample.append(svg('path',{d:'M3 10H51',fill:'none',stroke:style.color,'stroke-width':3,'stroke-dasharray':style.dash||'none'}));item.append(sample,document.createTextNode(style.label));box.append(item)}
 box.append(element('small','Unmapped or negated text is neutral; explicitly unknown is dashed. Styles do not imply deployment or approval. Overview styles represent all original aggregate members; filters change visibility, not evidence. White crossing gaps mean no junction.'));
}
function drawAggregate(world,a){
 const ap=aggregatePresentation(a),style=ap.style,markerId='aggregate-arrow-'+ap.key;let defs=$('diagram').querySelector('defs');
 if(!$(markerId)){const m=svg('marker',{id:markerId,markerWidth:10,markerHeight:8,refX:9,refY:4,orient:'auto',markerUnits:'userSpaceOnUse'});m.append(svg('path',{d:'M0,0 L10,4 L0,8 z',fill:style.color}));defs.append(m)}
 const route=svg('path',{d:a.points.map((p,i)=>(i?'L':'M')+p.x+' '+p.y).join(' '),class:'route aggregate-route','marker-end':'url(#'+markerId+')','data-kind':'aggregate','data-id':a.id,'data-style-class':ap.key,'aria-hidden':'true'});route.style.setProperty('--evidence-color',style.color);route.style.strokeDasharray=style.dash||'none';world.prepend(route);
 // The shared module supplies a clear source segment. Derive the anchor from
 // the actual polyline; reject off-segment/floating geometry instead of trusting it.
 const fraction=(a.badge.x+a.badge.width/2-a.points[0].x)/(a.points[1].x-a.points[0].x);
 const anchor=attachedPoint(a.points,{label_segment:0,label_fraction:fraction});
 if(Math.abs(anchor.y-(a.badge.y+a.badge.height/2))>.001)throw new Error('Shared badge is not attached to its source segment');
 const badge=svg('g',{class:'flow-badge aggregate-badge',role:'button',tabindex:0,'aria-label':'Aggregate '+a.id+': '+a.source_group+' to '+a.target_group+'; member flows '+a.flow_ids.join(', '),'data-kind':'aggregate','data-id':a.id,'data-style-class':ap.key,transform:`translate(${anchor.x-a.badge.width/2} ${anchor.y-a.badge.height/2})`});badge.style.setProperty('--evidence-color',style.color);badge.append(svg('rect',{width:a.badge.width,height:a.badge.height,rx:7}));
 // Preserve shared wrapped fields; replace only its style line with the
 // explicitly shared HTML mapping for unclassified versus unknown evidence.
 a.badge_lines.forEach((line,i)=>badge.append(svg('text',{x:12,y:25+i*22},line.startsWith('Style: ')?'Style: '+ap.key:line)));
 world.append(badge);return{route,badge};
}
function render(){
 const diagram=$('diagram');diagram.setAttribute('viewBox','0 0 1120 500');diagram.style.height='510px';
 focusOverviewButton.disabled=state.view!=='overview';overviewFocus.disabled=state.view!=='overview';overviewFocus.value='';
 if(!OVERVIEW||state.view!=='overview'){renderBase();renderEvidenceLegend();return}
 const world=$('world');world.replaceChildren();const c=OVERVIEW.canvas;diagram.setAttribute('viewBox',`0 260 ${c.width} ${c.height-260}`);diagram.style.height='700px';
 for(const a of OVERVIEW.aggregates)drawAggregate(world,a);
 for(const x of OVERVIEW.crossings){const ap=aggregatePresentation(aggregates.get(x.over)),g=svg('g',{class:'crossing','data-crossing-over':x.over,'data-crossing-under':x.under,'aria-hidden':'true'});g.append(svg('path',{d:`M${x.x-x.size/2} ${x.y}h${x.size}`,stroke:'white','stroke-width':9}),svg('path',{d:`M${x.x-x.size/2} ${x.y}h${x.size}`,stroke:ap.style.color,'stroke-width':3,'stroke-dasharray':ap.style.dash||'none'}));world.append(g)}
 for(const g of OVERVIEW.groups){const el=svg('g',{class:'group-box',role:'button',tabindex:0,'aria-label':'Presentation group '+g.id+': '+g.label+'; components '+g.member_node_ids.join(', '),'data-kind':'group','data-id':g.id,transform:`translate(${g.x} ${g.y})`});el.append(svg('rect',{width:g.width,height:g.height,rx:8}));label(el,g.id+' - '+g.label,16,32,'',34,2);g.body_lines.forEach((line,i)=>el.append(svg('text',{x:16,y:95+i*22},line)));world.append(el)}
 $('viewHelp').textContent=`Connected functional overview: ${OVERVIEW.groups.length} presentation groups; ${OVERVIEW.aggregates.length} aggregate arrows. Select a group/aggregate for every exact member flow and its focused view. Full atomic endpoints are not shown here. Large canvases need zoom/pan; reset fits the whole overview. This is not a one-screen executive diagram.`;
 fitLabels(world);reset();applyVisibility();paintSelection();renderEvidenceLegend();
}

registers();renderEvidenceLegend();render();
</script></html>'''


def validate_presentation(config):
    if not isinstance(config, dict):
        raise ValueError('Presentation config must be an object')
    if set(config) - {'evidence_rules', 'status_rules'}:
        raise ValueError('--presentation supports only evidence_rules and status_rules; use --overview for explicit connected grouping')
    allowed_classes = {'documented', 'observed', 'draft', 'historical', 'proposed', 'unknown', 'unverified'}
    allowed_flags = {'disabled', 'proposed', 'historical', 'unknown', 'unverified'}
    result = {'evidence_rules': config.get('evidence_rules', []), 'status_rules': config.get('status_rules', [])}
    for kind, rules in result.items():
        if not isinstance(rules, list):
            raise ValueError(kind + ' must be a list')
        seen = set()
        for rule in rules:
            if not isinstance(rule, dict) or not isinstance(rule.get('equals'), str):
                raise ValueError(kind + ' rules require exact string equals')
            fields = {'evidence', 'evidence.state'} if kind == 'evidence_rules' else {'status', 'details.status', 'flow_type'}
            if rule.get('field') not in fields:
                raise ValueError('Unsupported exact-match rule field')
            key = (rule['field'], rule['equals'])
            if key in seen:
                raise ValueError('Duplicate exact-match rule')
            seen.add(key)
            if kind == 'evidence_rules' and rule.get('class') not in allowed_classes:
                raise ValueError('Unsupported evidence class')
            if kind == 'status_rules' and (not isinstance(rule.get('flags'), list) or not rule['flags'] or any(x not in allowed_flags for x in rule['flags'])):
                raise ValueError('Unsupported status flags')
    return result


def safe_json(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':')).replace('<', '\\u003c').replace('&', '\\u0026')


def build(data, presentation=None, overview=None):
    """Return standalone HTML, validation counts and optional shared geometry.

    --overview includes the exact evidence/status rules used by all views.
    It is mutually exclusive with --presentation, avoiding diverging legends.
    """
    counts = validate(data)
    geometry = None
    if overview is not None:
        if not data['flows']:
            raise ValueError('Connected overview requires at least one supplied directed flow')
        if presentation is not None:
            raise ValueError('Use either --overview (with evidence/status rules) or --presentation, not both')
        import ulta_architecture_overview as shared
        geometry = shared.layout(data, overview, max_badge_lines=16)
        if geometry['checks']['violations']:
            raise ValueError('Shared overview geometry failed: ' + str(geometry['checks']['violations']))
        ids = [x['id'] for x in geometry['groups'] + geometry['aggregates']]
        if len(set(ids)) != len(ids):
            raise ValueError('Presentation group IDs must differ from generated aggregate IDs')
        config = validate_presentation({k:overview.get(k,[]) for k in ('evidence_rules','status_rules')})
    else:
        config = validate_presentation(presentation if presentation is not None else {})
    notice = ('The connected overview aggregates explicit functional presentation groups; it does not show every atomic endpoint. Grouping establishes no ownership, security or deployment boundary. Use the readable Overview focus list or select a group/aggregate and Zoom to overview selection, and open any exact member flow. Focused views preserve exact endpoints.' if geometry is not None else 'A component index is not a whole-system topology. Focused flow views preserve each directed relationship without crowded routing.')
    html = HTML.replace('__DATA__',safe_json(data)).replace('__PRESENTATION__',safe_json(config)).replace('__OVERVIEW__',safe_json(geometry)).replace('__OVERVIEW_NOTICE__',notice)
    return html, counts, geometry, config


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('input', type=Path)
    ap.add_argument('output', type=Path)
    ap.add_argument('--report', type=Path)
    config_args = ap.add_mutually_exclusive_group()
    config_args.add_argument('--presentation', type=Path)
    config_args.add_argument('--overview', type=Path)
    args = ap.parse_args()
    paths = [p.resolve() for p in (args.input,args.output,args.report,args.presentation,args.overview) if p]
    if len(paths)!=len(set(paths)):
        raise ValueError('Input, output, report and presentation/overview paths must differ')
    data = json.loads(args.input.read_text(encoding='utf-8'))
    presentation = json.loads(args.presentation.read_text(encoding='utf-8')) if args.presentation else None
    overview = json.loads(args.overview.read_text(encoding='utf-8')) if args.overview else None
    html, counts, geometry, config = build(data,presentation,overview)
    output = html.encode('utf-8')
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_bytes(output)
    report = {'result':'generated; browser and delivery checks still required',**counts,
              'bytes':len(output),'sha256':hashlib.sha256(output).hexdigest(),
              'layout':'connected functional group overview plus complete component indexes and focused flows' if geometry else 'paginated component indexes and one focused view per flow',
              'external_runtime_dependencies':[],'source_json_preserved':True,'presentation_rules':config,
              'shared_geometry':{'canvas':geometry['canvas'],'checks':geometry['checks'],'groups':len(geometry['groups']),'aggregates':len(geometry['aggregates'])} if geometry else None,
              'limitations':['No source-truth or completeness inference','Self-loops unsupported and rejected',
                             'Long diagram labels may be visibly shortened; full exact values remain accessible in registers and inspectors',
                             'Connected overview groups are presentation-only; exact atomic endpoints are in focused views',
                             'Large overview fit is orientation-only; Zoom to overview selection supplies readable group/aggregate detail',
                             'Native client download is not verified by authoring this file']}
    if args.report:
        args.report.parent.mkdir(parents=True,exist_ok=True)
        args.report.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
