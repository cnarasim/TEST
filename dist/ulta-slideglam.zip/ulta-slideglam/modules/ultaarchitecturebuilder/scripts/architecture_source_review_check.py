#!/usr/bin/env python3
"""Read-only local evidence-binding check. No semantic or authenticity inference."""
import argparse
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import sys
from urllib.parse import urlsplit
import xml.etree.ElementTree as ET

VERSION = '0.1.0-candidate'
MAX_BYTES = 64 * 1024 * 1024
LIMITS = {'source_authenticity': 'NOT_CHECKED', 'semantic_entailment': 'NOT_CHECKED',
          'atomic_completeness': 'REVIEWER_ATTESTED', 'visible_rendering': 'NOT_CHECKED',
          'HTML_runtime_hyperlinks': 'NOT_CHECKED', 'deployment_or_approval': 'NOT_CHECKED'}
TOP = {'title', 'scope', 'nodes', 'flows', 'sources', 'notes', 'facts', 'actions', 'fixture_source'}
NODE = {'id', 'label', 'technical_id', 'role', 'zone', 'details', 'source_ids', 'evidence'}
FLOW = {'id', 'source', 'target', 'label', 'protocol', 'protocol_state', 'transport', 'flow_type',
        'details', 'source_ids', 'evidence'}
SOURCE = {'id', 'title', 'url', 'version', 'date', 'status'}
EVIDENCE = {'state', 'as_of', 'note'}
GOOD = {'SUPPORTED', 'SUPPORTED_WITH_SCOPE'}
VERDICTS = GOOD | {'UNVERIFIED', 'UNSUPPORTED', 'CONTRADICTED', 'PROPOSED'}
KINDS = {'named_system', 'named_object', 'named_actor_group', 'logical_responsibility', 'unknown_party'}
RELATIONS = {'direct_interface', 'data_read', 'data_write', 'user_access', 'indirect_influence',
             'logical_requirement', 'proposed_alternative'}


def digest(b):
    return hashlib.sha256(b).hexdigest()


def canonical(x):
    return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def pairs(items):
    d = {}
    for k, v in items:
        if k in d:
            raise ValueError('Duplicate JSON key: ' + k)
        d[k] = v
    return d


def decode(b):
    return json.loads(b, object_pairs_hook=pairs,
                      parse_constant=lambda x: (_ for _ in ()).throw(ValueError('Nonfinite JSON: ' + x)))


def read(path):
    p = Path(path)
    if not p.is_file() or p.stat().st_size > MAX_BYTES:
        raise ValueError('Missing/non-file/oversize input: ' + str(p))
    return p.read_bytes()


def pointer(s):
    return str(s).replace('~', '~0').replace('/', '~1')


class Check:
    def __init__(self):
        self.failures = []
        self.unverified = []
        self.inputs = {}
        self.read_paths = set()
        self.snapshots = {}

    def snapshot(self, path):
        p = Path(path).resolve()
        self.read_paths.add(p)
        if p not in self.snapshots:
            self.snapshots[p] = read(p)
        return self.snapshots[p]

    def fail(self, code, where, detail):
        self.failures.append({'code': code, 'location': where, 'detail': detail})

    def unknown(self, code, where, detail):
        self.unverified.append({'code': code, 'location': where, 'detail': detail})

    def load(self, path, key):
        b = self.snapshot(path)
        self.inputs[key] = {'name': Path(path).name, 'bytes': len(b), 'sha256': digest(b)}
        return decode(b)

    def keys(self, obj, allowed, required, where):
        if not isinstance(obj, dict):
            raise ValueError(where + ': expected object')
        for k in sorted(set(obj) - set(allowed)):
            self.unknown('UNKNOWN_FIELD', where + '/' + k, 'Unsupported field must not be silently omitted.')
        for k in sorted(set(required) - set(obj)):
            self.fail('MISSING_FIELD', where + '/' + k, 'Required field is absent.')

    def index(self, rows, where):
        if not isinstance(rows, list):
            raise ValueError(where + ': expected list')
        result = {}
        for i, row in enumerate(rows):
            if not isinstance(row, dict) or not isinstance(row.get('id'), str) or not row['id']:
                self.fail('INVALID_ID', where + '/' + str(i), 'Expected nonempty string ID.')
                continue
            identity = row['id']
            if identity in result:
                self.fail('DUPLICATE_ID', where, identity)
            result[identity] = row
        return result


class HTMLData(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.active = False
        self.blocks = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'script' and a.get('id') == 'architecture-data':
            if a.get('type') != 'application/json':
                raise ValueError('architecture-data has unexpected type')
            self.active = True
            self.blocks.append('')

    def handle_data(self, data):
        if self.active:
            self.blocks[-1] += data

    def handle_endtag(self, tag):
        if tag == 'script':
            self.active = False


def inventory(c, data):
    c.keys(data, TOP, {'title', 'nodes', 'flows', 'sources'}, '/')
    units = []
    source_map = c.index(data.get('sources', []), '/sources')
    nodes = c.index(data.get('nodes', []), '/nodes')
    flows = c.index(data.get('flows', []), '/flows')
    if set(nodes) & set(flows):
        c.fail('DUPLICATE_GLOBAL_ID', '/', sorted(set(nodes) & set(flows)))
    if len(nodes) > 60 or len(flows) > 100:
        c.unknown('LIMIT', '/', 'Supported schema bounds: 60 nodes, 100 flows.')

    def add(owner, path, value, key=False):
        text = value if isinstance(value, str) else canonical(value)
        if not text.strip():
            return
        units.append({'id': owner + ':' + path + ('#key' if key else ''), 'owner': owner,
                      'pointer': path, 'kind': 'key' if key else 'text', 'text': text,
                      'text_sha256': digest(text.encode('utf-8'))})

    def walk(owner, path, value, free=False):
        if isinstance(value, dict):
            for k, v in value.items():
                p = path + '/' + pointer(k)
                if free:
                    add(owner, p, k, True)
                walk(owner, p, v, free)
        elif isinstance(value, list):
            for i, v in enumerate(value):
                walk(owner, path + '/' + str(i), v, free)
        else:
            add(owner, path, value)

    for kind, allowed, required in [('nodes', NODE, {'id', 'label', 'source_ids', 'evidence'}),
                                    ('flows', FLOW, {'id', 'source', 'target', 'label', 'protocol_state', 'source_ids', 'evidence'}),
                                    ('sources', SOURCE, {'id', 'title'})]:
        for i, row in enumerate(data.get(kind, [])):
            if not isinstance(row, dict) or 'id' not in row:
                continue
            owner = kind[:-1] + ':' + row['id']
            base = '/' + kind + '/' + str(i)
            c.keys(row, allowed, required, base)
            if kind != 'sources':
                refs = row.get('source_ids', [])
                if not isinstance(refs, list) or any(not isinstance(s, str) for s in refs):
                    c.fail('SOURCE_REFS', base, 'Expected explicit source-ID list.')
                else:
                    if len(refs) != len(set(refs)) or set(refs) - set(source_map):
                        c.fail('SOURCE_REFS', base, 'Duplicate or unresolved source IDs.')
                ev = row.get('evidence')
                if isinstance(ev, dict):
                    c.keys(ev, EVIDENCE, {'state'}, base + '/evidence')
                elif not isinstance(ev, str) or not ev:
                    c.fail('EVIDENCE_STATE', base, 'Expected evidence string or state object.')
            for k, v in row.items():
                if k not in {'id', 'source_ids', 'source', 'target'}:
                    walk(owner, base + '/' + pointer(k), v, k == 'details')
            if kind == 'flows':
                if row.get('source') not in nodes or row.get('target') not in nodes:
                    c.fail('ENDPOINT', base, 'Unresolved node ID.')
                relation = {k: row.get(k) for k in ['id', 'source', 'target', 'flow_type', 'protocol',
                                                    'protocol_state', 'transport', 'evidence']}
                add(owner, base + '/@relationship', canonical(relation))
                units[-1]['kind'] = 'relationship'
    for k, v in data.items():
        if k not in {'nodes', 'flows', 'sources'}:
            walk('context', '/' + pointer(k), v, k in {'facts', 'actions', 'notes'})
    if len(units) > 50000:
        raise ValueError('Material unit limit exceeded')
    return {'schema': 'architecture-final-inventory/1', 'units': units,
            'node_ids': sorted(nodes), 'flow_ids': sorted(flows), 'source_ids': sorted(source_map)}


def eligible_https(url):
    if not isinstance(url, str) or any(ord(x) <= 32 or ord(x) == 127 for x in url) or '\\' in url:
        return False
    try:
        p = urlsplit(url)
        return p.scheme == 'https' and bool(p.hostname) and '@' not in p.netloc and (p.port is None or 0 < p.port < 65536)
    except ValueError:
        return False


def artifacts(c, paths, data, overview=None):
    results = []
    seen = set()
    for path in paths:
        p = Path(path)
        if p.name in seen:
            raise ValueError('Artifact basenames must be unique')
        seen.add(p.name)
        b = c.snapshot(p)
        row = {'name': p.name, 'bytes': len(b), 'sha256': digest(b)}
        results.append(row)
        if p.suffix.lower() in {'.html', '.htm'}:
            h = HTMLData()
            h.feed(b.decode('utf-8'))
            if len(h.blocks) != 1:
                c.unknown('HTML_EXTRACTION', p.name, 'Expected exactly one architecture-data JSON block.')
                continue
            extracted = decode(h.blocks[0])
            row['format'] = 'html'
        elif p.suffix.lower() in {'.drawio', '.xml'}:
            if b'<!DOCTYPE' in b.upper() or b'<!ENTITY' in b.upper():
                raise ValueError('DTD/entities unsupported')
            root = ET.fromstring(b)
            if root.tag != 'mxfile' or 'supplied_input_json' not in root.attrib:
                c.unknown('XML_EXTRACTION', p.name, 'Expected native builder mxfile with supplied_input_json.')
                continue
            extracted = decode(root.attrib['supplied_input_json'])
            if digest(canonical(extracted).encode()) != root.get('supplied_input_sha256'):
                c.fail('XML_INPUT_HASH', p.name, 'Embedded canonical source hash mismatch.')
            flowmap = {x['id']: x for x in data['flows']}
            nodemap = {x['id']: x for x in data['nodes']}
            found = set()
            citations = set()
            pages = root.findall('diagram')
            if not pages:
                c.unknown('XML_PAGES', p.name, 'No pages extracted.')
            for i, page in enumerate(pages):
                r = page.find('mxGraphModel/root')
                loc = p.name + '/page/' + str(i + 1)
                if r is None:
                    c.unknown('XML_COMPRESSED_OR_UNSUPPORTED', loc, 'Expected uncompressed native page.')
                    continue
                ids = {}
                cells = []
                for obj in r:
                    cell = obj if obj.tag == 'mxCell' else obj.find('mxCell')
                    identity = obj.get('id')
                    if cell is None or identity is None:
                        c.unknown('XML_OBJECT', loc, 'Unrecognized native object shape.')
                        continue
                    if identity in ids:
                        c.fail('XML_DUPLICATE_ID', loc, identity)
                    ids[identity] = obj
                    cells.append((identity, cell))
                    expected_record = nodemap.get(identity, flowmap.get(identity))
                    if expected_record is not None and not obj.get('supplied_json'):
                        c.unknown('XML_RECORD_METADATA_MISSING', loc + '/' + identity,
                                  'Recognized final node/flow lacks supported supplied_json metadata.')
                    if obj.get('supplied_json'):
                        metadata = decode(obj.get('supplied_json'))
                        if not isinstance(metadata, dict):
                            c.unknown('XML_RECORD_METADATA_SHAPE', loc + '/' + identity,
                                      'Expected an object for native supplied_json metadata.')
                            continue
                        if expected_record is not None and canonical(metadata) != canonical(expected_record):
                            c.fail('XML_RECORD_METADATA_MISMATCH', loc + '/' + identity,
                                   'Native node/flow record differs from the exact final input record.')
                        if 'citation_source_id' in metadata:
                            sid, owner, url = (metadata.get(k) for k in ['citation_source_id', 'citation_record_id', 'citation_url'])
                            sources = {s['id']: s for s in data['sources']}
                            if sid not in sources or sources[sid].get('url') != url or obj.get('link') != url:
                                c.fail('XML_CITATION_TARGET', loc + '/' + identity, metadata)
                            citations.add((owner, sid))
                for identity, cell in cells:
                    for attr in ['parent', 'source', 'target']:
                        if cell.get(attr) is not None and cell.get(attr) not in ids:
                            c.fail('XML_REFERENCE', loc + '/' + identity, attr + '=' + cell.get(attr))
                    if identity in flowmap:
                        f = flowmap[identity]
                        if cell.get('edge') != '1' or (cell.get('source'), cell.get('target')) != (f['source'], f['target']):
                            c.fail('XML_NATIVE_ENDPOINT', loc + '/' + identity, 'Native edge differs from final source endpoint IDs.')
                        found.add(identity)
                    elif cell.get('edge') == '1':
                        obj = ids[identity]
                        if obj.get('aggregate_json') is None or not isinstance(overview, dict):
                            c.unknown('UNREVIEWED_NATIVE_EDGE', loc + '/' + identity, 'Extra edge outside final flow inventory; no recognized supplied overview aggregate.')
                            continue
                        aggregate = decode(obj.get('aggregate_json'))
                        mapping = {n: g['id'] for g in overview.get('presentation_groups', []) for n in g['node_ids']}
                        a, b = cell.get('source'), cell.get('target')
                        expected = [f for f in data['flows'] if mapping.get(f['source']) == a and mapping.get(f['target']) == b and a != b]
                        if not expected or aggregate.get('id') != identity or aggregate.get('source_group') != a or aggregate.get('target_group') != b or aggregate.get('flow_ids') != [f['id'] for f in expected] or aggregate.get('members') != expected:
                            c.fail('OVERVIEW_AGGREGATE_BINDING', loc + '/' + identity, 'Aggregate must preserve the exact supplied ordered group pair and all member flows.')
            if found != set(flowmap):
                c.fail('XML_MISSING_FLOWS', p.name, sorted(set(flowmap) - found))
            for owner in list(nodemap.values()) + list(flowmap.values()):
                for sid in owner['source_ids']:
                    source = next((s for s in data['sources'] if s['id'] == sid), {})
                    if eligible_https(source.get('url')) and (owner['id'], sid) not in citations:
                        c.fail('XML_MISSING_CITATION', p.name + '/' + owner['id'], sid)
            row.update(format='drawio', pages=len(pages), native_flows=len(found), citation_bindings=len(citations))
        else:
            c.unknown('ARTIFACT_FORMAT', p.name, 'Unsupported artifact format.')
            continue
        if canonical(extracted) != canonical(data):
            c.fail('ARTIFACT_INPUT_MISMATCH', p.name, 'Embedded source differs from exact input JSON.')
    return results


def bank_check(c, path, data):
    bank = c.load(path, 'bank')
    c.keys(bank, {'schema', 'sources', 'passages'}, {'schema', 'sources', 'passages'}, 'bank')
    if bank.get('schema') != 'architecture-evidence-bank/1':
        c.unknown('BANK_SCHEMA', 'bank', bank.get('schema'))
    sources = c.index(bank.get('sources', []), 'bank/sources')
    primary = {s['id']: s for s in data['sources']}
    if set(sources) != set(primary):
        c.fail('BANK_SOURCE_IDS', 'bank', {'missing': sorted(set(primary) - set(sources)), 'extra': sorted(set(sources) - set(primary))})
    captures = {}
    root = Path(path).resolve().parent
    for sid, s in sources.items():
        c.keys(s, {'id', 'title', 'url', 'retrieved_at', 'access_scope', 'omissions', 'capture', 'metadata'},
               {'id', 'title', 'url', 'retrieved_at', 'access_scope', 'omissions', 'capture', 'metadata'}, 'bank/source/' + sid)
        for k in ['title', 'url']:
            if sid in primary and s.get(k) != primary[sid].get(k):
                c.fail('SOURCE_IDENTITY', 'bank/source/' + sid, k + ' differs from final source record.')
        expected_metadata = {k: primary.get(sid, {}).get(k) for k in ['version', 'date', 'status']}
        if s.get('metadata') != expected_metadata:
            c.fail('SOURCE_METADATA', 'bank/source/' + sid, 'Final version/date/status must match retained source metadata exactly; no deployment inference.')
        if not isinstance(s.get('retrieved_at'), str) or not s.get('retrieved_at'):
            c.fail('RETRIEVAL_TIME', sid, 'Actual retrieval time required.')
        if s.get('access_scope') not in {'full_returned_text', 'excerpt', 'title_only', 'unavailable', 'user_supplied'}:
            c.fail('ACCESS_SCOPE', sid, 'Unsupported access scope.')
        cap = s.get('capture')
        if not isinstance(cap, dict):
            c.unknown('CAPTURE_UNAVAILABLE', sid, 'No retained capture.')
            continue
        c.keys(cap, {'file', 'bytes', 'sha256'}, {'file', 'bytes', 'sha256'}, sid + '/capture')
        rel = cap.get('file')
        if not isinstance(rel, str) or not rel or Path(rel).is_absolute() or '..' in Path(rel).parts or '\\' in rel:
            c.fail('CAPTURE_PATH', sid, 'Capture must use safe relative path.')
            continue
        p = root / rel
        if any(x.is_symlink() for x in [p] + list(p.parents) if x != root and root in [x] + list(x.parents)) or not p.resolve().is_relative_to(root):
            c.fail('CAPTURE_PATH', sid, 'Symlink/outside-bank capture rejected.')
            continue
        try:
            b = c.snapshot(p)
            if digest(b) != cap.get('sha256') or len(b) != cap.get('bytes'):
                c.fail('CAPTURE_HASH', sid, 'Retained bytes/hash mismatch.')
            captures[sid] = b.decode('utf-8')
        except (OSError, ValueError, UnicodeError) as exc:
            c.unknown('CAPTURE_UNAVAILABLE', sid, str(exc))
    passages = c.index(bank.get('passages', []), 'bank/passages')
    for pid, p in passages.items():
        c.keys(p, {'id', 'source_id', 'capture_sha256', 'start', 'end', 'quote', 'locator'},
               {'id', 'source_id', 'capture_sha256', 'start', 'end', 'quote', 'locator'}, 'passage/' + pid)
        sid = p.get('source_id')
        if sid not in sources:
            c.fail('PASSAGE_SOURCE', pid, sid)
            continue
        cap = sources[sid].get('capture') or {}
        if p.get('capture_sha256') != cap.get('sha256'):
            c.fail('PASSAGE_CAPTURE_HASH', pid, 'Passage references a different capture.')
        a, b = p.get('start'), p.get('end')
        if not isinstance(a, int) or isinstance(a, bool) or not isinstance(b, int) or isinstance(b, bool) or a < 0 or b <= a:
            c.fail('PASSAGE_SPAN', pid, 'Invalid Unicode character offsets.')
        elif sid in captures and (b > len(captures[sid]) or captures[sid][a:b] != p.get('quote')):
            c.fail('PASSAGE_SLICE', pid, 'Quote is not the exact retained Unicode slice.')
        if not isinstance(p.get('locator'), str) or not p['locator'].strip():
            c.fail('PASSAGE_LOCATOR', pid, 'Section/table/row/field locator required.')
    return bank, sources, passages


def review_check(c, review_path, inv, data, files, bank_sources, passages):
    review = c.load(review_path, 'review')
    c.keys(review, {'schema', 'binding', 'reviewer', 'claims', 'nonfactual_spans', 'nodes', 'relationships', 'context_citations'},
           {'schema', 'binding', 'reviewer', 'claims', 'nonfactual_spans', 'nodes', 'relationships', 'context_citations'}, 'review')
    if review.get('schema') != 'architecture-final-review/1':
        c.unknown('REVIEW_SCHEMA', 'review', review.get('schema'))
    expected = {'artifacts': [{k: f[k] for k in ['name', 'bytes', 'sha256']} for f in files],
                'input': c.inputs['input'], 'overview': c.inputs.get('overview'),
                'inventory_sha256': digest(canonical(inv).encode()), 'bank_sha256': c.inputs['bank']['sha256']}
    if review.get('binding') != expected:
        c.fail('STALE_REVIEW_BINDING', 'review/binding', {'expected': expected, 'actual': review.get('binding')})
    rev = review.get('reviewer', {})
    c.keys(rev, {'name', 'kind', 'reviewed_at', 'retrospective'}, {'name', 'kind', 'reviewed_at', 'retrospective'}, 'reviewer')
    if not all(isinstance(rev.get(k), str) and rev[k].strip() for k in ['name', 'kind', 'reviewed_at']) or not isinstance(rev.get('retrospective'), bool):
        c.fail('REVIEWER', 'reviewer', 'Actual named reviewer kind/time and retrospective boolean required.')
    units = {u['id']: u for u in inv['units']}
    claims = c.index(review.get('claims', []), 'review/claims')
    covered = {uid: set() for uid in units}
    required = {}
    unit_sources = {uid: set() for uid in units}

    def span(row, where):
        uid = row.get('unit_id')
        if uid not in units:
            c.fail('FINAL_UNIT_ID', where, uid)
            return None
        a, b, text = row.get('start'), row.get('end'), units[uid]['text']
        if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(text) or text[a:b] != row.get('quote'):
            c.fail('CLAIM_SLICE', where, 'Exact final unit slice mismatch.')
            return None
        covered[uid].update(range(a, b))
        return uid

    for cid, claim in claims.items():
        c.keys(claim, {'id', 'unit_id', 'start', 'end', 'quote', 'assertion', 'kind', 'passage_ids', 'verdict', 'scope', 'reason'},
               {'id', 'unit_id', 'start', 'end', 'quote', 'assertion', 'kind', 'passage_ids', 'verdict', 'scope', 'reason'}, 'claim/' + cid)
        uid = span(claim, cid)
        if not all(isinstance(claim.get(k), str) and claim[k].strip() for k in ['assertion', 'scope', 'reason']):
            c.fail('CLAIM_EXPLANATION', cid, 'Explicit assertion, scope and reason required.')
        verdict = claim.get('verdict')
        if verdict not in VERDICTS:
            c.fail('CLAIM_VERDICT', cid, verdict)
        elif verdict in {'UNSUPPORTED', 'CONTRADICTED'}:
            c.fail('DECLARED_SOURCE_FAILURE', cid, verdict)
        elif verdict == 'UNVERIFIED':
            c.unknown('DECLARED_UNVERIFIED', cid, claim.get('reason'))
        if claim.get('kind') not in {'technical', 'metadata', 'unknown', 'proposal'}:
            c.fail('CLAIM_KIND', cid, claim.get('kind'))
        refs = claim.get('passage_ids')
        if not isinstance(refs, list) or any(not isinstance(x, str) for x in refs):
            c.fail('CLAIM_PASSAGES', cid, 'Expected passage-ID list.')
            continue
        if len(set(refs)) != len(refs) or set(refs) - set(passages):
            c.fail('CLAIM_PASSAGES', cid, 'Duplicate/dangling passage IDs.')
        if not refs and claim.get('kind') in {'technical', 'metadata'}:
            c.fail('EMPTY_FACT_JOIN', cid, 'Factual assertion needs retained passage binding.')
        if not refs and claim.get('kind') == 'proposal' and verdict != 'PROPOSED':
            c.fail('PROPOSAL_VERDICT', cid, 'Unbound proposal cannot be presented as supported fact.')
        for pid in refs:
            if pid not in passages:
                continue
            sid = passages[pid]['source_id']
            s = bank_sources.get(sid, {})
            if claim.get('kind') == 'technical' and s.get('access_scope') in {'title_only', 'unavailable'}:
                c.unknown('INSUFFICIENT_CAPTURE_SCOPE', cid, sid + ': technical claim lacks body context.')
            if uid:
                unit_sources[uid].add(sid)
                required.setdefault(units[uid]['owner'], set()).add(sid)
    nonfactual = c.index(review.get('nonfactual_spans', []), 'review/nonfactual_spans')
    for nid, row in nonfactual.items():
        c.keys(row, {'id', 'unit_id', 'start', 'end', 'quote', 'reason'}, {'id', 'unit_id', 'start', 'end', 'quote', 'reason'}, 'nonfactual/' + nid)
        uid = span(row, nid)
        if uid and units[uid]['kind'] == 'relationship':
            c.fail('RELATIONSHIP_EXEMPTION', nid, 'Relationship unit cannot be nonfactual.')
        if not isinstance(row.get('reason'), str) or not row['reason'].strip():
            c.fail('NONFACTUAL_REASON', nid, 'Specific nonfactual reason required.')
    uncovered = []
    for uid, unit in units.items():
        missing = [i for i, ch in enumerate(unit['text']) if not ch.isspace() and i not in covered[uid]]
        if missing:
            ranges = []
            a = last = missing[0]
            for i in missing[1:]:
                if i != last + 1:
                    ranges.append([a, last + 1])
                    a = i
                last = i
            ranges.append([a, last + 1])
            detail = [{'start': a, 'end': b, 'quote': unit['text'][a:b]} for a, b in ranges]
            uncovered.append({'unit_id': uid, 'spans': detail})
            c.fail('UNCOVERED_FINAL_TEXT', uid, detail)
    union_rows = []
    for kind in ['nodes', 'flows']:
        for obj in data[kind]:
            owner = kind[:-1] + ':' + obj['id']
            actual, need = set(obj['source_ids']), required.get(owner, set())
            missing = need - actual
            if missing:
                c.fail('MISSING_REQUIRED_SOURCE', owner, sorted(missing))
            if actual - need:
                c.fail('UNBOUND_DECLARED_SOURCE', owner, sorted(actual - need))
            union_rows.append({'owner': owner, 'derived_required': sorted(need), 'actual': sorted(actual),
                               'missing': sorted(missing), 'additional_declared': sorted(actual - need)})

    # Explicit exact tokens with offsets, never substring/token-overlap semantic proof.
    context = c.index(review.get('context_citations', []), 'review/context_citations')
    mapped = {}
    for identity, row in context.items():
        c.keys(row, {'id', 'unit_id', 'source_id', 'start', 'end', 'quote'}, {'id', 'unit_id', 'source_id', 'start', 'end', 'quote'}, identity)
        uid, sid = row.get('unit_id'), row.get('source_id')
        if uid not in units or units[uid]['owner'] != 'context':
            c.fail('CONTEXT_BINDING', identity, 'Expected exact context unit.')
            continue
        sources = {s['id']: s for s in data['sources']}
        tokens = ['[' + sid + ']'] if isinstance(sid, str) else []
        if sid in sources and sources[sid].get('url'):
            tokens.append(sources[sid]['url'])
        a, b = row.get('start'), row.get('end')
        if type(a) is not int or type(b) is not int or not 0 <= a < b <= len(units[uid]['text']) or units[uid]['text'][a:b] != row.get('quote') or row.get('quote') not in tokens:
            c.fail('CONTEXT_CITATION_TOKEN', identity, 'Requires exact [source-ID] or supplied URL slice in the same unit.')
        else:
            mapped.setdefault(uid, set()).add(sid)
    for uid, need in unit_sources.items():
        if units[uid]['owner'] == 'context' and need - mapped.get(uid, set()):
            c.unknown('FREE_TEXT_CITATION_MAPPING', uid, {'required': sorted(need), 'mapped': sorted(mapped.get(uid, set()))})

    node_review = c.index(review.get('nodes', []), 'review/nodes')
    node_map = {n['id']: n for n in data['nodes']}
    if set(node_review) != set(node_map):
        c.fail('NODE_REVIEW_IDS', 'review/nodes', 'Must match every final node ID exactly.')
    for nid, n in node_review.items():
        c.keys(n, {'id', 'identity_kind', 'claim_ids', 'reason'}, {'id', 'identity_kind', 'claim_ids', 'reason'}, 'node-review/' + nid)
        if n.get('identity_kind') not in KINDS or not n.get('reason'):
            c.fail('NODE_IDENTITY_REVIEW', nid, 'Explicit supported identity level/reason required.')
        refs = n.get('claim_ids', [])
        if not isinstance(refs, list) or not refs:
            c.fail('NODE_IDENTITY_REVIEW', nid, 'Identity claim IDs required.')
            continue
        for cid in refs:
            if cid not in claims or units.get(claims[cid].get('unit_id'), {}).get('owner') != 'node:' + nid:
                c.fail('NODE_IDENTITY_JOIN', nid, cid)
    relations = c.index(review.get('relationships', []), 'review/relationships')
    flow_map = {f['id']: f for f in data['flows']}
    if set(relations) != set(flow_map):
        c.fail('RELATIONSHIP_REVIEW_IDS', 'review/relationships', 'Must match every final flow ID exactly.')
    for fid, r in relations.items():
        c.keys(r, {'id', 'source', 'target', 'actual_flow_type', 'reviewed_relation', 'claim_ids', 'source_support', 'target_support', 'relation_support'},
               {'id', 'source', 'target', 'actual_flow_type', 'reviewed_relation', 'claim_ids', 'source_support', 'target_support', 'relation_support'}, 'relationship/' + fid)
        f = flow_map.get(fid)
        if not f:
            continue
        if [r.get(k) for k in ['source', 'target']] != [f.get(k) for k in ['source', 'target']] or r.get('actual_flow_type') != f.get('flow_type'):
            c.fail('RELATIONSHIP_FINAL_MISMATCH', fid, 'Reviewed endpoints/type differ from final flow.')
        if r.get('reviewed_relation') not in RELATIONS:
            c.fail('RELATIONSHIP_KIND', fid, r.get('reviewed_relation'))
        refs = r.get('claim_ids', [])
        if not isinstance(refs, list) or not refs:
            c.fail('RELATIONSHIP_JOIN', fid, 'Relation claim IDs required.')
            refs = []
        for cid in refs:
            unit = units.get(claims.get(cid, {}).get('unit_id'), {})
            if unit.get('owner') != 'flow:' + fid or unit.get('kind') != 'relationship':
                c.fail('RELATIONSHIP_JOIN', fid, 'Must bind actual relationship unit, not independent endpoint existence: ' + str(cid))
        for axis in ['source', 'target', 'relation']:
            key = axis + '_support'
            decision = r.get(key, {})
            c.keys(decision, {'verdict', 'claim_ids', 'reason'}, {'verdict', 'claim_ids', 'reason'}, fid + '/' + key)
            status = decision.get('verdict')
            if status not in VERDICTS or not decision.get('reason'):
                c.fail('PARTICIPATION_DECISION', fid + '/' + key, 'Explicit verdict/reason required.')
            drefs = decision.get('claim_ids', [])
            if not isinstance(drefs, list) or not drefs or set(drefs) - set(refs):
                c.fail('PARTICIPATION_JOIN', fid + '/' + key, 'Participation must bind this actual relation claim.')
            if status in {'UNSUPPORTED', 'CONTRADICTED'}:
                c.fail('DECLARED_RELATIONSHIP_FAILURE', fid + '/' + key, status)
            elif status == 'UNVERIFIED':
                named = axis != 'relation' and node_review.get(f.get(axis), {}).get('identity_kind', '').startswith('named_')
                if named or r.get('reviewed_relation') in {'direct_interface', 'data_read', 'data_write', 'user_access'}:
                    c.fail('UNSUPPORTED_DRAWN_PARTICIPATION', fid + '/' + key, 'A logical/unknown label cannot establish this named endpoint or precise relationship.')
                else:
                    c.unknown('UNVERIFIED_PARTICIPATION', fid + '/' + key, decision.get('reason'))
            if status in GOOD:
                for cid in drefs if isinstance(drefs, list) else []:
                    if claims.get(cid, {}).get('verdict') not in GOOD or not claims.get(cid, {}).get('passage_ids'):
                        c.fail('POSITIVE_PARTICIPATION_JOIN', fid + '/' + key, 'Positive decision requires supported relation claim with retained passages.')
            if status == 'PROPOSED':
                framed = any(units.get(cl.get('unit_id'), {}).get('owner') == 'flow:' + fid and
                             cl.get('kind') == 'proposal' and cl.get('verdict') == 'PROPOSED'
                             for cl in claims.values())
                if r.get('reviewed_relation') != 'proposed_alternative' or not framed:
                    c.fail('PROPOSAL_RELATION_SCOPE', fid + '/' + key, 'Proposed participation requires declared proposed relationship and explicit final proposal span.')
    return {'claim_count': len(claims), 'nonfactual_span_count': len(nonfactual), 'reviewer': rev,
            'uncovered_units': uncovered, 'source_unions': union_rows,
            'relationship_count': len(relations), 'node_identity_count': len(node_review)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=['inventory', 'check'])
    parser.add_argument('--artifact', action='append', required=True)
    parser.add_argument('--input', required=True)
    parser.add_argument('--overview')
    parser.add_argument('--bank')
    parser.add_argument('--review')
    parser.add_argument('--report', required=True)
    args = parser.parse_args()
    # The report is the sole write; never overwrite a supplied/read input or symlink.
    out = Path(args.report)
    protected = [Path(x).resolve() for x in args.artifact + [args.input] + [x for x in [args.overview, args.bank, args.review] if x]]
    if out.is_symlink() or out.resolve() in protected:
        parser.error('Report cannot overwrite or alias an input or symlink.')
    c = Check()
    report = {'schema': 'architecture-evidence-contract-report/1', 'checker_version': VERSION,
              'checker_sha256': digest(Path(__file__).read_bytes()), 'command': args.command,
              'limits': LIMITS.copy()}
    try:
        data = c.load(args.input, 'input')
        overview = c.load(args.overview, 'overview') if args.overview else None
        inv = inventory(c, data)
        files = artifacts(c, args.artifact, data, overview)
        report.update(inventory=inv, inventory_sha256=digest(canonical(inv).encode()), artifacts=files)
        if args.command == 'check':
            if not args.bank or not args.review or not Path(args.bank).is_file() or not Path(args.review).is_file():
                c.unknown('MISSING_RETAINED_REVIEW', '/', 'Original evidence bank and final review are required; do not reconstruct missing originals.')
            else:
                bank, bank_sources, passages = bank_check(c, args.bank, data)
                report['review_checks'] = review_check(c, args.review, inv, data, files, bank_sources, passages)
                report['bank_counts'] = {'sources': len(bank_sources), 'passages': len(passages)}
    except (OSError, ValueError, TypeError, KeyError, IndexError, UnicodeError, ET.ParseError) as exc:
        c.unknown('INCOMPLETE_EXECUTION', '/', type(exc).__name__ + ': ' + str(exc))
    result = 'FAIL' if c.failures else 'UNVERIFIED' if c.unverified else 'INVENTORY_ONLY' if args.command == 'inventory' else 'EVIDENCE_CONTRACT_COMPLETE'
    report.update(result=result, failures=c.failures, unverified=c.unverified, input_files=c.inputs,
                  byte_snapshots=[{'path': str(p), 'bytes': len(b), 'sha256': digest(b)} for p, b in c.snapshots.items()])
    c.read_paths.add(Path(__file__).resolve())
    if out.resolve() in c.read_paths or out.exists() and any(p.exists() and out.samefile(p) for p in c.read_paths):
        parser.error('Report cannot overwrite a retained capture or other read input.')
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'result': result, 'failures': len(c.failures), 'unverified': len(c.unverified), 'report': str(out)}))
    return 1 if c.failures else 2 if c.unverified else 0


if __name__ == '__main__':
    sys.exit(main())
