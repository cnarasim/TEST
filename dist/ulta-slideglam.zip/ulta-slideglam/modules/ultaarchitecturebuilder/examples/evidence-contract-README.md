# Fictional evidence-contract runtime examples

These are mechanical test declarations, not enterprise sources or model semantic reviews. All systems, identities and dates are fictional. `review.json` is explicitly attributed to an automated fixture author. Some claims deliberately cover a whole compound unit: the checker can confirm exact coverage but cannot prove atomicity or entailment. Real outputs require an independent clause-level source review, correctly split assertions and no copied fixture verdicts.

The supplied source captures/bank/review are exact frozen test bytes. Do not edit them to make a test pass. Generate the outputs in a fresh writable output directory, keeping the indicated output basenames. From the extracted skill root:

```sh
mkdir -p diagnostic/contract-named diagnostic/contract-unknown
python3 scripts/ulta_architecture_html.py examples/contract-named/input.json diagnostic/contract-named/final.html --overview examples/contract-named/overview.json --report diagnostic/contract-named/html-build.json
python3 scripts/ulta_architecture_xml.py examples/contract-named/input.json diagnostic/contract-named/final.drawio --overview examples/contract-named/overview.json --report diagnostic/contract-named/xml-build.json
python3 scripts/architecture_source_review_check.py check --artifact diagnostic/contract-named/final.html --artifact diagnostic/contract-named/final.drawio --input examples/contract-named/input.json --overview examples/contract-named/overview.json --bank examples/contract-named/bank.json --review examples/contract-named/review.json --report diagnostic/contract-named/evidence-contract.json
python3 scripts/ulta_architecture_html.py examples/contract-unknown/input.json diagnostic/contract-unknown/final.html --report diagnostic/contract-unknown/html-build.json
python3 scripts/ulta_architecture_xml.py examples/contract-unknown/input.json diagnostic/contract-unknown/final.drawio --report diagnostic/contract-unknown/xml-build.json
python3 scripts/architecture_source_review_check.py check --artifact diagnostic/contract-unknown/final.html --artifact diagnostic/contract-unknown/final.drawio --input examples/contract-unknown/input.json --bank examples/contract-unknown/bank.json --review examples/contract-unknown/review.json --report diagnostic/contract-unknown/evidence-contract.json
```

Both checks should return exit0 / `EVIDENCE_CONTRACT_COMPLETE`. Compare all four actual generated output hashes with `manifest.json/evidence_contract_examples`. Report the literal commands, exit statuses, raw reports and actual file hashes. A matching package/example result is not source acceptance, visual approval, current deployment evidence or a publication recommendation.

The named fixture demonstrates source-union reconciliation across two sources and exact direct/read-model endpoint binding. The second fixture preserves an unknown producer at a functional requirement level plus a separate historical statement/proposed action. These positive mechanical controls coexist with separate negative/semantic-limit tests; their reviews are not reusable proof templates.
