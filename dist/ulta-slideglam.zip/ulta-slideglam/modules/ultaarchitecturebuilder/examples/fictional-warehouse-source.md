# Warehouse Reservation Pilot — fictional source packet

This is a self-contained synthetic test. Every project, person, system and value below is fictional. Use only this packet; no enterprise or web lookup is needed. Cite `Source A §n` or `Source B §n` beside claims; Word may use internal bookmarks. These are user-supplied section references, not external URLs. Do not invent links, approvals, production status or facts. Diagram nodes and connectors must remain editable. Keep proposals and uncertain values explicit.

## Source A — Pilot design register

Version 2; recorded 29 August 2026; historical design and sandbox configuration, not a production release record.

### A1 Purpose and scope
The pilot aims to prevent the same warehouse stock being promised twice by recording temporary quantity reservations. Scope is one fictional site, `WH-P07`, and SKU class `STANDARD`. Chilled stock and transfers between sites are excluded. The documented target is reservation-create p95 latency ≤200 ms. No savings, service-level benefit or production rollout is approved or measured in this packet.

### A2 Component catalogue
| ID | Name | Exact technical identifier | Responsibility |
|---|---|---|---|
| C1 | Warehouse ERP | `WMS_PILOT_ERP` | Supplies order requests and receives the availability snapshot |
| C2 | Reservation API | `wh-reservation-api` | Validates creates, persists reservations, emits changes and audit records |
| C3 | Reservation Database | `wh_reservation.reservation_v2` | Stores reservation rows, status and expiry time |
| C4 | Expiry Worker | `wh-reservation-expiry` | Polls expiry candidates and requests expiry; not the database or a UI |
| C5 | Operator Console | `wh-reservation-console` | Manual hold entry and audit lookup |
| C6 | Event Broker | `warehouse-reservation-broker` | Carries reservation change events |
| C7 | Reporting Service | `wh-availability-report` | Produces the net-available snapshot sent to ERP |
| C8 | Audit Archive | `wh_reservation_audit_v1` | Append-only audit storage with authorized read access |

### A3 Directed flow register
All flows describe design relationships, not proof of current deployment. F1–F4 and F6–F10 were configured in the sandbox as of A's date. F5 was configured but disabled.

| ID | From → To | Operation and exact interface | Mode/status |
|---|---|---|---|
| F1 | C1 → C2 | Create order hold, HTTPS `POST /v1/reservations`, `origin=ORDER` | Automated order path |
| F2 | C5 → C2 | Create manual hold, HTTPS `POST /v1/reservations`, `origin=MANUAL` | Human-initiated path |
| F3 | C2 → C3 | Transactional insert/update of `reservation_v2`; SQL over TLS | Synchronous persistence |
| F4 | C3 → C4 | Candidate rows where `status=ACTIVE` and `expires_at <= now`; SQL query results | Worker polls every 60 s; arrow is returned data, not query initiation |
| F5 | C4 → C2 | Request expiry, HTTPS `POST /v1/reservations/{id}/expire` | Proposed enablement; disabled in sandbox |
| F6 | C2 → C6 | Publish `reservation.changed.v1` with `reservation_id`, `site_id`, `qty_each`, `status` | Kafka over TLS; asynchronous |
| F7 | C6 → C7 | Deliver `reservation.changed.v1` to consumer group `availability-report-v1` | Kafka subscription |
| F8 | C7 → C1 | Produce/send `net_available_WH-P07.csv` nightly at 02:00 UTC; SFTP | Automated batch; producer is C7, not C5/C8 |
| F9 | C2 → C8 | Append event, HTTPS `POST /audit/v1/events` | Synchronous audit write |
| F10 | C5 → C8 | Read audit history, HTTPS `GET /audit/v1/events?reservation_id={id}` | Human-initiated read |

F1 and F2 are distinct creation variants; not every hold originates in ERP. Quantities use **each**, never cases. The declared outbound formula is `max(0, on_hand_each - active_reserved_each)`. Net availability is a derived value, not the same as gross on-hand stock. The interface supplying on-hand input to C7 is **not provided**; do not invent an eleventh flow. No network/security-zone boundaries are supplied.

### A4 People and access
Jordan Vale is the pilot coordinator; Mira Chen recorded QA results. A system owner, business approver and release approver are **not provided**. Access roles are a separate list: `WH_RESERVATION_OPERATOR` can enter manual holds; `WH_AUDIT_REVIEWER` can read audit history. No person-to-role assignments are supplied.

## Source B — QA readout and open decisions

Version 1; recorded 9 September 2026; test observations and proposed actions, not release approval.

### B1 Measured test results
Sandbox at `WH-P07`, 9 September 2026, 14:00–14:20 UTC: **160 create attempts; 152 passed; 8 failed; p95 latency 240 ms**. Counts cover that test only, not a daily volume or a production incident backlog. Of the successful holds, **120 used F1 and 32 used F2**. A snapshot example has `on_hand_each=500`, `active_reserved_each=125`, `net_available_each=375`. No business-benefit measurement exists. Automatic expiry F5 was not exercised because it remained disabled; this is not evidence that expiry passed or failed.

### B2 Status and unresolved inputs
Issue `WRP-17` (duplicate create retry) is **QA COMPLETE**, resolution **Not provided**; production deployment is not established. Issue `WRP-22` (audit lookup timeout) is **CLOSED**, a historical test defect. Neither issue has an external URL in this packet.

The current draft checklist says audit retention **30 days**, while the current configuration sheet says **28 days**. Both are recorded on 9 September 2026; no precedence or approved value is provided. Preserve the unresolved conflict. A whiteboard says **“pilot go 10/11”** with no year, date locale, timezone or approval. Do not normalize it into a launch date. Proposed F5 enablement needs review; no approval, owner or date is recorded.

### B3 Action register
Actions are proposals unless stated otherwise. Assignee values concern these actions only, not system ownership, access roles or approval authority. Target dates below are proposed, not commitments.

| ID | Action | Assignee recorded | Proposed target |
|---|---|---|---|
| ACT-01 | Reconcile 28-day versus 30-day audit retention and record the chosen policy with approval evidence. | Jordan Vale | 2026-09-18 |
| ACT-02 | Retest duplicate-create retries for `WRP-17`, preserving the same `reservation_id`; capture pass/fail evidence for both `origin=ORDER` and `origin=MANUAL` so the manual path is not lost behind aggregate results. | Mira Chen | 2026-09-19 |
| ACT-03 | Identify the release approver. | Not provided | Not provided |
| ACT-04 | Measure the p95 latency again under the same 160-attempt test conditions and compare against the ≤200 ms target; do not relabel the 240 ms observation as a production service level. | Mira Chen | 2026-09-20 |
| ACT-05 | Review F5 enablement and its failure handling; retain the disabled state until an authorized decision is recorded. | Not provided | Not provided |
| ACT-06 | Clarify “pilot go 10/11”. | Jordan Vale | Not provided |
