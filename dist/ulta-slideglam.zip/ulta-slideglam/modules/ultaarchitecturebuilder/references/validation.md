# Bounded validation for 0.3.0

The native connected HTML implementation passed 2,371 actual Chromium checks and 40 static checks on a small fictional fixture, a 40-node/40-flow fixture and unchanged R6 source records. Checks cover connected/focused views, real label bounds, exact directed endpoints, evidence rendering, keyboard/pointer interactions, focus selection/zoom and original source-data download. The R6 input remains an intentionally unfixed source-interpretation regression fixture; rendering success does not approve its claims.

The XML source-link change passed independent exact-output regeneration, six actual hyperlink clicks with fictional destinations intercepted locally, all six small-fixture pages checked for bounds, visual review of citation pages, and a 22-source/88-link pagination case. Link-free default fixture bytes remain unchanged. The shared overview module adds only the bounded optional max_badge_lines argument; its default of eight preserves existing XML behavior. All resource hashes are in the manifest.

These results establish the tested helper behaviors only. New artifact source truth, complete output review, native application parity, live platform resource execution, attachments and client retrieval require their own evidence. Missing URLs remain missing and semantic support is NOT_CHECKED by the serializers. The helper does not infer producers, protocols, status, deployment or approval.


## Evidence-contract gate 0.4.0

The added read-only checker passed45 expected local mutation/fixture outcomes and bounded independent peer review. Checks include complete non-whitespace text-span coverage, exact final byte/source/capture bindings, retained Unicode passage slices, exact source unions, explicit participation decisions, native object-record/endpoint consistency, protected report destinations and FAIL precedence. The original peer metadata-divergence counterexample is now rejected. Two fictional examples regenerate actual HTML/XML and reconcile their supplied mechanical fixture reviews. Original renderer/input-schema hashes and their five existing example output hashes remain unchanged.

The checker cannot authenticate captures, establish semantic entailment or prove atomicity; deliberately false positive-review and compound-claim cases still complete mechanically. Runtime HTML/visual serialization, source-access truth, real artifact semantic review and new agent delivery are separate. Unchanged R51 remains UNVERIFIED for missing original retained source-bank/final-review evidence; no enterprise regression was repaired by this package.
