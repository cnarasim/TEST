# Native XML source links

The serializer creates native editable UserObject cells with a link attribute and a labelled HTML anchor. Links appear beside the full component/flow record and each eligible source-register entry. Source IDs resolve only to the supplied source list. The original source JSON remains exact and no hostname or path is inferred.

Only supplied HTTPS URLs without whitespace/control characters, backslashes, credentials or malformed/out-of-range ports are eligible. A null or ineligible URL is retained in source data but not activated; the report names the reason. This is format validation, not validation of source access or claim support. Source metadata with a confirmed Confluence page ID must first be resolved under the agent's research rules before generation.

Citation labels retain source ID and a bounded title; the full title, URL and original record are preserved in the register/metadata. Added citation cells participate in pagination before all printed page references are built. Optional overview generation subsequently rebuilds references. Never hand-prepend pages.

Review every exported page and exercise actual link clicks in a compatible viewer. Links to fictional targets may be locally intercepted in a test; that proves activation only, not remote accessibility. Regenerate after structural edits. Core mxGraph checks do not establish desktop-specific extension behavior.

Supporting format documentation: [shape metadata](https://www.drawio.com/docs/manual/shapes/shape-data/), [text links](https://www.drawio.com/docs/manual/insert/insert-text-link/).
