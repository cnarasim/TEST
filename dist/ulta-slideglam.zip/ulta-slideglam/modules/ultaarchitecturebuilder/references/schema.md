# Architecture input schema 1.0

This schema preserves source assertions. Neither builder determines whether a supplied assertion is true.

| Key | Type and required meaning |
|---|---|
| `title` | Required nonempty string. |
| `scope` | Supplied scope string. |
| `nodes` | List of component objects. |
| `flows` | List of directed relationship objects. |
| `sources` | List of source objects. |
| `notes`, `facts`, `actions` | Optional supplied JSON; preserved in evidence sections/registers. |

Every node has unique nonempty `id`, `label`, `source_ids` (source-ID list) and `evidence`. Optional fields: `technical_id`, `role`, `details`, and source-supplied `zone`. Do not infer a zone. These bounded builders do not treat zone text as a validated security boundary.

Every flow has unique nonempty `id`, exact `source` and `target` node IDs, `label`, `source_ids` and `evidence`. The nullable `protocol` field holds the exact supplied interface/operation identifier; nullable `transport` independently holds the supplied transport text. `protocol_state` must be `provided`, `not_provided`, `unverified` or `not_applicable`. Provided requires a nonempty value; not-provided/inapplicable require null. For example, returned query data may have transport text supplied while the precise interface identifier remains null/not-provided.

Optional `flow_type` is an explicit source-supplied category. Do not derive it from the interface, endpoint name or transport. Optional `details` retains all exact fields, qualifiers, predicates, schedules, quantities, origin variants and scope caveats. No invented blank-filling edge is allowed. Self-loops are unsupported by the bounded focused HTML layout and are rejected.

`evidence` is either a nonempty string or an object with nonempty `state`, optional `as_of`, and optional `note`. These values must distinguish historical design, sandbox observation, proposal, unknown and current deployment evidence. Missing evidence is not a negative fact.

Every source has a unique `id`, `title`, optional HTTP(S) `url`, `version`, `date` and `status`. Source references must resolve to an actual source object. Null URL is valid for user-supplied evidence. Never invent a URL from a title.

Use the provided fictional JSON only as a syntax/example fixture. Replace it with the user's real source-grounded project data for ordinary requests. It includes eight components and ten flows; all dates, systems and people in that example are fictional. `fixture_source` records the fuller original packet and is provenance metadata, not a runtime file dependency.

## Shared bounded limits

At most 60 nodes and 100 flows. Node and flow IDs are globally unique, at most 80 characters and contain no control characters. These are input limits, not a promise that arbitrary long labels/IDs pass browser fit; inspect actual output. The helpers preserve exact values in registers. Split larger source sets explicitly without losing IDs or relationships.

## Separate presentation configuration

Source schema remains1.0. HTML `--presentation` takes exact-match evidence/status rules only. Both HTML and XML `--overview` take the same rule lists plus explicit functional groups. Both preserve source JSON independently of presentation config. See `presentation-rules.md` for the shared contract and the format-specific `optional-html-overview.md` / `optional-xml-overview.md` for bounds, mixed-state rules and navigation. Presentation classification is not evidence of approval or deployment.

## XML hyperlink projection
Eligible supplied HTTPS URLs become native editable source links beside records and in the source register. Missing or ineligible URLs stay in the embedded input and are listed as unlinked in the build report. See `xml-source-links.md`; do not synthesize URLs in the renderer.
