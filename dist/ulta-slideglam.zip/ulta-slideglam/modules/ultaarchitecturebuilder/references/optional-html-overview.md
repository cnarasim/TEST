# Connected HTML overview

Use the native `--overview` mode for a requested connected architecture. Supply explicit functional presentation groups in a separate JSON configuration; do not handwrite or append a new SVG router.

```sh
python3 scripts/ulta_architecture_html.py input.json output.html --overview overview.json --report html-build.json
```

The existing `examples/fictional-warehouse.json` and `examples/fictional-warehouse-overview.json` are a complete fictional example. Use `--presentation` alone for an index/focused-only file. `--presentation` and `--overview` are mutually exclusive: the overview configuration contains the single exact evidence/status rule set used by every HTML view.

## Input and scope

The overview configuration has only `presentation_groups`, `evidence_rules` and `status_rules`. Each group has exactly `id`, `label`, and `node_ids`; every original component belongs to exactly one nonempty group. Supply 2–8 groups. Group IDs are ASCII letter-start, at most 20 characters; labels are at most 65 characters. There may be at most 20 ordered-pair aggregate arrows. The source JSON contract is unchanged, with at most 60 components and 100 directed flows. Self-loops, missing endpoints and an empty connected flow set are rejected.

Group membership is a presentation choice, not evidence of ownership, security or deployment boundaries. An aggregate represents only supplied flows in the same ordered source-group/target-group pair. Reverse directions remain separate. Internal flows are named in the group. Every exact flow is still available through its focused view, with its original source and destination IDs and full record.

The helper imports `ulta_architecture_overview.layout` for aggregation, ports, polylines, crossing gaps and attached badges. There is no separate HTML router. HTML permits up to 16 wrapped badge lines through a bounded keyword argument; the shared module's default remains eight for existing XML calls. Evidence-heavy groups expand the canvas rather than omit source fields or shrink fonts. Inputs beyond these limits must be split into explicit scopes; do not silently remove flows or shorten source records.

## Readable navigation

The whole-map fit is an orientation view. For detailed reading, use the normal-size **Overview focus** dropdown to select any group or aggregate, or select it in the SVG and press **Zoom to overview selection**. The inspector names every original member. **Open focused flow** shows the exact atomic endpoints. The source and flow registers retain complete original text.

Changing **View** clears an inspector selection absent from the new diagram and preserves a selected node that remains visible. Selecting a flow in the View list does not silently assert that it is the inspected record; activate its badge or use **Open focused flow** to inspect it.

Selection zoom measures label scale in screen pixels. It retains the usual fit margin when readable and can use up to 98% of the view to meet a 13 px floor (13.1 px target for numerical margin). The complete selected box remains bounded. If the available view or zoom cap cannot meet the floor, the live status reports the limitation; browser zoom and the inspector remain available. This is not a guarantee for arbitrary viewport/input combinations.

SVG labels are fitted using the browser's actual text metrics. Text may visibly wrap or end in an ellipsis inside a bounded card; full exact text stays in accessible names and the inspector/register. This changes presentation only. A large full map is not a one-screen executive diagram, and the helper does not promise readable fit at every viewport or arbitrary maximum-density input. Actual browser review is still required.

## Evidence and interaction contract

- Focused routes, badges and legend use the same exact supplied evidence/status rules. Unmatched custom or negated values remain neutral; explicitly unknown/unverified values are dashed. Disabled status is an explicit rule, not keyword inference.
- Aggregates with mixed original fields or differing member classifications/status flags are neutral. Every member's original evidence, dates and status remains available. All-disabled homogeneous aggregates retain the disabled style. Filters change visibility, not the underlying evidence classification.
- Route badges derive their anchors from their own source segment. Shared geometry places the final arrow at the approached target perimeter; arrows do not traverse a target group to reach its far side. White crossing gaps mean no junction.
- Shared pointer/keyboard selection never reparents focusable SVG controls. Enter/Space, sequential Tab, search/filter visibility, wheel cursor anchoring, screen-CTM panning, centered zoom and reset remain supported.
- The source JSON download preserves original record semantics. No network runtime dependencies are introduced. External source hyperlinks activate only on request.

## Validation and remaining responsibility

Generate the file, then use an actual browser to test every group/aggregate, every focused flow, registers, keyboard order, filters, selection zoom and source-data download. Inspect representative fit/zoom screenshots, all technical-label bounds, arrow direction and legend correspondence. A build report alone cannot establish readable output or actual client delivery.

This helper does not verify the truth, completeness or currency of the supplied research. For example, unchanged R6 input still has draft/current qualification and collapsed source-sequence issues identified in its independent audit. They must be corrected through source review before producing a final enterprise artifact; the renderer must not invent corrections.
