# Optional XML functional overview (0.3.0)

This format-specific mode adds a connected presentation page before the component index, focused flow pages and complete registers. It preserves the source JSON and does not verify enterprise facts. The HTML counterpart is described in `optional-html-overview.md`.

```sh
python3 scripts/ulta_architecture_xml.py input.json output.drawio --overview overview.json --report xml-build.json
```

Run the complete bundled author and overview scripts together. Save original input and separate presentation config; both are embedded independently. Both formats share grouped overview geometry and exact-match rules. XML focused pages retain neutral direction-only lines; HTML focused flows also use the supplied classification rules. Default XML bytes for link-free tested inputs remain unchanged; eligible supplied URLs now add native source links. Never modify identities, directions, protocols, approval or deployment claims to make a diagram fit.

## Explicit presentation config

Only these top-level fields are accepted:

```json
{
  "presentation_groups": [
    {"id":"PG1","label":"Client interaction","node_ids":["C1","C5"]},
    {"id":"PG2","label":"Reservation core","node_ids":["C2","C3","C4"]},
    {"id":"PG3","label":"Events and reports","node_ids":["C6","C7"]},
    {"id":"PG4","label":"Audit","node_ids":["C8"]}
  ],
  "evidence_rules": [
    {"field":"evidence.state","equals":"sandbox configured","class":"historical"},
    {"field":"evidence.state","equals":"disabled/proposed","class":"proposed"}
  ],
  "status_rules": [
    {"field":"details.status","equals":"disabled; proposed enablement; not exercised","flags":["disabled","proposed"]}
  ]
}
```

This example is fictional, taken from the bundled original warehouse packet. It establishes no facts about real Ulta systems. Grouping means functional presentation only; never infer ownership, trust, security or deployment boundaries. Every source node must occur in exactly one nonempty group. Group IDs must be1–20 ASCII letters/digits/underscore/hyphen beginning with a letter. Labels are limited to65 characters. Use2–8 groups; generated AGG identifiers may not collide with group IDs.

Evidence rules match exactly either `evidence` (string form) or `evidence.state`. Classes: `documented`, `observed`, `draft`, `historical`, `proposed`, `unknown`, `unverified`. Status rules match exactly `status`, `details.status` or `flow_type`. Flags: `disabled`, `proposed`, `historical`, `unknown`, `unverified`. A status can carry both disabled and proposed enablement without implying approval. Classification rules require source review: matching proves only that supplied text was found, not that the chosen class is correct. Unknown/custom text is visibly unclassified and styled neutral; there is no substring matching, case-folding, trimming or negation inference. The helper rejects unsupported classes such as production or approved.

## Aggregation and native editability

Each ordered pair of distinct groups receives one directed aggregate containing every exact member flow ID and full original member record. Reverse directions are separate edges/ports. Internal flows remain explicitly listed in their group and retain original focused pages. All supplied facts, actions, sources and details are preserved.

Every route is orthogonal and uses its own vertical rail and source/target port lanes outside unrelated boxes. Source badges are **native relative edge-child vertices**, with their anchor calculated from the actual source segment's distance along the route and a centered offset. They are not free-floating rectangles. Badge borders and routes share one style mapping. Native edit tests verify badge centers remain on their own connector after an in-memory group move. Crossing-gap decorations are static: regenerate and render after manual node/route changes; attachment does not guarantee a manually edited diagram remains orthogonal or collision-free.

Mixed original evidence, protocol, transport, flow-type or status fields receive neutral mixed styling. Full raw fields stay in registers/metadata, dates supplied by members are listed, and per-member disabled/proposed/historical/unknown exceptions stay visible. All-disabled homogeneous aggregates are red/dashed. The overview legend describes documented design and observation as such; neither means deployed. Focused pages retain the existing neutral direction-only route style, so the overview legend explicitly applies to overview routes only.

## Bounds and acceptance

At most20 ordered-pair aggregates and8 wrapped badge lines; oversized evidence or grouping is rejected rather than omitted or shrunk. The original helper's60-node/100-flow limits also apply. At least one actual directed flow is needed; the builder does not invent one. Long or unusual inputs still need native rendering even within bounds.

All final page numbers are rebuilt after adding the overview. Updates cover printed footer/index targets and both `UserObject.label` and the child `mxCell.value`, which can otherwise disagree in actual renderers. Verify printed targets against the actual final page list.

The 40-node/40-flow test uses a large canvas and needs zoom/scroll. This is a readable navigable architecture document, not a single-screen executive slide. Core mxGraph rendering and attachment have been tested; diagrams.net desktop-specific editor extensions and subsequent manual editing workflows are not certified. Source semantics and client delivery require separate checks for each new enterprise artifact.
