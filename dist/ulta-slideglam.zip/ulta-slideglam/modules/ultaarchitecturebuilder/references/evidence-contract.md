# Architecture evidence contract 1 - local review candidate

This stdlib Python 3.9+ checker is read-only except for its requested report. It does not execute the builder, contact sources or modify artifacts. Keep the existing builder input schema and renderers unchanged. Run only after the requested final HTML/draw.io files, exact input and optional overview config are frozen.

```sh
python3 scripts/architecture_source_review_check.py inventory --artifact final.html --artifact final.drawio --input input.json --overview overview.json --report inventory.json
python3 scripts/architecture_source_review_check.py check --artifact final.html --artifact final.drawio --input input.json --overview overview.json --bank bank.json --review review.json --report evidence-contract.json
```

Repeat `--artifact` only for requested formats. Omit `--overview` when none was used. HTML presentation-only configuration is outside this first contract; the final artifact hash still binds its exact bytes. This is not a builder CLI wrapper or an approval command.

## Results

* Exit 0, `INVENTORY_ONLY`: extraction completed, without a source-review acceptance claim.
* Exit 0, `EVIDENCE_CONTRACT_COMPLETE`: the supplied review and retained records reconcile mechanically.
* Exit 1, `FAIL`: at least one demonstrated inconsistency or explicitly unsupported drawn relationship. Other unknown checks remain listed independently.
* Exit 2, `UNVERIFIED`: required evidence unavailable, unsupported extraction/mapping, malformed input or an incomplete check, with no known failure already recorded.

Argument/unsafe-output errors exit 2 without writing a report to the prohibited destination. Missing originals are not recreated to pass the gate. A later save of any bound artifact/input/config/bank invalidates the review.

Every report explicitly retains `source_authenticity: NOT_CHECKED`, `semantic_entailment: NOT_CHECKED`, `atomic_completeness: REVIEWER_ATTESTED`, `visible_rendering: NOT_CHECKED`, `HTML_runtime_hyperlinks: NOT_CHECKED` and `deployment_or_approval: NOT_CHECKED`. A falsely positive reviewer assertion, a disguised named object labelled logical, a compound assertion or a fabricated capture with internally matching hashes can pass this mechanical contract. Independent final-file/source review remains required.

## Exact final inventory

The extractor accepts one HTML `script#architecture-data[type=application/json]` and uncompressed native `mxfile` XML with `supplied_input_json` and its canonical SHA-256. It compares every embedded source value with the exact input JSON. It checks native per-page IDs/references and actual flow-ID endpoints, not substring occurrences. Every recognized native node/flow `supplied_json` object must exactly match its corresponding final source record; missing or unsupported metadata shapes stay UNVERIFIED. This checks stored record consistency, not visible labels or semantic truth. Additional native edges require a recognized supplied overview aggregate with exact actual ordered group pair and full member records; otherwise they are UNVERIFIED. Eligible HTTPS native citation targets must match the supplied source URLs and node/flow references. Runtime HTML navigation and visual text/geometry are separate checks.

Known material fields are input schema 1.0: `title`, `scope`, `nodes`, `flows`, `sources`, `notes`, `facts`, `actions`, and example-only `fixture_source`; node fields `label`, `technical_id`, `role`, `zone`, `details`, `evidence`; flow fields `label`, `protocol`, `protocol_state`, `transport`, `flow_type`, `details`, `evidence`; source fields `title`, `url`, `version`, `date`, `status`. Evidence is a string or `{state, as_of?, note?}`. Structural IDs/endpoints/source references are validated separately. Unknown object fields are inventoried where possible and marked UNVERIFIED rather than discarded.

All nonempty scalar material values, including null/numeric values, are exact text units. Free-form dictionary keys under facts/notes/actions/details are also material units: a heading can make a claim. Each unit records final owner (`node:<ID>`, `flow:<ID>`, `source:<ID>`, or `context`), input JSON pointer, exact text and SHA-256. Flow relationship units additionally serialize actual ID/source/target/type/interface/transport/evidence. Their `kind` is `relationship`; they cannot be exempted as decorative text. Inventory SHA-256 uses UTF-8 JSON with sorted keys and compact separators, `ensure_ascii=False`.

This inventory covers supplied source data, not every sentence in renderer code, aggregate presentation headings or altered visible serialization. The unchanged renderer/reproduction gate and actual native/browser review remain necessary; a matching embedded JSON block cannot prove visible correctness.

## Bank schema: `architecture-evidence-bank/1`

The top-level object has exactly `schema`, `sources` and `passages`. Unknown fields make the run UNVERIFIED. IDs must be nonempty strings and unique within their list; source IDs must exactly match the final source register.

Every source object has these keys:

| Key | Required value |
|---|---|
| `id`, `title`, `url` | Exact final source ID/title/URL. A user-supplied source may have null URL. |
| `retrieved_at` | Actual nonempty retrieval-time string. Its historical truth is attested, not inferred. |
| `access_scope` | `full_returned_text`, `excerpt`, `title_only`, `unavailable`, or `user_supplied`. |
| `omissions` | Explicit omitted/truncated content declaration; preserve limits. |
| `metadata` | Exactly the final source's `{version, date, status}` values (null when absent). Keep page versions and document revisions distinct in the source authoring process. |
| `capture` | `{file, bytes, sha256}` for exact retained UTF-8 bytes; null only when unavailable (UNVERIFIED). `file` is relative to the bank directory. |

Capture paths must remain inside the bank directory; absolute paths, traversal and symlinks are rejected. Each input/capture is snapshotted once per resolved path, and all its parsing/hashes/slices use that snapshot. Reports list actual byte observations. File existence and hashes detect a missing or mismatched capture; they do not authenticate the claimed origin or detect a falsely labelled summary.

Every passage has exactly `id`, `source_id`, `capture_sha256`, `start`, `end`, `quote`, `locator`. Offsets are zero-based Unicode character indices, end-exclusive, into the decoded retained capture. `quote` must equal the exact slice, with no whitespace normalization. `locator` is a nonempty section/table/row/field explanation. A technical claim bound only to title-only/unavailable text stays UNVERIFIED. Excerpts may support a narrow claim, but the reviewer must assess omitted context.

## Final review schema: `architecture-final-review/1`

The top-level object has exactly `schema`, `binding`, `reviewer`, `claims`, `nonfactual_spans`, `nodes`, `relationships`, `context_citations`. Empty lists are explicit; no default SUPPORTED or `claims_split=true` flag exists.

`binding` must equal the freshly derived object:

```json
{
  "artifacts": [{"name":"final.html","bytes":123,"sha256":"..."}],
  "input": {"name":"input.json","bytes":123,"sha256":"..."},
  "overview": null,
  "inventory_sha256": "...",
  "bank_sha256": "..."
}
```

Artifact order matches the CLI. A supplied overview uses its actual `{name, bytes, sha256}` record. Review bytes and checker bytes are hashed in the report; the package manifest independently pins the authorized checker. `reviewer` has actual `name`, `kind`, `reviewed_at` and boolean `retrospective`. Do not label a generated after-delivery review as an original human sign-off.

Each claim has exactly `id`, `unit_id`, `start`, `end`, `quote`, `assertion`, `kind`, `passage_ids`, `verdict`, `scope`, `reason`. The final unit/span/quote is exact. `assertion`, `scope` and `reason` are explicit nonempty reviewer text. `kind` is `technical`, `metadata`, `unknown` or `proposal`. `verdict` is `SUPPORTED`, `SUPPORTED_WITH_SCOPE`, `UNVERIFIED`, `UNSUPPORTED`, `CONTRADICTED` or `PROPOSED`. Technical/metadata claims require nonempty retained passage joins. Unbound proposal claims must use PROPOSED. Unknown/proposal classifications do not semantically exempt factual premises; the reviewer must split and bind those premises.

Each specifically reasoned nonfactual span has exactly `id`, `unit_id`, `start`, `end`, `quote`, `reason`. Every non-whitespace character in every material unit must be covered by at least one claim or a specifically reasoned nonfactual span. Uncovered spans fail and appear with offsets/quotes. Overlap is allowed for compound source support; exact partition coverage does not prove atomicity. A single falsely supported whole-unit claim can cover a compound paragraph, and a wrongly exempted positive clause remains a reviewer error this code cannot infer.

Required sources are independently derived from final claim → passage → source joins for each node/flow owner. The actual exported `source_ids` set must equal that set: missing secondary sources and additional unbound declarations both fail. Extra claimed sources are not accepted as a substitute for a correct comparison join. This is set reconciliation, not evidence entailment.

For sourced context/facts/actions outside a node/flow record, `context_citations` has exact `id`, `unit_id`, `source_id`, `start`, `end`, `quote`. It maps an exact `[source-ID]` token or the exact supplied source URL within the same material unit. It never scans for token overlap to prove a claim. Unsupported citation syntax or citations living in a different unit remain UNVERIFIED; a global source register is insufficient. This first adapter does not infer parent/child field citation inheritance.

## Typed final relationship review

Every actual node ID has exactly one `nodes` entry: `{id, identity_kind, claim_ids, reason}`. Identity kinds are `named_system`, `named_object`, `named_actor_group`, `logical_responsibility`, `unknown_party`. Claims must belong to that exact final node. The reviewer must honestly distinguish a functional unknown from a specific named table/app.

Every actual flow ID has exactly one `relationships` entry with `id`, `source`, `target`, `actual_flow_type`, `reviewed_relation`, `claim_ids`, `source_support`, `target_support`, `relation_support`. Source/target/type must match final data. `reviewed_relation` is `direct_interface`, `data_read`, `data_write`, `user_access`, `indirect_influence`, `logical_requirement`, or `proposed_alternative`.

Relationship `claim_ids` must reference that flow's actual synthetic relationship unit, not a fact about an endpoint merely existing. Each of the three support decisions has exactly `verdict`, `claim_ids`, `reason`, with nonempty claim IDs from the same relationship join. A positive decision needs supported relationship claims with retained passages. Explicitly unknown participation at a named endpoint fails even when the flow label says logical. Explicitly unverified direct/read/write/access relations also fail. Other unresolved participation stays UNVERIFIED. Proposed participation needs a proposed-alternative relationship and an explicit final proposal span. The checker does not use semantic substring rules to decide whether the stated support is true.

## Read-only and bounded behavior

Inputs are bounded to 64 MiB each, 60 nodes, 100 flows and 50,000 material units. Duplicate JSON keys/nonfinite values are rejected. Reports cannot overwrite read inputs, retained captures, checker source, symlinks or existing hard-link aliases. No network requests, dynamic imports from manifests, shell commands, template mutation or external uploads occur.

The two fictional fixtures and mutation results are local evidence-contract tests. They are not an assisted repair of an enterprise candidate, a live-agent reliability pass or a publish recommendation.
