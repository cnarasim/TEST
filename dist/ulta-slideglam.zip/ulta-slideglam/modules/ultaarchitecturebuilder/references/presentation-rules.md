# Evidence/status presentation rules

Source data and presentation config are separate. Preserve every original `evidence.state`, `as_of`, `note`, status, protocol and source reference. A successful exact match confirms only that the supplied value matched a rule; it does not validate the classification or source claim.

Both formats use this shared subset:

```json
{
  "evidence_rules": [
    {"field":"evidence.state","equals":"sandbox configured","class":"historical"},
    {"field":"evidence.state","equals":"disabled/proposed","class":"proposed"}
  ],
  "status_rules": [
    {"field":"details.status","equals":"disabled; proposed enablement; not exercised","flags":["disabled","proposed"]}
  ]
}
```

This is fictional source wording from the packaged warehouse example. Do not use its classifications as evidence about an enterprise project.

Evidence `field` is `evidence` for string form or `evidence.state` for object form. Classes are `documented`, `observed`, `draft`, `historical`, `proposed`, `unknown`, `unverified`. Status `field` is `status`, `details.status` or `flow_type`. Flags are `disabled`, `proposed`, `historical`, `unknown`, `unverified`; simultaneous disabled/proposed flags are valid when explicitly supported. `equals` must be a nonempty exact string. There is no substring search, case-folding, whitespace normalization or negation guessing. Unknown custom wording stays visibly raw and neutral/unclassified. Unsupported production/approval classes are rejected.

Supply only the documented fields, no duplicate rules or flags. HTML `--presentation` contains only the two rule lists. Both formats' `--overview` additionally contains `presentation_groups`; use their respective overview references for bounds. Grouping is rejected in HTML `--presentation`, and all config modes reject unknown top-level keys and invalid paths/classes/flags or duplicate exact rules.

| Evidence class | Color / route |
|---|---|
| documented | #286080 solid; documented design, not deployment |
| observed | #347466 solid; supplied observation at its actual scope/date |
| draft / proposed | #865EAD dashed |
| historical | #8A6A3D dashed |
| unknown / unverified | #686868 dashed |

Unclassified HTML uses a neutral style and its explicit legend label. Unclassified XML uses neutral unknown styling with an unclassified member label. An explicit disabled single HTML flow is red/dashed (#B04444) while retaining its original evidence class and flags. XML aggregates with mixed original evidence, protocol, transport, flow type or status remain neutral (#555555 solid), with member exceptions shown. Homogeneous all-disabled aggregates are red/dashed. The formats do not silently turn a proposal into a deployment claim.

HTML route, arrow, badge and legend share the same resolver, and selection preserves its color. HTML badges attach to actual route points, with an optional segment/fraction hint; connected HTML overview uses the bundled shared grouped router. XML aggregate badges are native edge-child vertices on source segments. The XML aggregate legend applies only to the optional overview; existing focused XML pages explicitly show direction-only neutral lines and original evidence text. This scope difference preserves existing detailed pages and avoids claiming a common aggregate meaning for a single flow.

Classification curators must check sources before choosing rules. Draft document status does not prove a future-only design, observation does not prove production, unknown does not mean absent, and disabled/proposed does not establish funding or approval. Render and inspect each new artifact; attachment by itself does not prevent overlaps.
