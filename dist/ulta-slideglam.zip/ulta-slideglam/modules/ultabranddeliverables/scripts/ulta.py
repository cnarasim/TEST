#!/usr/bin/env python3
"""Ulta brand deliverables - one command for decks and infographics on the Ulta template.

  ulta.py check                                         python-pptx, lxml, Pillow, the template hash; resvg (optional, PNG/PDF)
  ulta.py deck content.md --out Deck.pptx [--title T] [--max-slides N] [--theme ulta] [--density brief|normal|dense]
  ulta.py spec content.md --out spec.json               the slide plan (template slide numbers + region fills) to review or edit
  ulta.py build spec.json --out Deck.pptx               a deck from a (reviewed or hand-written) spec
  ulta.py templates                                     the infographic templates
  ulta.py content-template ID [--docx File.docx]        a template's fill-in content (Markdown on stdout, or a Word file)
  ulta.py diagram-styles                                the architecture diagram styles: what each is for and what it needs
  ulta.py diagram flows.txt|arch.json --out NAME [--style zones|auto] [--title T] [--all-styles] [--frame]
                                                        NAME.pptx (a diagram slide on the template), NAME.drawio, NAME.svg (+ NAME.png with resvg)
  ulta.py infographic filled.md --template ID|auto|free --format onepager|slide|square [--theme ulta] --out NAME
                                                        NAME.pptx, NAME.svg, NAME.html, NAME-content.md (+ NAME.png / NAME.pdf with resvg)
"""
import importlib
import importlib.util
import argparse, atexit, hashlib, json, os, re, shutil, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__)); KIT = os.path.join(HERE, 'kit'); TPL = os.path.join(KIT, 'templates')
sys.path.insert(0, KIT); sys.path.insert(0, os.path.join(KIT, 'infographic')); sys.path.insert(0, os.path.join(KIT, 'diagram'))


def scratch():
    """A private working folder in the temp folder, removed when this run ends."""
    d = tempfile.mkdtemp(prefix=f'ulta-run-{os.getpid()}-'); atexit.register(shutil.rmtree, d, True); return d   # tools/atomic.py sweeps a stopped run's


def _plain():
    """The skill's plain-punctuation pass (tools/plain.py: no em dashes in what a reader sees), loaded by its path so it
    can never shadow a kit module; None when the kit runs on its own, outside the skill."""
    path = os.path.normpath(os.path.join(HERE, '..', '..', '..', 'tools', 'plain.py'))
    if not os.path.exists(path): return None
    spec = importlib.util.spec_from_file_location('ulta_plain', path); mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod); return mod


PLAIN = _plain()


def run(args):
    p = subprocess.run([sys.executable] + args, capture_output=True, text=True, cwd=KIT)
    if p.returncode: sys.exit(f'failed: {" ".join(os.path.basename(a) for a in args[:1])}\n{(p.stdout + p.stderr)[-2000:]}')
    m = re.findall(r'\{.*\}', p.stdout, re.S)
    try: return json.loads(m[-1]) if m else {}
    except Exception: return {'raw': p.stdout[-800:]}


def cmd_check(a):
    ok = True
    for mod in ('pptx', 'lxml', 'PIL'):
        try: importlib.import_module(mod); print(f'ok      {mod}')
        except Exception: print(f'MISSING {mod} - pip install python-pptx lxml pillow'); ok = False
    for mod in ('page_to_spec', 'build_from_storyboard', 'themes', 'svgraster', 'info', 'templates', 'slide_diagram', 'draft_rules', 'build_drawio', 'drawio_router'):   # every kit module loads
        try: importlib.import_module(mod); print(f'ok      kit {mod}')
        except Exception as e: print(f'MISSING kit {mod}: {type(e).__name__}: {e}'); ok = False
    try: importlib.import_module('resvg_py'); print('ok      resvg-py (PNG / PDF pictures)')
    except Exception: print('note    resvg-py not installed - infographics give .pptx / .svg / .html; PNG and PDF are skipped')
    man = json.load(open(os.path.join(TPL, 'manifest.json'), encoding='utf-8'))
    for tid, t in man['templates'].items():
        h = hashlib.sha256(open(os.path.join(TPL, t['file']), 'rb').read()).hexdigest()
        print(('ok      ' if h == t['sha256'] else 'CHANGED ') + f"template {tid}: {t['file']}"); ok &= h == t['sha256']
    print('ready' if ok else 'NOT READY'); sys.exit(0 if ok else 1)


def cmd_spec(a, out=None):
    out = out or a.out; args = [os.path.join(KIT, 'page_to_spec.py'), os.path.abspath(a.input), '--out', os.path.abspath(out), '--density', a.density]
    if a.title: args += ['--title', a.title]
    if a.max_slides: args += ['--max-slides', str(a.max_slides)]
    r = run(args)
    if a.theme and a.theme != 'ulta':
        s = json.load(open(out, encoding='utf-8')); s['theme'] = a.theme; json.dump(s, open(out, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
    for w in r.get('warnings') or []: print('warning:', w)
    print(f"spec: {r.get('slides')} slides → {out}")
    if r.get('slides') is not None and r['slides'] <= 2: print('warning: only a cover and a closing slide - the content was not read; check the warnings above and `ulta.py check`')
    return out


def cmd_build(a, spec=None):
    sp = os.path.abspath(spec or a.input)
    r = run([os.path.join(KIT, 'build_from_storyboard.py'), sp, '--templates', TPL, '--out', os.path.abspath(a.out)])
    for w in r.get('warnings') or []: print('warning:', w)
    s = json.load(open(sp, encoding='utf-8')); n = len(s.get('slides') or []); print(f'built: {a.out} ({n} slides)')
    base = os.path.splitext(os.path.abspath(a.out))[0]; d = scratch()
    for k, sl in enumerate([x for x in s.get('slides') or [] if isinstance(x.get('diagram'), dict)], 1):   # each diagram slide also as an editable .drawio
        dsp = os.path.join(d, f'diagram-{k}.json'); json.dump(sl['diagram'], open(dsp, 'w'), ensure_ascii=False)
        dn = f'{base}-diagram{"" if k == 1 else "-" + str(k)}.drawio'
        run([os.path.join(KIT, 'diagram', 'build_drawio.py'), dsp, '--out', dn, '--theme', 'cloud' if sl.get('diagram_style') == 'cloud' else 'ulta'])
        if os.path.exists(dn): print(f'  {dn}')


def cmd_deck(a):
    d = scratch(); sp = cmd_spec(a, os.path.join(d, 'spec.json')); cmd_build(a, sp)


def cmd_templates(a):
    import templates as TP
    for c in TP.catalogue(): print(f"{c['id']:14} {c['name']:42} {c['group'] or '—':18} {c['blurb']}")


def cmd_content(a):
    import templates as TP
    md = TP.content_md(a.id)
    if not md: sys.exit(f'no template {a.id!r} - see: ulta.py templates')
    if not a.docx: print(md); return
    from docx import Document
    doc = Document()
    for block in re.split(r'\n(?=## )', md.strip()):
        lines = [l for l in block.split('\n') if l.strip()]
        if lines[0].startswith('# '):
            doc.add_paragraph(lines[0][2:], style='Title'); [doc.add_paragraph(l) for l in lines[1:]]; continue
        doc.add_paragraph(lines[0][3:], style='Heading 2'); rows = [l for l in lines[1:] if l.startswith('|') and not re.fullmatch(r'\|[\s:|-]+\|', l)]
        if rows:
            cells = [[c.strip() for c in r.strip('|').split('|')] for r in rows]; tb = doc.add_table(rows=len(cells), cols=len(cells[0])); tb.style = 'Table Grid'
            for i, r in enumerate(cells):
                for j, v in enumerate(r): tb.cell(i, j).text = v
        for l in lines[1:]:
            if l.startswith('|'): continue
            m = re.match(r'^\d{1,2}[.)]\s+(.*)', l)
            if l.startswith('- '): doc.add_paragraph(l[2:], style='List Bullet')
            elif m: doc.add_paragraph(m.group(1), style='List Number')
            elif l.startswith('### '): doc.add_paragraph(l[4:], style='Heading 3')
            else: doc.add_paragraph(l)
    doc.save(a.docx + '.part'); os.replace(a.docx + '.part', a.docx)
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', '..', 'tools'))
    try:
        import ulta_word; ulta_word.brand(a.docx, made=True)   # official Ulta Word template letterhead
    except Exception as e: print(f'note: Ulta Word letterhead not applied ({type(e).__name__}: {e})')
    print(f'wrote {a.docx}')


def cmd_infographic(a):
    import info as IG, templates as TP
    text = open(a.input, encoding='utf-8', errors='replace').read(); tid = a.template
    if tid == 'auto': tid = TP.detect(text); print(f'template (by its headings): {tid}')
    if tid == 'free': spec = IG.rules_spec(text, a.format, a.theme)
    else:
        f, n, miss = TP.coverage(tid, text)
        if n and f < n: print(f'note: {f} of the template\'s {n} sections found - missing: {", ".join(miss)} (headings: ulta.py content-template {tid})')
        spec = TP.template_spec(tid, text, a.format, a.theme) if f else IG.rules_spec(text, a.format, a.theme)
    if a.title: spec['title'] = a.title
    if a.title and PLAIN: spec['title'] = PLAIN.text(a.title)
    import pictures                                 # "![caption](file)": the picture, checked and without its metadata, in every file
    smp = pictures.samples(spec)
    for w in pictures.take_in(spec, os.path.dirname(os.path.abspath(a.input))): print('warning:', w)
    d = IG.layout(spec); base = os.path.abspath(a.out); os.makedirs(os.path.dirname(base) or '.', exist_ok=True); files = []
    if PLAIN: d = PLAIN.deep(d)                     # after parsing (which reads dashes in the content): all drawn from d
    for w in d.get('warnings') or []: print('warning:', w)
    svgs = IG.page_svgs(d); open(base + '.svg', 'w', encoding='utf-8').write(svgs[0]); files.append(base + '.svg')
    for i, s in enumerate(svgs[1:], 2): open(f'{base}-{i}.svg', 'w', encoding='utf-8').write(s); files.append(f'{base}-{i}.svg')
    open(base + '.html', 'w', encoding='utf-8').write(IG.to_html(d)); files.append(base + '.html')
    open(base + '-content.md', 'w', encoding='utf-8').write(IG.to_markdown(d)); files.append(base + '-content.md')
    if d['spec']['format'] == 'slide':   # 16:9: the infographic on the Ulta template, one slide (--frame: with its cover and closing)
        man = json.load(open(os.path.join(TPL, 'manifest.json'))); tpl = man.get('default') or 'STANDARD33'; roles = (man['templates'].get(tpl) or {}).get('roles') or {}
        sp = os.path.join(scratch(), 'spec.json')
        json.dump(IG.to_spec(d, tpl, a.frame and not a.no_frame, roles.get('two_col', 6), roles.get('cover', 1), roles.get('closing', 32)), open(sp, 'w', encoding='utf-8'), ensure_ascii=False)
        r = run([os.path.join(KIT, 'build_from_storyboard.py'), sp, '--templates', TPL, '--out', base + '.pptx'])
        for w in r.get('warnings') or []:
            if 'headline' not in w: print('warning:', w)
    else:
        import build_from_storyboard as B
        for w in B.info_pptx(d, base + '.pptx') or []: print('warning:', w)
    files.append(base + '.pptx')
    if IG.to_png(svgs[0], base + '.png', 2.0): files.append(base + '.png')
    if IG.to_pdf_pages(svgs, base + '.pdf', d['spec']['format']): files.append(base + '.pdf')
    s = d['spec']; print(f"built: {s.get('template') or 'free'} · {s['format']} · {len(s['blocks'])} blocks · {1 + len(d.get('pages') or [])} page(s)")
    n_t, low_t = IG.readable_report(d); print(f'readable text: {n_t} texts, {len(low_t)} under the bar')
    for t_, col, und, r_, need in low_t[:3]: print(f"warning: hard to read: '{t_[:40]}' #{col} on #{und} = {r_}:1 (needs {need}:1)")
    pl, sc, bare, ms = pictures.tally(s)
    if pl or ms or smp: print(f'pictures: {pl} placed, {sc} screenshots, {bare} without a caption, {ms} missing, {smp} samples')
    for f in files: print('  ' + f)


ARCH_STYLES = ['bands', 'outline', 'pastel', 'icons', 'midnight', 'numbered', 'cake', 'hub', 'chevron', 'bubbles', 'sequence', 'matrix', 'zones', 'tech', 'radial', 'tree', 'cloud']


def _arch_input(path):
    """A diagram from: arch JSON ({nodes, flows} or {systems, flows}); lines "A → B: what flows"; a chain "A → B → C"; or box art."""
    import slide_diagram as SD
    raw = open(path, encoding='utf-8', errors='replace').read(); s = raw.strip()
    if s.startswith('{'): return json.loads(s)
    lines = [l.strip().lstrip('-*• ') for l in s.split('\n') if l.strip() and not l.strip().startswith('#') and not re.match(r'^(diagram )?style\s*:', l.strip(), re.I)]
    pairs = []
    for l in lines:   # a chain on one line: each link is a pair
        parts = [p.strip() for p in re.split(r'\s*(?:→|->|──►|=>)\s*', l)]
        if len(parts) >= 3 and all(parts) and ':' not in parts[-1]: pairs += [(parts[i], parts[i + 1], '') for i in range(len(parts) - 1)]
    pairs += SD.arrow_lines([l for l in lines if len(re.findall(r'→|->|──►|=>', l)) == 1]) or []
    if pairs: return pairs
    if SD.is_art(raw): return raw
    sys.exit('no diagram found: write lines "A → B: what flows" (one per line), a chain "A → B → C", box art, or arch JSON')


def cmd_styles(a):
    import slide_diagram as SD
    print('Architecture styles (flows between systems):')
    for k in ARCH_STYLES: print(f"  {k:10} {SD.STYLES[k][0]:20} {SD.STYLES[k][1]}" + (f" - needs {SD.STYLE_NEEDS[k]}" if k in SD.STYLE_NEEDS else ''))
    print('Point graphics (a list of points, no flows) - use ulta.py infographic or a deck: funnel, pyramid, stairs, milestones, quadrant, venn, target, honeycomb')


def cmd_diagram(a):
    import slide_diagram as SD, info as IG
    src = _arch_input(a.input); title = a.title or os.path.splitext(os.path.basename(a.input))[0].replace('-', ' ').title()
    probe = SD.build(src, title, style='auto')
    if not probe: sys.exit('could not read a diagram of two or more systems from the input')
    _, arch0, _ = probe
    styles = [s for s in ARCH_STYLES if SD.suits(arch0, s)] if a.all_styles else [a.style]
    box = (70, 196, 1460, 576 - max(0, min(int(a.room or 0), 200))) if getattr(a, 'room', 0) else None   # room left free at the bottom
    man = json.load(open(os.path.join(TPL, 'manifest.json'))); tpl = man.get('default') or 'STANDARD33'; roles = (man['templates'].get(tpl) or {}).get('roles') or {}
    slides = []; base = os.path.abspath(a.out); os.makedirs(os.path.dirname(base) or '.', exist_ok=True); d0 = None; n_t, low_t = 0, []
    if a.frame: slides.append({'source': roles.get('cover', 1), 'kind': 'cover', 'fills': {'title': title}})
    for st in styles:
        d, arch, dropped = SD.build(src, title, style=st, box=box)
        if PLAIN: d, arch = PLAIN.deep(d), PLAIN.deep(arch)
        if st not in ('auto', d.get('style')): print(f'note: style "{st}" needs {SD.STYLE_NEEDS.get(st, "a different diagram")} — drawn as {d.get("style")}')
        d0 = d0 or (d, arch); n_, l_ = IG.readable_report(d, SD.SLIDE_BG); n_t += n_; low_t += l_
        slides.append({'source': roles.get('two_col', 6), 'fills': {'title': title if not a.all_styles else f"{title} - {SD.STYLES.get(d.get('style'), (d.get('style'),))[0]}", 'text1': [''], 'text2': ['']},
                       'hide': ['text1', 'text2'], 'info': d, 'info_svg': IG.to_svg(d, chrome=False), 'diagram': SD.drawio_spec(arch), 'arch': arch, 'diagram_style': d.get('style'),
                       'notes': SD.notes(arch, dropped)})
    if a.frame: slides.append({'source': roles.get('closing', 32), 'kind': 'closing', 'fills': {'text1': 'Thank you!', 'text2': 'Ulta Beauty | Proprietary & Confidential'}})
    sp = os.path.join(scratch(), 'spec.json'); json.dump({'template': tpl, 'title': title, 'slides': slides, 'warnings': []}, open(sp, 'w', encoding='utf-8'), ensure_ascii=False)
    r = run([os.path.join(KIT, 'build_from_storyboard.py'), sp, '--templates', TPL, '--out', base + '.pptx'])
    for w in r.get('warnings') or []:
        if 'headline' not in w: print('warning:', w)
    d, arch = d0; files = [base + '.pptx']
    dsp = sp + '.diagram.json'; json.dump(SD.drawio_spec(arch), open(dsp, 'w'), ensure_ascii=False)
    run([os.path.join(KIT, 'diagram', 'build_drawio.py'), dsp, '--out', base + '.drawio', '--theme', 'cloud' if d.get('style') == 'cloud' else 'ulta'])
    if os.path.exists(base + '.drawio'): files.append(base + '.drawio')
    svg = IG.to_svg(d); open(base + '.svg', 'w', encoding='utf-8').write(svg); files.append(base + '.svg')
    if IG.to_png(svg, base + '.png', 2.0): files.append(base + '.png')
    print(f"built: {len(styles)} diagram slide(s) · style {', '.join(s['diagram_style'] for s in slides if s.get('diagram_style'))} · {len(arch['nodes'])} systems, {len(arch['flows'])} flows")
    print(f'readable text: {n_t} texts, {len(low_t)} under the bar')
    for t_, col, und, r_, need in low_t[:3]: print(f"warning: hard to read: '{t_[:40]}' #{col} on #{und} = {r_}:1 (needs {need}:1)")
    for f in files: print('  ' + f)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter); sub = ap.add_subparsers(dest='cmd', required=True)
    sub.add_parser('check')
    for nm in ('deck', 'spec'):
        p = sub.add_parser(nm); p.add_argument('input'); p.add_argument('--out', required=True); p.add_argument('--title'); p.add_argument('--max-slides', type=int, default=0)
        p.add_argument('--theme', default='ulta'); p.add_argument('--density', default='brief', choices=['brief', 'normal', 'dense', 'compact', 'tight'])
    p = sub.add_parser('build'); p.add_argument('input'); p.add_argument('--out', required=True)
    sub.add_parser('templates'); sub.add_parser('diagram-styles')
    p = sub.add_parser('diagram'); p.add_argument('input'); p.add_argument('--out', required=True); p.add_argument('--style', default='auto'); p.add_argument('--title')
    p.add_argument('--room', type=int, default=0, help='canvas px (of 900) left free at the bottom, for a decision bar');
    p.add_argument('--all-styles', action='store_true', help='one slide per style that suits the diagram - to compare'); p.add_argument('--frame', action='store_true', help='add cover and closing slides')
    p = sub.add_parser('content-template'); p.add_argument('id'); p.add_argument('--docx')
    p = sub.add_parser('infographic'); p.add_argument('input'); p.add_argument('--out', required=True); p.add_argument('--template', default='auto')
    p.add_argument('--format', default='onepager', choices=['onepager', 'slide', 'square']); p.add_argument('--theme', default='ulta'); p.add_argument('--title')
    p.add_argument('--frame', action='store_true', help="16:9: add the template's cover and closing slides (without it: the slide alone)")
    p.add_argument('--no-frame', action='store_true', help='the slide alone (the default; kept for older instructions)')
    a = ap.parse_args()
    {'check': cmd_check, 'deck': cmd_deck, 'spec': cmd_spec, 'build': cmd_build, 'templates': cmd_templates, 'content-template': cmd_content, 'infographic': cmd_infographic, 'diagram-styles': cmd_styles, 'diagram': cmd_diagram}[a.cmd](a)


if __name__ == '__main__':
    main()
