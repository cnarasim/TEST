"""Infographic themes: how the coloured elements of the infographic slides (card headers, step boxes, label cells, bands, callout
strips, funnel / pyramid / cycle shapes) are treated. Same template, same typography, same Ulta palette - a different mood.
fill: keep | white | tint | dark | velvet (dark → brand gradient) | sunset (brand → warm gradient);  line: None | (hex or 'brand', pt);
radius: roundRect adj (0–50000) or None; shadow: False | True (soft grey) | 'brand' (a glow in the element's own colour)."""
THEMES = {
    'ulta':     {'label': 'Ulta',     'note': 'The template as designed; infographics lead in a light orange gradient on a light page, with icons on brand colours.', 'fill': 'keep',   'line': None,             'radius': None,  'shadow': False},
    'glow':     {'label': 'Glow',     'note': 'White cards floating on a soft glow in their own colour.',                        'fill': 'white',  'line': ('D9D9D9', 0.75), 'radius': 10000, 'shadow': 'brand'},
    'velvet':   {'label': 'Velvet',   'note': 'Deep ink cards lit by the brand colour from one corner - premium, dramatic.',      'fill': 'velvet', 'line': None,             'radius': 9000,  'shadow': True},
    'frost':    {'label': 'Frost',    'note': 'Pastel tints behind a fine white rule - light, glassy, calm.',                     'fill': 'tint',   'line': ('FFFFFF', 1.5),  'radius': 20000, 'shadow': False, 'tint': 0.84},
    'paper':    {'label': 'Paper',    'note': 'White cards, a hairline in the brand colour, ink type - quiet and precise.',       'fill': 'white',  'line': ('brand', 1.25),  'radius': 6000,  'shadow': False},
    'sunset':   {'label': 'Sunset',   'note': 'Elements warm into gold; one-pager cards run gold into a soft tint, dark type - vivid.', 'fill': 'sunset', 'line': None,             'radius': 12000, 'shadow': False},
    'charcoal': {'label': 'Charcoal', 'note': 'One charcoal ink for every element, white type; the takeaway keeps its accent.',   'fill': 'dark',   'line': None,             'radius': 8000,  'shadow': False},
}
ORDER = ['ulta', 'glow', 'velvet', 'frost', 'paper', 'sunset', 'charcoal']
ALIASES = {'consulting': 'paper', 'apple': 'frost', 'carbon': 'paper', 'material': 'glow', 'editorial': 'frost', 'ink': 'charcoal'}   # names used before v3.37
BRAND = {'D01381', 'E8275A', 'E8275A', 'E9341C', 'EE6C37', '5D0F43', 'F26923', 'C10060', 'E0531B'}   # the palette's solid colours, as the template and the builder write them
INK = '000000'
GOLD = 'FF893F'


def tint(hex_, amount):
    r, g, b = (int(hex_[i:i + 2], 16) for i in (0, 2, 4))
    f = lambda c: int(round(c + (255 - c) * amount))
    return f'{f(r):02X}{f(g):02X}{f(b):02X}'


def resolve(name):
    name = str(name or 'ulta').lower(); name = ALIASES.get(name, name)
    return name if name in THEMES else 'ulta'
