#!/usr/bin/env python3
"""Deterministic draft of a diagram from a plain description - no model. Sentences such as "OMS sends the order to SAP as an IDoc" become
flows; the systems named as a source or a target become nodes; nodes that only send sit left, those that only receive sit right, the rest in
the middle. Good enough to draw the first picture with AI off; the AI draft (when on) reads the same text with more nuance.

  draft_rules.py description.txt [--title "…"] → arch.json on stdout
"""
import json, re

SEND = r'(?:sends?|sent|transmits?|transmitted|publishes|published|posts?|posted|delivers?|delivered|passes|passed|pushes|pushed|forwards?|forwarded|routes?|routed|settles?|settled|exports?|exported|feeds?|fed|replicates?|replicated|hands? (?:over|off)|handed (?:over|off)|flows?|moves?|moved|transfers?|transferred|submits?|submitted|syncs?|synced|writes?|written|releases?|released|triggers?|triggered|calls?|called|notifies|notified|updates?|updated|integrates?|shares?|shared|streams?|streamed|uploads?|uploaded|returns?|returned)'
ASYNC = re.compile(r'\b(periodically|batch|nightly|daily|weekly|hourly|scheduled|async|asynchronous|idoc|file|files|queue|event|events|webhook|web hook|overnight|end of day)\b', re.I)
OPT = re.compile(r'\b(optional|optionally|if needed|may|when needed|on demand)\b', re.I)
REJECT = re.compile(r'\b(reject|rejected|rejection|rollback|reverse|reversed|cancel|cancelled|canceled|return|returned|error|failure)\b', re.I)
STOP = {'the', 'a', 'an', 'and', 'or', 'to', 'in', 'into', 'for', 'of', 'on', 'at', 'by', 'from', 'with', 'via', 'through', 'as', 'after', 'before', 'then', 'order', 'orders', 'info', 'information', 'data', 'payment', 'payments', 'period', 'processing', 'customer', 'customers'}
GENERIC = {'customer': 'Customer', 'customers': 'Customer', 'store': 'Store', 'stores': 'Stores', 'warehouse': 'Warehouse', 'supplier': 'Supplier', 'suppliers': 'Suppliers', 'vendor': 'Vendor', 'carrier': 'Carrier', 'bank': 'Bank', 'user': 'User', 'users': 'Users', 'planner': 'Planner', 'dc': 'DC'}


def sentences(text):
    text = re.sub(r'[ \t\r\f\v]+', ' ', str(text or '')).strip()   # keep line breaks: one line per flow is a sentence even without a full stop
    return [s.strip() for s in re.split(r'(?<=[.!?])\s+|\s*;\s*|\s*\n\s*', text) if len(s.strip()) > 3]


SYSTEM_NOUNS = {'website', 'site', 'app', 'apps', 'application', 'portal', 'platform', 'store', 'system', 'service', 'gateway', 'hub', 'cloud', 'api', 'database', 'warehouse', 'lake', 'queue', 'bus', 'server', 'engine'}


def is_system(tok, at_start, seen):
    if not tok or tok.lower() in STOP: return False
    if tok.isupper() and len(tok) >= 2: return True                                 # SAP, OMS, ESB
    if re.match(r'^[A-Z][a-z]+[A-Z]', tok): return True                                # TikTok, iDoc-like
    if tok[0].isupper() and not at_start: return True                                  # Rithum, Manhattan mid-sentence
    if tok[0].isupper() and at_start and tok.lower() in seen: return True              # a sentence-initial name we have already met
    return False


def phrase(words, i, at_start, seen):
    """A system name starting at words[i]: up to three capitalised tokens ("BY Enterprise Planning", "SAP S/4HANA")."""
    out = []
    j = i
    while j < len(words) and j - i < 3:
        w = words[j].strip('(),.;:"\'')
        if is_system(w, at_start and j == 0, seen): out.append(w); j += 1
        elif out and re.match(r'^[A-Z0-9/]+$', w): out.append(w); j += 1
        else: break
    if out and j < len(words) and words[j].strip('(),.;:"\'').lower() in SYSTEM_NOUNS:
        out.append(words[j].strip('(),.;:"\'').lower())   # "Ulta website" and "Ulta app" are two systems, not one "Ulta"
    return ' '.join(out) if out else None


def draft(text, title=''):
    sents = sentences(text); nodes = {}; flows = []; last = None; seen = set()
    order = []
    def node(name):
        key = re.sub(r'[^a-z0-9]', '', name.lower())
        if not key: return None
        if key not in nodes: nodes[key] = {'id': key[:24], 'label': name[:28], 'sub': '', 'sends': 0, 'recv': 0}; order.append(key)
        elif name.isupper() and not nodes[key]['label'].isupper(): pass                 # "ULTA" vs "Ulta": keep the first spelling
        return key
    for s in sents:
        m0 = re.match(r'^([^:]{3,80}):\s*(\S.*)$', s)
        if m0 and re.search(r'\b' + SEND + r'\b', m0.group(2), re.I) and not re.search(r'\b' + SEND + r'\b', m0.group(1), re.I):
            s = m0.group(2)   # "Draw an integration diagram: Ulta website sends …" - the lead-in is the request, not a system
        words = s.split(); lows = {w.strip('(),.;:"\'').lower() for w in words}
        seen |= {w.strip('(),.;:"\'').lower() for w in words if w.strip('(),.;:"\'')[:1].isupper()}
        # source: the first system phrase before the verb; else the last system of the previous sentence
        m = re.search(r'\b' + SEND + r'\b', s, re.I); src = None
        head = words[:len(re.findall(r'\S+', s[:m.start()]))] if m else words
        for i, w in enumerate(head):
            p = phrase(head, i, i == 0, seen)
            if p: src = p; break
        # target: the first system phrase after " to " / " into " / " toward(s) " (a generic noun such as "the customer" counts)
        tgt = None; tm = re.search(r'\b(?:to|into|towards?|onto)\s+(?:the\s+|an?\s+)?', s[m.end():] if m else s, re.I)
        if tm:
            tail = (s[m.end():] if m else s)[tm.end():].split()
            p = phrase(tail, 0, False, seen) if tail else None
            if not p and tail:
                g = tail[0].strip('(),.;:"\'').lower()
                if g in GENERIC: p = GENERIC[g]
            tgt = p
        if not src and tgt and last: src = nodes[last]['label']
        if src and tgt and src.lower() != tgt.lower():
            a, b = node(src), node(tgt)
            if a and b and a != b:
                kind = 'reject' if REJECT.search(s) else 'opt' if OPT.search(s) else 'async' if ASYNC.search(s) else 'sync'
                desc = re.sub(r'\s+', ' ', s).strip().rstrip('.')
                if len(desc) > 90: desc = desc[:87].rsplit(' ', 1)[0] + '…'
                flows.append({'source': a, 'target': b, 'kind': kind, 'desc': desc}); nodes[a]['sends'] += 1; nodes[b]['recv'] += 1; last = b
                continue
        # no flow: remember the system this sentence is about, for "then it is sent to X" next
        for i, w in enumerate(words):
            p = phrase(words, i, i == 0, seen)
            if p: last = node(p); break
    if len(flows) < 1: raise ValueError('no flows found - write sentences like "The order service sends the order to the warehouse"')
    used = [k for k in order if nodes[k]['sends'] or nodes[k]['recv']]
    left = [k for k in used if nodes[k]['sends'] and not nodes[k]['recv']]
    right = [k for k in used if nodes[k]['recv'] and not nodes[k]['sends']]
    mid = [k for k in used if k not in left and k not in right]
    zones = []; out_nodes = []
    for zid, title_, kind, ks in (('z1', 'Sources', 'dmz', left), ('z2', 'Core systems', 'core', mid), ('z3', 'Consumers', 'down', right)):
        if not ks: continue
        zones.append({'id': zid, 'title': title_, 'kind': kind})
        for k in ks: out_nodes.append({'id': nodes[k]['id'], 'label': nodes[k]['label'], 'sub': '', 'zone': zid, 'state': 'keep'})
    if len(zones) == 1: zones[0].update(title='Systems', kind='core')
    ids = {nodes[k]['id'] for k in used}
    out_flows = []; seen_pairs = set()
    for i, f in enumerate(flows):
        a, b = nodes[f['source']]['id'], nodes[f['target']]['id']
        if a not in ids or b not in ids or (a, b, f['desc']) in seen_pairs: continue
        seen_pairs.add((a, b, f['desc'])); n = len(out_flows) + 1
        out_flows.append({'id': f'F{n}', 'badge': f'{n}.0', 'source': a, 'target': b, 'kind': f['kind'], 'desc': f['desc']})
    t = (title or '').strip() or (out_nodes[0]['label'] + ' → ' + out_nodes[-1]['label'] + ' flow')
    return {'title': t[:70], 'subtitle': 'Drafted from the description (rules, no AI)', 'zones': zones, 'nodes': out_nodes, 'flows': out_flows}


def main():
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter); ap.add_argument('path'); ap.add_argument('--title', default='')
    a = ap.parse_args(); print(json.dumps(draft(open(a.path, encoding='utf-8').read(), a.title), indent=1, ensure_ascii=False))


if __name__ == '__main__': main()
