"""Diagram Icons Library and Resolver for ULTA and SAP BTP Standards.
Provides vector SVG icons embedded as draw.io data URIs, matched by system name, role, and zone.
"""
import urllib.parse

def _svg(content, bg='#0070F2', fg='#FFFFFF', size=24):
    """Wrap path into a 24x24 SVG data URL with a rounded badge."""
    raw = (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="{size}" height="{size}">'
           f'<rect width="24" height="24" rx="5" fill="{bg}"/>'
           f'<g fill="{fg}">{content}</g></svg>')
    return 'data:image/svg+xml;utf8,' + urllib.parse.quote(raw)

# ------------------------------------------------------------- SAP BTP Icons -
# Conforming to SAP BTP Solution Diagrams & Fiori Horizon Standards (SAP Blue #0070F2, Dark Blue #002A86, Green #107E3E)
SAP_SVGS = {
    's4': _svg('<path d="M4 6h10c2.5 0 4.5 1.5 4.5 3.5s-1.8 3.2-3.8 3.5c2.2.4 3.8 1.8 3.8 4.2 0 3-2.2 4.8-5.5 4.8H4V6zm3.5 3v3.5h5c1.2 0 2-.6 2-1.7s-.8-1.8-2-1.8h-5zm0 6.5V20h5.5c1.5 0 2.2-.7 2.2-2s-.7-2-2.2-2h-5.5z"/>', bg='#002A86'),
    'btp': _svg('<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3zm0 2.5L6 9l6 3.5L18 9l-6-3.5zm-6 5.5v5.5l6 3.5V14.5L6 11zm12 0l-6 3.5V20l6-3.5V11z"/>', bg='#0070F2'),
    'integration': _svg('<path d="M4 12a8 8 0 0114.9-4M20 12a8 8 0 01-14.9 4M12 4v4m0 8v4M4 12h4m8 0h4m-8-3a3 3 0 100 6 3 3 0 000-6z" stroke="#FFF" stroke-width="1.8" fill="none"/>', bg='#0070F2'),
    'event': _svg('<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="7" r="2.5"/><circle cx="18" cy="17" r="2.5"/><path d="M8.5 11l7-3m-7 5l7 3" stroke="#FFF" stroke-width="1.8"/>', bg='#107E3E'),
    'hana': _svg('<ellipse cx="12" cy="7" rx="7" ry="2.5"/><path d="M5 7v10c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5V7" stroke="#FFF" stroke-width="1.5" fill="none"/><ellipse cx="12" cy="12" rx="7" ry="2" stroke="#FFF" stroke-width="1" fill="none"/>', bg='#002A86'),
    'build': _svg('<path d="M12 4a8 8 0 100 16 8 8 0 000-16zm-1.5 4.5l5 3.5-5 3.5v-7z"/>', bg='#0070F2'),
    'gateway': _svg('<path d="M6 5h12v3H6V5zm2 5h8v9H8v-9zm-4 4h2v5H4v-5zm14 0h2v5h-2v-5z"/>', bg='#5B738B'),
    'security': _svg('<path d="M12 3L4 6v6c0 5 3.5 9.5 8 10 4.5-.5 8-5 8-10V6l-8-3zm-1 6h2v5h-2V9zm0 6h2v2h-2v-2z"/>', bg='#0070F2'),
    'analytics': _svg('<path d="M5 19h14v2H5v-2zm2-4h2v3H7v-3zm4-7h2v10h-2V8zm4 3h2v7h-2v-7zm-8-5l4-2 4 3 4-3v2l-4 3-4-3-4 2V6z"/>', bg='#0070F2'),
    'cloud': _svg('<path d="M17.5 9A5 5 0 008 10.5 4 4 0 004 14a4 4 0 004 4h9.5a4.5 4.5 0 000-9z"/>', bg='#0070F2'),
}

# ------------------------------------------------------------- ULTA Icons ----
# Conforming to ULTA Beauty Enterprise Diagram Standards (Ulta Orange #E85D04, Teal #07838F, Charcoal #1D2D3E)
ULTA_SVGS = {
    'store': _svg('<path d="M4 10l1-5h14l1 5v8H4v-8zm2-3l-.6 3h13.2l-.6-3H6zm4 6v5h4v-5h-4z"/>', bg='#E85D04'),
    'mobile': _svg('<rect x="6" y="3" width="12" height="18" rx="3" stroke="#FFF" stroke-width="1.5" fill="none"/><circle cx="12" cy="18" r="1"/><path d="M9 6h6" stroke="#FFF" stroke-width="1.2"/>', bg='#E85D04'),
    'oms': _svg('<path d="M6 3h8l4 4v14H6V3zm7 1v4h4M9 13l2 2 4-4" stroke="#FFF" stroke-width="1.5" fill="none"/>', bg='#07838F'),
    'wms': _svg('<path d="M3 8l9-5 9 5v12H3V8zm9-2.5L5.5 9 12 12.5 18.5 9 12 5.5zM6 13h4v5H6v-5zm8 0h4v5h-4v-5z"/>', bg='#07838F'),
    'supply': _svg('<path d="M3 6h11v9H3V6zm11 3h4l3 3v3h-7V9zm-9 9a2 2 0 100-4 2 2 0 000 4zm11 0a2 2 0 100-4 2 2 0 000 4z"/>', bg='#07838F'),
    'erp': _svg('<rect x="4" y="4" width="16" height="5" rx="1"/><rect x="4" y="10" width="16" height="5" rx="1"/><rect x="4" y="16" width="16" height="5" rx="1"/><circle cx="7" cy="6.5" r="1" fill="#E85D04"/><circle cx="7" cy="12.5" r="1" fill="#E85D04"/><circle cx="7" cy="18.5" r="1" fill="#E85D04"/>', bg='#1D2D3E'),
    'integration': _svg('<path d="M7 7h4v2H7V7zm6 8h4v2h-4v-2zm-2-4h2v2h-2v-2zM4 12a8 8 0 1016 0 8 8 0 00-16 0z" stroke="#FFF" stroke-width="1.5" fill="none"/>', bg='#E85D04'),
    'kafka': _svg('<circle cx="6" cy="12" r="2.5"/><circle cx="18" cy="7" r="2.5"/><circle cx="18" cy="17" r="2.5"/><path d="M8.5 11l7-3m-7 5l7 3" stroke="#FFF" stroke-width="1.8"/>', bg='#E85D04'),
    'db': _svg('<ellipse cx="12" cy="7" rx="7" ry="2.5"/><path d="M5 7v10c0 1.4 3.1 2.5 7 2.5s7-1.1 7-2.5V7" stroke="#FFF" stroke-width="1.5" fill="none"/><ellipse cx="12" cy="12" rx="7" ry="2" stroke="#FFF" stroke-width="1" fill="none"/>', bg='#1D2D3E'),
    'security': _svg('<path d="M12 3L4 6v6c0 5 3.5 9.5 8 10 4.5-.5 8-5 8-10V6l-8-3zm-1 6h2v5h-2V9zm0 6h2v2h-2v-2z"/>', bg='#07838F'),
    'analytics': _svg('<path d="M4 19h16v2H4v-2zm2-4h3v3H6v-3zm5-6h3v9h-3V9zm5 3h3v6h-3v-6z"/>', bg='#E85D04'),
    'loyalty': _svg('<path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>', bg='#E85D04'),
    'cloud': _svg('<path d="M17.5 9A5 5 0 008 10.5 4 4 0 004 14a4 4 0 004 4h9.5a4.5 4.5 0 000-9z"/>', bg='#07838F'),
}


def resolve_icon(name, sub='', zone='saas', theme='ulta'):
    """Resolve an appropriate SVG icon URL based on node label, subtitle, zone and theme."""
    txt = f"{name} {sub}".lower()
    
    if theme == 'sap':
        # SAP BTP domain matching
        if any(w in txt for w in ('s4', 's/4', 's4hana', 'erp', 'ecc')):
            return SAP_SVGS['s4']
        if any(w in txt for w in ('integration', 'cpi', 'api', 'gateway', 'middleware', 'bods')):
            return SAP_SVGS['integration']
        if any(w in txt for w in ('event', 'broker', 'mesh', 'kafka', 'queue', 'pubsub', 'jms')):
            return SAP_SVGS['event']
        if any(w in txt for w in ('hana', 'database', 'db', 'sql', 'datalake', 'store')):
            return SAP_SVGS['hana']
        if any(w in txt for w in ('build', 'work zone', 'workflow', 'process', 'automation')):
            return SAP_SVGS['build']
        if any(w in txt for w in ('analytics', 'sac', 'bi', 'reporting', 'dashboard')):
            return SAP_SVGS['analytics']
        if any(w in txt for w in ('security', 'identity', 'ias', 'ips', 'auth', 'iam', 'keystore')):
            return SAP_SVGS['security']
        if any(w in txt for w in ('cloud connector', 'onprem', 'on-prem')):
            return SAP_SVGS['gateway']
        if 'btp' in txt or zone == 'saas':
            return SAP_SVGS['btp']
        return SAP_SVGS['cloud']
    
    # ULTA Enterprise domain matching
    if any(w in txt for w in ('tiktok', 'mobile', 'app', 'web', 'ecom', 'digital', 'storefront')):
        return ULTA_SVGS['mobile']
    if any(w in txt for w in ('store', 'pos', 'kiosk', 'boutique', 'salon')):
        return ULTA_SVGS['store']
    if any(w in txt for w in ('oms', 'sterling', 'order', 'checkout')):
        return ULTA_SVGS['oms']
    if any(w in txt for w in ('wms', 'manhattan', 'warehouse', 'dc', 'fulfillment', 'pick')):
        return ULTA_SVGS['wms']
    if any(w in txt for w in ('allocation', 'replenishment', 'by ', 'jda', 'swift', 'truck', 'logistic')):
        return ULTA_SVGS['supply']
    if any(w in txt for w in ('s4', 's/4', 'sap', 'erp', 'ecc', 'core')):
        return ULTA_SVGS['erp']
    if any(w in txt for w in ('kafka', 'event', 'queue', 'stream', 'mq')):
        return ULTA_SVGS['kafka']
    if any(w in txt for w in ('integration', 'bods', 'api', 'gateway', 'middleware', 'mule')):
        return ULTA_SVGS['integration']
    if any(w in txt for w in ('database', 'db', 'snowflake', 'databricks', 'lake', 'hana')):
        return ULTA_SVGS['db']
    if any(w in txt for w in ('analytics', 'power bi', 'reporting', 'dashboard', 'bi')):
        return ULTA_SVGS['analytics']
    if any(w in txt for w in ('loyalty', 'reward', 'crm', 'guest', 'member')):
        return ULTA_SVGS['loyalty']
    if any(w in txt for w in ('security', 'auth', 'idp', 'okta', 'entra', 'iam')):
        return ULTA_SVGS['security']
    if zone == 'dmz':
        return ULTA_SVGS['mobile']
    if zone == 'core':
        return ULTA_SVGS['erp']
    return ULTA_SVGS['cloud']
