"""
enterprise-diagram-standards - deterministic router + geometry auditor.
Reference implementation for SKILL v0.7.0, Step 8.

Contract:
  * Every edge declares its FULL orthogonal corner list. Nothing is left to
    draw.io auto-routing, so every segment is known before the XML is written.
  * The auditor runs on that geometry. If any check fails, emit() raises and
    no file is produced.
"""
from xml.sax.saxutils import escape as _esc

def escape(s):
    return _esc(s, {'"': '&quot;'})

LANE_SEP      = 20   # min centreline separation between parallel connectors
SHAPE_CLEAR   = 15   # min clearance from an unrelated shape
BADGE_W, BADGE_H = 30, 18

# ---------------------------------------------------------------- styles ----
CYL = 'shape=cylinder3d;boundedLbl=1;backgroundOutline=1;size=15;'
SIDE = {'L':(0.0,None),'R':(1.0,None),'T':(None,0.0),'B':(None,1.0)}

THEMES = {
    'ulta': {
        'name': 'ULTA Beauty Enterprise Architecture Standard',
        'title_color': '#E85D04',
        'subtitle_color': '#737373',
        'meta_color': '#999999',
        'zone_stroke': {'dmz': '#07838F', 'saas': '#0070F2', 'core': '#5D36FF', 'down': '#188918'},
        'zone_fill': {'dmz': 'none', 'saas': 'none', 'core': 'none', 'down': 'none'},
        'zone_arc': 8,
        'state': {
            'keep':    'rounded=1;whiteSpace=wrap;html=1;fillColor=#F0FAF4;strokeColor=#2d7d52;strokeWidth=2;fontSize=10;fontStyle=1;fontColor=#303030;arcSize=8;',
            'changed': 'rounded=1;whiteSpace=wrap;html=1;fillColor=#FDFBF0;strokeColor=#bfa128;strokeWidth=2;fontSize=10;fontStyle=1;fontColor=#303030;arcSize=8;',
            'new':     'rounded=1;whiteSpace=wrap;html=1;fillColor=#EBF5FF;strokeColor=#0061a6;strokeWidth=2;fontSize=10;fontStyle=1;fontColor=#303030;arcSize=8;',
            'retire':  'rounded=1;whiteSpace=wrap;html=1;fillColor=#F5F5F5;strokeColor=#737373;strokeWidth=2;fontSize=10;fontStyle=1;fontColor=#737373;arcSize=8;dashed=1;',
            'future':  'rounded=1;whiteSpace=wrap;html=1;fillColor=#F9F0F9;strokeColor=#700470;strokeWidth=2;fontSize=10;fontStyle=1;fontColor=#303030;arcSize=8;dashed=1;',
        },
        'edge': {
            'sync':   ('#E85D04', 'edgeStyle=orthogonalEdgeStyle;rounded=1;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#E85D04;strokeWidth=2.5;endArrow=block;endFill=1;'),
            'async':  ('#F77F00', 'edgeStyle=orthogonalEdgeStyle;rounded=1;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#F77F00;strokeWidth=2;dashed=1;dashPattern=8 4;endArrow=block;endFill=1;'),
            'opt':    ('#FFBA08', 'edgeStyle=orthogonalEdgeStyle;rounded=1;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#FFBA08;strokeWidth=1.5;dashed=1;dashPattern=1 3;endArrow=open;endSize=6;endFill=0;'),
            'reject': ('#D00000', 'edgeStyle=orthogonalEdgeStyle;rounded=1;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#D00000;strokeWidth=2;endArrow=block;endFill=1;'),
        },
        'kind_html': {'sync': '#E85D04', 'async': '#F77F00', 'opt': '#B8860B', 'reject': '#D00000'},
        'legend_border': '#737373',
        'legend_bg': '#FAFAFA',
        'legend_head_bg': '#F5F5F5',
        'table_head_border': '#737373'
    },
    'sap': {
        'name': 'SAP BTP Solution Diagram Standard',
        'title_color': '#0070F2',
        'subtitle_color': '#5B738B',
        'meta_color': '#6A7D8F',
        'zone_stroke': {'dmz': '#0070F2', 'saas': '#0070F2', 'core': '#002A86', 'down': '#1D2D3E'},
        'zone_fill': {'dmz': '#F5FAFF', 'saas': '#F5FAFF', 'core': '#F0F4FA', 'down': '#F8F9FA'},
        'zone_arc': 16,
        'state': {
            'keep':    'rounded=1;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#0070F2;strokeWidth=1.5;fontSize=10;fontStyle=1;fontColor=#1D2D3E;arcSize=12;',
            'changed': 'rounded=1;whiteSpace=wrap;html=1;fillColor=#FFF8E6;strokeColor=#E76500;strokeWidth=2;fontSize=10;fontStyle=1;fontColor=#1D2D3E;arcSize=12;',
            'new':     'rounded=1;whiteSpace=wrap;html=1;fillColor=#EBF8FF;strokeColor=#0070F2;strokeWidth=2;fontSize=10;fontStyle=1;fontColor=#0040B0;arcSize=12;',
            'retire':  'rounded=1;whiteSpace=wrap;html=1;fillColor=#F5F6F7;strokeColor=#8996A3;strokeWidth=1.5;fontSize=10;fontStyle=1;fontColor=#6A7D8F;arcSize=12;dashed=1;',
            'future':  'rounded=1;whiteSpace=wrap;html=1;fillColor=#F6F2FC;strokeColor=#7828C8;strokeWidth=1.5;fontSize=10;fontStyle=1;fontColor=#1D2D3E;arcSize=12;dashed=1;',
        },
        'edge': {
            'sync':   ('#0070F2', 'edgeStyle=orthogonalEdgeStyle;rounded=1;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#0070F2;strokeWidth=2.5;endArrow=block;endFill=1;'),
            'async':  ('#107E3E', 'edgeStyle=orthogonalEdgeStyle;rounded=1;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#107E3E;strokeWidth=2;dashed=1;dashPattern=8 4;endArrow=block;endFill=1;'),
            'opt':    ('#E76500', 'edgeStyle=orthogonalEdgeStyle;rounded=1;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#E76500;strokeWidth=1.5;dashed=1;dashPattern=2 3;endArrow=open;endSize=6;endFill=0;'),
            'reject': ('#BB0000', 'edgeStyle=orthogonalEdgeStyle;rounded=1;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#BB0000;strokeWidth=2;endArrow=block;endFill=1;'),
        },
        'kind_html': {'sync': '#0070F2', 'async': '#107E3E', 'opt': '#E76500', 'reject': '#BB0000'},
        'legend_border': '#0070F2',
        'legend_bg': '#F8FBFE',
        'legend_head_bg': '#EBF8FF',
        'table_head_border': '#0070F2'
    },
    'cloud': {   # the cloud architecture-guide look: flat pastel zones, white square cards, thin blue orthogonal lines
        'name': 'Cloud reference architecture',
        'title_color': '#202124', 'subtitle_color': '#5F6368', 'meta_color': '#80868B',
        'zone_stroke': {'dmz': '#FCE8E6', 'saas': '#FFF8E1', 'core': '#E3F2FD', 'down': '#E6F4EA'},
        'zone_fill': {'dmz': '#FCE8E6', 'saas': '#FFF8E1', 'core': '#E3F2FD', 'down': '#E6F4EA'},
        'zone_arc': 0, 'zone_font': 'fontSize=12;fontStyle=0;fontColor=#757575;', 'sub_color': '#5F6368',
        'state': {
            'keep':    'rounded=0;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#BDBDBD;strokeWidth=1;fontSize=10;fontStyle=0;fontColor=#202124;',
            'changed': 'rounded=0;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#F9AB00;strokeWidth=1.5;fontSize=10;fontStyle=0;fontColor=#202124;',
            'new':     'rounded=0;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#4285F4;strokeWidth=1.5;fontSize=10;fontStyle=0;fontColor=#202124;',
            'retire':  'rounded=0;whiteSpace=wrap;html=1;fillColor=#F8F9FA;strokeColor=#BDBDBD;strokeWidth=1;fontSize=10;fontStyle=0;fontColor=#80868B;dashed=1;',
            'future':  'rounded=0;whiteSpace=wrap;html=1;fillColor=#FFFFFF;strokeColor=#A142F4;strokeWidth=1.5;fontSize=10;fontStyle=0;fontColor=#202124;dashed=1;',
        },
        'edge': {
            'sync':   ('#4285F4', 'edgeStyle=orthogonalEdgeStyle;rounded=0;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#4285F4;strokeWidth=1.5;endArrow=block;endFill=1;endSize=5;fontColor=#1A73E8;'),
            'async':  ('#4285F4', 'edgeStyle=orthogonalEdgeStyle;rounded=0;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#4285F4;strokeWidth=1.5;dashed=1;dashPattern=6 4;endArrow=block;endFill=1;endSize=5;fontColor=#1A73E8;'),
            'opt':    ('#8AB4F8', 'edgeStyle=orthogonalEdgeStyle;rounded=0;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#8AB4F8;strokeWidth=1.2;dashed=1;dashPattern=1 3;endArrow=open;endSize=5;endFill=0;fontColor=#1A73E8;'),
            'reject': ('#EA4335', 'edgeStyle=orthogonalEdgeStyle;rounded=0;jumpStyle=arc;jumpSize=6;html=1;strokeColor=#EA4335;strokeWidth=1.5;endArrow=block;endFill=1;endSize=5;'),
        },
        'kind_html': {'sync': '#1A73E8', 'async': '#1A73E8', 'opt': '#5F6368', 'reject': '#EA4335'},
        'legend_border': '#DADCE0', 'legend_bg': '#FFFFFF', 'legend_head_bg': '#F1F3F4', 'table_head_border': '#DADCE0'
    }
}

STATE = THEMES['ulta']['state']
EDGE = THEMES['ulta']['edge']
ZONE = THEMES['ulta']['zone_stroke']


class Diagram:
    def __init__(self, name, page_w, page_h, theme='ulta'):
        self.name, self.pw, self.ph = name, page_w, page_h
        self.theme_name = 'ulta'                      # the ULTA Enterprise Diagram Standards only (zero deviation)
        self.theme = THEMES[self.theme_name]
        self.zones, self.nodes, self.edges, self.extras = [], {}, [], []
        self.reserved = []          # rects connectors must not enter (legends, title)

    # ------------------------------------------------------------ content --
    def zone(self, zid, title, x, y, w, h, kind):
        sw = 2.5 if kind == 'core' else 2
        col = self.theme['zone_stroke'].get(kind, '#737373')
        fill = self.theme['zone_fill'].get(kind, 'none')
        arc = self.theme.get('zone_arc', 8)
        self.zones.append((zid, title, x, y, w, h,
            f'shape=swimlane;horizontal=1;startSize=24;html=1;whiteSpace=wrap;fillColor={fill};swimlaneFillColor={fill};'
            f'strokeColor={col};strokeWidth={sw};' + self.theme.get('zone_font', 'fontSize=12;fontStyle=1;fontColor=#303030;') + f'arcSize={arc};' + ('rounded=0;align=left;spacingLeft=8;' if not arc else '')))

    def node(self, nid, main, sub, state, x, y, w, h, cylinder=False, icon_url=None):
        st_style = self.theme['state'].get(state, self.theme['state']['keep'])
        node_style = st_style
        if icon_url:
            node_style = node_style.rstrip(';') + ';spacingLeft=30;align=left;'
        style = (CYL + node_style) if cylinder else node_style
        sub_col = self.theme.get('sub_color') or ('#5B738B' if self.theme_name == 'sap' else '#737373')
        label = f'{main}<br><span style="font-weight:normal;font-size:9px;color:{sub_col};">{sub}</span>'
        self.nodes[nid] = dict(x=x, y=y, w=w, h=h, style=style, label=label, name=main, icon_url=icon_url)

    def reserve(self, x, y, w, h):
        self.reserved.append((x, y, w, h))

    def text(self, tid, x, y, w, h, value, style):
        self.extras.append((tid, x, y, w, h, value, style))

    # ------------------------------------------------------------- routing --
    def _anchor(self, nid, side, frac):
        n = self.nodes[nid]
        if side == 'L': return (n['x'],            n['y'] + frac * n['h'])
        if side == 'R': return (n['x'] + n['w'],   n['y'] + frac * n['h'])
        if side == 'T': return (n['x'] + frac*n['w'], n['y'])
        return               (n['x'] + frac*n['w'], n['y'] + n['h'])

    def edge(self, badge, src, exit_, tgt, entry, kind, corners=(), desc='', label='', text=None, both=False):
        """corners = ordered list of intermediate (x, y) turning points.
        Path = exit anchor -> corners -> entry anchor, and every consecutive
        pair MUST be axis-aligned. No implicit routing is permitted."""
        p0 = self._anchor(src, *exit_)
        p1 = self._anchor(tgt, *entry)
        pts = [p0] + [tuple(map(float, c)) for c in corners] + [p1]
        for a, b in zip(pts, pts[1:]):
            if abs(a[0]-b[0]) > .01 and abs(a[1]-b[1]) > .01:
                raise ValueError(f'edge {badge}: non-orthogonal hop {a}->{b}')
        shown = text or badge   # a bundled line carries every step it stands for: "4.0 · 6.0 · 7.0", "3.1 ⇄ 4.1"
        self.edges.append(dict(badge=badge, src=src, tgt=tgt, kind=kind, pts=pts, text=shown, both=both, bw=max(BADGE_W, int(6.2 * len(shown) + 12)),
                               corners=list(corners), exit=exit_, entry=entry,
                               desc=desc, label=label or f'{self.nodes[src]["name"]} → {self.nodes[tgt]["name"]}'))

    # ------------------------------------------------------------- geometry -
    @staticmethod
    def _segs(e):
        out = []
        for a, b in zip(e['pts'], e['pts'][1:]):
            if a == b: continue
            out.append(('H' if abs(a[1]-b[1]) < .01 else 'V', a, b))
        return out

    @staticmethod
    def _rect_hit(seg, r, pad=0):
        _, (x1, y1), (x2, y2) = seg
        rx, ry, rw, rh = r
        return (min(x1,x2) < rx+rw+pad and max(x1,x2) > rx-pad
            and min(y1,y2) < ry+rh+pad and max(y1,y2) > ry-pad)

    def _point_at(self, e, f):
        pts = e['pts']
        L = [abs(a[0]-b[0]) + abs(a[1]-b[1]) for a, b in zip(pts, pts[1:])]
        tot = sum(L); want = tot * f; run = 0
        for (a, b), l in zip(zip(pts, pts[1:]), L):
            if run + l >= want or (a, b) == (pts[-2], pts[-1]):
                t = 0 if l == 0 else (want - run) / l
                return (a[0] + (b[0]-a[0])*t, a[1] + (b[1]-a[1])*t)
            run += l
        return pts[-1]

    def place_badges(self):
        """Pick, per edge, the first position along its own path where the badge
        rect touches no shape, no reserved block, no other edge, no other badge."""
        placed = []
        cands = [.5,.42,.58,.34,.66,.26,.74,.20,.80,.15,.85,.10,.90,.46,.54,.38,.62,.30,.70]
        order = sorted(self.edges, key=lambda e: e['badge'])
        for e in order:
            for f in cands:
                cx, cy = self._point_at(e, f)
                bw = e.get('bw', BADGE_W); r = (cx-bw/2, cy-BADGE_H/2, bw, BADGE_H)
                if any(self._rect_hit(('H',(r[0],r[1]),(r[0]+r[2],r[1]+r[3])), (n['x'],n['y'],n['w'],n['h']), 2)
                       for n in self.nodes.values()): continue
                if any(self._rect_hit(('H',(r[0],r[1]),(r[0]+r[2],r[1]+r[3])), rr, 2) for rr in self.reserved): continue
                if any(self._rect_hit(s, r, 1) for o in self.edges if o is not e for s in self._segs(o)): continue
                if any(not (r[0]+r[2]+6 < q[0] or q[0]+q[2]+6 < r[0] or
                            r[1]+r[3]+6 < q[1] or q[1]+q[3]+6 < r[1]) for q in placed): continue
                e['f'] = f; e['badge_rect'] = r; placed.append(r); break
            else:
                raise RuntimeError(f'edge {e["badge"]}: no collision-free badge position')

    # ---------------------------------------------------------------- audit -
    def audit(self):
        errs = []
        E = self.edges
        # 1 parallel overlap / insufficient lane separation
        for i, a in enumerate(E):
            for b in E[i+1:]:
                for o1, p1, q1 in self._segs(a):
                    for o2, p2, q2 in self._segs(b):
                        if o1 != o2: continue
                        if o1 == 'H':
                            fix1, fix2 = p1[1], p2[1]
                            lo1, hi1 = sorted((p1[0], q1[0])); lo2, hi2 = sorted((p2[0], q2[0]))
                        else:
                            fix1, fix2 = p1[0], p2[0]
                            lo1, hi1 = sorted((p1[1], q1[1])); lo2, hi2 = sorted((p2[1], q2[1]))
                        ov = min(hi1, hi2) - max(lo1, lo2)
                        if ov <= 0: continue
                        d = abs(fix1 - fix2)
                        if d < LANE_SEP - .01:
                            kind = 'SHARED SEGMENT' if d < .01 else f'lanes only {d:.0f}px apart'
                            errs.append(f'[overlap] {a["badge"]} vs {b["badge"]}: {o1} {kind} (overlap {ov:.0f}px)')
        # 2 connector through an unrelated shape
        for e in E:
            for s in self._segs(e):
                for nid, n in self.nodes.items():
                    if nid in (e['src'], e['tgt']): continue
                    if self._rect_hit(s, (n['x'], n['y'], n['w'], n['h']), SHAPE_CLEAR):
                        thru = self._rect_hit(s, (n['x'], n['y'], n['w'], n['h']), 0)
                        errs.append(f'[clearance] {e["badge"]} {"crosses" if thru else "runs <15px from"} {n["name"]}')
                for r in self.reserved:
                    if self._rect_hit(s, r, 0):
                        errs.append(f'[reserved] {e["badge"]} enters a reserved block {r}')
        # 3 crossings (reported, not fatal - must be line-hopped)
        cross = 0
        for i, a in enumerate(E):
            for b in E[i+1:]:
                for o1, p1, q1 in self._segs(a):
                    for o2, p2, q2 in self._segs(b):
                        if o1 == o2: continue
                        h, v = ((p1, q1), (p2, q2)) if o1 == 'H' else ((p2, q2), (p1, q1))
                        hy = h[0][1]; hx = sorted((h[0][0], h[1][0]))
                        vx = v[0][0]; vy = sorted((v[0][1], v[1][1]))
                        if hx[0] < vx < hx[1] and vy[0] < hy < vy[1]: cross += 1
        # 4 duplicate / non-unique badges
        bs = [e['badge'] for e in E]
        if len(bs) != len(set(bs)): errs.append('[badge] duplicate badge numbers')
        # 5 duplicate anchors on a shared port
        seen = {}
        for e in E:
            for nid, a in ((e['src'], e['exit']), (e['tgt'], e['entry'])):
                pt = self._anchor(nid, *a)
                if pt in seen and seen[pt] != e['badge']:
                    errs.append(f'[anchor] {e["badge"]} and {seen[pt]} share port {pt} on {self.nodes[nid]["name"]}')
                seen[pt] = e['badge']
        # 6 badge placement
        for e in E:
            if 'badge_rect' not in e: errs.append(f'[badge] {e["badge"]} unplaced')
        return errs, cross

    # ----------------------------------------------------------------- emit -
    def emit(self, path, subtitle, created, modified, legend_rows_html, state_legend, flow_legend_geom):
        self.place_badges()
        errs, cross = self.audit()
        print(f'audit: {len(self.edges)} connectors, {cross} discrete crossing(s), {len(errs)} violation(s)')
        for x in errs: print('   ', x)
        if errs: raise SystemExit('AUDIT FAILED - diagram not written')
        o = ['<?xml version="1.0" encoding="UTF-8"?>',
             f'<mxfile host="app.diagrams.net" type="device" agent="enterprise-diagram-standards-v0.7.0">',
             f'  <diagram id="d1" name="{escape(self.name)}">',
             f'    <mxGraphModel dx="1650" dy="1450" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" '
             f'arrows="1" fold="1" page="1" pageScale="1" pageWidth="{self.pw}" pageHeight="{self.ph}">',
             '      <root><mxCell id="0"/><mxCell id="1" parent="0"/>']
        def cell(i, v, st, x, y, w, h):
            o.append(f'        <mxCell id="{i}" value="{escape(v)}" style="{st}" vertex="1" parent="1">'
                     f'<mxGeometry x="{x}" y="{y}" width="{w}" height="{h}" as="geometry"/></mxCell>')
        cell('t1', self.name, f'text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;spacingLeft=4;spacingRight=4;overflow=hidden;rotatable=0;fontSize=18;fontStyle=1;fontColor={self.theme["title_color"]};', 50, 15, 700, 30)
        cell('t2', subtitle, f'text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;spacingLeft=4;overflow=hidden;rotatable=0;fontSize=10;fontStyle=0;fontColor={self.theme["subtitle_color"]};', 54, 48, 800, 20)
        cell('t3', f'Created: {created}  |  Last Modified: {modified}', f'text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;spacingLeft=4;overflow=hidden;rotatable=0;fontSize=9;fontStyle=2;fontColor={self.theme["meta_color"]};', 54, 66, 400, 18)
        for zid, ti, x, y, w, h, st in self.zones: cell(zid, ti, st, x, y, w, h)
        for nid, n in self.nodes.items():
            cell(nid, n['label'], n['style'], n['x'], n['y'], n['w'], n['h'])
            if n.get('icon_url'):
                icon_x = int(n['x'] + 8)
                icon_y = int(n['y'] + (n['h'] - 24) / 2)
                icon_st = f'shape=image;imageAspect=0;aspect=fixed;image={n["icon_url"]};pointerEvents=0;'
                o.append(f'        <mxCell id="{nid}_ico" value="" style="{icon_st}" vertex="1" parent="1">'
                         f'<mxGeometry x="{icon_x}" y="{icon_y}" width="24" height="24" as="geometry"/></mxCell>')
        for tid, x, y, w, h, v, st in self.extras: cell(tid, v, st, x, y, w, h)
        for e in self.edges:
            col, base = self.theme['edge'][e['kind']]
            ex, ey = SIDE[e['exit'][0]]; en, eny = SIDE[e['entry'][0]]
            ax = e['exit'][1] if ex is None else ex;  ay = e['exit'][1] if ex is not None else SIDE[e['exit'][0]][1]
            def anc(side, frac):
                return {'L':(0,frac),'R':(1,frac),'T':(frac,0),'B':(frac,1)}[side]
            sx, sy = anc(*e['exit']); tx, ty = anc(*e['entry'])
            st = (base + f'labelBackgroundColor=#FFFFFF;fontSize=9;fontStyle=1;labelBorderColor={col};labelPadding=3;'
                  f'exitX={sx};exitY={sy};exitDx=0;exitDy=0;entryX={tx};entryY={ty};entryDx=0;entryDy=0;')
            pts = ''.join(f'<mxPoint x="{c[0]}" y="{c[1]}"/>' for c in e['corners'])
            arr = f'<Array as="points">{pts}</Array>' if pts else ''
            if e.get('both'): st += 'startArrow=block;startFill=1;'   # one line for a two-way pair
            o.append(f'        <mxCell id="e{e["badge"].replace(".","_")}" value="{escape(e.get("text") or e["badge"])}" style="{st}" '
                     f'edge="1" parent="1" source="{e["src"]}" target="{e["tgt"]}">'
                     f'<mxGeometry relative="1" x="{round(2*e["f"]-1,4)}" y="0" as="geometry">{arr}</mxGeometry></mxCell>')
        o.append(state_legend)
        gx, gy, gw, gh, tw, th = flow_legend_geom
        o.append(f'        <mxCell id="fl" value="Flow Legend" style="shape=swimlane;horizontal=1;startSize=28;html=1;'
                 f'whiteSpace=wrap;fillColor={self.theme["legend_bg"]};strokeColor={self.theme["legend_border"]};strokeWidth=1.5;fontSize=13;fontStyle=1;'
                 f'fontColor=#303030;arcSize={self.theme.get("zone_arc",8)};" vertex="1" parent="1"><mxGeometry x="{gx}" y="{gy}" width="{gw}" height="{gh}" as="geometry"/></mxCell>')
        o.append(f'        <mxCell id="flt" value="{escape(legend_rows_html)}" style="text;html=1;strokeColor=none;'
                 f'fillColor=none;align=left;verticalAlign=top;spacingLeft=8;spacingTop=4;whiteSpace=wrap;overflow=auto;'
                 f'fontSize=10;fontColor=#303030;" vertex="1" parent="fl">'
                 f'<mxGeometry x="20" y="35" width="{tw}" height="{th}" as="geometry"/></mxCell>')   # inside the Flow Legend box: it moves and resizes with it
        o += ['      </root>', '    </mxGraphModel>', '  </diagram>', '</mxfile>', '']
        open(path, 'w').write('\n'.join(o))
        print(f'written: {path}')
