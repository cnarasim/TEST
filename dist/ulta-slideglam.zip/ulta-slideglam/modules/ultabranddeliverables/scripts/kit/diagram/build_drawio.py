#!/usr/bin/env python3
"""Deterministic draw.io builder: architecture JSON -> zone/gutter/ring layout -> ULTA v0.7.0 router audit -> .drawio.
No coordinates are chosen by hand; the layout follows the standard's formulas and the router refuses to write on any violation.

  build_drawio.py arch.json --out diagram.drawio [--wrap evidence-input.json]   (wrap = ultaarchbuilder contract metadata)

arch.json
{
  "title": "ULTA Beauty - Supply Protection Process",
  "subtitle": "C2 Container View | Order Management Platform | Current State",
  "created": "2026-09-13",                       # optional; default today. modified = today
  "zones": [{"id": "z1", "title": "Planning Systems", "kind": "dmz|saas|core|down"}, ...],   # left -> right order
  "nodes": [{"id": "swift", "label": "SWIFT", "sub": "Replenishment Planning", "zone": "z1",
             "state": "keep|changed|new|retire|future", "shape": "rect|cylinder"}, ...],       # top -> bottom order within a zone
  "flows": [{"id": "F1", "badge": "1.0", "source": "swift", "target": "bods", "kind": "sync|async|opt|reject",
             "desc": "Supply protection parameters from replenishment planning"}, ...]
}
Layout rules implemented (Steps 5, 7, 8 of the standard): shapes in zone columns with >= 40 px inset; connectors only in
gutters (width >= 20*(fan+1)+40), the top corridor (forward hops over >1 zone), the bottom return ring (reverse flows)
and zone-local risers (same-zone non-adjacent); ports staggered >= 20 px with node height grown to fit; fan-out lanes
nested (shortest travel outermost); lane order per gutter searched to remove overlaps/crossings; badges by candidate scan.
"""
import argparse, datetime, itertools, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
from drawio_router import Diagram, THEMES, escape  # noqa: E402
from icons import resolve_icon  # noqa: E402

LANE = 20; NODE_W = 140; NODE_H = 60; INSET = 40; ROW_GAP = 40; ZONE_HDR = 24
PAGE_L = 50; TITLE_H = 90; CORRIDOR_TOP = 30
STATE_NAMES = [('keep', 'Existing / Keep'), ('changed', 'Modified / Changed'), ('new', 'New / Introduced'),
               ('retire', 'Retire / Deprecate'), ('future', 'Future State')]
KIND_NAMES = [('sync', 'Sync API'), ('async', 'Async Batch'), ('opt', 'Optional / Conditional'), ('reject', 'Rejection / Rollback')]
KIND_HTML = {'sync': '#E85D04', 'async': '#F77F00', 'opt': '#B8860B', 'reject': '#D00000'}


def badge_key(b):
    return tuple(int(x) if x.isdigit() else x for x in str(b).replace('.', ' ').split())


class Layout:
    def __init__(self, spec):
        self.spec = spec
        self.zones = spec['zones']; self.zi = {z['id']: i for i, z in enumerate(self.zones)}
        self.nodes = {n['id']: dict(n) for n in spec['nodes']}
        self.flows = sorted(spec['flows'], key=lambda f: badge_key(f['badge']))
        for f in self.flows:
            for k in ('source', 'target'):
                if f[k] not in self.nodes: sys.exit(f'flow {f["badge"]}: unknown node {f[k]}')
        self.by_zone = {z['id']: [self.nodes[n['id']] for n in spec['nodes'] if n['zone'] == z['id']] for z in self.zones}
        for n in spec['nodes']:
            if n['zone'] not in self.zi: sys.exit(f'node {n["id"]}: unknown zone {n["zone"]}')

    # ---------------------------------------------------------------- classify
    def classify(self):
        """Decide each flow's route class and which gutters / corridor / ring it uses."""
        for f in self.flows:
            a, b = self.nodes[f['source']], self.nodes[f['target']]
            za, zb = self.zi[a['zone']], self.zi[b['zone']]
            if za == zb:
                ra = self.by_zone[a['zone']].index(a); rb = self.by_zone[b['zone']].index(b)
                f['cls'] = 'down' if rb == ra + 1 else 'up' if rb == ra - 1 else 'riser'
                f['gutters'] = []
            elif zb == za + 1:
                f['cls'] = 'fwd'; f['gutters'] = [za]
            elif zb > za + 1:
                f['cls'] = 'corridor'; f['gutters'] = [za, zb - 1]
            elif zb == za - 1 and not self.spec.get('return_ring'):
                f['cls'] = 'back'; f['gutters'] = [zb]   # to the neighbour on the left: through the gap between them (no loop round the bottom)
            else:
                f['cls'] = 'reverse'; f['gutters'] = [za] if za < len(self.zones) - 1 else [za - 1]
        # port demand per node side
        for n in self.nodes.values():
            n['ports'] = {'L': [], 'R': [], 'T': [], 'B': []}
        for f in self.flows:
            s, t = f['source'], f['target']
            if f['cls'] in ('fwd', 'corridor'):
                f['exit_side'], f['entry_side'] = 'R', 'L'
            elif f['cls'] == 'back':
                f['exit_side'], f['entry_side'] = 'L', 'R'
            elif f['cls'] == 'reverse':
                last = self.zi[self.nodes[s]['zone']] == len(self.zones) - 1
                f['exit_side'] = 'L' if last else 'R'; f['entry_side'] = 'L'
            elif f['cls'] == 'down':
                f['exit_side'], f['entry_side'] = 'B', 'T'
            elif f['cls'] == 'up':
                f['exit_side'], f['entry_side'] = 'T', 'B'
            else:
                f['exit_side'], f['entry_side'] = 'L', 'L'
            self.nodes[s]['ports'][f['exit_side']].append(f)
            self.nodes[t]['ports'][f['entry_side']].append(f)

    # ---------------------------------------------------------------- geometry
    def place(self, gutter_extra=0, corridor_lanes_extra=0):
        Z = self.zones
        # node sizes from port demand
        for n in self.nodes.values():
            need = max(len(n['ports']['L']), len(n['ports']['R']))
            n['w'] = NODE_W; n['h'] = max(NODE_H, LANE * (need + 1))
            if n.get('shape') == 'cylinder': n['h'] = max(80, n['h'])
        # risers per zone (same-zone non-adjacent flows) widen the left inset
        self.riser_lanes = {z['id']: [f for f in self.flows if f['cls'] == 'riser' and self.nodes[f['source']]['zone'] == z['id']] for z in Z}
        # reverse flows entering a zone also use its left riser area
        for f in self.flows:
            if f['cls'] == 'reverse':
                self.riser_lanes[self.nodes[f['target']]['zone']].append(f)
        # gutter widths
        self.gutter_edges = [[f for f in self.flows if g in f['gutters']] for g in range(len(Z) - 1)]
        self.gutter_w = [max(LANE * (len(es) + 1) + 40, 60) + gutter_extra for es in self.gutter_edges]
        # corridor lanes (top) and ring lanes (bottom)
        self.corridor = [f for f in self.flows if f['cls'] == 'corridor']
        self.ring = [f for f in self.flows if f['cls'] == 'reverse']
        corridor_h = LANE * (len(self.corridor) + 1) + corridor_lanes_extra if self.corridor else 0
        zone_top = TITLE_H + CORRIDOR_TOP + corridor_h
        # zone columns
        x = PAGE_L
        for z in Z:
            risers = len(self.riser_lanes[z['id']])
            left_inset = max(INSET, LANE * (risers + 1) + 20)
            z['x'] = x; z['left_inset'] = left_inset
            z['w'] = left_inset + NODE_W + INSET
            x += z['w'] + (self.gutter_w[self.zi[z['id']]] if self.zi[z['id']] < len(Z) - 1 else 0)
        # rows
        y0 = zone_top + ZONE_HDR + INSET
        max_bottom = y0
        for z in Z:
            y = y0
            for n in self.by_zone[z['id']]:
                n['x'] = z['x'] + z['left_inset']; n['y'] = y
                y += n['h'] + ROW_GAP
            max_bottom = max(max_bottom, y - ROW_GAP)
        zone_h = max_bottom - zone_top + INSET
        for z in Z:
            z['y'] = zone_top; z['h'] = zone_h
        self.zone_top, self.zone_bottom = zone_top, zone_top + zone_h
        self.page_w = max(x + PAGE_L, 900)   # wide enough for the legend on a one- or two-zone page
        # lane x per gutter (order optimised later)
        self.gutter_x0 = [Z[g]['x'] + Z[g]['w'] for g in range(len(Z) - 1)]
        # ring y lanes
        self.ring_y0 = self.zone_bottom + 40
        self.ring_h = LANE * (len(self.ring) + 1) if self.ring else 0
        self.corridor_y0 = TITLE_H + CORRIDOR_TOP
        # legends
        self.legend_y = self.ring_y0 + self.ring_h + 40
        self.page_h = self.legend_y + 110 + 30 + flow_table_h(self, self.spec.get('_flows_all') or self.flows, self.page_w - 2 * PAGE_L) + 60   # the flow table lists every flow, bundled or not, at its measured height

    # ---------------------------------------------------------------- ports
    def assign_ports(self):
        """Stagger ports on each side; order by the other endpoint's vertical position (fan lines don't cross)."""
        for n in self.nodes.values():
            for side, fl in n['ports'].items():
                if not fl: continue
                def other_y(f):
                    o = self.nodes[f['target'] if f['source'] == n['id'] else f['source']]
                    return o['y'] + o['h'] / 2
                if side in ('L', 'R'):
                    fl.sort(key=lambda f: (other_y(f), badge_key(f['badge'])))
                else:
                    fl.sort(key=lambda f: (self.nodes[f['target'] if f['source'] == n['id'] else f['source']]['x'], badge_key(f['badge'])))
                N = len(fl)
                for i, f in enumerate(fl):
                    frac = (i + 1) / (N + 1)
                    if f['source'] == n['id'] and f['exit_side'] == side: f['exit'] = (side, frac)
                    if f['target'] == n['id'] and f['entry_side'] == side: f['entry'] = (side, frac)

    def anchor(self, nid, side, frac):
        n = self.nodes[nid]
        return {'L': (n['x'], n['y'] + frac * n['h']), 'R': (n['x'] + n['w'], n['y'] + frac * n['h']),
                'T': (n['x'] + frac * n['w'], n['y']), 'B': (n['x'] + frac * n['w'], n['y'] + n['h'])}[side]

    # ---------------------------------------------------------------- routing
    def lane_x(self, g, k):
        return self.gutter_x0[g] + LANE + k * LANE

    def route(self, lane_order):
        """lane_order[g] = list of flow ids in lane order (k=0 innermost/leftmost). Returns corners per flow."""
        corners = {}
        lane_of = {g: {fid: k for k, fid in enumerate(order)} for g, order in lane_order.items()}
        corridor_k = {f['id']: i for i, f in enumerate(self.corridor)}
        ring_k = {f['id']: i for i, f in enumerate(self.ring)}
        riser_k = {}
        for zid, fl in self.riser_lanes.items():
            for i, f in enumerate(fl): riser_k[f['id']] = (zid, i)
        for f in self.flows:
            p0 = self.anchor(f['source'], *f['exit']); p1 = self.anchor(f['target'], *f['entry'])
            c = f['cls']
            if c in ('fwd', 'back'):
                lx = self.lane_x(f['gutters'][0], lane_of[f['gutters'][0]][f['id']])
                corners[f['id']] = [(lx, p0[1]), (lx, p1[1])]
            elif c == 'corridor':
                g0, g1 = f['gutters']
                lx0 = self.lane_x(g0, lane_of[g0][f['id']]); lx1 = self.lane_x(g1, lane_of[g1][f['id']])
                cy = self.corridor_y0 + LANE * (corridor_k[f['id']] + 1)
                corners[f['id']] = [(lx0, p0[1]), (lx0, cy), (lx1, cy), (lx1, p1[1])]
            elif c == 'reverse':
                g = f['gutters'][0]
                lx = self.lane_x(g, lane_of[g][f['id']])
                ry = self.ring_y0 + LANE * (ring_k[f['id']] + 1)
                zid, ri = riser_k[f['id']]
                z = self.zones[self.zi[zid]]
                rx = z['x'] + LANE * (ri + 1)
                corners[f['id']] = [(lx, p0[1]), (lx, ry), (rx, ry), (rx, p1[1])]
            elif c == 'riser':
                zid, ri = riser_k[f['id']]
                z = self.zones[self.zi[zid]]
                rx = z['x'] + LANE * (ri + 1)
                corners[f['id']] = [(rx, p0[1]), (rx, p1[1])]
            else:  # down / up: straight if aligned, else one jog
                corners[f['id']] = [] if abs(p0[0] - p1[0]) < .01 else [(p0[0], (p0[1] + p1[1]) / 2), (p1[0], (p0[1] + p1[1]) / 2)]
        return corners

    def initial_lane_order(self):
        order = {}
        for g, es in enumerate(self.gutter_edges):
            def travel(f):
                a = self.anchor(f['source'], *f['exit']); b = self.anchor(f['target'], *f['entry'])
                return -abs(a[1] - b[1])  # longest travel first -> innermost (leftmost) lane
            order[g] = [f['id'] for f in sorted(es, key=travel)]
        return order

    # ---------------------------------------------------------------- diagram assembly
    def build(self, lane_order, created, modified, theme='ulta'):
        d = Diagram(self.spec['title'], int(self.page_w), int(self.page_h), theme=theme)
        for z in self.zones:
            d.zone(z['id'], z['title'], z['x'], z['y'], z['w'], z['h'], z.get('kind', 'saas'))
        for n in self.spec['nodes']:
            m = self.nodes[n['id']]
            z_kind = next((z.get('kind', 'saas') for z in self.zones if z['id'] == m['zone']), 'saas')
            icon_url = resolve_icon(n['label'], n.get('sub', ''), zone=z_kind, theme=theme)
            d.node(n['id'], n['label'], n.get('sub', ''), n.get('state', 'keep'), m['x'], m['y'], m['w'], m['h'], cylinder=n.get('shape') == 'cylinder', icon_url=icon_url)
        d.reserve(PAGE_L, 10, self.page_w - 2 * PAGE_L, 70)                         # title block
        d.reserve(PAGE_L, self.legend_y, self.page_w - 2 * PAGE_L, self.page_h - self.legend_y)  # legends
        corners = self.route(lane_order)
        for f in self.flows:
            d.edge(f['badge'], f['source'], f['exit'], f['target'], f['entry'], f['kind'], corners=corners[f['id']], desc=f.get('desc', ''), text=f.get('text'), both=f.get('both', False))
        return d

    def score(self, lane_order):
        try:
            d = self.build(lane_order, '', '')
            d.place_badges()
            errs, cross = d.audit()
            return len(errs) * 100 + cross, errs, cross
        except RuntimeError as e:  # badge placement failed
            return 10_000, [str(e)], 0

    def optimise(self):
        best = self.initial_lane_order(); best_s, errs, cross = self.score(best)
        for g in sorted(best, key=lambda g: len(best[g]), reverse=True):
            if best_s == 0 or len(best[g]) < 2: continue
            ids = best[g]
            perms = list(itertools.permutations(ids)) if len(ids) <= 6 else [ids, ids[::-1]]
            for perm in perms:
                cand = dict(best); cand[g] = list(perm)
                s, e, c = self.score(cand)
                if s < best_s:
                    best, best_s, errs, cross = cand, s, e, c
                    if s == 0: break
        return best, best_s, errs, cross


def _run_layout(spec):
    """Full layout + lane search for one arrangement: (score, crossings, long_routes, L, order, errs) or None when it cannot be laid out."""
    L = Layout(spec); L.classify()
    for gx, cx in [(0, 0), (40, 20), (100, 40), (200, 60)]:
        L.place(gutter_extra=gx, corridor_lanes_extra=cx); L.assign_ports()
        order, s, errs, cross = L.optimise()
        if s < 100:
            longr = sum(1 for f in L.flows if f['cls'] in ('reverse', 'corridor', 'riser'))
            return s, cross, longr, L, order, errs
    return None


def arrangements(spec, max_zone_orders=6, sweeps=6):
    """Candidate arrangements of the same diagram: zone orders with the fewest backward / long flows, and within each zone a
    barycentre ordering (every box sits near the systems it talks to). The given order is always a candidate."""
    zones = [z['id'] for z in spec['zones']]; nodes = spec['nodes']; flows = spec['flows']
    zone_of = {n['id']: n['zone'] for n in nodes}
    def zone_cost(order):
        pos = {z: i for i, z in enumerate(order)}; c = 0
        for f in flows:
            a, b = pos[zone_of[f['source']]], pos[zone_of[f['target']]]
            c += 6 if b < a else (2 * (b - a - 1) if b > a + 1 else 0)
        return c
    orders = [zones]
    if 2 < len(zones) <= 6:
        ranked = sorted(itertools.permutations(zones), key=lambda o: (zone_cost(o), sum(1 for i, z in enumerate(o) if z != zones[i])))
        for o in ranked[:max_zone_orders]:
            if list(o) not in orders: orders.append(list(o))
    nbrs = {n['id']: [] for n in nodes}
    for f in flows:
        nbrs[f['source']].append(f['target']); nbrs[f['target']].append(f['source'])
    out = []
    for zo in orders:
        rows = {z: [n['id'] for n in nodes if n['zone'] == z] for z in zo}
        seen = set()
        def emit(r):
            key = tuple(tuple(r[z]) for z in zo)
            if key in seen: return
            seen.add(key); by = {n['id']: n for n in nodes}
            out.append(dict(spec, zones=[next(z for z in spec['zones'] if z['id'] == zid) for zid in zo], nodes=[by[i] for z in zo for i in r[z]]))
        emit(rows)
        r = {z: list(v) for z, v in rows.items()}
        for k in range(sweeps):
            pos = {i: (zo.index(z), j / max(1, len(r[z]) - 1)) for z in zo for j, i in enumerate(r[z])}
            seq = zo if k % 2 == 0 else zo[::-1]
            for z in seq:
                cur = {i: j for j, i in enumerate(r[z])}
                def bary(i):
                    ns = [pos[n][1] for n in nbrs[i] if n in pos and pos[n][0] != zo.index(z)]
                    return sum(ns) / len(ns) if ns else cur[i] / max(1, len(r[z]) - 1)
                r[z] = sorted(r[z], key=lambda i: (bary(i), cur[i]))
                for j, i in enumerate(r[z]): pos[i] = (zo.index(z), j / max(1, len(r[z]) - 1))
            emit(r)
    return out


def best_arrangement(spec):
    """The arrangement with the fewest crossings, then the fewest long routes (reverse ring, top corridor, risers), then the
    one closest to the given order. spec['keep_order'] = true builds exactly the given order."""
    if spec.get('keep_order'): return spec, None
    base = _run_layout(spec); best = (spec, base)
    def key(res):
        return (res[0] >= 100, res[1] * 3 + res[2], res[0])
    for cand in arrangements(spec)[1:]:
        res = _run_layout(cand)
        if res and (best[1] is None or key(res) < key(best[1])): best = (cand, res)
    info = {'crossings_before': base[1] if base else None, 'crossings_after': best[1][1] if best[1] else None,
            'long_before': base[2] if base else None, 'long_after': best[1][2] if best[1] else None, 'rearranged': best[0] is not spec}
    return best[0], info


def bundle_flows(spec):
    """One line per pair of systems: flows between the same two systems with the same line style share a line whose badge
    lists them all ("4.0 · 6.0 · 7.0"); a two-way pair becomes one double-headed line ("3.1 ⇄ 4.1"). Different styles
    (a dashed optional flow next to a solid one) stay separate lines. The flow table still lists every flow."""
    groups = {}
    for f in spec['flows']:
        groups.setdefault((frozenset((f['source'], f['target'])), f.get('kind', 'sync')), []).append(f)
    out = []
    for (_, kind), fs in groups.items():
        fs = sorted(fs, key=lambda f: badge_key(f['badge']))
        if len(fs) == 1: out.append(fs[0]); continue
        p = fs[0]; dirs = {(f['source'], f['target']) for f in fs}; both = len(dirs) == 2
        if both:
            fwd = [f['badge'] for f in fs if (f['source'], f['target']) == (p['source'], p['target'])]; rev = [f['badge'] for f in fs if (f['source'], f['target']) != (p['source'], p['target'])]
            text = ' · '.join(fwd) + ' ⇄ ' + ' · '.join(rev)
        else: text = ' · '.join(f['badge'] for f in fs)
        out.append(dict(p, text=text, both=both, members=[f['id'] for f in fs], desc=' / '.join(f.get('desc', '') for f in fs)))
    return dict(spec, flows=sorted(out, key=lambda f: badge_key(f['badge'])))


def process_groups(spec):
    """Flows grouped by process - the whole part of the step number (1.x, 2.x …)."""
    g = {}
    for f in spec['flows']:
        head = str(f['badge']).split('.')[0].strip()
        if head.isdigit(): g.setdefault(int(head), []).append(f)
    return dict(sorted(g.items()))


def process_page(spec, n, flows, theme, created, modified):
    """One small page for one process: only its systems and zones, its flows bundled and arranged; None if it will not lay out."""
    import contextlib, io, re, tempfile
    ids = {x for f in flows for x in (f['source'], f['target'])}
    nodes = [nd for nd in spec['nodes'] if nd['id'] in ids]; zids = [z['id'] for z in spec['zones'] if any(nd['zone'] == z['id'] for nd in nodes)]
    name = (spec.get('processes') or {}).get(str(n)) or str(flows[0].get('desc') or f'Process {n}')
    name = name if len(name) <= 42 else name[:41].rsplit(' ', 1)[0] + '…'
    sub = dict(spec, title=f"{n}. {name}", subtitle=f"{spec.get('title', '')} - process view, steps {flows[0]['badge']}–{flows[-1]['badge']}",
               zones=[z for z in spec['zones'] if z['id'] in zids], nodes=nodes, flows=flows)
    sub = bundle_flows(sub) if spec.get('bundle', True) is not False else sub; sub['_rows'] = len(flows); sub['_flows_all'] = flows
    try:
        sub, _ = best_arrangement(sub)
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            L = Layout(sub); L.classify(); res = None
            for gx, cx in [(0, 0), (40, 20), (100, 40), (200, 60)]:
                L.place(gutter_extra=gx, corridor_lanes_extra=cx); L.assign_ports(); order, s, errs, cross = L.optimise()
                if s < 100: res = (order, cross); break
            if res is None: return None
            d = L.build(res[0], created, modified, theme=theme); state_xml, rows_html, geom = legends_xml(L, sorted(flows, key=lambda f: badge_key(f['badge'])), theme=theme)
            tmp = tempfile.NamedTemporaryFile(suffix='.drawio', delete=False).name
            d.emit(tmp, sub['subtitle'], created, modified, rows_html, state_xml, geom)
        xml = open(tmp, encoding='utf-8').read(); os.unlink(tmp)
        m = re.search(r'<diagram id="d1" name="[^"]*">.*?</diagram>', xml, re.S)
        if not m: return None
        page = m.group(0).replace('<diagram id="d1" name="', f'<diagram id="p{n}" name="', 1)
        page = re.sub(r'(<diagram id="p\d+" name=")[^"]*"', lambda mm: mm.group(1) + escape(f'{n} · {name}') + '"', page, count=1)
        return f'{n} · {name}', page, res[1]
    except (SystemExit, Exception):
        return None


def flow_table_h(L, flows, w):
    """The flow legend's height, measured: a description or a system pair that wraps onto more lines makes its row taller (10 px Arial,
    about 5.8 px a character, rounded up) - a fixed 22 px per row let wrapped text run out of the legend box. One-line rows: 22 px, as before."""
    desc_w = max(100, (w - 40) - 8 - 45 - 260 - 120 - 8 * 12)   # the table's width minus the fixed columns and the cell padding
    cpl_d = max(12, int(desc_w / 5.8)); cpl_p = int((260 - 24) / 5.8)
    rows = 0
    for f in flows:
        a_, b_ = (L.nodes.get(f.get('source')) or {}), (L.nodes.get(f.get('target')) or {})
        pair = f"{a_.get('label', '')} → {b_.get('label', '')}"
        lines = max(1, -(-len(str(f.get('desc') or '')) // cpl_d), -(-len(pair) // cpl_p))
        rows += 9 + 13 * lines
    return 60 + rows


def legends_xml(L, flows, theme='ulta'):
    th = THEMES.get(theme, THEMES['ulta'])
    y = L.legend_y; w = L.page_w - 2 * PAGE_L
    border = th['legend_border']
    bg = th['legend_bg']
    arc = th.get('zone_arc', 8)
    o = [f'        <mxCell id="sl" value="System State &amp; Connector Legend" style="shape=swimlane;horizontal=1;startSize=24;html=1;whiteSpace=wrap;fillColor={bg};strokeColor={border};strokeWidth=1.5;fontSize=12;fontStyle=1;fontColor=#303030;arcSize={arc};" vertex="1" parent="1"><mxGeometry x="{PAGE_L}" y="{y}" width="{w}" height="110" as="geometry"/></mxCell>']
    step = max(150, (w - 60) // 5)   # a small process page still fits five states
    for i, (k, name) in enumerate(STATE_NAMES):
        x = PAGE_L + 30 + i * step
        o.append(f'        <mxCell id="sw{i}" value="" style="{th["state"][k]}" vertex="1" parent="sl"><mxGeometry x="{x - PAGE_L}" y="36" width="30" height="15" as="geometry"/></mxCell>')
        o.append(f'        <mxCell id="sn{i}" value="{escape(name)}" style="text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;spacingLeft=4;overflow=hidden;fontSize=10;fontColor=#303030;" vertex="1" parent="sl"><mxGeometry x="{x + 38 - PAGE_L}" y="34" width="{min(200, step - 44)}" height="18" as="geometry"/></mxCell>')
    step2 = max(180, (w - 60) // 4)
    dash = {'sync': '', 'async': 'dashed=1;dashPattern=8 4;', 'opt': 'dashed=1;dashPattern=1 3;', 'reject': ''}
    for i, (k, name) in enumerate(KIND_NAMES):
        x = PAGE_L + 30 + i * step2
        o.append(f'        <mxCell id="cw{i}" value="" style="line;strokeWidth=2.5;html=1;strokeColor={th["edge"][k][0]};{dash[k]}" vertex="1" parent="sl"><mxGeometry x="{x - PAGE_L}" y="72" width="44" height="2" as="geometry"/></mxCell>')
        o.append(f'        <mxCell id="cn{i}" value="{escape(name)}" style="text;html=1;strokeColor=none;fillColor=none;align=left;verticalAlign=middle;spacingLeft=4;overflow=hidden;fontSize=10;fontColor=#303030;" vertex="1" parent="sl"><mxGeometry x="{x + 52 - PAGE_L}" y="64" width="{min(220, step2 - 56)}" height="18" as="geometry"/></mxCell>')
    head_bg = th['legend_head_bg']
    head_border = th['table_head_border']
    rows = ["<table style='border-collapse:collapse;width:100%;font-family:Arial,Helvetica,sans-serif;font-size:10px;'>",
            f"<tr style='background:{head_bg};font-weight:bold;border-bottom:2px solid {head_border};'><td style='padding:6px 12px;width:45px;'>Step</td><td style='padding:6px 12px;width:260px;'>Source → Target</td><td style='padding:6px 12px;'>Description</td><td style='padding:6px 12px;width:120px;'>Type</td></tr>"]
    kind_name = dict(KIND_NAMES)
    kind_html = th['kind_html']
    for f in flows:
        rows.append(f"<tr style='border-bottom:1px solid #F5F5F5;'><td style='padding:5px 12px;font-weight:bold;'>{escape(f['badge'])}</td>"
                    f"<td style='padding:5px 12px;'>{escape(L.nodes[f['source']]['label'])} → {escape(L.nodes[f['target']]['label'])}</td>"
                    f"<td style='padding:5px 12px;'>{escape(f.get('desc', ''))}</td>"
                    f"<td style='padding:5px 12px;color:{kind_html[f['kind']]};font-weight:bold;'>{kind_name[f['kind']]}</td></tr>")
    rows.append('</table>')
    fl_y = y + 110 + 30; fl_h = flow_table_h(L, flows, w)
    return '\n'.join(o), ''.join(rows), (PAGE_L, fl_y, w, fl_h, w - 40, fl_h - 45)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('spec'); ap.add_argument('--out', required=True); ap.add_argument('--theme', default='ulta', choices=['ulta', 'sap', 'cloud'], help='Diagram styling standard (ulta is the default)')
    ap.add_argument('--wrap', help='ultaarchbuilder input.json to attach evidence metadata (writes badges.json too)')
    a = ap.parse_args()
    spec = json.load(open(a.spec, encoding='utf-8'))
    today = datetime.date.today().isoformat()
    created = spec.get('created') or today; modified = today
    th = 'ulta'          # every draw.io file follows the ULTA Enterprise Diagram Standards (zero deviation; no vendor themes)
    orig = spec; all_flows = sorted(spec['flows'], key=lambda f: badge_key(f['badge']))
    if spec.get('bundle', True) is not False: spec = bundle_flows(spec)   # one line per pair of systems
    spec['_rows'] = len(all_flows); spec['_flows_all'] = all_flows
    spec, arranged = best_arrangement(spec)   # the order that reads best: fewest crossings, fewest long detours
    L = Layout(spec); L.classify()
    result = None
    for attempt, (gx, cx) in enumerate([(0, 0), (40, 20), (100, 40), (200, 60)]):
        L.place(gutter_extra=gx, corridor_lanes_extra=cx); L.assign_ports()
        order, s, errs, cross = L.optimise()
        if s < 100:
            result = (order, errs, cross); break
    if result is None:
        print('LAYOUT FAILED after 4 attempts:'); [print('   ', e) for e in errs[:10]]; sys.exit(2)
    order, errs, cross = result
    d = L.build(order, created, modified, theme=th)
    state_xml, rows_html, geom = legends_xml(L, all_flows, theme=th)
    d.emit(a.out, spec.get('subtitle', ''), created, modified, rows_html, state_xml, geom)
    pages = []
    groups = process_groups(orig)
    # a small page per process after the overview - only when processes really group flows (a drafter that numbers every flow 1.0, 2.0, 3.0 … is not describing processes)
    if orig.get('process_pages', True) is not False and len(groups) >= 2 and len(all_flows) >= 6 and len(all_flows) >= 1.5 * len(groups):
        for n, fl in groups.items():
            pg = process_page(orig, n, sorted(fl, key=lambda f: badge_key(f['badge'])), th, created, modified)
            if pg: pages.append(pg)
        if pages:
            xml = open(a.out, encoding='utf-8').read()
            xml = xml.replace('<diagram id="d1" name="', '<diagram id="d1" name="Overview · ', 1).replace('</mxfile>', '\n'.join(p[1] for p in pages) + '\n</mxfile>', 1)
            open(a.out, 'w', encoding='utf-8').write(xml)
    print(json.dumps({'status': 'OK', 'out': os.path.abspath(a.out), 'zones': len(L.zones), 'nodes': len(L.nodes), 'flows': len(L.flows),
                      'crossings': cross, 'arranged': arranged, 'lines': len(L.flows), 'bundled_from': len(all_flows),
                      'pages': ['Overview'] + [p[0] for p in pages], 'page_crossings': [p[2] for p in pages], 'page': [int(L.page_w), int(L.page_h)]}, indent=2, ensure_ascii=False))
    if a.wrap:
        badges = {f['id']: f['badge'] for f in L.flows}
        bpath = os.path.splitext(a.out)[0] + '.badges.json'; json.dump(badges, open(bpath, 'w'), indent=1)
        wrapper = os.path.join(os.path.dirname(HERE), 'enterprisediagramstandards', 'scripts', 'ulta_drawio_evidence_wrap.py')
        print(f'evidence wrap: python3 {wrapper} {a.out} {a.wrap} {bpath} final.drawio')


if __name__ == '__main__':
    main()
