#!/usr/bin/env python3
"""A crisp architecture diagram for one slide of a deck (hybrid mode): no model, no tokens.

Reads what a page already holds - 
  - box art: ┌──┐ │ … │ └──┬──┘ boxes joined by │ / ▼ connectors with a label beside them, drawn on many lines or pasted
    flat onto one (Confluence copies often collapse it); +---+ ASCII boxes too;
  - arrow lines: "MIA → API Gateway: HTTPS", "SAP -> OMS (inventory sync)";
 - and lays it out for a 16:9 slide in the infographic canvas (1600 × 900 units, 120 to the inch): systems in columns from left to
right in the order the flows run, labelled arrows between them (an elbow where two boxes sit at different heights, a lane over or
under the boxes for a flow that skips a column or runs backwards). The deck builder draws it as native shapes (infographic/info
add_info), the deck twin as SVG (info.to_svg) - the same picture.

Crisp by rule: at most 8 systems and 10 lines (flows between the same two systems share one line), three bullet points per box,
labels cut to a phrase. What does not fit is named in the notes, never squeezed onto the slide.

  slide_diagram.py page.txt --out design.json      (a test hook: the first diagram found, laid out)
"""
import json, math, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__)); KIT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(KIT, 'infographic'))
import info as IG  # noqa: E402  (wrap / fit, colours, the canvas and the SVG renderer)

MAX_NODES, MAX_FLOWS, MAX_ITEMS = 8, 10, 3
TL, TR, BL, BR = '┌╔╭+', '┐╗╮+', '└╚╰+', '┘╝╯+'
HZ, VT = '─═━-┬┴+', '│║┃|├┤+'
DOWN, UP, RIGHT, LEFT = '▼v↓', '▲^↑', '►>→▶', '◄<←◀'
ARROW_LINE = re.compile(r'^\s*[-•*]?\s*(?P<a>[^→>=]{1,60}?)\s*(?:→|->|=>|⟶|——>|-->)\s*(?P<b>[^:()\[\]→]{1,60}?)\s*(?::\s*(?P<l>.{1,80}?)|[(\[]\s*(?P<l2>[^)\]]{1,80})[)\]])?\s*$')
NAME_OK = lambda s: bool(re.search(r'[A-Za-z]{2}', s)) and not re.match(r'^[\d$€£%.,\s+\-]+', s) and len(s) <= 40 and len(s.split()) <= 6


# ------------------------------------------------------------------------------------------------ detection
def is_art(text):
    t = str(text or '')
    if (len(re.findall('[┌╔╭]', t)) >= 2 and len(re.findall('[└╚╰]', t)) >= 2) or (len(re.findall(r'\+[-=]{3,}\+', t)) >= 4 and '|' in t): return True
    # chain art: names joined by drawn arrows on 2+ lines ("PIM ──► DSP ──► OMS" / "│ ▼"), the AI-chat way of drawing an architecture
    return len(re.findall(r'\w[^\n]{0,40}?\s*─+[►▶]\s*\w|\w\s*[◄◀]─+', t)) >= 3 and '\n' in t.strip()


def arrow_lines(lines):
    """Lines that read "A → B: label" - a list of (a, b, label), or None when fewer than two lines do (a single arrow is prose)."""
    got = []
    for l in lines:
        m = ARROW_LINE.match(str(l))
        if m and NAME_OK(m.group('a').strip(' .')) and NAME_OK(m.group('b').strip(' .')):
            got.append((m.group('a').strip(' .'), m.group('b').strip(' .'), (m.group('l') or m.group('l2') or '').strip(' .')))
    names = {x.lower() for a, b, _ in got for x in (a, b)}   # "14% → 4%" or "Q1 → Q2" bullets are not a system diagram
    return got if len(got) >= 2 and len(names) >= 3 and len(got) >= 0.6 * len([l for l in lines if str(l).strip()]) else None


# ------------------------------------------------------------------------------------------------ box art → systems and flows
def _box_text(lines):
    """A box's inner lines → (label, sub, items): the first plain line names it, a second plain line is the system, "- x" are points."""
    plain, items = [], []
    for l in lines:
        l = re.sub(r'\s+', ' ', l).strip(' │|')
        if not l: continue
        if re.match(r'^[-•*·]\s*', l): items.append(re.sub(r'^[-•*·]\s*', '', l))
        else: plain.append(l)
    label = plain[0] if plain else (items.pop(0) if items else 'System')
    return label, ' · '.join(plain[1:3]), items


def _clean_label(t):
    t = re.sub(r'[│|▼▲►◄▶◀↓↑→←v^─━═\-]{1,}\s*$', '', re.sub(r'^\s*[│|▼▲►◄▶◀↓↑→←─━═]+', '', str(t or ''))).strip()
    t = re.sub(r'[│▼▲►◄▶◀↓↑→←─━═]', ' ', t); return re.sub(r'\s+', ' ', t).strip(' -|')


def parse_flat(text):
    """Box art pasted onto one line (or a simple vertical stack): boxes in reading order, the text between two boxes labels the line."""
    t = str(text); boxes = []; flows = []; prev_end = None
    for m in re.finditer(r'[┌╔╭][─═━┬]*[┐╗╮](.*?)[└╚╰][─═━┬┴]*[┘╝╯]', t, re.S):
        segs = [s for s in re.split(r'[│║┃]', m.group(1))]
        label, sub, items = _box_text(segs)
        boxes.append({'label': label, 'sub': sub, 'items': items})
        if prev_end is not None and len(boxes) >= 2:
            gap = t[prev_end:m.start()]; up = any(ch in gap for ch in UP) and not any(ch in gap for ch in DOWN)
            a, b = len(boxes) - 2, len(boxes) - 1
            flows.append({'s': b if up else a, 't': a if up else b, 'label': _clean_label(gap)})
        prev_end = m.end()
    return boxes, flows


def parse_grid(text):
    """Box art on many lines: every rectangle found on the character grid, connectors traced from a box edge (│ down to the next box,
    ─ right to the next box) with the words written beside or on them as the label. None when nothing parses."""
    lines = str(text).replace('\t', '    ').split('\n')
    W = max((len(l) for l in lines), default=0); G = [l.ljust(W) for l in lines]; H = len(G)
    at = lambda r, c: G[r][c] if 0 <= r < H and 0 <= c < W else ' '
    boxes = []
    for r in range(H):
        for c in range(W):
            if at(r, c) not in TL or at(r, c + 1) not in HZ: continue
            c2 = c + 1
            while c2 < W and at(r, c2) in HZ and not (at(r, c2) in TR and c2 - c >= 3 and at(r + 1, c2) in VT): c2 += 1
            if at(r, c2) not in TR or c2 - c < 3: continue
            r2 = r + 1
            while r2 < H and at(r2, c) in VT and at(r2, c) not in BL: r2 += 1
            if r2 >= H or at(r2, c) not in BL or at(r2, c2) not in BR or r2 - r < 2: continue
            if any(b['r'] <= r <= b['r2'] and b['c'] <= c <= b['c2'] for b in boxes): continue   # a box inside a box: keep the outer one
            inner = [G[k][c + 1:c2] for k in range(r + 1, r2)]
            label, sub, items = _box_text(inner)
            boxes.append({'r': r, 'c': c, 'r2': r2, 'c2': c2, 'label': label, 'sub': sub, 'items': items})
    if len(boxes) < 2: return None
    def box_at(r, c):
        return next((i for i, b in enumerate(boxes) if b['r'] <= r <= b['r2'] and b['c'] <= c <= b['c2']), None)
    flows = []; seen = set()
    for i, b in enumerate(boxes):
        for x in range(b['c'] + 1, b['c2']):   # downward connectors from the bottom edge (or just under it)
            if at(b['r2'], x) not in '┬+╤' and at(b['r2'] + 1, x) not in VT + DOWN + UP: continue
            rr, label, up = b['r2'] + 1, [], False
            while rr < H and at(rr, x) in VT + DOWN + UP + ' ' and box_at(rr, x) is None:
                if at(rr, x) in UP: up = True
                txt = G[rr][x + 1:].strip()
                if txt and not re.match(r'^[┌└│─┐┘+|]', txt): label.append(re.split(r'\s{3,}|[│┌└]', txt)[0])
                if at(rr, x) == ' ' and not label and at(rr + 1, x) == ' ': break
                rr += 1
            j = box_at(rr, x)
            if j is not None and j != i and (i, j) not in seen:
                seen.add((i, j)); flows.append({'s': j if up else i, 't': i if up else j, 'label': _clean_label(' '.join(label))})
        for y in range(b['r'] + 1, b['r2']):   # rightward connectors from the right edge
            if at(y, b['c2'] + 1) not in '─━═-►>▶→' and at(y, b['c2']) not in '├┤╟':
                continue
            cc, label, left = b['c2'] + 1, '', False
            while cc < W and box_at(y, cc) is None:
                ch = at(y, cc)
                if ch in LEFT: left = True
                if ch not in '─━═-►>▶→◄<◀← ': label += ch
                elif label and not label.endswith(' '): label += ' '
                if ch == ' ' and at(y, cc + 1) == ' ' and at(y, cc + 2) == ' ': break
                cc += 1
            j = box_at(y, cc)
            if j is not None and not label.strip():   # the words written just above (or below) the arrow name it
                for yy in (y - 1, y + 1):
                    near = G[yy][b['c2'] + 1:boxes[j]['c']].strip() if 0 <= yy < H else ''
                    if near and not re.search(r'[┌└┐┘│─]', near): label = near; break
            if j is not None and j != i and (i, j) not in seen and (j, i) not in seen:
                seen.add((i, j)); flows.append({'s': j if left else i, 't': i if left else j, 'label': _clean_label(label)})
    order = sorted(range(len(boxes)), key=lambda k: (boxes[k]['r'], boxes[k]['c']))
    pos = {k: n for n, k in enumerate(order)}
    return [{'label': boxes[k]['label'], 'sub': boxes[k]['sub'], 'items': boxes[k]['items']} for k in order], [{'s': pos[f['s']], 't': pos[f['t']], 'label': f['label']} for f in flows]


CH_ARROW = re.compile(r'(◄──►|◀──▶|<-+>|◄─*|◀─*|<-+|─*►|─*▶|-+>|=>|→|←|↔)')
CH_STOP = set('│├└┌┐┘┴┬┤─►◄▼▲▶◀|')


def parse_chains(text, title=''):
    """Chain art - names joined by arrows ("PIM ──► DSP ──► OMS", "OMS ◄──► Mirakl") with │ ▼ ├ └ ┴ connectors between rows, the way
    AI chats draw an architecture without boxes. Every name is a system ("SAP S/4 (Entity 7200)": name + role), an arrow on a row is a
    flow, a vertical connector is traced from the name above to the name it reaches below; "[Order Flow]" lines are group titles.
    → from_dict fields, or None (fewer than 3 systems or 2 flows)."""
    rows = [re.sub(r'(?<![─-])-{2,}>', '──►', re.sub(r'<-{2,}(?![─-])', '◄──', l.rstrip())) for l in str(text or '').split('\n')]
    if not any(re.search(r'[─-]+[►▶>]|[◄◀<][─-]+|→|←', r) for r in rows): return None
    W = max((len(r) for r in rows), default=0); G = [r.ljust(W) for r in rows]
    NODE = re.compile(r'[^\s│├└┌┐┘┴┬┤─►◄▼▲▶◀|<>]+(?: [^\s│├└┌┐┘┴┬┤─►◄▼▲▶◀|<>]+)*')
    nodes = {}   # (row, c0) -> {'name','role','c0','c1','row','note'}
    for r, line in enumerate(G):
        st = line.strip()
        if re.fullmatch(r'\[[^\]]{2,60}\]', st) or not st: continue   # "[Order Fulfillment Flow]" names a group, it is not a system
        for m in NODE.finditer(line):
            tok = m.group(0).strip()
            if not re.search(r'[A-Za-z]{2}', tok): continue
            note = bool(re.fullmatch(r'\(.*\)', tok))
            nm = re.sub(r'\s*\(.*$', '', tok).strip() or tok; role = (re.search(r'\(([^)]*)\)', tok).group(1) if '(' in tok and not note else '')
            nodes[(r, m.start())] = {'name': nm, 'role': role, 'c0': m.start(), 'c1': m.end() - 1, 'row': r, 'note': note, 'tok': tok}
    real = {k: v for k, v in nodes.items() if not v['note']}
    def at(r, c, slack=0):
        best = None
        for v in real.values():
            if v['row'] != r: continue
            d = 0 if v['c0'] <= c <= v['c1'] else min(abs(c - v['c0']), abs(c - v['c1']))
            if d <= slack and (best is None or d < best[0]): best = (d, v)
        return best[1] if best else None
    pairs = []
    def add(a, b, lab=''):
        if a and b and a is not b: pairs.append((a, b, lab))
    for r in range(len(G)):   # arrows along a row
        row_nodes = sorted([v for v in real.values() if v['row'] == r], key=lambda v: v['c0'])
        for x, y in zip(row_nodes, row_nodes[1:]):
            gap = G[r][x['c1'] + 1:y['c0']]
            fw, bw = bool(re.search(r'[►▶>→]', gap)), bool(re.search(r'[◄◀<←]', gap))
            if fw: add(x, y)
            if bw: add(y, x)
    def trace(r, c, d, src, seen):   # follow a connector from a node: d = 'down' | 'left' | 'right'
        while 0 <= r < len(G) and 0 <= c < W and (r, c, d) not in seen:
            seen.add((r, c, d)); ch = G[r][c]
            if ch == ' ':
                if d == 'down':
                    v = at(r, c, 2)
                    if v: add(src, v); return
                return
            if ch in '▼':
                for rr in range(r + 1, min(len(G), r + 4)):
                    if re.fullmatch(r'\s*\[[^\]]+\]\s*', G[rr]): continue
                    v = at(rr, c, 3)
                    if v: add(src, v); return
                    if G[rr][c] not in ' ': trace(rr, c, 'down', src, seen); return
                return
            if ch in '►▶':
                v = next((v for v in sorted(real.values(), key=lambda v: v['c0']) if v['row'] == r and v['c0'] > c), None); add(src, v); return
            if ch == '│': r += 1; continue
            if ch == '├': trace(r, c + 1, 'right', src, seen); r += 1; continue
            if ch == '└': c += 1; d = 'right'; continue
            if ch == '┴': trace(r, c - 1, 'left', src, seen); c += 1; d = 'right'; continue
            if ch in '┌┐┬': r += 1; d = 'down'; continue
            if ch == '─': c += 1 if d == 'right' else -1; continue
            if d == 'down':
                v = at(r, c, 1)
                if v: add(src, v)
            return
    for v in list(real.values()):
        cols = [c for c in range(v['c0'], v['c1'] + 1) if v['row'] + 1 < len(G) and G[v['row'] + 1][c] in '│▼├└┌']
        for c in cols: trace(v['row'] + 1, c, 'down', v, set())
    names = {}
    for v in real.values(): names.setdefault(v['name'].lower(), v)
    canon = lambda v: names[v['name'].lower()]['name']
    flows, seenf = [], set()
    for a, b, lab in pairs:
        k = (canon(a), canon(b))
        if k[0] != k[1] and k not in seenf: seenf.add(k); flows.append({'from': k[0], 'to': k[1], 'label': lab})
    used = {x for f in flows for x in (f['from'], f['to'])}
    roles = {}
    for v in real.values():
        if v['role'] and v['name'] in used: roles.setdefault(v['name'], [])
        if v['role'] and v['role'] not in roles.get(v['name'], []): roles.setdefault(v['name'], []).append(v['role'])
    nds = [{'name': n, 'role': (roles.get(n) or [''])[0], 'points': (roles.get(n) or [])[1:3]} for n in dict.fromkeys(canon(v) for v in sorted(real.values(), key=lambda v: (v['row'], v['c0']))) if n in used]
    if len(nds) < 3 or len(flows) < 2: return None
    return {'title': title, 'nodes': nds, 'flows': flows, 'from': 'chain art'}


def from_art(text, title=''):
    """Box art (flat or on a grid) → arch {title, nodes, flows}; None when it does not read as a diagram."""
    if not re.search(r'[┌└╔╭+]\s*[─═-]', str(text)) or not re.search(r'[┐┘╗╮]', str(text)) or re.search(r'\w ─+[►▶]', str(text)):   # no boxes, names joined by arrows: chain art
        ch = parse_chains(text, title)
        if ch: return from_dict(ch, title)
    grid = parse_grid(text) if '\n' in str(text).strip() else None
    flat = parse_flat(text)
    # the grid reader needs the drawing's columns; a copy that collapsed the indentation (Confluence's code block) breaks its connectors,
    # where the reading-order reader still sees every box and every line: the reader that finds more flows wins, a tie goes to the grid
    got = grid if grid and grid[1] and len(grid[1]) >= len(flat[1]) else flat
    boxes, fl = got
    if len(boxes) < 2: return None
    nodes = [dict(id=f'n{i}', **b) for i, b in enumerate(boxes)]
    return {'title': title, 'nodes': nodes, 'flows': [{'source': f'n{f["s"]}', 'target': f'n{f["t"]}', 'label': f['label']} for f in fl], 'from': 'box art'}


def from_arrows(pairs, title=''):
    ids = {}; nodes = []
    def nid(name):
        k = re.sub(r'\s+', ' ', name).strip().lower()
        if k not in ids: ids[k] = f'n{len(nodes)}'; nodes.append({'id': ids[k], 'label': name.strip(), 'sub': '', 'items': []})
        return ids[k]
    flows = [{'source': nid(a), 'target': nid(b), 'label': l} for a, b, l in pairs]
    return {'title': title, 'nodes': nodes, 'flows': flows, 'from': 'arrow lines'}


# ------------------------------------------------------------------------------------------------ crisp
def _short(t, n):
    t = re.sub(r'\s+', ' ', str(t or '')).strip()
    if len(t) <= n: return t
    cut = t[:n - 1].rsplit(' ', 1)[0].rstrip(',;:/-') + '…'
    sys.stderr.write(f'CUT\t{n}\t{t}\n')          # reported, so the caller can ask for a shorter label instead of shipping '…'
    return cut


def crisp(arch):
    """At most 8 systems (the best-connected kept), 10 lines (flows between the same two systems share one), 3 points a box, short
    labels. Returns (arch, dropped) - dropped names what left the slide (it goes to the notes)."""
    nodes, flows = list(arch['nodes']), list(arch['flows']); dropped = []
    if len(nodes) > MAX_NODES:
        deg = {n['id']: 0 for n in nodes}
        for f in flows: deg[f['source']] = deg.get(f['source'], 0) + 1; deg[f['target']] = deg.get(f['target'], 0) + 1
        keep = set(sorted((n['id'] for n in nodes), key=lambda i: (-deg[i], int(i[1:]) if i[1:].isdigit() else 0))[:MAX_NODES])
        dropped += [n['label'] for n in nodes if n['id'] not in keep]
        nodes = [n for n in nodes if n['id'] in keep]; flows = [f for f in flows if f['source'] in keep and f['target'] in keep]
    pairs = {}
    for f in flows:
        if f['source'] == f['target']: continue
        key = frozenset((f['source'], f['target']))
        if key in pairs:
            p = pairs[key]
            rev = (f['source'], f['target']) != (p['source'], p['target'])
            if rev: p['both'] = True
            if f.get('label') and f['label'] not in p['label']: p['label'] = (p['label'] + (' ⇄ ' if rev else ' · ') + f['label']).strip(' ·⇄ ')
        else: pairs[key] = dict(f, label=f.get('label') or '')
    flows = list(pairs.values())
    if len(flows) > MAX_FLOWS: dropped += [f'{f["source"]}→{f["target"]}' for f in flows[MAX_FLOWS:]]; flows = flows[:MAX_FLOWS]
    out = []; cap = MAX_ITEMS if len(nodes) <= 6 else 0   # 7+ systems: the boxes are too small for points to stay readable (≥ 8 pt) - they go to the notes
    for n in nodes:
        its = [_short(x, 34) for x in n.get('items') or []]
        if len(its) > cap: dropped.append(f'{n["label"]}: ' + '; '.join(its[cap:]))
        pts = arch.get('from') == 'points'   # "Make it a graphic": the role is the author's own point - kept whole up to two lines, never cut with "…"
        out.append(dict(n, label=_short(n['label'], 34 if pts else 30), sub=(re.sub(r'\s+', ' ', str(n.get('sub') or '')).strip()[:70] if pts else _short(n.get('sub'), 34)), items=its[:cap]))
    for f in flows: f['label'] = _short(f['label'], 44 if (f.get('both') or ' · ' in f['label'] or ' ⇄ ' in f['label']) else 26)
    return dict(arch, nodes=out, flows=flows), dropped


# ------------------------------------------------------------------------------------------------ layout
def _layers(nodes, flows):
    """Columns from the flows: a system sits one column right of everything that sends to it (cycles broken where they close)."""
    ids = [n['id'] for n in nodes]; succ = {i: [] for i in ids}
    for f in flows: succ[f['source']].append(f['target'])
    back, state = set(), {}
    def dfs(u):
        state[u] = 1
        for v in succ[u]:
            if state.get(v) == 1: back.add((u, v))
            elif not state.get(v): dfs(v)
        state[u] = 2
    for i in ids:
        if not state.get(i): dfs(i)
    layer = {i: 0 for i in ids}
    for _ in range(len(ids)):
        for f in flows:
            if (f['source'], f['target']) not in back: layer[f['target']] = max(layer[f['target']], layer[f['source']] + 1)
    used = sorted(set(layer.values())); remap = {v: k for k, v in enumerate(used)}
    return {i: remap[layer[i]] for i in ids}


STYLES = {   # id → (name, what it is for) - the ten looks a diagram slide can take; 'auto' picks hub & spoke or bands
    'bands': ('Ulta bands', 'brand-colour header band per system'),
    'outline': ('Outline', 'white boxes, coloured borders - minimal'),
    'pastel': ('Pastel', 'soft tint fills, no borders - calm'),
    'icons': ('Icon cards', 'a template pictogram for every system'),
    'midnight': ('Midnight', 'dark panel, light lines - the emphasis slide'),
    'numbered': ('Numbered flows', 'numbered badges on the lines and a flow legend'),
    'cake': ('Layer cake', 'stacked tiers, top to bottom'),
    'hub': ('Hub & spoke', 'the central system in the middle, senders left, receivers right'),
    'chevron': ('Chevron pipeline', 'a process of chevrons, the detail under each'),
    'bubbles': ('Bubbles', 'circles with pictograms, names beneath'),
    'sequence': ('Sequence', 'a lifeline per system, the flows as numbered messages in order'),
    'matrix': ('Interface matrix', 'who sends to whom: systems × systems, the flow in the cell'),
    'zones': ('Zones', 'systems grouped into Channels · Integration · Core · Data'),
    'tech': ('Technical shapes', 'databases as cylinders, events as queues, people as people'),
    'radial': ('Radial', 'systems around a ring, flows as chords'),
    'tree': ('Fan-out tree', 'one source on top, what it feeds below'),
    'funnel': ('Funnel', 'stages narrowing to an outcome - a pipeline, a sales or hiring funnel'),
    'pyramid': ('Pyramid', 'tiers from the apex down - priorities, maturity, a hierarchy of needs'),
    'stairs': ('Staircase', 'each step higher than the last - growth, maturity, a staged roadmap'),
    'milestones': ('Timeline', 'milestones on one line, text above and below'),
    'quadrant': ('Quadrant 2×2', 'four quadrants with a pictogram each'),
    'venn': ('Venn', 'two or three overlapping circles'),
    'target': ('Target', 'concentric rings to a bullseye'),
    'honeycomb': ('Honeycomb', 'hexagon tiles, one a point'),
    'cloud': ('Cloud reference', 'flat pastel zones, white cards with a blue icon, thin blue elbow lines - the cloud architecture-guide look'),
}
CLOUD_Z = ('F3EDEB', 'FDE1D2', 'FFE8EE', 'F2F2F2', 'F9E3DE')   # cloud reference: the zone tints, each one apart from the white canvas and its neighbours
QUAD_TINTS = ('FDE1D2', 'FFE8EE', 'FAD3DB', 'F3EDEB')   # 2x2: four template tints, none the colour of the slide behind them
CLOUD_LINE, CLOUD_BORDER, CLOUD_MUTED = '5D0F43', 'D9D9D9', '404040'
SLIDE_BG = 'FFF3ED'   # the template's content slides: what a diagram's text sits on outside its shapes
DARK, DARK2, LINE_C = '000000', '404040', '8C7F78'


def _degree(arch):
    d = {n['id']: 0 for n in arch['nodes']}
    for f in arch['flows']: d[f['source']] += 1; d[f['target']] += 1
    return d


def is_chain(arch):
    """Every system in its own column and every flow one step forward: a pipeline."""
    lay = _layers(arch['nodes'], arch['flows'])
    return len(set(lay.values())) == len(arch['nodes']) and all(lay[f['target']] == lay[f['source']] + 1 for f in arch['flows']) and len(arch['flows']) >= len(arch['nodes']) - 1


def auto_style(arch):
    """Hub & spoke when one system carries the picture (in at least half the lines, four systems or more), else the Ulta bands."""
    d = _degree(arch); n = len(arch['nodes']); f = max(1, len(arch['flows']))
    top = max(d.values()) if d else 0
    return 'hub' if n >= 4 and top >= 3 and top >= 0.5 * f and not is_chain(arch) else 'bands'


def suits(arch, st):
    """Crisp only: chevrons need a chain, hub & spoke a real hub (a system on three lines or more), layer cake at most two systems a tier."""
    if st == 'chevron': return is_chain(arch)
    if st == 'hub': return len(arch['nodes']) >= 3 and max(_degree(arch).values() or [0]) >= 3
    if st == 'cake':
        lay = _layers(arch['nodes'], arch['flows']); per = {}
        for v in lay.values(): per[v] = per.get(v, 0) + 1
        return max(per.values() or [0]) <= 2
    if st == 'sequence': return len(arch['flows']) >= 2
    if st == 'matrix':
        s_ = {f['source'] for f in arch['flows']}; t_ = {f['target'] for f in arch['flows']}
        return len(arch['flows']) >= 3 and len(s_) <= 7 and len(t_) <= 7
    if st == 'zones': return len(_zones(arch)[1]) >= 2
    if st == 'tech': return len({kind_of(n) for n in arch['nodes']}) >= 2
    if st == 'radial': return 4 <= len(arch['nodes']) <= 8
    if st == 'tree': return _tree_root(arch) is not None
    if st in SMART:   # point graphics: a list of points (no flows, or the points' own chain) - they would drop an architecture's flows
        n = len(arch['nodes']); listy = arch.get('from') == 'points' or not arch['flows'] or (st in ('stairs', 'milestones') and is_chain(arch))
        rng = {'funnel': (3, 6), 'pyramid': (3, 6), 'stairs': (3, 6), 'milestones': (3, 8), 'quadrant': (4, 4), 'venn': (2, 3), 'target': (3, 5), 'honeycomb': (3, 7)}[st]
        return listy and rng[0] <= n <= rng[1]
    return True


# ------------------------------------------------------------------------------------------------ v6.9 SmartArt-style graphics
# Funnel, pyramid, staircase, milestone timeline, 2×2 quadrant, Venn, target and honeycomb: native shapes in the Ulta palette, built
# from a list of points (each a name and an optional line under it). A name is never cut: its font steps down until it fits.
SMART = ('funnel', 'pyramid', 'stairs', 'milestones', 'quadrant', 'venn', 'target', 'honeycomb')


def _fit(text, w, fs, fsmin, font='bold', maxl=2):
    while True:
        ls = IG.wrap(str(text or ''), max(20, w), fs, font)
        if (len(ls) <= maxl and all(len(x) * fs * IG.CW[font] <= w + 2 for x in ls)) or fs <= fsmin: return ls, fs
        fs -= 1


def _tlabel(cv, n, x, y, w, color, sub_color, fs=24, sfs=17, align='left', maxl=2, smax=3):
    """A point's name (bold) and its line (muted) as a block; returns the block's height."""
    ls, f = _fit(n['label'], w, fs, 12, 'bold', maxl); h = cv.text(x, y, w, ls, f, color, 'bold', align, 1.18, name='diagram system', src=n['label'])
    if n.get('sub'):
        ss, sf = _fit(n['sub'], w, sfs, 11, 'body', smax); h += 4 + cv.text(x, y + h + 4, w, ss, sf, sub_color, 'body', align, 1.25, name='diagram sub', src=n['sub'])
    return h


def _tblock_h(n, w, fs=24, sfs=17, maxl=2, smax=3):
    ls, f = _fit(n['label'], w, fs, 12, 'bold', maxl); h = len(ls) * f * 1.18
    if n.get('sub'): ss, sf = _fit(n['sub'], w, sfs, 11, 'body', smax); h += 4 + len(ss) * sf * 1.25
    return h


def _bands(arch, box, kind):
    """Funnel (wide to narrow) and pyramid (apex on top): one band a point, the text beside it with a leader line."""
    nodes = arch['nodes']; cv = IG.Canvas(); X0, Y0, BW, BH = box; n = len(nodes)
    FW = BW * 0.46; cx = X0 + FW / 2; gap = 10; th = (BH - gap * (n - 1)) / n
    tx = X0 + FW + 70; tw = X0 + BW - tx
    for i, nd in enumerate(nodes):
        y = Y0 + i * (th + gap); col = IG.PALETTE[i % len(IG.PALETTE)]
        if kind == 'funnel': w1 = FW * (1 - 0.66 * i / n); w2 = FW * (1 - 0.66 * (i + 1) / n)
        else: w1 = FW * (i / n) + (FW * 0.06 if i == 0 else 0); w2 = FW * ((i + 1) / n)
        if kind == 'pyramid' and i == 0: cv.poly([(cx, y), (cx + w2 / 2, y + th), (cx - w2 / 2, y + th)], col, name='diagram box')
        else: cv.poly([(cx - w1 / 2, y), (cx + w1 / 2, y), (cx + w2 / 2, y + th), (cx - w2 / 2, y + th)], col, name='diagram box')
        num = str(i + 1); cv.text(cx - 30, y + th / 2 - 15, 60, [num], 26, 'FFFFFF', 'bold', 'center', 1.1, name='diagram badge text', src=num)
        edge = cx + max(w1, w2) / 2 if kind == 'funnel' else cx + (w1 + w2) / 4 + 6
        bh = _tblock_h(nd, tw); ty = y + (th - bh) / 2
        cv.line(edge + 8, y + th / 2, tx - 14, y + th / 2, IG.tint(col, 0.35), 2, name='diagram leader'); cv.ellipse(tx - 18, y + th / 2 - 4, 8, 8, col, None, name='diagram dot')
        _tlabel(cv, nd, tx, ty, tw, IG.INK, IG.MUTED)
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _funnel(arch, box): return _bands(arch, box, 'funnel')


def _pyramid(arch, box): return _bands(arch, box, 'pyramid')


def _stairs(arch, box):
    """Staircase: each point a step higher than the one before - growth, maturity, a roadmap of stages."""
    nodes = arch['nodes']; cv = IG.Canvas(); X0, Y0, BW, BH = box; n = len(nodes); gap = 14
    bw = (BW - gap * (n - 1)) / n
    for i, nd in enumerate(nodes):
        h = BH * (0.38 + 0.62 * (i + 1) / n); x = X0 + i * (bw + gap); y = Y0 + BH - h; col = IG.PALETTE[i % len(IG.PALETTE)]
        cv.rect(x, y, bw, h, col, None, 12, name='diagram box'); cv.rect(x, y + h - 12, bw, 12, col, None, 0, name='diagram box foot')
        cv.text(x + 16, y + 12, 60, [str(i + 1)], 30, 'FFFFFF', 'bold', 'left', 1.1, name='diagram badge text', src=str(i + 1))
        _tlabel(cv, nd, x + 16, y + 56, bw - 32, 'FFFFFF', 'FFF5F3', fs=21, sfs=15, maxl=3, smax=4)
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _milestones(arch, box):
    """Timeline: milestones on one line, the text alternating above and below on stems so neighbours never collide."""
    nodes = arch['nodes']; cv = IG.Canvas(); X0, Y0, BW, BH = box; n = len(nodes)
    ym = Y0 + BH / 2; step = BW / n; cv.line(X0, ym, X0 + BW, ym, 'D9CEC8', 4, name='diagram axis', arrow=True)
    tw = min(320, step * 1.7 - 20)
    for i, nd in enumerate(nodes):
        cx = X0 + step * (i + 0.5); col = IG.PALETTE[i % len(IG.PALETTE)]; up = i % 2 == 0
        cv.ellipse(cx - 15, ym - 15, 30, 30, col, 'FFFFFF', 4, name='diagram box')
        bh = _tblock_h(nd, tw, 22, 16); stem = 46
        if up: y0 = ym - 15 - stem - bh; cv.line(cx, ym - 17, cx, ym - 17 - stem + 8, col, 2, name='diagram stem')
        else: y0 = ym + 15 + stem; cv.line(cx, ym + 17, cx, ym + 17 + stem - 8, col, 2, name='diagram stem')
        _tlabel(cv, nd, cx - tw / 2, y0, tw, IG.INK, IG.MUTED, fs=22, sfs=16, align='center')
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _quadrant(arch, box):
    """2×2: four tinted quadrants, each with its pictogram, name and line; a thin cross through the middle."""
    nodes = arch['nodes'][:4]; cv = IG.Canvas(); X0, Y0, BW, BH = box; g = 16
    qw, qh = (BW - g) / 2, (BH - g) / 2
    for i, nd in enumerate(nodes):
        r, c = divmod(i, 2); x = X0 + c * (qw + g); y = Y0 + r * (qh + g); col = IG.PALETTE[i % len(IG.PALETTE)]
        cv.rect(x, y, qw, qh, QUAD_TINTS[i % len(QUAD_TINTS)], None, 18, name='diagram box')   # a template tint each, never the slide's own colour
        tw = qw - 170; bh = _tblock_h(nd, tw, 27, 19, 2, 4); D = 88; cy = y + qh / 2
        cv.ellipse(x + 34, cy - D / 2, D, D, col, None, name='diagram icon badge'); cv.icon(_icon_for(nd), x + 34 + D * 0.2, cy - D * 0.3, D * 0.6, 'FFFFFF', bold=True)
        _tlabel(cv, nd, x + 146, cy - bh / 2, tw, IG.INK, IG.MUTED, fs=27, sfs=19, maxl=2, smax=4)   # the colour is the badge's; the words read in ink
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _venn(arch, box):
    """Venn: two or three overlapping see-through circles, each named in its own part."""
    nodes = arch['nodes'][:3]; cv = IG.Canvas(); X0, Y0, BW, BH = box; n = len(nodes)
    R = min(BH * 0.40, BW * 0.2) if n == 3 else min(BH * 0.46, BW * 0.24); cx0, cy0 = X0 + BW / 2, Y0 + BH / 2
    if n == 2: cen = [(cx0 - R * 0.62, cy0), (cx0 + R * 0.62, cy0)]; lab = [(-R * 0.55, 0), (R * 0.55, 0)]
    else: cen = [(cx0 - R * 0.62, cy0 - R * 0.42), (cx0 + R * 0.62, cy0 - R * 0.42), (cx0, cy0 + R * 0.62)]; lab = [(-R * 0.5, -R * 0.35), (R * 0.5, -R * 0.35), (0, R * 0.55)]
    for i, (cx, cy) in enumerate(cen):
        col = IG.PALETTE[i % len(IG.PALETTE)]   # a palette pastel ringed in its colour: the files keep it light (a tint was mapped back to the full colour)
        cv.ellipse(cx - R, cy - R, 2 * R, 2 * R, IG.PASTEL.get(col, 'FFF3ED'), col, 3, name='diagram box', alpha=0.7)
    for i, nd in enumerate(nodes):
        (cx, cy), (dx, dy) = cen[i], lab[i]; w = R * 0.95; bh = _tblock_h(nd, w, 24, 16)
        _tlabel(cv, nd, cx + dx - w / 2, cy + dy - bh / 2, w, IG.shade(IG.PALETTE[i % len(IG.PALETTE)], 0.55), IG.INK, fs=24, sfs=16, align='center')
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _target(arch, box):
    """Target: concentric rings from the outermost point to the bullseye, each ring named on the right with a leader line."""
    nodes = arch['nodes']; cv = IG.Canvas(); X0, Y0, BW, BH = box; n = len(nodes)
    R = BH / 2; cx, cy = X0 + R + 10, Y0 + BH / 2; tx = cx + R + 90; tw = X0 + BW - tx; rowh = BH / n
    for i in range(n):
        r = R * (1 - i / n); col = IG.PALETTE[i % len(IG.PALETTE)]; cv.ellipse(cx - r, cy - r, 2 * r, 2 * r, col, 'FFFFFF', 3, name='diagram box')
    for i, nd in enumerate(nodes):
        r = R * (1 - (i + 0.5) / n); col = IG.PALETTE[i % len(IG.PALETTE)]; ty = Y0 + i * rowh + rowh / 2
        cv.line(cx + r * 0.55, cy - r * 0.83 if i < n - 1 else cy, tx - 22, ty, IG.tint(col, 0.2), 2, name='diagram leader'); cv.ellipse(tx - 26, ty - 5, 10, 10, col, None, name='diagram dot')
        bh = _tblock_h(nd, tw, 23, 17); _tlabel(cv, nd, tx, ty - bh / 2, tw, IG.INK, IG.MUTED, fs=23, sfs=17)
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _honeycomb(arch, box):
    """Honeycomb: one hexagon a point, in one row (up to 4) or two offset rows, the name and line inside."""
    nodes = arch['nodes']; cv = IG.Canvas(); X0, Y0, BW, BH = box; n = len(nodes)
    rows = [nodes] if n <= 4 else [nodes[:(n + 1) // 2], nodes[(n + 1) // 2:]]
    per = max(len(r) for r in rows) + (0.5 if len(rows) > 1 else 0); W = min(BW / per, (BH / (1 + 0.75 * (len(rows) - 1))) * 0.866 / 1.0)
    Hh = W / 0.866; total_w = per * W; x0 = X0 + (BW - total_w) / 2; y0 = Y0 + (BH - (Hh + (len(rows) - 1) * Hh * 0.75)) / 2; k = 0
    for ri, row in enumerate(rows):
        for ci, nd in enumerate(row):
            cx = x0 + W * (ci + 0.5) + (W / 2 if ri == 1 else 0); cy = y0 + Hh / 2 + ri * Hh * 0.75; col = IG.PALETTE[k % len(IG.PALETTE)]; k += 1
            w2, h2 = W / 2 - 5, Hh / 2 - 5
            cv.poly([(cx, cy - h2), (cx + w2, cy - h2 / 2), (cx + w2, cy + h2 / 2), (cx, cy + h2), (cx - w2, cy + h2 / 2), (cx - w2, cy - h2 / 2)], col, name='diagram box')
            tw = w2 * 1.45; bh = _tblock_h(nd, tw, 20, 14, 3, 3)
            _tlabel(cv, nd, cx - tw / 2, cy - bh / 2, tw, 'FFFFFF', 'FFF5F3', fs=20, sfs=14, align='center', maxl=3, smax=3)
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def layout(arch, box=(70, 196, 1460, 576), style='auto'):     # bottom 772 px = 6.43 in: panels and nodes stay clear of the logo
    """arch (crisp) → infographic design {w, h, bg, els, style}: the slide's body region holds the diagram; the title is the slide's own."""
    st = auto_style(arch) if style in (None, '', 'auto') or style not in STYLES else style
    _ICONS.clear()
    if not arch['nodes']: return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': [], 'style': st}
    if not suits(arch, st): st = 'bands'   # a style that does not fit this diagram (a pipeline needs a chain …) keeps the columns
    if st in SMART: box = (box[0], box[1], box[2], box[3] - 56)   # point graphics fill to the edge: keep them clear of the footer logo
    elif st == 'cake': box = (box[0], box[1], box[2], box[3] - 40)   # the tiers fill the height: the last one sat on the footer logo
    special = {'cake': _cake, 'hub': _hub, 'chevron': _chevron, 'sequence': _sequence, 'matrix': _matrix, 'radial': _radial, 'tree': _tree,
               'funnel': _funnel, 'pyramid': _pyramid, 'stairs': _stairs, 'milestones': _milestones, 'quadrant': _quadrant, 'venn': _venn, 'target': _target, 'honeycomb': _honeycomb}
    d = special[st](arch, box) if st in special else _columns(arch, box, st)
    IG.deepen_under_words(d['els'], SLIDE_BG)   # words on a colour seen as dark are white: an orange or pink box under small type goes deep
    IG.readable_icons(d['els'], SLIDE_BG); IG.readable_text(d['els'], SLIDE_BG)   # every word readable on what it sits on (4.5:1, large 3:1)
    d['style'] = st; return d


SYSTEM_ICONS = [   # what a block is, from its name first, then its words: the pictogram that says it (first match wins)
    (r'quick win', 'speed'), (r'big bet', 'target'), (r'fill-?ins?\b', 'puzzle'), (r'\bavoid\b|\bstop\b', 'blocked'),
    (r'\bpos\b|point of sale|\btill\b|checkout', 'barcode'), (r'ulta\.com|\bweb\b|website|e-?commerce|online|\bshop\b', 'add-to-bag'),
    (r'\bapps?\b|mobile', 'mobile'), (r'gateway|\bapis?\b', 'share'), (r'integration|middleware|\besb\b|\bhub\b|ipaas|mulesoft|boomi', 'network'),
    (r'\berp\b|\bsap\b|finance|ledger|accounting', 'layers'), (r'\bwms\b|warehouse management|\bdcs?\b|distribution|fulfil', 'package'),
    (r'\boms\b|\borders?\b', 'receipt'), (r'data ?lake|lakehouse|data warehouse|analytics|\bbi\b|reporting|databricks|snowflake|insight', 'bar-chart'),
    (r'\bcrm\b|loyalty|customer|\bguests?\b|rewards', 'customer-love'), (r'inventory|\bstock\b|replenish', 'shelf'),
    (r'planning|\bplan\b|forecast|demand', 'trend-up'), (r'pric|promo', 'tag'), (r'payment|\bcards?\b|wallet|budget|cost', 'wallet'),
    (r'kafka|queue|events?\b|stream|\bmq\b', 'inbox'), (r'\bitems?\b|product|catalog|master data|\bmdm\b|\bpim\b', 'cube'),
    (r'identity|\bauth|\bsso\b|security|access', 'lock'), (r'e-?mail|notification|messag', 'email'), (r'search', 'search'),
    (r'vendor|supplier|partner', 'team-growth'), (r'deliver|shipping|carrier|logistic|transport', 'delivery'),
    (r'associate|employee|people|\bteams?\b|\bhr\b', 'team'), (r'\bstores?\b|retail', 'stores'), (r'vision|goal|target', 'target'),
    (r'technolog|platform|system', 'laptop-analytics'), (r'business|value|revenue', 'trend-up')]
ICON_SPARE = ['gears', 'layers', 'cube', 'puzzle', 'insight', 'focus', 'sliders', 'performance', 'growth-check', 'star']
_ICONS = {}   # block -> its pictogram, for the diagram being laid out (layout() starts it afresh)


def _icon_for(n):
    """A block's pictogram: the one its name says (ERP, WMS, POS, data lake, quick wins ...), else the one its words say; a block
    whose words say nothing gets one no other block in the diagram has, so blocks never look alike."""
    key = n.get('id') or n['label']
    if key in _ICONS: return _ICONS[key]
    used = set(_ICONS.values()); name = str(n['label']).lower(); text = ' '.join([n['label'], n.get('sub') or ''] + list(n.get('items') or [])).lower()
    ic = n.get('icon') if n.get('icon') and IG.icon_svg(n.get('icon')) else None
    ic = ic or next((i for p_, i in SYSTEM_ICONS if re.search(p_, name)), None) or next((i for p_, i in SYSTEM_ICONS if re.search(p_, text)), None)
    if not ic:
        ic = IG.pick_icon(text)
        if not ic or ic in used: ic = next((x for x in ICON_SPARE if x not in used), 'gears')
    _ICONS[key] = ic
    return ic


def _pill(cv, text, lx, ly, lw, mode, dark=False, centre=False, plain=False):
    """A flow label: a small pill over its line (above a straight line, centred on a lane or an elbow); plain = blue text on the line's tint (cloud reference)."""
    if plain:
        fs = 14; ls = IG.wrap(text, max(80, lw - 8), fs, 'body')[:3]; tw = min(max(lw, 80), max(len(x) for x in ls) * fs * 0.56 + 10); th = len(ls) * fs * 1.2 + 4
        cx = lx + (lw - tw) / 2 if not centre else lx - tw / 2; cy = ly - th - 4 if mode == 'fwd' else ly - th / 2
        cv.rect(cx, cy, tw, th, 'FFFFFF', None, 3, name='diagram label'); cv.text(cx + 2, cy + 2, tw - 4, ls, fs, '5D0F43', 'body', 'center', 1.2, name='diagram label text', src=text); return
    fs = 15; lw = max(lw, max((len(w_) for w_ in str(text).split()), default=4) * fs * 0.6 + 22)   # never narrower than its longest word
    ls = IG.wrap(text, max(60, lw - 12), fs, 'bold')[:3]; tw = min(max(lw, 70), max(len(x) for x in ls) * fs * 0.56 + 16); th = len(ls) * fs * 1.2 + 8
    cx = lx + (lw - tw) / 2 if not centre else lx - tw / 2; cy = ly - th - 6 if mode == 'fwd' else ly - th / 2
    cv.rect(cx, cy, tw, th, DARK2 if dark else 'FFFFFF', None if dark else 'E2D6CF', 8, 1, name='diagram label')
    cv.text(cx + 4, cy + 4, tw - 8, ls, fs, 'FFFFFF' if dark else IG.INK, 'bold', 'center', 1.2, name='diagram label text', src=text)


def _badge(cv, n, x, y, dark=False):
    r = 15; cv.ellipse(x - r, y - r, 2 * r, 2 * r, 'FFFFFF' if dark else IG.INK, None, name='diagram badge')
    cv.text(x - r, y - 9.5, 2 * r, [str(n)], 15, DARK if dark else 'FFFFFF', 'bold', 'center', 1.0, name='diagram badge text', src=str(n))


def _columns(arch, box, st):
    """The column family (bands, outline, pastel, icons, midnight, numbered, bubbles): systems in columns in flow order, routed lines."""
    nodes, flows = arch['nodes'], arch['flows']; cv = IG.Canvas()
    X0, Y0, BW, BH = box
    dark = st == 'midnight'; numbered = st == 'numbered'; bub = st in ('bubbles', 'tech'); cloud = st == 'cloud'; zones = st == 'zones' or (cloud and _cloud_zones(arch))
    if dark: cv.rect(X0 - 24, Y0 - 22, BW + 48, BH + 40, DARK, None, 18, name='diagram panel')
    if cloud:   # a white canvas; without zones, one tinted container holds every system (the architecture-guide look)
        cv.rect(X0 - 24, Y0 - 22, BW + 48, BH + 40, 'FFFFFF', None, 0, name='diagram panel')
        if not zones: cv.rect(X0 - 12, Y0 - 10, BW + 24, BH + 20, CLOUD_Z[0], None, 0, name='diagram zone')
    LW = 290 if numbered else 0
    if numbered: BW = BW - LW - 28
    lay, znames = _zones(arch) if zones else (_layers(nodes, flows), None)
    if not flows and not zones: lay = {n['id']: k for k, n in enumerate(nodes)}   # a list with no arrows (SmartArt-style points) reads left to right, not one stacked column
    ncol = max(lay.values()) + 1
    per_row = ncol if ncol <= 5 else (ncol + 1) // 2; rows = (ncol + per_row - 1) // per_row
    grid = {}
    for n in nodes: grid.setdefault(lay[n['id']], []).append(n['id'])
    pos = {}
    for c in sorted(grid):
        first = list(grid[c])
        def bary(i):
            ps = [pos[f['source']] for f in flows if f['target'] == i and f['source'] in pos] + [pos[f['target']] for f in flows if f['source'] == i and f['target'] in pos]
            return (sum(ps) / len(ps) if ps else first.index(i), first.index(i))
        grid[c] = sorted(first, key=bary)
        for k, i in enumerate(grid[c]): pos[i] = k
    labelled = any(f.get('label') for f in flows) and not numbered
    gap = 132 if labelled else (64 if numbered else 84)
    back_lane = any(lay[f['target']] <= lay[f['source']] for f in flows if lay[f['target']] // per_row == lay[f['source']] // per_row)
    skip_lane = any((lay[f['target']] - lay[f['source']] > 1 or lay[f['target']] < lay[f['source']]) and lay[f['target']] // per_row == lay[f['source']] // per_row for f in flows)   # skips and gutter routes run on the lane above
    lane = 34; row_gap = 70 if rows > 1 else 0
    zt = 46 if zones else 0   # a zone's name above its systems
    row_h = (BH - row_gap * (rows - 1)) / rows - (lane if back_lane else 0) - (lane if skip_lane else 0) - zt
    bw = (BW - gap * (per_row - 1)) / per_row
    by_id = {n['id']: n for n in nodes}; geo = {}; pad = 16
    def measure(n, s):
        fh, fsb, fi = 19 * s, 18 * s, 16.5 * s
        isz = fh * 1.9 if st == 'icons' else 0
        tw_ = bw - 2 * pad
        whole = lambda text, fs, font, w_=bw - 2 * pad: max((len(x) for x in str(text or '').split()), default=0) <= int(w_ / (fs * IG.CW[font]))
        if cloud:   # the icon on the left; the name and its role beside it; points under a hairline
            isz = fh * 1.55; tw_ = bw - 2 * pad - isz - 12 * s; fsc = fsb * 0.92
            hl0 = IG.wrap(n['label'], tw_, fh, 'body'); sl0 = IG.wrap(n['sub'], tw_, fsc, 'body') if n.get('sub') else []
            il0 = [IG.wrap('• ' + it, tw_, fi, 'body') for it in n.get('items') or []]; il = [x[:3] for x in il0]
            head_h = max(isz, len(hl0[:3]) * fh * 1.22 + len(sl0[:2]) * fsc * 1.25) + 22 * s
            need = head_h + (10 * s + sum(len(x) for x in il) * fi * 1.3 + 6 * s * len(il) + 8 * s if il else 0)
            ok = whole(n['label'], fh, 'body', tw_) and len(hl0) <= 3 and (not n.get('sub') or (whole(n['sub'], fsc, 'body', tw_) and len(sl0) <= 2)) and all(whole(it, fi, 'body', tw_) and len(x) <= 3 for it, x in zip(n.get('items') or [], il0))
            return dict(fh=fh, fsb=fsc, fi=fi, hl=hl0[:3], sl=sl0[:2], il=il, head_h=head_h, need=need, ok=ok, D=0, isz=isz)
        if bub:
            D = min(126 * s, bw * 0.62); hl0 = IG.wrap(n['label'], bw - 8, fh, 'bold'); sl0 = IG.wrap(n['sub'], bw - 8, fsb * 0.9, 'body') if n.get('sub') else []
            need = D + 12 * s + len(hl0[:2]) * fh * 1.22 + len(sl0[:2]) * fsb * 0.9 * 1.25
            ok = whole(n['label'], fh, 'bold', bw - 8) and len(hl0) <= 2 and len(sl0) <= 2
            return dict(fh=fh, fsb=fsb * 0.9, fi=fi, hl=hl0[:2], sl=sl0[:2], il=[], head_h=0, need=need, ok=ok, D=D, isz=0)
        hl0 = IG.wrap(n['label'], tw_, fh, 'bold'); hl = hl0[:3]; head_h = len(hl) * fh * 1.22 + (isz + 10 * s if isz else 0) + 18 * s
        sl0 = IG.wrap(n['sub'], bw - 2 * pad, fsb, 'bold') if n.get('sub') else []; sl = sl0[:2]
        il0 = [IG.wrap('• ' + it, bw - 2 * pad, fi, 'body') for it in n.get('items') or []]; il = [x[:3] for x in il0]
        ok = (whole(n['label'], fh, 'bold', tw_) and len(hl0) <= 3 and (not n.get('sub') or (whole(n['sub'], fsb, 'bold') and len(sl0) <= 2))
              and all(whole(it, fi, 'body') and len(x) <= 3 for it, x in zip(n.get('items') or [], il0)))
        empty = not n.get('sub') and not n.get('items')
        need = head_h if empty else max(head_h + 12 * s + len(sl) * fsb * 1.25 + (8 * s if sl and il else 0) + sum(len(x) for x in il) * fi * 1.3 + 6 * s * len(il) + 14 * s, 96 * s)
        return dict(fh=fh, fsb=fsb, fi=fi, hl=hl, sl=sl, il=il, head_h=head_h, need=need, ok=ok, D=0, isz=isz)
    vgap = 26
    def fits(s):
        for c, ids in grid.items():
            k = len(ids); h_each = (row_h - vgap * (k - 1)) / k
            if any(m['need'] > h_each or not m['ok'] for m in (measure(by_id[i], s) for i in ids)): return False
        return True
    scale = next((s for s in ((1.1, 1.04, 1.0, 0.94, 0.88, 0.82, 0.76, 0.7) if cloud else (1.5, 1.42, 1.34, 1.26, 1.18, 1.1, 1.04, 1.0, 0.94, 0.88, 0.82, 0.76, 0.7)) if fits(s)), 0.7)   # cloud reference: compact cards, as in the guides
    row_need = {}
    for c, ids in grid.items():
        r = c // per_row; row_need[r] = max([row_need.get(r, 0)] + [measure(by_id[i], scale)['need'] for i in ids if len(ids) == 1])
    band = {}
    for c, ids in grid.items():
        r, p = divmod(c, per_row)
        x = X0 + p * (bw + gap); top = Y0 + r * (row_h + row_gap + zt + (lane if back_lane else 0) + (lane if skip_lane else 0)) + (lane if skip_lane else 0) + zt
        k = len(ids); h_each = (row_h - vgap * (k - 1)) / k
        if zones and cloud:   # flat tinted zone, square corners, its name in dark grey at the top left
            cv.rect(x - 16, top - zt - 4, bw + 32, row_h + zt + 22, CLOUD_Z[c % len(CLOUD_Z)], None, 0, name='diagram zone')
            cv.text(x - 4, top - zt + 6, bw + 8, [znames[c]], 18, CLOUD_MUTED, 'bold', name='diagram zone title', src=znames[c])
        elif zones:   # the zone: a soft container with its name, the systems inside
            cv.rect(x - 16, top - zt - 4, bw + 32, row_h + zt + 22, 'F8F5F5', 'D9D9D9', 16, 1.2, name='diagram zone')
            cv.text(x - 4, top - zt + 8, bw + 8, [znames[c]], 18, IG.TITLE, 'bold', name='diagram zone title', src=znames[c])
        for j, i in enumerate(ids):
            n = by_id[i]; m = measure(n, scale); empty = not n.get('sub') and not n.get('items')
            col = IG.PALETTE[c % len(IG.PALETTE)]
            if bub:
                h = m['need']; y = top + j * (h_each + vgap) + (h_each - h) / 2; D = m['D']; cxm = x + bw / 2
                geo[i] = (cxm - D / 2, y, D, D); b_ = band.setdefault(r, [y, y + h]); b_[0] = min(b_[0], y); b_[1] = max(b_[1], y + h)
                if st == 'tech': _shape(cv, kind_of(n), cxm - D / 2, y, D, col)
                else:
                    cv.ellipse(cxm - D / 2, y, D, D, col, None, name='diagram box')
                    cv.icon(_icon_for(n), cxm - D * 0.29, y + D * 0.21, D * 0.58, 'FFFFFF', bold=True)
                yy = y + D + 10 * scale
                yy += cv.text(x + 4, yy, bw - 8, m['hl'], m['fh'], IG.INK, 'bold', 'center', 1.22, name='diagram system', src=n['label'])
                if m['sl']: cv.text(x + 4, yy + 2, bw - 8, m['sl'], m['fsb'], IG.MUTED, 'body', 'center', 1.25, name='diagram sub', src=n['sub'])
                continue
            h = min(h_each, m['need'] if empty else max(m['need'], row_need.get(r, 0) if k == 1 else m['need'])); y = top + j * (h_each + vgap) + (h_each - h) / 2
            geo[i] = (x, y, bw, h); b_ = band.setdefault(r, [y, y + h]); b_[0] = min(b_[0], y); b_[1] = max(b_[1], y + h)
            head_c, sub_c, item_c = 'FFFFFF', IG.INK, IG.MUTED
            if cloud:   # white card, thin grey border, square corners; a blue pictogram; name + role beside it; points under a hairline
                cv.rect(x, y, bw, h, 'FFFFFF', CLOUD_BORDER, 0, 1.2, name='diagram box')
                ix = x + pad; iy = y + 11 * scale; cv.icon(_icon_for(n), ix, iy, m['isz'], CLOUD_LINE)
                tx = ix + m['isz'] + 12 * scale; tw2 = x + bw - pad - tx; yy = y + 11 * scale
                yy += cv.text(tx, yy, tw2, m['hl'], m['fh'], '202124', 'body', lh=1.22, name='diagram system', src=n['label'])
                if m['sl']: cv.text(tx, yy, tw2, m['sl'], m['fsb'], CLOUD_MUTED, 'body', lh=1.25, name='diagram sub', src=n['sub'])
                if m['il']:
                    yl = y + m['head_h'] - 6 * scale; cv.line(tx, yl, x + bw - pad, yl, 'D9D9D9', 1, name='diagram rule'); yy = yl + 10 * scale
                    for it, ls in zip(n.get('items') or [], m['il']):
                        if yy + len(ls) * m['fi'] * 1.3 > y + h - 6: break
                        yy += cv.text(tx, yy, tw2, ls, m['fi'], IG.INK, 'body', lh=1.3, name='diagram point', src='• ' + it) + 6 * scale
                continue
            if st in ('bands', 'zones') or (empty and st in ('numbered',)):
                if empty: cv.rect(x, y, bw, h, col, None, 12, name='diagram box')
                else:
                    cv.rect(x, y, bw, h, 'FFFFFF', 'E2D6CF', 12, 1.5, name='diagram box'); cv.rect(x, y, bw, m['head_h'], col, None, 12, name='diagram head')
                    cv.rect(x, y + m['head_h'] - 12, bw, 12, col, None, 0, name='diagram head')
            elif st == 'numbered':
                cv.rect(x, y, bw, h, 'FFFFFF', 'D9CEC8', 6, 1.5, name='diagram box'); cv.rect(x, y, bw, m['head_h'], IG.INK, None, 6, name='diagram head')
                cv.rect(x, y + m['head_h'] - 6, bw, 6, IG.INK, None, 0, name='diagram head'); cv.rect(x, y, 8, m['head_h'], col, None, 0, name='diagram accent')
            elif st == 'outline':
                cv.rect(x, y, bw, h, 'FFFFFF', col, 12, 3, name='diagram box'); head_c = IG.shade(col, 0.12)
                if not empty: cv.line(x + pad, y + m['head_h'] - 2, x + bw - pad, y + m['head_h'] - 2, IG.tint(col, 0.55), 1.5, name='diagram rule')
            elif st == 'pastel':
                cv.rect(x, y, bw, h, IG.tint(col, 0.86), None, 16, name='diagram box'); head_c = IG.shade(col, 0.28)
            elif st == 'icons':
                cv.rect(x, y, bw, h, 'FFFFFF', 'E2D6CF', 14, 1.5, name='diagram box'); head_c = IG.INK
                cv.rect(x, y, bw, 7, col, None, 0, name='diagram accent')
            elif st == 'midnight':
                cv.rect(x, y, bw, h, DARK2, None, 12, name='diagram box'); cv.rect(x, y, bw, 6, col, None, 0, name='diagram accent')
                head_c, sub_c, item_c = 'FFFFFF', 'F9E3DE', 'CFC3BC'
            tx = x + pad
            ty = y + 9 * scale
            if m['isz']:
                cv.ellipse(x + pad, y + 14 * scale, m['isz'], m['isz'], col, None, name='diagram icon badge')
                cv.icon(_icon_for(n), x + pad + m['isz'] * 0.18, y + 14 * scale + m['isz'] * 0.18, m['isz'] * 0.64, 'FFFFFF', bold=True); ty = y + 14 * scale + m['isz'] + 10 * scale
            cv.text(tx, ty, x + bw - pad - tx, m['hl'], m['fh'], head_c, 'bold', lh=1.22, name='diagram system', src=n['label'])
            yy = y + m['head_h'] + 12 * scale
            if m['sl']: yy += cv.text(x + pad, yy, bw - 2 * pad, m['sl'], m['fsb'], sub_c, 'bold', lh=1.25, name='diagram sub', src=n['sub']) + (8 * scale if m['il'] else 0)
            for it, ls in zip(n.get('items') or [], m['il']):
                if yy + len(ls) * m['fi'] * 1.3 > y + h - 6: break
                yy += cv.text(x + pad, yy, bw - 2 * pad, ls, m['fi'], item_c, 'body', lh=1.3, name='diagram point', src='• ' + it) + 6 * scale
    lc = 'B9AFA9' if dark else (CLOUD_LINE if cloud else LINE_C); sw = 1.8 if cloud else 2.6
    side_use = {}
    def port(i, side, key): side_use.setdefault((i, side), []).append(key)
    for f in flows:
        s, t = f['source'], f['target']; cs, ct = lay[s], lay[t]; same_row = cs // per_row == ct // per_row
        if same_row and ct == cs: f['_route'] = 'vert' if abs(pos[s] - pos[t]) == 1 else 'side'; continue   # one zone / column: straight to a neighbour, round the side past a box between
        if same_row and ct == cs + 1: port(s, 'R', id(f)); port(t, 'L', id(f)); f['_route'] = 'fwd'
        elif same_row and ct > cs + 1 and pos[s] == 0 and pos[t] == 0: port(s, 'T', id(f)); port(t, 'T', id(f)); f['_route'] = 'over'
        elif same_row and ct < cs and pos[s] == len(grid[cs]) - 1 and pos[t] == len(grid[ct]) - 1: port(s, 'B', id(f)); port(t, 'B', id(f)); f['_route'] = 'under'
        elif same_row: port(s, 'R' if ct > cs else 'L', id(f)); port(t, 'L' if ct > cs else 'R', id(f)); f['_route'] = 'gut'   # a box above (or below) would be crossed: out to the gutter, along the lane, in from the gutter
        elif ct > cs:   # down to a later row: out of the bottom unless a box sits below in the column, then out of the side into the gutter (never through a box)
            f['_ss'] = 'B' if pos[s] == len(grid[cs]) - 1 else 'R'; f['_ts'] = 'T' if pos[t] == 0 else 'L'
            port(s, f['_ss'], id(f)); port(t, f['_ts'], id(f)); f['_route'] = 'down'
        else:
            f['_ss'] = 'T' if pos[s] == 0 else 'R'; f['_ts'] = 'B' if pos[t] == len(grid[ct]) - 1 else 'L'
            port(s, f['_ss'], id(f)); port(t, f['_ts'], id(f)); f['_route'] = 'up'   # back to an earlier row (a loop closing): top of the source to the bottom of the target
    other = {}
    for f in flows: other[(f['source'], id(f))] = f['target']; other[(f['target'], id(f))] = f['source']
    for (i, side), ks in side_use.items():
        ks.sort(key=lambda key: (geo[other[(i, key)]][1] + geo[other[(i, key)]][3] / 2) if side in 'LR' else (geo[other[(i, key)]][0] + geo[other[(i, key)]][2] / 2))
    def pt(i, side, key):
        x, y, w, h = geo[i]; ks = side_use[(i, side)]; k = ks.index(key); n = len(ks); frac = (k + 1) / (n + 1)
        if bub and side in 'LR': return (x if side == 'L' else x + w), y + h / 2 + (k - (n - 1) / 2) * min(18, h / (n + 1))
        if side == 'L': return x, y + h * (0.5 if n == 1 else 0.25 + 0.5 * k / max(1, n - 1))
        if side == 'R': return x + w, y + h * (0.5 if n == 1 else 0.25 + 0.5 * k / max(1, n - 1))
        if side == 'T': return x + w * frac, y
        return x + w * frac, y + h
    labels = []
    for num, f in enumerate(flows, 1):
        s, t, key = f['source'], f['target'], id(f); r = f['_route']
        if r == 'side':   # round the column's margin (the side with fewer lines arriving), never through the box in between
            (sx, sy, sw_, sh_), (tx, ty, tw_, th_) = geo[s], geo[t]; col_ = lay[s]; lo, hi_ = sorted((pos[s], pos[t]))
            mids = [i for i in grid[col_] if lo < pos[i] < hi_]
            useL = sum(len(side_use.get((i, 'L'), [])) for i in mids); useR = sum(len(side_use.get((i, 'R'), [])) for i in mids)
            right = useR < useL; xl = max(sx + sw_, tx + tw_) + 11 if right else min(sx, tx) - 11; ex = (lambda g: g[0] + g[2]) if right else (lambda g: g[0])
            pts = [(ex(geo[s]), sy + sh_ / 2), (xl, sy + sh_ / 2), (xl, ty + th_ / 2), (ex(geo[t]), ty + th_ / 2)]
            lx, ly, lw = (xl + 48 if right else xl - 48) - 60, (sy + ty) / 2 + (sh_ + th_) / 4, 120; r = 'mid'   # the label in the gutter beside the lane
        elif r == 'vert':
            (sx, sy, sw_, sh_), (tx, ty, tw_, th_) = geo[s], geo[t]; xv = sx + sw_ / 2
            pts = [(xv, sy + sh_), (xv, ty)] if sy < ty else [(xv, sy), (xv, ty + th_)]
            lx, ly, lw = xv - 75, (pts[0][1] + pts[1][1]) / 2, 150; r = 'mid'
        elif r == 'fwd':
            (x1, y1), (x2, y2) = pt(s, 'R', key), pt(t, 'L', key)
            if abs(y1 - y2) < 3: pts = [(x1, y1), (x2, y1)]; lx, ly, lw = x1 + 6, y1, x2 - x1 - 12
            else: xm = (x1 + x2) / 2; pts = [(x1, y1), (xm, y1), (xm, y2), (x2, y2)]; lx, ly, lw = x1 + 6, (y1 + y2) / 2, x2 - x1 - 12; r = 'mid'
        elif r == 'over':
            (x1, y1), (x2, y2) = pt(s, 'T', key), pt(t, 'T', key); ly_ = band[lay[s] // per_row][0] - lane * 0.62
            pts = [(x1, y1), (x1, ly_), (x2, ly_), (x2, y2)]; lx, ly, lw = min(x1, x2) + 20, ly_, abs(x2 - x1) - 40
        elif r == 'under':
            (x1, y1), (x2, y2) = pt(s, 'B', key), pt(t, 'B', key); ly_ = band[lay[s] // per_row][1] + lane * 0.62
            pts = [(x1, y1), (x1, ly_), (x2, ly_), (x2, y2)]; lx, ly, lw = min(x1, x2) + 20, ly_, abs(x2 - x1) - 40
        elif r == 'gut':
            fwd_ = lay[t] > lay[s]; (x1, y1), (x2, y2) = pt(s, 'R' if fwd_ else 'L', key), pt(t, 'L' if fwd_ else 'R', key)
            colx = lambda c, right: (max if right else min)((geo[i][0] + geo[i][2]) if right else geo[i][0] for i in grid[c])
            gx1 = colx(lay[s], fwd_) + (14 if fwd_ else -14); gx2 = colx(lay[t], not fwd_) + (-14 if fwd_ else 14)
            ly_ = band[lay[s] // per_row][0] - lane * 0.62
            pts = [(x1, y1), (gx1, y1), (gx1, ly_), (gx2, ly_), (gx2, y2), (x2, y2)]; lx, ly, lw = min(gx1, gx2) + 20, ly_, abs(gx2 - gx1) - 40
        elif r in ('up', 'down'):
            ss, ts = f.get('_ss') or ('T' if r == 'up' else 'B'), f.get('_ts') or ('B' if r == 'up' else 'T')
            (x1, y1), (x2, y2) = pt(s, ss, key), pt(t, ts, key)
            rs_, rt_ = lay[s] // per_row, lay[t] // per_row
            if r == 'up': ym = (band[rt_][1] + band[rs_][0]) / 2 + 16 if rt_ < rs_ and rt_ in band and rs_ in band else (y1 + y2) / 2   # its own lane, below the downward lines'
            else: ym = (band[rs_][1] + band[rt_][0]) / 2 if rt_ > rs_ and rt_ in band else (y1 + y2) / 2
            colR = lambda c: max(geo[i][0] + geo[i][2] for i in grid[c]) + 14; colL = lambda c: min(geo[i][0] for i in grid[c]) - 14
            head = [(x1, y1), (x1, ym)] if ss in 'TB' else [(x1, y1), (colR(lay[s]), y1), (colR(lay[s]), ym)]
            tail = [(x2, ym), (x2, y2)] if ts in 'TB' else [(colL(lay[t]), ym), (colL(lay[t]), y2), (x2, y2)]
            pts = head + tail; xs_ = [p_[0] for p_ in pts]; lx, ly, lw = min(xs_) + 20, ym, max(120, max(xs_) - min(xs_) - 40)
        for k in range(len(pts) - 1):
            (a1, b1), (a2, b2) = pts[k], pts[k + 1]
            cv.line(a1, b1, a2, b2, lc, sw, dash=bool(cloud and re.search(r'backup|async|replicat|batch|snapshot', str(f.get('label') or ''), re.I)), name='diagram flow', arrow=(k == len(pts) - 2), arrow_start=(k == 0 and bool(f.get('both'))))
        if numbered: labels.append((num, lx + lw / 2, ly if r != 'fwd' else ly))
        elif f.get('label'): labels.append((f['label'], lx, ly, lw, r))
    if numbered:
        nm = {n['id']: n['label'] for n in nodes}
        for num, bx, by in labels: _badge(cv, num, bx, by)
        lx0 = X0 + BW + 28; cv.rect(lx0, Y0, LW, BH, 'F8F5F5', 'D9D9D9', 12, 1, name='diagram legend')
        cv.text(lx0 + 18, Y0 + 16, LW - 36, ['Flows'], 20, IG.TITLE, 'bold', name='diagram legend title', src='Flows')
        yy = Y0 + 52; fsL = 14.5
        for num, f in enumerate(flows, 1):
            txt = f'{nm.get(f["source"], "?")} {"⇄" if f.get("both") else "→"} {nm.get(f["target"], "?")}' + (f' - {f["label"]}' if f.get('label') else '')
            ls = IG.wrap(txt, LW - 100, fsL, 'body')[:3]   # wrapped narrower than the box: PowerPoint never adds a line the layout did not count
            if yy + len(ls) * fsL * 1.3 > Y0 + BH - 10: break
            _badge(cv, num, lx0 + 32, yy + 10)
            yy += max(cv.text(lx0 + 56, yy, LW - 76, ls, fsL, IG.INK, 'body', lh=1.3, name='diagram legend item', src=txt), len(ls) * fsL * 1.3) + 16
    else:
        for text, lx, ly, lw, r in labels: _pill(cv, text, lx, ly, lw, r, dark=dark, plain=cloud)
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _cake(arch, box):
    """Layer cake: one tier per column of the flow, stacked top to bottom - the tier's name in a brand block on the left, its system
    and points as chips across; the flows between neighbouring tiers are short labelled arrows down the gutter."""
    nodes, flows = arch['nodes'], arch['flows']; cv = IG.Canvas(); X0, Y0, BW, BH = box
    lay = _layers(nodes, flows); tiers = {}
    for n in nodes: tiers.setdefault(lay[n['id']], []).append(n)
    T = len(tiers); gapT = 40 if any(f.get('label') for f in flows) else 26; th = (BH - gapT * (T - 1)) / T
    other_lane = any(abs(lay[f['target']] - lay[f['source']]) != 1 for f in flows)
    W = BW - (46 if other_lane else 0); LB = 300; top = {}
    for t_, (c, ns) in enumerate(sorted(tiers.items())):
        y = Y0 + t_ * (th + gapT); col = IG.PALETTE[c % len(IG.PALETTE)]; top[c] = y
        cv.rect(X0, y, W, th, IG.tint(col, 0.9), None, 14, name='diagram tier')
        cv.rect(X0, y, LB, th, col, None, 14, name='diagram tier head'); cv.rect(X0 + LB - 14, y, 14, th, col, None, 0, name='diagram tier head')
        label = ns[0]['label'] if len(ns) == 1 else ' · '.join(n['label'] for n in ns)
        fs = 22 if th >= 90 else 18; ls = IG.wrap(label, LB - 36, fs, 'bold')[:3]
        while len(ls) * fs * 1.2 > th - 12 and fs > 13: fs -= 1; ls = IG.wrap(label, LB - 36, fs, 'bold')[:3]
        cv.text(X0 + 18, y + (th - len(ls) * fs * 1.2) / 2, LB - 36, ls, fs, 'FFFFFF', 'bold', lh=1.2, name='diagram system', src=label)
        chips = ([n['sub'] for n in ns if n.get('sub')] if len(ns) == 1 else []) + [it for n in ns for it in (n.get('items') or [])] if len(ns) == 1 else [n.get('sub') or n['label'] for n in ns]
        cx = X0 + LB + 22; fsC = 17 if th >= 80 else 15; ch = fsC * 1.9; cy = y + (th - ch) / 2; rowsC = [[]]; xx = cx
        for k, chip in enumerate(chips):
            cw = len(chip) * fsC * 0.55 + 30
            if xx + cw > X0 + W - 16: rowsC.append([]); xx = cx
            rowsC[-1].append((chip, xx, cw, k == 0 and len(ns) == 1 and bool(ns[0].get('sub')))); xx += cw + 12
        rowsC = [r for r in rowsC if r][:max(1, int((th - 12) // (ch + 8)))]
        cy = y + (th - len(rowsC) * (ch + 8) + 8) / 2
        for r_ in rowsC:
            for chip, xx, cw, strong in r_:
                cv.rect(xx, cy, cw, ch, col if strong else 'FFFFFF', None if strong else IG.tint(col, 0.6), ch / 2, 1.2, name='diagram chip')
                cv.text(xx, cy + (ch - fsC * 1.15) / 2, cw, [chip], fsC, 'FFFFFF' if strong else IG.INK, 'bold' if strong else 'body', 'center', 1.15, name='diagram point', src=chip)
            cy += ch + 8
    pairs = {}
    for f in flows:
        cs, ct = lay[f['source']], lay[f['target']]
        if abs(ct - cs) == 1:
            p = pairs.setdefault((min(cs, ct), max(cs, ct)), {'down': False, 'up': False, 'labels': []})
            p['down' if ct > cs else 'up'] = True; p['both'] = f.get('both')
            if f.get('label') and f['label'] not in p['labels']: p['labels'].append(f['label'])
    for (a, b), p in pairs.items():   # one arrow between two tiers, its labels together beside it
        ax = X0 + LB / 2; y1 = top[a] + th; y2 = top[b]
        cv.line(ax, y1, ax, y2, LINE_C, 2.6, name='diagram flow', arrow=p['down'] or not p['up'], arrow_start=p['up'] or bool(p.get('both')))
        if p['labels']:
            lab = ' · '.join(p['labels']); ls = IG.wrap(lab, 520, 15, 'bold')[:2]
            cv.text(ax + 14, (y1 + y2) / 2 - len(ls) * 9, 520, ls, 15, IG.INK, 'bold', lh=1.2, name='diagram label text', src=lab)
    for f in flows:
        cs, ct = lay[f['source']], lay[f['target']]
        if abs(ct - cs) == 1: continue
        if True:   # a tier skipped or a flow back up: down the right-hand lane
            lx = X0 + W + 24; ya = top[cs] + th / 2; yb = top[ct] + th / 2
            cv.line(X0 + W, ya, lx, ya, LINE_C, 2.6, name='diagram flow'); cv.line(lx, ya, lx, yb, LINE_C, 2.6, name='diagram flow')
            cv.line(lx, yb, X0 + W, yb, LINE_C, 2.6, name='diagram flow', arrow=True)
            if f.get('label'): _pill(cv, f['label'], lx, (ya + yb) / 2, 170, 'mid', centre=True)
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _hub(arch, box):
    """Hub & spoke: the best-connected system in the middle; systems that only send sit left, only receive right, both above / below."""
    nodes, flows = arch['nodes'], arch['flows']; cv = IG.Canvas(); X0, Y0, BW, BH = box
    deg = _degree(arch); hub = max(nodes, key=lambda n: (deg[n['id']], -nodes.index(n)))['id']; by = {n['id']: n for n in nodes}
    sides = {'L': [], 'R': [], 'T': [], 'B': []}
    for n in nodes:
        if n['id'] == hub: continue
        to_hub = any(f['source'] == n['id'] and f['target'] == hub for f in flows); from_hub = any(f['source'] == hub and f['target'] == n['id'] for f in flows)
        sides['L' if to_hub and not from_hub else 'R' if from_hub and not to_hub else ('T' if len(sides['T']) <= len(sides['B']) else 'B')].append(n['id'])
    for a, b in (('L', 'R'), ('R', 'L')):   # keep the picture balanced: a long side gives one to the short one via top / bottom
        while len(sides[a]) > len(sides[b]) + 2 and len(sides[a]) > 3: sides['T' if len(sides['T']) <= len(sides['B']) else 'B'].append(sides[a].pop())
    sw_, sh_ = 270, 96; hw, hh = 330, 150; cx, cy = X0 + BW / 2, Y0 + BH / 2; geo = {}
    geo[hub] = (cx - hw / 2, cy - hh / 2, hw, hh)
    def column(ids, x):
        n = len(ids)
        for k, i in enumerate(ids):
            y = Y0 + (BH - n * sh_) / (n + 1) * (k + 1) + k * sh_; geo[i] = (x, y, sw_, sh_)
    column(sides['L'], X0); column(sides['R'], X0 + BW - sw_)
    for key_, yy in (('T', Y0), ('B', Y0 + BH - sh_ + 10)):
        n = len(sides[key_]); span = BW - 2 * sw_ - 140
        for k, i in enumerate(sides[key_]): geo[i] = (X0 + sw_ + 70 + span * (k + 0.5) / n - sw_ / 2, yy - (24 if key_ == 'T' else 0), sw_, sh_ - 14)
    def edge_pt(i, tx, ty):   # where the line from the box centre towards (tx, ty) leaves the box
        x, y, w, h = geo[i]; mx, my = x + w / 2, y + h / 2; dx, dy = tx - mx, ty - my
        if dx == 0 and dy == 0: return mx, my
        sx = (w / 2) / abs(dx) if dx else 1e9; sy = (h / 2) / abs(dy) if dy else 1e9; s = min(sx, sy); return mx + dx * s, my + dy * s
    labels = []
    for f in flows:
        a, b = geo[f['source']], geo[f['target']]
        ac, bc = (a[0] + a[2] / 2, a[1] + a[3] / 2), (b[0] + b[2] / 2, b[1] + b[3] / 2)
        p1 = edge_pt(f['source'], *bc); p2 = edge_pt(f['target'], *ac)
        cv.line(p1[0], p1[1], p2[0], p2[1], LINE_C, 2.6, name='diagram flow', arrow=True, arrow_start=bool(f.get('both')))
        if f.get('label'):
            sp, hp = (p1, p2) if f['target'] == hub else (p2, p1)   # nearer the spoke: the lines converge on the hub
            labels.append((f['label'], sp[0] + (hp[0] - sp[0]) * 0.4, sp[1] + (hp[1] - sp[1]) * 0.4))
    for i, (x, y, w, h) in geo.items():
        n = by[i]; c = nodes.index(n); col = IG.TITLE if i == hub else IG.PALETTE[c % len(IG.PALETTE)]
        if i == hub:
            cv.rect(x, y, w, h, col, None, 22, name='diagram box')
            cv.icon(_icon_for(n), x + 22, y + h / 2 - 30, 60, 'FFFFFF', bold=True)
            ls = IG.wrap(n['label'], w - 120, 26, 'bold')[:2]; sub = IG.wrap(n.get('sub') or '', w - 120, 17, 'body')[:2]
            th_ = len(ls) * 26 * 1.15 + (len(sub) * 17 * 1.25 + 4 if sub else 0); yy = y + (h - th_) / 2
            yy += cv.text(x + 98, yy, w - 116, ls, 26, 'FFFFFF', 'bold', lh=1.15, name='diagram system', src=n['label'])
            if sub: cv.text(x + 98, yy + 4, w - 116, sub, 17, 'FFFFFF', 'body', lh=1.25, name='diagram sub', src=n['sub'])
        else:
            cv.rect(x, y, w, h, 'FFFFFF', IG.tint(col, 0.45), 14, 2, name='diagram box'); cv.rect(x, y, 8, h, col, None, 0, name='diagram accent')
            ls = IG.wrap(n['label'], w - 40, 19, 'bold')[:2]; sub = IG.wrap(n.get('sub') or (n.get('items') or [''])[0], w - 40, 15, 'body')[:2]
            th_ = len(ls) * 19 * 1.2 + (len(sub) * 15 * 1.25 + 4 if sub and sub[0] else 0); yy = y + (h - th_) / 2
            yy += cv.text(x + 24, yy, w - 40, ls, 19, IG.INK, 'bold', lh=1.2, name='diagram system', src=n['label'])
            if sub and sub[0]: cv.text(x + 24, yy + 4, w - 40, sub, 15, IG.MUTED, 'body', lh=1.25, name='diagram sub', src=' '.join(sub))
    for text, mx, my in labels: _pill(cv, text, mx, my, 150, 'mid', centre=True)
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _chevron(arch, box):
    """Chevron pipeline (a chain): one chevron per system across the slide, the system's name in it; its detail in a column beneath;
    the flow's label over the join."""
    nodes, flows = arch['nodes'], arch['flows']; cv = IG.Canvas(); X0, Y0, BW, BH = box
    lay = _layers(nodes, flows); order = sorted(nodes, key=lambda n: lay[n['id']]); n = len(order)
    lab = {(f['source'], f['target']): f.get('label') or '' for f in flows}
    d = 34; ov = 10; cw = (BW + (n - 1) * (d - ov)) / n; ch = 118; top = Y0 + 64; fs0 = 21
    if not any(nd.get('sub') or nd.get('items') for nd in nodes): ch = 150; top = Y0 + (BH - ch) / 2 - 20; fs0 = 30   # no detail under the chevrons: the pipeline sits in the middle, a little taller, its names larger
    for k, nd in enumerate(order):
        x = X0 + k * (cw - d + ov); col = IG.PALETTE[k % len(IG.PALETTE)]
        pts = [(x, top), (x + cw - d, top), (x + cw, top + ch / 2), (x + cw - d, top + ch), (x, top + ch)] + ([(x + d, top + ch / 2)] if k else [])
        cv.poly(pts, col, name='diagram box')
        inner = cw - d - (d if k else 0) - 16; fs = fs0; ls = IG.wrap(nd['label'], inner, fs, 'bold')
        while (len(ls) > 3 or max(len(w_) for w_ in nd['label'].split()) > int(inner / (fs * IG.CW['bold']))) and fs > 13: fs -= 1; ls = IG.wrap(nd['label'], inner, fs, 'bold')
        cv.text(x + (d if k else 0) + 10, top + (ch - len(ls[:3]) * fs * 1.18) / 2, inner, ls[:3], fs, 'FFFFFF', 'bold', 'center', 1.18, name='diagram system', src=nd['label'])
        cx0 = x + (d if k else 0) + 4; colw = cw - d - (d if k else 0) + 4; yy = top + ch + 24
        if nd.get('sub'):
            sl = IG.wrap(nd['sub'], colw, 18, 'bold')[:2]; yy += cv.text(cx0, yy, colw, sl, 18, IG.INK, 'bold', lh=1.25, name='diagram sub', src=nd['sub']) + 8
        for it in nd.get('items') or []:
            il = IG.wrap('• ' + it, colw, 16, 'body')[:3]
            if yy + len(il) * 16 * 1.3 > Y0 + BH: break
            yy += cv.text(cx0, yy, colw, il, 16, IG.MUTED, 'body', lh=1.3, name='diagram point', src='• ' + it) + 6
        if k:
            t_ = lab.get((order[k - 1]['id'], nd['id'])) or lab.get((nd['id'], order[k - 1]['id'])) or ''
            if t_: _pill(cv, t_, x + d / 2 - 2, top - 30, min(150, cw - 20), 'mid', centre=True)
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


# ------------------------------------------------------------------------------------------------ v5.1: six more ways to read it
KIND_WORDS = [   # first match wins: what a system is, from its own words (zones and technical shapes)
    ('user', r'\b(associates?|customers?|shoppers?|guests?|users?|managers?|leads?|store team|planners?|people|persona)\b'),
    ('queue', r'\b(kafka|event(s|ing)?|queue|topics?|pub/?sub|mq|message bus|event bus|ksqldb|eventing)\b'),
    ('db', r'\b(database|db|data ?lake|datastore|data store|staging|cache|redis|sql|snowflake|bigquery|hana db|lakehouse|warehouse \(data\))\b'),
    ('gateway', r'\b(api|apis|gateway|apigee|esb|cpi|btp|integration|middleware|mulesoft|tibco|orchestration|rithum|boomi|ipaas)\b'),
    ('cloud', r'\b(saas|salesforce|tiktok|amazon|shopify|amplience|google|azure|aws|cloud|marketplace|social)\b'),
]
ZONE_WORDS = [   # left to right: where a system sits in a landscape
    ('Channels', r'\b(store|stores|pos|handheld|mia|app|apps|mobile|web|site|tiktok|shop|marketplace|customer|channel|ecom|e-com|swift|bank|banks|edi|supplier|suppliers|vendor|vendors|partner|partners|payment network|card network|website|storefront|dotcom|ecommerce|e-commerce)\b|\w\.com\b'),   # v6.12: entry points incl. external networks; v6.13: a web address (Ulta.com) is a channel
    ('Integration', r'\b(api|apis|gateway|apigee|esb|cpi|btp|integration|middleware|mulesoft|tibco|kafka|event|orchestration|rithum|flink|boomi)\b'),
    ('Data & consumers', r'\b(report|reporting|analytics|bi|data|lake|downstream|consumers?|atp|availability|replenishment|insight|dashboard)\b'),
    ('Core systems', r'\b(sap|s/4|s4|erp|oms|wms|wmos|pim|core|record|finance|inventory|ledger|crm|hana|aatp|gatp|sterling|manhattan|o9|blue yonder|ewm|car)\b'),   # v6.12: retail system names
]


def kind_of(n):
    t = ' '.join([n['label'], n.get('sub') or ''] + list(n.get('items') or [])[:1]).lower()
    return next((k for k, rx in KIND_WORDS if re.search(rx, t)), 'app')


def zone_of(n):
    t = ' '.join([n['label'], n.get('sub') or '']).lower()
    return next((z for z, rx in ZONE_WORDS if re.search(rx, t)), 'Core systems')


def _cloud_zones(arch):
    """Cloud reference uses zones only when they keep the reading order: two zones or more and every line runs forward (or within a zone)."""
    lay, used = _zones(arch)
    return len(used) >= 2 and not is_chain(arch) and all(lay[f['target']] >= lay[f['source']] for f in arch['flows'])


def _zones(arch):
    order = [z for z, _ in ZONE_WORDS]; order = ['Channels', 'Integration', 'Core systems', 'Data & consumers']
    got = {n['id']: zone_of(n) for n in arch['nodes']}; used = [z for z in order if z in got.values()]
    return {i: used.index(z) for i, z in got.items()}, used


def _shape(cv, kind, x, y, D, col):
    """A system drawn as what it is: a cylinder, a queue, a person, a cloud, a hexagon gateway or an app tile."""
    if kind == 'db':
        eh = D * 0.24; cv.rect(x, y + eh / 2, D, D - eh, col, None, 0, name='diagram box'); cv.ellipse(x, y + D - eh, D, eh, col, None, name='diagram box')
        cv.ellipse(x, y, D, eh, IG.tint(col, 0.35), None, name='diagram box top')
    elif kind == 'queue':
        cv.rect(x, y + D * 0.2, D, D * 0.6, col, None, D * 0.12, name='diagram box')
        for k in range(3): cv.rect(x + D * (0.22 + 0.2 * k), y + D * 0.3, D * 0.1, D * 0.4, 'FFFFFF', None, 3, name='diagram queue slot')
    elif kind == 'user':
        cv.ellipse(x + D * 0.3, y, D * 0.4, D * 0.4, col, None, name='diagram box'); cv.rect(x + D * 0.1, y + D * 0.46, D * 0.8, D * 0.54, col, None, D * 0.3, name='diagram box')
    elif kind == 'cloud':
        for cx_, cy_, r_ in ((0.32, 0.5, 0.26), (0.55, 0.38, 0.3), (0.76, 0.55, 0.22)): cv.ellipse(x + D * (cx_ - r_), y + D * (cy_ - r_), 2 * D * r_, 2 * D * r_, col, None, name='diagram box')
        cv.rect(x + D * 0.12, y + D * 0.5, D * 0.8, D * 0.27, col, None, D * 0.13, name='diagram box')
    elif kind == 'gateway':
        cv.poly([(x + D * 0.25, y + D * 0.08), (x + D * 0.75, y + D * 0.08), (x + D, y + D * 0.5), (x + D * 0.75, y + D * 0.92), (x + D * 0.25, y + D * 0.92), (x, y + D * 0.5)], col, name='diagram box')
    else:
        cv.rect(x, y + D * 0.08, D, D * 0.84, col, None, D * 0.16, name='diagram box'); cv.rect(x + D * 0.12, y + D * 0.22, D * 0.76, D * 0.1, 'FFFFFF', None, 3, name='diagram app bar')


def _sequence(arch, box):
    """Sequence: a lifeline per system (in the order they first appear), the flows as numbered messages top to bottom."""
    nodes, flows = arch['nodes'], arch['flows']; cv = IG.Canvas(); X0, Y0, BW, BH = box
    order = []
    for f in flows:
        for i in (f['source'], f['target']):
            if i not in order: order.append(i)
    order += [n['id'] for n in nodes if n['id'] not in order]
    by = {n['id']: n for n in nodes}; n = len(order); colw = BW / n; hh = 62; xs = {}
    for k, i in enumerate(order):
        x = X0 + k * colw; col = IG.PALETTE[k % len(IG.PALETTE)]; bw_ = colw - 22; cx = x + colw / 2; xs[i] = cx
        fs = 18; ls = IG.wrap(by[i]['label'], bw_ - 16, fs, 'bold')
        while (len(ls) > 2 or max(len(w_) for w_ in by[i]['label'].split()) > int((bw_ - 16) / (fs * IG.CW['bold']))) and fs > 12: fs -= 1; ls = IG.wrap(by[i]['label'], bw_ - 16, fs, 'bold')
        cv.rect(cx - bw_ / 2, Y0, bw_, hh, col, None, 10, name='diagram box')
        cv.text(cx - bw_ / 2 + 8, Y0 + (hh - len(ls[:2]) * fs * 1.15) / 2, bw_ - 16, ls[:2], fs, 'FFFFFF', 'bold', 'center', 1.15, name='diagram system', src=by[i]['label'])
        cv.line(cx, Y0 + hh, cx, Y0 + BH, 'C9BDB6', 1.8, dash=True, name='diagram lifeline')
    step = (BH - hh - 30) / max(1, len(flows)); y = Y0 + hh + 18 + step * 0.55
    for k, f in enumerate(flows, 1):
        x1, x2 = xs[f['source']], xs[f['target']]
        cv.line(x1, y, x2, y, LINE_C, 2.6, name='diagram flow', arrow=True, arrow_start=bool(f.get('both')))
        _badge(cv, k, x1 + (14 if x2 > x1 else -14), y)
        if f.get('label'):
            lw = abs(x2 - x1) - 40; ls = IG.wrap(f['label'], max(90, lw), 15, 'bold')[:2]
            cv.text(min(x1, x2) + 24, y - len(ls) * 18 - 4, max(90, lw), ls, 15, IG.INK, 'bold', 'center', 1.2, name='diagram label text', src=f['label'])
        y += step
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _matrix(arch, box):
    """Interface matrix: who sends (rows) to whom (columns); the flow's label in the cell, a tick where it has none."""
    nodes, flows = arch['nodes'], arch['flows']; cv = IG.Canvas(); X0, Y0, BW, BH = box
    srcs = [n for n in nodes if any(f['source'] == n['id'] or (f.get('both') and f['target'] == n['id']) for f in flows)]
    tgts = [n for n in nodes if any(f['target'] == n['id'] or (f.get('both') and f['source'] == n['id']) for f in flows)]
    cell = {}
    for f in flows:
        cell[(f['source'], f['target'])] = f.get('label') or '✓'
        if f.get('both'): cell[(f['target'], f['source'])] = f.get('label') or '✓'
    hw = 250; hh = 74; cw = (BW - hw) / len(tgts); rh = min(86, (BH - hh) / len(srcs)); top = Y0 + (BH - hh - rh * len(srcs)) / 2
    cv.rect(X0, top, hw, hh, 'F8F5F5', None, 10, name='diagram corner')
    cv.text(X0 + 14, top + hh / 2 - 22, hw - 28, ['From ↓  To →'], 17, IG.MUTED, 'bold', lh=1.2, name='diagram legend title', src='From ↓  To →')
    for j, n in enumerate(tgts):
        col = IG.PALETTE[nodes.index(n) % len(IG.PALETTE)]; x = X0 + hw + j * cw
        cv.rect(x + 3, top, cw - 6, hh, col, None, 10, name='diagram head'); fs = 19; ls = IG.wrap(n['label'], cw - 20, fs, 'bold')
        while (len(ls) > 3 or max(len(w_) for w_ in n['label'].split()) > int((cw - 20) / (fs * IG.CW['bold']))) and fs > 11: fs -= 1; ls = IG.wrap(n['label'], cw - 20, fs, 'bold')
        cv.text(x + 10, top + (hh - len(ls[:3]) * fs * 1.15) / 2, cw - 20, ls[:3], fs, 'FFFFFF', 'bold', 'center', 1.15, name='diagram system', src=n['label'])
    for r, n in enumerate(srcs):
        col = IG.PALETTE[nodes.index(n) % len(IG.PALETTE)]; y = top + hh + r * rh
        cv.rect(X0, y + 3, hw, rh - 6, IG.tint(col, 0.85), None, 10, name='diagram row head'); cv.rect(X0, y + 3, 8, rh - 6, col, None, 0, name='diagram accent')
        ls = IG.wrap(n['label'], hw - 34, 19, 'bold')[:2]
        cv.text(X0 + 20, y + (rh - len(ls) * 19 * 1.18) / 2, hw - 34, ls, 19, IG.INK, 'bold', lh=1.18, name='diagram system', src=n['label'])
        for j, m in enumerate(tgts):
            x = X0 + hw + j * cw; v = cell.get((n['id'], m['id']))
            cv.rect(x + 3, y + 3, cw - 6, rh - 6, 'FFFFFF' if v else 'F8F5F5', 'D9D9D9' if v else None, 8, 1, name='diagram cell')
            if v:
                fsx = 18 if rh >= 70 else 16; ls = IG.wrap(v, cw - 22, fsx, 'body')[:3]
                cv.text(x + 11, y + (rh - len(ls) * fsx * 1.2) / 2, cw - 22, ls, fsx, IG.INK if v != '✓' else IG.TITLE, 'body' if v != '✓' else 'bold', 'center', 1.2, name='diagram point', src=v)
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _radial(arch, box):
    """Radial: systems around a ring (no centre), every flow a straight chord with its label at the middle."""
    nodes, flows = arch['nodes'], arch['flows']; cv = IG.Canvas(); X0, Y0, BW, BH = box
    n = len(nodes); cx, cy = X0 + BW / 2, Y0 + BH / 2; bw_, bh_ = 240, 82; rx, ry = BW / 2 - bw_ / 2 - 10, BH / 2 - bh_ / 2 - 6; geo = {}
    for k, nd in enumerate(nodes):
        a = -math.pi / 2 + 2 * math.pi * k / n; x = cx + rx * math.cos(a) - bw_ / 2; y = cy + ry * math.sin(a) - bh_ / 2; geo[nd['id']] = (x, y, bw_, bh_)
    def edge_pt(i, tx, ty):
        x, y, w, h = geo[i]; mx, my = x + w / 2, y + h / 2; dx, dy = tx - mx, ty - my
        s = min((w / 2) / abs(dx) if dx else 1e9, (h / 2) / abs(dy) if dy else 1e9); return mx + dx * s, my + dy * s
    labels = []
    for f in flows:
        a, b = geo[f['source']], geo[f['target']]; ac, bc = (a[0] + a[2] / 2, a[1] + a[3] / 2), (b[0] + b[2] / 2, b[1] + b[3] / 2)
        p1, p2 = edge_pt(f['source'], *bc), edge_pt(f['target'], *ac)
        cv.line(p1[0], p1[1], p2[0], p2[1], LINE_C, 2.4, name='diagram flow', arrow=True, arrow_start=bool(f.get('both')))
        if f.get('label'): labels.append((f['label'], p1[0] + (p2[0] - p1[0]) * 0.5, p1[1] + (p2[1] - p1[1]) * 0.5))
    for k, nd in enumerate(nodes):
        x, y, w, h = geo[nd['id']]; col = IG.PALETTE[k % len(IG.PALETTE)]
        cv.rect(x, y, w, h, col, None, h / 2, name='diagram box'); fs = 19; ls = IG.wrap(nd['label'], w - 36, fs, 'bold')
        while (len(ls) > 2 or max(len(w_) for w_ in nd['label'].split()) > int((w - 36) / (fs * IG.CW['bold']))) and fs > 12: fs -= 1; ls = IG.wrap(nd['label'], w - 36, fs, 'bold')
        cv.text(x + 18, y + (h - len(ls[:2]) * fs * 1.15) / 2, w - 36, ls[:2], fs, 'FFFFFF', 'bold', 'center', 1.15, name='diagram system', src=nd['label'])
    for text, mx, my in labels: _pill(cv, text, mx, my, 150, 'mid', centre=True)
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


def _tree_root(arch):
    ins = {n['id']: 0 for n in arch['nodes']}; outs = {n['id']: 0 for n in arch['nodes']}
    for f in arch['flows']: ins[f['target']] += 1; outs[f['source']] += 1
    roots = [i for i in ins if ins[i] == 0 and outs[i] > 0]
    return roots[0] if len(roots) == 1 and all(v <= 1 for i, v in ins.items() if i != roots[0]) and outs[roots[0]] >= 2 else None


def _tree(arch, box):
    """Fan-out tree: the one source on top, what it feeds below it, level by level - org-chart connectors."""
    nodes, flows = arch['nodes'], arch['flows']; cv = IG.Canvas(); X0, Y0, BW, BH = box
    root = _tree_root(arch); kids = {}; lvl = {root: 0}; q = [root]; by = {n['id']: n for n in nodes}; lab = {}
    for f in flows: kids.setdefault(f['source'], []).append(f['target']); lab[(f['source'], f['target'])] = f.get('label') or ''
    while q:
        u = q.pop(0)
        for v in kids.get(u, []):
            if v not in lvl: lvl[v] = lvl[u] + 1; q.append(v)
    levels = {}
    for i, l in lvl.items(): levels.setdefault(l, []).append(i)
    L = max(levels) + 1; vgap = 70; bh_ = min(130, (BH - vgap * (L - 1)) / L); geo = {}
    for l in range(L):
        ids = levels[l]; w_ = min(300, (BW - 30 * (len(ids) - 1)) / len(ids)); tot = len(ids) * w_ + 30 * (len(ids) - 1); x = X0 + (BW - tot) / 2
        for k, i in enumerate(ids): geo[i] = (x + k * (w_ + 30), Y0 + l * (bh_ + vgap), w_, bh_)
    for u, vs in kids.items():
        if u not in geo: continue
        x, y, w, h = geo[u]; mx = x + w / 2; ym = y + h + vgap / 2; vs = [v for v in vs if lvl.get(v) == lvl[u] + 1]
        if not vs: continue
        cv.line(mx, y + h, mx, ym, LINE_C, 2.6, name='diagram flow')
        xsv = [geo[v][0] + geo[v][2] / 2 for v in vs]; cv.line(min(xsv + [mx]), ym, max(xsv + [mx]), ym, LINE_C, 2.6, name='diagram flow')
        for v, xv in zip(vs, xsv):
            cv.line(xv, ym, xv, geo[v][1], LINE_C, 2.6, name='diagram flow', arrow=True)
            if lab.get((u, v)): _pill(cv, lab[(u, v)], xv, ym + (geo[v][1] - ym) / 2 + 2, min(170, geo[v][2]), 'mid', centre=True)
    for i, (x, y, w, h) in geo.items():
        nd = by[i]; col = IG.TITLE if i == root else IG.PALETTE[(lvl[i] + nodes.index(nd)) % len(IG.PALETTE)]
        cv.rect(x, y, w, h, col if i == root else 'FFFFFF', None if i == root else IG.tint(col, 0.4), 14, 2, name='diagram box')
        if i != root: cv.rect(x, y, w, 8, col, None, 0, name='diagram accent')
        fs = 20 if i == root else 18; ls = IG.wrap(nd['label'], w - 30, fs, 'bold')
        while (len(ls) > 2 or max(len(w_) for w_ in nd['label'].split()) > int((w - 30) / (fs * IG.CW['bold']))) and fs > 12: fs -= 1; ls = IG.wrap(nd['label'], w - 30, fs, 'bold')
        sub = IG.wrap(nd.get('sub') or '', w - 30, 15, 'body')[:1] if nd.get('sub') else []
        th_ = len(ls[:2]) * fs * 1.15 + (len(sub) * 15 * 1.3 + 4 if sub else 0); yy = y + (h - th_) / 2
        yy += cv.text(x + 15, yy, w - 30, ls[:2], fs, 'FFFFFF' if i == root else IG.INK, 'bold', 'center', 1.15, name='diagram system', src=nd['label'])
        if sub: cv.text(x + 15, yy + 4, w - 30, sub, 15, 'FFFFFF' if i == root else IG.MUTED, 'body', 'center', 1.3, name='diagram sub', src=nd['sub'])
    return {'w': 1600, 'h': 900, 'bg': 'FFFFFF', 'els': cv.els}


# ------------------------------------------------------------------------------------------------ more sources of an architecture (v5.4)
def _nid_map():
    ids, nodes = {}, []
    def nid(name, sub='', items=None):
        k = re.sub(r'\s+', ' ', str(name)).strip().lower()
        if not k: return None
        if k not in ids: ids[k] = f'n{len(nodes)}'; nodes.append({'id': ids[k], 'label': str(name).strip(), 'sub': str(sub or '').strip(), 'items': [str(x).strip() for x in (items or []) if str(x).strip()]})
        return ids[k]
    return nid, nodes


def from_dict(d, title=''):
    """{"nodes": [{"name", "role", "points"}], "flows": [{"from", "to", "label"}]} - what the AI step passes on (or a ```diagram block)."""
    if not isinstance(d, dict): return None
    nid, nodes = _nid_map()
    for n in d.get('nodes') or []:
        if isinstance(n, dict): nid(n.get('name') or n.get('label') or '', n.get('role') or n.get('sub') or '', n.get('points') or n.get('items') or [])
        elif isinstance(n, str): nid(n)
    flows = []
    for f in d.get('flows') or []:
        if not isinstance(f, dict): continue
        a, b = nid(f.get('from') or f.get('source') or ''), nid(f.get('to') or f.get('target') or '')
        if a and b and a != b: flows.append({'source': a, 'target': b, 'label': str(f.get('label') or '').strip()})
    if len(nodes) < 2 or not flows: return None
    return {'title': str(d.get('title') or title or ''), 'nodes': nodes, 'flows': flows, 'from': d.get('from') or 'fields'}


def from_drawio(xml, title=''):
    """draw.io XML (an <mxfile> or <mxGraphModel>) → the from_dict fields: every labelled box is a system (its first line the name, a
    bracketed line its role, "•" lines its points), every connector between two systems a flow with its label. Swimlanes and
    containers are not systems. None when it is not draw.io XML or holds fewer than 2 systems / no flow."""
    import html as _h, xml.etree.ElementTree as ET
    s = str(xml or '')
    m = re.search(r'<mxGraphModel\b.*?</mxGraphModel>', s, re.S)
    if not m: return None
    body = re.sub(r'^\s*```.*$', '', m.group(0), flags=re.M)
    try: root = ET.fromstring(body)
    except ET.ParseError: return None
    cells = {c.get('id'): c for c in root.iter('mxCell')}
    def text(v):
        v = _h.unescape(re.sub(r'<br\s*/?>', '\n', str(v or ''), flags=re.I)); v = re.sub(r'<[^>]+>', '', v)
        return [l.strip() for l in v.split('\n') if l.strip()]
    systems = {}
    for cid, c in cells.items():
        if c.get('vertex') != '1': continue
        st = c.get('style') or ''; lines = text(c.get('value'))
        if not lines or 'swimlane' in st or st.startswith('text;') or 'group' in st.split(';')[0]: continue
        name = re.sub(r'\s*[\[(].*$', '', lines[0]).strip() or lines[0]
        role = next((l.strip('[]() ') for l in lines[1:] if re.match(r'^[\[(]', l)), '') or (re.search(r'[\[(]([^\])]+)[\])]', lines[0]).group(1) if re.search(r'[\[(]([^\])]+)[\])]', lines[0]) else '')
        pts = [l.lstrip('•-–* ').strip() for l in lines[1:] if re.match(r'^[•\-–*]', l)]
        systems[cid] = {'name': name, 'role': role, 'points': pts}
    names = [v['name'] for v in systems.values()]
    for cid, v in systems.items():   # two boxes with one name ("SAP S/4HANA" twice) keep their role in the name
        if names.count(v['name']) > 1 and v['role']: v['name'] = f"{v['name']} {v['role'].split('/')[0].split(':')[0].strip()}"[:48]
    flows = []
    for c in cells.values():
        if c.get('edge') != '1': continue
        a, b = systems.get(c.get('source')), systems.get(c.get('target'))
        if a and b and a is not b: flows.append({'from': a['name'], 'to': b['name'], 'label': ' '.join(text(c.get('value')))})
    if len(systems) < 2 or not flows: return None
    dg = root.find('.//diagram')
    return {'title': title or '', 'nodes': list(systems.values()), 'flows': flows, 'from': 'drawio'}


SRC_COL = re.compile(r'^(source|source system|from|sender|sending system|origin|producer|publisher|upstream|provider)\b', re.I)
TGT_COL = re.compile(r'^(target|target system|to|receiver|receiving system|destination|consumer|subscriber|downstream)\b', re.I)
LAB_COL = re.compile(r'\b(protocol|interface|method|mechanism|pattern|technology|transport|format|data|object|payload|message|integration|type|frequency)\b', re.I)


def from_table(rows, title=''):
    """An interface table (Source / Target columns, a protocol or data column for the label) → arch; None when it is not one."""
    if not rows or len(rows) < 3: return None
    head = [str(c).strip() for c in rows[0]]
    si = next((k for k, h in enumerate(head) if SRC_COL.match(h)), None); ti = next((k for k, h in enumerate(head) if TGT_COL.match(h)), None)
    if si is None or ti is None or si == ti: return None
    li = next((k for k, h in enumerate(head) if k not in (si, ti) and LAB_COL.search(h)), None)
    nid, nodes = _nid_map(); flows = []; data = [r for r in rows[1:] if max(si, ti) < len(r) and (str(r[si]).strip() or str(r[ti]).strip())]
    good = [r for r in data if is_system_name(r[si]) and is_system_name(r[ti]) and len(str(r[si])) <= 40 and len(str(r[ti])) <= 40]
    if len(good) < max(2, int(0.7 * len(data))): return None   # an interface table names systems in its rows - a metrics or plan table does not
    for r in good:
        a, b = nid(r[si]), nid(r[ti])
        if a and b and a != b: flows.append({'source': a, 'target': b, 'label': (str(r[li]).strip() if li is not None and li < len(r) else '')})
    if len(nodes) < 2 or len(flows) < 2: return None
    return {'title': title, 'nodes': nodes, 'flows': flows, 'from': 'interface table'}


PROTO = re.compile(r'\b(REST|SOAP|OData|IDoc|API|APIs|ESB|SFTP|FTP|file|files|Kafka|event|events|queue|MQ|batch|webhook|EDI|JDBC|GraphQL|gRPC|HTTPS?|CPI|RFC|BAPI)\b', re.I)


COMMON_WORDS = set('today early later store stores customer customers business finance team teams order orders data inventory payment payments '
                   'supplier suppliers vendor vendors treasury management process processes people leadership operations sales marketing it '
                   'monday tuesday wednesday thursday friday the this that our we'.split())


def is_system_name(lbl):
    """A name that reads as a system: an acronym (SAP, OMS), a product in CamelCase (TikTok) or a proper name (Rithum, Amplience) - 
    not a figure, not a common word, not a hyphenated phrase ("Early-payment")."""
    s = str(lbl or '').strip()
    if not s or re.fullmatch(r'[\d\s.,%$€£+-]+', s) or re.search(r'[A-Za-z]+-[a-z]', s): return False
    if re.search(r'\b[A-Z][A-Z0-9/&.]{1,}', s) or re.search(r'\b[A-Z][a-z]+[A-Z]\w*', s): return True
    words = re.findall(r'[A-Za-z]+', s)
    return bool(words) and words[0][0].isupper() and all(w.lower() not in COMMON_WORDS for w in words) and len(words) <= 4


FLOW_VERB = re.compile(r'\b(sends?|posts?|forwards?|publish(?:es)?|push(?:es)?|calls?|feeds?|syncs?|synchroni[sz]es|writes?|loads?|pass(?:es)?|routes?|streams?|transmits?|exports?|delivers?|'
                       r'pulls?|reads?|receives?|fetch(?:es)?|gets?|imports?)\b', re.I)
PULL_VERB = re.compile(r'^(pulls?|reads?|receives?|fetch(?:es)?|gets?|imports?)$', re.I)


ASK = re.compile(r'^(provide|please|upload|list|describe|define|explain|attach|enter|add|include|confirm|select|link|share|identify|state|specify|has|have|is|are|does|do|will|can|should|was|were|new)\b', re.I)


def _statements(text):
    """The text without form furniture: field codes ("R01 1.", "G04") go, and questions or instructions are dropped."""
    out = []
    for line in str(text or '').splitlines():
        s = re.sub(r'^\s*(?:[-*•]\s*)?(?:[A-Z]{1,2}\d{1,3}\b\.?\s*)?(?:\d{1,2}[.)]\s*)?', '', line)
        if '?' in s or ASK.match(s): continue
        out.append(s)
    return '\n'.join(out)


def _unname(s, names):
    """The sentence without its systems' names, so "API gateway" never reads as the protocol "API"."""
    for n in sorted({x for x in names if x}, key=len, reverse=True): s = re.sub(re.escape(n), ' ', s, flags=re.I)
    return s


def _slug(s): return re.sub(r'[^a-z0-9]', '', str(s).lower())


def _clause_flows(text, known, clean, systemish):
    """(source, target, protocol) per clause: the subject before a flow verb sends to the system after "to / through / into"
    (from "from" for pull verbs); a ", which …" clause's subject is the system just named."""
    known = sorted({k for k in known if k}, key=len, reverse=True); out = []
    def mention(seg):
        for k in known:
            m = re.search(r'(?<![\w/])' + re.escape(k) + r'(?![\w/])', seg, re.I)
            if m: return m.start(), k
        m = re.search(r'\b(?:to|through|into|onto|from)\s+(?:the\s+|an?\s+)?((?:[A-Z][\w/&.-]*|[a-z]+)(?:\s+(?:[A-Z][\w/&.-]*|app|gateway|platform|service|system|hub|portal|engine|lake|warehouse|database|bus|queue))*)', seg)
        if m and systemish(m.group(1)) and len(m.group(1)) <= 40: return m.start(1), m.group(1)
        return None
    for sent in re.split(r'(?<=[.!?])\s+|\n+', str(text or '')):
        prev = None
        for cl in re.split(r',\s*(?=which\b)|;\s*|,?\s+and then\s+|,\s*then\s+', sent):
            v = FLOW_VERB.search(cl)
            if not v: continue
            head = cl[:v.start()].strip(' ,')
            m_ = re.match(r'(.+?)\s+[a-z]+s\b.*\band$', head)   # "MIA app captures counts and posts …" → the subject is "MIA app"
            if m_: head = m_.group(1)
            subj = prev if re.fullmatch(r'(?i)(which|it|that|then|and)?\s*(then)?', head) else clean(re.sub(r'(?i)\s+(then|also|now|first|later)$', '', head))
            if subj and not systemish(subj):
                hit = mention(head); subj = hit[1] if hit else None
            if not subj or len(subj) > 40: continue
            rest = cl[v.end():]; pull = bool(PULL_VERB.match(v.group(1)))
            seg = rest
            pm = re.search(r'\b(from)\b' if pull else r'\b(to|through|into|onto|toward)\b', rest)
            if pm: seg = rest[pm.start():]
            hit = mention(seg)
            if not hit or _slug(hit[1]) == _slug(subj): continue
            m = PROTO.search(_unname(cl, known + [subj, hit[1]])); lab = m.group(1) if m else ''
            out.append((hit[1], subj, lab) if pull else (subj, hit[1], lab)); prev = hit[1] if not pull else subj
    return out


def from_sentences(text, title=''):
    """Sentences that say who sends what to whom ("OMS sends the order to SAP as an IDoc") → arch, by the diagram rules (no model);
    the label is the protocol a sentence names. None unless it reads as an architecture (3+ systems, 2+ flows)."""
    text = _statements(text)   # a form's questions and instructions ("Provide link to …", "Has X been sent to Y?") are not flows
    try:
        import draft_rules
        spec = draft_rules.draft(text, title)
    except Exception: return None   # noqa: BLE001
    LEAD = re.compile(r'^(today|then|now|currently|also|early|later|finally|first|next|our|the|this|that|these|each|every|when|if|once|after|before|both|all)\b[\s,:-]*', re.I)
    SYSNOUN = re.compile(r'\b(app|application|platform|system|service|gateway|hub|engine|portal|database|db|lake|warehouse|erp|crm|wms|oms|pim|pos|mdm|bus|queue|cloud|api|cpi|btp|esb|suite|store|handheld|website|site)\b', re.I)
    def clean(lbl):
        lbl = LEAD.sub('', str(lbl)).strip(' -,'); return lbl
    def systemish(lbl):
        return is_system_name(lbl) or bool(SYSNOUN.search(lbl))
    keep = {}
    for n in spec.get('nodes', []):
        lbl = clean(n['label'])
        if lbl and systemish(lbl): keep[n['id']] = lbl
    nodes = [{'id': i, 'label': l, 'sub': '', 'items': []} for i, l in keep.items()]
    flows = []
    for f in spec.get('flows', []):
        if f['source'] not in keep or f['target'] not in keep or f['source'] == f['target']: continue
        m = PROTO.search(_unname(f.get('desc') or '', keep.values())); flows.append({'source': f['source'], 'target': f['target'], 'label': m.group(1) if m else ''})
    for s_, t_, lab in _clause_flows(text, [n['label'] for n in nodes], clean, systemish):   # clauses the drafter skips ("…, which posts X to Y")
        a, b = _slug(s_), _slug(t_)
        for i_, l_ in ((a, s_), (b, t_)):
            if i_ not in keep: keep[i_] = l_; nodes.append({'id': i_, 'label': l_, 'sub': '', 'items': []})
        if a != b and not any(f['source'] == a and f['target'] == b for f in flows): flows.append({'source': a, 'target': b, 'label': lab})
    used = {f['source'] for f in flows} | {f['target'] for f in flows}; nodes = [n for n in nodes if n['id'] in used]
    if len(nodes) < 3 or len(flows) < 3: return None   # read from prose: only a clear picture (3+ systems, 3+ flows), never a guess
    return {'title': title, 'nodes': nodes, 'flows': flows, 'from': 'sentences'}


def from_layers(cards, title=''):
    """An architecture section written as layers (a sub-heading per layer, its points under it) → a top-to-bottom chain of layers."""
    nid, nodes = _nid_map(); ids = []
    for head, lines in cards[:MAX_NODES]:
        pts = [re.sub(r'^[•–\-*]\s*', '', str(l)).strip() for l in lines if str(l).strip()]
        ids.append(nid(head, pts[0] if pts and len(pts[0]) <= 40 else '', pts[1:] if pts and len(pts[0]) <= 40 else pts))
    flows = [{'source': ids[k], 'target': ids[k + 1], 'label': ''} for k in range(len(ids) - 1)]
    if len(nodes) < 3: return None
    return {'title': title, 'nodes': nodes, 'flows': flows, 'from': 'layers', 'style_hint': 'cake'}


def overlap(a, b):
    """How far two diagrams show the same systems (0–1, by the words of their names) - one architecture gets one slide."""
    w = lambda arch: {x for n in arch['nodes'] for x in re.findall(r'[a-z0-9/]{3,}', n['label'].lower())}
    A, B = w(a), w(b)
    return len(A & B) / max(1, min(len(A), len(B)))


def notes(arch, dropped, source_text=''):
    """The speaker notes for a diagram slide: every system with its points, every line, what crisp left off the slide."""
    nm = {n['id']: n['label'] for n in arch['nodes']}
    out = ['Systems: ' + '; '.join(n['label'] + (f' ({n["sub"]})' if n.get('sub') else '') + (': ' + ', '.join(n['items']) if n.get('items') else '') for n in arch['nodes'])]
    out.append('Flows: ' + '; '.join(f'{nm.get(f["source"], "?")} {"⇄" if f.get("both") else "→"} {nm.get(f["target"], "?")}' + (f' ({f["label"]})' if f.get('label') else '') for f in arch['flows']))
    if dropped: out.append('Kept off the slide to keep it crisp: ' + '; '.join(dropped))
    return ' - '.join(out)


def drawio_spec(arch):
    """The same diagram for build_drawio.py (one zone per column), so the deck ships an editable .drawio beside it.
    Each zone is named from its systems (Channels, Integration, Core systems, Data & consumers; a repeated name becomes
    Sources / Downstream systems by position) and each system keeps its state, so the file reads like the standard."""
    from collections import Counter
    lay = _layers(arch['nodes'], arch['flows']); ncol = max(lay.values()) + 1 if lay else 1
    kind = {'Channels': 'saas', 'Integration': 'dmz', 'Core systems': 'core', 'Data & consumers': 'down'}
    names = [Counter(zone_of(n) for n in arch['nodes'] if lay[n['id']] == c).most_common(1)[0][0] if any(lay[n['id']] == c for n in arch['nodes']) else 'Core systems'
             for c in range(ncol)]
    titles = []
    for c, z in enumerate(names):
        t = z
        if names.count(z) > 1:
            t = 'Sources' if c == 0 else 'Downstream systems' if c == ncol - 1 else z if names.index(z) == c else f'{z} ({c + 1})'
        titles.append(t)
    zones = [{'id': f'z{c}', 'title': titles[c], 'kind': {'Sources': 'saas', 'Downstream systems': 'down'}.get(titles[c]) or kind.get(names[c], 'core')} for c in range(ncol)]
    st = {'existing': 'keep', 'keep': 'keep', 'modified': 'changed', 'changed': 'changed', 'new': 'new', 'retire': 'retire', 'future': 'future'}
    nodes = [{'id': n['id'], 'label': n['label'], 'sub': n.get('sub') or '', 'zone': f'z{lay[n["id"]]}', 'state': st.get(str(n.get('state') or '').lower(), 'keep')}
             for n in arch['nodes']]
    flows = [{'id': f'F{k}', 'badge': f'{k}.0', 'source': f['source'], 'target': f['target'], 'kind': 'sync', 'desc': f.get('label') or ''} for k, f in enumerate(arch['flows'], 1)]
    return {'title': arch.get('title') or 'Architecture', 'subtitle': 'Editable copy of the deck diagram · ULTA Enterprise Diagram Standards palette',
            'zones': zones, 'nodes': nodes, 'flows': flows}


STYLE_NEEDS = {'zones': 'systems in two or more zones (Channels, Integration, Core, Data)', 'chevron': 'a single chain of systems', 'hub': 'one system linked to three or more',
               'cake': 'at most two systems per tier', 'sequence': 'two or more flows', 'matrix': 'three or more flows', 'tech': 'two or more kinds of system (app, database, queue, gateway …)',
               'radial': '4 to 8 systems', 'tree': 'one root system', 'cloud': 'zones that keep the reading order'}


def build(text_or_pairs, title='', style='auto', box=None):
    """One call for the deck: box art text or arrow-line pairs → (design, arch, dropped) or None. style: one of STYLES or 'auto';
    box: the region it is drawn in (default the slide's body; a deck keeps the bottom free for a decision bar)."""
    if isinstance(text_or_pairs, dict): arch = text_or_pairs if text_or_pairs.get('nodes') and isinstance(text_or_pairs['nodes'][0], dict) and 'id' in text_or_pairs['nodes'][0] else from_dict(text_or_pairs, title)
    else: arch = from_arrows(text_or_pairs, title) if isinstance(text_or_pairs, list) else from_art(text_or_pairs, title)
    if not arch or len(arch['nodes']) < 2: return None
    if style in (None, '', 'auto') and arch.get('style_hint') and suits(arch, arch['style_hint']): style = arch['style_hint']
    arch, dropped = crisp(arch)
    return (layout(arch, box=box, style=style) if box else layout(arch, style=style)), arch, dropped


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(); ap.add_argument('page'); ap.add_argument('--out')
    a = ap.parse_args(); t = open(a.page, encoding='utf-8').read()
    for para in re.split(r'\n\s*\n', t):
        if is_art(para):
            d, arch, dropped = build(para, 'Architecture')
            res = {'design': d, 'arch': arch, 'dropped': dropped}
            open(a.out, 'w').write(json.dumps(res, indent=1)) if a.out else print(json.dumps({'arch': arch, 'dropped': dropped}, indent=1))
            break
