#!/usr/bin/env python3
"""Audit a .drawio file that was edited by hand (in the diagram page's draw.io pane or in draw.io itself) against the connector rules the
router enforces when it builds one: orthogonal connectors only, no connector through an unrelated shape (15 px clearance),
parallel lanes at least 20 px apart, unique badges. Reports; never rewrites.

  audit_xml.py diagram.drawio            → prints "audit: N connectors, K crossing(s), M violation(s)" and one line per violation
"""
import argparse, html, json, re
import xml.etree.ElementTree as ET

LANE_SEP = 20; SHAPE_CLEAR = 15


def style_map(st):
    d = {}
    for part in (st or '').split(';'):
        if '=' in part: k, v = part.split('=', 1); d[k] = v
        elif part: d[part] = '1'
    return d


def plain(v):
    v = html.unescape(v or ''); v = re.sub(r'<br\s*/?>', ' ', v, flags=re.I); v = re.sub(r'<[^>]+>', '', v)
    return ' '.join(v.split())


def load(path_or_xml):
    xml = path_or_xml if path_or_xml.lstrip().startswith('<') else open(path_or_xml, encoding='utf-8').read()
    root = ET.fromstring(xml)
    model = root if root.tag == 'mxGraphModel' else root.find('.//mxGraphModel')
    if model is None: raise ValueError('no <mxGraphModel> in the file (compressed draw.io files are not supported — save uncompressed: Extras → Compressed off)')
    cells = {c.get('id'): c for c in model.find('root').iter('mxCell')}
    return cells


def geometry(cells, cid):
    """Absolute rectangle of a vertex, walking container parents (a node dropped into a swimlane has relative coordinates)."""
    c = cells.get(cid); g = c.find('mxGeometry') if c is not None else None
    if g is None: return None
    x, y = float(g.get('x', 0)), float(g.get('y', 0)); w, h = float(g.get('width', 0)), float(g.get('height', 0))
    p = c.get('parent')
    while p and p not in ('0', '1'):
        pc = cells.get(p); pg = pc.find('mxGeometry') if pc is not None else None
        if pg is None: break
        x += float(pg.get('x', 0)); y += float(pg.get('y', 0)); p = pc.get('parent')
    return x, y, w, h


def anchor(rect, sx, sy):
    x, y, w, h = rect
    return (x + w * (0.5 if sx is None else float(sx)), y + h * (0.5 if sy is None else float(sy)))


def segs(points):
    """Consecutive points → ('H'|'V', p, q); a diagonal pair (draw.io bends it itself for orthogonalEdgeStyle) becomes an L."""
    out = []
    for p, q in zip(points, points[1:]):
        if abs(p[1] - q[1]) < 1: out.append(('H', p, q))
        elif abs(p[0] - q[0]) < 1: out.append(('V', p, q))
        else: m = (q[0], p[1]); out.append(('H', p, m)); out.append(('V', m, q))
    return [s for s in out if abs(s[1][0] - s[2][0]) >= 1 or abs(s[1][1] - s[2][1]) >= 1]


def rect_hit(seg, rect, clear):
    o, p, q = seg; x, y, w, h = rect
    x0, y0, x1, y1 = x - clear, y - clear, x + w + clear, y + h + clear
    if o == 'H':
        lo, hi = sorted((p[0], q[0])); return y0 < p[1] < y1 and hi > x0 and lo < x1
    lo, hi = sorted((p[1], q[1])); return x0 < p[0] < x1 and hi > y0 and lo < y1


def audit(cells):
    nodes = {}; edges = []
    for cid, c in cells.items():
        st = style_map(c.get('style'))
        if c.get('edge') == '1':
            edges.append((cid, c, st)); continue
        if c.get('vertex') != '1' or cid in ('0', '1'): continue
        if st.get('shape') == 'swimlane' or 'swimlane' in st or st.get('text') or 'edgeLabel' in st or st.get('shape') == 'image': continue   # zones, free text, badge labels and legend icons are not shapes a connector must avoid
        r = geometry(cells, cid)
        if r and r[2] > 0 and r[3] > 0: nodes[cid] = (r, plain(c.get('value')) or cid)
    E = []; errs = []
    labels = {}
    for cid, c, st in [(k, v, style_map(v.get('style'))) for k, v in cells.items()]:
        if 'edgeLabel' in st and c.get('parent') in cells: labels.setdefault(c.get('parent'), plain(c.get('value')))
    for cid, c, st in edges:
        badge = labels.get(cid) or plain(c.get('value')) or cid
        src, tgt = c.get('source'), c.get('target'); g = c.find('mxGeometry')
        pts = []
        if src in nodes: pts.append(anchor(nodes[src][0], st.get('exitX'), st.get('exitY')))
        elif g is not None and g.find("mxPoint[@as='sourcePoint']") is not None: sp = g.find("mxPoint[@as='sourcePoint']"); pts.append((float(sp.get('x', 0)), float(sp.get('y', 0))))
        if g is not None: pts += [(float(p.get('x')), float(p.get('y'))) for p in g.findall('Array/mxPoint')]
        if tgt in nodes: pts.append(anchor(nodes[tgt][0], st.get('entryX'), st.get('entryY')))
        elif g is not None and g.find("mxPoint[@as='targetPoint']") is not None: tp = g.find("mxPoint[@as='targetPoint']"); pts.append((float(tp.get('x', 0)), float(tp.get('y', 0))))
        if len(pts) < 2: continue
        if st.get('edgeStyle') != 'orthogonalEdgeStyle': errs.append(f'[orthogonal] {badge}: connector is not orthogonal (edgeStyle={st.get("edgeStyle") or "straight"})')
        E.append({'badge': badge, 'src': src, 'tgt': tgt, 'segs': segs(pts)})
    for i, a in enumerate(E):                                     # parallel lanes too close / shared
        for b in E[i + 1:]:
            for o1, p1, q1 in a['segs']:
                for o2, p2, q2 in b['segs']:
                    if o1 != o2: continue
                    if o1 == 'H': fix1, fix2 = p1[1], p2[1]; lo1, hi1 = sorted((p1[0], q1[0])); lo2, hi2 = sorted((p2[0], q2[0]))
                    else: fix1, fix2 = p1[0], p2[0]; lo1, hi1 = sorted((p1[1], q1[1])); lo2, hi2 = sorted((p2[1], q2[1]))
                    ov = min(hi1, hi2) - max(lo1, lo2)
                    if ov <= 0: continue
                    d = abs(fix1 - fix2)
                    if d < LANE_SEP - .01 and not (a['src'] == b['src'] and ov < 30) and not (a['tgt'] == b['tgt'] and ov < 30):
                        errs.append(f'[overlap] {a["badge"]} vs {b["badge"]}: {o1} {"shared segment" if d < .01 else f"lanes only {d:.0f}px apart"} (overlap {ov:.0f}px)')
    for e in E:                                                   # through or too close to an unrelated shape
        for s in e['segs']:
            for nid, (r, name) in nodes.items():
                if nid in (e['src'], e['tgt']): continue
                if rect_hit(s, r, SHAPE_CLEAR):
                    errs.append(f'[clearance] {e["badge"]} {"crosses" if rect_hit(s, r, 0) else "runs <15px from"} {name}')
    cross = 0
    for i, a in enumerate(E):
        for b in E[i + 1:]:
            for o1, p1, q1 in a['segs']:
                for o2, p2, q2 in b['segs']:
                    if o1 == o2: continue
                    h, v = ((p1, q1), (p2, q2)) if o1 == 'H' else ((p2, q2), (p1, q1))
                    hy = h[0][1]; hx = sorted((h[0][0], h[1][0])); vx = v[0][0]; vy = sorted((v[0][1], v[1][1]))
                    if hx[0] < vx < hx[1] and vy[0] < hy < vy[1]: cross += 1
    bs = [e['badge'] for e in E]
    if len(bs) != len(set(bs)): errs.append('[badge] duplicate badge numbers')
    errs = list(dict.fromkeys(errs))
    return {'connectors': len(E), 'crossings': cross, 'violations': errs, 'line': f'audit: {len(E)} connectors, {cross} discrete crossing(s), {len(errs)} violation(s)'}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('path'); ap.add_argument('--json', action='store_true')
    a = ap.parse_args(); r = audit(load(a.path))
    if a.json: print(json.dumps(r)); return
    print(r['line'])
    for x in r['violations']: print('   ', x)


if __name__ == '__main__': main()
