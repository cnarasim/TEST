/* The page's own editing kit (infographic and UI screens pages): no chat, no server. The page keeps its content (the spec) and
   lays itself out again with the bundled engine after every change; this file gives it what every editor needs:
   - path(obj, 'blocks.2.items.1.value') / setPath: read and change one field of the content
   - UndoStack: undo / redo of whole-content snapshots (typing bursts become one step)
   - Saver: writes this same page with the new content in its data block (into the opened file where the browser
     allows it - Chrome, Edge - else as a download); Ctrl+S
   - Inline: the floating text box that edits a text where it is drawn
   - IconPicker: the template's pictograms, searchable
   - toast, esc, keyboard shortcuts.
   Inlined in the page: it must never contain a closing script tag. */
(function (root) {
  'use strict';
  var CSS = [
    '#toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#000000;color:#FFFFFF;padding:9px 16px;border-radius:999px;font:13px/1.4 -apple-system,"Segoe UI",Roboto,Arial,sans-serif;opacity:0;transition:opacity .2s;pointer-events:none;z-index:90;max-width:min(560px,90vw);text-align:center}',
    '#toast.on{opacity:1}',
    '.ue-inline{position:fixed;z-index:80;background:#FFFFFF;border:2px solid #F26923;border-radius:10px;box-shadow:0 12px 32px rgba(0,0,0,.2);padding:5px 6px 4px;box-sizing:border-box;min-width:180px}',
    '.ue-inline textarea{display:block;box-sizing:border-box;width:100%;border:0;outline:none;resize:none;background:#FFFFFF;color:#000000;padding:2px 4px;margin:0;overflow:hidden;line-height:1.25}',
    '.ue-inline .ue-st{display:flex;gap:10px;align-items:center;font:600 11.5px/1.3 -apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:#404040;padding:4px 4px 1px}',
    '.ue-inline .ue-st span:last-child{margin-left:auto;font-weight:400;white-space:nowrap}.ue-inline .ue-st.warn{color:#B4441A}',
    '.ue-pick{position:fixed;inset:0;background:rgba(43,35,32,.32);display:none;align-items:center;justify-content:center;z-index:85}.ue-pick.on{display:flex}',
    '.ue-pick .box{background:#FFFFFF;border-radius:16px;width:min(600px,94vw);max-height:82vh;display:flex;flex-direction:column;box-shadow:0 20px 60px rgba(0,0,0,.25)}',
    '.ue-pick .top{display:flex;gap:8px;align-items:center;padding:12px 14px;border-bottom:1px solid #D9D9D9}.ue-pick .top b{font-size:13.5px;color:#B4441A;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:45%}',
    '.ue-pick input{flex:1;border:1px solid #D9D9D9;border-radius:9px;padding:7px 10px;font:13px inherit;min-width:0}',
    '.ue-pick .grid{overflow:auto;padding:12px 14px;display:grid;grid-template-columns:repeat(auto-fill,minmax(74px,1fr));gap:8px}',
    '.ue-pick .grid button{border:1px solid #D9D9D9;border-radius:12px;background:#FFFFFF;cursor:pointer;padding:8px 4px 6px;display:flex;flex-direction:column;align-items:center;gap:4px;color:#B4441A;font:500 10.5px/1.2 -apple-system,"Segoe UI",Roboto,Arial,sans-serif}',
    '.ue-pick .grid button:hover,.ue-pick .grid button.cur{border-color:#F26923;background:#FFF5F3}.ue-pick .grid button svg{width:34px;height:34px}',
    '.ue-pick .grid button span{color:#404040;max-width:70px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ue-pick .grid .opt{grid-column:span 2;flex-direction:row;justify-content:center;font-weight:600;color:#000000;min-height:44px}',
    '@media print{#toast,.ue-inline,.ue-pick{display:none!important}}'
  ].join('\n');
  function addCss() { if (document.getElementById('ue-css')) return; var s = document.createElement('style'); s.id = 'ue-css'; s.textContent = CSS; document.head.appendChild(s); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]; }); }
  function toast(t, ms) {
    var e = document.getElementById('toast');
    if (!e) { e = document.createElement('div'); e.id = 'toast'; document.body.appendChild(e); }
    e.textContent = t; e.classList.add('on'); clearTimeout(e._t); e._t = setTimeout(function () { e.classList.remove('on'); }, ms || 2200);
  }
  function keys(p) { return String(p).split('.').map(function (k) { return /^\d+$/.test(k) ? +k : k; }); }
  function path(o, p) { var ks = keys(p); for (var i = 0; i < ks.length; i++) { if (o == null) return undefined; o = o[ks[i]]; } return o; }
  function setPath(o, p, v) {
    var ks = keys(p);
    for (var i = 0; i < ks.length - 1; i++) {
      if (o[ks[i]] == null || typeof o[ks[i]] !== 'object') o[ks[i]] = typeof ks[i + 1] === 'number' ? [] : {};
      o = o[ks[i]];
    }
    o[ks[ks.length - 1]] = v;
  }

  // ---------------------------------------------------------------------------------------------- undo / redo
  function UndoStack(limit) { this.s = []; this.i = -1; this.limit = limit || 300; this.timer = null; }
  UndoStack.prototype.reset = function (st) { this.s = [st]; this.i = 0; };
  UndoStack.prototype.top = function () { return this.s[this.i]; };
  UndoStack.prototype.push = function (st) {
    if (this.s[this.i] === st) return false;
    this.s = this.s.slice(0, this.i + 1); this.s.push(st);
    if (this.s.length > this.limit) this.s.shift();
    this.i = this.s.length - 1; return true;
  };
  UndoStack.prototype.undo = function () { return this.i > 0 ? this.s[--this.i] : null; };
  UndoStack.prototype.redo = function () { return this.i < this.s.length - 1 ? this.s[++this.i] : null; };
  UndoStack.prototype.canUndo = function () { return this.i > 0; };
  UndoStack.prototype.canRedo = function () { return this.i < this.s.length - 1; };

  // ---------------------------------------------------------------------------------------------- save this page
  function Saver(o) { this.o = o; this.handle = null; }   // o: {pristine, data() -> object for the data block, fileName()}
  Saver.prototype.html = function () {
    var P = this.o.pristine, m = new RegExp('<' + 'script id="data"[^>]*>').exec(P);
    if (!m) throw new Error('the page data was not found');
    var a = m.index + m[0].length, b = P.indexOf('<' + '/script>', a);
    return P.slice(0, a) + JSON.stringify(this.o.data()).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029') + P.slice(b);
  };
  Saver.prototype.save = function () {
    var self = this, name = (this.o.fileName && this.o.fileName()) || 'page.html', blob;
    try { blob = new Blob([this.html()], {type: 'text/html'}); } catch (e) { toast('Not saved: ' + e.message); return Promise.resolve(false); }
    function download() {
      var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
      document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
      toast('Saved to your downloads as ' + name + ' - open that file to keep editing'); return true;
    }
    if (!window.showSaveFilePicker) return Promise.resolve(download());
    var pick = this.handle ? Promise.resolve(this.handle) : window.showSaveFilePicker({suggestedName: name, types: [{description: 'Web page', accept: {'text/html': ['.html', '.htm']}}]});
    return pick.then(function (h) {
      return h.createWritable().then(function (w) { return w.write(blob).then(function () { return w.close(); }); })
        .then(function () { self.handle = h; toast('Saved ' + h.name); return true; });
    }).catch(function (e) { return e && e.name === 'AbortError' ? false : download(); });
  };
  function fileName(fallback) {
    try { var n = decodeURIComponent(location.pathname.split('/').pop() || ''); return /\.html?$/i.test(n) ? n : fallback; } catch (e) { return fallback; }
  }

  // ---------------------------------------------------------------------------------------------- the text box over a drawn text
  function Inline(o) {   // o: {input(value), done(keep), limit?}
    this.o = o; this.el = null; this.ta = null; this.st = null; this.old = '';
  }
  Inline.prototype.open = function (rect, value, look) {
    this.close(true);
    var self = this, el = document.createElement('div'), ta = document.createElement('textarea'), st = document.createElement('div');
    el.className = 'ue-inline'; st.className = 'ue-st'; el.appendChild(ta); el.appendChild(st); document.body.appendChild(el);
    this.el = el; this.ta = ta; this.st = st; this.old = value; this.look = look || {};
    ta.value = value; ta.setAttribute('aria-label', this.look.label || 'Text');
    ta.style.font = (this.look.weight || 400) + ' ' + Math.max(12, Math.min(30, this.look.size || 15)) + 'px ' + (this.look.family || 'inherit');
    this.place(rect); this.grow(); this.status();
    ta.addEventListener('input', function () { self.grow(); self.status(); self.o.input(ta.value); });
    ta.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); self.close(true); }
      else if (e.key === 'Escape') { e.preventDefault(); self.close(false); }
      e.stopPropagation();
    });
    ta.addEventListener('blur', function () { setTimeout(function () { if (self.ta === ta && document.activeElement !== ta) self.close(true); }, 120); });
    setTimeout(function () { ta.focus(); ta.select(); }, 0);
  };
  Inline.prototype.place = function (r) {
    if (!this.el || !r) return;
    var w = Math.max(200, Math.min(window.innerWidth - 24, r.width + 16)), x = Math.max(12, Math.min(window.innerWidth - w - 12, r.left - 8));
    var y = r.top - 7; if (y + 60 > window.innerHeight) y = Math.max(8, window.innerHeight - 120);
    this.el.style.left = x + 'px'; this.el.style.top = Math.max(8, y) + 'px'; this.el.style.width = w + 'px';
  };
  Inline.prototype.grow = function () { if (!this.ta) return; this.ta.style.height = 'auto'; this.ta.style.height = Math.min(220, this.ta.scrollHeight + 2) + 'px'; };
  Inline.prototype.status = function () {
    if (!this.st) return;
    var n = Array.from(this.ta.value.trim()).length, lim = this.look.limit, over = lim && n > lim;
    this.st.className = 'ue-st' + (over ? ' warn' : '');
    this.st.innerHTML = '<span>' + (over ? 'Longer than ' + lim + ' characters - it will be cut with \u2026' : esc(this.look.hint || 'Enter to finish \u00b7 Esc to undo')) + '</span><span>' + n + (lim ? ' / ' + lim : '') + '</span>';
  };
  Inline.prototype.isOpen = function () { return !!this.el; };
  Inline.prototype.close = function (keep) {
    if (!this.el) return;
    var el = this.el, ta = this.ta, old = this.old;
    this.el = this.ta = this.st = null; el.remove();
    if (!keep && ta.value !== old) this.o.input(old);
    this.o.done(keep);
  };

  // ---------------------------------------------------------------------------------------------- icons
  var SYN = {money: ['wallet', 'cost', 'price', 'revenue', 'budget', 'receipt'], dollar: ['wallet', 'cost', 'price', 'revenue'], cash: ['wallet', 'payment'], cost: ['wallet', 'price', 'tag'],
    revenue: ['sales', 'bar-chart', 'trend-up'], profit: ['trend-up', 'growth', 'wallet'], people: ['team', 'person', 'user'], staff: ['team', 'person'], customer: ['person', 'customer-love', 'user', 'heart'],
    time: ['calendar', 'milestones', 'speed', 'clock'], date: ['calendar'], fast: ['speed', 'performance'], risk: ['warning', 'alert', 'blocked'], issue: ['warning', 'alert'], problem: ['warning', 'alert', 'puzzle'],
    security: ['lock', 'compliance', 'verified'], safe: ['lock', 'compliance'], quality: ['verified', 'award', 'star', 'rating'], goal: ['target', 'focus'], idea: ['insight', 'idea'], data: ['analytics', 'chart', 'laptop'],
    report: ['analytics', 'document'], store: ['stores', 'shelf', 'location'], shop: ['stores', 'bag', 'add-to-bag'], product: ['package', 'cube', 'bag'], stock: ['shelf', 'package', 'cube'], inventory: ['shelf', 'package'],
    ship: ['delivery', 'package'], truck: ['delivery'], deliver: ['delivery'], email: ['email', 'inbox'], talk: ['chat', 'conversation', 'comment'], process: ['gears', 'sliders', 'milestones'], settings: ['gears', 'sliders'],
    win: ['award', 'crown', 'star'], success: ['award', 'thumbs-up', 'growth-check'], growth: ['trend-up', 'growth', 'team-growth'], beauty: ['lipstick', 'lashes', 'skin', 'salon'], mobile: ['mobile', 'touch'], phone: ['mobile']};
  function iconMarkup(icons, name) {   // the pictogram in currentColor, for buttons and the gallery
    var i = icons && icons[name];
    return i ? '<svg viewBox="' + i.vb + '" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' + i.inner.replace(/(fill|stroke)="#[0-9A-Fa-f]{3,6}"/g, '$1="currentColor"') + '</svg>' : '';
  }
  function IconPicker(icons, catalog) {
    this.icons = icons || {}; this.kw = {}; var self = this;
    (catalog || []).forEach(function (c) { self.kw[c[0]] = c[1] || []; });
    var d = document.createElement('div'); d.className = 'ue-pick'; d.setAttribute('role', 'dialog'); d.setAttribute('aria-label', 'Pick an icon');
    d.innerHTML = '<div class="box"><div class="top"><b></b><input placeholder="Search - e.g. money, team, growth, store" aria-label="Search icons"><button type="button" class="pill">Close</button></div><div class="grid"></div></div>';
    document.body.appendChild(d); this.d = d; this.q = d.querySelector('input'); this.g = d.querySelector('.grid');
    d.addEventListener('click', function (e) { if (e.target === d) self.close(); });
    d.querySelector('.top button').onclick = function () { self.close(); };
    this.q.oninput = function () { self.paint(); };
    this.q.onkeydown = function (e) { if (e.key === 'Escape') { e.stopPropagation(); self.close(); } };
  }
  IconPicker.prototype.open = function (o) {   // o: {title, current, auto (offer "match the words"), none (offer "no icon"), pick(name|'')}
    this.o = o; this.d.querySelector('b').textContent = o.title || 'Pick an icon'; this.q.value = '';
    this.d.classList.add('on'); this.paint(); var q = this.q; setTimeout(function () { q.focus(); }, 30);
  };
  IconPicker.prototype.close = function () { this.d.classList.remove('on'); };
  IconPicker.prototype.paint = function () {
    var self = this, q = this.q.value.trim().toLowerCase(), o = this.o || {};
    var qs = q ? [q].concat(SYN[q] || Object.keys(SYN).filter(function (w) { return q.length >= 3 && w.indexOf(q) === 0; }).reduce(function (a, w) { return a.concat(SYN[w]); }, [])) : [];
    var hit = function (n) { return qs.some(function (w) { return n.indexOf(w) >= 0 || (self.kw[n] || []).some(function (k) { return k.indexOf(w) >= 0 || (w.length >= 4 && k.length >= 4 && w.indexOf(k) >= 0); }); }); };
    var names = Object.keys(this.icons).filter(function (n) { return !q || hit(n); });
    var opt = o.auto ? '<button type="button" class="opt' + (!o.current ? ' cur' : '') + '" data-n="">Auto - match the words</button>' : o.none ? '<button type="button" class="opt' + (!o.current ? ' cur' : '') + '" data-n="">No icon</button>' : '';
    this.g.innerHTML = opt + names.map(function (n) {
      return '<button type="button" data-n="' + esc(n) + '" class="' + (n === o.current ? 'cur' : '') + '" title="' + esc(n + ' - ' + (self.kw[n] || []).join(', ')) + '">' + iconMarkup(self.icons, n) + '<span>' + esc(n) + '</span></button>';
    }).join('') + (names.length ? '' : '<div style="grid-column:1/-1;color:#404040;font-size:12px">No icon matches \u201c' + esc(q) + '\u201d.</div>');
    this.g.querySelectorAll('button[data-n]').forEach(function (b) { b.onclick = function () { self.close(); if (o.pick) o.pick(b.getAttribute('data-n')); }; });
  };

  root.UltaPage = {addCss: addCss, esc: esc, toast: toast, path: path, setPath: setPath, UndoStack: UndoStack, Saver: Saver, fileName: fileName,
    Inline: Inline, IconPicker: IconPicker, iconMarkup: iconMarkup};
})(this);
