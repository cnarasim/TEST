/* The infographic layout (kit/infographic/info.py and the two template blocks of templates.py) in the page, so the page relays
   itself out after an edit with no chat and no server. A line-for-line port: same blocks, sizes, fitting, pagination and SVG;
   tests/parity compares it with the Python layout on hundreds of contents. Each drawn text carries `p`, the field of the content
   it shows ("blocks.2.items.1.value"), which is what the page's editor changes when that text is clicked.
   Needs UltaCore (engine-core.js). Never contains a closing script tag. */
(function (root, factory) {
  var core = typeof module === 'object' && module.exports ? require('./engine-core.js') : root.UltaCore;
  var m = factory(core);
  if (typeof module === 'object' && module.exports) module.exports = m; else root.UltaInfo = m;
})(this, function (C) {
  'use strict';
  var pyRound = C.pyRound, fit = C.fit, wrap = C.wrap, clean = C.clean, tint = C.tint, shade = C.shade, textW = C.textW, truthy = C.truthy, isObj = C.isObj;
  var INK = '000000', MUTED = '404040', LINE = 'D9D9D9', GOLD = 'FF893F', TITLE = 'EE6C37';
  var PALETTE = ['F26923', 'E8275A', 'D01381', '5D0F43', 'E9341C'];   // v139: the brand's colours in turn (info.py PALETTE)
  var TOP_RULE = ['EE6C37', 'E8275A'];   // the page's top rule: Ulta orange into raspberry
  // v139: the Ulta look (info.py GRAD, LOOKS, LIGHT_STAGES, LIGHT_LEAD): 'light' leads with a light orange gradient and dark words on the big
  // shapes; 'gradient' runs them deep with white words; 'flat' draws the colours as they are. Marks run into a deeper shade of their colour.
  var GRAD = {F26923: ['F26923', 'E9341C'], EE6C37: ['EE6C37', 'E9341C'], E9341C: ['E9341C', 'E0531B'], E0531B: ['E0531B', 'E9341C'],
    F24C26: ['F24C26', 'E9341C'], E8275A: ['E8275A', 'DB0058'], D01381: ['D01381', 'C10060'], '5D0F43': ['C10060', '5D0F43'],
    DB0058: ['DB0058', 'C10060'], C10060: ['C10060', '5D0F43']};
  var LOOKS = ['light', 'gradient', 'flat'];
  var LIGHT_STAGES = [['FF893F', 'FF7826'], ['FF7826', 'F26923'], ['FF7826', 'F24C26'], ['FF7826', 'E9341C'], ['FF7826', 'E0531B']];
  var LIGHT_LEAD = ['FF893F', 'F26923'];
  var DEEP = 'DB0058', FILLED = ['ulta', 'sunset', 'velvet', 'charcoal'];
  var LIGHT_CARD = 'FDE1D2';   // v136: on the Ulta theme an element that carries words is the pale orange with dark words (info.py LIGHT_CARD)
  var PASTEL = {F26923: 'FDE1D2', EE6C37: 'FDE1D2', E8275A: 'FAD3DB', D01381: 'E4C8DB', '5D0F43': 'E4C8DB', E9341C: 'F9E3DE',
    E0531B: 'FDE1D2', F24C26: 'F9E3DE'};   // sunset's light ends
  var DISPLAY = "'Playfair Display Black','Playfair Display',Georgia,'Times New Roman',serif";
  var BODY = "'Circular Std','Circular Std Book',Circular,Inter,'Helvetica Neue',Helvetica,Arial,sans-serif";
  var FORMATS = {
    slide: {name: 'Slide 16:9', w: 1600, h: 900, body: [60, 174, 1480, 620]},
    onepager: {name: 'One-pager', w: 1020, h: 1320, margin: 60},
    square: {name: 'Social square', w: 1080, h: 1080, margin: 56}
  };
  var BLOCKS = ['stats', 'steps', 'timeline', 'compare', 'bars', 'donut', 'list', 'quote', 'takeaway', 'status', 'rag', 'risks', 'table', 'ragcards',
    'image', 'gallery', 'feature', 'band', 'flow', 'stairs', 'chevrons', 'pyramid', 'curve', 'hub', 'house', 'cards', 'rings'];
  var WIDE = new Set(['stats', 'steps', 'timeline', 'compare', 'list', 'takeaway', 'status', 'rag', 'risks', 'table', 'ragcards', 'gallery', 'feature', 'band', 'flow',
    'stairs', 'chevrons', 'pyramid', 'curve', 'hub', 'house', 'cards', 'rings']);
  var HALF = new Set(['table', 'list', 'risks', 'timeline', 'stats', 'compare', 'steps', 'donut', 'bars', 'quote', 'image']);
  var PIC_H = 430, REF = /^[0-9a-f]{12}$/;
  var THEME_ORDER = ['ulta', 'glow', 'velvet', 'frost', 'paper', 'sunset', 'charcoal'];
  var ALIASES = {consulting: 'paper', apple: 'frost', carbon: 'paper', material: 'glow', editorial: 'frost', ink: 'charcoal'};
  var ICON_SIZE = {s: 0.85, m: 1.0, l: 1.22};
  var STAT_ICONS = ['trend-up', 'target', 'performance', 'award'];
  var LIST_FALLBACK = ['idea', 'check', 'star', 'target', 'performance', 'award', 'lightbulb', 'flag'];
  var RAG = {green: ['2E8B57', 'On track'], amber: ['D99100', 'At risk'], red: ['C8102E', 'Off track'], '': ['9A8F88', 'Not set']};
  var RAG_WORDS = [['red', /^\s*(r|red|off[ -]?track|blocked|critical|high|\u{1F534})(?![a-z])/u], ['amber', /^\s*(a|amber|yellow|y|at[ -]?risk|watch|medium|med|\u{1F7E0}|\u{1F7E1})(?![a-z])/u],
    ['green', /^\s*(g|green|on[ -]?track|ok|done|complete[d]?|low|\u{1F7E2})(?![a-z])/u]];
  var STATUS_ICONS = [[/secur|firewall|access|auth|compliance/, 'lock'], [/integrat|interface|api|connect|delta share|pipeline/, 'network'], [/test|qa|quality|uat|validat/, 'verified-badge'],
    [/\bai\b|data science|model|ml\b|machine learning|forecast/, 'idea'], [/report|\bbi\b|kpi|dashboard|analytics/, 'bar-chart'],
    [/data|requirement|mapping|source/, 'laptop-analytics'], [/design|architect/, 'puzzle'], [/assort|range/, 'shelf'], [/alloc|replen/, 'shuffle'],
    [/store|site/, 'stores'], [/price|pricing|promo/, 'tag'], [/deliver|logist|supply|dc\b|warehouse/, 'delivery'], [/change|train|people|adoption/, 'team'],
    [/vendor|partner|infosys|databricks|o9|sap|accenture|deloitte/, 'team-growth'], [/risk|issue|block/, 'warning'], [/support|help|escalat/, 'support'],
    [/budget|cost|finance/, 'wallet'], [/launch|go[- ]live|cutover|release/, 'target'], [/customer|guest/, 'customer-love'], [/plan|program|project/, 'milestones']];
  var STATUS_FALLBACK = ['performance', 'gears', 'insight', 'layers', 'puzzle', 'cube', 'growth-check', 'focus', 'sliders', 'network'];
  var FACT_ICON = {'overall status': 'performance', 'week ending': 'calendar', phase: 'milestones', 'project lead': 'person'};
  var FACT_ICONS = [[/status|rag|health/, 'performance'], [/lead|owner|sponsor|manager|commander|decision owner/, 'person'], [/budget|cost|price|spend/, 'wallet'],
    [/week|period|date|start|end|go[- ]live|launch|steerco|updated|needed by|due|when/, 'calendar'], [/phase|stage|milestone/, 'milestones'],
    [/audience|for$|team|who/, 'team'], [/impact|severity|priority|risk/, 'warning'], [/duration|time|speed|frequency/, 'speed'], [/system|tool|platform/, 'laptop-analytics'],
    [/trigger|start when/, 'pointer'], [/topic|subject|area/, 'idea'], [/programme|program|project|product/, 'layers']];
  var SECTION_ICON = {rag: 'team', risks: 'warning', timeline: 'milestones', list: 'idea', steps: 'list', stats: 'bar-chart', table: 'list', ragcards: 'team', compare: 'balance', quote: 'chat'};
  var SPLIT = new Set(['ragcards', 'table', 'rag', 'risks', 'list', 'timeline', 'steps']);
  var RAGCOL = /^(status|rag|health|state)$/i, SEVCOL = /^(severity|priority|impact)$/i;
  var S = {squeeze: false, look: 'light'};

  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function get(o, k, d) { return o && has(o, k) && o[k] !== undefined ? o[k] : d; }
  function iconSet() { return new Set(C.iconNames()); }
  function fl() { return C.state.minFs || 14; }
  function num(v) {
    var m = C.pyStr(C.or(v)).match(/-?\d[\d,]*(?:\.\d+)?/);
    if (!m) return null;
    var x = Number(m[0].replace(/,/g, ''));
    return isNaN(x) ? null : x;
  }
  function resolveTheme(name) { name = C.pyStr(C.or(name) || 'ulta').toLowerCase(); name = has(ALIASES, name) ? ALIASES[name] : name; return THEME_ORDER.indexOf(name) >= 0 ? name : 'ulta'; }
  function ragOf(v) {
    var s = C.pyStrip(C.pyStr(C.or(v))).toLowerCase();
    for (var i = 0; i < RAG_WORDS.length; i++) if (RAG_WORDS[i][1].test(s)) return RAG_WORDS[i][0];
    return '';
  }
  function deep(c) { return C.contrast('FFFFFF', c) >= 4.5; }   // white words read on c: the raspberries, berry and plum
  function style(theme, c, role) {   // role 'card': the element carries words (the default); 'mark': it does not (info.py style)
    var t = THEME_ORDER.indexOf(theme) >= 0 ? theme : 'ulta', card = (role || 'card') === 'card';
    if (t === 'ulta' && card) return {fill: LIGHT_CARD, grad: null, stroke: null, glow: null, text: INK, sub: MUTED, head: INK, icon: 'E0531B', r: 14};
    if (t === 'ulta') { var g = S.look !== 'flat' && has(GRAD, c) ? GRAD[c].slice() : null; return {fill: g ? g[0] : c, grad: g, stroke: null, glow: null, text: 'FFFFFF', sub: 'FFFFFF', head: 'FFFFFF', icon: 'FFFFFF', r: 14}; }
    if (t === 'glow') return {fill: 'FFFFFF', grad: null, stroke: 'EFE4DD', glow: tint(c, 0.72), text: INK, sub: MUTED, head: c, icon: c, r: 18};
    if (t === 'velvet') return {fill: INK, grad: [shade(deep(c) ? c : DEEP, 0.05), '231B18'], stroke: null, glow: null, text: 'FFFFFF', sub: 'F9E3DE', head: 'FFFFFF', icon: 'FFFFFF', r: 16};
    if (t === 'frost') return {fill: tint(c, 0.8), grad: null, stroke: 'FFFFFF', glow: null, text: INK, sub: '4A403B', head: shade(c, 0.12), icon: shade(c, 0.05), r: 22};
    if (t === 'paper') return {fill: 'FFFFFF', grad: null, stroke: c, glow: null, text: INK, sub: MUTED, head: c, icon: c, r: 8};
    if (t === 'sunset' && card) return {fill: GOLD, grad: [GOLD, has(PASTEL, c) ? PASTEL[c] : 'FFF3ED'], stroke: null, glow: null, text: INK, sub: MUTED, head: '5D0F43', icon: '5D0F43', r: 16};
    if (t === 'sunset') return {fill: c, grad: [c, deep(c) ? DEEP : GOLD], stroke: null, glow: null, text: 'FFFFFF', sub: 'FFFFFF', head: 'FFFFFF', icon: 'FFFFFF', r: 16};
    return {fill: '404040', grad: null, stroke: null, glow: null, text: 'FFFFFF', sub: 'E6DCD6', head: 'FFFFFF', icon: 'FFFFFF', r: 12};
  }

  // ------------------------------------------------------------------------------------------------ content \u2192 spec
  // Blocks and items keep where they came from (_i: the block's place in the content, _j: each item's), through every
  // re-normalising, splitting and dropping, so a drawn text always knows the field it shows.
  function rawList(v, n) { return Array.isArray(v) ? v.slice(0, n) : typeof v === 'string' ? Array.from(v).slice(0, n) : []; }
  function jmap(b, key, keep) { var src = key ? (isObj(b[key]) ? b[key]._j : null) : b._j; return keep.map(function (k) { return Array.isArray(src) ? src[k] : k; }); }
  function splitBar(s, keys) { var p = String(s).split('|').map(function (q) { return C.pyStrip(q); }), o = {}; keys.forEach(function (k, i) { o[k] = i < p.length ? p[i] : ''; }); return o; }
  function items(v, keys, n, ICONS) {
    var out = [], keep = [];
    rawList(v, n).forEach(function (it, ix) {
      if (typeof it === 'string') it = splitBar(it, keys);
      if (!isObj(it)) return;
      var o = {};
      keys.forEach(function (k) { if (k !== 'icon') o[k] = clean(it[k], ['title', 'when', 'value', 'label'].indexOf(k) >= 0 ? 90 : 170); });
      if (typeof it.icon === 'string' && ICONS.has(it.icon)) o.icon = it.icon;
      if (keys.some(function (k) { return k !== 'icon' && C.pyStrip(C.pyStr(C.or(o[k]))); })) { out.push(o); keep.push(ix); }
    });
    return [out, keep];
  }
  function normalise(spec) {
    var s = isObj(spec) ? spec : {}, ICONS = iconSet();
    var out = {title: clean(s.title, 90) || 'Infographic', subtitle: clean(s.subtitle, 180), kicker: clean(s.kicker, 40).toUpperCase(), source: clean(s.source, 160),
      format: typeof s.format === 'string' && has(FORMATS, s.format) ? s.format : 'onepager', theme: truthy(s.theme) ? resolveTheme(s.theme) : 'ulta', blocks: []};
    if (truthy(s.template) && /^[a-z_]{2,24}$/.test(C.pyStr(s.template))) out.template = s.template;
    if (THEME_ORDER.indexOf(out.theme) < 0) out.theme = 'ulta';
    if (LOOKS.indexOf(s.look) >= 0 && s.look !== 'light') out.look = s.look;   // v139: the Ulta look - light (default), gradient or flat
    var io = isObj(s.icons) ? s.icons : null;
    if (io && Object.keys(io).length) out.icons = {size: has(ICON_SIZE, io.size) ? io.size : 'm', weight: io.weight === 'bold' ? 'bold' : 'regular', badge: ['auto', 'filled', 'light'].indexOf(io.badge) >= 0 ? io.badge : 'auto'};
    if (typeof s._sp === 'string') out._sp = s._sp;
    rawList(s.blocks, 8).forEach(function (b, bi) {
      if (!isObj(b) || BLOCKS.indexOf(b.type) < 0) return;
      var t = b.type, nb = {type: t, title: clean(b.title, 60)}, r;
      nb._i = typeof b._i === 'number' ? b._i : bi;
      if (t === 'stats') { r = items(b.items, ['value', 'label', 'icon'], 4, ICONS); nb.items = r[0]; nb._j = jmap(b, null, r[1]); }
      else if (t === 'steps') { r = items(b.items, ['title', 'text'], 6, ICONS); nb.items = r[0]; nb._j = jmap(b, null, r[1]); }
      else if (t === 'timeline') { r = items(b.items, ['when', 'title', 'text'], 7, ICONS); nb.items = r[0]; nb._j = jmap(b, null, r[1]); }
      else if (t === 'list') { r = items(b.items, ['title', 'text', 'icon'], 9, ICONS); nb.items = r[0]; nb._j = jmap(b, null, r[1]); }
      else if (t === 'bars') {
        r = items(b.items, ['label', 'value'], 8, ICONS); var bk = [];
        nb.items = r[0].filter(function (it, x) { var ok = num(it.value) !== null; if (ok) bk.push(r[1][x]); return ok; }); nb._j = jmap(b, null, bk); nb.unit = clean(b.unit, 12);
      } else if (t === 'donut') {
        r = items(b.items, ['value', 'label'], 3, ICONS); var dk = [];
        nb.items = r[0].filter(function (it, x) { var ok = num(it.value) !== null; if (ok) dk.push(r[1][x]); return ok; }); nb._j = jmap(b, null, dk);
      } else if (t === 'status' || t === 'rag' || t === 'risks') {
        var keys = {status: ['label', 'value', 'rag'], rag: ['name', 'owner', 'rag', 'now', 'next'], risks: ['title', 'text', 'owner', 'due', 'rag']}[t], sk = [];
        nb.items = [];
        rawList(b.items, {status: 5, rag: 10, risks: 6}[t]).forEach(function (it, ix) {
          if (typeof it === 'string') it = splitBar(it, keys);
          if (!isObj(it)) return;
          var o = {}; keys.forEach(function (k) { o[k] = clean(it[k], 200); });
          if (o.rag) o.rag = ragOf(o.rag) || '';
          if (keys.some(function (k) { return k !== 'rag' && o[k]; })) { nb.items.push(o); sk.push(ix); }
        });
        nb._j = jmap(b, null, sk);
        if (t === 'rag') {
          var cs = Array.isArray(b.cols) && b.cols.length ? b.cols.slice(0, 2) : ['This week', 'Next week'];
          nb.cols = cs.map(function (c) { return clean(c, 40); }).concat(['This week', 'Next week'].slice(rawList(b.cols, 2).length));
        }
      } else if (t === 'table') {
        nb.cols = rawList(b.cols, 6).map(function (c) { return clean(c, 40); }); var n = nb.cols.length, tk = [];
        nb.icons = truthy(b.icons);
        nb.items = [];
        rawList(b.items, 10).forEach(function (row, ix) {
          if (!Array.isArray(row) || !row.some(function (c) { return C.pyStrip(C.pyStr(c)); })) return;
          var cells = row.concat(new Array(n).fill('')).slice(0, n).map(function (c) { return clean(c, 160); });
          nb.items.push(cells); tk.push(ix);
        });
        nb._j = jmap(b, null, tk);
        if (!n || !nb.items.length) return;
      } else if (t === 'ragcards') {
        nb.items = []; var rk = [];
        rawList(b.items, 9).forEach(function (it, ix) {
          if (typeof it === 'string') { var p = it.split('|').map(function (q) { return C.pyStrip(q); }).concat(['', '', '', '']); it = {name: p[0], owner: p[1], rag: p[2], text: p[3]}; }
          if (isObj(it) && C.pyStrip(C.pyStr(C.or(it.name)))) { nb.items.push({name: clean(it.name, 200), owner: clean(it.owner, 200), text: clean(it.text, 420), rag: ragOf(it.rag)}); rk.push(ix); }
        });
        nb._j = jmap(b, null, rk);
      } else if (t === 'compare') {
        ['left', 'right'].forEach(function (side) {
          var v = isObj(b[side]) ? b[side] : {}, ck = [], its = [];
          rawList(v.items, 6).forEach(function (x, ix) { if (clean(x)) { its.push(clean(x, 140)); ck.push(ix); } });
          nb[side] = {title: clean(v.title, 40) || (side === 'left' ? 'Today' : 'Target'), items: its, _j: jmap(b, side, ck)};
        });
        if (!nb.left.items.length && !nb.right.items.length) return;
      } else if (t === 'quote') {
        nb.text = clean(b.text, 240); nb.by = clean(b.by, 60);
        if (!nb.text) return;
      } else if (t === 'takeaway') {
        nb.text = clean(b.text, 220);
        if (typeof b.icon === 'string' && ICONS.has(b.icon)) nb.icon = b.icon;
        if (!nb.text) return;
      } else if (t === 'image' || t === 'feature') {
        Object.assign(nb, pictureFields(b));
        if (t === 'feature') {
          nb.side = b.side === 'left' ? 'left' : 'right'; r = items(b.items, ['title', 'text', 'icon'], 6, ICONS); nb.items = r[0]; nb._j = jmap(b, null, r[1]);
          if (!nb.items.length) { nb.type = 'image'; delete nb.items; delete nb.side; delete nb._j; }
        }
        if (!nb.src) return;
      } else if (t === 'gallery') {
        nb.items = []; var gk = [];
        rawList(b.items, 4).forEach(function (it, ix) { if (!isObj(it)) return; var f = pictureFields(it); if (!f.src) return; delete f.frame; delete f.fit; nb.items.push(f); gk.push(ix); });
        nb._j = jmap(b, null, gk); nb.fit = ['contain', 'cover'].indexOf(b.fit) >= 0 ? b.fit : '';
      } else if (t === 'band') {
        nb.label = clean(b.label, 30); r = items(b.items, ['title', 'icon'], 5, ICONS); nb.items = r[0]; nb._j = jmap(b, null, r[1]);
      } else if (['stairs', 'chevrons', 'pyramid', 'curve', 'rings'].indexOf(t) >= 0) {   // v139: ways to tell it
        r = items(b.items, ['when', 'title', 'text', 'icon'], t === 'rings' ? 4 : 5, ICONS); nb.items = r[0]; nb._j = jmap(b, null, r[1]);
      } else if (t === 'hub' || t === 'cards') {
        r = items(b.items, ['title', 'text', 'icon'], t === 'hub' ? 8 : 9, ICONS); nb.items = r[0]; nb._j = jmap(b, null, r[1]);
        if (t === 'hub') nb.center = clean(b.center, 80);
      } else if (t === 'house') {
        nb.roof = clean(b.roof, 200); nb.base = clean(b.base, 200); r = items(b.items, ['title', 'text', 'icon'], 6, ICONS); nb.items = r[0]; nb._j = jmap(b, null, r[1]);
        if (typeof b.icon === 'string' && ICONS.has(b.icon)) nb.icon = b.icon;
      } else if (t === 'flow') {
        nb.lanes = [];
        rawList(b.lanes, 2).forEach(function (ln, li) {
          if (!isObj(ln)) return;
          var rr = items(ln.items, ['title', 'icon'], 6, ICONS);
          if (rr[0].length) nb.lanes.push({title: clean(ln.title, 60), tone: ['before', 'after'].indexOf(ln.tone) >= 0 ? ln.tone : '', items: rr[0], _l: li, _j: jmap(ln, null, rr[1])});
        });
        if (!nb.lanes.length) return;
      }
      if (has(nb, 'items') && !nb.items.length) return;
      if (b.half === true) nb.half = true;   // v139: shares its row with the next block marked half
      out.blocks.push(nb);
    });
    var imgs = isObj(s.images) ? s.images : {}, used = [];
    out.blocks.forEach(function (b) {
      [b.src].concat(b.type === 'gallery' ? b.items.map(function (it) { return it.src; }) : []).forEach(function (r_) { if (typeof r_ === 'string' && has(imgs, r_) && used.indexOf(r_) < 0) used.push(r_); });
    });
    if (used.length) { out.images = {}; used.forEach(function (r_) { out.images[r_] = imgs[r_]; }); }   // the pictures the blocks show, each once
    return out;
  }
  function pictureFields(b) {   // a picture's fields as a block (or a gallery item) gives them
    var src = C.pyStrip(C.pyStr(C.or(b.src) || C.or(b.image) || C.or(b.picture) || '')).slice(0, 400), cap = clean(b.caption, 160);
    return {src: src, caption: cap, alt: clean(b.alt, 160),   // kept only when given: drawn, the caption or the title stands in
      frame: ['auto', 'browser', 'phone', 'plain'].indexOf(b.frame) >= 0 ? b.frame : 'auto', fit: ['contain', 'cover'].indexOf(b.fit) >= 0 ? b.fit : ''};
  }
  var INTERNAL = ['_i', '_j', '_ic', '_tpl', '_sp', '_page', '_im', '_l', '_cols'];
  function strip(o) {   // the spec without the engine's own keys (as the Python layout returns it)
    if (Array.isArray(o)) return o.map(strip);
    if (!isObj(o)) return o;
    var r = {}; Object.keys(o).forEach(function (k) { if (INTERNAL.indexOf(k) < 0) r[k] = strip(o[k]); }); return r;
  }

  // ------------------------------------------------------------------------------------------------ paths
  function bp(b, f) { return typeof b._i === 'number' ? 'blocks.' + b._i + (f ? '.' + f : '') : null; }
  function ip(b, i, f) { return typeof b._i === 'number' ? 'blocks.' + b._i + '.items.' + (Array.isArray(b._j) ? b._j[i] : i) + (f !== undefined && f !== null ? '.' + f : '') : null; }
  function kw(p, more) { var o = more || {}; if (p) o.p = p; return o; }

  // ------------------------------------------------------------------------------------------------ icons
  function listIcon(it, used) {
    var p = it.icon || C.pickIcon(get(it, 'title', '') + ' ' + get(it, 'text', ''));
    if (!p || used.has(p) || C.iconSvg(p) === null) {
      var nx = LIST_FALLBACK.concat(STAT_ICONS).find(function (x) { return !used.has(x) && C.iconSvg(x) !== null; });
      p = nx !== undefined ? nx : (p || 'idea');
    }
    used.add(p);
    return p;
  }
  function statusIcon(text, used) {
    used = used || new Set(); var s = C.pyStr(C.or(text)).toLowerCase(), ICONS = iconSet();
    for (var i = 0; i < STATUS_ICONS.length; i++) {
      var ic = STATUS_ICONS[i][1];
      if (STATUS_ICONS[i][0].test(s) && ICONS.has(ic) && !used.has(ic)) { used.add(ic); return ic; }
    }
    var p = C.pickIcon(text);
    if (p && ICONS.has(p) && !used.has(p)) { used.add(p); return p; }
    var f = STATUS_FALLBACK.find(function (x) { return ICONS.has(x) && !used.has(x); });
    f = f !== undefined ? f : 'idea'; used.add(f); return f;
  }
  function factIcon(label) {
    var l = C.pyStrip(C.pyStr(C.or(label)).toLowerCase()), ICONS = iconSet();
    if (has(FACT_ICON, l)) return FACT_ICON[l];
    var hit = FACT_ICONS.find(function (x) { return x[0].test(l) && ICONS.has(x[1]); });
    return (hit && hit[1]) || statusIcon(label);
  }
  function ic(b) { var o = b._ic || {}; return [has(ICON_SIZE, o.size) ? ICON_SIZE[o.size] : 1.0, o.weight === 'bold', o.badge || 'auto']; }

  // ------------------------------------------------------------------------------------------------ blocks
  function card(cv, x, y, w, h, st, name) {
    name = name || 'card';
    if (st.glow) cv.rect(x + 2, y + 7, w - 4, h, st.glow, null, st.r + 2, undefined, undefined, name + ' glow');
    cv.rect(x, y, w, h, st.fill, st.stroke, st.r, st.stroke ? 1.5 : 1, st.grad, name);
  }
  function blockTitle(cv, b, x, y, w, k, accent) {
    if (!b.title) return 0;
    cv.rect(x, y + 3 * k, 5 * k, 22 * k, accent, null, 2, undefined, undefined, 'title bar');
    var f = fit(b.title, w - 16 * k, 60 * k, pyRound(21 * k), pyRound(15 * k), 'bold', undefined, 2);
    return cv.text(x + 15 * k, y, w - 16 * k, f[1], f[0], INK, 'bold', undefined, undefined, 'block title', b.title, kw(bp(b, 'title'))) + 12 * k;
  }
  function cardIcon(cv, name, x, y, s, colour, theme, o, disc) {   // a card's pictogram: on the Ulta theme in a disc of `disc` with a white one, else a white disc (info.py card_icon)
    if (theme === 'ulta' && disc) {
      var st = style('ulta', disc, 'mark'); cv.ellipse(x, y, s, s, st.fill, null, undefined, 'card icon disc', {grad: st.grad});
      cv.icon(name, x + s * 0.2, y + s * 0.2, s * 0.6, 'FFFFFF', o);
    } else if (theme === 'ulta') { cv.ellipse(x, y, s, s, 'FFFFFF', null, undefined, 'card icon disc'); cv.icon(name, x + s * 0.2, y + s * 0.2, s * 0.6, 'E0531B', o); }
    else cv.icon(name, x, y, s, colour, o);
  }
  function drawStats(cv, b, x, y, w, k, theme, ci) {
    var its = b.items, n = its.length, g = 16 * k, cw = (w - g * (n - 1)) / n, pad = 20 * k, parts = [];
    its.forEach(function (it, i) {
      var c = PALETTE[(ci + i) % PALETTE.length], st = style(theme, c);
      var v = fit(it.value, cw - 2 * pad, 130 * k, pyRound(54 * k), pyRound(24 * k), 'display', 1.08, 2);
      var l = fit(it.label, cw - 2 * pad, 96 * k, pyRound(16 * k), pyRound(12 * k), 'body', 1.3, 4);
      var f_ = ic(b)[0], ih = it.icon ? (40 * k * f_ + 12 * k) : 0;
      parts.push([c, st, v[0], v[1], l[0], l[1], ih]);
    });
    var ch = Math.max.apply(null, parts.map(function (p) { return pad * 2 + p[6] + p[3].length * p[2] * 1.08 + 8 * k + p[5].length * p[4] * 1.3; }));
    its.forEach(function (it, i) {
      var p = parts[i], c = p[0], st = p[1], cx = x + i * (cw + g), yy = y + pad;
      card(cv, cx, y, cw, ch, st, 'stat card');
      if (p[6]) { var o = ic(b); cardIcon(cv, it.icon, cx + pad, yy, 40 * k * o[0], st.icon, theme, kw(ip(b, i, 'icon'), {bold: o[1]}), c); yy += p[6]; }
      yy += cv.text(cx + pad, yy, cw - 2 * pad, p[3], p[2], theme !== 'ulta' ? st.head : 'E9341C', 'display', undefined, 1.08, 'stat value', it.value, kw(ip(b, i, 'value'))) + 8 * k;
      cv.text(cx + pad, yy, cw - 2 * pad, p[5], p[4], st.sub, 'body', undefined, 1.3, 'stat label', it.label, kw(ip(b, i, 'label')));
    });
    return ch;
  }
  function rule(cv, x, y, w, sw, colour, theme, name) {   // the line through steps and dates: a pale line in the block's colour (info.py rule)
    cv.line(x, y, x + w, y, colour, sw, undefined, name);
  }
  function drawSteps(cv, b, x, y, w, k, theme, ci) {
    var its = b.items, n = its.length, colw = w / n, d = 58 * k, cy = y + d / 2, hmax = 0, tex = [];
    rule(cv, x + colw / 2, cy, w - colw, 4 * k, tint(PALETTE[ci % 5], 0.55), theme, 'steps line');
    its.forEach(function (it) {
      var t = fit(it.title, colw - 20 * k, 60 * k, pyRound(17 * k), pyRound(13 * k), 'bold', 1.2, 2);
      var x_ = it.text ? fit(it.text, colw - 20 * k, 110 * k, pyRound(14 * k), pyRound(11 * k), 'body', 1.32, 5) : [0, []];
      tex.push([t[0], t[1], x_[0], x_[1]]); hmax = Math.max(hmax, t[1].length * t[0] * 1.2 + (x_[1].length ? 8 * k + x_[1].length * x_[0] * 1.32 : 0));
    });
    its.forEach(function (it, i) {
      var e = tex[i], c = PALETTE[(ci + i) % 5], st = style(theme, c, theme === 'ulta' ? 'mark' : 'card'), mx = x + i * colw + colw / 2;   // the Ulta dot: a solid orange mark
      if (theme === 'ulta' && S.look === 'light') { var sg = stage(theme, i); st = Object.assign({}, st, {fill: sg[0], grad: sg[1], head: sg[3]}); }   // v139: the light lead
      if (st.glow) cv.ellipse(mx - d / 2 - 3 * k, y - 3 * k + 5 * k, d + 6 * k, d + 6 * k, st.glow, undefined, undefined, 'step glow');
      cv.ellipse(mx - d / 2, y, d, d, !st.grad ? st.fill : st.grad[0], st.stroke, st.stroke ? 2 : 1, 'step dot', {grad: st.grad});
      var nfs = Math.max(30, pyRound(30 * k));   // never under 18 pt: white on an orange dot reads at 3:1 (info.py draw_steps)
      cv.text(mx - d / 2, y + d / 2 - nfs * 0.54, d, [String(i + 1)], nfs, theme !== 'ulta' || st.head === INK ? st.head : 'FFFFFF', 'display', 'center', 1.08, 'step number', undefined, dk(st.head));
      var yy = y + d + 14 * k;
      yy += cv.text(x + i * colw + 10 * k, yy, colw - 20 * k, e[1], e[0], INK, 'bold', 'center', 1.2, 'step title', it.title, kw(ip(b, i, 'title')));
      if (e[3].length) cv.text(x + i * colw + 10 * k, yy + 8 * k, colw - 20 * k, e[3], e[2], MUTED, 'body', 'center', 1.32, 'step text', it.text, kw(ip(b, i, 'text')));
    });
    return d + 14 * k + hmax;
  }
  function drawTimeline(cv, b, x, y, w, k, theme, ci) {
    var its = b.items, n = its.length, colw = w / n, wh = 26 * k, ly = y + wh + 12 * k, c0 = PALETTE[ci % 5], hmax = 0, tex = [];
    rule(cv, x, ly, w, 4 * k, tint(c0, 0.5), theme, 'timeline line');
    its.forEach(function (it) {
      var t = fit(get(it, 'title', ''), colw - 16 * k, 44 * k, pyRound(16 * k), pyRound(12 * k), 'bold', 1.2, 2);
      var x_ = it.text ? fit(get(it, 'text', ''), colw - 16 * k, 100 * k, pyRound(13.5 * k), pyRound(11 * k), 'body', 1.32, 5) : [0, []];
      tex.push([t[0], t[1], x_[0], x_[1]]); hmax = Math.max(hmax, t[1].length * t[0] * 1.2 + (x_[1].length ? 6 * k + x_[1].length * x_[0] * 1.32 : 0));
    });
    its.forEach(function (it, i) {
      var e = tex[i], c = PALETTE[(ci + i) % 5], st = style(theme, c, 'mark'), cx = x + i * colw + 8 * k;
      if (theme === 'ulta' && S.look === 'light') { var sg = stage(theme, i); st = Object.assign({}, st, {fill: sg[0], grad: sg[1]}); c = INK; }   // v139: the light lead, dark labels
      var wv = fit(get(it, 'when', ''), colw - 16 * k, wh, pyRound(17 * k), pyRound(11 * k), 'bold', 1.1, 1);
      cv.text(cx, y, colw - 16 * k, wv[1], wv[0], theme !== 'charcoal' ? c : INK, 'bold', undefined, 1.1, 'timeline when', get(it, 'when', ''), kw(ip(b, i, 'when')));
      cv.ellipse(cx, ly - 9 * k, 18 * k, 18 * k, !st.grad ? st.fill : st.grad[0], 'FFFFFF', 3, 'timeline dot', {grad: st.grad});
      var yy = ly + 22 * k;
      yy += cv.text(cx, yy, colw - 16 * k, e[1], e[0], INK, 'bold', undefined, 1.2, 'timeline title', get(it, 'title', ''), kw(ip(b, i, 'title')));
      if (e[3].length) cv.text(cx, yy + 6 * k, colw - 16 * k, e[3], e[2], MUTED, 'body', undefined, 1.32, 'timeline text', it.text, kw(ip(b, i, 'text')));
    });
    return wh + 12 * k + 22 * k + hmax;
  }
  function drawCompare(cv, b, x, y, w, k, theme, ci) {
    var gap = 70 * k, cw = (w - gap) / 2, pad = 20 * k, hh = 46 * k;
    var left = theme === 'ulta' ? Object.assign({}, style('ulta', TITLE), {fill: 'F2F2F2'}) : FILLED.indexOf(theme) >= 0 ? style('charcoal', INK) : style('paper', '404040');   // Ulta: a pale grey head beside the pale orange
    var sides = [['left', b.left, left], ['right', b.right, style(theme, PALETTE[ci % 5])]];
    var lays = [], fs = Math.max(15 * k, C.state.minFs), tfs = Math.max(pyRound(17 * k), C.state.minFs);
    sides.forEach(function (sd) { lays.push(sd[1].items.map(function (t) { return wrap(t, cw - 2 * pad - 22 * k, fs, 'body'); })); });
    var any = lays.some(function (r) { return r.length; });
    var ih = any ? Math.max.apply(null, lays.map(function (rows) { return rows.reduce(function (a, r) { return a + (r.length * fs * 1.32 + 8 * k); }, 0); })) : 0;
    var ch = hh + pad + ih + pad - 8 * k;
    sides.forEach(function (sd, j) {
      var side = sd[1], st = sd[2], rows = lays[j], cx = x + j * (cw + gap), sp = bp(b, sd[0]);
      cv.rect(cx, y, cw, ch, theme !== 'frost' ? 'FFFFFF' : tint(PALETTE[ci % 5], 0.9), LINE, 16, 1.2, undefined, 'compare card');
      cv.rect(cx, y, cw, hh, st.fill, st.stroke, 16, st.stroke ? 1.5 : 1, st.grad, 'compare head');
      cv.text(cx + pad, y + hh / 2 - tfs * 0.6, cw - 2 * pad, [side.title], tfs, st.head, 'bold', undefined, 1.2, 'compare title', side.title, kw(sp && sp + '.title'));
      var yy = y + hh + pad, mark = j ? PALETTE[ci % 5] : '404040';
      side.items.forEach(function (t, q) {
        cv.ellipse(cx + pad, yy + 5 * k, 10 * k, 10 * k, mark, undefined, undefined, 'compare mark');
        yy += cv.text(cx + pad + 22 * k, yy, cw - 2 * pad - 22 * k, rows[q], fs, INK, 'body', undefined, 1.32, 'compare item', t, kw(sp && sp + '.items.' + (Array.isArray(side._j) ? side._j[q] : q))) + 8 * k;
      });
    });
    var ax = x + cw + gap / 2, ay = y + ch / 2, c = PALETTE[ci % 5];
    var sc = ['sunset', 'velvet', 'charcoal'].indexOf(theme) >= 0 ? sides[1][2] : style('ulta', c, 'mark');   // the arrow on its disc: a filled card's own run, else an orange mark
    cv.ellipse(ax - 22 * k, ay - 22 * k, 44 * k, 44 * k, sc.fill, 'FFFFFF', 3, 'compare arrow', {grad: sc.grad});
    cv.text(ax - 22 * k, ay - 14 * k, 44 * k, ['\u2192'], pyRound(22 * k), 'FFFFFF', 'bold', 'center', 1.2, 'compare arrow text');   // a mark (DOTS), not words
    return ch;
  }
  function drawBars(cv, b, x, y, w, k, theme, ci) {
    var its = b.items, vals = its.map(function (it) { return num(it.value) || 0; }), mx = Math.max.apply(null, vals.concat([1e-9]));
    var lw = w * 0.34, vw = 76 * k, bw = w - lw - vw - 12 * k, rh = 38 * k, c = PALETTE[ci % 5], st = style(theme, c, 'mark'), unit = b.unit || '';
    its.forEach(function (it, i) {
      var v = vals[i], yy = y + i * rh, l = fit(it.label, lw - 12 * k, rh - 6 * k, pyRound(14.5 * k), pyRound(11 * k), 'body', 1.15, 2);
      cv.text(x, yy + (rh - l[1].length * l[0] * 1.15) / 2 - 2 * k, lw - 12 * k, l[1], l[0], INK, 'body', undefined, 1.15, 'bar label', it.label, kw(ip(b, i, 'label')));
      cv.rect(x + lw, yy + rh / 2 - 10 * k, bw, 20 * k, tint(c, 0.88), null, 10 * k, undefined, undefined, 'bar track');
      var fw = v > 0 ? Math.max(20 * k, bw * (v / mx)) : 0;
      if (fw) cv.rect(x + lw, yy + rh / 2 - 10 * k, fw, 20 * k, theme === 'charcoal' ? '404040' : c, null, 10 * k, undefined, st.grad, 'bar');
      var val = C.pyStrip(C.pyStr(it.value)); val = val.indexOf(unit) >= 0 ? val : val + unit;
      cv.text(x + lw + bw + 12 * k, yy + rh / 2 - 10 * k, vw, [val], pyRound(15 * k), theme !== 'charcoal' ? shade(c, 0.1) : INK, 'bold', undefined, 1.2, 'bar value', val, kw(ip(b, i, 'value')));
    });
    return its.length * rh;
  }
  function drawDonut(cv, b, x, y, w, k, theme, ci) {
    var its = b.items, m = its.length, colw = w / m, r = Math.min(colw * 0.3, 72 * k), sw = 16 * k, hmax = 0, labs = [];
    its.forEach(function (it) { var l = fit(it.label, colw - 20 * k, 80 * k, pyRound(14.5 * k), pyRound(11 * k), 'body', 1.3, 4); labs.push(l); hmax = Math.max(hmax, l[1].length * l[0] * 1.3); });
    its.forEach(function (it, i) {
      var l = labs[i], c = PALETTE[(ci + i) % 5], st = style(theme, c, 'mark'), cx = x + i * colw + colw / 2, cy = y + r + sw / 2, v = num(it.value) || 0;
      cv.arc(cx, cy, r, sw, v / 100.0, st.fill !== 'FFFFFF' && !st.grad ? st.fill : c, tint(c, 0.86), {name: 'ring'});
      var vs = C.pyStrip(C.pyStr(it.value)); vs = vs.indexOf('%') >= 0 ? vs : vs + '%';
      var vf = fit(vs, (r - sw / 2) * 1.35, r * 0.8, pyRound(32 * k), pyRound(14 * k), 'display', 1.05, 1);
      cv.text(cx - r * 0.75, cy - vf[0] * 0.55, r * 1.5, vf[1], vf[0], INK, 'display', 'center', 1.05, 'ring value', vs, kw(ip(b, i, 'value')));
      cv.text(x + i * colw + 10 * k, y + 2 * r + sw + 12 * k, colw - 20 * k, l[1], l[0], MUTED, 'body', 'center', 1.3, 'ring label', it.label, kw(ip(b, i, 'label')));
    });
    return 2 * r + sw + 12 * k + hmax;
  }
  function drawList(cv, b, x, y, w, k, theme, ci) {
    var its = b.items, n = its.length, used = new Set();
    var cols = b._cols || ((w >= 900 && n >= 3 && n !== 4) ? 3 : (n >= 2 && w >= 440 ? 2 : 1));
    var g = 24 * k, cw = (w - g * (cols - 1)) / cols, isz = 50 * k, rows = Math.ceil(n / cols), y0 = y;
    for (var r_ = 0; r_ < rows; r_++) {
      var row = its.slice(r_ * cols, (r_ + 1) * cols), hs = [];
      row.forEach(function (it, j) {
        var i = r_ * cols + j, c = PALETTE[(ci + i) % 5], st = style(theme, c, 'mark'), cx = x + j * (cw + g), tw = cw - isz - 14 * k, o = ic(b), icol;   // the brand's colours in turn
        var filled = o[2] === 'filled' || (o[2] === 'auto' && FILLED.indexOf(theme) >= 0);
        if (filled) {
          var bf = st.grad ? st.grad[0] : ((st.fill === 'FFFFFF' || st.fill === null || theme === 'frost') ? c : st.fill);
          cv.ellipse(cx, y, isz, isz, bf, undefined, undefined, 'list badge', {grad: st.grad}); icol = 'FFFFFF';
        } else {
          cv.ellipse(cx, y, isz, isz, tint(c, 0.86), theme === 'paper' ? st.stroke : null, 1.5, 'list badge'); icol = st.icon !== 'FFFFFF' ? st.icon : shade(c, 0.15);
        }
        var fr = Math.min(0.78, 0.6 * o[0]), off = isz * (1 - fr) / 2;
        cv.icon(listIcon(it, used), cx + off, y + off, isz * fr, icol, kw(ip(b, i, 'icon'), {bold: o[1]}));
        var yy = y;
        if (it.title) {
          var t = fit(it.title, tw, 48 * k, pyRound(16.5 * k), pyRound(12.5 * k), 'bold', 1.2, 2);
          yy += cv.text(cx + isz + 14 * k, yy + 2 * k, tw, t[1], t[0], INK, 'bold', undefined, 1.2, 'list title', it.title, kw(ip(b, i, 'title'))) + 6 * k;
        }
        if (it.text) {
          var x_ = fit(it.text, tw, 96 * k, pyRound(14 * k), pyRound(11 * k), 'body', 1.32, 5);
          yy += cv.text(cx + isz + 14 * k, yy + 2 * k, tw, x_[1], x_[0], MUTED, 'body', undefined, 1.32, 'list text', it.text, kw(ip(b, i, 'text')));
        }
        hs.push(Math.max(isz, yy - y));
      });
      y += Math.max.apply(null, hs) + 22 * k;
    }
    return y - y0 - 22 * k;
  }
  function drawQuote(cv, b, x, y, w, k, theme, ci) {
    var c = PALETTE[ci % 5], pad = 22 * k;
    var f = fit(b.text, w - 2 * pad - 20 * k, 220 * k, pyRound(25 * k), pyRound(15 * k), 'display', 1.25, 6);
    cv.rect(x, y, 6 * k, 10, c, null, 3, undefined, undefined, 'quote bar');
    cv.text(x + pad, y - 14 * k, 60 * k, ['\u201c'], pyRound(64 * k), c, 'display', undefined, 1.0, 'quote mark');
    var h = 44 * k + cv.text(x + pad, y + 44 * k, w - 2 * pad, f[1], f[0], INK, 'display', undefined, 1.25, 'quote text', b.text, kw(bp(b, 'text')));
    if (b.by) h += 8 * k + cv.text(x + pad, y + h + 8 * k, w - 2 * pad, [' - ' + b.by], pyRound(14 * k), MUTED, 'body', undefined, 1.3, 'quote by', ' - ' + b.by, kw(bp(b, 'by')));
    cv.els.forEach(function (e) { if (e.name === 'quote bar' && e.h === 10) e.h = pyRound(h, 1); });
    return h;
  }
  function drawTakeaway(cv, b, x, y, w, k, theme, ci) {
    var band = theme === 'ulta' || theme === 'charcoal', c = band ? TITLE : PALETTE[ci % 5], pad = 24 * k;   // v139: the Ulta orange banner, white words (info.py draw_takeaway)
    var st = band ? {fill: TITLE, grad: theme === 'ulta' && S.look === 'gradient' ? GRAD[TITLE].slice() : null, stroke: null, glow: null, text: 'FFFFFF', sub: 'FFFFFF', head: 'FFFFFF', icon: 'FFFFFF', r: 14} : style(theme, c);
    if (band && theme === 'ulta' && S.look === 'light') st = Object.assign({}, st, {fill: LIGHT_LEAD[0], grad: LIGHT_LEAD.slice(), text: INK, sub: INK, head: INK, icon: INK});   // the light lead, dark words
    var isz = b.icon ? 42 * k * ic(b)[0] : 0, tw = w - 2 * pad - (isz ? isz + 18 * k : 0);
    var f = band && st.head !== INK ? fit(b.text, tw, 190, Math.max(24, pyRound(24 * k)), 24, 'bold', 1.3, 6) : fit(b.text, tw, 140 * k, pyRound(21 * k), pyRound(14 * k), 'bold', 1.3, 4);   // white words: 14 pt bold or more
    var h = Math.max(f[1].length * f[0] * 1.3, isz) + 2 * pad;
    card(cv, x, y, w, h, st, 'takeaway');
    if (isz && band) cv.icon(b.icon, x + pad, y + (h - isz) / 2, isz, st.icon, kw(bp(b, 'icon'), {bold: ic(b)[1]}));
    else if (isz) cardIcon(cv, b.icon, x + pad, y + (h - isz) / 2, isz, st.icon, theme, kw(bp(b, 'icon'), {bold: ic(b)[1]}));
    cv.text(x + pad + (isz ? isz + 18 * k : 0), y + (h - f[1].length * f[0] * 1.3) / 2, tw, f[1], f[0], st.head, 'bold', undefined, 1.3, 'takeaway text', b.text, kw(bp(b, 'text'), dk(st.head)));
    return h;
  }
  function statusTitle(cv, b, x, y, w, k, accent, icon, theme) {   // the badge in the theme's fill with a white icon, or tinted with an orange one
    if (!b.title) return 0;
    var d = 38 * k, ink;
    if (FILLED.indexOf(theme) >= 0) { var st = style(theme, TITLE, 'mark'); cv.ellipse(x, y, d, d, st.fill, null, undefined, 'section badge', {grad: st.grad}); ink = 'FFFFFF'; }
    else { cv.ellipse(x, y, d, d, tint(TITLE, 0.86), null, undefined, 'section badge'); ink = 'E0531B'; }
    cv.icon(icon || statusIcon(b.title), x + d * 0.22, y + d * 0.22, d * 0.56, ink, {bold: true});
    var f = fit(b.title, w - d - 18 * k, 64 * k, pyRound(29 * k), pyRound(21 * k), 'display', 1.05, 2), th = f[1].length * f[0] * 1.05;
    cv.text(x + d + 14 * k, y + Math.max(0, (d - th) / 2) - 2 * k, w - d - 18 * k, f[1], f[0], TITLE, 'display', undefined, 1.05, 'block title', b.title, kw(bp(b, 'title')));
    return Math.max(d, th) + 12 * k;
  }
  function ragPill(cv, x, y, w, h, rag, k, word) {
    word = word === undefined ? true : word;
    var R = has(RAG, rag) ? RAG[rag] : RAG[''], c = R[0], label = R[1], ink = shade(c, 0.3), fs = pyRound(Math.max(fl(), 15 * k));
    var pw = Math.min(w, word ? (textW(label, fs, 'bold') + 44 * k) : h);
    cv.rect(x, y, pw, h, tint(c, 0.84), null, h / 2, undefined, undefined, 'rag pill');
    cv.ellipse(x + 11 * k, y + h / 2 - 6 * k, 12 * k, 12 * k, c, null, undefined, 'rag dot');
    if (word) cv.text(x + 30 * k, y + (h - fs * 1.15) / 2, pw - 34 * k, [label], fs, ink, 'bold', undefined, 1.15, 'rag word', label);
    return pw;
  }
  function headStyle(theme, acc) {   // [fill, gradient, ink] of a table head (info.py _head_style)
    if (theme === 'ulta') return [LIGHT_CARD, null, INK];   // v136: the pale orange with dark words
    if (FILLED.indexOf(theme) >= 0) { var st = style(theme, theme === 'sunset' ? TITLE : acc); return [st.fill, st.grad, theme === 'sunset' ? INK : 'FFFFFF']; }
    var c = ['glow', 'paper'].indexOf(theme) >= 0 ? TITLE : acc; return [tint(c, 0.88), null, c === TITLE ? 'E0531B' : shade(c, 0.3)];
  }
  function table(cv, x, y, w, k, theme, ci, heads, fracs, rows, o) {
    // o: {ragCol, barCol, name, headIcons, rowIcons, headP: [path per column], cellP: (row, col) \u2192 path}
    var ragCol = o.ragCol === undefined ? null : o.ragCol, barCol = o.barCol === undefined ? null : o.barCol, name = o.name || 'status';
    var headIcons = o.headIcons || heads.map(function () { return null; }), rowIcons = o.rowIcons || null;
    var acc = PALETTE[ci % 5], pad = 10 * k, hfs = pyRound(Math.max(fl(), 13.5 * k)), fs = pyRound(Math.max(fl() + 0.5, 15.5 * k)), lh = 1.25, bd = 34 * k;
    var hs = headStyle(theme, acc), hfill = hs[0], hgrad = hs[1], hink = hs[2];
    var xs = [x]; fracs.forEach(function (f) { xs.push(xs[xs.length - 1] + f * w); });
    var hls = heads.map(function (h_, j) {
      var ix = xs[j] + pad + (headIcons[j] ? 24 * k : 0);
      return h_ ? wrap(h_.toUpperCase(), Math.max(10, xs[j + 1] - ix - pad - 4), hfs * 1.08, 'bold').slice(0, 2) : [];
    });
    var hh = Math.max.apply(null, hls.map(function (l) { return l.length; }).concat([1])) * hfs * 1.2 + 2 * pad + 2 * k;
    cv.rect(x, y, w, hh, hfill, null, 12 * k, undefined, hgrad, name + ' head');
    heads.forEach(function (h_, j) {
      if (!h_) return;
      var ix = xs[j] + pad, hi = headIcons[j];
      if (hi) { cv.icon(hi, ix, y + (hh - 18 * k) / 2, 18 * k, hink, {bold: true}); ix += 24 * k; }
      var cw = xs[j + 1] - ix - pad;
      cv.text(ix, y + (hh - hls[j].length * hfs * 1.2) / 2, cw, hls[j], hfs, hink, 'bold', undefined, 1.2, name + ' heading', h_, kw(o.headP && o.headP[j], {spacing: 1}));
    });
    var yy = y + hh + 6 * k;
    rows.forEach(function (r, i) {
      var cells = r.map(function (v, j) {
        if (j === ragCol || j === barCol) return null;
        var cw = xs[j + 1] - xs[j] - 2 * pad - (j === 0 && rowIcons ? bd + 12 * k : 0), f_ = fs + (j === 0 ? 1.5 : 0);
        return [wrap(v || '\u2014', cw, f_, j === 0 ? 'bold' : 'body'), f_];
      });
      var rh = Math.max.apply(null, cells.filter(Boolean).map(function (c) { return c[0].length * c[1] * lh; }).concat([bd])) + 2 * pad;
      var sev = barCol !== null ? (has(RAG, ragOf(r[barCol])) ? RAG[ragOf(r[barCol])] : RAG[''])[0] : null;
      cv.rect(x, yy, w, rh, 'FFFFFF', LINE, 12 * k, 1.2, undefined, name + ' row');
      if (sev) cv.rect(x, yy, 7 * k, rh, sev, null, 3 * k, undefined, undefined, name + ' severity');
      cells.forEach(function (c, j) {
        if (j === ragCol) { ragPill(cv, xs[j] + pad, yy + (rh - 32 * k) / 2, xs[j + 1] - xs[j] - 2 * pad, 32 * k, ragOf(r[j]), k); return; }
        if (c === null) return;
        var ls = c[0], f_ = c[1], v = r[j] || '\u2014', tx = xs[j] + pad + (sev && j === 0 ? 6 * k : 0);
        if (j === 0 && rowIcons) {
          var bc = sev || PALETTE[(ci + i) % 5];
          cv.ellipse(tx, yy + (rh - bd) / 2, bd, bd, tint(bc, 0.85), null, undefined, name + ' badge');
          cv.icon(rowIcons[i], tx + bd * 0.2, yy + (rh - bd) / 2 + bd * 0.2, bd * 0.6, shade(bc, 0.15), {bold: true}); tx += bd + 12 * k;
        }
        var th = ls.length * f_ * lh;
        cv.text(tx, yy + (rh - th) / 2, xs[j + 1] - tx - pad, ls, f_, v !== '\u2014' ? INK : MUTED, j === 0 ? 'bold' : 'body', undefined, lh, name + ' cell', v, kw(o.cellP && o.cellP(i, j)));
      });
      yy += rh + 5 * k;
    });
    return yy - y - 5 * k;
  }
  function iconDisc(cv, x, y, d, c, ink, theme, rag, name) {   // a round icon disc in c; returns the icon's colour (info.py icon_disc)
    if (FILLED.indexOf(theme) >= 0 && !rag) { var st = style(theme, c, 'mark'); cv.ellipse(x, y, d, d, st.fill, null, undefined, name, {grad: st.grad}); return 'FFFFFF'; }
    cv.ellipse(x, y, d, d, tint(c, 0.85), null, undefined, name); return ink;
  }
  function drawStatus(cv, b, x, y, w, k, theme, ci) {
    var its = b.items, n = its.length, g = 14 * k, cw = (w - g * (n - 1)) / n, pad = 16 * k, icz = 36 * k, tw = cw - 2 * pad - icz - 20 * k, parts = [];
    its.forEach(function (it) {
      var r = it.rag ? ragOf(it.rag) : '', val = r ? RAG[r][1] : get(it, 'value', '');
      var v = fit(val, tw, 96 * k, pyRound(28 * k), pyRound(15 * k), 'display', 1.05, 3); parts.push([r, val, v[0], v[1]]);
    });
    var h = Math.max.apply(null, parts.map(function (p) { return pad * 2 + Math.max(icz, 18 * k + 6 * k + p[3].length * p[2] * 1.05); }));
    its.forEach(function (it, i) {
      var p = parts[i], r = p[0], cx = x + i * (cw + g), lab = C.pyStr(get(it, 'label', ''));
      var c = r ? RAG[r][0] : PALETTE[(ci + i) % 5], ink = shade(c, 0.25);
      cv.rect(cx, y, cw, h, 'FFFFFF', LINE, 16 * k, 1.2, undefined, 'status tile'); cv.rect(cx, y + 14 * k, 5 * k, h - 28 * k, c, null, 2.5 * k, undefined, undefined, 'status accent');
      var dink = iconDisc(cv, cx + pad, y + (h - icz) / 2 - 4 * k, icz + 8 * k, c, ink, theme, !!r, 'status icon disc');
      cv.icon(factIcon(lab), cx + pad + 4 * k + icz * 0.12, y + (h - icz) / 2 + icz * 0.12, icz * 0.76, dink, {bold: true});
      var tx = cx + pad + icz + 20 * k, bh = 18 * k + 6 * k + p[3].length * p[2] * 1.05, ty = y + (h - bh) / 2, lf = pyRound(Math.max(fl(), 13 * k));
      cv.text(tx, ty, tw, wrap(lab.toUpperCase(), tw, lf, 'bold').slice(0, 1), lf, MUTED, 'bold', undefined, 1.2, 'status label', lab, kw(ip(b, i, 'label'), {spacing: 1}));
      cv.text(tx, ty + 24 * k, tw, p[3], p[2], ink, 'display', undefined, 1.05, 'status value', p[1], kw(r ? null : ip(b, i, 'value')));
    });
    return h;
  }
  function drawRag(cv, b, x, y, w, k, theme, ci) {
    var cs = (b.cols && b.cols.length ? b.cols : ['This week', 'Next week']).slice(0, 2), used = new Set(), F = ['name', 'owner', 'rag', 'now', 'next'];
    var rows = b.items.map(function (it) { return F.map(function (f) { return get(it, f, ''); }); });
    var icons = b.items.map(function (it) { return statusIcon(get(it, 'name', ''), used); });
    return table(cv, x, y, w, k, theme, ci, ['Workstream', 'Owner', 'Status', cs[0], cs[1]], [0.22, 0.14, 0.14, 0.25, 0.25], rows,
      {ragCol: 2, name: 'workstream', headIcons: ['layers', 'person', 'performance', 'calendar', 'trend-up'], rowIcons: icons,
        headP: [null, null, null, bp(b, 'cols.0'), bp(b, 'cols.1')], cellP: function (i, j) { return ip(b, i, F[j]); }});
  }
  function drawRisks(cv, b, x, y, w, k, theme, ci) {
    var its = b.items;
    var keep = ['title', 'text', 'owner', 'due'].filter(function (f) { return f === 'title' || its.some(function (it) { return ['', '\u2014', '-'].indexOf(C.pyStrip(C.pyStr(C.or(it[f])))) < 0; }); });
    var H = {title: ['Risk or ask', 0.42, 'warning'], text: ['Support needed from', 0.25, 'support'], owner: ['Owner', 0.17, 'person'], due: ['Need by', 0.16, 'calendar']};
    var tot = keep.reduce(function (a, f) { return a + H[f][1]; }, 0), rows = its.map(function (it) { return keep.map(function (f) { return get(it, f, ''); }).concat([get(it, 'rag', '')]); });
    return table(cv, x, y, w, k, theme, ci + 1, keep.map(function (f) { return H[f][0]; }).concat(['']), keep.map(function (f) { return H[f][1] / tot; }).concat([0.0]), rows,
      {barCol: keep.length, name: 'risk', headIcons: keep.map(function (f) { return H[f][2]; }).concat([null]), rowIcons: rows.map(function () { return 'warning'; }),
        cellP: function (i, j) { return ip(b, i, keep[j]); }});
  }
  function drawTable(cv, b, x, y, w, k, theme, ci) {
    var heads = (b.cols || []).slice(), n = heads.length;
    var rows = b.items.map(function (r) { return r.concat(new Array(Math.max(0, n - r.length)).fill('')); });
    if (!n) return 0;
    var rag = heads.findIndex(function (h) { return RAGCOL.test(C.pyStrip(h)); }), sev = heads.findIndex(function (h) { return SEVCOL.test(C.pyStrip(h)); });
    rag = rag < 0 ? null : rag; sev = sev < 0 ? null : sev;
    var lens = heads.map(function (h, j) { return Math.max.apply(null, [C.cps(h).length].concat(rows.map(function (r) { return C.cps(C.pyStr(C.or(r[j]))).length; }))); });
    lens = lens.map(function (L, j) { return (j === rag || j === sev) ? 14 : Math.min(60, Math.max(8, L)); });
    if (sev !== null) lens[sev] = 0.001;
    var tot = lens.reduce(function (a, L) { return a + L; }, 0), fr = lens.map(function (L) { return L / tot; }), icons = null;
    if (b.icons) { var used = new Set(); icons = rows.map(function (r) { return statusIcon(r[0], used); }); }
    return table(cv, x, y, w, k, theme, ci, heads.map(function (h, j) { return j !== sev ? h : ''; }), fr, rows,
      {ragCol: rag, barCol: sev, name: 'table', headIcons: heads.map(function (h, j) { return j === 0 && b.icons ? statusIcon(h) : null; }), rowIcons: icons,
        headP: heads.map(function (h, j) { return bp(b, 'cols.' + j); }), cellP: function (i, j) { return ip(b, i, j); }});
  }
  function drawRagcards(cv, b, x, y, w, k, theme, ci) {
    var its = b.items, n = its.length, per = (w >= 880 && n !== 4) ? 3 : (n > 1 ? 2 : 1), g = 14 * k, cw = (w - g * (per - 1)) / per, pad = 16 * k, icz = 40 * k;
    var used = new Set(), parts = [];
    its.forEach(function (it) {
      var nf = fit(get(it, 'name', ''), cw - 2 * pad - icz - 12 * k, 52 * k, pyRound(20 * k), pyRound(15 * k), 'bold', 1.2, 2);
      var tf = fit(get(it, 'text', '') || '\u2014', cw - 2 * pad, 130 * k, pyRound(Math.max(fl() + 0.5, 15.5 * k)), fl(), 'body', 1.3, 5);
      parts.push([nf[0], nf[1], tf[0], tf[1], statusIcon(get(it, 'name', ''), used)]);
    });
    var rows = []; for (var i = 0; i < n; i += per) rows.push(parts.slice(i, i + per));
    var yy = y;
    rows.forEach(function (row, ri) {
      var hh = Math.max.apply(null, row.map(function (p) { return pad * 2 + Math.max(icz, p[1].length * p[0] * 1.2 + 22 * k) + 10 * k + 30 * k + 10 * k + p[3].length * p[2] * 1.3; }));
      row.forEach(function (p, j) {
        var ix = ri * per + j, it = its[ix], cx = x + j * (cw + g), r = ragOf(it.rag), c = r ? RAG[r][0] : PALETTE[(ci + ri * per + j) % 5];
        cv.rect(cx, yy, cw, hh, 'FFFFFF', LINE, 14 * k, 1.2, undefined, 'ragcard'); cv.rect(cx, yy + 12 * k, 5 * k, hh - 24 * k, c, null, 2.5 * k, undefined, undefined, 'ragcard accent');
        var icol = iconDisc(cv, cx + pad, yy + pad, icz, c, shade(c, 0.15), theme, !!r, 'ragcard icon disc'); cv.icon(p[4], cx + pad + icz * 0.2, yy + pad + icz * 0.2, icz * 0.6, icol, {bold: true});
        var tx = cx + pad + icz + 12 * k, ty = yy + pad;
        ty += cv.text(tx, ty, cw - 2 * pad - icz - 12 * k, p[1], p[0], INK, 'bold', undefined, 1.2, 'ragcard name', get(it, 'name', ''), kw(ip(b, ix, 'name')));
        if (it.owner) {
          var of = pyRound(Math.max(fl(), 14 * k));
          cv.text(tx, ty + 2 * k, cw - 2 * pad - icz - 12 * k, wrap(it.owner, cw - 2 * pad - icz - 12 * k, of, 'body').slice(0, 1), of, MUTED, 'body', undefined, 1.2, 'ragcard owner', it.owner, kw(ip(b, ix, 'owner')));
        }
        var py = yy + pad + Math.max(icz, p[1].length * p[0] * 1.2 + 22 * k) + 10 * k;
        ragPill(cv, cx + pad, py, cw - 2 * pad, 30 * k, r, k);
        cv.text(cx + pad, py + 40 * k, cw - 2 * pad, p[3], p[2], it.text ? INK : MUTED, 'body', undefined, 1.3, 'ragcard text', get(it, 'text', '') || '\u2014', kw(ip(b, ix, 'text')));
      });
      yy += hh + g;
    });
    return yy - y - g;
  }
  // ------------------------------------------------------------------------------------------------ v7 pictures
  function pic(b, ref) { var m = b._im || {}; return typeof ref === 'string' && has(m, ref) ? m[ref] : null; }
  function frameOf(b, rec) {
    var f = b.frame || 'auto';
    if (f !== 'auto') return f;
    if (!rec) return 'plain';
    if (rec.kind === 'screen') return rec.h > rec.w * 1.35 ? 'phone' : 'browser';
    return 'plain';
  }
  function picture(cv, b, ref, x, y, w, k, maxh, alt, fit_, p) {   // a picture with its frame, at most w wide and maxh tall, centred in w: [width, height]
    var rec = pic(b, ref), frame = frameOf(b, rec); alt = alt || b.alt || b.caption || b.title || 'Picture';
    if (!rec) {
      var h = Math.min(maxh, w * 0.5); cv.rect(x, y, w, h, 'F3EDEB', LINE, pyRound(12 * k, 1), 1.2, undefined, 'picture missing', kw(p));
      var s = Math.min(56 * k, h * 0.4); cv.icon('image', x + (w - s) / 2, y + h / 2 - s * 0.9, s, MUTED);
      var msg = ref === 'new' ? 'Add a picture: Edit, then Add a picture' : 'Picture not found' + (typeof ref === 'string' && ref && !REF.test(ref) ? ': ' + ref : ' - upload it again');
      var f = fit(msg, w - 40 * k, 40 * k, pyRound(14 * k), pyRound(11 * k), 'body', 1.3, 2, false);
      cv.text(x + 20 * k, y + h / 2 + s * 0.3, w - 40 * k, f[1], f[0], MUTED, 'body', 'center', 1.3, 'picture missing text', msg);
      return [w, h];
    }
    fit_ = fit_ || b.fit || ((rec.kind === 'photo' && frame === 'plain') ? 'cover' : 'contain');
    var bar = frame === 'browser' ? 24 * k : 0, bez = frame === 'phone' ? 9 * k : 0, pw = w - 2 * bez, ph;
    if (fit_ === 'cover') ph = Math.min(maxh - bar - 2 * bez, pw * 0.62);
    else {
      ph = pw * rec.h / rec.w;
      if (ph + bar + 2 * bez > maxh) { ph = maxh - bar - 2 * bez; pw = ph * rec.w / rec.h; }
    }
    var ow = pw + 2 * bez, oh = ph + bar + 2 * bez, ox = x + (w - ow) / 2, ref_ = {ref: ref};
    if (frame === 'browser') {
      cv.rect(ox, y, ow, oh, 'F3EDEB', LINE, pyRound(8 * k, 1), 1.2, undefined, 'browser window');
      ['F26923', 'FF893F', 'E0531B'].forEach(function (c, i) { cv.ellipse(ox + 12 * k + i * 13 * k, y + bar / 2 - 3.5 * k, 7 * k, 7 * k, c, undefined, undefined, 'browser dot'); });
      cv.image(ox, y + bar, pw, ph, ref, fit_, 0, 'picture', alt, kw(p));
    } else if (frame === 'phone') {
      cv.rect(ox, y, ow, oh, INK, null, pyRound(26 * k, 1), undefined, undefined, 'phone');
      cv.image(ox + bez, y + bez, pw, ph, ref, fit_, pyRound(18 * k, 1), 'picture', alt, kw(p));
    } else {
      cv.image(ox, y, pw, ph, ref, fit_, pyRound(12 * k, 1), 'picture', alt, kw(p));
      cv.rect(ox, y, pw, ph, null, LINE, pyRound(12 * k, 1), 1.2, undefined, 'picture edge');
    }
    return [ow, oh];
  }
  function caption(cv, text, x, y, w, k, align, draw, name, p) {
    if (!text) return 0;
    var f = fit(text, w, 66 * k, pyRound(14 * k), pyRound(11 * k), 'body', 1.3, 3, draw !== false);
    if (draw !== false) cv.text(x, y, w, f[1], f[0], MUTED, 'body', align || 'left', 1.3, name || 'picture caption', text, kw(p));
    return f[1].length * f[0] * 1.3;
  }
  function drawImage(cv, b, x, y, w, k, theme, ci) {
    var r = picture(cv, b, b.src, x, y, w, k, PIC_H * k, undefined, undefined, bp(b, 'src')), cx = x + (w - r[0]) / 2;
    return r[1] + (b.caption ? 10 * k + caption(cv, b.caption, cx, y + r[1] + 10 * k, Math.max(r[0], 240 * k), k, 'left', true, undefined, bp(b, 'caption')) : 0);
  }
  function drawFeature(cv, b, x, y, w, k, theme, ci) {
    var rec = pic(b, b.src), g = 32 * k, pw = (w - g) * (rec && rec.h > rec.w * 1.2 ? 0.38 : 0.5), lw = w - g - pw, px, lx;
    if (b.side !== 'left') { px = x + lw + g; lx = x; } else { px = x; lx = x + pw + g; }
    var hl = drawList(cv, Object.assign({}, b, {_cols: 1}), lx, y, lw, k, theme, ci);
    var r = picture(cv, b, b.src, px, y, pw, k, PIC_H * k, undefined, undefined, bp(b, 'src')), cx = px + (pw - r[0]) / 2;
    var hc = b.caption ? 10 * k + caption(cv, b.caption, cx, y + r[1] + 10 * k, r[0], k, 'left', true, undefined, bp(b, 'caption')) : 0;
    return Math.max(hl, r[1] + hc);
  }
  function drawGallery(cv, b, x, y, w, k, theme, ci) {
    var its = b.items, n = its.length, g = 20 * k, cw = (w - g * (n - 1)) / n, bh = Math.min(cw * (n > 1 ? 0.62 : 0.56), 380 * k), hs = [], b2 = Object.assign({}, b, {frame: 'auto'});
    its.forEach(function (it) { hs.push(picture(new C.Canvas(), b2, it.src, 0, 0, cw, k, bh, it.alt || it.caption, b.fit || null)[1]); });
    var top = Math.max.apply(null, hs), hc = Math.max.apply(null, its.map(function (it) { return caption(cv, it.caption, 0, 0, cw, k, 'left', false); }).concat([0]));
    its.forEach(function (it, i) {
      var cx = x + i * (cw + g);
      picture(cv, b2, it.src, cx, y + top - hs[i], cw, k, bh, it.alt || it.caption, b.fit || null, ip(b, i, 'src'));
      if (it.caption) caption(cv, it.caption, cx, y + top + 10 * k, cw, k, 'center', true, 'gallery caption', ip(b, i, 'caption'));
    });
    return top + (hc ? 10 * k + hc : 0);
  }
  function drawBand(cv, b, x, y, w, k, theme, ci) {
    var st = style(theme, TITLE), pad = 22 * k, its = b.items, n = its.length, lab = b.label || '', o = ic(b);   // in Ulta orange (info.py draw_band)
    var lfs = Math.max(pyRound(13 * k), C.state.minFs), lh_ = lab ? lfs * 1.2 + 12 * k : 0, g = 18 * k, cw = (w - 2 * pad - g * (n - 1)) / n, isz = 30 * k * o[0];
    var fits = its.map(function (it) { return fit(it.title, cw - isz - 10 * k, 64 * k, pyRound(16 * k), pyRound(12 * k), 'bold', 1.25, 3); });
    var ih = Math.max(Math.max.apply(null, fits.map(function (f) { return f[1].length * f[0] * 1.25; })), isz), h = pad + lh_ + ih + pad;
    card(cv, x, y, w, h, st, 'band');
    var ink = st.head;
    if (lab) cv.text(x + pad, y + pad, w - 2 * pad, [lab.toUpperCase()], lfs, st.sub, 'bold', undefined, 1.2, 'band label', lab.toUpperCase(), kw(bp(b, 'label'), {spacing: 1.5}));
    var yy = y + pad + lh_, used = new Set();
    its.forEach(function (it, i) {
      var cx = x + pad + i * (cw + g), f = fits[i];
      cv.icon(listIcon(it, used), cx, yy + (ih - isz) / 2, isz, st.icon, kw(ip(b, i, 'icon'), {bold: o[1]}));
      cv.text(cx + isz + 10 * k, yy + (ih - f[1].length * f[0] * 1.25) / 2, cw - isz - 10 * k, f[1], f[0], ink, 'bold', undefined, 1.25, 'band item', it.title, kw(ip(b, i, 'title')));
    });
    return h;
  }
  function lp(b, ln, i, f) {   // a flow lane's field: "blocks.4.lanes.1.items.2.title"
    if (typeof b._i !== 'number') return null;
    var base = 'blocks.' + b._i + '.lanes.' + (typeof ln._l === 'number' ? ln._l : 0);
    return i === null ? base + '.' + f : base + '.items.' + (Array.isArray(ln._j) ? ln._j[i] : i) + '.' + f;
  }
  function drawFlow(cv, b, x, y, w, k, theme, ci) {
    var lanes = b.lanes, y0 = y, g = 14 * k, pad = 16 * k, o = ic(b), d = 46 * k * o[0];
    var tw = lanes.some(function (ln) { return !!ln.title; }) ? Math.min(230 * k, 0.27 * w) : 0;   // the lanes' names, in a column of their own
    lanes.forEach(function (ln, li) {
      var after = ln.tone === 'after' || (!ln.tone && li === lanes.length - 1), c = after ? PALETTE[(ci + 1) % 5] : MUTED;
      var its = ln.items, n = its.length, sx = x + pad + 8 * k + (tw ? tw + 12 * k : 0), colw = (x + w - pad - sx) / n;
      var tf = ln.title ? fit(ln.title, tw, 80 * k, pyRound(16 * k), pyRound(12 * k), 'bold', 1.2, 3) : [0, []];
      var labs = its.map(function (it) { return fit(it.title, colw - 12 * k, 60 * k, pyRound(14 * k), pyRound(11 * k), 'body', 1.25, 3); });
      var sh = d + 8 * k + Math.max.apply(null, labs.map(function (f) { return f[1].length * f[0] * 1.25; })), th = tf[1].length * tf[0] * 1.2;
      var hh = pad + Math.max(th, sh) + pad;
      cv.rect(x, y, w, hh, 'FFFFFF', LINE, 14, 1.2, undefined, 'flow lane');
      cv.rect(x, y + 12 * k, 5 * k, hh - 24 * k, c, null, 2, undefined, undefined, 'flow accent');
      if (tf[1].length) cv.text(x + pad + 8 * k, y + (hh - th) / 2, tw, tf[1], tf[0], INK, 'bold', undefined, 1.2, 'flow title', ln.title, kw(lp(b, ln, null, 'title')));
      var cy = y + (hh - sh) / 2, used = new Set();
      its.forEach(function (it, i) {
        var cx = sx + i * colw + colw / 2, f = labs[i], s = d * 0.56;
        cv.ellipse(cx - d / 2, cy, d, d, after ? c : 'F3EDEB', after ? null : LINE, 1.2, 'flow step', {grad: after ? style(theme, c, 'mark').grad : null});
        cv.icon(listIcon(it, used), cx - s / 2, cy + (d - s) / 2, s, after ? 'FFFFFF' : MUTED, kw(lp(b, ln, i, 'icon'), {bold: o[1]}));
        if (i < n - 1) cv.line(cx + d / 2 + 8 * k, cy + d / 2, cx + colw - d / 2 - 8 * k, cy + d / 2, c, 2.5 * k, undefined, 'flow arrow', {arrow: true});
        cv.text(cx - colw / 2 + 6 * k, cy + d + 8 * k, colw - 12 * k, f[1], f[0], INK, 'body', 'center', 1.25, 'flow step text', it.title, kw(lp(b, ln, i, 'title')));
      });
      y += hh + g;
    });
    return y - y0 - g;
  }

  // ------------------------------------------------------------------------------------------------ v139 ways to tell it (info.py)
  // A journey that climbs (stairs), runs in arrows (chevrons), builds up in layers (pyramid), rises on a curve (curve) or widens in
  // rings (rings); one idea and its parts (hub); what holds a vision up (house); points as tiles (cards).
  var RAMP = ['F26923', 'F24C26', 'E9341C', 'DB0058', 'C10060', '5D0F43'], RAMP_FLAT = ['F26923', 'E9341C', 'DB0058', 'C10060', '5D0F43'];
  function solid(theme, c) {   // [fill, grad, stroke, ink, icon] of a shape drawn in colour on every theme (info.py _solid)
    var st = style(theme, c, 'mark');
    if (FILLED.indexOf(theme) >= 0) return [st.fill, st.grad, null, st.head, st.icon];
    return [c, null, null, 'FFFFFF', 'FFFFFF'];
  }
  function stage(theme, i) {   // a journey's stage i (info.py _stage)
    if (theme !== 'ulta') return solid(theme, PALETTE[i % 5]);
    var j = Math.min(i, 4);
    if (S.look === 'light') return [LIGHT_STAGES[j][0], LIGHT_STAGES[j].slice(), null, INK, INK];
    if (S.look === 'flat') return [RAMP_FLAT[j], null, null, 'FFFFFF', 'FFFFFF'];
    return [RAMP[j], [RAMP[j], RAMP[j + 1]], null, 'FFFFFF', 'FFFFFF'];
  }
  function dk(ink, o) { o = o || {}; if (ink === INK) o.dark = true; return o; }   // dark words stay dark on the light lead (info.py _dk)
  function lead(theme) { return theme === 'ulta' && S.look === 'light' ? [LIGHT_LEAD[0], LIGHT_LEAD.slice(), null, INK, INK] : solid(theme, TITLE); }   // info.py _lead
  function head(title, wb, wf, k) {   // [beside, [fs, lines]]: a stage name on its shape, 14 pt bold or more (info.py _head)
    var hi = Math.max(24, pyRound(26 * k));
    if (C.split(title || '').every(function (x) { return textW(x, 24, 'bold') <= wb; }) && wrap(title, wb, 24, 'bold').length <= 2) return [true, fit(title, wb, 62 * k, hi, 24, 'bold', 1.15, 2)];
    return [false, fit(title, wf, 62 * k, hi, 24, 'bold', 1.15, 2)];
  }
  function fitHy(text, w, h, hi, lo, font, lh, maxLines) {   // a hyphenated word too wide for a narrow column breaks after a hyphen (info.py _fit_hy)
    var pairs = [], toks = [];
    C.split(text || '').forEach(function (t) {
      if (C.strip(t, '-').indexOf('-') >= 0 && textW(t, lo, font) > w) {
        var ps = t.split('-'), segs = ps.slice(0, -1).map(function (p) { return p + '-'; }).concat([ps[ps.length - 1]]);
        for (var q = 0; q + 1 < segs.length; q++) pairs.push([segs[q], segs[q + 1]]);
        toks = toks.concat(segs);
      } else toks.push(t);
    });
    var f = fit(toks.join(' '), w, h, hi, lo, font, lh, maxLines), ls = f[1];
    pairs.forEach(function (p) { ls = ls.map(function (l) { return l.split(p[0] + ' ' + p[1]).join(p[0] + p[1]); }); });
    return [f[0], ls];
  }
  function stageFits(it, w, k, lines, when) {   // [when, text, height] (info.py _stage_fits)
    lines = lines === undefined ? 5 : lines; when = when === undefined ? true : when;
    var wl = when && it.when ? fit(it.when.toUpperCase(), w, 22 * k, 14, 14, 'bold', 1.2, 1) : [0, []];
    var xl = it.text ? fit(it.text, w, (24 * lines) * k + 40, Math.max(14, pyRound(14 * k)), 14, 'body', 1.3, lines) : [0, []];
    return [wl, xl, (wl[1].length ? wl[1].length * wl[0] * 1.2 + (xl[1].length ? 4 * k : 0) : 0) + xl[1].length * xl[0] * 1.3];
  }
  function stageDraw(cv, b, i, it, f, x, y, w, k, align, name) {   // info.py _stage_draw
    var wl = f[0], xl = f[1];
    if (wl[1].length) y += cv.text(x, y, w, wl[1], wl[0], INK, 'bold', align || 'left', 1.2, name + ' when', it.when.toUpperCase(), kw(ip(b, i, 'when'), {spacing: 1})) + (xl[1].length ? 4 * k : 0);
    if (xl[1].length) cv.text(x, y, w, xl[1], xl[0], MUTED, 'body', align || 'left', 1.3, name + ' text', it.text, kw(ip(b, i, 'text')));
  }
  function onShape(cv, b, i, it, used, x, y, w, h, k, ink, icol, isz, name) {   // a stage's pictogram and name on its shape (info.py _on_shape)
    var hd = head(get(it, 'title', ''), w - isz - 12 * k, w, k), fs = hd[1][0], ls = hd[1][1], th = ls.length * fs * 1.15, oy;
    if (hd[0]) {
      oy = y + (h - Math.max(isz, th)) / 2;
      cv.icon(listIcon(it, used), x, oy + Math.max(0, (th - isz) / 2), isz, icol, kw(ip(b, i, 'icon'), {bold: ic(b)[1]}));
      cv.text(x + isz + 12 * k, oy + Math.max(0, (isz - th) / 2), w - isz - 12 * k, ls, fs, ink, 'bold', undefined, 1.15, name + ' title', get(it, 'title', ''), kw(ip(b, i, 'title'), dk(ink)));
    } else {
      oy = y + (h - isz - 8 * k - th) / 2;
      cv.icon(listIcon(it, used), x + (w - isz) / 2, oy, isz, icol, kw(ip(b, i, 'icon'), {bold: ic(b)[1]}));
      cv.text(x, oy + isz + 8 * k, w, ls, fs, ink, 'bold', 'center', 1.15, name + ' title', get(it, 'title', ''), kw(ip(b, i, 'title'), dk(ink)));
    }
  }
  function onShapeH(it, w, k, isz) { var hd = head(get(it, 'title', ''), w - isz - 12 * k, w, k), th = hd[1][1].length * hd[1][0] * 1.15; return hd[0] ? Math.max(isz, th) : isz + 8 * k + th; }
  function sum(xs) { return xs.reduce(function (a, v) { return a + v; }, 0); }
  function drawStairs(cv, b, x, y, w, k, theme, ci) {   // info.py draw_stairs
    var its = b.items, n = its.length, g = 5 * k, sw = (w - g * (n - 1)) / n, pad = 16 * k, isz = 36 * k * ic(b)[0], used = new Set(), fl = 50 * k;
    var hh = Math.max.apply(null, its.map(function (it) { return onShapeH(it, sw - 2 * pad, k, isz); }));
    var face0 = Math.max(76 * k, 2 * pad + 10 * k + hh), rise = 40 * k;
    var tex = its.map(function (it, i) { return stageFits(it, sw - 8 * k - (i === n - 1 ? 46 * k : 0), k); });
    var H = Math.max.apply(null, [face0 + (n - 1) * rise + fl].concat(tex.map(function (t, i) { return face0 + i * rise + (t[2] ? 14 * k + t[2] : 0); }))), base = y + H;
    its.forEach(function (it, i) {
      var s = stage(theme, i), t = tex[i], fx = x + i * (sw + g), fh = face0 + i * rise, fy = base - fh;
      cv.rect(fx, fy, sw, fh, s[0], s[2], 6 * k, 1, s[1], 'stair');
      cv.rect(fx, fy, sw, 9 * k, LIGHT_CARD, null, 4 * k, undefined, undefined, 'stair tread');
      onShape(cv, b, i, it, used, fx + pad, fy + 10 * k + pad, sw - 2 * pad, hh, k, s[3], s[4], isz, 'stair');
      if (t[2]) stageDraw(cv, b, i, it, t, fx + 4 * k, fy - 14 * k - t[2], sw - 8 * k, k, undefined, 'stair');
    });
    var sl = stage(theme, n - 1), px = x + w - 30 * k, fy2 = base - face0 - (n - 1) * rise;
    cv.line(px, fy2, px, fy2 - fl, '404040', 3 * k, undefined, 'stair flag pole');
    cv.poly([[px, fy2 - fl], [px + 28 * k, fy2 - fl + 10 * k], [px, fy2 - fl + 20 * k]], sl[0], null, undefined, 'stair flag', {grad: sl[1]});
    return H;
  }
  function drawChevrons(cv, b, x, y, w, k, theme, ci) {   // info.py draw_chevrons
    var its = b.items, n = its.length, d = 34 * k, g = 7 * k, cw = (w + (n - 1) * (d - g)) / n, pad = 14 * k, isz = 34 * k * ic(b)[0], used = new Set();
    var ins = its.map(function (it, i) { return (i ? d : pad) + 8 * k; });
    var hh = Math.max.apply(null, its.map(function (it, i) { return onShapeH(it, cw - ins[i] - d, k, isz); })), ch = Math.max(90 * k, 2 * pad + hh);
    var tex = its.map(function (it, i) { return stageFits(it, cw - ins[i] - d, k); }), hm = Math.max.apply(null, tex.map(function (t) { return t[2]; }));
    its.forEach(function (it, i) {
      var s = stage(theme, i), t = tex[i], cx = x + i * (cw - d + g);
      cv.poly([[cx, y], [cx + cw - d, y], [cx + cw, y + ch / 2], [cx + cw - d, y + ch], [cx, y + ch]].concat(i ? [[cx + d, y + ch / 2]] : []), s[0], s[2], 1, 'chevron', {grad: s[1]});
      onShape(cv, b, i, it, used, cx + ins[i], y + pad, cw - ins[i] - d, ch - 2 * pad, k, s[3], s[4], isz, 'chevron');
      if (t[2]) stageDraw(cv, b, i, it, t, cx + ins[i], y + ch + 16 * k, cw - ins[i] - d, k, undefined, 'chevron');
    });
    return ch + (hm ? 16 * k + hm : 0);
  }
  function drawPyramid(cv, b, x, y, w, k, theme, ci) {   // info.py draw_pyramid
    var its = b.items, n = its.length, pw = Math.min(w * 0.42, 540 * k), gx = 34 * k, lx = x + pw + gx, lw = w - pw - gx, g = 6 * k, used = new Set(), isz = 32 * k * ic(b)[0];
    var tls = its.map(function (it) { return fit(get(it, 'title', ''), lw, 48 * k, Math.max(14, pyRound(18 * k)), 14, 'bold', 1.2, 2); });
    var wls = its.map(function (it) { return stageFits(Object.assign({}, it, {text: ''}), lw, k); }), tex = its.map(function (it) { return stageFits(it, lw, k, 3, false); });
    var hs = its.map(function (it, i) { return (wls[i][2] ? wls[i][2] + 4 * k : 0) + tls[i][1].length * tls[i][0] * 1.2 + (tex[i][2] ? 6 * k + tex[i][2] : 0); });
    var lh = Math.max(70 * k, isz + 30 * k, Math.max.apply(null, hs) + 12 * k), H = n * lh + (n - 1) * g, cx = x + pw / 2;
    var hw = function (yy) { return (pw / 2) * (yy - y) / H; };
    for (var j = 0; j < n; j++) {   // from the top: the last item
      var i = n - 1 - j, it = its[i], s = stage(theme, i), yt = y + j * (lh + g), yb = yt + lh;
      cv.poly((j === 0 ? [[cx, yt]] : [[cx - hw(yt), yt], [cx + hw(yt), yt]]).concat([[cx + hw(yb), yb], [cx - hw(yb), yb]]), s[0], s[2], 1, 'pyramid layer', {grad: s[1]});
      cv.icon(listIcon(it, used), cx - isz / 2, j === 0 ? (yb - isz - 12 * k) : (yt + (lh - isz) / 2), isz, s[4], kw(ip(b, i, 'icon'), {bold: ic(b)[1]}));
      var my = (yt + yb) / 2, ex = cx + hw(my) + 12 * k, lc = s[1] ? s[1][1] : s[0];
      cv.line(ex, my, lx - 16 * k, my, lc, 2 * k, true, 'pyramid leader');
      cv.ellipse(lx - 21 * k, my - 5 * k, 10 * k, 10 * k, lc, undefined, undefined, 'pyramid leader dot');
      var yy = my - hs[i] / 2;
      if (wls[i][2]) { stageDraw(cv, b, i, it, wls[i], lx, yy, lw, k, undefined, 'pyramid'); yy += wls[i][2] + 4 * k; }
      yy += cv.text(lx, yy, lw, tls[i][1], tls[i][0], INK, 'bold', undefined, 1.2, 'pyramid title', get(it, 'title', ''), kw(ip(b, i, 'title')));
      if (tex[i][2]) stageDraw(cv, b, i, it, tex[i], lx, yy + 6 * k, lw, k, undefined, 'pyramid');
    }
    return H;
  }
  function drawCurve(cv, b, x, y, w, k, theme, ci) {   // info.py draw_curve
    var its = b.items, n = its.length, colw = w / n, d = 56 * k, used = new Set(), ah = 170 * k;
    var tls = its.map(function (it) { return fit(get(it, 'title', ''), colw - 28 * k, 48 * k, Math.max(14, pyRound(18 * k)), 14, 'bold', 1.2, 2); });
    var tex = its.map(function (it) { return stageFits(it, colw - 28 * k, k, 4, false); }), wls = its.map(function (it) { return stageFits(Object.assign({}, it, {text: ''}), colw - 20 * k, k); });
    var hw = Math.max.apply(null, wls.map(function (t) { return t[2]; })), hs = its.map(function (it, i) { return tls[i][1].length * tls[i][0] * 1.2 + (tex[i][2] ? 6 * k + tex[i][2] : 0); });
    var top = (hw ? hw + 10 * k : 0) + d / 2 + 6 * k, base = y + top + ah;
    var f = function (t) { return t * t * t * (t * (6 * t - 15) + 10); }, cy = function (t) { return base - ah * (0.04 + 0.96 * f(t)); };
    var pts = []; for (var q = 0; q < 49; q++) pts.push([x + w * q / 48, cy(q / 48)]);
    var s0 = stage(theme, 0), sz = stage(theme, n - 1);
    cv.poly([[x, base]].concat(pts, [[x + w, base]]), theme === 'ulta' ? LIGHT_CARD : tint(s0[0], 0.86), null, undefined, 'curve area', {grad: theme === 'ulta' ? ['FFF3ED', LIGHT_CARD] : null});
    cv.poly(pts.map(function (p) { return [p[0], p[1] - 3.5 * k]; }).concat(pts.slice().reverse().map(function (p) { return [p[0], p[1] + 3.5 * k]; })), s0[0], null, undefined, 'curve line',
      {grad: (s0[1] || sz[1]) ? [s0[0], sz[1] ? sz[1][1] : sz[0]] : null});
    cv.line(x, base, x + w, base, LINE, 2, undefined, 'curve base');
    its.forEach(function (it, i) {
      var s = stage(theme, i), t = (i + 0.5) / n, px = x + w * t, py = cy(t), dz = d * 0.56;
      cv.line(px, py + d / 2, px, base, s[1] ? s[1][1] : s[0], 2 * k, true, 'curve leader');
      cv.ellipse(px - d / 2, py - d / 2, d, d, s[0], 'FFFFFF', 4 * k, 'curve dot', {grad: s[1]});
      cv.icon(listIcon(it, used), px - dz / 2, py - dz / 2, dz, s[4], kw(ip(b, i, 'icon'), {bold: ic(b)[1]}));
      if (wls[i][2]) stageDraw(cv, b, i, it, wls[i], px - colw / 2 + 10 * k, py - d / 2 - 8 * k - wls[i][2], colw - 20 * k, k, 'center', 'curve');
      var yy = base + 16 * k + cv.text(px - colw / 2 + 14 * k, base + 16 * k, colw - 28 * k, tls[i][1], tls[i][0], INK, 'bold', 'center', 1.2, 'curve title', get(it, 'title', ''), kw(ip(b, i, 'title')));
      if (tex[i][2]) stageDraw(cv, b, i, it, tex[i], px - colw / 2 + 14 * k, yy + 6 * k, colw - 28 * k, k, 'center', 'curve');
    });
    return top + ah + 16 * k + Math.max.apply(null, hs);
  }
  function drawHub(cv, b, x, y, w, k, theme, ci) {   // info.py draw_hub
    var its = b.items, n = its.length, L = Math.floor((n + 1) / 2), sides = [its.slice(0, L), its.slice(L)], D = Math.min(250 * k, w * 0.24), dd = 58 * k, used = new Set();
    var bump = 26 * k, reach = D / 2 + 64 * k, tw = w / 2 - reach - dd - bump - 16 * k;
    var tex = sides.map(function (side) { return side.map(function (it) {
      return [fit(get(it, 'title', ''), tw, 44 * k, Math.max(14, pyRound(17 * k)), 14, 'bold', 1.2, 2), it.text ? fit(get(it, 'text', ''), tw, 130 * k, Math.max(14, pyRound(14 * k)), 14, 'body', 1.3, 6) : [0, []]]; }); });
    var th = function (tt) { return tt[0][1].length * tt[0][0] * 1.2 + (tt[1][1].length ? 4 * k + tt[1][1].length * tt[1][0] * 1.3 : 0); };
    var rh = Math.max.apply(null, [dd + 18 * k].concat([].concat.apply([], tex.map(function (s) { return s.map(function (tt) { return th(tt) + 20 * k; }); }))));
    var rows = Math.max(sides[0].length, sides[1].length), H = Math.max(D + 48 * k, rows * rh), cx = x + w / 2, cy = y + H / 2, l = lead(theme), marks = [];
    sides.forEach(function (side, si) {
      var m = side.length;
      side.forEach(function (it, j) {
        var off = j - (m - 1) / 2, yy = cy + off * rh, dx = reach + dd / 2 + bump * Math.abs(off) / Math.max(1, (m - 1) / 2);
        marks.push([si, it, tex[si][j], si ? cx + dx : cx - dx, yy, PALETTE[(ci + marks.length) % 5], si ? L + j : j]);
      });
    });
    marks.forEach(function (mk) {   // the spokes under the discs
      var px = mk[3], yy = mk[4], c = mk[5], Ln = Math.sqrt((px - cx) * (px - cx) + (yy - cy) * (yy - cy)) || 1, ux = (px - cx) / Ln, uy = (yy - cy) / Ln;
      cv.line(cx + (D / 2) * ux, cy + (D / 2) * uy, px - (dd / 2) * ux, yy - (dd / 2) * uy, theme !== 'charcoal' ? tint(c, 0.45) : '8A8C8F', 3 * k, undefined, 'hub spoke');
    });
    cv.ellipse(cx - D / 2 - 14 * k, cy - D / 2 - 14 * k, D + 28 * k, D + 28 * k, theme === 'ulta' ? LIGHT_CARD : tint(TITLE, 0.85), null, undefined, 'hub halo');
    cv.ellipse(cx - D / 2, cy - D / 2, D, D, l[0], null, undefined, 'hub', {grad: l[1]});
    if (b.center) {
      var f = fit(b.center, D * 0.72, D * 0.62, Math.max(24, pyRound(28 * k)), l[3] !== INK ? 24 : 16, 'bold', 1.12, 4);   // white needs 14 pt bold on orange; dark may be smaller
      cv.text(cx - D * 0.36, cy - f[1].length * f[0] * 1.12 / 2, D * 0.72, f[1], f[0], l[3], 'bold', 'center', 1.12, 'hub text', b.center, kw(bp(b, 'center'), dk(l[3])));
    }
    marks.forEach(function (mk) {
      var si = mk[0], it = mk[1], tt = mk[2], px = mk[3], yy = mk[4], i = mk[6], s = solid(theme, mk[5]), dz = dd * 0.56;
      cv.ellipse(px - dd / 2, yy - dd / 2, dd, dd, s[0], 'FFFFFF', 3 * k, 'hub disc', {grad: s[1]});
      cv.icon(listIcon(it, used), px - dz / 2, yy - dz / 2, dz, s[4], kw(ip(b, i, 'icon'), {bold: ic(b)[1]}));
      var h = th(tt), tx = si ? px + dd / 2 + 16 * k : x, ww = si ? (x + w - tx) : (px - dd / 2 - 16 * k - x), al = si ? 'left' : 'right';
      var y0 = yy - h / 2 + cv.text(tx, yy - h / 2, ww, tt[0][1], tt[0][0], INK, 'bold', al, 1.2, 'hub title', get(it, 'title', ''), kw(ip(b, i, 'title')));
      if (tt[1][1].length) cv.text(tx, y0 + 4 * k, ww, tt[1][1], tt[1][0], MUTED, 'body', al, 1.3, 'hub item text', it.text, kw(ip(b, i, 'text')));
    });
    return H;
  }
  function drawHouse(cv, b, x, y, w, k, theme, ci) {   // info.py draw_house
    var its = b.items, n = its.length, used = new Set(), pad = 16 * k, l = lead(theme);
    var rh = 100 * k, ax = x + 34 * k, aw = w - 68 * k, gp = 20 * k, pw = (aw - gp * (n - 1)) / n, isz = 46 * k;
    if (pw < 170 * k) { ax = x + 18 * k; aw = w - 36 * k; gp = 10 * k; pad = 9 * k; pw = (aw - gp * (n - 1)) / n; isz = 40 * k; }   // narrow: room for the words
    var roof = b.roof ? fit(b.roof, aw - 40 * k, 92 * k, Math.max(14, pyRound(19 * k)), Math.max(14, pyRound(14 * k)), 'bold', 1.25, 3) : [0, []];
    var bh = roof[1].length ? roof[1].length * roof[0] * 1.25 + 2 * pad : 0;
    var a0 = Math.min.apply(null, its.map(function (it) { return fitHy(get(it, 'title', ''), pw - 2 * pad, 66 * k, Math.max(14, pyRound(17 * k)), 14, 'bold', 1.2, 3)[0]; }));
    var ts = its.filter(function (it) { return it.text; }).map(function (it) { return fitHy(it.text, pw - 2 * pad, 120 * k, Math.max(14, pyRound(14 * k)), 14, 'body', 1.3, 6)[0]; });
    var t0 = ts.length ? Math.min.apply(null, ts) : 0;
    var cols = its.map(function (it) { return [fitHy(get(it, 'title', ''), pw - 2 * pad, 66 * k, a0, a0, 'bold', 1.2, 3), it.text ? fitHy(get(it, 'text', ''), pw - 2 * pad, 120 * k, t0, t0, 'body', 1.3, 6) : [0, []]]; });
    var ph = Math.max.apply(null, cols.map(function (c) { return pad + isz + 12 * k + c[0][1].length * c[0][0] * 1.2 + (c[1][1].length ? 6 * k + c[1][1].length * c[1][0] * 1.3 : 0) + pad; }));
    var base = b.base ? fit(b.base, w - 2 * pad - 60 * k, 100 * k, Math.max(24, pyRound(25 * k)), 24, 'bold', 1.25, 3) : [0, []];
    var fh = base[1].length ? base[1].length * base[0] * 1.25 + 2 * pad : 22 * k;
    cv.poly([[x, y + rh], [x + w / 2, y], [x + w, y + rh]], l[0], null, undefined, 'house roof', {grad: l[1]});
    cv.icon(b.icon || 'insight', x + w / 2 - 21 * k, y + rh * 0.42, 42 * k, l[4], kw(bp(b, 'icon')));
    var yy = y + rh + 6 * k;
    if (roof[1].length) {
      cv.rect(x + 14 * k, yy, w - 28 * k, bh, theme === 'ulta' ? LIGHT_CARD : style(theme, TITLE).fill, null, 6 * k, undefined, undefined, 'house beam');
      cv.text(x + 34 * k, yy + pad, w - 68 * k, roof[1], roof[0], theme === 'ulta' ? INK : style(theme, TITLE).head, 'bold', 'center', 1.25, 'house roof text', b.roof, kw(bp(b, 'roof')));
      yy += bh + 10 * k;
    }
    its.forEach(function (it, i) {
      var a = cols[i][0], t = cols[i][1], s = solid(theme, PALETTE[(ci + i) % 5]), px = ax + i * (pw + gp), dz = isz * 0.58;
      cv.rect(px - 6 * k, yy, pw + 12 * k, 12 * k, s[0], null, 3 * k, 1, s[1], 'pillar capital');
      cv.rect(px, yy + 12 * k, pw, ph, theme !== 'velvet' ? 'FFFFFF' : '2A2220', theme !== 'velvet' ? LINE : null, 0, 1, undefined, 'pillar');
      cv.ellipse(px + (pw - isz) / 2, yy + 12 * k + pad, isz, isz, s[0], null, undefined, 'pillar disc', {grad: s[1]});
      cv.icon(listIcon(it, used), px + (pw - dz) / 2, yy + 12 * k + pad + (isz - dz) / 2, dz, s[4], kw(ip(b, i, 'icon'), {bold: ic(b)[1]}));
      var ty = yy + 12 * k + pad + isz + 12 * k + cv.text(px + pad, yy + 12 * k + pad + isz + 12 * k, pw - 2 * pad, a[1], a[0], theme !== 'velvet' ? INK : 'FFFFFF', 'bold', 'center', 1.2, 'pillar title', get(it, 'title', ''), kw(ip(b, i, 'title')));
      if (t[1].length) cv.text(px + pad, ty + 6 * k, pw - 2 * pad, t[1], t[0], theme !== 'velvet' ? MUTED : 'F9E3DE', 'body', 'center', 1.3, 'pillar text', it.text, kw(ip(b, i, 'text')));
      cv.rect(px - 6 * k, yy + 12 * k + ph, pw + 12 * k, 10 * k, s[0], null, 3 * k, 1, s[1], 'pillar foot');
    });
    yy += 12 * k + ph + 10 * k + 8 * k;
    cv.rect(x + 14 * k, yy, w - 28 * k, fh, l[0], null, 8 * k, 1, l[1], 'house base');
    if (base[1].length) cv.text(x + 14 * k + pad + 30 * k, yy + pad, w - 28 * k - 2 * pad - 60 * k, base[1], base[0], l[3], 'bold', 'center', 1.25, 'house base text', b.base, kw(bp(b, 'base'), dk(l[3])));
    cv.rect(x, yy + fh + 5 * k, w, 12 * k, FILLED.indexOf(theme) >= 0 ? (l[1] ? l[1][1] : shade(l[0], 0.12)) : l[0], null, 4 * k, undefined, undefined, 'house step');
    return yy + fh + 17 * k - y;
  }
  function drawCards(cv, b, x, y, w, k, theme, ci) {   // info.py draw_cards
    var its = b.items, n = its.length, used = new Set();
    var cols = ((n === 4 || n === 8) && w >= 1200) ? 4 : (n >= 3 && w >= 760) ? 3 : (n >= 2 && w >= 440) ? 2 : 1;
    var g = 20 * k, cw = (w - g * (cols - 1)) / cols, pad = 18 * k, isz = 48 * k, rows = Math.ceil(n / cols), y0 = y;
    for (var r_ = 0; r_ < rows; r_++) {
      var row = its.slice(r_ * cols, (r_ + 1) * cols), lay = row.map(function (it) {
        var a = fit(get(it, 'title', ''), cw - 2 * pad - isz - 12 * k, 48 * k, Math.max(14, pyRound(17 * k)), 14, 'bold', 1.2, 2);
        var t = it.text ? fit(get(it, 'text', ''), cw - 2 * pad, 96 * k, Math.max(14, pyRound(14 * k)), 14, 'body', 1.3, 4) : [0, []];
        return [a, t, pad + Math.max(isz, a[1].length * a[0] * 1.2) + (t[1].length ? 10 * k + t[1].length * t[0] * 1.3 : 0) + pad];
      });
      var h = Math.max.apply(null, lay.map(function (q) { return q[2]; })), base = r_ * cols, yr = y;
      row.forEach(function (it, j) {
        var i = base + j, a = lay[j][0], t = lay[j][1], c = PALETTE[(ci + i) % 5], st = style(theme, c, 'card'), s = solid(theme, c), cx = x + j * (cw + g), dz = isz * 0.58, ah = a[1].length * a[0] * 1.2;
        card(cv, cx, yr, cw, h, st, 'tile');
        cv.ellipse(cx + pad, yr + pad, isz, isz, s[0], null, undefined, 'tile disc', {grad: s[1]});
        cv.icon(listIcon(it, used), cx + pad + (isz - dz) / 2, yr + pad + (isz - dz) / 2, dz, s[4], kw(ip(b, i, 'icon'), {bold: ic(b)[1]}));
        cv.text(cx + pad + isz + 12 * k, yr + pad + Math.max(0, (isz - ah) / 2), cw - 2 * pad - isz - 12 * k, a[1], a[0], st.head, 'bold', undefined, 1.2, 'tile title', get(it, 'title', ''), kw(ip(b, i, 'title')));
        if (t[1].length) cv.text(cx + pad, yr + pad + Math.max(isz, ah) + 10 * k, cw - 2 * pad, t[1], t[0], (theme === 'velvet' || theme === 'charcoal') ? st.sub : MUTED, 'body', undefined, 1.3, 'tile text', it.text, kw(ip(b, i, 'text')));
      });
      y += h + g;
    }
    return y - y0 - g;
  }
  function drawRings(cv, b, x, y, w, k, theme, ci) {   // info.py draw_rings
    var its = b.items, n = its.length, R = Math.min(w * 0.27, 215 * k), isz = 30 * k * ic(b)[0], used = new Set();
    var under_ = w - 2 * R - 64 * k < 260 * k;   // too narrow for the words beside the rings: they go under them
    if (under_) R = Math.min(w * 0.46, 170 * k);
    var r = its.map(function (it, i) { return n > 1 ? R * (0.6 + 0.4 * i / (n - 1)) : R; });
    var cx = x + (under_ ? w / 2 : R), yb = y + 2 * R, lx = x + (under_ ? 22 * k : 2 * R + 64 * k), lw = w - (under_ ? 22 * k : 2 * R + 64 * k);
    var mid = r.map(function (ri, i) { return yb - ri - (i ? r[i - 1] : 0); });
    var band = r.map(function (ri, i) { return 2 * (i ? Math.sqrt(Math.max(0.0, ri * ri - r[i - 1] * r[i - 1])) : r[0] * 0.9) - 24 * k; });
    var inside = its.map(function (it, i) { return C.split(get(it, 'title', '')).every(function (x_) { return textW(x_, 24, 'bold') <= band[i]; }); });
    var heads = its.map(function (it, i) { return inside[i] ? head(get(it, 'title', ''), band[i] - isz - 10 * k, band[i], k) : [false, [0, []]]; });   // fitted only where it goes
    var tls = its.map(function (it, i) { return !inside[i] ? fit(get(it, 'title', ''), lw, 48 * k, Math.max(14, pyRound(18 * k)), 14, 'bold', 1.2, 2) : [0, []]; });
    var wls = its.map(function (it) { return stageFits(Object.assign({}, it, {text: ''}), lw, k); }), tex = its.map(function (it) { return stageFits(it, lw, k, 3, false); });
    var hs = its.map(function (it, i) { return (wls[i][2] ? wls[i][2] + 4 * k : 0) + tls[i][1].length * tls[i][0] * 1.2 + (tex[i][2] ? 6 * k + tex[i][2] : 0); });
    for (var q = n - 1; q >= 0; q--) { var sq = stage(theme, q); cv.ellipse(cx - r[q], yb - 2 * r[q], 2 * r[q], 2 * r[q], sq[0], 'FFFFFF', 3 * k, 'ring', {grad: sq[1]}); }
    its.forEach(function (it, i) {
      var s = stage(theme, i), fs = heads[i][1][0], ls = heads[i][1][1], th = ls.length * fs * 1.15, yy;
      if (!inside[i]) cv.icon(listIcon(it, used), cx - isz / 2, mid[i] - isz / 2, isz, s[4], kw(ip(b, i, 'icon'), {bold: ic(b)[1]}));
      else if (heads[i][0]) {
        var tw = Math.max.apply(null, ls.map(function (l) { return textW(l, fs, 'bold'); })), ox = cx - (isz + 10 * k + tw) / 2;
        cv.icon(listIcon(it, used), ox, mid[i] - isz / 2, isz, s[4], kw(ip(b, i, 'icon'), {bold: ic(b)[1]}));
        cv.text(ox + isz + 10 * k, mid[i] - th / 2, tw + 4 * k, ls, fs, s[3], 'bold', undefined, 1.15, 'ring title', get(it, 'title', ''), kw(ip(b, i, 'title'), dk(s[3])));
      } else {
        cv.icon(listIcon(it, used), cx - isz / 2, mid[i] - (isz + 6 * k + th) / 2, isz, s[4], kw(ip(b, i, 'icon'), {bold: ic(b)[1]}));
        cv.text(cx - band[i] / 2, mid[i] - (isz + 6 * k + th) / 2 + isz + 6 * k, band[i], ls, fs, s[3], 'bold', 'center', 1.15, 'ring title', get(it, 'title', ''), kw(ip(b, i, 'title'), dk(s[3])));
      }
      var lc = s[1] ? s[1][1] : s[0], h = (wls[i][2] ? wls[i][2] + 4 * k : 0) + tls[i][1].length * tls[i][0] * 1.2 + (tex[i][2] ? 6 * k + tex[i][2] : 0);
      if (under_) { yy = yb + 18 * k + sum(hs.slice(0, i)) + 14 * k * i; cv.ellipse(x + 2 * k, yy + 3 * k, 10 * k, 10 * k, lc, undefined, undefined, 'ring leader dot'); }
      else {
        var ex = cx + Math.sqrt(Math.max(0.0, R * R - (mid[i] - (yb - R)) * (mid[i] - (yb - R)))) + 10 * k;
        cv.line(ex, mid[i], lx - 16 * k, mid[i], lc, 2 * k, true, 'ring leader');
        cv.ellipse(lx - 21 * k, mid[i] - 5 * k, 10 * k, 10 * k, lc, undefined, undefined, 'ring leader dot'); yy = mid[i] - h / 2;
      }
      if (wls[i][2]) { stageDraw(cv, b, i, it, wls[i], lx, yy, lw, k, undefined, 'ring'); yy += wls[i][2] + 4 * k; }
      if (tls[i][1].length) yy += cv.text(lx, yy, lw, tls[i][1], tls[i][0], INK, 'bold', undefined, 1.2, 'ring name', get(it, 'title', ''), kw(ip(b, i, 'title')));
      if (tex[i][2]) stageDraw(cv, b, i, it, tex[i], lx, yy + 6 * k, lw, k, undefined, 'ring');
    });
    return 2 * R + (under_ ? 18 * k + sum(hs) + 14 * k * (n - 1) : 0);
  }

  var DRAW = {stats: drawStats, steps: drawSteps, timeline: drawTimeline, compare: drawCompare, bars: drawBars, donut: drawDonut, list: drawList, quote: drawQuote,
    takeaway: drawTakeaway, status: drawStatus, rag: drawRag, risks: drawRisks, table: drawTable, ragcards: drawRagcards,
    image: drawImage, feature: drawFeature, gallery: drawGallery, band: drawBand, flow: drawFlow,
    stairs: drawStairs, chevrons: drawChevrons, pyramid: drawPyramid, curve: drawCurve, hub: drawHub, house: drawHouse, cards: drawCards, rings: drawRings};

  // ------------------------------------------------------------------------------------------------ the page
  function rowsOf(blocks, width) {
    var rows = [], i = 0, pair = function (x) { return HALF.has(x.type); };
    while (i < blocks.length) {
      var b = blocks[i];
      if (b.half && i + 1 < blocks.length && blocks[i + 1].half && width >= 760) { rows.push([b, blocks[i + 1]]); i += 2; }   // v139: asked for
      else if (!WIDE.has(b.type) && i + 1 < blocks.length && !WIDE.has(blocks[i + 1].type) && width >= 880) { rows.push([b, blocks[i + 1]]); i += 2; }
      else if (S.squeeze && width >= 1200 && pair(b) && i + 1 < blocks.length && pair(blocks[i + 1])) { rows.push([b, blocks[i + 1]]); i += 2; }
      else { rows.push([b]); i += 1; }
    }
    return rows;
  }
  function btitle(cv, b, x, y, w, k, accent, theme) {
    if (['', 'free', undefined, null].indexOf(b._tpl) < 0) return statusTitle(cv, b, x, y, w, k, accent, (b.type === 'rag' || b.type === 'risks') ? SECTION_ICON[b.type] : null, theme);
    return blockTitle(cv, b, x, y, w, k, accent);
  }
  function tag(cv, from, b) {   // what a block drew knows its block (the editor selects the block it belongs to)
    if (typeof b._i === 'number') for (var i = from; i < cv.els.length; i++) if (cv.els[i].blk === undefined) cv.els[i].blk = b._i;
  }
  function drawRow(cv, row, x, y, w, k, theme, ci0) {
    var at = cv.els.length;
    if (row.length === 1) { var b = row[0], ht = btitle(cv, b, x, y, w, k, PALETTE[ci0 % 5], theme), h1 = ht + DRAW[b.type](cv, b, x, y + ht, w, k, theme, ci0); tag(cv, at, b); return h1; }
    var g = 44 * k, cw = (w - g) / 2, hs = [];
    row.forEach(function (b, j) { at = cv.els.length; var ht = btitle(cv, b, x + j * (cw + g), y, cw, k, PALETTE[(ci0 + j) % 5], theme); hs.push(ht + DRAW[b.type](cv, b, x + j * (cw + g), y + ht, cw, k, theme, ci0 + j)); tag(cv, at, b); });
    return Math.max.apply(null, hs);
  }
  function subP(spec) { return spec._sp || 'subtitle'; }
  function header(cv, spec, fmt) {
    var F = FORMATS[fmt], m = F.margin, W = F.w, y = m, tpl = ['', 'free', undefined, null].indexOf(spec.template) < 0;
    cv.rect(0, 0, W, 12, TITLE, null, 0, undefined, TOP_RULE, 'top rule', {chrome: false});
    if (spec.kicker) y += cv.text(m, y, W - 2 * m, [spec.kicker], 15, 'E0531B', 'bold', undefined, 1.2, 'kicker', spec.kicker, {p: 'kicker', spacing: 2}) + 10;
    var hi = fmt === 'onepager' ? 64 : 58, f = fit(spec.title, W - 2 * m, hi * 2.3, hi, 34, 'display', 1.06, 3);
    if (tpl) {
      var f1 = fit(spec.title, W - 2 * m, hi * 1.1, hi, 42, 'display', 1.06, 1, false);
      if (wrap(spec.title, W - 2 * m, f1[0], 'display').length === 1) f = f1;
    }
    y += cv.text(m, y, W - 2 * m, f[1], f[0], TITLE, 'display', undefined, 1.06, 'title', spec.title, {p: 'title'}) + 14;
    if (spec.subtitle) {
      var s = fit(spec.subtitle, W - 2 * m, 90, 21, 15, 'body', 1.35, 3);
      y += cv.text(m, y, W - 2 * m, s[1], s[0], MUTED, 'body', undefined, 1.35, 'subtitle', spec.subtitle, {p: subP(spec)});
    }
    return y + 34;
  }
  function footer(cv, spec, fmt) {
    var F = FORMATS[fmt], m = F.margin, W = F.w, H = F.h, y = H - m + 6;
    cv.line(m, y - 22, W - m, y - 22, LINE, 1.5, undefined, 'footer rule');
    if (spec.source) {
      var f = fit('Source: ' + spec.source, W - 2 * m - 170, 36, 12.5, 10, 'body', 1.3, 2);
      cv.text(m, y - 8, W - 2 * m - 170, f[1], f[0], MUTED, 'body', undefined, 1.3, 'source', 'Source: ' + spec.source, {p: 'source'});
    }
    cv.els.push({k: 'logo', x: W - m - 118, y: y - 10, w: 118, h: 47.7, name: 'logo'});
    return y - 22 - 24;
  }
  function relayout(spec, blocks, warn) {
    var s2 = Object.assign({}, spec, {blocks: blocks.map(function (b) { var o = {}; Object.keys(b).forEach(function (q) { if (q !== '_ic' && q !== '_tpl' && q !== '_im') o[q] = b[q]; }); return o; })});
    var d = layout(s2); d.warnings = warn.concat(d.warnings); return d;
  }
  function layout1(spec) {
    spec = normalise(spec); S.look = spec.look || 'light';
    var fmt = spec.format, F = FORMATS[fmt], W = F.w, H = F.h, theme = spec.theme, warn = [], blocks = spec.blocks.slice(), bx, by, bw, bh;
    blocks.forEach(function (b) { b._ic = spec.icons || {}; b._tpl = spec.template || ''; b._im = spec.images || {}; });
    if (!blocks.length) blocks = [{type: 'takeaway', text: spec.subtitle || 'Add content: paste a page, a list of numbers, steps or points.'}];
    var top = new C.Canvas();
    if (fmt === 'slide') {
      var t = fit(spec.title, 1400, 62, 60, 30, 'display', 0.95, 1), tfs = t[0], tls = t[1];
      if (wrap(spec.title, 1400, tfs, 'display').length > 1) { tfs = 40; tls = wrap(spec.title, 1400, 40, 'display').slice(0, 2); }
      top.text(73, tls.length === 1 ? 53 : 40, tls.length === 1 ? 1400 : 1100, tls, tfs, TITLE, 'display', undefined, 0.95, 'title', spec.title, {p: 'title', chrome: true});
      top.els.push({k: 'logo', x: 62, y: 806, w: 130, h: 52.6, name: 'logo', chrome: true});
      top.text(1135, 842, 400, ['Ulta Beauty | Proprietary & Confidential'], 11.5, INK, 'body', 'right', undefined, 'footer', undefined, {chrome: true});
      bx = F.body[0]; by = F.body[1]; bw = F.body[2]; bh = F.body[3];
      if (spec.subtitle) {
        var sf = fit(spec.subtitle, bw, 56, 19, 14, 'body', 1.3, 2);
        by += top.text(bx, by - 6, bw, sf[1], sf[0], MUTED, 'body', undefined, 1.3, 'subtitle', spec.subtitle, {p: subP(spec)}) + 14; bh = F.body[3] - (by - F.body[1]);
      }
    } else {
      by = header(top, spec, fmt); var bottom = footer(top, spec, fmt); bx = F.margin; bw = W - 2 * bx; bh = bottom - by;
    }
    var tpl = ['', 'free', undefined, null].indexOf(spec.template) < 0, body = null;
    C.state.minFs = tpl ? 14 : 0;
    var kmin = tpl ? (S.squeeze ? 0.62 : fmt === 'slide' ? 0.8 : 0.66) : 0.62;
    var KS = [1.45, 1.36, 1.28, 1.2, 1.12, 1.05, 1.0, 0.94, 0.88, 0.82, 0.8, 0.76, 0.7, 0.66, 0.62].filter(function (x) { return x >= kmin; });
    var before = function (rows, r) { var at = rows.findIndex(function (q) { return C.deepEq(q, r); }); return rows.slice(0, at).reduce(function (a, q) { return a + q.length; }, 0); };
    C.state.quiet = true;   // v139: a trial size that cuts text is not the one drawn: only the final drawing reports a cut (info.py QUIET)
    while (blocks.length) {
      var rows = rowsOf(blocks, bw);
      for (var ki = 0; ki < KS.length; ki++) {
        var k = KS[ki], g = 34 * k, hs = [];
        rows.forEach(function (r) { hs.push(drawRow(new C.Canvas(), r, 0, 0, bw, k, theme, before(rows, r))); });
        var tot = hs.reduce(function (a, h) { return a + h; }, 0) + g * (rows.length - 1);
        if (tot <= bh) { body = [rows, hs, k, g, tot]; break; }
      }
      if (body) break;
      var drop = blocks.length - 1;
      if (tpl) { for (var di = blocks.length - 1; di >= 0; di--) if (['timeline', 'list', 'steps'].indexOf(blocks[di].type) >= 0) { drop = di; break; } }
      if (tpl && fmt !== 'slide' && ['takeaway', 'status'].indexOf(blocks[drop].type) >= 0) {   // on a page the decision and the facts stay: the last other section goes
        for (var dj = blocks.length - 1; dj >= 0; dj--) if (['takeaway', 'status'].indexOf(blocks[dj].type) < 0) { drop = dj; break; }
      }
      if (tpl && blocks[drop].type === 'takeaway' && !spec.subtitle && fmt === 'slide') {
        spec.subtitle = blocks[drop].text; if (typeof blocks[drop]._i === 'number') spec._sp = 'blocks.' + blocks[drop]._i + '.text';
        blocks.splice(drop, 1); warn.push('the decision is shown under the title - the slide has no room for it as a block');
        C.state.quiet = false; return relayout(spec, blocks, warn);   // as in Python: the template's text floor is still set while it relays out
      }
      warn.push('"' + (blocks[drop].title || blocks[drop].type) + '" left out - it does not fit on the ' + F.name.toLowerCase() + '; ' + (fmt === 'onepager' ? 'shorter sections give it room' : 'the one-pager has room for it')); blocks.splice(drop, 1);
    }
    C.state.quiet = false; var cv = new C.Canvas(); cv.els = top.els;
    if (body) {
      var rows2 = body[0], hs2 = body[1], k2 = body[2], g0 = body[3], tot2 = body[4], extra = bh - tot2;
      var g2 = g0 + (rows2.length > 1 ? Math.min(extra / (rows2.length - 1), 46) : 0);
      var y = by + Math.max(0, (bh - (hs2.reduce(function (a, h) { return a + h; }, 0) + g2 * (rows2.length - 1))) / 2);
      rows2.forEach(function (r, i) { drawRow(cv, r, bx, y, bw, k2, theme, rows2.slice(0, i).reduce(function (a, q) { return a + q.length; }, 0)); y += hs2[i] + g2; });
      if (k2 < 0.8) warn.push('the content is dense \u2014 sizes shrunk to ' + pyRound(k2 * 100) + ' %; ' + (fmt === 'onepager' ? 'a shorter section or one fewer gives larger text' : 'the one-pager gives it more room'));
    }
    if (blocks.length) spec.blocks = spec.blocks.filter(function (b) { return blocks.some(function (x) { return C.deepEq(x, b); }); });
    var bg = fmt === 'slide' ? 'FFF3ED' : 'F8F5F5';   // a slide: the template's own content background (info.py layout)
    spec.blocks.forEach(function (b) { delete b._ic; delete b._tpl; delete b._im; });
    readableIcons(cv.els, bg); readableText(cv.els, bg); C.state.minFs = 0; S.look = 'light';
    return {spec: spec, w: W, h: H, bg: bg, els: cv.els, warnings: warn};
  }
  function fits1(spec) {
    var d = layout1(Object.assign({}, spec, {_page: 1}));
    return !d.warnings.some(function (w) { return w.indexOf('left out') >= 0 || w.indexOf('dense') >= 0 || w.indexOf('under the title') >= 0; });
  }
  function paginate(spec, maxPages) {
    maxPages = maxPages || 6;
    var queue = spec.blocks.map(function (b) { return Object.assign({}, b); }), pages = [];
    while (queue.length && pages.length < maxPages) {
      var page = [];
      while (queue.length) {
        if (fits1(Object.assign({}, spec, {blocks: page.concat([queue[0]])}, pages.length ? {subtitle: ''} : {}))) { page.push(queue.shift()); continue; }
        if (page.length) break;
        var b = queue[0], its = b.items || [];
        if (SPLIT.has(b.type) && its.length > 1) {
          var h = Math.floor((its.length + 1) / 2), jj = Array.isArray(b._j) ? b._j : its.map(function (_, q) { return q; });
          queue.splice(0, 1, Object.assign({}, b, {items: its.slice(0, h), _j: jj.slice(0, h)}), Object.assign({}, b, {items: its.slice(h), _j: jj.slice(h), title: b.title ? b.title + ' (cont.)' : ''}));
          continue;
        }
        page.push(queue.shift()); break;
      }
      pages.push(page);
    }
    if (queue.length) pages[pages.length - 1] = pages[pages.length - 1].concat(queue);
    return pages;
  }
  function layout(spec) {
    if (isObj(spec) && (spec._page === undefined || spec._page === null)) {
      var n_ = normalise(spec);
      if (['', 'free', undefined, null].indexOf(n_.template) < 0 && n_.format === 'slide' && n_.blocks.length >= 2 && !fits1(n_)) {
        S.squeeze = true; var d1;
        try { d1 = layout1(Object.assign({}, n_, {_page: 1})); } finally { S.squeeze = false; }
        if (!d1.warnings.some(function (w) { return w.indexOf('left out') >= 0; })) return d1;
        var pages = paginate(n_);
        if (pages.length > 1 && pages[pages.length - 1].length === 1 && pages[pages.length - 1][0].type === 'takeaway' && !n_.subtitle &&
            fits1(Object.assign({}, n_, {blocks: pages[0], subtitle: pages[pages.length - 1][0].text}))) {
          var last = pages.pop()[0]; n_ = Object.assign({}, n_, {subtitle: last.text}); if (typeof last._i === 'number') n_._sp = 'blocks.' + last._i + '.text';
        }
        if (pages.length === 1) { var one = layout1(Object.assign({}, n_, {blocks: pages[0], _page: 1})); one.spec = n_; return one; }
        if (pages.length > 1) {
          var ds = pages.map(function (pg, i) { return layout1(Object.assign({}, n_, {blocks: pg, _page: i + 1}, i === 0 ? {} : {title: n_.title + ' (cont.)', subtitle: ''})); });
          var first = ds[0]; first.spec = n_; first.pages = ds.slice(1); first.warnings = [].concat.apply([], ds.map(function (x) { return x.warnings; })); return first;
        }
      }
    }
    return layout1(spec);
  }
  // the layout of an edited content: the design, its pages, the spec as Python returns it (engine keys removed)
  function design(spec) {
    C.state.cuts = []; C.state.minFs = 0; S.squeeze = false;
    var d = layout(C.copy(spec));
    d.spec = strip(d.spec);
    (d.pages || []).forEach(function (p) { p.spec = strip(p.spec); });
    d.cuts = C.state.cuts.slice();
    return d;
  }

  // ------------------------------------------------------------------------------------------------ icon contrast
  function inPoly(pts, px, py) {   // ray casting: inside the polygon (a funnel band, a chevron, a hexagon)?
    var inside = false, n = pts.length;
    for (var a = 0; a < n; a++) {
      var p1 = pts[a], p2 = pts[(a + 1) % n];
      if ((p1[1] > py) !== (p2[1] > py) && px < p1[0] + (py - p1[1]) * (p2[0] - p1[0]) / (p2[1] - p1[1])) inside = !inside;
    }
    return inside;
  }
  function box(e) {   // [x0, y0, x1, y1] of a rect, ellipse or polygon (info.py _box)
    if (e.k !== 'poly') return [e.x, e.y, e.x + e.w, e.y + e.h];
    var xs = e.pts.map(function (q) { return q[0]; }), ys = e.pts.map(function (q) { return q[1]; });
    return [Math.min.apply(null, xs), Math.min.apply(null, ys), Math.max.apply(null, xs), Math.max.apply(null, ys)];
  }
  function under(els, i, px, py, bg) { return underAt(els, i, px, py, bg)[0]; }
  function underAt(els, i, px, py, bg, m) {   // [colour, index of the shape] a point of element i sits on: the topmost filled shape, blended when see-through;
    m = m || function (c) { return c; };       // m: the brand pass's fill mapping - each fill and stop is recoloured, then blended (info.py _under_at)
    for (var q = i - 1; q >= 0; q--) {
      var e = els[q];
      if ((e.k !== 'rect' && e.k !== 'ellipse' && e.k !== 'poly') || !(e.fill || e.grad)) continue;
      var inside;
      if (e.k === 'poly') inside = inPoly(e.pts, px, py);
      else if (e.k === 'rect') inside = e.x <= px && px <= e.x + e.w && e.y <= py && py <= e.y + e.h;
      else inside = e.w > 0 && e.h > 0 && Math.pow((px - e.x - e.w / 2) / (e.w / 2), 2) + Math.pow((py - e.y - e.h / 2) / (e.h / 2), 2) <= 1;
      if (!inside) continue;
      var bx = box(e), f = e.grad ? C.mix(m(e.grad[0]), m(e.grad[1]), bx[2] > bx[0] ? Math.max(0.0, Math.min(1.0, (px - bx[0]) / (bx[2] - bx[0]))) : 0.5) : m(e.fill), a = e.alpha;
      return [(a !== undefined && a !== null && a !== 1) ? C.mix(underAt(els, q, px, py, bg, m)[0], f, a) : f, q];
    }
    return [m(bg), null];
  }
  function readableColor(color, und) {
    color = C.pyStr(color).toUpperCase();
    if (C.contrast(color, und) >= (color === 'FFFFFF' ? 2.5 : 3.0)) return color;
    if (C.contrast('FFFFFF', und) < C.contrast(INK, und)) {
      var base = (C.lum(color) || 0) > 0.6 ? TITLE : color, ks = [0.0, 0.2, 0.3, 0.4, 0.55];
      for (var i = 0; i < ks.length; i++) { var s = ks[i] ? shade(base, ks[i]) : base; if (C.contrast(s, und) >= 3.0) return s; }
      return INK;
    }
    return C.contrast('FFFFFF', und) >= 3.0 || C.contrast('FFFFFF', und) >= C.contrast(INK, und) ? 'FFFFFF' : INK;
  }
  // every text readable on what it sits on (WCAG AA: 4.5:1, large text 3:1), judged in the colours the brand pass gives the page -
  // as tools/ulta_conform.py gives the files (info.py readable_text, the same rules in the same order)
  var TEMPLATE_PALETTE = ['000000', '404040', '505152', '5D0F43', '8A8C8F', 'C10060', 'D01381', 'D9D9D9', 'DB0058', 'DE7445', 'E0531B', 'E4C8DB',
    'E8275A', 'E9341C', 'EA0B59', 'EE6C37', 'F14C24', 'F16A1C', 'F24C26', 'F26923', 'F2F2F2', 'F3EDEB', 'F8F5F5', 'F9E3DE',
    'FAD3DB', 'FDE1D2', 'FF7826', 'FF893F', 'FFE8EE', 'FFF2F6', 'FFF3ED', 'FFF5F3', 'FFFFFF'];
  var STATUS_COLOURS = ['00B050', '0BA03E', 'FFC000', 'FF0000'], DOTS = ['●', '■', '▲', '▼', '◆', '•', '→'];   // marks, not words (info.py DOTS)
  var BRANDMAP = new C.Conform({allowed: TEMPLATE_PALETTE, keep: TEMPLATE_PALETTE.concat(STATUS_COLOURS), status: STATUS_COLOURS});
  var DEEP_TEXT = {pink: ['C10060', 'DB0058', 'D01381'], orange: [], neutral: ['404040']};
  function family(h) {
    var c = [0, 2, 4].map(function (k) { return parseInt(h.substr(k, 2), 16); }), mx = Math.max(c[0], c[1], c[2]), mn = Math.min(c[0], c[1], c[2]);
    return mx - mn < 25 ? 'neutral' : (c[2] > c[1] + 10 ? 'pink' : 'orange');
  }
  function textNeed(e) { var pt = (e.fs || 0) * 0.6; return pt >= 18 || (e.font === 'bold' && pt >= 14) ? 3.0 : 4.5; }   // large: 18 pt, or 14 pt bold (info.py text_need)
  function textPoint(e) {
    var ln = (e.lines || [''])[0], tw = Math.min(e.w, textW(ln, e.fs, e.font || 'body'));
    return [e.x + (e.align === 'right' ? e.w - tw / 2 : e.align === 'center' ? e.w / 2 : tw / 2), e.y + e.fs * (e.lh || 1.22) / 2];
  }
  function textEnds(e) {   // where the words of a text's first line start and end
    var ln = (e.lines || [''])[0], tw = Math.min(e.w, textW(ln, e.fs, e.font || 'body'));
    var x0 = e.x + (e.align === 'right' ? e.w - tw : e.align === 'center' ? (e.w - tw) / 2 : 0), y = e.y + e.fs * (e.lh || 1.22) / 2;
    return [[x0, y], [x0 + tw, y]];
  }
  function grounds(els, i, e, bg, m) {   // [[colours], shape] under a text: its line's middle - and on a gradient both ends of the line (info.py _grounds)
    var pt = textPoint(e), ua = underAt(els, i, pt[0], pt[1], bg, m);
    if (ua[1] === null || !els[ua[1]].grad) return [[ua[0]], ua[1]];
    return [[ua[0]].concat(textEnds(e).map(function (p) { return underAt(els, i, p[0], p[1], bg, m)[0]; })), ua[1]];
  }
  function apca(t, b) {   // how well words in t read on b to the eye (APCA 0.0.98G): positive for words darker than their ground (info.py _apca)
    var y = function (h) { var c = [0, 2, 4].map(function (i) { return parseInt(h.substr(i, 2), 16) / 255; }), v = 0.2126729 * Math.pow(c[0], 2.4) + 0.7151522 * Math.pow(c[1], 2.4) + 0.0721750 * Math.pow(c[2], 2.4); return v < 0.022 ? v + Math.pow(0.022 - v, 1.414) : v; };
    var yt = y(t), yb = y(b), s;
    if (Math.abs(yb - yt) < 0.0005) return 0.0;
    if (yb > yt) { s = (Math.pow(yb, 0.56) - Math.pow(yt, 0.57)) * 1.14; return s < 0.1 ? 0.0 : (s - 0.027) * 100; }
    s = (Math.pow(yb, 0.65) - Math.pow(yt, 0.62)) * 1.14; return s > -0.1 ? 0.0 : (s + 0.027) * 100;
  }
  function lightBetter(c) { return Math.abs(apca('FFFFFF', c)) > Math.abs(apca(INK, c)); }   // light words read better on c (info.py _light_better)
  function readableOn(color, gs, need) {   // readableTextColor over every ground of a line, else white or ink (info.py _readable_on)
    if (gs.some(function (u) { return apca(color, u) > 0; }) && gs.every(function (u) { return lightBetter(u) && C.contrast('FFFFFF', u) >= need; })) return 'FFFFFF';   // light words on a dark ground
    if (gs.length === 1) return readableTextColor(color, gs[0], need);
    var nw = readableTextColor(color, gs.reduce(function (a, u) { return C.contrast(color, u) < C.contrast(color, a) ? u : a; }), need);
    if (gs.every(function (u) { return C.contrast(nw, u) >= need; })) return nw;
    var low = function (c) { return Math.min.apply(null, gs.map(function (u) { return C.contrast(c, u); })); };
    return low(INK) > low('FFFFFF') ? INK : 'FFFFFF';
  }
  function readableTextColor(color, und, need) {
    var status = STATUS_COLOURS.indexOf(color) >= 0;
    if (!status && C.contrast(color, und) >= need) return color;
    var cw = C.contrast('FFFFFF', und), ci = C.contrast(INK, und);
    if (cw >= need && cw >= ci) return 'FFFFFF';
    if (cw < ci) {
      var fam = family(color), cands = (status ? [] : (DEEP_TEXT[fam] || []).concat(fam === 'pink' ? ['5D0F43'] : [])).concat([INK]);   // an orange turns black, never plum
      for (var q = 0; q < cands.length; q++) if (C.contrast(cands[q], und) >= need) return cands[q];
      return INK;
    }
    return 'FFFFFF';
  }
  function fillMap(c) { return BRANDMAP.map(c); }
  function readableText(els, bg) {
    var on = {}, dark = [];
    els.forEach(function (e, i) {
      if (e.k !== 'text' || !e.color || !(e.lines || []).join('').trim()) return;
      var col = C.pyStr(e.color).toUpperCase();
      if (e.font === 'display' && col === TITLE) return;
      if (DOTS.indexOf((e.lines || []).join('').trim()) >= 0) return;   // a status dot is a mark, not words
      var gr = grounds(els, i, e, bg, fillMap), gs = gr[0], q = gr[1], need = textNeed(e);
      var cur = STATUS_COLOURS.indexOf(col) >= 0 ? col : BRANDMAP.text(col), nw = readableOn(cur, gs, need);
      if (e.dark && nw === 'FFFFFF' && gs.every(function (u) { return C.contrast(cur, u) >= need; })) nw = cur;   // v139: the light lead's one dark voice
      if (q !== null) (on[q] = on[q] || []).push([i, gs, need]);
      if (nw !== cur) { e.color = nw; if (nw === INK && cur === 'FFFFFF' && q !== null && dark.indexOf(q) < 0) dark.push(q); }
    });
    dark.sort(function (a, b) { return a - b; }).forEach(function (q) {   // one voice per card: its other white words turn dark too
      (on[q] || []).forEach(function (m) { var e = els[m[0]]; if (C.pyStr(e.color).toUpperCase() === 'FFFFFF' && m[1].every(function (u) { return C.contrast(INK, u) >= m[2]; })) e.color = INK; });
    });
    els.forEach(function (e, i) {
      if (e.k === 'icon' && C.pyStr(e.color || '').toUpperCase() === 'FFFFFF') {
        var ua = underAt(els, i, e.x + e.s / 2, e.y + e.s / 2, bg);
        if (ua[1] !== null && dark.indexOf(ua[1]) >= 0) e.color = INK;
      }
    });
  }
  function readableIcons(els, bg) {
    els.forEach(function (e, i) {
      if (e.k !== 'icon' || !e.color) return;
      var nw = readableColor(e.color, under(els, i, e.x + e.s / 2, e.y + e.s / 2, bg));
      if (nw !== e.color) e.color = nw;
    });
  }

  // ------------------------------------------------------------------------------------------------ SVG
  function toSvg(d, opt) {
    opt = opt || {};
    var chrome = opt.chrome !== false, W = d.w, H = d.h, defs = [], out = [], gid = {}, pre = opt.idPrefix || 'g', esc = C.esc, f1 = function (v) { return C.pyFix(v, 1); };
    var imgs = (d.spec && d.spec.images) || {}, clips = 0;
    var grad = function (a, b) { var key = a + b; if (!has(gid, key)) { gid[key] = pre + Object.keys(gid).length; defs.push('<linearGradient id="' + gid[key] + '" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#' + a + '"/><stop offset="1" stop-color="#' + b + '"/></linearGradient>'); } return 'url(#' + gid[key] + ')'; };
    if (chrome) out.push('<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="#' + d.bg + '"/>');
    d.els.forEach(function (e, idx) {
      if (e.chrome && !chrome) return;
      var k = e.k, stroke;
      if (k === 'rect') {
        if (e.w <= 0 || e.h <= 0) return;
        stroke = e.stroke ? ' stroke="#' + e.stroke + '" stroke-width="' + (e.sw === undefined ? 1 : e.sw) + '"' : '';
        var r = Math.min(e.r || 0, e.w / 2, e.h / 2), fill = e.grad ? grad(e.grad[0], e.grad[1]) : (e.fill ? '#' + e.fill : 'none');
        out.push('<rect x="' + e.x + '" y="' + e.y + '" width="' + e.w + '" height="' + e.h + '" rx="' + r + '" fill="' + fill + '"' + stroke + '/>');
      } else if (k === 'ellipse') {
        stroke = e.stroke ? ' stroke="#' + e.stroke + '" stroke-width="' + (e.sw === undefined ? 1 : e.sw) + '"' : '';
        var op = e.alpha ? ' fill-opacity="' + e.alpha + '"' : '';
        out.push('<ellipse cx="' + (e.x + e.w / 2) + '" cy="' + (e.y + e.h / 2) + '" rx="' + (e.w / 2) + '" ry="' + (e.h / 2) + '" fill="' + (e.grad ? grad(e.grad[0], e.grad[1]) : e.fill ? '#' + e.fill : 'none') + '"' + stroke + op + '/>');
      } else if (k === 'line') {
        [['arrow', e.x1, e.y1, e.x2, e.y2], ['arrow_start', e.x2, e.y2, e.x1, e.y1]].forEach(function (A) {
          if (!e[A[0]]) return;   // an arrowhead drawn as a small triangle (renderers without marker support draw it too)
          var ax = A[1], ay = A[2], bx = A[3], by = A[4], L = Math.hypot(bx - ax, by - ay) || 1, ux = (bx - ax) / L, uy = (by - ay) / L, al = 5.5 * e.sw + 4, aw = 2.4 * e.sw + 3;
          out.push('<path d="M' + f1(bx) + ',' + f1(by) + ' L' + f1(bx - ux * al + uy * aw) + ',' + f1(by - uy * al - ux * aw) + ' L' + f1(bx - ux * al - uy * aw) + ',' + f1(by - uy * al + ux * aw) + ' Z" fill="#' + e.color + '"/>');
        });
        out.push('<line x1="' + e.x1 + '" y1="' + e.y1 + '" x2="' + e.x2 + '" y2="' + e.y2 + '" stroke="#' + e.color + '" stroke-width="' + e.sw + '" stroke-linecap="round"' + (e.dash ? ' stroke-dasharray="6 6"' : '') + '/>');
      } else if (k === 'poly') {   // a closed shape from points
        stroke = e.stroke ? ' stroke="#' + e.stroke + '" stroke-width="' + (e.sw === undefined ? 1 : e.sw) + '"' : '';
        out.push('<path d="M' + e.pts.map(function (q) { return f1(q[0]) + ',' + f1(q[1]); }).join(' L') + ' Z" fill="' + (e.grad ? grad(e.grad[0], e.grad[1]) : '#' + e.fill) + '"' + stroke + '/>');
      } else if (k === 'arc') {
        var L = 2 * Math.PI * e.r * e.frac;
        out.push('<circle cx="' + e.cx + '" cy="' + e.cy + '" r="' + e.r + '" fill="none" stroke="#' + e.track + '" stroke-width="' + e.sw + '"/>');
        if (e.frac >= 0.999) out.push('<circle cx="' + e.cx + '" cy="' + e.cy + '" r="' + e.r + '" fill="none" stroke="#' + e.color + '" stroke-width="' + e.sw + '"/>');
        else if (L > 0.5) {
          var a = -Math.PI / 2 + 2 * Math.PI * e.frac, x2 = e.cx + e.r * Math.cos(a), y2 = e.cy + e.r * Math.sin(a);
          out.push('<path d="M' + C.pyFix(e.cx, 2) + ',' + C.pyFix(e.cy - e.r, 2) + ' A' + e.r + ',' + e.r + ' 0 ' + (e.frac > 0.5 ? 1 : 0) + ' 1 ' + C.pyFix(x2, 2) + ',' + C.pyFix(y2, 2) + '" fill="none" stroke="#' + e.color + '" stroke-width="' + e.sw + '" stroke-linecap="round"/>');
        }
      } else if (k === 'icon') {
        var m = C.iconMarkup(e.name, e.color, e.bold);
        if (m) out.push('<g transform="' + C.place(m[0], e.x, e.y, e.s, e.s) + '">' + m[1] + '</g>');
      } else if (k === 'logo') {
        var lg = C.logo(); if (lg) out.push('<g transform="' + C.place(lg[0], e.x, e.y, e.w, e.h) + '">' + lg[1] + '</g>');
      } else if (k === 'image') {
        var rec = has(imgs, e.ref) ? imgs[e.ref] : null;
        if (!rec || e.w <= 0 || e.h <= 0) return;
        var rr = Math.min(e.r || 0, e.w / 2, e.h / 2), clip = '';
        if (rr) {
          var cid = 'c' + pre.slice(1) + (clips++);
          defs.push('<clipPath id="' + cid + '"><rect x="' + e.x + '" y="' + e.y + '" width="' + e.w + '" height="' + e.h + '" rx="' + rr + '"/></clipPath>'); clip = ' clip-path="url(#' + cid + ')"';
        }
        out.push('<image data-img="' + e.ref + '" x="' + e.x + '" y="' + e.y + '" width="' + e.w + '" height="' + e.h + '" preserveAspectRatio="xMidYMid slice"' + clip + ' href="data:' + rec.mime +
          ';base64,' + rec.data + '" role="img" aria-label="' + esc(e.alt || 'Picture') + '"/>');
      } else if (k === 'text') {
        var fam = e.font === 'display' ? DISPLAY : BODY, fw = e.font === 'display' ? 900 : (e.font === 'bold' ? 700 : 400);
        var anchor = {left: 'start', center: 'middle', right: 'end'}[e.align || 'left'], tx = e.x + (anchor === 'middle' ? e.w / 2 : anchor === 'end' ? e.w : 0);
        var sp = e.spacing ? ' letter-spacing="' + e.spacing + '"' : '';
        e.lines.forEach(function (ln, i) {
          var ty = e.y + e.fs * (0.86 + i * e.lh) + (e.lh - 1) * e.fs / 2;
          out.push('<text data-i="' + idx + '" x="' + f1(tx) + '" y="' + f1(ty) + '" font-family="' + esc(fam) + '" font-size="' + e.fs + '" font-weight="' + fw + '" fill="#' + e.color + '" text-anchor="' + anchor + '"' + sp + '>' + esc(ln) + '</text>');
        });
      }
    });
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H + '">' + (defs.length ? '<defs>' + defs.join('') + '</defs>' : '') + out.join('') + '</svg>';
  }
  function pageSvgs(d, opt) {
    opt = opt || {};
    return [d].concat(d.pages || []).map(function (p, i) { return toSvg(p, Object.assign({}, opt, {idPrefix: (opt.idPrefix || 'g') + (i ? i + '_' : '')})); });
  }

  return {FORMATS: FORMATS, BLOCKS: BLOCKS, THEME_ORDER: THEME_ORDER, PALETTE: PALETTE, LOOKS: LOOKS, RAG: RAG, style: style, normalise: normalise, strip: strip,
    layout: layout, design: design, toSvg: toSvg, pageSvgs: pageSvgs, ragOf: ragOf, num: num, resolveTheme: resolveTheme};
});
