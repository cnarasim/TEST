/* The UI screens layout (tools/ui_screens.py) in the page, so the screens relay themselves out after an edit with no chat and
   no server. A line-for-line port: same normalising (plain punctuation, limits, problems), components, sizes and SVG (drawn by
   UltaInfo.toSvg, as Python draws them with info.to_svg); tests/parity compares it with the Python layout on hundreds of specs.
   Each drawn text carries `p`, the field of the spec it shows ("screens.0.sections.2.items.1.label"), relative to the spec object
   passed to design(): the page holds the normalised spec (design().spec) and passes that, so a click edits exactly that field.
   Texts made up by the layout (initials, step numbers, "Step 2 of 3", a phone table row's joined detail, the default "Yes"
   option, the required mark) carry none. Needs UltaCore (engine-core.js) and UltaInfo (info-engine.js). Never contains a closing
   script tag. */
(function (root, factory) {
  var node = typeof module === 'object' && module.exports;
  var core = node ? require('./engine-core.js') : root.UltaCore;
  var info = node ? require('./info-engine.js') : root.UltaInfo;
  var m = factory(core, info);
  if (node) module.exports = m; else root.UltaScreens = m;
})(this, function (C, I) {
  'use strict';
  var pyRound = C.pyRound, textW = C.textW, wrap = C.wrap, isObj = C.isObj, truthy = C.truthy, pyStr = C.pyStr, pyStrip = C.pyStrip, cps = C.cps;
  var DEV = {desktop: {W: 1440, H: 900, head: 64, nav: 232, pad: 32, gap: 20, title: 26, zoom: 1.0, cols: 2, card: 24},
    tablet: {W: 1024, H: 768, head: 60, nav: 200, pad: 24, gap: 18, title: 24, zoom: 1.25, cols: 2, card: 20},
    mobile: {W: 390, H: 844, head: 56, nav: 0, pad: 16, gap: 16, title: 22, zoom: 2.0, cols: 1, card: 16}};
  var DEVICES = ['desktop', 'tablet', 'mobile'];
  var BG = 'F8F5F5', CARD = 'FFFFFF', EDGE = 'F2F2F2', FIELD = 'D9D9D9', INK = '000000', MUTED = '404040';
  var ACC = 'F26923', DEEP = 'DB0058', TINT = 'FFF5F3', TINT2 = 'FDE1D2', PINK = 'FFE8EE';
  var STATUS = {green: '0BA03E', amber: 'FFC000', red: 'FF0000'};
  var WORDS = [['red', /\b(rejected|out of stock|no stock|error|failed|overdue|blocked|cancel+ed|late|off track|declined|expired|missing)\b/],
    ['amber', /\b(pending|in transit|low|partial|in review|review|waiting|draft|scheduled|on hold|at risk|processing|requested|due)\b/],
    ['green', /\b(available|approved|complete|completed|done|active|in stock|received|delivered|on track|open|paid|ready|success|confirmed|shipped|sent|yes|passed)\b/]];
  var NAV_ICONS = [[/home|dashboard|overview|start/, 'home'], [/inventor|stock|item|product|article|sku|assort/, 'cube'],
    [/transfer|ship|deliver|transport|logistic|freight/, 'delivery'], [/receiv|inbound|asn|package|parcel|return/, 'package'],
    [/order|purchase|invoice|bill|requisition/, 'receipt'], [/custom|client|member|loyal|vendor|supplier|partner/, 'person'],
    [/report|analytic|insight|kpi|metric|performance/, 'bars'], [/setting|admin|config|preference/, 'sliders'],
    [/store|location|site|branch|region/, 'pin'], [/message|mail|inbox|notification/, 'email'],
    [/task|approv|review|check|audit/, 'check'], [/promo|pric|tag|offer|deal|coupon|markdown/, 'tag'],
    [/calendar|schedule|plan|appointment|shift/, 'calendar'], [/scan|barcode|upc|label/, 'barcode'],
    [/search|find|lookup/, 'search'], [/user|team|people|staff|employee|associate/, 'user'],
    [/bag|cart|basket|sales/, 'bag'], [/payment|wallet|refund|money|finance/, 'wallet'], [/help|support|faq/, 'info']];
  var KINDS = ['text', 'select', 'date', 'number', 'search', 'textarea', 'checkbox', 'radio', 'toggle', 'readonly'];
  var COMPONENTS = [
    ['search', 'a search box and filter chips', '{"type": "search", "placeholder": "Search item, UPC or description", "value": "", "filters": ["In stock", "Within 10 miles"], "active": [0]}'],
    ['form', 'fields in 1-3 columns; kind: ' + KINDS.join(', '), '{"type": "form", "title": "Transfer details", "columns": 2, "fields": [{"label": "Quantity", "value": "6", "kind": "number", "required": true, "help": "Up to 24 on hand"}, {"label": "Reason", "value": "Special order", "kind": "select"}, {"label": "Notify the store", "kind": "checkbox", "checked": true}, {"label": "Ship by", "kind": "radio", "options": ["Van", "Courier"], "value": "Van"}]}'],
    ['table', 'rows and columns; a Status column shows coloured marks; select boxes and a row button are optional (up to 12 rows; a list on mobile)', '{"type": "table", "title": "Nearby stores", "columns": ["Store", "Distance", "On hand", "Status"], "rows": [["1042 Naperville", "3.2 mi", "24", "Available"]], "select": true, "selected": [0], "action": "View", "footer": "Showing 4 of 12 stores"}'],
    ['kpis', '2-4 number tiles', '{"type": "kpis", "items": [{"value": "24", "label": "Units on hand", "delta": "+6 vs last week"}]}'],
    ['tabs', 'a tab row (the first is open unless active says otherwise)', '{"type": "tabs", "items": ["Details", "Lines", "History"], "active": 0}'],
    ['alert', 'a message: info, success, warning or error', '{"type": "alert", "kind": "success", "title": "Request sent", "text": "Store 1042 has your request."}'],
    ['buttons', 'a row of buttons; style primary, secondary, accent (raspberry), danger or link', '{"type": "buttons", "items": [{"label": "Back"}, {"label": "Send request", "style": "primary"}], "align": "right"}'],
    ['summary', 'label and value pairs', '{"type": "summary", "title": "Transfer summary", "items": [["Units", "6"], ["Value", "$171.00"]], "columns": 2}'],
    ['list', 'rows with a title, detail, a value on the right and an optional status', '{"type": "list", "title": "What happens next", "items": [{"title": "Store 1042 picks the units", "text": "Today, before 5 pm", "meta": "Today", "status": "In review"}]}'],
    ['cards', 'a grid of small cards (title, text, meta, status, a button)', '{"type": "cards", "columns": 3, "items": [{"title": "1042 Naperville", "text": "24 on hand", "meta": "3.2 mi", "status": "Available", "action": "Choose"}]}'],
    ['bars', 'a small bar chart (values from the data)', '{"type": "bars", "title": "Transfers by week", "unit": "", "items": [{"label": "Week 40", "value": "18"}]}'],
    ['text', 'a paragraph', '{"type": "text", "title": "About transfers", "text": "Stores can move stock to each other within a district."}'],
    ['row', 'components side by side (widths are shares)', '{"type": "row", "widths": [2, 1], "columns": [[{"type": "form", "fields": []}], [{"type": "summary", "items": []}]]}']];
  var STYLES = ['primary', 'secondary', 'accent', 'danger', 'link'];

  function has(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }
  function total(xs) { var t = 0; for (var i = 0; i < xs.length; i++) t += xs[i]; return t; }   // info._total: left to right, as Python adds them
  function statusOf(word) { var s = pyStr(C.or(word)).toLowerCase(), hit = WORDS.find(function (q) { return q[1].test(s); }); return hit ? hit[0] : ''; }
  function navIcon(label) { var s = pyStr(C.or(label)).toLowerCase(), hit = NAV_ICONS.find(function (q) { return q[0].test(s); }); return hit ? hit[1] : 'dot'; }

  // ------------------------------------------------------------------------------------------------ plain punctuation (tools/plain.py)
  var EM = '\u2014', EN = '\u2013';
  var PATH_KEYS = new Set(['image', 'images', 'path', 'file', 'files', 'src', 'out', 'logo', 'icon', 'picture', 'screenshot', 'href', 'url', 'template', 'font', 'fonts']);
  function plainText(s) {
    if (!s || (s.indexOf(EM) < 0 && s.indexOf(' ' + EN + ' ') < 0 && s.indexOf('&#8212;') < 0 && s.toLowerCase().indexOf('&#x2014;') < 0 && s.indexOf('&mdash;') < 0)) return s;
    s = s.replace(/&#(?:8212|x2014|X2014);|&mdash;/g, EM).replace(/\u2014+>/g, function (m) { return new Array(m.length).join('-') + '>'; });
    if (!pyStrip(s.split(EM).join(''))) return '-';
    s = s.replace(/[ \t]*\u2014+(?![\u2014>])[ \t]*/g, ' - ').replace(/[ \t]+\u2013[ \t]+/g, ' - ');
    if (s.indexOf(' - ') === 0) s = '- ' + s.slice(3);
    if (s.length >= 3 && s.slice(-3) === ' - ') s = s.slice(0, -3) + ' -';
    return s;
  }
  function deep(o, key) {
    if (typeof o === 'string') return PATH_KEYS.has(key) ? o : plainText(o);
    if (Array.isArray(o)) return o.map(function (v) { return deep(v, key); });
    if (isObj(o)) { var r = {}; Object.keys(o).forEach(function (k) { r[k] = deep(o[k], k); }); return r; }
    return o;
  }

  // ------------------------------------------------------------------------------------------------ spec
  function _s(v) { return v === null || v === undefined ? '' : (Array.isArray(v) || isObj(v)) ? v : pyStrip(pyStr(v)); }
  function _int(v, d) {   // int(float(v)), the default on what float() refuses
    d = d === undefined ? 0 : d;
    if (v === null || v === undefined) return d;
    if (typeof v === 'boolean') return v ? 1 : 0;
    if (typeof v === 'number') { if (isNaN(v)) return d; if (!isFinite(v)) throw new Error('OverflowError: cannot convert float infinity to integer'); return Math.trunc(v) || 0; }
    if (typeof v !== 'string') return d;
    var s = pyStrip(v).replace(/(\d)_(?=\d)/g, '$1');
    if (/^[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?$/i.test(s)) { var x = Number(s); if (!isFinite(x)) throw new Error('OverflowError: cannot convert float infinity to integer'); return Math.trunc(x) || 0; }
    if (/^[+-]?inf(inity)?$/i.test(s)) throw new Error('OverflowError: cannot convert float infinity to integer');
    return d;
  }
  function seq(v) {   // what Python iterates in "for x in (v or [])"
    if (!truthy(v)) return [];
    if (Array.isArray(v)) return v;
    if (typeof v === 'string') return cps(v);
    if (isObj(v)) return Object.keys(v);
    throw new TypeError('object is not iterable');
  }
  function sl(v, n) {   // "(v or [])[:n]"
    if (!truthy(v)) return [];
    if (Array.isArray(v)) return v.slice(0, n);
    if (typeof v === 'string') return cps(v).slice(0, n);
    throw new TypeError('unhashable type: slice');
  }
  function digits(v) { return /^[0-9]+$/.test(pyStr(v)); }   // str(v).isdigit()
  function keep(list, ok) {   // [x for x in list if ok(x)] with where each kept one came from
    var out = [], at = [];
    list.forEach(function (x, i) { if (ok(x)) { out.push(x); at.push(i); } });
    return [out, at];
  }
  function button(b) {
    b = isObj(b) ? b : {label: b};
    var st = pyStr(C.or(b.style) || 'secondary').toLowerCase();
    return {label: _s(b.label) || 'Button', style: STYLES.indexOf(st) >= 0 ? st : 'secondary'};
  }
  function component(c, where, probs) {
    if (!isObj(c)) return null;
    var t = pyStr(C.or(c.type)).toLowerCase(), o = {type: t}, r;
    if (truthy(c.title)) o.title = _s(c.title);
    if (t === 'search') {
      o.placeholder = _s(c.placeholder) || 'Search'; o.value = _s(c.value);
      o.filters = seq(c.filters).map(_s).slice(0, 8);
      o.active = seq(c.active).filter(digits).map(function (i) { return _int(i); });
    } else if (t === 'form') {
      o.columns = truthy(c.columns) ? Math.max(1, Math.min(3, _int(c.columns, 1))) : 0;
      o.fields = [];
      sl(c.fields, 18).forEach(function (f) {
        f = isObj(f) ? f : {label: f};
        var kind = pyStr(C.or(f.kind) || 'text').toLowerCase();
        if (KINDS.indexOf(kind) < 0) { probs.push('note: ' + where + ": field kind '" + kind + "' drawn as a text box (" + KINDS.join(', ') + ')'); kind = 'text'; }
        o.fields.push({label: _s(f.label), value: _s(f.value), kind: kind, placeholder: _s(f.placeholder), required: truthy(f.required), help: _s(f.help),
          error: _s(f.error), checked: truthy(f.checked), options: seq(f.options).map(_s).slice(0, 5), wide: truthy(f.wide)});
      });
    } else if (t === 'table') {
      var cols = seq(c.columns).map(_s).slice(0, 7);
      var rows = seq(c.rows).map(function (rw) { return (Array.isArray(rw) ? rw : [rw]).map(_s).slice(0, cols.length || 7); });
      if (rows.length > 12) { probs.push('note: ' + where + ': ' + rows.length + ' rows - showing 12 (say how many there are in "footer")'); rows = rows.slice(0, 12); }
      if (!cols.length) { probs.push('FAIL ' + where + ': a table needs "columns"'); return null; }
      rows = rows.map(function (rw) { return rw.concat(new Array(Math.max(0, cols.length - rw.length)).fill('')); });
      var st = c.status, si;
      if (typeof st === 'string' && cols.indexOf(st) >= 0) si = cols.indexOf(st);
      else if ((typeof st === 'number' && Number.isInteger(st) || typeof st === 'boolean') && 0 <= +st && +st < cols.length) si = +st;
      else si = cols.findIndex(function (h) { return /status|state|stage/i.test(h); });
      o.columns = cols; o.rows = rows; o.status = si; o.select = truthy(c.select); o.action = _s(c.action);
      o.selected = seq(c.selected).filter(digits).map(function (i) { return _int(i); }); o.footer = _s(c.footer);
    } else if (t === 'kpis') {
      r = keep(seq(c.items), isObj);
      o.items = r[0].map(function (i) { return {value: _s(i.value), label: _s(i.label), delta: _s(i.delta), trend: _s(i.trend).toLowerCase()}; }).slice(0, 4); o._j = r[1].slice(0, 4);
    } else if (t === 'tabs') {
      o.items = seq(c.items).map(_s).slice(0, 7); o.active = _int(c.active);
    } else if (t === 'alert') {
      var k = pyStr(C.or(c.kind) || 'info').toLowerCase();
      o.kind = ['info', 'success', 'warning', 'error'].indexOf(k) >= 0 ? k : 'info'; o.text = _s(c.text);
    } else if (t === 'buttons') {
      o.items = seq(c.items).map(button).slice(0, 5); o.align = pyStr(C.or(c.align) || 'right').toLowerCase();
    } else if (t === 'summary') {
      r = keep(seq(c.items), function (p) { return Array.isArray(p) && p.length; });
      o.items = r[0].map(function (p) { return [_s(p[0]), p.length > 1 ? _s(p[1]) : '']; }).slice(0, 12); o._j = r[1].slice(0, 12);
      o.columns = Math.max(0, Math.min(3, _int(c.columns)));
    } else if (t === 'list') {
      r = keep(seq(c.items), isObj);
      o.items = r[0].map(function (i) { return {title: _s(i.title), text: _s(i.text), meta: _s(i.meta), status: _s(i.status)}; }).slice(0, 8); o._j = r[1].slice(0, 8);
    } else if (t === 'cards') {
      r = keep(seq(c.items), isObj);
      o.items = r[0].map(function (i) { return {title: _s(i.title), text: _s(i.text), meta: _s(i.meta), status: _s(i.status), action: _s(i.action)}; }).slice(0, 9); o._j = r[1].slice(0, 9);
      o.columns = Math.max(0, Math.min(4, _int(c.columns)));
    } else if (t === 'bars') {
      r = keep(seq(c.items), function (i) { return isObj(i) && /\d/.test(pyStr(C.or(i.value))); });
      o.items = r[0].map(function (i) { return {label: _s(i.label), value: _s(i.value)}; }).slice(0, 8); o._j = r[1].slice(0, 8); o.unit = _s(c.unit);
    } else if (t === 'text') {
      o.text = _s(c.text);
    } else if (t === 'row') {
      var cs = seq(c.columns).map(function (col) {
        return (Array.isArray(col) ? col : [col]).map(function (x, mi) { var y = component(x, where, probs); if (y) y._i = mi; return y; });
      }).slice(0, 3);
      o.columns = cs.map(function (col) { return col.filter(function (x) { return x; }); });
      o.widths = seq(c.widths).map(function (w) { return Math.max(0.0, _int(w, 1)); }).slice(0, 3);
    } else {
      probs.push('note: ' + where + ": '" + t + "' is not a component (" + COMPONENTS.map(function (x) { return x[0]; }).join(', ') + ') - left out');
      return null;
    }
    var empty = {form: 'fields', table: 'columns', kpis: 'items', tabs: 'items', buttons: 'items', summary: 'items', list: 'items', cards: 'items', bars: 'items', text: 'text'}[t];
    if ((empty && !truthy(o[empty])) || (t === 'row' && !o.columns.some(function (col) { return col.length; }))) {
      probs.push('note: ' + where + ': the ' + t + ' section has nothing to show' + (t === 'bars' ? ' (bar values need numbers)' : '') + ' - left out');
      return null;
    }
    return o;
  }
  function paths(o, p) {   // where each component sits in the spec: sections by place, components inside a row by column and place
    o._p = p;
    if (o.type === 'row') o.columns.forEach(function (col, ci) { col.forEach(function (x) { paths(x, p + '.columns.' + ci + '.' + x._i); }); });
  }
  function placeholders(spec, probs) {   // template sample words never go on a screen
    var seen = new Set();
    (function walk(v) {
      if (Array.isArray(v)) v.forEach(walk);
      else if (isObj(v)) Object.keys(v).forEach(function (k) { if (k[0] !== '_') walk(v[k]); });
      else if (typeof v === 'string' && v && !seen.has(v)) {
        seen.add(v);
        if (/lorem ipsum|dolor sit|text here|insert (text|headline)|\bxx+%|placeholder text/i.test(v)) probs.push("FAIL placeholder text '" + cps(v).slice(0, 40).join('') + "' - give the screen its real words");
      }
    })(spec);
  }
  function normalise(raw) {
    raw = deep(isObj(raw) ? raw : {});
    var probs = [], dev = pyStr(C.or(raw.device) || 'desktop').toLowerCase(), r;
    if (!has(DEV, dev)) { probs.push("note: device '" + dev + "' is not desktop, tablet or mobile - drawn as desktop"); dev = 'desktop'; }
    r = keep(seq(raw.nav).map(_s), truthy);
    var spec = {title: _s(raw.title) || 'UI screens', app: _s(raw.app) || 'Ulta Beauty', device: dev, user: _s(raw.user), nav: r[0].slice(0, 8), screens: []};
    spec._nav = r[1].slice(0, 8);
    var screens = truthy(raw.screens) ? raw.screens : [];
    if (!truthy(screens)) probs.push('FAIL no screens: give "screens": [{"title": ..., "sections": [...]}]');
    if (screens.length > 12) { probs.push('note: ' + screens.length + ' screens - drew the first 12; make the rest as a second set'); screens = screens.slice(0, 12); }
    seq(screens).forEach(function (sc, si) {
      var n = si + 1;
      sc = isObj(sc) ? sc : {};
      var bc = keep(seq(sc.breadcrumb).map(_s), truthy);
      var o = {name: _s(sc.name) || _s(sc.title) || 'Screen ' + n, title: _s(sc.title), subtitle: _s(sc.subtitle), nav: _s(sc.nav),
        breadcrumb: bc[0].slice(0, 5), actions: seq(sc.actions).map(button).slice(0, 4), sections: []};
      o._bc = bc[1].slice(0, 5);
      if (!truthy(o.title)) probs.push('FAIL screen ' + n + ': no title - every screen says what it is for');
      var st = sc.steps;
      if (isObj(st) && truthy(st.items)) {
        var its = seq(st.items);
        o.steps = {items: its.map(_s).slice(0, 6), current: Math.max(1, Math.min(_int(st.current, 1), Math.min(its.length, 6)))};
      }
      seq(sc.sections).forEach(function (c, k) {
        var c2 = component(c, 'screen ' + n + ', part ' + (k + 1), probs);
        if (c2) { paths(c2, 'screens.' + si + '.sections.' + k); o.sections.push(c2); }
      });
      spec.screens.push(o);
    });
    placeholders(spec, probs);
    return [spec, probs];
  }
  function strip(o) {   // the spec without the engine's own keys
    if (Array.isArray(o)) return o.map(strip);
    if (!isObj(o)) return o;
    var r = {}; Object.keys(o).forEach(function (k) { if (k[0] !== '_') r[k] = strip(o[k]); }); return r;
  }
  function cp(c, f) { return c && c._p ? c._p + '.' + f : null; }
  function jm(c, i) { return Array.isArray(c._j) ? c._j[i] : i; }

  // ------------------------------------------------------------------------------------------------ drawing
  var GLYPHS = ['home', 'bars', 'check', 'info', 'down', 'right', 'dot'];
  function Screen(spec, n, problems) {
    this.cv = new C.Canvas(); this.spec = spec; this.dev = spec.device; this.D = DEV[this.dev];
    this.mob = this.dev === 'mobile'; this.n = n; this.problems = problems; this.clicks = []; this.blocks = [];
  }
  var P = Screen.prototype;
  P.rect = function (x, y, w, h, fill, stroke, r, sw, name) {
    this.cv.rect(x, y, w, h, fill, stroke, r === undefined ? 0 : r, sw === undefined ? 1 : sw, undefined, name || 'box');
    return this.cv.els[this.cv.els.length - 1];
  };
  P.line = function (x1, y1, x2, y2, color, sw, name, dash) {
    this.cv.line(x1, y1, x2, y2, color === undefined ? EDGE : color, sw === undefined ? 1 : sw, !!dash, name || 'line');
    return this.cv.els[this.cv.els.length - 1];
  };
  P.dot = function (cx, cy, d, fill, stroke, sw, name) {
    this.cv.ellipse(cx - d / 2, cy - d / 2, d, d, fill, stroke, sw === undefined ? 1 : sw, name || 'dot');
    return this.cv.els[this.cv.els.length - 1];
  };
  // wrapped text from the top-left; returns its height. fitLines: at most that many lines - it shrinks a little first, and is
  // named as a problem when it still does not fit (never cut)
  P.text = function (x, y, w, s, fs, color, font, align, lh, name, fitLines, p) {
    color = color === undefined ? INK : color; font = font || 'body'; align = align || 'left'; lh = lh === undefined ? 1.3 : lh; name = name || 'text';
    s = pyStrip(s === null || s === undefined ? '' : pyStr(s));
    if (!s) return 0;
    var ls = wrap(s, w, fs, font);
    var over = function (f) { return ls.some(function (q) { return textW(q, f, font) > w + 0.5; }); };
    if (fitLines && (ls.length > fitLines || over(fs))) {
      var f = fs;
      while (f > Math.max(11.5, fs * 0.82) && (ls.length > fitLines || over(f))) { f = pyRound(f - 0.5, 1); ls = wrap(s, w, f, font); }
      if (ls.length > fitLines) this.problems.push('FAIL screen ' + this.n + ": '" + cps(s).slice(0, 48).join('') + "' is too long for its " + name + ' - shorten it');
      fs = f;
    }
    this.cv.text(x, y, w, ls, fs, color, font, align, lh, name, s, p ? {p: p} : undefined);
    return ls.length * fs * lh;
  };
  P.mid = function (x, y, w, h, s, fs, color, font, align, name, p) {   // one line, centred in a box of height h
    var lh = 1.25;
    return this.text(x, y + (h - fs * lh) / 2, w, s, fs, color === undefined ? INK : color, font || 'body', align || 'left', lh, name || 'label', 1, p);
  };
  P.click = function (kind, label, x, y, w, h) {
    this.clicks.push({kind: kind, label: pyStr(label), box: [pyRound(x, 1), pyRound(y, 1), pyRound(w, 1), pyRound(h, 1)]});
  };
  P.icon = function (name, x, y, s, color) {   // a kit icon, or one of the few drawn here (home, bars, check, info, chevrons, dot)
    color = color === undefined ? INK : color;
    if (GLYPHS.indexOf(name) < 0 && C.iconSvg(name)) { this.cv.icon(name, x, y, s, color); return; }
    var sw = Math.max(1.5, s / 12), self = this;
    var L = function (a, b, c, d) { self.line(x + a * s, y + b * s, x + c * s, y + d * s, color, sw, 'glyph'); };
    if (name === 'home') { L(.12, .48, .5, .14); L(.5, .14, .88, .48); L(.22, .4, .22, .86); L(.78, .4, .78, .86); L(.22, .86, .78, .86); L(.42, .86, .42, .62); L(.42, .62, .58, .62); L(.58, .62, .58, .86); }
    else if (name === 'bars') { [[.2, .62], [.42, .38], [.64, .18]].forEach(function (q) { self.rect(x + q[0] * s, y + q[1] * s, .16 * s, (.86 - q[1]) * s, color, null, 1.5, undefined, 'glyph'); }); L(.12, .9, .88, .9); }
    else if (name === 'check') { L(.18, .52, .4, .74); L(.4, .74, .82, .28); }
    else if (name === 'info') { this.dot(x + s / 2, y + s / 2, s * .84, null, color, sw, 'glyph'); L(.5, .44, .5, .72); this.dot(x + s / 2, y + s * .3, sw * 1.4, color, undefined, undefined, 'glyph'); }
    else if (name === 'down') { L(.25, .38, .5, .63); L(.5, .63, .75, .38); }
    else if (name === 'right') { L(.38, .25, .63, .5); L(.63, .5, .38, .75); }
    else this.dot(x + s / 2, y + s / 2, s * .32, color, undefined, undefined, 'glyph');
  };
  P.button = function (x, y, b, h, w, fs, p) {
    h = h === undefined ? 40 : h; fs = fs === undefined ? 14 : fs;
    var st = b.style, label = b.label, tw = textW(label, fs, 'bold');
    w = w || Math.max(88, tw + 40);
    if (st === 'link') {
      this.mid(x, y, w, h, label, fs, INK, 'bold', 'center', 'button text', p);
      this.line(x + (w - tw) / 2, y + h / 2 + fs * .7, x + (w + tw) / 2, y + h / 2 + fs * .7, ACC, 2, 'link line');
    } else {
      var k = {primary: [INK, null, CARD], accent: [DEEP, null, CARD], danger: [CARD, 'E9341C', INK]};
      k = has(k, st) ? k[st] : [CARD, FIELD, INK];
      this.rect(x, y, w, h, k[0], k[1], 8, st === 'danger' ? 1.5 : 1, st + ' button');
      this.mid(x + 12, y, w - 24, h, label, fs, k[2], 'bold', 'center', 'button text', p);
    }
    this.click('button', label, x, y, w, h);
    return w;
  };
  P.pill = function (x, y, word, fs, p) {   // a status: a coloured dot (the mark) and the word in black on light grey
    fs = fs === undefined ? 13 : fs;
    var k = statusOf(word), h = 26, tw = textW(word, fs, 'body'), w = tw + (k ? 34 : 20);
    this.rect(x, y, w, h, EDGE, null, 13, undefined, 'status pill');
    if (k) this.dot(x + 14, y + h / 2, 8, STATUS[k], undefined, undefined, 'status dot');
    this.mid(x + (k ? 24 : 10), y, tw + 4, h, word, fs, INK, 'body', undefined, 'status text', p);
    return w;
  };

  // -- the frame: header, menu, page head
  P.header = function (W, head) {
    var s = this.spec, pad = this.D.pad, x = pad;
    this.rect(0, 0, W, head, CARD, undefined, undefined, undefined, 'header'); this.line(0, head, W, head, EDGE, 1, 'header edge');
    if (this.mob) { this.icon('menu', x, (head - 22) / 2, 22, INK); this.click('menu', 'Menu', x - 6, (head - 34) / 2, 34, 34); x += 36; }
    var lh = this.mob ? 26 : 30;
    this.cv.els.push({k: 'logo', x: x, y: pyRound((head - lh) / 2, 1), w: pyRound(lh * 2.47, 1), h: lh, name: 'logo'});
    x += lh * 2.47 + 16;
    this.line(x, head * .3, x, head * .7, FIELD, 1, 'logo rule'); x += 16;
    var right = W - pad, user = s.user;
    if (user && !this.mob) {
      var uw = Math.min(textW(user, 14, 'body'), 240);
      this.text(right - uw, (head - 14 * 1.25) / 2, uw + 1, user, 14, INK, 'body', 'right', 1.25, 'user', 1, 'user');
      right -= uw + 12;
    }
    if (user || this.mob) {
      var ini = ((user || s.app).match(/[A-Za-z]+/g) || []).slice(0, 2).map(function (w) { return w[0]; }).join('').toUpperCase() || 'U', d = 34;
      this.dot(right - d / 2, head / 2, d, TINT2, undefined, undefined, 'avatar');
      this.mid(right - d, head / 2 - d / 2, d, d, ini, 13, INK, 'bold', 'center', 'avatar text');
      this.click('user menu', user || 'Account', right - d, head / 2 - d / 2, d, d); right -= d + 16;
    }
    this.mid(x, 0, Math.max(60, right - x - 8), head, s.app, this.mob ? 16 : 17, INK, 'bold', undefined, 'app name', 'app');
  };
  P.navP = function (i) { var m = this.spec._nav; return 'nav.' + (Array.isArray(m) ? m[i] : i); };
  P.sidenav = function (active, side, head) {
    var y = head + 16, self = this, a = pyStr(C.or(active)).toLowerCase();
    this.spec.nav.forEach(function (it, i) {
      var on = it.toLowerCase() === a, h = 44;
      if (on) { self.rect(12, y, side - 24, h, TINT, null, 8, undefined, 'nav active'); self.rect(12, y + 10, 4, h - 20, ACC, null, 2, undefined, 'nav marker'); }
      self.icon(navIcon(it), 28, y + 12, 20, on ? ACC : MUTED);
      self.mid(60, y, side - 76, h, it, 14, on ? INK : MUTED, on ? 'bold' : 'body', undefined, 'nav label', self.navP(i));
      self.click('menu item', it, 12, y, side - 24, h);
      y += h + 4;
    });
  };
  P.tabbar = function (active, W, H) {
    var items = this.spec.nav.slice(0, 5), h = 64, y = H - h, cw = W / items.length, self = this, a = pyStr(C.or(active)).toLowerCase();
    this.rect(0, y, W, h, CARD, undefined, undefined, undefined, 'tab bar'); this.line(0, y, W, y, EDGE, 1, 'tab bar edge');
    items.forEach(function (it, i) {
      var on = it.toLowerCase() === a, cx = i * cw;
      if (on) self.rect(cx + cw / 2 - 16, y, 32, 3, ACC, null, 1.5, undefined, 'tab marker');
      self.icon(navIcon(it), cx + cw / 2 - 11, y + 11, 22, on ? ACC : MUTED);
      self.mid(cx + 4, y + 36, cw - 8, 20, it, 11, on ? INK : MUTED, on ? 'bold' : 'body', 'center', 'nav label', self.navP(i));
      self.click('menu item', it, cx, y, cw, h);
    });
  };
  P.pageHead = function (sc, x, y, w, sp) {
    var D = this.D, self = this;
    if (truthy(sc.breadcrumb) && !this.mob) {
      var cx = x, bc = sc.breadcrumb;
      bc.forEach(function (b, i) {
        var last = i === bc.length - 1, f = last ? 'bold' : 'body', tw = textW(b, 13, f);
        self.text(cx, y, tw + 2, b, 13, last ? INK : MUTED, f, undefined, 1.3, 'breadcrumb', undefined, sp + '.breadcrumb.' + (Array.isArray(sc._bc) ? sc._bc[i] : i));
        if (!last) { self.click('link', b, cx, y - 2, tw, 20); cx += tw + 6; self.icon('right', cx, y + 2, 13, MUTED); cx += 19; }
        else cx += tw;
      });
      y += 30;
    }
    var acts = sc.actions || [];
    var aw = this.mob ? 0 : total(acts.map(function (b) { return Math.max(88, textW(b.label, 14, 'bold') + 40); })) + 12 * Math.max(0, acts.length - 1);
    var tw_ = w - aw - (aw ? 24 : 0);
    var th = this.text(x, y, tw_, sc.title, D.title, INK, 'bold', undefined, 1.2, 'screen title', 2, sp + '.title');
    if (acts.length && !this.mob) {
      var bx = x + w - aw;
      acts.forEach(function (b, i) { bx += self.button(bx, y + Math.max(0, (D.title * 1.2 - 40) / 2), b, undefined, undefined, undefined, sp + '.actions.' + i + '.label') + 12; });
    }
    y += Math.max(th, acts.length && !this.mob ? 40 : 0);
    if (sc.subtitle) y += 6 + this.text(x, y + 6, tw_, sc.subtitle, 14, MUTED, 'body', undefined, 1.4, 'screen subtitle', undefined, sp + '.subtitle');
    y += 22;
    if (sc.steps) y += this.stepper(sc.steps, x, y, w, sp + '.steps.items.') + 22;
    return y;
  };
  P.stepper = function (st, x, y, w, ip) {
    var items = st.items, cur = st.current, self = this;
    if (this.mob) {
      this.text(x, y, w, 'Step ' + cur + ' of ' + items.length, 13, MUTED, 'body', undefined, 1.3, 'step count');
      this.text(x, y + 18, w, items[cur - 1], 15, INK, 'bold', undefined, 1.3, 'step label', undefined, ip + (cur - 1));
      this.rect(x, y + 44, w, 6, EDGE, null, 3, undefined, 'step track'); this.rect(x, y + 44, w * cur / items.length, 6, ACC, null, 3, undefined, 'step progress');
      return 50;
    }
    var n = items.length, seg = w / n, d = 28;
    items.forEach(function (it, k) {
      var i = k + 1, cx = x + (i - 1) * seg;
      if (i < n) self.line(cx + d + 8 + Math.min(textW(it, 14, 'bold'), seg - d - 60) + 12, y + d / 2, cx + seg - 12, y + d / 2, i < cur ? ACC : FIELD, 2, 'step line');
      if (i < cur) { self.dot(cx + d / 2, y + d / 2, d, ACC, undefined, undefined, 'step done'); self.icon('check', cx + 5, y + 5, d - 10, CARD); }
      else if (i === cur) { self.dot(cx + d / 2, y + d / 2, d, DEEP, undefined, undefined, 'step current'); self.mid(cx, y, d, d, String(i), 13, CARD, 'bold', 'center', 'step number'); }
      else { self.dot(cx + d / 2, y + d / 2, d, CARD, FIELD, 1.5, 'step next'); self.mid(cx, y, d, d, String(i), 13, MUTED, 'bold', 'center', 'step number'); }
      self.mid(cx + d + 8, y, Math.min(textW(it, 14, 'bold') + 4, seg - d - 20), d, it, 14, i <= cur ? INK : MUTED, i === cur ? 'bold' : 'body', undefined, 'step label', ip + k);
    });
    return d;
  };

  // -- components
  P.section = function (c, x, y, w) {   // a part, and the box it takes (the page outlines the part a click selects; not drawn)
    var h = this.part(c, x, y, w);
    this.blocks.push({p: c._p || null, type: c.type, x: x, y: y, w: w, h: h});
    return h;
  };
  P.part = function (c, x, y, w) {
    var t = c.type;
    if (t === 'row') return this.row(c, x, y, w);
    if (['tabs', 'alert', 'buttons', 'kpis'].indexOf(t) >= 0) return this['c_' + t](c, x, y, w);
    var pad = this.D.card, box = this.rect(x, y, w, 0, CARD, EDGE, 12, 1, 'card'), yy = y + pad;
    if (c.title) yy += this.text(x + pad, yy, w - 2 * pad, c.title, 16, INK, 'bold', undefined, 1.3, 'section title', 2, cp(c, 'title')) + 14;
    yy += this['c_' + t](c, x + pad, yy, w - 2 * pad);
    box.h = pyRound(yy + pad - y, 1);
    return box.h;
  };
  P.row = function (c, x, y, w) {
    var cols = c.columns.filter(function (col) { return col.length; }), self = this, yy;
    if (!cols.length) return 0;
    if (this.mob) {   // side by side does not fit a phone: one above the other
      yy = y;
      cols.forEach(function (col) { col.forEach(function (comp) { yy += self.section(comp, x, yy, w) + self.D.gap; }); });
      return yy - y - this.D.gap;
    }
    var ws0 = c.widths || [], ws = cols.map(function (_, i) { return i < ws0.length && ws0[i] > 0 ? ws0[i] : 1; });
    var g = this.D.gap, avail = w - g * (cols.length - 1), xx = x, hs = [];
    cols.forEach(function (col, i) {
      var cw = avail * ws[i] / total(ws);
      yy = y;
      col.forEach(function (comp) { yy += self.section(comp, xx, yy, cw) + g; });
      hs.push(yy - y - g); xx += cw + g;
    });
    return Math.max.apply(null, hs);
  };
  P.c_search = function (c, x, y, w) {
    var h = this.mob ? 44 : 42, self = this;
    this.rect(x, y, w, h, CARD, FIELD, 10, 1, 'search box');
    this.icon('search', x + 14, y + (h - 18) / 2, 18, MUTED);
    var hasv = truthy(c.value);
    this.mid(x + 44, y, w - 60, h, c.value || c.placeholder, 14, hasv ? INK : MUTED, 'body', undefined, hasv ? 'field value' : 'placeholder', cp(c, hasv ? 'value' : 'placeholder'));
    this.click('search box', c.placeholder, x, y, w, h);
    var yy = y + h;
    if (truthy(c.filters)) {
      yy += 12; var cx = x, act = new Set(c.active || []);
      c.filters.forEach(function (f, i) {
        var on = act.has(i), fw = textW(f, 13, on ? 'bold' : 'body') + (on ? 44 : 28);
        if (cx + fw > x + w) { cx = x; yy += 40; }
        self.rect(cx, yy, fw, 32, on ? TINT : CARD, on ? ACC : FIELD, 16, on ? 1.5 : 1, 'filter chip');
        if (on) self.icon('check', cx + 10, yy + 8, 16, ACC);
        self.mid(cx + (on ? 30 : 14), yy, fw - (on ? 44 : 28) + 2, 32, f, 13, INK, on ? 'bold' : 'body', undefined, 'chip text', cp(c, 'filters.' + i));
        self.click('filter', f, cx, yy, fw, 32); cx += fw + 8;
      });
      yy += 32;
    }
    return yy - y;
  };
  P.field = function (f, x, y, w, fp) {   // one field: its label, the box with the value, help or error under it; returns the height
    var k = f.kind, yy = y, h = this.mob ? 44 : 40, self = this, th;
    var q = function (key) { return fp ? fp + '.' + key : null; };
    if (k === 'checkbox' || k === 'toggle') {
      if (k === 'checkbox') {
        this.rect(x, yy + 2, 20, 20, f.checked ? ACC : CARD, f.checked ? null : FIELD, 4, 1.5, 'checkbox');
        if (f.checked) this.icon('check', x + 2, yy + 4, 16, CARD);
        th = this.text(x + 30, yy + 2, w - 30, f.label, 14, INK, 'body', undefined, 1.3, 'field label', undefined, q('label'));
        this.click('checkbox', f.label, x, yy, w, Math.max(24, th));
        yy += Math.max(24, th);
      } else {
        var on = f.checked;
        this.rect(x, yy + 2, 40, 22, on ? ACC : FIELD, null, 11, undefined, 'toggle');
        this.dot(x + (on ? 29 : 11), yy + 13, 16, CARD, undefined, undefined, 'toggle knob');
        th = this.text(x + 52, yy + 3, w - 52, f.label, 14, INK, 'body', undefined, 1.3, 'field label', undefined, q('label'));
        this.click('toggle', f.label, x, yy, w, Math.max(26, th));
        yy += Math.max(26, th);
      }
    } else {
      if (f.label) {
        var lw = textW(f.label, 13, 'bold');
        th = this.text(x, yy, w - (f.required ? 14 : 0), f.label, 13, MUTED, 'bold', undefined, 1.3, 'field label', undefined, q('label'));
        if (f.required) this.text(x + Math.min(lw, w - 14) + 4, yy, 12, '*', 13, INK, 'bold', undefined, 1.3, 'required mark');
        yy += th + 6;
      }
      if (k === 'radio') {
        var ox = x, oy = yy, opts = f.options.length ? f.options.map(function (o, i) { return [o, q('options.' + i)]; }) : [[f.value || 'Yes', f.value ? q('value') : null]];
        opts.forEach(function (op) {
          var o = op[0], on2 = o === f.value, ow = textW(o, 14, 'body') + 36;
          if (ox + ow > x + w || self.mob) { if (ox > x) { ox = x; oy += 30; } }
          self.dot(ox + 10, oy + 11, 20, CARD, on2 ? ACC : FIELD, on2 ? 2 : 1.5, 'radio');
          if (on2) self.dot(ox + 10, oy + 11, 10, ACC, undefined, undefined, 'radio dot');
          self.text(ox + 28, oy + 2, ow - 28, o, 14, INK, 'body', undefined, 1.3, 'option', undefined, op[1]);
          self.click('option', o, ox, oy, ow, 24); ox += ow + 20;
        });
        yy = oy + 26;
      } else {
        var lines = k === 'textarea' ? 3 : 1, bh = lines === 1 ? h : Math.max(88, 20 + 3 * 14 * 1.4), err = truthy(f.error);
        this.rect(x, yy, w, bh, k === 'readonly' ? EDGE : CARD, err ? 'E9341C' : (k === 'readonly' ? EDGE : FIELD), 8, err ? 1.5 : 1, 'field box');
        var lx = x + 12, rw = w - 24;
        if (k === 'search') { this.icon('search', x + 12, yy + (h - 18) / 2, 18, MUTED); lx += 28; rw -= 28; }
        if (k === 'select' || k === 'date') {
          rw -= 28;
          if (k === 'select') this.icon('down', x + w - 32, yy + (h - 20) / 2, 20, MUTED);
          else this.icon('calendar', x + w - 32, yy + (h - 18) / 2, 18, MUTED);
        }
        var val = f.value || f.placeholder, ink = f.value ? INK : MUTED, vp = q(f.value ? 'value' : 'placeholder');
        if (lines === 1) this.mid(lx, yy, rw, h, val, 14, ink, 'body', undefined, f.value ? 'field value' : 'placeholder', vp);
        else this.text(lx, yy + 10, rw, val, 14, ink, 'body', undefined, 1.4, 'textarea value', 3, vp);
        this.click(k !== 'text' ? k : 'field', f.label || val, x, yy, w, bh);
        yy += bh;
      }
      if (f.error) {
        this.icon('warning', x, yy + 6, 14, 'E9341C');
        yy += 6 + this.text(x + 20, yy + 5, w - 20, f.error, 12.5, INK, 'body', undefined, 1.35, 'field error', undefined, q('error'));
      } else if (f.help) {
        yy += 6 + this.text(x, yy + 5, w, f.help, 12.5, MUTED, 'body', undefined, 1.35, 'field help', undefined, q('help'));
      }
    }
    return yy - y;
  };
  P.c_form = function (c, x, y, w) {
    var cols = c.columns || (this.mob ? 1 : this.D.cols); cols = this.mob ? 1 : cols;
    var g = 20, gy = 18, cw = (w - g * (cols - 1)) / cols, yy = y, row = [], self = this;
    var flush = function (row, yy) {
      if (!row.length) return yy;
      var hs = row.map(function (q, i) { return self.field(q[0], x + i * (cw + g), yy, cw, q[1]); });
      return yy + Math.max.apply(null, hs) + gy;
    };
    c.fields.forEach(function (f, i) {
      var fp = cp(c, 'fields.' + i);
      if (f.kind === 'textarea' || f.wide) { yy = flush(row, yy); row = []; yy += self.field(f, x, yy, w, fp) + gy; return; }
      row.push([f, fp]);
      if (row.length === cols) { yy = flush(row, yy); row = []; }
    });
    yy = flush(row, yy);
    return Math.max(0, yy - y - gy);
  };
  P.c_table = function (c, x, y, w) {
    var self = this, h;
    if (this.mob) {   // a phone: each row is a list item
      var items = c.rows.map(function (r, ri) {
        return {title: r[0], text: r.map(function (v, j) { return [v, j]; }).filter(function (q) { return q[1] && q[1] !== c.status && q[0]; })
          .map(function (q) { return /[A-Za-z]{3}/.test(q[0]) ? q[0] : c.columns[q[1]] + ' ' + q[0]; }).join(' \u00b7 '),
          meta: '', status: c.status >= 0 ? r[c.status] : '', _pp: {title: cp(c, 'rows.' + ri + '.0'), status: c.status >= 0 ? cp(c, 'rows.' + ri + '.' + c.status) : null}};
      });
      h = this.c_list({items: items}, x, y, w);
      if (c.footer) h += 10 + this.text(x, y + h + 10, w, c.footer, 13, MUTED, 'body', undefined, 1.3, 'table footer', undefined, cp(c, 'footer'));
      return h;
    }
    var cols = c.columns, rows = c.rows, si = c.status, lead = c.select ? 40 : 0;
    var actW = c.action ? textW(c.action, 13, 'bold') + 32 : 0, tail = actW ? actW + 16 : 0;
    var nat = cols.map(function (hname, j) {
      var cells = rows.map(function (r) { return r[j]; });
      if (j === si) return Math.max.apply(null, [textW(hname, 13, 'bold')].concat(cells.filter(function (v) { return v; }).map(function (v) { return textW(v, 13, 'body') + 34; }))) + 24;
      return Math.max.apply(null, [textW(hname, 13, 'bold')].concat(cells.map(function (v) { return textW(v, 14, 'body'); }))) + 24;
    });
    var avail = w - lead - tail, tn = total(nat);
    var ws = tn > avail ? nat.map(function (n) { return n * avail / tn; }) : nat.map(function (n) { return n + (avail - tn) / nat.length; });
    var hh = 40, cx = x + lead;
    this.rect(x, y, w, hh, BG, null, 8, undefined, 'table head');
    cols.forEach(function (hname, j) { self.mid(cx + 12, y, ws[j] - 16, hh, hname, 13, MUTED, 'bold', undefined, 'column heading', cp(c, 'columns.' + j)); cx += ws[j]; });
    if (c.select) this.rect(x + 12, y + 10, 18, 18, CARD, FIELD, 4, 1.5, 'checkbox');
    var yy = y + hh, sel = new Set(c.selected || []);
    rows.forEach(function (r, i) {
      var lines = r.map(function (v, j) { return j !== si ? wrap(v, ws[j] - 24, 14, 'body') : [v]; });
      var rh = Math.max(52, Math.max.apply(null, lines.map(function (l) { return l.length; })) * 14 * 1.3 + 26);
      if (sel.has(i)) self.rect(x, yy, w, rh, TINT, null, 0, undefined, 'selected row');
      self.line(x, yy + rh, x + w, yy + rh, EDGE, 1, 'row edge');
      if (c.select) {
        var on = sel.has(i);
        self.rect(x + 12, yy + (rh - 18) / 2, 18, 18, on ? ACC : CARD, on ? null : FIELD, 4, 1.5, 'checkbox');
        if (on) self.icon('check', x + 13, yy + (rh - 16) / 2, 16, CARD);
        self.click('row checkbox', r[0], x + 11, yy + (rh - 20) / 2, 20, 20);
      }
      var cx2 = x + lead;
      r.forEach(function (v, j) {
        if (j === si && v) self.pill(cx2 + 12, yy + (rh - 26) / 2, v, undefined, cp(c, 'rows.' + i + '.' + j));
        else if (v) {
          var th = lines[j].length * 14 * 1.3;
          self.text(cx2 + 12, yy + (rh - th) / 2, ws[j] - 24, v, 14, INK, j === 0 ? 'bold' : 'body', undefined, 1.3, 'cell', undefined, cp(c, 'rows.' + i + '.' + j));
        }
        cx2 += ws[j];
      });
      if (actW) self.button(x + w - actW - 8, yy + (rh - 34) / 2, {label: c.action, style: 'secondary'}, 34, actW, 13, cp(c, 'action'));
      yy += rh;
    });
    if (c.footer) {
      yy += 14;
      this.text(x, yy, w - 120, c.footer, 13, MUTED, 'body', undefined, 1.3, 'table footer', undefined, cp(c, 'footer'));
      this.rect(x + w - 76, yy - 6, 32, 30, CARD, FIELD, 8, undefined, 'pager');
      this.line(x + w - 56, yy + 3, x + w - 64, yy + 9, MUTED, 1.6, 'glyph'); this.line(x + w - 64, yy + 9, x + w - 56, yy + 15, MUTED, 1.6, 'glyph');
      this.rect(x + w - 36, yy - 6, 32, 30, CARD, FIELD, 8, undefined, 'pager');
      this.icon('right', x + w - 30, yy + 1, 20, MUTED);
      this.click('previous page', 'Previous', x + w - 76, yy - 6, 32, 30); this.click('next page', 'Next', x + w - 36, yy - 6, 32, 30);
      yy += 24;
    }
    return yy - y;
  };
  P.c_kpis = function (c, x, y, w) {
    var its = c.items, self = this;
    if (!its.length) return 0;
    var per = this.mob ? 2 : its.length, g = this.mob ? 16 : 20, tw = (w - g * (per - 1)) / per, yy = y, hrow = 0, row = [];
    its.forEach(function (it, i) {
      if (i && i % per === 0) { row.forEach(function (b) { b.h = hrow; }); yy += hrow + g; hrow = 0; row = []; }   // one height for the tiles of a row
      var tx = x + (i % per) * (tw + g), p = self.mob ? 16 : 20, ip = cp(c, 'items.' + jm(c, i));
      var box = self.rect(tx, yy, tw, 0, CARD, EDGE, 12, 1, 'kpi tile');
      self.rect(tx, yy + 16, 4, 28, ACC, null, 2, undefined, 'kpi mark');
      var h = p + self.text(tx + p, yy + p, tw - 2 * p, it.label, 13, MUTED, 'body', undefined, 1.3, 'kpi label', undefined, ip && ip + '.label') + 6;
      h += self.text(tx + p, yy + h, tw - 2 * p, it.value, self.mob ? 26 : 30, INK, 'bold', undefined, 1.15, 'kpi value', 1, ip && ip + '.value');
      if (it.delta) {
        var up = !/^[-\u2212]/.test(pyStrip(pyStr(it.delta)));
        var good = (it.trend === 'good' || it.trend === 'bad') ? it.trend === 'good' : up;   // fewer days can be the good news
        var ay = yy + h + 10;
        self.cv.poly(up ? [[tx + p, ay + 9], [tx + p + 10, ay + 9], [tx + p + 5, ay + 1]] : [[tx + p, ay + 1], [tx + p + 10, ay + 1], [tx + p + 5, ay + 9]],
          STATUS[good ? 'green' : 'red'], undefined, undefined, 'kpi arrow');
        h += 6 + self.text(tx + p + 16, yy + h + 6, tw - 2 * p - 16, it.delta, 13, MUTED, 'body', undefined, 1.3, 'kpi delta', undefined, ip && ip + '.delta');
      }
      h += p; box.h = pyRound(h, 1); hrow = Math.max(hrow, box.h); row.push(box);
    });
    row.forEach(function (b) { b.h = hrow; });
    return yy + hrow - y;
  };
  P.c_tabs = function (c, x, y, w) {
    var h = 44, cx = x, act = c.active || 0;
    this.line(x, y + h, x + w, y + h, FIELD, 1, 'tabs edge');
    for (var i = 0; i < c.items.length; i++) {
      var it = c.items[i], on = i === act, tw = textW(it, 14, 'bold');
      if (cx + tw > x + w) break;
      this.mid(cx, y, tw + 2, h, it, 14, on ? INK : MUTED, on ? 'bold' : 'body', undefined, 'tab', cp(c, 'items.' + i));
      if (on) this.rect(cx, y + h - 3, tw, 3, ACC, null, 1.5, undefined, 'tab marker');
      this.click('tab', it, cx - 8, y, tw + 16, h); cx += tw + 32;
    }
    return h;
  };
  P.c_alert = function (c, x, y, w) {
    var k = c.kind, fill = {info: TINT, success: EDGE, warning: TINT2, error: PINK}[k], mark = {info: ACC, success: STATUS.green, warning: STATUS.amber, error: 'E9341C'}[k];
    var box = this.rect(x, y, w, 0, fill, null, 10, undefined, 'alert'), bar = this.rect(x, y, 5, 0, mark, null, 2, undefined, 'alert mark');
    this.icon({info: 'info', success: 'check', warning: 'warning', error: 'warning'}[k], x + 18, y + 16, 20, mark);
    var yy = y + 15;
    if (c.title) yy += this.text(x + 50, yy, w - 66, c.title, 14, INK, 'bold', undefined, 1.35, 'alert title', undefined, cp(c, 'title')) + 2;
    yy += this.text(x + 50, yy, w - 66, c.text, 14, INK, 'body', undefined, 1.4, 'alert text', undefined, cp(c, 'text'));
    var h = Math.max(52, yy - y + 15); box.h = bar.h = pyRound(h, 1);
    return h;
  };
  P.c_buttons = function (c, x, y, w) {
    var its = c.items, self = this, bp = function (i) { return c._ip ? c._ip + '.' + i + '.label' : cp(c, 'items.' + i + '.label'); };
    if (this.mob || c.align === 'full') {
      var yy = y, order = its.map(function (b, i) { return [b, i]; });
      order.sort(function (a, b) { return (a[0].style !== 'primary') - (b[0].style !== 'primary') || a[1] - b[1]; });   // primary first, otherwise as given
      order.forEach(function (q) { self.button(x, yy, q[0], 48, w, 15, bp(q[1])); yy += 58; });
      return yy - y - 10;
    }
    var ws = its.map(function (b) { return Math.max(88, textW(b.label, 14, 'bold') + 40); }), tot = total(ws) + 12 * (ws.length - 1);
    var bx = c.align === 'left' ? x : x + w - tot;
    its.forEach(function (b, i) { self.button(bx, y, b, 40, ws[i], undefined, bp(i)); bx += ws[i] + 12; });
    return 40;
  };
  P.c_summary = function (c, x, y, w) {
    var its = c.items, cols = this.mob ? 1 : (c.columns || 2), g = 24, cw = (w - g * (cols - 1)) / cols, yy = y, hrow = 0, self = this;
    its.forEach(function (kv, i) {
      if (i && i % cols === 0) { yy += hrow + 16; hrow = 0; }
      var cx = x + (i % cols) * (cw + g), ip = cp(c, 'items.' + jm(c, i));
      var h = self.text(cx, yy, cw, kv[0], 13, MUTED, 'body', undefined, 1.3, 'summary label', undefined, ip && ip + '.0') + 4;
      h += self.text(cx, yy + h, cw, kv[1], 15, INK, 'bold', undefined, 1.35, 'summary value', undefined, ip && ip + '.1');
      hrow = Math.max(hrow, h);
    });
    return yy + hrow - y;
  };
  P.c_list = function (c, x, y, w) {
    var yy = y, self = this, n = c.items.length;
    c.items.forEach(function (it, i) {
      var ip = it._pp ? null : cp(c, 'items.' + jm(c, i)), q = function (f) { return it._pp ? (it._pp[f] || null) : ip && ip + '.' + f; };
      var right = 0;
      if (it.status) right = textW(it.status, 13, 'body') + (statusOf(it.status) ? 34 : 20) + 12;
      var mw = it.meta ? textW(it.meta, 13, 'body') + 16 : 0, tw = w - right - mw - 24;
      var th = self.text(x, yy + 12, tw, it.title, 14, INK, 'bold', undefined, 1.35, 'list title', undefined, q('title'));
      if (it.text) th += 2 + self.text(x, yy + 12 + th + 2, tw, it.text, 13, MUTED, 'body', undefined, 1.35, 'list text', undefined, q('text'));
      var rh = Math.max(56, th + 24);
      if (it.meta) self.mid(x + w - right - mw - 20, yy, mw, rh, it.meta, 13, MUTED, 'body', 'right', 'list meta', q('meta'));
      if (it.status) self.pill(x + w - right - 8, yy + (rh - 26) / 2, it.status, undefined, q('status'));
      self.icon('right', x + w - 18, yy + (rh - 18) / 2, 18, MUTED);
      self.click('list row', it.title, x, yy, w, rh);
      if (i < n - 1) self.line(x, yy + rh, x + w, yy + rh, EDGE, 1, 'row edge');
      yy += rh;
    });
    return yy - y;
  };
  P.c_cards = function (c, x, y, w) {
    var its = c.items, self = this;
    if (!its.length) return 0;
    var cols = this.mob ? 1 : (c.columns || (this.dev === 'desktop' ? 3 : 2)), g = 16, cw = (w - g * (cols - 1)) / cols, yy = y;
    for (var r0 = 0; r0 < its.length; r0 += cols) {
      var row = its.slice(r0, r0 + cols), boxes = [], hs = [];
      row.forEach(function (it, k) {
        var cx = x + k * (cw + g), p = 16, ip = cp(c, 'items.' + jm(c, r0 + k));
        var box = self.rect(cx, yy, cw, 0, CARD, FIELD, 12, 1, 'item card'); boxes.push(box);
        var h = p;
        if (it.status) { self.pill(cx + p, yy + h, it.status, undefined, ip && ip + '.status'); h += 26 + 10; }
        h += self.text(cx + p, yy + h, cw - 2 * p, it.title, 15, INK, 'bold', undefined, 1.3, 'card title', undefined, ip && ip + '.title');
        if (it.text) h += 4 + self.text(cx + p, yy + h + 4, cw - 2 * p, it.text, 13, MUTED, 'body', undefined, 1.35, 'card text', undefined, ip && ip + '.text');
        if (it.meta) h += 6 + self.text(cx + p, yy + h + 6, cw - 2 * p, it.meta, 13, INK, 'body', undefined, 1.35, 'card meta', undefined, ip && ip + '.meta');
        hs.push(h);
      });
      var top = Math.max.apply(null, hs);
      row.forEach(function (it, k) {
        var cx = x + k * (cw + g), h = top, ip = cp(c, 'items.' + jm(c, r0 + k));
        if (it.action) { self.button(cx + 16, yy + h + 14, {label: it.action, style: 'secondary'}, 36, cw - 32, 13, ip && ip + '.action'); h += 14 + 36; }
        boxes[k].h = pyRound(h + 16, 1);
      });
      yy += Math.max.apply(null, boxes.map(function (b) { return b.h; })) + g;
    }
    return yy - y - g;
  };
  function barValue(v) {   // float(re.sub(r"[^\d.\-]", "", v) or 0); a value Python cannot read draws as its leading number here
    var s = v.replace(/[^\d.\-]/g, '');
    if (!s) return 0;
    if (/^-?(\d+\.?\d*|\.\d+)$/.test(s)) return Number(s);
    return parseFloat(s) || 0;
  }
  P.c_bars = function (c, x, y, w) {
    var its = c.items, self = this, unit = c.unit === undefined ? '' : c.unit;
    if (!its.length) return 0;
    var vals = its.map(function (i) { return barValue(i.value); }), top = Math.max.apply(null, vals.concat([1]));
    var lw = Math.min(Math.max.apply(null, its.map(function (i) { return textW(i.label, 13, 'body'); }).concat([40])) + 16, w * .35);
    var vw = Math.max.apply(null, its.map(function (i) { return textW(i.value + unit, 13, 'bold'); }).concat([30])) + 12;
    var bw = w - lw - vw, yy = y;
    its.forEach(function (it, i) {
      var v = vals[i], ip = cp(c, 'items.' + jm(c, i));
      self.mid(x, yy, lw - 12, 30, it.label, 13, INK, 'body', undefined, 'bar label', ip && ip + '.label');
      self.rect(x + lw, yy + 9, bw, 12, EDGE, null, 6, undefined, 'bar track');
      self.rect(x + lw, yy + 9, Math.max(6, bw * v / top), 12, ACC, null, 6, undefined, 'bar');
      self.mid(x + lw + bw + 10, yy, vw, 30, it.value + unit, 13, INK, 'bold', undefined, 'bar value', ip && ip + '.value');
      yy += 36;
    });
    return yy - y - 6;
  };
  P.c_text = function (c, x, y, w) { return this.text(x, y, w, c.text, 14, INK, 'body', undefined, 1.5, 'paragraph', undefined, cp(c, 'text')); };

  // (design, clickable elements) for screen n: the same design dict an infographic page has (w, h, bg, els)
  function layout(spec, n, problems) {
    var sc = spec.screens[n - 1], S = new Screen(spec, n, problems), D = S.D, W = D.W, sp = 'screens.' + (n - 1);
    var nav = spec.nav || [], side = nav.length && !S.mob ? D.nav : 0, head = D.head, panel, edge;
    var page = S.rect(0, 0, W, D.H, BG, undefined, undefined, undefined, 'page');
    if (side) { panel = S.rect(0, head, side, D.H - head, CARD, undefined, undefined, undefined, 'nav panel'); edge = S.line(side, head, side, D.H, EDGE, 1, 'nav edge'); }
    S.header(W, head);
    if (side) S.sidenav(sc.nav, side, head);
    var x0 = side + D.pad, cw = W - side - 2 * D.pad;
    var y = S.pageHead(sc, x0, head + D.pad - 4, cw, sp);
    sc.sections.forEach(function (comp) { y += S.section(comp, x0, y, cw) + D.gap; });
    if (S.mob && truthy(sc.actions)) y += S.c_buttons({items: sc.actions, align: 'full', _ip: sp + '.actions'}, x0, y, cw) + D.gap;
    var H = Math.max(D.H, pyRound(y - D.gap + D.pad + (S.mob && nav.length ? 64 : 0)));
    page.h = H;
    if (side) { panel.h = H - head; edge.y2 = H; }
    if (S.mob && nav.length) S.tabbar(sc.nav, W, H);
    return [{w: W, h: H, bg: BG, els: S.cv.els, warnings: [], spec: {title: sc.title, name: sc.name, format: 'screen'}}, S.clicks, S.blocks];
  }
  // every screen of a spec, as the page needs it: the spec without the engine's keys, problems, designs, clickable elements and
  // each part's box (blocks: per screen, [{p, type, x, y, w, h}], a part inside a row before the row)
  function design(raw) {
    C.state.cuts = []; C.state.minFs = 0;
    var r = normalise(raw), spec = r[0], problems = r[1], designs = [], clicks = [], blocks = [];
    for (var n = 1; n <= spec.screens.length; n++) { var q = layout(spec, n, problems); designs.push(q[0]); clicks.push(q[1]); blocks.push(q[2]); }
    return {spec: strip(spec), problems: problems, designs: designs, clicks: clicks, blocks: blocks};
  }
  function svgs(d) { return d.designs.map(function (x) { return I.toSvg(x); }); }

  return {DEV: DEV, DEVICES: DEVICES, KINDS: KINDS, COMPONENTS: COMPONENTS, STYLES: STYLES, STATUS: STATUS, statusOf: statusOf, navIcon: navIcon,
    plainText: plainText, normalise: normalise, strip: strip, layout: layout, design: design, svgs: svgs};
});
