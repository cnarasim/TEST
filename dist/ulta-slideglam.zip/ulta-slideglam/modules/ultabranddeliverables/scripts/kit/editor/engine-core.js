/* The layout engine's shared core, in the page: the same arithmetic as the Python kit (info.py), so a page relaid out in the
   browser after an edit matches what the skill would draw from the same content.
   - pyRound / pyFix: Python's round() and "{:.nf}" (half to even on the exact value; Math.round differs on ties)
   - textW / wrap / fit / clean: the kit's text measuring (metrics.json: advances + pair kerning of the bundled faces)
   - tint / shade / mix / lum / contrast: colours
   - Canvas: the element list every renderer draws; icons; the SVG writer pieces
   Loaded inline in a page (window.UltaCore) or with require() by the parity test. Never contains a closing script tag. */
(function (root, factory) {
  var m = factory();
  if (typeof module === 'object' && module.exports) module.exports = m; else root.UltaCore = m;
})(this, function () {
  'use strict';
  var WS = /[\t\n\x0b\x0c\r\x1c-\x1f \x85\xa0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]+/;
  var WSG = /[\t\n\x0b\x0c\r\x1c-\x1f \x85\xa0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]+/g;
  var state = {minFs: 0, cuts: [], quiet: false};   // quiet: a trial size of a layout, its cuts are not reported
  var FACES = null, UNITS = new Map(), ICONS = {}, CATALOG = [], LOGO = null;
  var CW = {display: 0.60, body: 0.50, bold: 0.54};

  // ------------------------------------------------------------------------------------------------ Python numbers
  function pyRound(x, nd) {
    if (typeof x !== 'number' || !isFinite(x)) return x;
    if (nd === undefined || nd === null) {
      var f = Math.floor(x), d = x - f;
      if (d > 0.5) return f + 1;
      if (d < 0.5) return f;
      return f % 2 === 0 ? f : f + 1;
    }
    var m = Math.pow(10, nd), y = x * m, fl = Math.floor(y), dd = y - fl;
    if (Math.abs(dd - 0.5) > 1e-6) return (dd < 0.5 ? fl : fl + 1) / m;
    var s = Math.abs(x).toFixed(Math.min(100, nd + 50)), p = s.indexOf('.');   // a near tie: the exact decimal value decides
    var n = Number(s.slice(0, p) + s.slice(p + 1, p + 1 + nd)), tail = s.slice(p + 1 + nd), up;
    if (tail[0] > '5') up = true; else if (tail[0] < '5') up = false; else up = /[1-9]/.test(tail.slice(1)) || n % 2 === 1;
    if (up) n += 1;
    return (x < 0 ? -n : n) / m;
  }
  function pyFix(x, nd) { return pyRound(x, nd).toFixed(nd); }
  function pyStr(v) { return v === null || v === undefined ? 'None' : v === true ? 'True' : v === false ? 'False' : String(v); }
  function or(v) { return v === null || v === undefined || v === false || v === 0 || v === '' || (Array.isArray(v) && !v.length) ? '' : v; }   // Python "v or ''"
  function truthy(v) { return !(v === null || v === undefined || v === false || v === 0 || v === '' || (Array.isArray(v) && !v.length) || (isObj(v) && !Object.keys(v).length)); }
  function isObj(v) { return v !== null && typeof v === 'object' && !Array.isArray(v); }
  function cps(s) { return Array.from(s); }
  function split(s) { return String(s).split(WS).filter(function (x) { return x !== ''; }); }
  function strip(s, chars) {
    var a = cps(s), i = 0, j = a.length;
    while (i < j && chars.indexOf(a[i]) >= 0) i++;
    while (j > i && chars.indexOf(a[j - 1]) >= 0) j--;
    return a.slice(i, j).join('');
  }
  function rstrip(s, chars) { var a = cps(s), j = a.length; while (j > 0 && chars.indexOf(a[j - 1]) >= 0) j--; return a.slice(0, j).join(''); }
  function pyStrip(s) { return String(s).replace(new RegExp('^' + WS.source), '').replace(new RegExp(WS.source + '$'), ''); }
  function deepEq(a, b) {
    if (a === b) return true;
    if (typeof a !== typeof b || a === null || b === null || typeof a !== 'object') return false;
    if (Array.isArray(a) !== Array.isArray(b)) return false;
    if (Array.isArray(a)) { if (a.length !== b.length) return false; for (var i = 0; i < a.length; i++) if (!deepEq(a[i], b[i])) return false; return true; }
    var ka = Object.keys(a), kb = Object.keys(b);
    if (ka.length !== kb.length) return false;
    for (var k = 0; k < ka.length; k++) if (!Object.prototype.hasOwnProperty.call(b, ka[k]) || !deepEq(a[ka[k]], b[ka[k]])) return false;
    return true;
  }
  function copy(o) { return JSON.parse(JSON.stringify(o)); }

  // ------------------------------------------------------------------------------------------------ text
  function setMetrics(m) { FACES = m && (m.faces || m); UNITS = new Map(); }
  function units(s, font) {
    var M = FACES && FACES[font];
    if (!M) return null;
    var key = font + '\n' + s, u = UNITS.get(key);
    if (u === undefined) {
      var adv = M.adv, kern = M.kern, miss = M.miss, prev = '';
      u = 0;
      for (var ch of s) {
        var a = adv[ch]; u += a === undefined ? miss : a;
        if (prev) { var k = kern[prev + ch]; if (k !== undefined) u += k; }
        prev = ch;
      }
      if (UNITS.size > 200000) UNITS.clear();
      UNITS.set(key, u);
    }
    return u;
  }
  function textW(s, fs, font) {
    font = font || 'body'; s = String(s);
    var n = /[\ud800-\udfff]/.test(s) ? cps(s).length : s.length;   // characters, as Python counts them
    var est = n * fs * CW[font], u = units(s, font);
    return u !== null ? Math.max(est, u * fs / 12800) : est;
  }
  function wrap(text, w, fs, font) {
    font = font || 'body';
    var words = split(or(text)), lines = [], cur = '';
    var fits = function (s) { return textW(s, fs, font) <= w; };
    for (var i = 0; i < words.length; i++) {
      var wd = words[i];
      while (!fits(wd) && cps(wd).length > 1) {   // a word wider than the line breaks where it must
        if (cur) { lines.push(cur); cur = ''; }
        var a = cps(wd), n = a.length - 1;
        while (n > 1 && !fits(a.slice(0, n).join(''))) n--;
        lines.push(a.slice(0, n).join('')); wd = a.slice(n).join('');
      }
      if (!cur) cur = wd;
      else if (fits(cur + ' ' + wd)) cur += ' ' + wd;
      else { lines.push(cur); cur = wd; }
    }
    if (cur) lines.push(cur);
    return lines.length ? lines : [''];
  }
  function fit(text, w, h, hi, lo, font, lh, maxLines, report) {
    font = font || 'body'; lh = lh === undefined ? 1.22 : lh; report = report === undefined ? true : report;
    if (state.minFs) {
      lo = Math.max(lo, state.minFs); hi = Math.max(hi, lo); h = Math.max(h, wrap(text, w, lo, font).length * lo * lh); maxLines = null;
    }
    var words = split(or(text));
    var capOk = function (s) { return words.every(function (x) { return textW(x, s, font) <= w; }); };
    for (var pass = 0; pass < 2; pass++) {
      var whole = pass === 0, fs = hi;
      while (fs >= lo) {
        var ls = wrap(text, w, fs, font);
        if ((!whole || capOk(fs)) && ls.length * fs * lh <= h && (!maxLines || ls.length <= maxLines)) return [fs, ls];
        fs -= 1;
      }
    }
    var out = wrap(text, w, lo, font);
    var n = h ? Math.max(1, Math.trunc(h / (lo * lh))) : out.length;
    if (maxLines) n = Math.min(n, maxLines);
    if (out.length > n) {
      if (report && !state.quiet) state.cuts.push([out.slice(0, n).reduce(function (t, x) { return t + cps(x).length + 1; }, 0), pyStr(text)]);
      out = out.slice(0, n); out[n - 1] = rstrip(out[n - 1], '.,;: ') + '\u2026';
    }
    return [lo, out];
  }
  function clean(t, n) {
    n = n === undefined ? 160 : n;
    var s = pyStrip(pyStr(or(t)).replace(/[*_`]+/g, '').replace(WSG, ' '));
    var a = cps(s);
    if (a.length <= n) return s;
    state.cuts.push([n, s]);
    var head = a.slice(0, n - 1).join(''), sp = head.lastIndexOf(' ');
    return (sp >= 0 ? head.slice(0, sp) : head) + '\u2026';
  }

  // ------------------------------------------------------------------------------------------------ colours
  function rgb(h) { return [0, 2, 4].map(function (i) { return parseInt(h.slice(i, i + 2), 16); }); }
  function hx(v) { var s = v.toString(16).toUpperCase(); return s.length < 2 ? '0' + s : s; }
  function tint(h, amount) { return rgb(h).map(function (c) { return hx(pyRound(c + (255 - c) * amount)); }).join(''); }
  function shade(h, amount) { return rgb(h).map(function (c) { return hx(pyRound(c * (1 - amount))); }).join(''); }
  function mix(a, b, f) { var x = rgb(a), y = rgb(b); return x.map(function (p, i) { return hx(pyRound(p + (y[i] - p) * f)); }).join(''); }
  function lum(h) {
    if (typeof h !== 'string' || !/^[0-9A-Fa-f]{6}/.test(h)) return null;
    var c = rgb(h).map(function (v) { v = v / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2];
  }
  function contrast(a, b) {
    var la = lum(a), lb = lum(b);
    if (la === null || lb === null) return 21.0;
    return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
  }

  // ------------------------------------------------------------------------------------------------ the brand's colours
  // tools/ulta_conform.py in the page: every colour off the template palette becomes the nearest palette colour (text never a
  // status colour, gradients never one), then - another brand active - each palette colour that brand's (the page's palette data).
  function lab(h) {
    var c = rgb(h).map(function (v) { v = v / 255; return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); });
    var x = (c[0] * .4124 + c[1] * .3576 + c[2] * .1805) / .9505, y = c[0] * .2126 + c[1] * .7152 + c[2] * .0722, z = (c[0] * .0193 + c[1] * .1192 + c[2] * .9505) / 1.089;
    var f = function (t) { return t > 0.008856 ? Math.pow(t, 1 / 3) : 7.787 * t + 16 / 116; };
    return [116 * f(y) - 16, 500 * (f(x) - f(y)), 200 * (f(y) - f(z))];
  }
  var CALM = ['5D0F43', 'E8275A', '000000', '404040', 'FFFFFF', 'F8F5F5'];
  function Conform(p) {
    var self = this;
    this.order = (p.allowed || []).map(function (c) { return c.toUpperCase(); }); this.labs = {};
    this.order.forEach(function (c) { self.labs[c] = lab(c); });
    this.keep = new Set((p.keep || []).map(function (c) { return c.toUpperCase(); })); this.status = new Set(p.status || []);
    this.named = p.named || {}; this.re = p.recolour || null; this.cache = {};
  }
  Conform.prototype.nearest = function (keys, L) {
    var best = null, bd = Infinity, labs = this.labs;
    keys.forEach(function (c) { var v = labs[c], d = (v[0] - L[0]) * (v[0] - L[0]) + (v[1] - L[1]) * (v[1] - L[1]) + (v[2] - L[2]) * (v[2] - L[2]); if (d < bd) { bd = d; best = c; } });
    return best;
  };
  Conform.prototype.map = function (h) {
    h = h.toUpperCase();
    if (this.keep.has(h)) return h;
    if (this.cache[h] === undefined) {
      var c = rgb(h), r = c[0], g = c[1], b = c[2], sat = Math.max(r, g, b) - Math.min(r, g, b), light = Math.min(r, g, b) > 200, keys = this.order;
      if (sat >= 40 && g > r && g >= b && !light) this.cache[h] = '00B050';            // RAG green stays a status green
      else if (sat >= 60 && r > 200 && 140 <= g && g <= 215 && b < 120 && !light) this.cache[h] = 'FFC000';   // RAG amber
      else {
        if (sat >= 25 && (b > r || g > r)) keys = keys.filter(function (k) { return CALM.indexOf(k) >= 0; });
        this.cache[h] = this.nearest(keys, lab(h));
      }
    }
    return this.cache[h];
  };
  Conform.prototype.deco = function (h) {
    h = h.toUpperCase();
    if (this.keep.has(h) && !this.status.has(h)) return h;
    var c = rgb(h), self = this, keys = this.order.filter(function (k) { return !self.status.has(k); });
    if (Math.max(c[0], c[1], c[2]) - Math.min(c[0], c[1], c[2]) >= 25 && (c[2] > c[0] || c[1] > c[0])) keys = keys.filter(function (k) { return CALM.indexOf(k) >= 0; });
    return this.nearest(keys, lab(h));
  };
  Conform.prototype.text = function (h) {
    h = h.toUpperCase();
    if (this.keep.has(h) && !this.status.has(h)) return h;
    return this.nearest(this.order, lab(h));
  };
  Conform.prototype.svg = function (s) {   // fix_text on a drawn page, in its order
    var self = this, named = this.named;
    s = s.replace(/(<text\b[^>]*\bfill=")#([0-9A-Fa-f]{6})/g, function (m, a, h) { return a + '#' + self.text(h); });
    s = s.replace(/(stop-color\s*[:=]\s*["']?)#([0-9A-Fa-f]{6})\b/gi, function (m, a, h) { return a + '#' + self.deco(h); });
    s = s.replace(/#([0-9A-Fa-f]{6})\b/g, function (m, h) { return '#' + self.map(h); });
    s = s.replace(/#([0-9A-Fa-f]{3})\b(?![0-9A-Fa-f])/g, function (m, h) { return '#' + self.map(h[0] + h[0] + h[1] + h[1] + h[2] + h[2]); });
    s = s.replace(/((?:^|[;{\s"'])(?:color|fill|stroke|background(?:-color)?|border(?:-[a-z]+)?-color|stop-color)\s*[:=]\s*)(["']?)([a-z]+)\b/gi,
      function (m, a, q, w) { var h = named[w.toLowerCase()]; return a + q + (h ? '#' + self.map(h) : w); });
    if (this.re) { var re = this.re; s = s.replace(/#([0-9A-Fa-f]{6})\b/g, function (m, h) { return '#' + (re[h.toUpperCase()] || h); }); }
    return s;
  };

  // ------------------------------------------------------------------------------------------------ icons and the logo
  function setIcons(icons, catalog, logo) { ICONS = icons || {}; CATALOG = catalog || []; if (logo) LOGO = logo; }
  function iconSvg(name) { var i = name && Object.prototype.hasOwnProperty.call(ICONS, name) ? ICONS[name] : null; return i ? [i.vb, i.inner] : null; }
  var STOP = new Set('the a an and or of for to in on with by at from is are be as & / - \u2013 \u2014 vs'.split(' '));
  function pickIcon(text) {   // the catalog icon whose keywords overlap the text most; null when nothing matches
    var words = new Set();
    pyStr(text).split(/[\s/&\u2013\u2014-]+/).forEach(function (w) { w = strip(w, '.,:;()"\'').toLowerCase(); if (!STOP.has(w)) words.add(w); });
    var stems = new Set(); words.forEach(function (w) { var a = cps(w); if (a.length >= 5) stems.add(a.slice(0, 5).join('')); });
    var best = null, score = 0;
    CATALOG.forEach(function (c) {
      var s = 0;
      c[1].forEach(function (k) { if (words.has(k)) s += 2; });
      c[1].forEach(function (k) { var a = cps(k); if (a.length >= 5 && stems.has(a.slice(0, 5).join(''))) s += 1; });
      if (s > score) { best = c[0]; score = s; }
    });
    return best;
  }
  function iconNames() { return CATALOG.map(function (c) { return c[0]; }); }

  // ------------------------------------------------------------------------------------------------ the element list
  function Canvas() { this.els = []; this.warn = []; }
  function assign(o, kw) { if (kw) for (var k in kw) if (Object.prototype.hasOwnProperty.call(kw, k)) o[k] = kw[k]; return o; }
  Canvas.prototype.rect = function (x, y, w, h, fill, stroke, r, sw, grad, name, kw) {
    this.els.push(assign({k: 'rect', x: pyRound(x, 1), y: pyRound(y, 1), w: pyRound(w, 1), h: pyRound(h, 1), fill: fill === undefined ? null : fill,
      stroke: stroke === undefined ? null : stroke, r: r === undefined ? 0 : r, sw: sw === undefined ? 1 : sw, grad: grad ? grad.slice() : null, name: name || 'box'}, kw));
  };
  Canvas.prototype.text = function (x, y, w, lines, fs, color, font, align, lh, name, src, kw) {
    lh = lh === undefined || lh === null ? 1.22 : lh;
    var h = lines.length * fs * lh;
    this.els.push(assign({k: 'text', x: pyRound(x, 1), y: pyRound(y, 1), w: pyRound(w, 1), h: pyRound(h, 1), lines: lines,
      t: src !== undefined && src !== null ? src : lines.join(' '), fs: pyRound(fs, 1), color: color, font: font || 'body', align: align || 'left', lh: lh, name: name || 'text'}, kw));
    return h;
  };
  Canvas.prototype.ellipse = function (x, y, w, h, fill, stroke, sw, name, kw) {
    this.els.push(assign({k: 'ellipse', x: pyRound(x, 1), y: pyRound(y, 1), w: pyRound(w, 1), h: pyRound(h, 1), fill: fill === undefined ? null : fill,
      stroke: stroke === undefined ? null : stroke, sw: sw === undefined ? 1 : sw, name: name || 'dot'}, kw));
  };
  Canvas.prototype.line = function (x1, y1, x2, y2, color, sw, dash, name, kw) {
    this.els.push(assign({k: 'line', x1: pyRound(x1, 1), y1: pyRound(y1, 1), x2: pyRound(x2, 1), y2: pyRound(y2, 1), color: color, sw: sw === undefined ? 2 : sw,
      dash: !!dash, name: name || 'line'}, kw));
  };
  Canvas.prototype.icon = function (name, x, y, s, color, kw) {
    if (name && iconSvg(name)) this.els.push(assign({k: 'icon', name: name, x: pyRound(x, 1), y: pyRound(y, 1), s: pyRound(s, 1), color: color}, kw));
  };
  Canvas.prototype.poly = function (pts, fill, stroke, sw, name, kw) {
    this.els.push(assign({k: 'poly', pts: pts.map(function (q) { return [pyRound(q[0], 1), pyRound(q[1], 1)]; }), fill: fill, stroke: stroke === undefined ? null : stroke,
      sw: sw === undefined ? 1 : sw, name: name || 'shape'}, kw));
  };
  Canvas.prototype.image = function (x, y, w, h, ref, fit, r, name, alt, kw) {   // a picture the content holds (spec.images[ref])
    this.els.push(assign({k: 'image', x: pyRound(x, 1), y: pyRound(y, 1), w: pyRound(w, 1), h: pyRound(h, 1), ref: ref, fit: fit || 'contain', r: pyRound(r || 0, 1),
      name: name || 'picture', alt: alt === undefined ? 'Picture' : alt}, kw));
  };
  Canvas.prototype.arc = function (cx, cy, r, sw, frac, color, track, kw) {
    this.els.push(assign({k: 'arc', cx: pyRound(cx, 1), cy: pyRound(cy, 1), r: pyRound(r, 1), sw: pyRound(sw, 1), frac: Math.max(0.0, Math.min(1.0, frac)), color: color, track: track}, kw));
  };

  // ------------------------------------------------------------------------------------------------ SVG pieces
  function esc(t) { return pyStr(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;'); }
  function place(vb, x, y, w, h) {
    var v = vb.replace(/,/g, ' ').trim().split(/\s+/).map(Number), s = Math.min(w / v[2], h / v[3]);
    return 'translate(' + pyFix(x + (w - v[2] * s) / 2, 2) + ',' + pyFix(y + (h - v[3] * s) / 2, 2) + ') scale(' + pyFix(s, 5) + ') translate(' + pyFix(-v[0], 2) + ',' + pyFix(-v[1], 2) + ')';
  }
  function iconMarkup(name, color, bold) {
    var ic = iconSvg(name);
    if (!ic) return null;
    var vb = ic[0], inner = ic[1].replace(/fill="#[0-9A-Fa-f]{3,6}"/g, 'fill="#' + color + '"').replace(/stroke="#[0-9A-Fa-f]{3,6}"/g, 'stroke="#' + color + '"');
    if (bold) {
      var p = vb.split(/\s+/).map(Number), vw = Math.max(p[2], p[3]);
      inner = inner.replace(/\s(?:stroke="none"|stroke-width="[^"]*")/g, '');
      inner = '<g stroke="#' + color + '" stroke-width="' + pyFix(vw * 0.045, 2) + '" stroke-linejoin="round" stroke-linecap="round">' + inner + '</g>';
    }
    return [vb, inner];
  }
  function logo() { return LOGO; }

  return {state: state, CW: CW, pyRound: pyRound, pyFix: pyFix, pyStr: pyStr, or: or, truthy: truthy, isObj: isObj, cps: cps, split: split, strip: strip,
    rstrip: rstrip, pyStrip: pyStrip, deepEq: deepEq, copy: copy, setMetrics: setMetrics, units: units, textW: textW, wrap: wrap, fit: fit, clean: clean,
    tint: tint, shade: shade, mix: mix, lum: lum, contrast: contrast, setIcons: setIcons, iconSvg: iconSvg, pickIcon: pickIcon, iconNames: iconNames,
    Canvas: Canvas, esc: esc, place: place, iconMarkup: iconMarkup, logo: logo, Conform: Conform};
});
