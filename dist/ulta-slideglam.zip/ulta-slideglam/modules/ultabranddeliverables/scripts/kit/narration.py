#!/usr/bin/env python3
"""Narration for a deck: the words a narrated walkthrough speaks, one script per slide, kept in the slide's `talk` (the same field
the speaker notes use, so the PowerPoint's notes and the narrated page never disagree).

Where the script comes from, in order: a "Narration:" line the storyboard wrote under the slide's heading (a person or the
model writing it); else these rules - the headline, the key point and the slide's own items, said as plain sentences. The rules never add a fact that is not on the slide.
"""
import re

WPM = 150   # a calm narration pace: words per minute


def _clean(s):
    s = re.sub(r'\{[^{}]*\}|\{/\}', '', str(s or ''))                 # colour markup
    s = re.sub(r'\*\*(.*?)\*\*', r'\1', s).replace('## ', '')
    s = re.sub(r'^[•–\-◦▪✓→]\s*', '', s.strip())
    return re.sub(r'\s+', ' ', s).strip()


def _sentence(s):
    s = _clean(s).rstrip(' ;,:')
    if not s: return ''
    s = s[0].upper() + s[1:]
    return s if s[-1] in '.!?' else s + '.'


def _items(sl):
    """The things a slide lists, as short phrases: graphic items, flow steps, table rows, bullets."""
    out = []
    for it in ((sl.get('graphic') or {}).get('items') or []) + (sl.get('flow') or []):
        t, x = _clean(it.get('title')), _clean(it.get('text'))
        out.append(f'{t}: {x}' if t and x and not x.lower().startswith(t.lower().rstrip('…')) else (x or t))
    f = sl.get('fills') or {}
    tbl = f.get('table')
    if not out and isinstance(tbl, list) and len(tbl) == 1 and f.get('text1'):   # the process-steps slide: names in text1…4, "Step n\ndetail" in the one table row
        for k in range(1, 9):
            name = _clean(f.get(f'text{k}'))
            if not name: continue
            cell = str(tbl[0][k - 1]) if k - 1 < len(tbl[0]) else ''
            detail = _clean(cell.split('\n', 1)[1]) if '\n' in cell else ''
            out.append(f'{name}: {detail}' if detail and not detail.lower().startswith(name.lower()) else (detail or name))
    if isinstance(tbl, list) and len(tbl) > 1 and not out:
        head = [_clean(c) for c in tbl[0]]
        for row in tbl[1:]:
            cells = [_clean(c) for c in row if _clean(c)]
            if not cells: continue
            if len(cells) >= 2 and not head[0].strip('#'):
                out.append(f'{cells[0]}: {" - ".join(cells[1:])}')
            elif len(cells) >= 2:
                out.append(f'{cells[0]}: {"; ".join(cells[1:])}' if not cells[0].isdigit() else '; '.join(cells[1:]))
            else: out.append(cells[0])
    if not out:
        for k in sorted(f):
            if k in ('title', 'table'): continue
            v = f[k]
            for line in (v if isinstance(v, list) else [v]):
                if isinstance(line, list): continue
                c = _clean(line)
                if c and len(c) > 3 and not c.lower().startswith(('ulta beauty', 'thank you')): out.append(c)
    return out


def rules_script(sl, deck_title=''):
    """One slide's narration by rules: what the slide says, as sentences (at most ~80 words)."""
    kind = sl.get('kind'); f = sl.get('fills') or {}
    title = _clean(f.get('title')).replace(' (cont.)', '')
    if kind == 'cover': return f"{_sentence(title or deck_title)} Let's walk through it."
    if kind == 'closing': return 'That is the walkthrough. Thank you.'
    if kind in ('agenda', 'divider'): return _sentence(f'Next: {title}') if title else ''
    parts = [_sentence(title)] if title else []
    if sl.get('takeaway'): parts.append(_sentence(sl['takeaway']))
    words = sum(len(p.split()) for p in parts)
    for it in _items(sl):
        s = _sentence(it)
        if not s or s in parts: continue
        if words + len(s.split()) > 80: break
        parts.append(s); words += len(s.split())
    return ' '.join(parts)


def attach(spec, narr):
    """Storyboard "Narration:" lines ({section headline: text}) onto the first slide of each section."""
    done = set()
    title = str(spec.get('title') or '').strip()
    if title in narr:   # a "Narration:" line under the "# Title" is the cover's welcome
        cover = next((sl for sl in spec.get('slides') or [] if sl.get('kind') == 'cover'), None)
        if cover is not None: cover['talk'] = _clean(narr[title])[:900]; done.add(title)
    for sl in spec.get('slides') or []:
        sec = str(sl.get('sec') or '').strip()
        key = next((k for k in narr if k == sec or (sec and (k.startswith(sec.rstrip('…')) or sec.startswith(k)))), None)
        if key and key not in done:
            sl['talk'] = _clean(narr[key])[:900]; done.add(key)
    return len(done)


def fill(spec):
    """Every slide without a script gets one by rules. Returns the number filled."""
    n = 0; title = _clean(spec.get('title'))
    for sl in spec.get('slides') or []:
        if not str(sl.get('talk') or '').strip():
            s = rules_script(sl, title)
            if s: sl['talk'] = s; n += 1
    return n


def stats(spec):
    """Words, estimated minutes and how many slides have a script."""
    talks = [str(sl.get('talk') or '') for sl in spec.get('slides') or []]
    words = sum(len(t.split()) for t in talks)
    return {'slides': len(talks), 'narrated': sum(1 for t in talks if t.strip()), 'words': words, 'minutes': round(words / WPM, 1)}
