"""Infographics on the Ulta standard: content → a block spec → a deterministic layout → SVG / PNG / PDF / HTML / PowerPoint.

AI generates (or rules read) the spec; Python lays it out. Every position, size and font size is computed here once and every renderer draws
the same geometry. Typography is the template's: Playfair Display Black for display type (titles, big numbers) and Circular Std for body.
The seven infographic themes of the deck builder (themes.py) set how the coloured elements are treated; the page stays light.

spec = {title, subtitle, kicker, source, format: slide|onepager|square, theme, blocks: [{type, title?, ...}]}
Block types - stats {items:[{value, label, icon?}]} · steps {items:[{title, text}]} · timeline {items:[{when, title, text}]} ·
compare {left:{title, items}, right:{title, items}} · bars {items:[{label, value}], unit?} · donut {items:[{value, label}]} ·
list {items:[{title, text, icon?}]} · quote {text, by?} · takeaway {text, icon?}
Pictures (v7, pictures.py takes them in): image {src, caption?, alt?, frame: auto|browser|phone|plain, fit: contain|cover} ·
gallery {items:[{src, caption?, alt?}]} · feature {src, caption?, alt?, side: right|left, items:[{title, text, icon?}]} ·
band {label?, items:[{title, icon?}]} · flow {lanes:[{title, tone: before|after, items:[{title, icon?}]}]}. A spec's pictures are
kept once in spec['images'] (id -> the picture); blocks name them by id.
"""
import html, json, math, os, re, sys

HERE = os.path.dirname(os.path.abspath(__file__)); KIT = os.path.dirname(HERE)
sys.path.insert(0, KIT)
try:
    import themes as TH
except Exception:   # the kit layout is fixed; this keeps the module importable on its own
    TH = None

PX = 7620            # EMU per canvas unit: every format is drawn at 120 units per inch
INK, MUTED, LINE, GOLD = '000000', '404040', 'D9D9D9', 'FF893F'
TITLE = 'EE6C37'     # the template's headline colour
# v139: the brand's colours in turn, as Ulta's one-pagers have them - Ulta orange, raspberry, magenta, berry, red-orange: the numbered
# steps, the discs behind pictograms and the section marks take them by block and by item; the title and the message banner stay
# Ulta orange. (v136-v138 ran every element in oranges.) White reads on each.
PALETTE = ['F26923', 'E8275A', 'D01381', '5D0F43', 'E9341C']
TOP_RULE = ('EE6C37', 'E8275A')   # the page's top rule: Ulta orange into raspberry
# The Ulta look (v139): 'light' (the default) leads with a light orange gradient - the big shapes (a journey's stages, the message
# banner, a hub, a house) run from Ulta's light orange into Ulta orange with dark words on them, and the small marks (discs, badges,
# dots) take the brand's colours, each running into a deeper one of its family with a white pictogram (GRAD); 'gradient' runs the big
# shapes deep - Ulta orange into red-orange and raspberry - with white words; 'flat' draws the colours as they are, as Ulta's printed
# one-pagers have them. Template colours only: the brand pass keeps them.
GRAD = {'F26923': ('F26923', 'E9341C'), 'EE6C37': ('EE6C37', 'E9341C'), 'E9341C': ('E9341C', 'E0531B'), 'E0531B': ('E0531B', 'E9341C'),
        'F24C26': ('F24C26', 'E9341C'), 'E8275A': ('E8275A', 'DB0058'), 'D01381': ('D01381', 'C10060'), '5D0F43': ('C10060', '5D0F43'),
        'DB0058': ('DB0058', 'C10060'), 'C10060': ('C10060', '5D0F43')}
LOOKS = ('light', 'gradient', 'flat')
LOOK = ['light']   # the look in force while a design is laid out (set from the spec by _layout1)
# The light lead's stages: each starts light - where white words would not read, so every stage keeps the same dark words - and runs
# deeper stage by stage: light orange, then into Ulta orange, red-orange and on.
LIGHT_STAGES = [('FF893F', 'FF7826'), ('FF7826', 'F26923'), ('FF7826', 'F24C26'), ('FF7826', 'E9341C'), ('FF7826', 'E0531B')]
LIGHT_LEAD = ('FF893F', 'F26923')   # the banner, a hub's centre, a house's roof and base
# The Ulta theme is light (v136): an element that carries words (a card, a table head, the value band) is the pale orange with dark
# words; the message banner is Ulta orange with white words, set large enough for white to read there (v139).
LIGHT_CARD = 'FDE1D2'
PASTEL = {'F26923': 'FDE1D2', 'EE6C37': 'FDE1D2', 'E8275A': 'FAD3DB', 'D01381': 'E4C8DB', '5D0F43': 'E4C8DB', 'E9341C': 'F9E3DE',
          'E0531B': 'FDE1D2', 'F24C26': 'F9E3DE'}   # sunset's light ends (and the diagrams' pale circles)
DEEP = 'DB0058'      # the warmest colour white words read on: where sunset warms a deep colour, and what lights a velvet card
FILLED = ('ulta', 'sunset', 'velvet', 'charcoal')   # themes that fill their elements in colour (the others draw them light)
DISPLAY = "'Playfair Display Black','Playfair Display',Georgia,'Times New Roman',serif"
BODY = "'Circular Std','Circular Std Book',Circular,Inter,'Helvetica Neue',Helvetica,Arial,sans-serif"   # Inter (bundled) draws the previews where Circular is not installed
FONT_PPT = {'display': 'Playfair Display Black', 'body': 'Circular Std Book', 'bold': 'Circular Std Bold'}

FORMATS = {
    'slide':    {'name': 'Slide 16:9', 'blurb': 'One slide on the Ulta template - the headline is the template\'s own', 'w': 1600, 'h': 900, 'body': (60, 174, 1480, 620)},
    'onepager': {'name': 'One-pager', 'blurb': 'Letter portrait - print it or share it as a PDF', 'w': 1020, 'h': 1320, 'margin': 60},
    'square':   {'name': 'Social square', 'blurb': '1:1 for Workplace, Teams or LinkedIn posts', 'w': 1080, 'h': 1080, 'margin': 56},
}
FORMAT_ORDER = ['slide', 'onepager', 'square']
BLOCKS = {
    'stats': 'Big numbers with a label (2–4)', 'steps': 'A process in numbered steps (3–6)', 'timeline': 'Dates or phases on a line (3–7)',
    'compare': 'Before / after, today / target', 'bars': 'A bar chart from label + value pairs', 'donut': 'Percentages as rings (1–3)',
    'list': 'Points with a pictogram each', 'quote': 'A pull quote', 'takeaway': 'The one message to remember',
    'status': 'Status strip: overall RAG, week, phase, lead (2–5 facts)', 'rag': 'Workstreams: RAG, owner, this week, next week', 'risks': 'Risks & support required, with owner and date',
    'image': 'A picture: a UI screen or a product photo, with a caption', 'gallery': '2-4 pictures side by side, each with a caption',
    'feature': 'A picture beside its points: a UI concept and what it does', 'band': 'A coloured strip: a label and 2-5 short points (the value)',
    'flow': 'Today and tomorrow: one or two lanes of steps with pictograms',
    'stairs': 'A journey that climbs: each stage a step higher (2-5)', 'chevrons': 'A journey in arrows, each stage pointing to the next (2-5)',
    'pyramid': 'Layers that build on each other, the first at the base (2-5)', 'curve': 'Stages as dots on a rising curve (2-5)',
    'hub': 'One idea at the centre with its parts around it (2-8)', 'house': 'A vision on pillars: the roof, 1-6 pillars and the foundation',
    'cards': 'Points as tiles, each with a pictogram (2-9)', 'rings': 'Reach that widens: each stage a wider circle around the last (2-4)',
}
WIDE = {'stats', 'steps', 'timeline', 'compare', 'list', 'takeaway', 'status', 'rag', 'risks', 'gallery', 'feature', 'band', 'flow',
        'stairs', 'chevrons', 'pyramid', 'curve', 'hub', 'house', 'cards', 'rings'}
THEME_ORDER = ['ulta', 'glow', 'velvet', 'frost', 'paper', 'sunset', 'charcoal']


# ------------------------------------------------------------------------------------------------------------------ helpers
def tint(hex_, amount):
    r, g, b = (int(hex_[i:i + 2], 16) for i in (0, 2, 4)); f = lambda c: int(round(c + (255 - c) * amount))
    return f'{f(r):02X}{f(g):02X}{f(b):02X}'


def shade(hex_, amount):
    r, g, b = (int(hex_[i:i + 2], 16) for i in (0, 2, 4)); f = lambda c: int(round(c * (1 - amount)))
    return f'{f(r):02X}{f(g):02X}{f(b):02X}'


def clean(t, n=160):
    t = re.sub(r'\s+', ' ', re.sub(r'[*_`]+', '', str(t or ''))).strip()
    if len(t) <= n: return t
    sys.stderr.write(f'CUT\t{n}\t{t}\n')
    return t[:n - 1].rsplit(' ', 1)[0] + '…'


def icon_names():
    try: return [i['name'] for i in json.load(open(os.path.join(KIT, 'icons', 'icons.json'), encoding='utf-8'))['icons']]
    except Exception: return []


def pick_icon(text):
    try:
        from build_from_storyboard import pick_icon as _p
        return _p(text)
    except Exception: return 'idea'


_ICON_CACHE = {}
def icon_svg(name):
    """(viewBox, inner markup) of a template pictogram, ids stripped."""
    if name not in _ICON_CACHE:
        try: s = open(os.path.join(KIT, 'icons', name + '.svg'), encoding='utf-8').read()
        except Exception: _ICON_CACHE[name] = None; return None
        vb = (re.search(r'viewBox="([^"]+)"', s) or re.search(r'(x)', 'x')).group(1)
        inner = re.sub(r'^.*?<svg[^>]*>|</svg>\s*$', '', s, flags=re.S); inner = re.sub(r'\sid="[^"]*"', '', inner); inner = re.sub(r'<defs>\s*</defs>', '', inner)
        inner = re.sub(r'<style\b.*?</style>', '', inner, flags=re.S); inner = re.sub(r'\sclass="[^"]*"', '', inner)   # half the set colours itself by CSS (fill:#F16A1C) - CSS beats the recoloured fill attribute: an orange icon drawn as "white"
        _ICON_CACHE[name] = (vb, inner)
    return _ICON_CACHE[name]


def logo_svg():
    s = open(os.path.join(HERE, 'ulta-logo.svg'), encoding='utf-8').read()
    return re.search(r'viewBox="([^"]+)"', s).group(1), re.sub(r'<style>.*?</style>', '', re.sub(r'^.*?<svg[^>]*>|</svg>\s*$', '', s, flags=re.S), flags=re.S)


CW = {'display': 0.60, 'body': 0.50, 'bold': 0.54}   # average advance per character, as a share of the font size (conservative)
FONT_DIR = os.path.normpath(os.path.join(KIT, '..', '..', '..', '..', 'fonts'))   # the skill's bundled fonts (metrics.json is measured from them)
_MET = []; _UNITS = {}


def _units(s, font):
    """The width of s in the bundled face (Inter, Playfair Display) at 200 px in 1/64 px: advances plus pair kerning from
    metrics.json (font_metrics.py) - the same table the page's own editor measures with, so both lay out alike; None without it."""
    if not _MET:
        try: _MET.append(json.load(open(os.path.join(HERE, 'metrics.json'), encoding='utf-8'))['faces'])
        except Exception: _MET.append({})   # noqa: BLE001
    M = _MET[0].get(font)
    if not M: return None
    key = font + '\n' + s; u = _UNITS.get(key)
    if u is None:
        adv, kern, miss = M['adv'], M['kern'], M['miss']; u = 0; prev = ''
        for ch in s:
            u += adv.get(ch, miss)
            if prev: u += kern.get(prev + ch, 0)
            prev = ch
        if len(_UNITS) > 200000: _UNITS.clear()
        _UNITS[key] = u
    return u


def text_w(s, fs, font='body'):
    """The width of s at size fs: the larger of its real width in the preview face and the average-advance estimate, so a line
    fits the PNG / PDF / HTML previews and PowerPoint (Circular Std, narrower) alike. The estimate alone let bold table cells and
    upper-case headings run into the next column."""
    est = len(s) * fs * CW[font]
    u = _units(s, font)
    return max(est, u * fs / 12800) if u is not None else est


def _total(xs):
    """A left-to-right sum: Python 3.12 made sum() of floats compensated, which moved a few positions by 0.1 between Python
    versions; every version (and the page's own JavaScript engine) now adds up alike."""
    t = 0
    for x in xs: t += x
    return t


def wrap(text, w, fs, font='body'):
    words = str(text or '').split(); lines = []; cur = ''
    fits = lambda s: text_w(s, fs, font) <= w
    for wd in words:
        while len(wd) > 1 and not fits(wd):             # a word wider than the line breaks where it must
            if cur: lines.append(cur); cur = ''
            n = len(wd) - 1
            while n > 1 and not fits(wd[:n]): n -= 1
            lines.append(wd[:n]); wd = wd[n:]
        if not cur: cur = wd
        elif fits(cur + ' ' + wd): cur += ' ' + wd
        else: lines.append(cur); cur = wd
    if cur: lines.append(cur)
    return lines or ['']


HALF = {'table', 'list', 'risks', 'timeline', 'stats', 'compare', 'steps', 'donut', 'bars', 'quote', 'image'}   # can sit half-width beside another when squeezed
def _fl(): return MIN_FS[0] or 14   # the text floor in force (14 units = 8.4 pt; 13.4 when squeezed onto one slide)


SQUEEZE = [False]   # v6.13: a template squeezed onto one 16:9 slide (smaller floors)
MIN_FS = [0]   # v6.11: a template page sets a floor (14 units = 8.4 pt in the PowerPoint) for every fitted text while it is laid out
QUIET = [False]   # v139: while sizes are tried: a size that cuts text is not the one drawn, so only the final drawing reports a cut


def fit(text, w, h, hi, lo, font='body', lh=1.22, max_lines=None, report=True):
    """The largest size in [lo, hi] at which the text wraps inside w × h; (fs, lines)."""
    if MIN_FS[0]:   # a template: never under the floor and never cut - the text takes the lines it needs (the height grows)
        lo = max(lo, MIN_FS[0]); hi = max(hi, lo); h = max(h, len(wrap(text, w, lo, font)) * lo * lh); max_lines = None
    cap_ok = lambda s: all(text_w(x, s, font) <= w for x in str(text or '').split())   # no word broken mid-way ("30-m / in")
    for whole in (True, False):   # first the largest size that keeps every word whole; only if none does, a word may break
        fs = hi
        while fs >= lo:
            ls = wrap(text, w, fs, font)
            if (not whole or cap_ok(fs)) and len(ls) * fs * lh <= h and (not max_lines or len(ls) <= max_lines): return fs, ls
            fs -= 1
    ls = wrap(text, w, lo, font)
    n = max(1, int(h / (lo * lh))) if h else len(ls)
    if max_lines: n = min(n, max_lines)
    if len(ls) > n:
        if report and not QUIET[0]: sys.stderr.write(f'CUT\t{sum(len(x) + 1 for x in ls[:n])}\t{text}\n')
        ls = ls[:n]; ls[-1] = ls[-1].rstrip('.,;: ') + '…'
    return lo, ls


def _deep(c):
    """White words read on c (4.5:1): the template's raspberries, berry and plum - not its oranges and pinks."""
    return _contrast('FFFFFF', c) >= TEXT_NEED


def style(theme, c, role='card'):
    """How one coloured element looks in a theme: fill (or a gradient), line, and the ink on it. role 'card': it carries words, 'mark':
    it does not (a badge, an icon disc, a dot, a bar). A gradient never leaves the colour's family, so one ink reads along the whole
    element (v130). The Ulta theme is light (v136): words sit on the pale orange in dark ink, marks are the colour with white
    pictograms - running into a deeper one of its family (GRAD), or flat in the 'flat' look (v139); sunset puts words on gold running
    into the colour's pastel, in dark ink, and warms its marks into gold; velvet lights its dark cards with a colour white words read on."""
    t = theme if theme in THEME_ORDER else 'ulta'
    if t == 'ulta' and role == 'card':
        return {'fill': LIGHT_CARD, 'grad': None, 'stroke': None, 'glow': None, 'text': INK, 'sub': MUTED, 'head': INK, 'icon': 'E0531B', 'r': 14}
    if t == 'ulta':
        g = GRAD.get(c) if LOOK[0] != 'flat' else None
        return {'fill': g[0] if g else c, 'grad': g, 'stroke': None, 'glow': None, 'text': 'FFFFFF', 'sub': 'FFFFFF', 'head': 'FFFFFF', 'icon': 'FFFFFF', 'r': 14}
    if t == 'glow': return {'fill': 'FFFFFF', 'grad': None, 'stroke': 'EFE4DD', 'glow': tint(c, 0.72), 'text': INK, 'sub': MUTED, 'head': c, 'icon': c, 'r': 18}
    if t == 'velvet': return {'fill': INK, 'grad': (shade(c if _deep(c) else DEEP, 0.05), '231B18'), 'stroke': None, 'glow': None, 'text': 'FFFFFF', 'sub': 'F9E3DE', 'head': 'FFFFFF', 'icon': 'FFFFFF', 'r': 16}
    if t == 'frost': return {'fill': tint(c, 0.8), 'grad': None, 'stroke': 'FFFFFF', 'glow': None, 'text': INK, 'sub': '4A403B', 'head': shade(c, 0.12), 'icon': shade(c, 0.05), 'r': 22}
    if t == 'paper': return {'fill': 'FFFFFF', 'grad': None, 'stroke': c, 'glow': None, 'text': INK, 'sub': MUTED, 'head': c, 'icon': c, 'r': 8}
    if t == 'sunset' and role == 'card': return {'fill': GOLD, 'grad': (GOLD, PASTEL.get(c, 'FFF3ED')), 'stroke': None, 'glow': None, 'text': INK, 'sub': MUTED, 'head': '5D0F43', 'icon': '5D0F43', 'r': 16}
    if t == 'sunset': return {'fill': c, 'grad': (c, DEEP if _deep(c) else GOLD), 'stroke': None, 'glow': None, 'text': 'FFFFFF', 'sub': 'FFFFFF', 'head': 'FFFFFF', 'icon': 'FFFFFF', 'r': 16}
    return {'fill': '404040', 'grad': None, 'stroke': None, 'glow': None, 'text': 'FFFFFF', 'sub': 'E6DCD6', 'head': 'FFFFFF', 'icon': 'FFFFFF', 'r': 12}   # charcoal


def catalogue():
    th = getattr(TH, 'THEMES', {}) if TH else {}
    return {'formats': [{'id': k, 'name': FORMATS[k]['name'], 'blurb': FORMATS[k]['blurb'], 'w': FORMATS[k]['w'], 'h': FORMATS[k]['h']} for k in FORMAT_ORDER],
            'themes': [{'id': k, 'name': (th.get(k) or {}).get('label', k.title()), 'note': (th.get(k) or {}).get('note', ''),
                        'swatch': list(LIGHT_LEAD) if k == 'ulta' else style(k, PALETTE[0], 'mark')['grad'] or [style(k, PALETTE[0], 'mark')['fill']]} for k in THEME_ORDER],
            'blocks': [{'type': k, 'what': v} for k, v in BLOCKS.items()], 'icons': icon_names(), 'templates': TEMPLATES}


# ------------------------------------------------------------------------------------------------------------------ spec
def _items(v, keys, n=8):
    out = []
    for it in (v or [])[:n]:
        if isinstance(it, str):
            parts = [p.strip() for p in it.split('|')]; it = {k: (parts[i] if i < len(parts) else '') for i, k in enumerate(keys)}
        if not isinstance(it, dict): continue
        it = {k: clean(it.get(k), 90 if k in ('title', 'when', 'value', 'label') else 170) for k in keys if k != 'icon'} | ({'icon': it['icon']} if it.get('icon') in ICONS else {})
        if any(str(it.get(k) or '').strip() for k in keys if k != 'icon'): out.append(it)
    return out


ICONS = set(icon_names())


def num(v):
    m = re.search(r'-?\d[\d,]*(?:\.\d+)?', str(v or ''))
    try: return float(m.group(0).replace(',', '')) if m else None
    except Exception: return None


ICON_SIZE = {'s': 0.85, 'm': 1.0, 'l': 1.22}


def _ic(b):
    """(size factor, bold, badge) for the pictograms of block b - the infographic's icon options, passed down by layout()."""
    o = b.get('_ic') or {}
    return ICON_SIZE.get(o.get('size'), 1.0), o.get('weight') == 'bold', o.get('badge') or 'auto'


def normalise(spec):
    s = spec if isinstance(spec, dict) else {}
    out = {'title': clean(s.get('title'), 90) or 'Infographic', 'subtitle': clean(s.get('subtitle'), 180), 'kicker': clean(s.get('kicker'), 40).upper(),
           'source': clean(s.get('source'), 160), 'format': s.get('format') if s.get('format') in FORMATS else 'onepager',
           'theme': (TH.resolve(s.get('theme')) if TH else s.get('theme')) if s.get('theme') else 'ulta', 'blocks': []}
    if s.get('template') and re.fullmatch(r'[a-z_]{2,24}', str(s['template'])): out['template'] = s['template']   # free, status, or a templates.py id
    if out['theme'] not in THEME_ORDER: out['theme'] = 'ulta'
    if s.get('look') in LOOKS and s['look'] != 'light': out['look'] = s['look']   # v139: the Ulta look - light (default), gradient or flat
    io_ = s.get('icons') if isinstance(s.get('icons'), dict) else None
    if io_:   # how pictograms are drawn: size s | m | l, weight regular | bold, list badge auto | filled | light
        out['icons'] = {'size': io_.get('size') if io_.get('size') in ICON_SIZE else 'm', 'weight': 'bold' if io_.get('weight') == 'bold' else 'regular',
                        'badge': io_.get('badge') if io_.get('badge') in ('auto', 'filled', 'light') else 'auto'}
    for b in (s.get('blocks') or [])[:8]:
        if not isinstance(b, dict) or b.get('type') not in BLOCKS: continue
        t = b['type']; nb = {'type': t, 'title': clean(b.get('title'), 60)}
        if t == 'stats': nb['items'] = _items(b.get('items'), ['value', 'label', 'icon'], 4)
        elif t == 'steps': nb['items'] = _items(b.get('items'), ['title', 'text'], 6)
        elif t == 'timeline': nb['items'] = _items(b.get('items'), ['when', 'title', 'text'], 7)
        elif t == 'list': nb['items'] = _items(b.get('items'), ['title', 'text', 'icon'], 9)
        elif t == 'bars':
            nb['items'] = [it for it in _items(b.get('items'), ['label', 'value'], 8) if num(it.get('value')) is not None]; nb['unit'] = clean(b.get('unit'), 12)
        elif t == 'donut': nb['items'] = [it for it in _items(b.get('items'), ['value', 'label'], 3) if num(it.get('value')) is not None]
        elif t in ('status', 'rag', 'risks'):   # v6.9 status report: fields kept whole (up to 200 characters), RAG words normalised
            keys = {'status': ['label', 'value', 'rag'], 'rag': ['name', 'owner', 'rag', 'now', 'next'], 'risks': ['title', 'text', 'owner', 'due', 'rag']}[t]; nb['items'] = []
            for it in (b.get('items') or [])[:{'status': 5, 'rag': 10, 'risks': 6}[t]]:
                if isinstance(it, str): p_ = [q.strip() for q in it.split('|')]; it = {k_: (p_[i_] if i_ < len(p_) else '') for i_, k_ in enumerate(keys)}
                if not isinstance(it, dict): continue
                o_ = {k_: clean(it.get(k_), 200) for k_ in keys}
                if o_.get('rag'): o_['rag'] = rag_of(o_['rag']) or ''
                if any(o_[k_] for k_ in keys if k_ != 'rag'): nb['items'].append(o_)
            if t == 'rag': nb['cols'] = [clean(c_, 40) for c_ in (b.get('cols') or ['This week', 'Next week'])[:2]] + ['This week', 'Next week'][len((b.get('cols') or [])[:2]):]
        elif t == 'table':   # v6.11 templates: any header + rows (cells kept whole up to 160 characters)
            nb['cols'] = [clean(c_, 40) for c_ in (b.get('cols') or [])[:6]]; n_ = len(nb['cols']); nb['icons'] = bool(b.get('icons'))
            nb['items'] = [[clean(c_, 160) for c_ in (list(r_) + [''] * n_)[:n_]] for r_ in (b.get('items') or [])[:10] if isinstance(r_, (list, tuple)) and any(str(c_).strip() for c_ in r_)]
            if not n_ or not nb['items']: continue
        elif t == 'ragcards':
            nb['items'] = []
            for it in (b.get('items') or [])[:9]:
                if isinstance(it, str): p_ = [q.strip() for q in it.split('|')]; it = dict(zip(('name', 'owner', 'rag', 'text'), p_ + [''] * 4))
                if isinstance(it, dict) and str(it.get('name') or '').strip(): nb['items'].append({k_: clean(it.get(k_), 420 if k_ == 'text' else 200) for k_ in ('name', 'owner', 'text')} | {'rag': rag_of(it.get('rag'))})   # this week + next week fit whole
        elif t == 'compare':
            for side in ('left', 'right'):
                v = b.get(side) if isinstance(b.get(side), dict) else {}
                nb[side] = {'title': clean(v.get('title'), 40) or ('Today' if side == 'left' else 'Target'), 'items': [clean(x, 140) for x in (v.get('items') or [])[:6] if clean(x)]}
            if not nb['left']['items'] and not nb['right']['items']: continue
        elif t == 'quote':
            nb['text'] = clean(b.get('text'), 240); nb['by'] = clean(b.get('by'), 60)
            if not nb['text']: continue
        elif t == 'takeaway':
            nb['text'] = clean(b.get('text'), 220)
            if b.get('icon') in ICONS: nb['icon'] = b['icon']
            if not nb['text']: continue
        elif t in ('image', 'feature'):
            nb.update(_picture_fields(b))
            if t == 'feature':
                nb['side'] = 'left' if b.get('side') == 'left' else 'right'; nb['items'] = _items(b.get('items'), ['title', 'text', 'icon'], 6)
                if not nb['items']: nb['type'] = 'image'; del nb['items'], nb['side']   # no points: the picture alone
            if not nb['src']: continue
        elif t == 'gallery':
            nb['items'] = [_picture_fields(it) for it in (b.get('items') or [])[:4] if isinstance(it, dict)]
            nb['items'] = [it for it in nb['items'] if it['src']]
            for it in nb['items']: it.pop('frame', None); it.pop('fit', None)
            nb['fit'] = b.get('fit') if b.get('fit') in ('contain', 'cover') else ''
        elif t == 'band':
            nb['label'] = clean(b.get('label'), 30); nb['items'] = _items(b.get('items'), ['title', 'icon'], 5)
        elif t in ('stairs', 'chevrons', 'pyramid', 'curve', 'rings'): nb['items'] = _items(b.get('items'), ['when', 'title', 'text', 'icon'], 4 if t == 'rings' else 5)   # v139: ways to tell it
        elif t in ('hub', 'cards'):
            nb['items'] = _items(b.get('items'), ['title', 'text', 'icon'], 8 if t == 'hub' else 9)
            if t == 'hub': nb['center'] = clean(b.get('center'), 80)
        elif t == 'house':
            nb['roof'] = clean(b.get('roof'), 200); nb['base'] = clean(b.get('base'), 200); nb['items'] = _items(b.get('items'), ['title', 'text', 'icon'], 6)
            if b.get('icon') in ICONS: nb['icon'] = b['icon']
        elif t == 'flow':
            nb['lanes'] = []
            for ln in (b.get('lanes') or [])[:2]:
                if not isinstance(ln, dict): continue
                its = _items(ln.get('items'), ['title', 'icon'], 6)
                if its: nb['lanes'].append({'title': clean(ln.get('title'), 60), 'tone': ln.get('tone') if ln.get('tone') in ('before', 'after') else '', 'items': its})
            if not nb['lanes']: continue
        if 'items' in nb and not nb['items']: continue
        if b.get('half') is True: nb['half'] = True   # v139: shares its row with the next block marked half
        out['blocks'].append(nb)
    imgs = s.get('images') if isinstance(s.get('images'), dict) else {}
    used = [r_ for b in out['blocks'] for r_ in [b.get('src')] + [it.get('src') for it in (b.get('items') or []) if b['type'] == 'gallery'] if r_ in imgs]
    if used: out['images'] = {r_: imgs[r_] for r_ in dict.fromkeys(used)}   # the pictures the blocks show, each once
    return out


def _picture_fields(b):
    """A picture's fields as a block (or a gallery item) gives them: src (the picture's id, or a file name still to take in),
    caption, alt text (kept only when given: drawn, the caption or the title stands in, so an edited caption is never
    contradicted by an old description), frame and fit."""
    src = str(b.get('src') or b.get('image') or b.get('picture') or '').strip()[:400]
    cap = clean(b.get('caption'), 160)
    return {'src': src, 'caption': cap, 'alt': clean(b.get('alt'), 160),
            'frame': b.get('frame') if b.get('frame') in ('auto', 'browser', 'phone', 'plain') else 'auto',
            'fit': b.get('fit') if b.get('fit') in ('contain', 'cover') else ''}


# ------------------------------------------------------------------------------------------------------------------ rules (AI off)
NUMTOK = re.compile(r'(?:[$£€])?\d[\d,]*(?:\.\d+)?\s*(?:%|percent|pts?|k|m|bn|x|\+)?(?![\w])', re.I)
STAT_ICONS = ['trend-up', 'target', 'performance', 'award']
SEQ_WORDS = re.compile(r'\b(steps?|process|how|phases?|stages?|approach|journey|plan|roadmap|rollout|way forward|next steps)\b', re.I)
TIME_TOK = re.compile(r'^\s*((?:Q[1-4]|H[12])(?:\s*(?:FY)?\s*\d{2,4})?|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s*\d{0,4}|(?:19|20)\d{2}|Week\s*\d+|Wave\s*\d+|Phase\s*\d+|Day\s*\d+)\s*[:\-–—]\s*', re.I)
TAKE_WORDS = re.compile(r'\b(ask|takeaway|key message|bottom line|summary|decision|conclusion|why it matters|so what)\b', re.I)
CMP_WORDS = re.compile(r'\b(before|after|today|target|current|future|as[- ]is|to[- ]be|from|vs\.?|versus)\b', re.I)


def _pct(tok):
    return re.sub(r'\s*percent', '%', tok.strip(), flags=re.I)


def _stat(line):
    toks = [t.strip() for t in NUMTOK.findall(line) if re.search(r'\d', t)]
    if not toks: return None
    if len(toks) >= 2 and re.search(r'\bfrom\b.*\bto\b|→|->', line, re.I): value = f'{_pct(toks[0])} → {_pct(toks[1])}'
    else: value = _pct(toks[0])
    label = line
    if '→' in value: label = re.sub(r'\s*\bfrom\b\s*' + re.escape(toks[0]) + r'.*?\bto\b\s*' + re.escape(toks[1]) + r'\s*', ' ', label, flags=re.I)
    elif label.strip().lower().startswith(toks[0].lower()): label = label.strip()[len(toks[0]):]
    label = re.sub(r'\s+', ' ', label).strip(' ,.;:-–—')
    if len(label.split()) < 2: label = line
    return {'value': value, 'label': clean(cap(label), 120)}


def cap(s):
    s = str(s or '').strip()
    return s[:1].upper() + s[1:] if s else s


PIC_LINE = re.compile(r'^!\[([^\]]*)\]\((.+?)\)\s*$')   # ![caption](file) - Markdown's picture line


def _pic_line(l):
    """{'src', 'caption'} for a Markdown picture line ("![The new screen](/mnt/data/screen.png)"), else None."""
    m = PIC_LINE.match(l)
    if not m: return None
    src = re.sub(r'\s+"[^"]*"$', '', m.group(2).strip()).strip().strip('<>').strip()
    return {'src': src, 'caption': clean(m.group(1), 160)} if src else None


def _sections(text):
    lines = [l.rstrip() for l in str(text or '').replace('\r', '').split('\n')]
    title = subtitle = source = ''; secs = []; cur = None; sub = None
    for raw in lines:
        l = raw.strip()
        if not l: continue
        pl = _pic_line(l)
        if pl:   # a picture belongs to the section it is in (before any heading: a section of its own)
            if cur is None: cur = {'title': '', 'bullets': [], 'paras': [], 'rows': [], 'subs': [], 'ordered': False}; secs.append(cur)
            cur.setdefault('pics', []).append(pl); continue
        if re.match(r'^(source|sources|data)\s*:', l, re.I): source = re.sub(r'^\w+\s*:\s*', '', l); continue
        m = re.match(r'^(#{1,4})\s+(.*)', l)
        if m:
            lvl, h = len(m.group(1)), clean(m.group(2), 90)
            if lvl == 1 and not title: title = h; continue
            if lvl >= 3 and cur is not None: sub = {'title': h, 'items': []}; cur['subs'].append(sub); continue
            cur = {'title': h, 'bullets': [], 'paras': [], 'rows': [], 'subs': [], 'ordered': False}; secs.append(cur); sub = None; continue
        if not title: title = clean(re.sub(r'^[-*•]\s*', '', l), 90); continue
        if cur is None:
            if not subtitle and not re.match(r'^([-*•]|\d+[.)]|\|)', l): subtitle = clean(l, 180); continue
            cur = {'title': '', 'bullets': [], 'paras': [], 'rows': [], 'subs': [], 'ordered': False}; secs.append(cur)
        if l.startswith('|'):
            cells = [c.strip() for c in l.strip('|').split('|')]
            if not all(re.fullmatch(r':?-{2,}:?', c) for c in cells if c): cur['rows'].append(cells)
            continue
        b = re.match(r'^([-*•]|\d+[.)])\s+(.*)', l)
        if b:
            if b.group(1)[0].isdigit(): cur['ordered'] = True
            (sub['items'] if sub is not None else cur['bullets']).append(clean(b.group(2), 170)); continue
        if l.startswith('>'): cur['paras'].append('> ' + clean(l.lstrip('> '), 240)); continue
        if l.endswith(':') and len(l) < 70: cur = {'title': clean(l[:-1], 90), 'bullets': [], 'paras': [], 'rows': [], 'subs': [], 'ordered': False}; secs.append(cur); sub = None; continue
        (sub['items'] if sub is not None else cur['paras']).append(clean(l, 240))
    return title, subtitle, source, secs


def rules_spec(text, fmt='onepager', theme='ulta', title=''):
    """Headings become blocks; what is under them picks the block: a table with numbers → bars, two sub-headings → compare, numbers in most
    bullets → stats (percentages alone → rings), dated lines → timeline, an ordered list or a process heading → steps, one sentence → takeaway
    or quote, anything else → a list with a pictogram per point."""
    t0, subtitle, source, secs = _sections(text)
    blocks = []
    for i, s in enumerate(secs):
        h, bl, ps, rows = s['title'], s['bullets'], s['paras'], s['rows']
        pics = s.get('pics') or []
        if pics:   # pictures: one beside its points, one alone, or two to four side by side
            if len(pics) == 1 and bl: blocks.append({'type': 'feature', 'title': h, 'src': pics[0]['src'], 'caption': pics[0]['caption'], 'items': _points(bl)[:6]}); continue
            if len(pics) == 1: blocks.append({'type': 'image', 'title': h, 'src': pics[0]['src'], 'caption': pics[0]['caption'] or ' '.join(ps)[:160]}); continue
            blocks.append({'type': 'gallery', 'title': h, 'items': [{'src': p_['src'], 'caption': p_['caption']} for p_ in pics[:4]]})
            if bl: blocks.append({'type': 'list', 'title': '', 'items': _points(bl)})
            continue
        if len(s['subs']) == 2 and all(FLOW_SIDES[j].search(s['subs'][j]['title'] or '') for j in (0, 1)) and \
                all(2 <= len(x['items']) <= 6 and all(len(t.split()) <= 7 for t in x['items']) for x in s['subs']):   # today -> tomorrow, in short steps
            blocks.append({'type': 'flow', 'title': h, 'lanes': [{'title': x['title'], 'tone': ('before', 'after')[j], 'items': [{'title': t} for t in x['items']]} for j, x in enumerate(s['subs'])]}); continue
        if len(rows) >= 3 and all(len(r) >= 2 for r in rows[1:]) and sum(num(r[1]) is not None for r in rows[1:]) >= max(2, len(rows[1:]) - 1):
            unit = '%' if all('%' in r[1] for r in rows[1:] if r[1]) else ''
            blocks.append({'type': 'bars', 'title': h or rows[0][1], 'unit': unit, 'items': [{'label': r[0], 'value': r[1]} for r in rows[1:] if num(r[1]) is not None]}); continue
        if len(s['subs']) == 2:
            a, b = s['subs']; blocks.append({'type': 'compare', 'title': h, 'left': {'title': a['title'], 'items': a['items']}, 'right': {'title': b['title'], 'items': b['items']}}); continue
        if bl:
            times = [TIME_TOK.match(x) for x in bl]
            if len(bl) >= 3 and sum(1 for m in times if m) >= len(bl) - 1:
                items = []
                for x, m in zip(bl, times):
                    rest = x[m.end():] if m else x; tt, _, tx = rest.partition(' — ') if ' — ' in rest else rest.partition(': ')
                    items.append({'when': m.group(1) if m else '', 'title': cap(clean(tt, 60)), 'text': cap(clean(tx, 140))})
                blocks.append({'type': 'timeline', 'title': h, 'items': items}); continue
            stats = [_stat(x) for x in bl]
            if 2 <= len(bl) <= 4 and sum(1 for x in stats if x) >= len(bl) - (0 if len(bl) == 2 else 1) and all(len(x) <= 110 for x in bl):
                vals = [x for x in stats if x]
                if len(vals) <= 3 and all(re.fullmatch(r'\d+(?:\.\d+)?%', v['value']) and num(v['value']) <= 100 for v in vals):
                    blocks.append({'type': 'donut', 'title': h, 'items': vals}); continue
                blocks.append({'type': 'stats', 'title': h, 'items': [dict(v, icon=pick_icon(v['label']) or STAT_ICONS[j % 4]) for j, v in enumerate(vals)]}); continue
            if VALUE_WORDS.search(h or '') and 2 <= len(bl) <= 5 and all(len(x.split()) <= 6 and ': ' not in x for x in bl):   # the value, in a band
                blocks.append({'type': 'band', 'label': h, 'items': [{'title': cap(clean(x, 60))} for x in bl]}); continue
            if (s['ordered'] or SEQ_WORDS.search(h or '')) and 3 <= len(bl) <= 6:
                items = []
                for x in bl:
                    a, sep, b = x.partition(': ') if ': ' in x else x.partition(' — ')
                    items.append({'title': cap(clean(a, 50)), 'text': cap(clean(b, 140))} if sep and len(a) <= 50 else {'title': cap(clean(' '.join(x.split()[:4]), 50)), 'text': cap(clean(x, 140))})
                blocks.append({'type': 'steps', 'title': h, 'items': items}); continue
            items = []
            for x in bl[:9]:
                a, sep, b = x.partition(': ') if ': ' in x else x.partition(' — ')
                items.append({'title': clean(a, 50), 'text': clean(b, 140), 'icon': pick_icon(x)} if sep and len(a) <= 50 else {'title': '', 'text': clean(x, 150), 'icon': pick_icon(x)})
            if all(not it['title'] for it in items):   # plain bullets: the first few words carry the point, the rest explains it
                for it in items:
                    w = it['text'].split(); it['title'] = ' '.join(w[:5]).rstrip('.,;:') if len(w) > 7 else it['text']; it['text'] = ' '.join(w[5:]) if len(w) > 7 else ''
            blocks.append({'type': 'list', 'title': h, 'items': items}); continue
        if ps:
            p = ps[0]
            if p.startswith('> ') or p[:1] in '“"': blocks.append({'type': 'quote', 'title': h, 'text': p.lstrip('> ').strip('“”"'), 'by': ps[1] if len(ps) > 1 and len(ps[1]) < 60 else ''}); continue
            blocks.append({'type': 'takeaway', 'title': '' if TAKE_WORDS.search(h or '') or i == len(secs) - 1 else h, 'text': ' '.join(ps)[:220], 'icon': 'target'}); continue
    if not blocks and subtitle: blocks.append({'type': 'takeaway', 'text': subtitle}); subtitle = ''
    return normalise({'title': title or t0, 'subtitle': subtitle, 'source': source, 'format': fmt, 'theme': theme, 'blocks': blocks})


FLOW_SIDES = (re.compile(r'\b(today|current|now|before|as[- ]is|manual|old)\b', re.I), re.compile(r'\b(tomorrow|future|next|after|to[- ]be|target|digital|new)\b', re.I))
VALUE_WORDS = re.compile(r'\b(value|benefits?|outcomes?|why it matters|what we gain|gains)\b', re.I)


def _points(bl):
    """Bullets as points with a pictogram each: "Lead: detail" splits, a plain line keeps its first words as the lead."""
    items = []
    for x in bl[:9]:
        a, sep, b = x.partition(': ') if ': ' in x else x.partition(' — ')
        items.append({'title': clean(a, 50), 'text': clean(b, 140), 'icon': pick_icon(x)} if sep and len(a) <= 50 else {'title': '', 'text': clean(x, 150), 'icon': pick_icon(x)})
    if all(not it['title'] for it in items):
        for it in items:
            w = it['text'].split(); it['title'] = ' '.join(w[:5]).rstrip('.,;:') if len(w) > 7 else it['text']; it['text'] = ' '.join(w[5:]) if len(w) > 7 else ''
    return items


def sample_spec(fmt='onepager', theme='ulta'):
    return normalise({'title': 'Supply protection pilot', 'kicker': 'B2B · Q3 update', 'subtitle': 'Protected stock kept launch SKUs on shelf for priority partners.', 'format': fmt, 'theme': theme,
                      'source': 'Sample content - replace it with yours',
                      'blocks': [{'type': 'stats', 'items': [{'value': '14% → 4%', 'label': 'Shortfalls on launch SKUs', 'icon': 'trend-up'}, {'value': '120', 'label': 'Articles protected across 3 DCs', 'icon': 'package'}, {'value': '400', 'label': 'More articles next wave', 'icon': 'growth-check'}]},
                                 {'type': 'steps', 'title': 'How it works', 'items': [{'title': 'Reserve', 'text': 'Stock is held for priority partners'}, {'title': 'Review', 'text': 'Unused protection is checked weekly'}, {'title': 'Release', 'text': 'Surplus returns to open demand'}]},
                                 {'type': 'takeaway', 'text': 'Extend protection to the next 400 articles before the holiday peak.', 'icon': 'target'}]})


# ------------------------------------------------------------------------------------------------------------------ layout
class Canvas:
    def __init__(self): self.els = []; self.warn = []
    def rect(self, x, y, w, h, fill=None, stroke=None, r=0, sw=1, grad=None, name='box', **kw):
        self.els.append({'k': 'rect', 'x': round(x, 1), 'y': round(y, 1), 'w': round(w, 1), 'h': round(h, 1), 'fill': fill, 'stroke': stroke, 'r': r, 'sw': sw, 'grad': list(grad) if grad else None, 'name': name, **kw})
    def text(self, x, y, w, lines, fs, color, font='body', align='left', lh=1.22, name='text', src=None, **kw):
        h = len(lines) * fs * lh
        self.els.append({'k': 'text', 'x': round(x, 1), 'y': round(y, 1), 'w': round(w, 1), 'h': round(h, 1), 'lines': lines, 't': src if src is not None else ' '.join(lines), 'fs': round(fs, 1), 'color': color, 'font': font, 'align': align, 'lh': lh, 'name': name, **kw})
        return h
    def ellipse(self, x, y, w, h, fill=None, stroke=None, sw=1, name='dot', **kw):
        self.els.append({'k': 'ellipse', 'x': round(x, 1), 'y': round(y, 1), 'w': round(w, 1), 'h': round(h, 1), 'fill': fill, 'stroke': stroke, 'sw': sw, 'name': name, **kw})
    def line(self, x1, y1, x2, y2, color, sw=2, dash=False, name='line', **kw):
        self.els.append({'k': 'line', 'x1': round(x1, 1), 'y1': round(y1, 1), 'x2': round(x2, 1), 'y2': round(y2, 1), 'color': color, 'sw': sw, 'dash': dash, 'name': name, **kw})
    def icon(self, name, x, y, s, color, **kw):
        if name and icon_svg(name): self.els.append({'k': 'icon', 'name': name, 'x': round(x, 1), 'y': round(y, 1), 's': round(s, 1), 'color': color, **kw})
    def poly(self, pts, fill, stroke=None, sw=1, name='shape', **kw):
        self.els.append({'k': 'poly', 'pts': [(round(x, 1), round(y, 1)) for x, y in pts], 'fill': fill, 'stroke': stroke, 'sw': sw, 'name': name, **kw})
    def image(self, x, y, w, h, ref, fit='contain', r=0, name='picture', alt='Picture', **kw):
        self.els.append({'k': 'image', 'x': round(x, 1), 'y': round(y, 1), 'w': round(w, 1), 'h': round(h, 1), 'ref': ref, 'fit': fit, 'r': round(r, 1), 'name': name, 'alt': alt, **kw})
    def arc(self, cx, cy, r, sw, frac, color, track, **kw):
        self.els.append({'k': 'arc', 'cx': round(cx, 1), 'cy': round(cy, 1), 'r': round(r, 1), 'sw': round(sw, 1), 'frac': max(0.0, min(1.0, frac)), 'color': color, 'track': track, **kw})


def card(cv, x, y, w, h, st, name='card'):
    if st.get('glow'): cv.rect(x + 2, y + 7, w - 4, h, st['glow'], None, st['r'] + 2, name=name + ' glow')
    cv.rect(x, y, w, h, st['fill'], st['stroke'], st['r'], 1.5 if st['stroke'] else 1, st['grad'], name=name)


def block_title(cv, b, x, y, w, k, accent):
    if not b.get('title'): return 0
    cv.rect(x, y + 3 * k, 5 * k, 22 * k, accent, None, 2, name='title bar')
    fs, ls = fit(b['title'], w - 16 * k, 60 * k, round(21 * k), round(15 * k), 'bold', max_lines=2)
    return cv.text(x + 15 * k, y, w - 16 * k, ls, fs, INK, 'bold', name='block title', src=b['title']) + 12 * k


def card_icon(cv, name, x, y, s, colour, theme, bold, disc=None):
    """A card's pictogram in an s-square: on the Ulta theme in a disc - of the colour `disc` with a white pictogram (a big number's
    icon, v138), else white with the deep orange one (the decision) - elsewhere drawn straight on the card in the theme's icon colour."""
    if theme == 'ulta' and disc:
        st = style('ulta', disc, 'mark'); cv.ellipse(x, y, s, s, st['fill'], None, name='card icon disc', grad=st['grad'])
        cv.icon(name, x + s * 0.2, y + s * 0.2, s * 0.6, 'FFFFFF', bold=bold)
    elif theme == 'ulta': cv.ellipse(x, y, s, s, 'FFFFFF', None, name='card icon disc'); cv.icon(name, x + s * 0.2, y + s * 0.2, s * 0.6, 'E0531B', bold=bold)
    else: cv.icon(name, x, y, s, colour, bold=bold)


def draw_stats(cv, b, x, y, w, k, theme, ci):
    its = b['items']; n = len(its); g = 16 * k; cw = (w - g * (n - 1)) / n; pad = 20 * k
    parts = []
    for i, it in enumerate(its):
        c = PALETTE[(ci + i) % len(PALETTE)]; st = style(theme, c)
        vfs, vls = fit(it['value'], cw - 2 * pad, 130 * k, round(54 * k), round(24 * k), 'display', 1.08, 2)
        lfs, lls = fit(it['label'], cw - 2 * pad, 96 * k, round(16 * k), round(12 * k), 'body', 1.3, 4)
        f_, bold_, _ = _ic(b); ih = (40 * k * f_ + 12 * k) if it.get('icon') else 0
        parts.append((c, st, vfs, vls, lfs, lls, ih))
    ch = max(pad * 2 + p[6] + len(p[3]) * p[2] * 1.08 + 8 * k + len(p[5]) * p[4] * 1.3 for p in parts)
    for i, (it, p) in enumerate(zip(its, parts)):
        c, st, vfs, vls, lfs, lls, ih = p; cx = x + i * (cw + g); card(cv, cx, y, cw, ch, st, 'stat card'); yy = y + pad
        if ih: f_, bold_, _ = _ic(b); card_icon(cv, it['icon'], cx + pad, yy, 40 * k * f_, st['icon'], theme, bold_, c); yy += ih
        yy += cv.text(cx + pad, yy, cw - 2 * pad, vls, vfs, st['head'] if theme != 'ulta' else 'E9341C', 'display', lh=1.08, name='stat value', src=it['value']) + 8 * k
        cv.text(cx + pad, yy, cw - 2 * pad, lls, lfs, st['sub'], 'body', lh=1.3, name='stat label', src=it['label'])
    return ch


def rule(cv, x, y, w, sw, colour, theme, name):
    """The line that strings steps and dates together, centred on y: a pale line in the block's colour (v139: on the Ulta theme too)."""
    cv.line(x, y, x + w, y, colour, sw, name=name)


def draw_steps(cv, b, x, y, w, k, theme, ci):
    its = b['items']; n = len(its); colw = w / n; d = 58 * k; cy = y + d / 2
    rule(cv, x + colw / 2, cy, w - colw, 4 * k, tint(PALETTE[ci % 5], 0.55), theme, 'steps line')
    hmax = 0; tex = []
    for i, it in enumerate(its):
        tfs, tls = fit(it['title'], colw - 20 * k, 60 * k, round(17 * k), round(13 * k), 'bold', 1.2, 2)
        xfs, xls = fit(it.get('text', ''), colw - 20 * k, 110 * k, round(14 * k), round(11 * k), 'body', 1.32, 5) if it.get('text') else (0, [])
        tex.append((tfs, tls, xfs, xls)); hmax = max(hmax, len(tls) * tfs * 1.2 + (8 * k + len(xls) * xfs * 1.32 if xls else 0))
    for i, (it, (tfs, tls, xfs, xls)) in enumerate(zip(its, tex)):
        c = PALETTE[(ci + i) % 5]; st = style(theme, c, 'mark' if theme == 'ulta' else 'card'); mx = x + i * colw + colw / 2   # the Ulta dot: a solid orange mark
        if theme == 'ulta' and LOOK[0] == 'light': f_, g_, _, ink_, _ = _stage(theme, i); st = dict(st, fill=f_, grad=g_, head=ink_)   # v139: the light lead
        if st.get('glow'): cv.ellipse(mx - d / 2 - 3 * k, y - 3 * k + 5 * k, d + 6 * k, d + 6 * k, st['glow'], name='step glow')
        cv.ellipse(mx - d / 2, y, d, d, st['fill'] if not st['grad'] else st['grad'][0], st['stroke'], 2 if st['stroke'] else 1, name='step dot', grad=st['grad'])
        nfs = max(30, round(30 * k))   # never under 18 pt: a number on an orange dot is white, and white reads there at 3:1 from 18 pt
        cv.text(mx - d / 2, y + d / 2 - nfs * 0.54, d, [str(i + 1)], nfs, st['head'] if theme != 'ulta' or st['head'] == INK else 'FFFFFF', 'display', 'center', 1.08, name='step number', **_dk(st['head']))
        yy = y + d + 14 * k
        yy += cv.text(x + i * colw + 10 * k, yy, colw - 20 * k, tls, tfs, INK, 'bold', 'center', 1.2, name='step title', src=it['title'])
        if xls: cv.text(x + i * colw + 10 * k, yy + 8 * k, colw - 20 * k, xls, xfs, MUTED, 'body', 'center', 1.32, name='step text', src=it['text'])
    return d + 14 * k + hmax


def draw_timeline(cv, b, x, y, w, k, theme, ci):
    its = b['items']; n = len(its); colw = w / n; wh = 26 * k; ly = y + wh + 12 * k; c0 = PALETTE[ci % 5]
    rule(cv, x, ly, w, 4 * k, tint(c0, 0.5), theme, 'timeline line'); hmax = 0; tex = []
    for it in its:
        tfs, tls = fit(it.get('title', ''), colw - 16 * k, 44 * k, round(16 * k), round(12 * k), 'bold', 1.2, 2)
        xfs, xls = fit(it.get('text', ''), colw - 16 * k, 100 * k, round(13.5 * k), round(11 * k), 'body', 1.32, 5) if it.get('text') else (0, [])
        tex.append((tfs, tls, xfs, xls)); hmax = max(hmax, len(tls) * tfs * 1.2 + (6 * k + len(xls) * xfs * 1.32 if xls else 0))
    for i, (it, (tfs, tls, xfs, xls)) in enumerate(zip(its, tex)):
        c = PALETTE[(ci + i) % 5]; st = style(theme, c, 'mark'); cx = x + i * colw + 8 * k
        if theme == 'ulta' and LOOK[0] == 'light': f_, g_, *_ = _stage(theme, i); st = dict(st, fill=f_, grad=g_); c = INK   # v139: the light lead, dark labels
        wfs, wls = fit(it.get('when', ''), colw - 16 * k, wh, round(17 * k), round(11 * k), 'bold', 1.1, 1)
        cv.text(cx, y, colw - 16 * k, wls, wfs, c if theme not in ('charcoal',) else INK, 'bold', lh=1.1, name='timeline when', src=it.get('when', ''))
        cv.ellipse(cx, ly - 9 * k, 18 * k, 18 * k, st['fill'] if not st['grad'] else st['grad'][0], 'FFFFFF', 3, name='timeline dot', grad=st['grad'])
        yy = ly + 22 * k
        yy += cv.text(cx, yy, colw - 16 * k, tls, tfs, INK, 'bold', lh=1.2, name='timeline title', src=it.get('title', ''))
        if xls: cv.text(cx, yy + 6 * k, colw - 16 * k, xls, xfs, MUTED, 'body', lh=1.32, name='timeline text', src=it['text'])
    return wh + 12 * k + 22 * k + hmax


def draw_compare(cv, b, x, y, w, k, theme, ci):
    gap = 70 * k; cw = (w - gap) / 2; pad = 20 * k; hh = 46 * k
    left = (dict(style('ulta', TITLE), fill='F2F2F2') if theme == 'ulta' else style('charcoal', INK) if theme in FILLED else style('paper', '404040'))   # Ulta: a pale grey head beside the pale orange
    sides = [(b['left'], left), (b['right'], style(theme, PALETTE[ci % 5]))]
    lays = []; fs = max(15 * k, MIN_FS[0]); tfs = max(round(17 * k), MIN_FS[0])   # a template's floor applies here too
    for side, st in sides:
        rows = [wrap(t, cw - 2 * pad - 22 * k, fs, 'body') for t in side['items']]; lays.append(rows)
    ih = max(_total(len(r) * fs * 1.32 + 8 * k for r in rows) for rows in lays) if any(lays) else 0
    ch = hh + pad + ih + pad - 8 * k
    for j, ((side, st), rows) in enumerate(zip(sides, lays)):
        cx = x + j * (cw + gap)
        cv.rect(cx, y, cw, ch, 'FFFFFF' if theme != 'frost' else tint(PALETTE[ci % 5], 0.9), LINE, 16, 1.2, name='compare card')
        cv.rect(cx, y, cw, hh, st['fill'], st['stroke'], 16, 1.5 if st['stroke'] else 1, st['grad'], name='compare head')
        cv.text(cx + pad, y + hh / 2 - tfs * 0.6, cw - 2 * pad, [side['title']], tfs, st['head'] if st['fill'] != 'FFFFFF' else st['head'], 'bold', lh=1.2, name='compare title', src=side['title'])
        yy = y + hh + pad; mark = PALETTE[ci % 5] if j else '404040'
        for t, ls in zip(side['items'], rows):
            cv.ellipse(cx + pad, yy + 5 * k, 10 * k, 10 * k, mark, name='compare mark')
            yy += cv.text(cx + pad + 22 * k, yy, cw - 2 * pad - 22 * k, ls, fs, INK, 'body', lh=1.32, name='compare item', src=t) + 8 * k
    ax = x + cw + gap / 2; ay = y + ch / 2; c = PALETTE[ci % 5]
    sc = sides[1][1] if theme in ('sunset', 'velvet', 'charcoal') else style('ulta', c, 'mark')   # the arrow on its disc: a filled card's own run, else an orange mark
    cv.ellipse(ax - 22 * k, ay - 22 * k, 44 * k, 44 * k, sc['fill'], 'FFFFFF', 3, name='compare arrow', grad=sc['grad'])
    cv.text(ax - 22 * k, ay - 14 * k, 44 * k, ['→'], round(22 * k), 'FFFFFF', 'bold', 'center', 1.2, name='compare arrow text')   # a mark (DOTS), not words
    return ch


def draw_bars(cv, b, x, y, w, k, theme, ci):
    its = b['items']; vals = [num(it['value']) or 0 for it in its]; mx = max(vals + [1e-9]); lw = w * 0.34; vw = 76 * k; bw = w - lw - vw - 12 * k; rh = 38 * k; c = PALETTE[ci % 5]
    st = style(theme, c, 'mark')
    for i, (it, v) in enumerate(zip(its, vals)):
        yy = y + i * rh; lfs, lls = fit(it['label'], lw - 12 * k, rh - 6 * k, round(14.5 * k), round(11 * k), 'body', 1.15, 2)
        cv.text(x, yy + (rh - len(lls) * lfs * 1.15) / 2 - 2 * k, lw - 12 * k, lls, lfs, INK, 'body', lh=1.15, name='bar label', src=it['label'])
        cv.rect(x + lw, yy + rh / 2 - 10 * k, bw, 20 * k, tint(c, 0.88), None, 10 * k, name='bar track')
        fw = max(20 * k, bw * (v / mx)) if v > 0 else 0
        if fw: cv.rect(x + lw, yy + rh / 2 - 10 * k, fw, 20 * k, '404040' if theme == 'charcoal' else c, None, 10 * k, grad=st['grad'], name='bar')
        val = str(it['value']).strip(); val = val if (b.get('unit') or '') in val else val + (b.get('unit') or '')
        cv.text(x + lw + bw + 12 * k, yy + rh / 2 - 10 * k, vw, [val], round(15 * k), shade(c, 0.1) if theme != 'charcoal' else INK, 'bold', lh=1.2, name='bar value', src=val)
    return len(its) * rh


def draw_donut(cv, b, x, y, w, k, theme, ci):
    its = b['items']; m = len(its); colw = w / m; r = min(colw * 0.3, 72 * k); sw = 16 * k; hmax = 0; labs = []
    for it in its:
        lfs, lls = fit(it['label'], colw - 20 * k, 80 * k, round(14.5 * k), round(11 * k), 'body', 1.3, 4); labs.append((lfs, lls)); hmax = max(hmax, len(lls) * lfs * 1.3)
    for i, (it, (lfs, lls)) in enumerate(zip(its, labs)):
        c = PALETTE[(ci + i) % 5]; st = style(theme, c, 'mark'); cx = x + i * colw + colw / 2; cy = y + r + sw / 2; v = num(it['value']) or 0
        cv.arc(cx, cy, r, sw, v / 100.0, st['fill'] if st['fill'] != 'FFFFFF' and not st['grad'] else c, tint(c, 0.86), name='ring')
        vs = str(it['value']).strip(); vs = vs if '%' in vs else vs + '%'
        vfs, vls = fit(vs, (r - sw / 2) * 1.35, r * 0.8, round(32 * k), round(14 * k), 'display', 1.05, 1)
        cv.text(cx - r * 0.75, cy - vfs * 0.55, r * 1.5, vls, vfs, INK, 'display', 'center', 1.05, name='ring value', src=vs)
        cv.text(x + i * colw + 10 * k, y + 2 * r + sw + 12 * k, colw - 20 * k, lls, lfs, MUTED, 'body', 'center', 1.3, name='ring label', src=it['label'])
    return 2 * r + sw + 12 * k + hmax


LIST_FALLBACK = ['idea', 'check', 'star', 'target', 'performance', 'award', 'lightbulb', 'flag']


def list_icon(it, used):
    """The item's icon: its own, else the best keyword match, else a generic one; never empty, never a repeat in the block."""
    p = it.get('icon') or pick_icon(it.get('title', '') + ' ' + it.get('text', ''))
    if not p or p in used or icon_svg(p) is None:
        p = next((x for x in LIST_FALLBACK + STAT_ICONS if x not in used and icon_svg(x) is not None), p or 'idea')
    used.add(p)
    return p


def draw_list(cv, b, x, y, w, k, theme, ci):
    its = b['items']; n = len(its); used = set()
    cols = b.get('_cols') or (3 if (w >= 900 and n >= 3 and n != 4) else (2 if n >= 2 and w >= 440 else 1))
    g = 24 * k; cw = (w - g * (cols - 1)) / cols; isz = 50 * k; rows = math.ceil(n / cols); y0 = y
    for r_ in range(rows):
        row = its[r_ * cols:(r_ + 1) * cols]; hs = []
        for j, it in enumerate(row):
            i = r_ * cols + j; c = PALETTE[(ci + i) % 5]; st = style(theme, c, 'mark'); cx = x + j * (cw + g); tw = cw - isz - 14 * k   # the badge: the brand's colours in turn
            f_, bold_, badge_ = _ic(b); filled = badge_ == 'filled' or (badge_ == 'auto' and theme in FILLED)
            if filled:
                bf = st['grad'][0] if st['grad'] else (c if st['fill'] in ('FFFFFF', None) or theme in ('frost',) else st['fill'])
                cv.ellipse(cx, y, isz, isz, bf, name='list badge', grad=st['grad']); icol = 'FFFFFF'
            else:
                cv.ellipse(cx, y, isz, isz, tint(c, 0.86), st['stroke'] if theme == 'paper' else None, 1.5, name='list badge'); icol = st['icon'] if st['icon'] != 'FFFFFF' else shade(c, 0.15)
            fr = min(0.78, 0.6 * f_); off = isz * (1 - fr) / 2
            cv.icon(list_icon(it, used), cx + off, y + off, isz * fr, icol, bold=bold_)
            yy = y
            if it.get('title'):
                tfs, tls = fit(it['title'], tw, 48 * k, round(16.5 * k), round(12.5 * k), 'bold', 1.2, 2); yy += cv.text(cx + isz + 14 * k, yy + 2 * k, tw, tls, tfs, INK, 'bold', lh=1.2, name='list title', src=it['title']) + 6 * k
            if it.get('text'):
                xfs, xls = fit(it['text'], tw, 96 * k, round(14 * k), round(11 * k), 'body', 1.32, 5); yy += cv.text(cx + isz + 14 * k, yy + 2 * k, tw, xls, xfs, MUTED, 'body', lh=1.32, name='list text', src=it['text'])
            hs.append(max(isz, yy - y))
        y += max(hs) + 22 * k
    return y - y0 - 22 * k


def draw_quote(cv, b, x, y, w, k, theme, ci):
    c = PALETTE[ci % 5]; pad = 22 * k
    fs, ls = fit(b['text'], w - 2 * pad - 20 * k, 220 * k, round(25 * k), round(15 * k), 'display', 1.25, 6)
    cv.rect(x, y, 6 * k, 10, c, None, 3, name='quote bar')
    cv.text(x + pad, y - 14 * k, 60 * k, ['“'], round(64 * k), c, 'display', lh=1.0, name='quote mark')
    h = 44 * k + cv.text(x + pad, y + 44 * k, w - 2 * pad, ls, fs, INK, 'display', lh=1.25, name='quote text', src=b['text'])
    if b.get('by'): h += 8 * k + cv.text(x + pad, y + h + 8 * k, w - 2 * pad, [' - ' + b['by']], round(14 * k), MUTED, 'body', lh=1.3, name='quote by', src=' - ' + b['by'])
    for e in cv.els:
        if e.get('name') == 'quote bar' and e['h'] == 10: e['h'] = round(h, 1)
    return h


def draw_takeaway(cv, b, x, y, w, k, theme, ci):
    """The one message: on the Ulta and charcoal themes the Ulta orange banner, white words and a white pictogram (v139) - the words
    14 pt bold or more, where white reads on the orange (3:1); elsewhere a card in the theme's look."""
    band = theme in ('ulta', 'charcoal'); c = TITLE if band else PALETTE[ci % 5]
    st = ({'fill': TITLE, 'grad': GRAD[TITLE] if theme == 'ulta' and LOOK[0] == 'gradient' else None, 'stroke': None, 'glow': None, 'text': 'FFFFFF', 'sub': 'FFFFFF',
           'head': 'FFFFFF', 'icon': 'FFFFFF', 'r': 14} if band else style(theme, c))
    if band and theme == 'ulta' and LOOK[0] == 'light':   # the light lead: light orange into Ulta orange, dark words
        st = dict(st, fill=LIGHT_LEAD[0], grad=LIGHT_LEAD, text=INK, sub=INK, head=INK, icon=INK)
    pad = 24 * k; isz = 42 * k * _ic(b)[0] if b.get('icon') else 0
    tw = w - 2 * pad - (isz + 18 * k if isz else 0)
    fs, ls = (fit(b['text'], tw, 190, max(24, round(24 * k)), 24, 'bold', 1.3, 6) if band and st['head'] != INK   # white words: 14 pt bold or more
              else fit(b['text'], tw, 140 * k, round(21 * k), round(14 * k), 'bold', 1.3, 4))
    h = max(len(ls) * fs * 1.3, isz) + 2 * pad
    card(cv, x, y, w, h, st, 'takeaway')
    if isz and band: cv.icon(b['icon'], x + pad, y + (h - isz) / 2, isz, st['icon'], bold=_ic(b)[1])
    elif isz: card_icon(cv, b['icon'], x + pad, y + (h - isz) / 2, isz, st['icon'], theme, _ic(b)[1])
    cv.text(x + pad + (isz + 18 * k if isz else 0), y + (h - len(ls) * fs * 1.3) / 2, tw, ls, fs, st['head'], 'bold', lh=1.3, name='takeaway text', src=b['text'], **_dk(st['head']))
    return h


DRAW = {'stats': draw_stats, 'steps': draw_steps, 'timeline': draw_timeline, 'compare': draw_compare, 'bars': draw_bars, 'donut': draw_donut, 'list': draw_list, 'quote': draw_quote, 'takeaway': draw_takeaway}


# ------------------------------------------------------------------------------------------------------------------ v7 pictures
# The user's own pictures in the Ulta look: a UI screen in a browser window or a phone, a photo with rounded corners, a caption
# under it. A picture is never stretched: a screen is drawn whole at its own proportions (narrower when it would be too tall), a
# photo may be cropped to fill its box. Sizes follow k like every block, so a page with pictures fits as a page without them.
PIC_H = 430   # the tallest a picture is drawn, in canvas units at full size (k = 1)
REF_ = re.compile(r'^[0-9a-f]{12}$')


def _pic(b, ref):
    return (b.get('_im') or {}).get(ref) if isinstance(ref, str) else None


def _frame_of(b, rec):
    f = b.get('frame') or 'auto'
    if f != 'auto': return f
    if not rec: return 'plain'
    if rec.get('kind') == 'screen': return 'phone' if rec['h'] > rec['w'] * 1.35 else 'browser'
    return 'plain'


def _picture(cv, b, ref, x, y, w, k, maxh, alt=None, fit_=None):
    """A picture with its frame, at most w wide and maxh tall, centred in w. Returns (width, height) drawn."""
    rec = _pic(b, ref); frame = _frame_of(b, rec); alt = alt or b.get('alt') or b.get('caption') or b.get('title') or 'Picture'
    if not rec:   # named but not here (a file that could not be read): a card that says so, never a blank
        h = min(maxh, w * 0.5); cv.rect(x, y, w, h, 'F3EDEB', LINE, round(12 * k, 1), 1.2, name='picture missing')
        s = min(56 * k, h * 0.4); cv.icon('image', x + (w - s) / 2, y + h / 2 - s * 0.9, s, MUTED)
        msg = 'Add a picture: Edit, then Add a picture' if ref == 'new' else 'Picture not found' + (': ' + ref if isinstance(ref, str) and ref and not REF_.match(ref) else ' - upload it again')
        fs, ls = fit(msg, w - 40 * k, 40 * k, round(14 * k), round(11 * k), 'body', 1.3, 2, report=False)
        cv.text(x + 20 * k, y + h / 2 + s * 0.3, w - 40 * k, ls, fs, MUTED, 'body', 'center', 1.3, name='picture missing text', src=msg)
        return w, h
    fit_ = fit_ or b.get('fit') or ('cover' if rec.get('kind') == 'photo' and frame == 'plain' else 'contain')
    bar = 24 * k if frame == 'browser' else 0; bez = 9 * k if frame == 'phone' else 0
    pw = w - 2 * bez
    if fit_ == 'cover': ph = min(maxh - bar - 2 * bez, pw * 0.62)
    else:
        ph = pw * rec['h'] / rec['w']
        if ph + bar + 2 * bez > maxh: ph = maxh - bar - 2 * bez; pw = ph * rec['w'] / rec['h']
    ow, oh = pw + 2 * bez, ph + bar + 2 * bez; ox = x + (w - ow) / 2
    if frame == 'browser':
        cv.rect(ox, y, ow, oh, 'F3EDEB', LINE, round(8 * k, 1), 1.2, name='browser window')
        for i, c in enumerate(('F26923', 'FF893F', 'E0531B')): cv.ellipse(ox + 12 * k + i * 13 * k, y + bar / 2 - 3.5 * k, 7 * k, 7 * k, c, name='browser dot')
        cv.image(ox, y + bar, pw, ph, ref, fit_, 0, name='picture', alt=alt)
    elif frame == 'phone':
        cv.rect(ox, y, ow, oh, INK, None, round(26 * k, 1), name='phone')
        cv.image(ox + bez, y + bez, pw, ph, ref, fit_, round(18 * k, 1), name='picture', alt=alt)
    else:
        cv.image(ox, y, pw, ph, ref, fit_, round(12 * k, 1), name='picture', alt=alt)
        cv.rect(ox, y, pw, ph, None, LINE, round(12 * k, 1), 1.2, name='picture edge')
    return ow, oh


def _caption(cv, b, text, x, y, w, k, align='left', draw=True, name='picture caption'):
    if not text: return 0
    fs, ls = fit(text, w, 66 * k, round(14 * k), round(11 * k), 'body', 1.3, 3)
    if draw: cv.text(x, y, w, ls, fs, MUTED, 'body', align, 1.3, name=name, src=text)
    return len(ls) * fs * 1.3


def draw_image(cv, b, x, y, w, k, theme, ci):
    pw, ph = _picture(cv, b, b['src'], x, y, w, k, PIC_H * k)
    cx = x + (w - pw) / 2
    return ph + (10 * k + _caption(cv, b, b.get('caption'), cx, y + ph + 10 * k, max(pw, 240 * k), k) if b.get('caption') else 0)


def draw_feature(cv, b, x, y, w, k, theme, ci):
    """A picture beside its points: a screen or a photo takes half the width, a phone's screen (tall) 38 %; the points (a
    one-column list) the rest."""
    rec = _pic(b, b['src']); g = 32 * k; pw = (w - g) * (0.38 if rec and rec['h'] > rec['w'] * 1.2 else 0.5); lw = w - g - pw
    px, lx = (x + lw + g, x) if b.get('side') != 'left' else (x, x + pw + g)
    hl = draw_list(cv, dict(b, _cols=1), lx, y, lw, k, theme, ci)
    dw, dh = _picture(cv, b, b['src'], px, y, pw, k, PIC_H * k)
    cx = px + (pw - dw) / 2
    hc = (10 * k + _caption(cv, b, b.get('caption'), cx, y + dh + 10 * k, dw, k)) if b.get('caption') else 0
    return max(hl, dh + hc)


def draw_gallery(cv, b, x, y, w, k, theme, ci):
    its = b['items']; n = len(its); g = 20 * k; cw = (w - g * (n - 1)) / n; bh = min(cw * (0.62 if n > 1 else 0.56), 380 * k)
    hs = []
    for it in its:   # each picture's height, to sit them on one line at the bottom of the row
        t = Canvas(); hs.append(_picture(t, dict(b, frame='auto'), it['src'], 0, 0, cw, k, bh, alt=it.get('alt') or it.get('caption'), fit_=b.get('fit') or None)[1])
    top = max(hs); hc = max([_caption(cv, b, it.get('caption'), 0, 0, cw, k, draw=False) for it in its] + [0])
    for i, (it, h) in enumerate(zip(its, hs)):
        cx = x + i * (cw + g)
        _picture(cv, dict(b, frame='auto'), it['src'], cx, y + top - h, cw, k, bh, alt=it.get('alt') or it.get('caption'), fit_=b.get('fit') or None)
        if it.get('caption'): _caption(cv, b, it['caption'], cx, y + top + 10 * k, cw, k, 'center', name='gallery caption')
    return top + (10 * k + hc if hc else 0)


def draw_band(cv, b, x, y, w, k, theme, ci):
    """The value in one coloured strip: a small label, then each point with a pictogram (in Ulta orange: the pale orange with dark
    words on the Ulta theme)."""
    st = style(theme, TITLE); pad = 22 * k; its = b['items']; n = len(its); lab = b.get('label') or ''
    lfs = max(round(13 * k), MIN_FS[0]); lh_ = (lfs * 1.2 + 12 * k) if lab else 0
    g = 18 * k; cw = (w - 2 * pad - g * (n - 1)) / n; isz = 30 * k * _ic(b)[0]
    fits = [fit(it['title'], cw - isz - 10 * k, 64 * k, round(16 * k), round(12 * k), 'bold', 1.25, 3) for it in its]
    ih = max(max(len(ls) * fs * 1.25 for fs, ls in fits), isz)
    h = pad + lh_ + ih + pad
    card(cv, x, y, w, h, st, 'band')
    ink = st['head']
    if lab: cv.text(x + pad, y + pad, w - 2 * pad, [lab.upper()], lfs, st['sub'], 'bold', lh=1.2, name='band label', src=lab.upper(), spacing=1.5)
    yy = y + pad + lh_; used = set()
    for i, (it, (fs, ls)) in enumerate(zip(its, fits)):
        cx = x + pad + i * (cw + g)
        cv.icon(list_icon(it, used), cx, yy + (ih - isz) / 2, isz, st['icon'], bold=_ic(b)[1])
        cv.text(cx + isz + 10 * k, yy + (ih - len(ls) * fs * 1.25) / 2, cw - isz - 10 * k, ls, fs, ink, 'bold', lh=1.25, name='band item', src=it['title'])
    return h


def draw_flow(cv, b, x, y, w, k, theme, ci):
    """How the work changes: a lane per state (today, then tomorrow) - its name on the left, then a line of steps: a pictogram
    in a circle, a few words under it, an arrow to the next. Today is drawn in neutrals, tomorrow in the brand colours."""
    lanes = b['lanes']; y0 = y; g = 14 * k; pad = 16 * k; d = 46 * k * _ic(b)[0]
    tw = min(230 * k, 0.27 * w) if any(ln.get('title') for ln in lanes) else 0   # the lanes' names, in a column of their own
    for li, ln in enumerate(lanes):
        after = ln.get('tone') == 'after' or (not ln.get('tone') and (li == len(lanes) - 1))
        c = PALETTE[(ci + 1) % 5] if after else MUTED
        its = ln['items']; n = len(its); sx = x + pad + 8 * k + (tw + 12 * k if tw else 0); colw = (x + w - pad - sx) / n
        tfs, tls = fit(ln['title'], tw, 80 * k, round(16 * k), round(12 * k), 'bold', 1.2, 3) if ln.get('title') else (0, [])
        labs = [fit(it['title'], colw - 12 * k, 60 * k, round(14 * k), round(11 * k), 'body', 1.25, 3) for it in its]
        sh = d + 8 * k + max(len(ls) * fs * 1.25 for fs, ls in labs); th = len(tls) * tfs * 1.2
        hh = pad + max(th, sh) + pad
        cv.rect(x, y, w, hh, 'FFFFFF', LINE, 14, 1.2, name='flow lane')
        cv.rect(x, y + 12 * k, 5 * k, hh - 24 * k, c, None, 2, name='flow accent')
        if tls: cv.text(x + pad + 8 * k, y + (hh - th) / 2, tw, tls, tfs, INK, 'bold', lh=1.2, name='flow title', src=ln['title'])
        cy = y + (hh - sh) / 2; used = set()
        for i, (it, (fs, ls)) in enumerate(zip(its, labs)):
            cx = sx + i * colw + colw / 2
            cv.ellipse(cx - d / 2, cy, d, d, c if after else 'F3EDEB', None if after else LINE, 1.2, name='flow step', grad=style(theme, c, 'mark')['grad'] if after else None)
            s = d * 0.56; cv.icon(list_icon(it, used), cx - s / 2, cy + (d - s) / 2, s, 'FFFFFF' if after else MUTED, bold=_ic(b)[1])
            if i < n - 1: cv.line(cx + d / 2 + 8 * k, cy + d / 2, cx + colw - d / 2 - 8 * k, cy + d / 2, c, 2.5 * k, name='flow arrow', arrow=True)
            cv.text(cx - colw / 2 + 6 * k, cy + d + 8 * k, colw - 12 * k, ls, fs, INK, 'body', 'center', 1.25, name='flow step text', src=it['title'])
        y += hh + g
    return y - y0 - g


DRAW.update({'image': draw_image, 'feature': draw_feature, 'gallery': draw_gallery, 'band': draw_band, 'flow': draw_flow})


# ------------------------------------------------------------------------------------------------------------------ v139 ways to tell it
# The same story told another way: a journey that climbs (stairs), runs in arrows (chevrons), builds up in layers (pyramid) or rises
# on a curve (curve); one idea with its parts around it (hub); what holds a vision up (house: a roof, pillars and a foundation); points
# as tiles (cards). On the Ulta theme a journey's stages run as one warm gradient - Ulta orange deepening stage by stage into red-orange,
# raspberry and berry (RAMP), each stage running into the next one's colour - and the parts' pictogram discs take the brand's colours.
RAMP = ['F26923', 'F24C26', 'E9341C', 'DB0058', 'C10060', '5D0F43']
RAMP_FLAT = ['F26923', 'E9341C', 'DB0058', 'C10060', '5D0F43']   # the flat look: a step apart, so neighbouring stages differ


def _solid(theme, c):
    """(fill, gradient, stroke, ink, icon) of a shape that is drawn in colour on every theme: the theme's mark, but the colour itself
    where the theme draws its marks white or pale (glow, frost, paper)."""
    st = style(theme, c, 'mark')
    if theme in FILLED: return st['fill'], st['grad'], None, st['head'], st['icon']
    return c, None, None, 'FFFFFF', 'FFFFFF'


def _stage(theme, i):
    """(fill, gradient, stroke, ink, icon) of a journey's stage i: on the Ulta theme the warm run (white reads along all of it at 3:1, the
    stage names are 14 pt bold or more), elsewhere the theme's colours in turn."""
    if theme != 'ulta': return _solid(theme, PALETTE[i % 5])
    j = min(i, 4)
    if LOOK[0] == 'light': return LIGHT_STAGES[j][0], LIGHT_STAGES[j], None, INK, INK   # dark words: they read along all of it
    if LOOK[0] == 'flat': return RAMP_FLAT[j], None, None, 'FFFFFF', 'FFFFFF'
    return RAMP[j], (RAMP[j], RAMP[j + 1]), None, 'FFFFFF', 'FFFFFF'


def _dk(ink):
    """The text option that keeps dark words dark on the light lead (readable_text: never turned white where dark reads)."""
    return {'dark': True} if ink == INK else {}


def _lead(theme):
    """(fill, gradient, stroke, ink, icon) of the lead shape - a hub's centre, a house's roof and base: on the Ulta theme's light look the
    light orange run with dark words, else the theme's headline colour."""
    if theme == 'ulta' and LOOK[0] == 'light': return LIGHT_LEAD[0], LIGHT_LEAD, None, INK, INK
    return _solid(theme, TITLE)


def _head(title, wb, wf, k):
    """A stage name on its shape, white and 14 pt bold or more: beside the pictogram when every word fits there in two lines, else under
    it at the shape's full width. (beside, (fs, lines))."""
    hi = max(24, round(26 * k))
    if all(text_w(x, 24, 'bold') <= wb for x in str(title or '').split()) and len(wrap(title, wb, 24, 'bold')) <= 2:
        return True, fit(title, wb, 62 * k, hi, 24, 'bold', 1.15, 2)
    return False, fit(title, wf, 62 * k, hi, 24, 'bold', 1.15, 2)


def _fit_hy(text, w, h, hi, lo, font='body', lh=1.22, max_lines=None):
    """fit() in a narrow column: a hyphenated word too wide for it breaks after a hyphen (self-checkout), not in the middle."""
    pairs, toks = [], []
    for t_ in str(text or '').split():
        if '-' in t_.strip('-') and text_w(t_, lo, font) > w:
            ps = t_.split('-'); segs = [p_ + '-' for p_ in ps[:-1]] + [ps[-1]]
            pairs += list(zip(segs, segs[1:])); toks += segs
        else: toks.append(t_)
    fs, ls = fit(' '.join(toks), w, h, hi, lo, font, lh, max_lines)
    for a_, b_ in pairs: ls = [l_.replace(a_ + ' ' + b_, a_ + b_) for l_ in ls]
    return fs, ls


def _stage_fits(it, w, k, lines=5, when=True):
    """A stage's 'when' (in capitals) and words fitted to w: ((fs, lines) when, (fs, lines) text, height)."""
    wl = fit(it['when'].upper(), w, 22 * k, 14, 14, 'bold', 1.2, 1) if when and it.get('when') else (0, [])
    xl = fit(it['text'], w, (24 * lines) * k + 40, max(14, round(14 * k)), 14, 'body', 1.3, lines) if it.get('text') else (0, [])
    h = (len(wl[1]) * wl[0] * 1.2 + (4 * k if xl[1] else 0) if wl[1] else 0) + len(xl[1]) * xl[0] * 1.3
    return wl, xl, h


def _stage_draw(cv, it, fits_, x, y, w, k, align='left', name='stage'):
    wl, xl, _ = fits_
    if wl[1]: y += cv.text(x, y, w, wl[1], wl[0], INK, 'bold', align, 1.2, name=name + ' when', src=it['when'].upper(), spacing=1) + (4 * k if xl[1] else 0)
    if xl[1]: cv.text(x, y, w, xl[1], xl[0], MUTED, 'body', align, 1.3, name=name + ' text', src=it['text'])


def _on_shape(cv, it, used, b, x, y, w, h, k, ink, icol, isz, name):
    """A stage's pictogram and name on its shape (the box x, y, w, h inside it): side by side, or the pictogram over the name when the
    shape is narrow - centred in the box."""
    beside, (fs, ls) = _head(it.get('title', ''), w - isz - 12 * k, w, k); th = len(ls) * fs * 1.15
    if beside:
        oy = y + (h - max(isz, th)) / 2
        cv.icon(list_icon(it, used), x, oy + max(0, (th - isz) / 2), isz, icol, bold=_ic(b)[1])
        cv.text(x + isz + 12 * k, oy + max(0, (isz - th) / 2), w - isz - 12 * k, ls, fs, ink, 'bold', lh=1.15, name=name + ' title', src=it.get('title', ''), **_dk(ink))
    else:
        oy = y + (h - isz - 8 * k - th) / 2
        cv.icon(list_icon(it, used), x + (w - isz) / 2, oy, isz, icol, bold=_ic(b)[1])
        cv.text(x, oy + isz + 8 * k, w, ls, fs, ink, 'bold', 'center', 1.15, name=name + ' title', src=it.get('title', ''), **_dk(ink))


def _on_shape_h(it, w, k, isz):
    beside, (fs, ls) = _head(it.get('title', ''), w - isz - 12 * k, w, k); th = len(ls) * fs * 1.15
    return max(isz, th) if beside else isz + 8 * k + th


def draw_stairs(cv, b, x, y, w, k, theme, ci):
    """A journey that climbs: each stage a step higher than the one before - its pictogram and name on the step, its words above it,
    a flag on the top step."""
    its = b['items']; n = len(its); g = 5 * k; sw_ = (w - g * (n - 1)) / n; pad = 16 * k; isz = 36 * k * _ic(b)[0]; used = set(); fl = 50 * k
    hh = max(_on_shape_h(it, sw_ - 2 * pad, k, isz) for it in its)
    face0 = max(76 * k, 2 * pad + 10 * k + hh); rise = 40 * k
    tex = [_stage_fits(it, sw_ - 8 * k - (46 * k if i == n - 1 else 0), k) for i, it in enumerate(its)]
    H = max([face0 + (n - 1) * rise + fl] + [face0 + i * rise + (14 * k + t[2] if t[2] else 0) for i, t in enumerate(tex)]); base = y + H
    for i, (it, t) in enumerate(zip(its, tex)):
        fill, grad, stroke, ink, icol = _stage(theme, i); fx = x + i * (sw_ + g); fh = face0 + i * rise; fy = base - fh
        cv.rect(fx, fy, sw_, fh, fill, stroke, 6 * k, 1, grad, name='stair')
        cv.rect(fx, fy, sw_, 9 * k, LIGHT_CARD, None, 4 * k, name='stair tread')   # the step's lit edge (a template colour: the brand pass keeps it)
        _on_shape(cv, it, used, b, fx + pad, fy + 10 * k + pad, sw_ - 2 * pad, hh, k, ink, icol, isz, 'stair')
        if t[2]: _stage_draw(cv, it, t, fx + 4 * k, fy - 14 * k - t[2], sw_ - 8 * k, k, name='stair')
    fill, grad, *_ = _stage(theme, n - 1); px = x + w - 30 * k; fy = base - face0 - (n - 1) * rise
    cv.line(px, fy, px, fy - fl, '404040', 3 * k, name='stair flag pole')
    cv.poly([(px, fy - fl), (px + 28 * k, fy - fl + 10 * k), (px, fy - fl + 20 * k)], fill, None, name='stair flag', grad=grad)
    return H


def draw_chevrons(cv, b, x, y, w, k, theme, ci):
    """A journey in arrows: each stage a chevron pointing to the next - its pictogram and name inside, its words under it."""
    its = b['items']; n = len(its); d = 34 * k; g = 7 * k; cw = (w + (n - 1) * (d - g)) / n; pad = 14 * k; isz = 34 * k * _ic(b)[0]; used = set()
    ins = [(d if i else pad) + 8 * k for i in range(n)]   # where the words start: past the notch
    hh = max(_on_shape_h(it, cw - ins[i] - d, k, isz) for i, it in enumerate(its)); ch = max(90 * k, 2 * pad + hh)
    tex = [_stage_fits(it, cw - ins[i] - d, k) for i, it in enumerate(its)]; hm = max(t[2] for t in tex)
    for i, (it, t) in enumerate(zip(its, tex)):
        fill, grad, stroke, ink, icol = _stage(theme, i); cx = x + i * (cw - d + g)
        pts = [(cx, y), (cx + cw - d, y), (cx + cw, y + ch / 2), (cx + cw - d, y + ch), (cx, y + ch)] + ([(cx + d, y + ch / 2)] if i else [])
        cv.poly(pts, fill, stroke, 1, name='chevron', grad=grad)
        _on_shape(cv, it, used, b, cx + ins[i], y + pad, cw - ins[i] - d, ch - 2 * pad, k, ink, icol, isz, 'chevron')
        if t[2]: _stage_draw(cv, it, t, cx + ins[i], y + ch + 16 * k, cw - ins[i] - d, k, name='chevron')
    return ch + (16 * k + hm if hm else 0)


def draw_pyramid(cv, b, x, y, w, k, theme, ci):
    """Layers that build on each other: the first item the base, the last the top - a pictogram in each layer, its 'when', name and
    words beside it."""
    its = b['items']; n = len(its); pw = min(w * 0.42, 540 * k); gx = 34 * k; lx = x + pw + gx; lw = w - pw - gx; g = 6 * k; used = set(); isz = 32 * k * _ic(b)[0]
    tls = [fit(it.get('title', ''), lw, 48 * k, max(14, round(18 * k)), 14, 'bold', 1.2, 2) for it in its]
    wls = [_stage_fits(dict(it, text=''), lw, k) for it in its]; tex = [_stage_fits(it, lw, k, 3, when=False) for it in its]
    hs = [(wl[2] + 4 * k if wl[2] else 0) + len(tl[1]) * tl[0] * 1.2 + (6 * k + t[2] if t[2] else 0) for wl, tl, t in zip(wls, tls, tex)]
    lh = max(70 * k, isz + 30 * k, max(hs) + 12 * k); H = n * lh + (n - 1) * g; cx = x + pw / 2
    hw = lambda yy: (pw / 2) * (yy - y) / H
    for j in range(n):   # from the top: the last item
        i = n - 1 - j; it = its[i]; fill, grad, stroke, ink, icol = _stage(theme, i)
        yt = y + j * (lh + g); yb = yt + lh
        pts = ([(cx, yt)] if j == 0 else [(cx - hw(yt), yt), (cx + hw(yt), yt)]) + [(cx + hw(yb), yb), (cx - hw(yb), yb)]
        cv.poly(pts, fill, stroke, 1, name='pyramid layer', grad=grad)
        cv.icon(list_icon(it, used), cx - isz / 2, (yb - isz - 12 * k) if j == 0 else (yt + (lh - isz) / 2), isz, icol, bold=_ic(b)[1])
        my = (yt + yb) / 2; ex = cx + hw(my) + 12 * k; lc = grad[1] if grad else fill
        cv.line(ex, my, lx - 16 * k, my, lc, 2 * k, dash=True, name='pyramid leader')
        cv.ellipse(lx - 21 * k, my - 5 * k, 10 * k, 10 * k, lc, name='pyramid leader dot')
        yy = my - hs[i] / 2
        if wls[i][2]: _stage_draw(cv, it, wls[i], lx, yy, lw, k, name='pyramid'); yy += wls[i][2] + 4 * k
        yy += cv.text(lx, yy, lw, tls[i][1], tls[i][0], INK, 'bold', lh=1.2, name='pyramid title', src=it.get('title', ''))
        if tex[i][2]: _stage_draw(cv, it, tex[i], lx, yy + 6 * k, lw, k, name='pyramid')
    return H


def draw_curve(cv, b, x, y, w, k, theme, ci):
    """A curve that rises: growth or maturity as an S-curve, each stage a dot on it - its 'when' over the dot, its name and words under
    the line."""
    its = b['items']; n = len(its); colw = w / n; d = 56 * k; used = set(); ah = 170 * k
    tls = [fit(it.get('title', ''), colw - 28 * k, 48 * k, max(14, round(18 * k)), 14, 'bold', 1.2, 2) for it in its]
    tex = [_stage_fits(it, colw - 28 * k, k, 4, when=False) for it in its]; wls = [_stage_fits(dict(it, text=''), colw - 20 * k, k) for it in its]
    hw_ = max(t[2] for t in wls); hs = [len(tl[1]) * tl[0] * 1.2 + (6 * k + t[2] if t[2] else 0) for tl, t in zip(tls, tex)]
    top = (hw_ + 10 * k if hw_ else 0) + d / 2 + 6 * k; base = y + top + ah
    f = lambda t_: t_ * t_ * t_ * (t_ * (6 * t_ - 15) + 10)   # an S from 0 to 1 in plain arithmetic: the page's engine draws the same curve
    cy = lambda t_: base - ah * (0.04 + 0.96 * f(t_))
    pts = [(x + w * j / 48, cy(j / 48)) for j in range(49)]
    f0, g0, *_ = _stage(theme, 0); fz, gz, *_ = _stage(theme, n - 1)
    cv.poly([(x, base)] + pts + [(x + w, base)], LIGHT_CARD if theme == 'ulta' else tint(f0, 0.86), None, name='curve area',
            grad=('FFF3ED', LIGHT_CARD) if theme == 'ulta' else None)
    cv.poly([(px, py - 3.5 * k) for px, py in pts] + [(px, py + 3.5 * k) for px, py in reversed(pts)], f0, None, name='curve line',
            grad=(f0, gz[1] if gz else fz) if (g0 or gz) else None)
    cv.line(x, base, x + w, base, LINE, 2, name='curve base')
    for i, it in enumerate(its):
        fill, grad, stroke, ink, icol = _stage(theme, i); t_ = (i + 0.5) / n; px = x + w * t_; py = cy(t_)
        cv.line(px, py + d / 2, px, base, grad[1] if grad else fill, 2 * k, dash=True, name='curve leader')
        cv.ellipse(px - d / 2, py - d / 2, d, d, fill, 'FFFFFF', 4 * k, name='curve dot', grad=grad)
        s = d * 0.56; cv.icon(list_icon(it, used), px - s / 2, py - s / 2, s, icol, bold=_ic(b)[1])
        if wls[i][2]: _stage_draw(cv, it, wls[i], px - colw / 2 + 10 * k, py - d / 2 - 8 * k - wls[i][2], colw - 20 * k, k, 'center', name='curve')
        yy = base + 16 * k + cv.text(px - colw / 2 + 14 * k, base + 16 * k, colw - 28 * k, tls[i][1], tls[i][0], INK, 'bold', 'center', 1.2, name='curve title', src=it.get('title', ''))
        if tex[i][2]: _stage_draw(cv, it, tex[i], px - colw / 2 + 14 * k, yy + 6 * k, colw - 28 * k, k, 'center', name='curve')
    return top + ah + 16 * k + max(hs)


def draw_hub(cv, b, x, y, w, k, theme, ci):
    """One idea and its parts: the idea in a disc at the centre, each part a pictogram on a spoke with its name and words beside it -
    half on the left, half on the right."""
    its = b['items']; n = len(its); L = (n + 1) // 2; sides = [its[:L], its[L:]]; D = min(250 * k, w * 0.24); dd = 58 * k; used = set()
    bump = 26 * k; reach = D / 2 + 64 * k   # how far out the discs sit (further at the ends of a side)
    tw = w / 2 - reach - dd - bump - 16 * k
    tex = [[(fit(it.get('title', ''), tw, 44 * k, max(14, round(17 * k)), 14, 'bold', 1.2, 2), fit(it.get('text', ''), tw, 130 * k, max(14, round(14 * k)), 14, 'body', 1.3, 6) if it.get('text') else (0, []))
            for it in side] for side in sides]
    th = lambda tt: len(tt[0][1]) * tt[0][0] * 1.2 + (4 * k + len(tt[1][1]) * tt[1][0] * 1.3 if tt[1][1] else 0)
    rh = max([dd + 18 * k] + [th(tt) + 20 * k for s in tex for tt in s]); rows = max(len(s) for s in sides); H = max(D + 48 * k, rows * rh)
    cx = x + w / 2; cy = y + H / 2; fill, grad, stroke, ink, icol = _lead(theme)
    marks = []
    for si, (side, tt_) in enumerate(zip(sides, tex)):
        m = len(side)
        for j, (it, tt) in enumerate(zip(side, tt_)):
            off = j - (m - 1) / 2; yy = cy + off * rh; dx = reach + dd / 2 + bump * abs(off) / max(1, (m - 1) / 2); px = cx + dx if si else cx - dx
            marks.append((si, it, tt, px, yy, PALETTE[(ci + len(marks)) % 5]))
    for si, it, tt, px, yy, c in marks:   # the spokes under the discs (a unit vector, no trigonometry: the page's engine draws the same)
        L = math.sqrt((px - cx) * (px - cx) + (yy - cy) * (yy - cy)) or 1; ux, uy = (px - cx) / L, (yy - cy) / L
        cv.line(cx + (D / 2) * ux, cy + (D / 2) * uy, px - (dd / 2) * ux, yy - (dd / 2) * uy, tint(c, 0.45) if theme != 'charcoal' else '8A8C8F', 3 * k, name='hub spoke')
    cv.ellipse(cx - D / 2 - 14 * k, cy - D / 2 - 14 * k, D + 28 * k, D + 28 * k, LIGHT_CARD if theme == 'ulta' else tint(TITLE, 0.85), None, name='hub halo')
    cv.ellipse(cx - D / 2, cy - D / 2, D, D, fill, None, name='hub', grad=grad)
    if b.get('center'):
        fs, ls = fit(b['center'], D * 0.72, D * 0.62, max(24, round(28 * k)), 24 if ink != INK else 16, 'bold', 1.12, 4)   # white needs 14 pt bold on orange; dark may be smaller
        cv.text(cx - D * 0.36, cy - len(ls) * fs * 1.12 / 2, D * 0.72, ls, fs, ink, 'bold', 'center', 1.12, name='hub text', src=b['center'], **_dk(ink))
    for si, it, tt, px, yy, c in marks:
        f_, g_, s_, ink_, icol_ = _solid(theme, c)
        cv.ellipse(px - dd / 2, yy - dd / 2, dd, dd, f_, 'FFFFFF', 3 * k, name='hub disc', grad=g_)
        s = dd * 0.56; cv.icon(list_icon(it, used), px - s / 2, yy - s / 2, s, icol_, bold=_ic(b)[1])
        h = th(tt); tx = px + dd / 2 + 16 * k if si else x; ww = (x + w - tx) if si else (px - dd / 2 - 16 * k - x); al = 'left' if si else 'right'
        y0 = yy - h / 2 + cv.text(tx, yy - h / 2, ww, tt[0][1], tt[0][0], INK, 'bold', al, 1.2, name='hub title', src=it.get('title', ''))
        if tt[1][1]: cv.text(tx, y0 + 4 * k, ww, tt[1][1], tt[1][0], MUTED, 'body', al, 1.3, name='hub item text', src=it['text'])
    return H


def draw_house(cv, b, x, y, w, k, theme, ci):
    """What holds a vision up: the roof carries it, a pillar for each part, the foundation they stand on - the message."""
    its = b['items']; n = len(its); used = set(); pad = 16 * k; fill, grad, stroke, ink, icol = _lead(theme)
    rh = 100 * k; ax = x + 34 * k; aw = w - 68 * k; gp = 20 * k; pw_ = (aw - gp * (n - 1)) / n; isz = 46 * k
    if pw_ < 170 * k: ax = x + 18 * k; aw = w - 36 * k; gp = 10 * k; pad = 9 * k; pw_ = (aw - gp * (n - 1)) / n; isz = 40 * k   # narrow: room for the words
    roof = fit(b.get('roof', ''), aw - 40 * k, 92 * k, max(14, round(19 * k)), max(14, round(14 * k)), 'bold', 1.25, 3) if b.get('roof') else (0, [])
    bh = (len(roof[1]) * roof[0] * 1.25 + 2 * pad) if roof[1] else 0
    a0 = min(_fit_hy(it.get('title', ''), pw_ - 2 * pad, 66 * k, max(14, round(17 * k)), 14, 'bold', 1.2, 3)[0] for it in its)   # one size across the pillars
    t0 = min([_fit_hy(it['text'], pw_ - 2 * pad, 120 * k, max(14, round(14 * k)), 14, 'body', 1.3, 6)[0] for it in its if it.get('text')] or [0])
    cols = [(_fit_hy(it.get('title', ''), pw_ - 2 * pad, 66 * k, a0, a0, 'bold', 1.2, 3),
             _fit_hy(it.get('text', ''), pw_ - 2 * pad, 120 * k, t0, t0, 'body', 1.3, 6) if it.get('text') else (0, [])) for it in its]
    ph = max(pad + isz + 12 * k + len(a[1]) * a[0] * 1.2 + (6 * k + len(t[1]) * t[0] * 1.3 if t[1] else 0) + pad for a, t in cols)
    base = fit(b.get('base', ''), w - 2 * pad - 60 * k, 100 * k, max(24, round(25 * k)), 24, 'bold', 1.25, 3) if b.get('base') else (0, [])
    fh = (len(base[1]) * base[0] * 1.25 + 2 * pad) if base[1] else 22 * k
    cv.poly([(x, y + rh), (x + w / 2, y), (x + w, y + rh)], fill, None, name='house roof', grad=grad)
    cv.icon(b.get('icon') or 'insight', x + w / 2 - 21 * k, y + rh * 0.42, 42 * k, icol)
    yy = y + rh + 6 * k
    if roof[1]:
        cv.rect(x + 14 * k, yy, w - 28 * k, bh, LIGHT_CARD if theme == 'ulta' else style(theme, TITLE)['fill'], None, 6 * k, name='house beam')
        cv.text(x + 34 * k, yy + pad, w - 68 * k, roof[1], roof[0], INK if theme == 'ulta' else style(theme, TITLE)['head'], 'bold', 'center', 1.25, name='house roof text', src=b['roof'])
        yy += bh + 10 * k
    for i, (it, (a, t)) in enumerate(zip(its, cols)):
        c = PALETTE[(ci + i) % 5]; f_, g_, s_, ink_, icol_ = _solid(theme, c); px = ax + i * (pw_ + gp)
        cv.rect(px - 6 * k, yy, pw_ + 12 * k, 12 * k, f_, None, 3 * k, 1, g_, name='pillar capital')
        cv.rect(px, yy + 12 * k, pw_, ph, 'FFFFFF' if theme != 'velvet' else '2A2220', LINE if theme != 'velvet' else None, 0, 1, name='pillar')
        cv.ellipse(px + (pw_ - isz) / 2, yy + 12 * k + pad, isz, isz, f_, None, name='pillar disc', grad=g_)
        s = isz * 0.58; cv.icon(list_icon(it, used), px + (pw_ - s) / 2, yy + 12 * k + pad + (isz - s) / 2, s, icol_, bold=_ic(b)[1])
        ty = yy + 12 * k + pad + isz + 12 * k + cv.text(px + pad, yy + 12 * k + pad + isz + 12 * k, pw_ - 2 * pad, a[1], a[0], INK if theme != 'velvet' else 'FFFFFF', 'bold', 'center', 1.2, name='pillar title', src=it.get('title', ''))
        if t[1]: cv.text(px + pad, ty + 6 * k, pw_ - 2 * pad, t[1], t[0], MUTED if theme != 'velvet' else 'F9E3DE', 'body', 'center', 1.3, name='pillar text', src=it['text'])
        cv.rect(px - 6 * k, yy + 12 * k + ph, pw_ + 12 * k, 10 * k, f_, None, 3 * k, 1, g_, name='pillar foot')
    yy += 12 * k + ph + 10 * k + 8 * k
    cv.rect(x + 14 * k, yy, w - 28 * k, fh, fill, None, 8 * k, 1, grad, name='house base')
    if base[1]: cv.text(x + 14 * k + pad + 30 * k, yy + pad, w - 28 * k - 2 * pad - 60 * k, base[1], base[0], ink, 'bold', 'center', 1.25, name='house base text', src=b['base'], **_dk(ink))
    cv.rect(x, yy + fh + 5 * k, w, 12 * k, (grad[1] if grad else shade(fill, 0.12)) if theme in FILLED else fill, None, 4 * k, name='house step')
    return yy + fh + 17 * k - y


def draw_cards(cv, b, x, y, w, k, theme, ci):
    """Points as tiles: each a card with a pictogram disc, its name beside it and its words under them."""
    its = b['items']; n = len(its); used = set()
    cols = 4 if n in (4, 8) and w >= 1200 else 3 if n >= 3 and w >= 760 else 2 if n >= 2 and w >= 440 else 1
    g = 20 * k; cw = (w - g * (cols - 1)) / cols; pad = 18 * k; isz = 48 * k; rows = math.ceil(n / cols); y0 = y
    for r_ in range(rows):
        row = its[r_ * cols:(r_ + 1) * cols]; lay = []
        for it in row:
            a = fit(it.get('title', ''), cw - 2 * pad - isz - 12 * k, 48 * k, max(14, round(17 * k)), 14, 'bold', 1.2, 2)
            t = fit(it.get('text', ''), cw - 2 * pad, 96 * k, max(14, round(14 * k)), 14, 'body', 1.3, 4) if it.get('text') else (0, [])
            lay.append((a, t, pad + max(isz, len(a[1]) * a[0] * 1.2) + (10 * k + len(t[1]) * t[0] * 1.3 if t[1] else 0) + pad))
        h = max(l_[2] for l_ in lay)
        for j, (it, (a, t, _)) in enumerate(zip(row, lay)):
            i = r_ * cols + j; c = PALETTE[(ci + i) % 5]; st = style(theme, c, 'card'); f_, g_, s_, ink_, icol_ = _solid(theme, c); cx = x + j * (cw + g)
            card(cv, cx, y, cw, h, st, 'tile')
            cv.ellipse(cx + pad, y + pad, isz, isz, f_, None, name='tile disc', grad=g_)
            s = isz * 0.58; cv.icon(list_icon(it, used), cx + pad + (isz - s) / 2, y + pad + (isz - s) / 2, s, icol_, bold=_ic(b)[1])
            ah_ = len(a[1]) * a[0] * 1.2
            cv.text(cx + pad + isz + 12 * k, y + pad + max(0, (isz - ah_) / 2), cw - 2 * pad - isz - 12 * k, a[1], a[0], st['head'], 'bold', lh=1.2, name='tile title', src=it.get('title', ''))
            if t[1]: cv.text(cx + pad, y + pad + max(isz, ah_) + 10 * k, cw - 2 * pad, t[1], t[0], st['sub'] if theme in ('velvet', 'charcoal') else MUTED, 'body', lh=1.3, name='tile text', src=it['text'])
        y += h + g
    return y - y0 - g


def draw_rings(cv, b, x, y, w, k, theme, ci):
    """Reach that widens: the first item the inner circle, each next one a wider circle around it, all standing on one point - its
    pictogram and name inside its band (the name beside the rings when it does not fit there whole), its 'when' and words beside the
    rings on a leader line."""
    its = b['items']; n = len(its); R = min(w * 0.27, 215 * k); isz = 30 * k * _ic(b)[0]; used = set()
    under = w - 2 * R - 64 * k < 260 * k   # too narrow for the words beside the rings: they go under them
    if under: R = min(w * 0.46, 170 * k)
    r = [R * (0.6 + 0.4 * i / (n - 1)) if n > 1 else R for i in range(n)]
    cx = x + (w / 2 if under else R); yb = y + 2 * R; lx = x + (22 * k if under else 2 * R + 64 * k); lw = w - (22 * k if under else 2 * R + 64 * k)
    mid = [yb - r[i] - (r[i - 1] if i else 0) for i in range(n)]   # the middle of each band (of the inner circle: its centre)
    band = [2 * (math.sqrt(max(0.0, r[i] * r[i] - r[i - 1] * r[i - 1])) if i else r[0] * 0.9) - 24 * k for i in range(n)]   # its width there
    inside = [all(text_w(x_, 24, 'bold') <= band[i] for x_ in str(it.get('title', '')).split()) for i, it in enumerate(its)]
    heads = [_head(it.get('title', ''), band[i] - isz - 10 * k, band[i], k) if inside[i] else (False, (0, [])) for i, it in enumerate(its)]   # fitted only where it goes
    tls = [fit(it.get('title', ''), lw, 48 * k, max(14, round(18 * k)), 14, 'bold', 1.2, 2) if not inside[i] else (0, []) for i, it in enumerate(its)]
    wls = [_stage_fits(dict(it, text=''), lw, k) for it in its]; tex = [_stage_fits(it, lw, k, 3, when=False) for it in its]
    hs_ = [(wls[i][2] + 4 * k if wls[i][2] else 0) + len(tls[i][1]) * tls[i][0] * 1.2 + (6 * k + tex[i][2] if tex[i][2] else 0) for i in range(n)]
    for i in range(n - 1, -1, -1):   # the widest first, the inner one on top
        fill, grad, stroke, ink, icol = _stage(theme, i)
        cv.ellipse(cx - r[i], yb - 2 * r[i], 2 * r[i], 2 * r[i], fill, 'FFFFFF', 3 * k, name='ring', grad=grad)
    for i, it in enumerate(its):
        fill, grad, stroke, ink, icol = _stage(theme, i); beside, (fs, ls) = heads[i]; th = len(ls) * fs * 1.15
        if not inside[i]: cv.icon(list_icon(it, used), cx - isz / 2, mid[i] - isz / 2, isz, icol, bold=_ic(b)[1])
        elif beside:
            tw_ = max(text_w(l_, fs, 'bold') for l_ in ls); ox = cx - (isz + 10 * k + tw_) / 2
            cv.icon(list_icon(it, used), ox, mid[i] - isz / 2, isz, icol, bold=_ic(b)[1])
            cv.text(ox + isz + 10 * k, mid[i] - th / 2, tw_ + 4 * k, ls, fs, ink, 'bold', lh=1.15, name='ring title', src=it.get('title', ''), **_dk(ink))
        else:
            cv.icon(list_icon(it, used), cx - isz / 2, mid[i] - (isz + 6 * k + th) / 2, isz, icol, bold=_ic(b)[1])
            cv.text(cx - band[i] / 2, mid[i] - (isz + 6 * k + th) / 2 + isz + 6 * k, band[i], ls, fs, ink, 'bold', 'center', 1.15, name='ring title', src=it.get('title', ''), **_dk(ink))
        lc = grad[1] if grad else fill; th2 = len(tls[i][1]) * tls[i][0] * 1.2
        h = (wls[i][2] + 4 * k if wls[i][2] else 0) + th2 + (6 * k + tex[i][2] if tex[i][2] else 0)
        if under:   # in order under the rings, the first stage first
            yy = yb + 18 * k + sum(hs_[:i]) + 14 * k * i; cv.ellipse(x + 2 * k, yy + 3 * k, 10 * k, 10 * k, lc, name='ring leader dot')
        else:
            ex = cx + math.sqrt(max(0.0, R * R - (mid[i] - (yb - R)) * (mid[i] - (yb - R)))) + 10 * k
            cv.line(ex, mid[i], lx - 16 * k, mid[i], lc, 2 * k, dash=True, name='ring leader')
            cv.ellipse(lx - 21 * k, mid[i] - 5 * k, 10 * k, 10 * k, lc, name='ring leader dot'); yy = mid[i] - h / 2
        if wls[i][2]: _stage_draw(cv, it, wls[i], lx, yy, lw, k, name='ring'); yy += wls[i][2] + 4 * k
        if tls[i][1]: yy += cv.text(lx, yy, lw, tls[i][1], tls[i][0], INK, 'bold', lh=1.2, name='ring name', src=it.get('title', ''))
        if tex[i][2]: _stage_draw(cv, it, tex[i], lx, yy + 6 * k, lw, k, name='ring')
    return 2 * R + (18 * k + sum(hs_) + 14 * k * (n - 1) if under else 0)


DRAW.update({'stairs': draw_stairs, 'chevrons': draw_chevrons, 'pyramid': draw_pyramid, 'curve': draw_curve, 'hub': draw_hub, 'house': draw_house, 'cards': draw_cards, 'rings': draw_rings})


# ------------------------------------------------------------------------------------------------------------------ v6.9 weekly status report
# Three blocks for a project status one-pager: a status strip (overall RAG, week, lead), workstreams (RAG, owner, this week, next week)
# and risks & support required. RAG is always a colour AND a word (On track / At risk / Off track) - never colour alone.
RAG = {'green': ('2E8B57', 'On track'), 'amber': ('D99100', 'At risk'), 'red': ('C8102E', 'Off track'), '': ('9A8F88', 'Not set')}
RAG_WORDS = [('red', r'^\s*(r|red|off[ -]?track|blocked|critical|high|🔴)(?![a-z])'), ('amber', r'^\s*(a|amber|yellow|y|at[ -]?risk|watch|medium|med|🟠|🟡)(?![a-z])'),
             ('green', r'^\s*(g|green|on[ -]?track|ok|done|complete[d]?|low|🟢)(?![a-z])')]


def rag_of(v):
    s = str(v or '').strip().lower()
    for k, pat in RAG_WORDS:
        if re.match(pat, s): return k
    return ''


# ------------------------------------------------------------------------------------------------------------------ v6.9 status report - the bold Ulta look
# Ulta typography up front (Playfair Display Black section titles in Ulta orange), the brand gradient on table heads, the kit's own
# icon set throughout: a badge per workstream picked from its name, column icons, icon tiles in the status strip, a warning badge per risk.
STATUS_ICONS = [(r'secur|firewall|access|auth|compliance', 'lock'), (r'integrat|interface|api|connect|delta share|pipeline', 'network'), (r'test|qa|quality|uat|validat', 'verified-badge'),
                (r'\bai\b|data science|model|ml\b|machine learning|forecast', 'idea'), (r'report|\bbi\b|kpi|dashboard|analytics', 'bar-chart'),
                (r'data|requirement|mapping|source', 'laptop-analytics'), (r'design|architect', 'puzzle'), (r'assort|range', 'shelf'), (r'alloc|replen', 'shuffle'),
                (r'store|site', 'stores'), (r'price|pricing|promo', 'tag'), (r'deliver|logist|supply|dc\b|warehouse', 'delivery'), (r'change|train|people|adoption', 'team'),
                (r'vendor|partner|infosys|databricks|o9|sap|accenture|deloitte', 'team-growth'), (r'risk|issue|block', 'warning'), (r'support|help|escalat', 'support'),
                (r'budget|cost|finance', 'wallet'), (r'launch|go[- ]live|cutover|release', 'target'), (r'customer|guest', 'customer-love'), (r'plan|program|project', 'milestones')]
STATUS_FALLBACK = ['performance', 'gears', 'insight', 'layers', 'puzzle', 'cube', 'growth-check', 'focus', 'sliders', 'network']


def status_icon(text, used=None):
    """An icon for a workstream, a risk or a fact, from its words (the kit's icon set); a different one from those already used in the block."""
    used = used if used is not None else set(); s = str(text or '').lower()
    for pat, ic in STATUS_ICONS:
        if re.search(pat, s) and ic in ICONS and ic not in used: used.add(ic); return ic
    p = pick_icon(text)
    if p and p in ICONS and p not in used: used.add(p); return p
    ic = next((x for x in STATUS_FALLBACK if x in ICONS and x not in used), 'idea'); used.add(ic); return ic


FACT_ICON = {'overall status': 'performance', 'week ending': 'calendar', 'phase': 'milestones', 'project lead': 'person'}
FACT_ICONS = [(r'status|rag|health', 'performance'), (r'lead|owner|sponsor|manager|commander|decision owner', 'person'), (r'budget|cost|price|spend', 'wallet'),
              (r'week|period|date|start|end|go[- ]live|launch|steerco|updated|needed by|due|when', 'calendar'), (r'phase|stage|milestone', 'milestones'),
              (r'audience|for$|team|who', 'team'), (r'impact|severity|priority|risk', 'warning'), (r'duration|time|speed|frequency', 'speed'), (r'system|tool|platform', 'laptop-analytics'),
              (r'trigger|start when', 'pointer'), (r'topic|subject|area', 'idea'), (r'programme|program|project|product', 'layers')]


def fact_icon(label):
    """The status strip's icon for a fact, from its label (owner → person, dates → calendar, budget → wallet …)."""
    l = str(label or '').lower().strip()
    if l in FACT_ICON: return FACT_ICON[l]
    return next((ic for pat, ic in FACT_ICONS if re.search(pat, l) and ic in ICONS), None) or status_icon(label)


def status_title(cv, b, x, y, w, k, accent, icon=None, theme='ulta'):
    """A status-report section title: Ulta orange Playfair Display Black, with a round badge holding the section's icon - in the
    theme's own fill (the brand gradient on the Ulta theme) with a white icon, or a tinted disc with an orange icon where the theme
    draws its elements light."""
    if not b.get('title'): return 0
    d = 38 * k
    if theme in FILLED: st = style(theme, TITLE, 'mark'); cv.ellipse(x, y, d, d, st['fill'], None, name='section badge', grad=st['grad']); ink = 'FFFFFF'
    else: cv.ellipse(x, y, d, d, tint(TITLE, 0.86), None, name='section badge'); ink = 'E0531B'
    cv.icon(icon or status_icon(b['title']), x + d * 0.22, y + d * 0.22, d * 0.56, ink, bold=True)
    fs, ls = fit(b['title'], w - d - 18 * k, 64 * k, round(29 * k), round(21 * k), 'display', 1.05, 2)
    th = len(ls) * fs * 1.05; cv.text(x + d + 14 * k, y + max(0, (d - th) / 2) - 2 * k, w - d - 18 * k, ls, fs, TITLE, 'display', lh=1.05, name='block title', src=b['title'])
    return max(d, th) + 12 * k


def _rag_pill(cv, x, y, w, h, rag, k, word=True):
    """A RAG pill: solid in the RAG colour, the word in white (dark ink on amber, for contrast), a white dot. Returns its width."""
    c, label = RAG.get(rag, RAG['']); ink = shade(c, 0.3); fs = round(max(_fl(), 15 * k))   # calm: a light tint, a dot and the word in the RAG colour
    pw = min(w, (text_w(label, fs, 'bold') + 44 * k) if word else h)
    cv.rect(x, y, pw, h, tint(c, 0.84), None, h / 2, name='rag pill')
    cv.ellipse(x + 11 * k, y + h / 2 - 6 * k, 12 * k, 12 * k, c, None, name='rag dot')
    if word: cv.text(x + 30 * k, y + (h - fs * 1.15) / 2, pw - 34 * k, [label], fs, ink, 'bold', lh=1.15, name='rag word', src=label)
    return pw


def _head_style(theme, acc):
    """The table head (fill, gradient, ink): the pale orange with dark words on the Ulta theme (v136); where the theme fills its elements,
    a band in its colours - Ulta orange into gold with black words on sunset, the accent's dark velvet, charcoal; where it draws them
    light, a pale band in the accent with the words in its deep shade (Ulta orange on glow and paper)."""
    if theme == 'ulta': return LIGHT_CARD, None, INK
    if theme in FILLED: st = style(theme, TITLE if theme == 'sunset' else acc); return st['fill'], st['grad'], INK if theme == 'sunset' else 'FFFFFF'
    c = TITLE if theme in ('glow', 'paper') else acc
    return tint(c, 0.88), None, ('E0531B' if c == TITLE else shade(c, 0.3))


def _table(cv, x, y, w, k, theme, ci, heads, fracs, rows, rag_col=None, bar_col=None, name='status', head_icons=None, row_icons=None):
    """The status table: a brand-gradient head with column icons, rows with an icon badge before the first cell, text wrapped to fit
    (never cut); a RAG column draws a solid pill, a severity column colours the row's badge and left edge. Returns the height."""
    acc = PALETTE[ci % 5]; pad = 10 * k; hfs = round(max(_fl(), 13.5 * k)); fs = round(max(_fl() + 0.5, 15.5 * k)); lh = 1.25; bd = 34 * k
    hfill, hgrad, hink = _head_style(theme, acc)
    xs = [x]; [xs.append(xs[-1] + f * w) for f in fracs]
    hls = []   # v6.13: a long heading wraps (two lines) instead of running into the next column
    for j, h_ in enumerate(heads):
        ix = xs[j] + pad + (24 * k if (head_icons or [None] * len(heads))[j] else 0); hls.append(wrap(h_.upper(), max(10, xs[j + 1] - ix - pad - 4), hfs * 1.08, 'bold')[:2] if h_ else [])
    hh = max([len(l_) for l_ in hls] + [1]) * hfs * 1.2 + 2 * pad + 2 * k
    cv.rect(x, y, w, hh, hfill, None, 12 * k, grad=hgrad, name=name + ' head')
    for j, h_ in enumerate(heads):
        if not h_: continue
        ix = xs[j] + pad; hi = (head_icons or [None] * len(heads))[j]
        if hi: cv.icon(hi, ix, y + (hh - 18 * k) / 2, 18 * k, hink, bold=True); ix += 24 * k
        cw = xs[j + 1] - ix - pad; cv.text(ix, y + (hh - len(hls[j]) * hfs * 1.2) / 2, cw, hls[j], hfs, hink, 'bold', lh=1.2, name=name + ' heading', src=h_, spacing=1)
    yy = y + hh + 6 * k
    for i, r in enumerate(rows):
        cells = []
        for j, v in enumerate(r):
            if j in (rag_col, bar_col): cells.append(None); continue
            cw = xs[j + 1] - xs[j] - 2 * pad - (bd + 12 * k if j == 0 and row_icons else 0); f_ = fs + (1.5 if j == 0 else 0)
            cells.append((wrap(v or '—', cw, f_, 'bold' if j == 0 else 'body'), f_))
        rh = max([len(c[0]) * c[1] * lh for c in cells if c] + [bd]) + 2 * pad
        sev = RAG.get(rag_of(r[bar_col]), RAG[''])[0] if bar_col is not None else None
        cv.rect(x, yy, w, rh, 'FFFFFF', LINE, 12 * k, 1.2, name=name + ' row')
        if sev: cv.rect(x, yy, 7 * k, rh, sev, None, 3 * k, name=name + ' severity')
        for j, c in enumerate(cells):
            if j == rag_col: _rag_pill(cv, xs[j] + pad, yy + (rh - 32 * k) / 2, xs[j + 1] - xs[j] - 2 * pad, 32 * k, rag_of(r[j]), k); continue
            if c is None: continue
            ls, f_ = c; v = r[j] or '—'; tx = xs[j] + pad + (6 * k if sev and j == 0 else 0)
            if j == 0 and row_icons:
                bc = sev or PALETTE[(ci + i) % 5]; cv.ellipse(tx, yy + (rh - bd) / 2, bd, bd, tint(bc, 0.85), None, name=name + ' badge')
                cv.icon(row_icons[i], tx + bd * 0.2, yy + (rh - bd) / 2 + bd * 0.2, bd * 0.6, shade(bc, 0.15), bold=True); tx += bd + 12 * k
            th = len(ls) * f_ * lh
            cv.text(tx, yy + (rh - th) / 2, xs[j + 1] - tx - pad, ls, f_, INK if v != '—' else MUTED, 'bold' if j == 0 else 'body', lh=lh, name=name + ' cell', src=v)
        yy += rh + 5 * k
    return yy - y - 5 * k


def icon_disc(cv, x, y, d, c, ink, theme, rag, name):
    """A round icon disc in colour c; returns the icon's colour. Where the theme fills its elements, the disc takes the theme's fill
    (the brand gradient on the Ulta theme) and a white icon; a RAG colour, or a light theme, keeps a tinted disc and the ink given -
    status colours mark, they never carry a white icon (white on amber reads at 2:1)."""
    if theme in FILLED and not rag:
        st = style(theme, c, 'mark'); cv.ellipse(x, y, d, d, st['fill'], None, name=name, grad=st['grad']); return 'FFFFFF'
    cv.ellipse(x, y, d, d, tint(c, 0.85), None, name=name); return ink


def draw_status(cv, b, x, y, w, k, theme, ci):
    """The status strip: a white tile per fact with an accent edge and an icon disc (icon_disc: the theme's fill and a white icon; the
    overall status's RAG colour as a tint), the label in small caps and the value in Playfair Display."""
    its = b['items']; n = len(its); g = 14 * k; cw = (w - g * (n - 1)) / n; pad = 16 * k; ic = 36 * k; tw = cw - 2 * pad - ic - 20 * k; parts = []
    for i, it in enumerate(its):
        r = rag_of(it.get('rag')) if it.get('rag') else ''
        val = RAG[r][1] if r else it.get('value', '')
        vfs, vls = fit(val, tw, 96 * k, round(28 * k), round(15 * k), 'display', 1.05, 3); parts.append((r, val, vfs, vls))   # never cut: up to three lines
    h = max(pad * 2 + max(ic, 18 * k + 6 * k + len(p[3]) * p[2] * 1.05) for p in parts)
    for i, (it, (r, val, vfs, vls)) in enumerate(zip(its, parts)):
        cx = x + i * (cw + g); lab = str(it.get('label', ''))
        c = RAG[r][0] if r else PALETTE[(ci + i) % 5]; ink = shade(c, 0.25)   # a white tile, the value in the colour's deep shade
        cv.rect(cx, y, cw, h, 'FFFFFF', LINE, 16 * k, 1.2, name='status tile'); cv.rect(cx, y + 14 * k, 5 * k, h - 28 * k, c, None, 2.5 * k, name='status accent')
        disc_ink = icon_disc(cv, cx + pad, y + (h - ic) / 2 - 4 * k, ic + 8 * k, c, ink, theme, bool(r), 'status icon disc')
        cv.icon(fact_icon(lab), cx + pad + 4 * k + ic * 0.12, y + (h - ic) / 2 + ic * 0.12, ic * 0.76, disc_ink, bold=True); tx = cx + pad + ic + 20 * k
        bh = 18 * k + 6 * k + len(vls) * vfs * 1.05; ty = y + (h - bh) / 2
        cv.text(tx, ty, tw, wrap(lab.upper(), tw, round(max(_fl(), 13 * k)), 'bold')[:1], round(max(_fl(), 13 * k)), MUTED, 'bold', lh=1.2, name='status label', src=lab, spacing=1)
        cv.text(tx, ty + 24 * k, tw, vls, vfs, ink, 'display', lh=1.05, name='status value', src=val)
    return h


def draw_rag(cv, b, x, y, w, k, theme, ci):
    c0, c1 = (b.get('cols') or ['This week', 'Next week'])[:2]; used = set()
    rows = [[it.get('name', ''), it.get('owner', ''), it.get('rag', ''), it.get('now', ''), it.get('next', '')] for it in b['items']]
    icons = [status_icon(it.get('name', ''), used) for it in b['items']]
    return _table(cv, x, y, w, k, theme, ci, ['Workstream', 'Owner', 'Status', c0, c1], [0.22, 0.14, 0.14, 0.25, 0.25], rows, rag_col=2, name='workstream',
                  head_icons=['layers', 'person', 'performance', 'calendar', 'trend-up'], row_icons=icons)


def draw_risks(cv, b, x, y, w, k, theme, ci):
    its = b['items']; keep = [f for f in ('title', 'text', 'owner', 'due') if f in ('title',) or any(str(it.get(f) or '').strip() not in ('', '—', '-') for it in its)]   # v6.13: empty columns go
    H = {'title': ('Risk or ask', 0.42, 'warning'), 'text': ('Support needed from', 0.25, 'support'), 'owner': ('Owner', 0.17, 'person'), 'due': ('Need by', 0.16, 'calendar')}
    tot = _total(H[f][1] for f in keep); rows = [[it.get(f, '') for f in keep] + [it.get('rag', '')] for it in its]
    return _table(cv, x, y, w, k, theme, ci + 1, [H[f][0] for f in keep] + [''], [H[f][1] / tot for f in keep] + [0.0], rows, bar_col=len(keep), name='risk',
                  head_icons=[H[f][2] for f in keep] + [None], row_icons=['warning'] * len(rows))


DRAW.update({'status': draw_status, 'rag': draw_rag, 'risks': draw_risks})


# the content template: what the team fills in (Word or Markdown); status_spec reads it without AI
STATUS_TEMPLATE_MD = """# Demand Planning - Weekly Status
Week ending: 10/09
Overall status: Green
Project lead: Rowan
Phase: Build

## Workstreams
| Workstream | Owner | Status | This week (10/09) | Next week (10/16) |
|---|---|---|---|---|
| Data Requirements | Felix / Mila | Green | Paper model for inventory & promo data via Ulta Medallion | Data mapping for Item, Loc, Time, Sales, Listing |
| Integration Design | Rowan / Elliot | Amber |-| Historical data load KDD & architecture review |
| Testing | Owen / Ines / Arlo | Green |-| Testing strategy & framework deliverable |
| AI / Data Science | Vance / Elliot | Green | Definition of Done for DP Data Science inputs (draft) | Definition of Done (final) · meeting cadence & agenda |
| Reporting & BI | Theo | Green |-| DP reports inventory & new KPI |

## Risks & support required
| Risk or ask | Support needed from | Owner | Need by | Severity |
|---|---|---|---|---|
| Validate 3-year historical data availability & confirm implementation timelines | Databricks & Infosys | Rowan | 10/16 | Amber |
| Confirm firewall rules & Delta Share connectivity before data load | Ulta Security & o9 | Elliot | 10/14 | Red |

## Milestones
- 10/09: Paper model for inventory & promo data
- 10/16: Historical data load KDD & architecture review
- 10/23: Testing strategy & framework signed off
- 10/30: Data mapping complete

## Decision needed
Approve Delta Share as the connection for the historical data load by 10/14.
"""

STATUS_KEYS = {'week': r'^(week ending|week of|week|period|reporting period|as of|date)$', 'overall': r'^(overall( status)?|status|overall rag|rag)$',
               'lead': r'^(project lead|lead|owner|pm|project manager|sponsor)$', 'phase': r'^(phase|stage)$', 'project': r'^(project|programme|program)$'}
COLS_RAG = {'name': r'workstream|stream|area|team|track|work ?package', 'owner': r'owner|lead|who|responsible', 'rag': r'status|rag|health',
            'now': r'this week|current|done|completed|progress|now', 'next': r'next week|next|planned|upcoming|coming'}
COLS_RISK = {'title': r'risk|issue|ask|item|blocker|dependency', 'text': r'support|from|need(ed)? from|help|who can', 'owner': r'owner|raised|lead',
             'due': r'need by|due|by when|date|deadline', 'rag': r'severity|rag|impact|priority|status'}


def _detab(text):
    """A table copied out of Word arrives as tab-separated lines: turn them into | rows so the reader sees a table."""
    out = []
    for l in str(text or '').replace('\r', '').split('\n'):
        out.append('| ' + ' | '.join(c.strip() for c in l.split('\t')) + ' |' if l.count('\t') >= 1 and not l.lstrip().startswith(('#', '-', '*', '|')) else l)
    return '\n'.join(out)


def _map_cols(head, spec):
    """Column index per field, matched on the header words; a field with no column gets None."""
    used = set(); out = {}
    for f, pat in spec.items():
        j = next((i for i, h in enumerate(head) if i not in used and re.search(pat, h or '', re.I)), None)
        out[f] = j
        if j is not None: used.add(j)
    return out


def _week_label(h, default):
    m = re.search(r'\(([^)]+)\)', h or ''); return (default + ' (' + m.group(1) + ')') if m else (h.strip() if h and h.strip() else default)


def status_spec(text, fmt='slide', theme='ulta', title=''):
    """The weekly status content template → a status-report infographic, by rules (no AI). Lines "Key: value" before the first section
    fill the status strip; a Workstreams table (or bullets "Name - owner - status - this week - next week") the workstream block; a Risks
    table the risks block; dated bullets the milestones; other sections a list or the closing takeaway."""
    text = _detab(text); lines = text.split('\n'); facts = {}; kept = []; seen_h2 = False
    for l in lines:
        s = l.strip()
        if s.startswith('## '): seen_h2 = True
        m = re.match(r'^([A-Za-z][A-Za-z /&]{1,28}):\s*(.*)$', s)
        if not seen_h2 and m and not s.startswith('|'):
            if re.fullmatch(r'[\s—–\-.]*|n/?a|none', m.group(2).strip(), re.I): continue   # v6.13: an empty fact draws nothing
            key = next((k for k, pat in STATUS_KEYS.items() if re.match(pat, m.group(1).strip(), re.I)), None)
            if key and key not in facts: facts[key] = clean(m.group(2), 60); continue
        kept.append(l)
    t0, subtitle, source, secs = _sections('\n'.join(kept))
    blocks = []; strip = []
    if facts.get('overall'): strip.append({'label': 'Overall status', 'value': facts['overall'], 'rag': facts['overall']})
    if facts.get('week'): strip.append({'label': 'Week ending', 'value': facts['week']})
    if facts.get('phase'): strip.append({'label': 'Phase', 'value': facts['phase']})
    if facts.get('lead'): strip.append({'label': 'Project lead', 'value': facts['lead']})
    if strip: blocks.append({'type': 'status', 'items': strip})
    for s in secs:
        h = s['title'] or ''; rows = s['rows']
        if re.search(r'how to (fill|use)|instructions|ignores this', h, re.I): continue   # the template's own guidance
        if re.search(r'work ?stream|status by|teams?|tracks?|areas?', h, re.I) or (rows and re.search(COLS_RAG['name'], ' '.join(rows[0]), re.I) and re.search(COLS_RAG['rag'], ' '.join(rows[0]), re.I)):
            items = []; cols = ['This week', 'Next week']
            if rows:
                head = rows[0]; cm = _map_cols(head, COLS_RAG)
                if cm['now'] is not None: cols[0] = _week_label(head[cm['now']], 'This week')
                if cm['next'] is not None: cols[1] = _week_label(head[cm['next']], 'Next week')
                for r in rows[1:]:
                    g = lambda f: (r[cm[f]] if cm[f] is not None and cm[f] < len(r) else '').strip()
                    if g('name'): items.append({'name': g('name'), 'owner': g('owner').rstrip(' /'), 'rag': g('rag'), 'now': g('now'), 'next': g('next')})
            else:
                for x in s['bullets']:
                    p = [q.strip() for q in re.split(r'\s+[—–|]\s+|\s+-\s+', x)]
                    if p and p[0]: items.append({'name': p[0], 'owner': p[1] if len(p) > 1 else '', 'rag': p[2] if len(p) > 2 else '', 'now': p[3] if len(p) > 3 else '', 'next': p[4] if len(p) > 4 else ''})
            if items: blocks.append({'type': 'rag', 'title': h if not re.fullmatch(r'work ?streams?', h, re.I) else 'Workstreams', 'cols': cols, 'items': items}); continue
        if re.search(r'risk|issue|support|blocker|depend|escalat', h, re.I):
            items = []
            if rows:
                head = rows[0]; cm = _map_cols(head, COLS_RISK)
                for r in rows[1:]:
                    g = lambda f: (r[cm[f]] if cm[f] is not None and cm[f] < len(r) else '').strip()
                    if g('title') or g('text'): items.append({'title': g('title') or g('text'), 'text': g('text') if g('title') else '', 'owner': g('owner'), 'due': g('due'), 'rag': g('rag')})
            else:
                for x in s['bullets']:
                    a, sep, b2 = x.partition(' — ') if ' — ' in x else x.partition(': ')
                    items.append({'title': b2 if sep else x, 'text': a if sep else '', 'owner': '', 'due': '', 'rag': ''})
            if items: blocks.append({'type': 'risks', 'title': h or 'Risks & support required', 'items': items}); continue
        if rows and len(rows) > 1 and re.search(r'milestone|timeline|dates|roadmap|upcoming|plan', h, re.I):   # v6.13: a milestones table
            cm = _map_cols(rows[0], {'when': r'date|when|due|by|target', 'title': r'milestone|what|item|event|deliverable'}); items = []
            for r in rows[1:8]:
                w_ = (r[cm['when']] if cm['when'] is not None and cm['when'] < len(r) else '').strip(); t_ = (r[cm['title']] if cm['title'] is not None and cm['title'] < len(r) else r[0]).strip()
                if w_ or t_: items.append({'when': clean(w_, 18), 'title': clean(t_, 60)})
            if len(items) >= 2: blocks.append({'type': 'timeline', 'title': h, 'items': items}); continue
        if s['bullets'] and re.search(r'milestone|timeline|dates|roadmap|upcoming|plan', h, re.I):
            items = []
            for x in s['bullets'][:7]:
                m = re.match(r'^([^:—–]{1,18}?)\s*[:—–]\s*(.+)$', x)
                items.append({'when': m.group(1).strip(), 'title': clean(m.group(2), 60)} if m else {'when': '', 'title': clean(x, 60)})
            blocks.append({'type': 'timeline', 'title': h, 'items': items}); continue
        if s['paras'] and not s['bullets'] and not rows:
            blocks.append({'type': 'takeaway', 'title': '' if re.search(r'decision|ask|summary|bottom line', h, re.I) else h, 'text': (h + ': ' if re.search(r'decision|ask', h, re.I) else '') + ' '.join(s['paras'])[:200], 'icon': 'target'}); continue
        if s['bullets']:
            blocks.append({'type': 'list', 'title': h, 'items': [{'title': clean(x, 50) if len(x) <= 50 else clean(' '.join(x.split()[:5]), 50), 'text': '' if len(x) <= 50 else clean(' '.join(x.split()[5:]), 140), 'icon': pick_icon(x)} for x in s['bullets'][:6]]})
    sub = subtitle or ' · '.join(x for x in (facts.get('project'), ('Week ending ' + facts['week']) if facts.get('week') else '') if x)
    return normalise({'title': title or t0 or 'Weekly status', 'kicker': 'Weekly status report', 'subtitle': sub if not strip else subtitle, 'source': source,
                      'format': fmt, 'theme': theme, 'template': 'status', 'blocks': blocks})


TEMPLATES = [{'id': 'free', 'name': 'Free-form', 'blurb': 'Your content picks the blocks: numbers, steps, dates, a takeaway'},
             {'id': 'status', 'name': 'Weekly status report', 'blurb': 'Overall status, workstreams with RAG, risks & support required, milestones - from the status content template'}]


def rows_of(blocks, width):
    """Wide blocks take a row; two narrow ones (bars, rings, quote) share one when there is room."""
    rows = []; i = 0
    while i < len(blocks):
        b = blocks[i]
        pairable = lambda x: x['type'] in HALF   # v6.13 squeezed onto one 16:9 slide: these share a row side by side
        if b.get('half') and i + 1 < len(blocks) and blocks[i + 1].get('half') and width >= 760: rows.append([b, blocks[i + 1]]); i += 2   # v139: asked for
        elif b['type'] not in WIDE and i + 1 < len(blocks) and blocks[i + 1]['type'] not in WIDE and width >= 880: rows.append([b, blocks[i + 1]]); i += 2
        elif SQUEEZE[0] and width >= 1200 and pairable(b) and i + 1 < len(blocks) and pairable(blocks[i + 1]): rows.append([b, blocks[i + 1]]); i += 2
        else: rows.append([b]); i += 1
    return rows


SECTION_ICON = {'rag': 'team', 'risks': 'warning', 'timeline': 'milestones', 'list': 'idea', 'steps': 'list', 'stats': 'bar-chart'}


def _btitle(cv, b, x, y, w, k, accent, theme):
    """A block's title: the status report's Ulta section title (Playfair, Ulta orange, icon badge), else the standard one."""
    if b.get('_tpl') not in (None, '', 'free'): return status_title(cv, b, x, y, w, k, accent, SECTION_ICON.get(b['type']) if b['type'] in ('rag', 'risks') else None, theme)   # every template: Ulta section titles, an icon from the heading
    return block_title(cv, b, x, y, w, k, accent)


def draw_row(cv, row, x, y, w, k, theme, ci0):
    if len(row) == 1:
        b = row[0]; ht = _btitle(cv, b, x, y, w, k, PALETTE[ci0 % 5], theme); return ht + DRAW[b['type']](cv, b, x, y + ht, w, k, theme, ci0)
    g = 44 * k; cw = (w - g) / 2; hs = []
    for j, b in enumerate(row):
        ht = _btitle(cv, b, x + j * (cw + g), y, cw, k, PALETTE[(ci0 + j) % 5], theme); hs.append(ht + DRAW[b['type']](cv, b, x + j * (cw + g), y + ht, cw, k, theme, ci0 + j))
    return max(hs)


def header(cv, spec, fmt, k):
    """The one-pager / square header: gradient rule, kicker, the title in Playfair Display Black, the subtitle. Returns the bottom."""
    F = FORMATS[fmt]; m = F['margin']; W = F['w']; y = m
    cv.rect(0, 0, W, 12, TITLE, None, 0, grad=TOP_RULE, name='top rule', chrome=False)
    if spec.get('kicker'): y += cv.text(m, y, W - 2 * m, [spec['kicker']], 15, 'E0531B', 'bold', lh=1.2, name='kicker', src=spec['kicker'], spacing=2) + 10
    hi = 64 if fmt == 'onepager' else 58
    fs, ls = fit(spec['title'], W - 2 * m, hi * 2.3, hi, 34, 'display', 1.06, 3)
    if spec.get('template') not in (None, '', 'free'):
        f1, l1 = fit(spec['title'], W - 2 * m, hi * 1.1, hi, 42, 'display', 1.06, 1, report=False)   # a probe: kept only if one line
        if len(wrap(spec['title'], W - 2 * m, f1, 'display')) == 1: fs, ls = f1, l1
    y += cv.text(m, y, W - 2 * m, ls, fs, TITLE, 'display', lh=1.06, name='title', src=spec['title']) + 14
    if spec.get('subtitle'):
        sfs, sls = fit(spec['subtitle'], W - 2 * m, 90, 21, 15, 'body', 1.35, 3); y += cv.text(m, y, W - 2 * m, sls, sfs, MUTED, 'body', lh=1.35, name='subtitle', src=spec['subtitle'])
    return y + 34


def footer(cv, spec, fmt):
    F = FORMATS[fmt]; m = F['margin']; W, H = F['w'], F['h']; y = H - m + 6
    cv.line(m, y - 22, W - m, y - 22, LINE, 1.5, name='footer rule')
    if spec.get('source'):
        fs, ls = fit('Source: ' + spec['source'], W - 2 * m - 170, 36, 12.5, 10, 'body', 1.3, 2); cv.text(m, y - 8, W - 2 * m - 170, ls, fs, MUTED, 'body', lh=1.3, name='source', src='Source: ' + spec['source'])
    cv.els.append({'k': 'logo', 'x': W - m - 118, 'y': y - 10, 'w': 118, 'h': 47.7, 'name': 'logo'})
    return y - 22 - 24


def _relayout(spec, blocks, warn):
    s2 = dict(spec, blocks=[{k: v for k, v in b.items() if k not in ('_ic', '_tpl', '_im')} for b in blocks]); d = layout(s2); d['warnings'] = warn + d['warnings']; return d


def layout(spec):
    """(v6.9) A weekly status report on a 16:9 slide is two slides, as status decks are: status and workstreams, then "(cont.)" with
    risks, milestones and the decision - nothing dropped, both at full size. The design is page 1 with `pages` [page 2]; its spec keeps
    every block, so editing works on the whole report."""
    if isinstance(spec, dict) and spec.get('_page') is None:
        n_ = normalise(spec)
        if n_.get('template') not in (None, '', 'free') and n_['format'] == 'slide' and len(n_['blocks']) >= 2 and not _fits1(n_):
            SQUEEZE[0] = True   # v6.13: squeeze onto one slide first - sizes down to 62 %, text down to 8 pt (the PowerPoint's readability floor)
            try: d1 = _layout1(dict(n_, _page=1))
            finally: SQUEEZE[0] = False
            if not [w for w in d1['warnings'] if 'left out' in w]: return d1
            pages = _paginate(n_)   # still too much at 8 pt: continue on "(cont.)" slides, nothing left out   # v6.13: as many slides as the content needs - sections never dropped, a long one split across slides
            if len(pages) > 1 and len(pages[-1]) == 1 and pages[-1][0]['type'] == 'takeaway' and not n_.get('subtitle') and _fits1(dict(n_, blocks=pages[0], subtitle=pages[-1][0]['text'])):
                n_ = dict(n_, subtitle=pages.pop()[0]['text'])   # a lone closing decision: under the title of slide 1, not a slide of its own
            if len(pages) == 1: return _layout1(dict(n_, blocks=pages[0], _page=1)) | {'spec': n_}
            if len(pages) > 1:
                ds = [_layout1(dict(n_, blocks=pg, _page=i + 1, **({} if i == 0 else {'title': n_['title'] + ' (cont.)', 'subtitle': ''}))) for i, pg in enumerate(pages)]
                d1 = ds[0]; d1['spec'] = n_; d1['pages'] = ds[1:]; d1['warnings'] = [w for d_ in ds for w in d_['warnings']]; return d1
    return _layout1(spec)


SPLIT = {'ragcards', 'table', 'rag', 'risks', 'list', 'timeline', 'steps'}   # blocks whose items can continue on the next slide


def _paginate(spec, max_pages=6):
    """16:9 pages for a template: each slide takes sections while they fit at a readable size; a section too long for a slide on its own is
    split by its items ("Workstreams" then "Workstreams (cont.)"). Nothing is left out."""
    queue = [dict(b) for b in spec['blocks']]; pages = []
    while queue and len(pages) < max_pages:
        page = []
        while queue:
            if _fits1(dict(spec, blocks=page + [queue[0]], **({} if not pages else {'subtitle': ''}))): page.append(queue.pop(0)); continue
            if page: break
            b = queue[0]; its = b.get('items') or []
            if b['type'] in SPLIT and len(its) > 1:   # alone it does not fit: half its items now, the rest on the next slide
                h = (len(its) + 1) // 2; queue[0:1] = [dict(b, items=its[:h]), dict(b, items=its[h:], title=(b.get('title') + ' (cont.)') if b.get('title') else '')]; continue
            page.append(queue.pop(0)); break   # cannot split: it goes on its own slide at the smallest readable size
        pages.append(page)
    if queue: pages[-1] += queue
    return pages


def _fits1(spec):
    """A template on one slide at a readable size, nothing left out."""
    d_ = _layout1(dict(spec, _page=1)); return not [w for w in d_['warnings'] if 'left out' in w or 'dense' in w or 'under the title' in w]


def page_svgs(d, chrome=True):
    """Every page's SVG: the design, then its continuation pages (a status report on a slide)."""
    return [to_svg(d, chrome=chrome)] + [to_svg(p, chrome=chrome) for p in d.get('pages') or []]


def _layout1(spec):
    """spec → design {spec, w, h, els, warnings}: the body is fitted by shrinking every size in steps (never below 62 %); a block that still
    does not fit is left out and named in the warnings."""
    spec = normalise(spec); fmt = spec['format']; F = FORMATS[fmt]; W, H = F['w'], F['h']; theme = spec['theme']; warn = []
    LOOK[0] = spec.get('look') or 'light'
    blocks = list(spec['blocks'])
    for b_ in blocks: b_['_ic'] = spec.get('icons') or {}; b_['_tpl'] = spec.get('template') or ''; b_['_im'] = spec.get('images') or {}   # the icon options, the template and the pictures reach every block's drawing (removed again below)
    if not blocks: blocks = [{'type': 'takeaway', 'text': spec.get('subtitle') or 'Add content: paste a page, a list of numbers, steps or points.'}]
    top = Canvas()
    if fmt == 'slide':
        tfs, tls = fit(spec['title'], 1400, 62, 60, 30, 'display', 0.95, 1)   # v6.12: one line, as on the template - down to 30 px before a second line
        if len(wrap(spec['title'], 1400, tfs, 'display')) > 1: tfs, tls = 40, wrap(spec['title'], 1400, 40, 'display')[:2]
        top.text(73, 53 if len(tls) == 1 else 40, 1400 if len(tls) == 1 else 1100, tls, tfs, TITLE, 'display', lh=0.95, name='title', src=spec['title'], chrome=True)
        top.els.append({'k': 'logo', 'x': 62, 'y': 806, 'w': 130, 'h': 52.6, 'name': 'logo', 'chrome': True})
        top.text(1135, 842, 400, ['Ulta Beauty | Proprietary & Confidential'], 11.5, INK, 'body', 'right', name='footer', chrome=True)
        bx, by, bw, bh = F['body']
        if spec.get('subtitle'):
            sfs, sls = fit(spec['subtitle'], bw, 56, 19, 14, 'body', 1.3, 2); by += top.text(bx, by - 6, bw, sls, sfs, MUTED, 'body', lh=1.3, name='subtitle', src=spec['subtitle']) + 14; bh = F['body'][3] - (by - F['body'][1])
    else:
        by = header(top, spec, fmt, 1); bottom = footer(top, spec, fmt); bx = F['margin']; bw = W - 2 * bx; bh = bottom - by
    tpl_ = spec.get('template') not in (None, '', 'free'); MIN_FS[0] = 14 if tpl_ else 0; body = None; kmin = (0.62 if SQUEEZE[0] else 0.8 if fmt == 'slide' else 0.66) if tpl_ else 0.62   # a template stays readable: on a slide 80 %, a page 70 %
    QUIET[0] = True
    while blocks:
        rows = rows_of(blocks, bw)
        for k in [x for x in [1.45, 1.36, 1.28, 1.2, 1.12, 1.05, 1.0, 0.94, 0.88, 0.82, 0.8, 0.76, 0.7, 0.66, 0.62] if x >= kmin]:   # sparse content grows (to 145 %) before space is spread
            g = 34 * k; cv = Canvas(); hs = []
            for r in rows:
                t = Canvas(); hs.append(draw_row(t, r, 0, 0, bw, k, theme, sum(len(x) for x in rows[:rows.index(r)])))
            tot = _total(hs) + g * (len(rows) - 1)
            if tot <= bh: body = (rows, hs, k, g, tot); break
        if body: break
        drop = next((i for i in range(len(blocks) - 1, -1, -1) if blocks[i]['type'] in ('timeline', 'list', 'steps')), len(blocks) - 1) if tpl_ else len(blocks) - 1   # the decision stays; milestones go first
        if tpl_ and fmt != 'slide' and blocks[drop]['type'] in ('takeaway', 'status'):   # on a page the decision and the facts stay: the last other section goes
            drop = next((i for i in range(len(blocks) - 1, -1, -1) if blocks[i]['type'] not in ('takeaway', 'status')), drop)
        if tpl_ and blocks[drop]['type'] == 'takeaway' and not spec.get('subtitle') and fmt == 'slide':   # the decision moves under the title rather than going
            spec['subtitle'] = blocks[drop]['text']; blocks.pop(drop); warn.append('the decision is shown under the title - the slide has no room for it as a block'); QUIET[0] = False; return _relayout(spec, blocks, warn)
        warn.append(f'"{blocks[drop].get("title") or blocks[drop]["type"]}" left out - it does not fit on the {F["name"].lower()}; ' + ('shorter sections give it room' if fmt == 'onepager' else 'the one-pager has room for it')); blocks.pop(drop)
    QUIET[0] = False; cv = Canvas(); cv.els = top.els
    if body:
        rows, hs, k, g, tot = body; extra = bh - tot; g2 = g + (min(extra / (len(rows) - 1), 46) if len(rows) > 1 else 0)
        y = by + max(0, (bh - (_total(hs) + g2 * (len(rows) - 1))) / 2)   # what is left is shared above and below
        for i, r in enumerate(rows):
            draw_row(cv, r, bx, y, bw, k, theme, sum(len(x) for x in rows[:i])); y += hs[i] + g2
        if k < 0.8: warn.append(f'the content is dense — sizes shrunk to {round(k * 100)} %; ' + ('a shorter section or one fewer gives larger text' if fmt == 'onepager' else 'the one-pager gives it more room'))
    spec['blocks'] = [b for b in spec['blocks'] if b in blocks] if blocks else spec['blocks']
    bg = 'FFF3ED' if fmt == 'slide' else 'F8F5F5'   # a slide: the template's own content background (v136), as the PowerPoint shows it
    for b_ in spec['blocks']: b_.pop('_ic', None); b_.pop('_tpl', None); b_.pop('_im', None)
    readable_icons(cv.els, bg); readable_text(cv.els, bg); MIN_FS[0] = 0; LOOK[0] = 'light'
    return {'spec': spec, 'w': W, 'h': H, 'bg': bg, 'els': cv.els, 'warnings': warn}


def _lum(h):
    try: r, g, b = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))
    except Exception: return None   # noqa: BLE001
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def _contrast(a, b):
    la, lb = _lum(a), _lum(b)
    if la is None or lb is None: return 21.0
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)


def _in_poly(pts, px, py):
    """Ray casting: is the point inside the polygon (a funnel band, a chevron, a hexagon)?"""
    inside = False; n = len(pts)
    for a in range(n):
        x1, y1 = pts[a]; x2, y2 = pts[(a + 1) % n]
        if (y1 > py) != (y2 > py) and px < x1 + (py - y1) * (x2 - x1) / (y2 - y1): inside = not inside
    return inside


def _under(els, i, px, py, bg):
    """The colour a point of element i sits on: the topmost filled rect / ellipse / polygon drawn before it that contains the point,
    blended with what lies under it when it is see-through (a Venn circle); else the page."""
    return _under_at(els, i, px, py, bg)[0]


def _under_at(els, i, px, py, bg, m=None):
    """(colour, index of the shape) a point of element i sits on; the index is None on the page itself. m: the brand pass's
    fill mapping - it recolours each fill and gradient stop, not the blend a see-through shape makes, so a blend is made of
    the mapped colours (as a viewer of the recoloured file sees it)."""
    m = m or (lambda c: c)
    for q in range(i - 1, -1, -1):
        e = els[q]
        if e.get('k') not in ('rect', 'ellipse', 'poly') or not (e.get('fill') or e.get('grad')): continue
        if e['k'] == 'poly': inside = _in_poly(e['pts'], px, py)
        else:
            x, y, w, h = e['x'], e['y'], e['w'], e['h']
            if e['k'] == 'rect': inside = x <= px <= x + w and y <= py <= y + h
            else: inside = w > 0 and h > 0 and ((px - x - w / 2) / (w / 2)) ** 2 + ((py - y - h / 2) / (h / 2)) ** 2 <= 1
        if not inside: continue
        if e.get('grad'):   # the gradient where the point sits (it runs left to right; a shape from points, across its box)
            x0_, _, x1_, _ = _box(e); f = _mix(m(e['grad'][0]), m(e['grad'][1]), max(0.0, min(1.0, (px - x0_) / (x1_ - x0_))) if x1_ > x0_ else 0.5)
        else: f = m(e['fill'])
        a = e.get('alpha')
        return (_mix(_under_at(els, q, px, py, bg, m)[0], f, a) if a not in (None, 1, 1.0) else f), q
    return m(bg), None


TEXT_NEED, TEXT_NEED_LARGE = 4.5, 3.0   # WCAG 2.1 AA: text 4.5:1; large text (18 pt, or 14 pt bold) 3:1
DEEP_TEXT = {'pink': ('C10060', 'DB0058', 'D01381'), 'orange': (), 'neutral': ('404040',)}   # template colours that read on a light ground, by hue
STATUS_TEXT = {'00B050', '0BA03E', 'FFC000', 'FF0000'}   # status colours mark a dot or a pill, never words: the brand pass turns such text grey
DOTS = ('●', '■', '▲', '▼', '◆', '•', '→')   # marks, not words: a status dot, the compare arrow (a white mark on orange reads at 3:1)
# The files are recoloured to the template's palette (tools/ulta_conform.py; the page's own engine does the same): a colour is
# judged as the reader will see it - a shade of orange that reads at 5:1 comes back as the palette's lighter orange at 3:1.
TEMPLATE_PALETTE = ['000000', '404040', '505152', '5D0F43', '8A8C8F', 'C10060', 'D01381', 'D9D9D9', 'DB0058', 'DE7445', 'E0531B', 'E4C8DB',
                    'E8275A', 'E9341C', 'EA0B59', 'EE6C37', 'F14C24', 'F16A1C', 'F24C26', 'F26923', 'F2F2F2', 'F3EDEB', 'F8F5F5', 'F9E3DE',
                    'FAD3DB', 'FDE1D2', 'FF7826', 'FF893F', 'FFE8EE', 'FFF2F6', 'FFF3ED', 'FFF5F3', 'FFFFFF']
STATUS_COLOURS = ['00B050', '0BA03E', 'FFC000', 'FF0000']
CALM = ('5D0F43', 'E8275A', '000000', '404040', 'FFFFFF', 'F8F5F5')
_KEEP = set(TEMPLATE_PALETTE) | set(STATUS_COLOURS); _LABS = {}


def _lab(h):
    if h not in _LABS:
        def lin(c):
            c /= 255
            return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
        r, g, b = (lin(int(h[i:i + 2], 16)) for i in (0, 2, 4))
        x, y, z = (r * .4124 + g * .3576 + b * .1805) / .9505, r * .2126 + g * .7152 + b * .0722, (r * .0193 + g * .1192 + b * .9505) / 1.089
        f = lambda t_: t_ ** (1 / 3) if t_ > 0.008856 else 7.787 * t_ + 16 / 116
        _LABS[h] = (116 * f(y) - 16, 500 * (f(x) - f(y)), 200 * (f(y) - f(z)))
    return _LABS[h]


def _nearest(keys, L):
    return min(keys, key=lambda c: sum((a - b) ** 2 for a, b in zip(_lab(c), L)))


def brand_fill(h):
    """The colour a fill is drawn in once the files are recoloured (tools/ulta_conform.py Mapper)."""
    h = str(h).upper()
    if h in _KEEP: return h
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4)); sat = max(r, g, b) - min(r, g, b); light = min(r, g, b) > 200
    if sat >= 40 and g > r and g >= b and not light: return '00B050'
    if sat >= 60 and r > 200 and 140 <= g <= 215 and b < 120 and not light: return 'FFC000'
    keys = [k for k in TEMPLATE_PALETTE if k in CALM] if sat >= 25 and (b > r or g > r) else TEMPLATE_PALETTE
    return _nearest(keys, _lab(h))


def brand_text(h):
    """The colour a text is drawn in once the files are recoloured: the nearest palette colour, never a status colour."""
    h = str(h).upper()
    if h in _KEEP and h not in STATUS_TEXT: return h
    return _nearest(TEMPLATE_PALETTE, _lab(h))


def _family(h):
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    if max(r, g, b) - min(r, g, b) < 25: return 'neutral'
    return 'pink' if b > g + 10 else 'orange'


def text_need(e):
    """The contrast a text needs: 3:1 when it is large - 18 pt, or 14 pt in bold (WCAG; v139: the previews and PDFs draw the bold face
    the PowerPoint names) - else 4.5:1. A canvas unit is 0.6 pt on a slide and on a page."""
    pt = (e.get('fs') or 0) * 0.6
    return TEXT_NEED_LARGE if pt >= 18 or (e.get('font') == 'bold' and pt >= 14) else TEXT_NEED


def _text_point(e):
    """Where a text's first line sits: the middle of the words, not of a box that may run past the fill they are written on."""
    ln = (e.get('lines') or [''])[0]; tw = min(e['w'], text_w(ln, e['fs'], e.get('font') or 'body'))
    x = e['x'] + (e['w'] - tw / 2 if e.get('align') == 'right' else e['w'] / 2 if e.get('align') == 'center' else tw / 2)
    return x, e['y'] + e['fs'] * (e.get('lh') or 1.22) / 2


def _text_ends(e):
    """Where the words of a text's first line start and end."""
    ln = (e.get('lines') or [''])[0]; tw = min(e['w'], text_w(ln, e['fs'], e.get('font') or 'body'))
    x0 = e['x'] + (e['w'] - tw if e.get('align') == 'right' else (e['w'] - tw) / 2 if e.get('align') == 'center' else 0)
    y = e['y'] + e['fs'] * (e.get('lh') or 1.22) / 2
    return (x0, y), (x0 + tw, y)


def _grounds(els, i, e, bg, m):
    """([colours], index of the shape) a text sits on: under the middle of its first line - and on a gradient under both ends of the
    line too (v130): the words have to read along the whole run, not only where it is halfway."""
    under, q = _under_at(els, i, *_text_point(e), bg, m)
    if q is None or not els[q].get('grad'): return [under], q
    return [under] + [_under_at(els, i, px, py, bg, m)[0] for px, py in _text_ends(e)], q


def _apca(t, b):
    """How well words in t read on b to the eye (APCA 0.0.98G, the measure of the WCAG 3 drafts): positive for words darker than
    their ground, negative for lighter ones, 0 when they do not read."""
    def y(h):
        r, g, b_ = (int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)); v = 0.2126729 * r ** 2.4 + 0.7151522 * g ** 2.4 + 0.0721750 * b_ ** 2.4
        return v + (0.022 - v) ** 1.414 if v < 0.022 else v
    yt, yb = y(t), y(b)
    if abs(yb - yt) < 0.0005: return 0.0
    if yb > yt: s = (yb ** 0.56 - yt ** 0.57) * 1.14; return 0.0 if s < 0.1 else (s - 0.027) * 100
    s = (yb ** 0.65 - yt ** 0.62) * 1.14; return 0.0 if s > -0.1 else (s + 0.027) * 100


def _light_better(c):
    """Light words read better on c than dark ones: every brand colour but gold and the tints - the grounds people see as dark, where
    WCAG 2 alone would pick black for the oranges, pinks and reds."""
    return abs(_apca('FFFFFF', c)) > abs(_apca(INK, c))


def _readable_on(color, grounds, need):
    """readable_text_color over every ground a line sits on, judged on the one the colour reads worst on; when what that gives does not
    read on all of them (a gradient across two families), white or ink, whichever reads best on its own worst ground. Dark words on
    a ground people see as dark turn white wherever white reaches the contrast they need (v130: light text on dark grounds)."""
    if any(_apca(color, u) > 0 for u in grounds) and all(_light_better(u) and _contrast('FFFFFF', u) >= need for u in grounds): return 'FFFFFF'
    if len(grounds) == 1: return readable_text_color(color, grounds[0], need)
    new = readable_text_color(color, min(grounds, key=lambda u: _contrast(color, u)), need)
    if all(_contrast(new, u) >= need for u in grounds): return new
    return max(('FFFFFF', INK), key=lambda c: min(_contrast(c, u) for u in grounds))


def readable_text_color(color, under, need):
    """The text colour to use on `under`: kept when it reads; else white when white reads; on a light ground a deep template colour of the
    same hue (raspberry for the pinks, then plum), else ink: an orange that does not read turns black, never plum (v136) - never a
    colour outside the template's palette."""
    color = str(color).upper()
    if color not in STATUS_TEXT and _contrast(color, under) >= need: return color
    cw, ci = _contrast('FFFFFF', under), _contrast(INK, under)
    if cw >= need and cw >= ci: return 'FFFFFF'
    if cw < ci:
        fam = _family(color)
        for c in (() if color in STATUS_TEXT else DEEP_TEXT.get(fam, ()) + (('5D0F43',) if fam == 'pink' else ())) + (INK,):
            if _contrast(c, under) >= need: return c
        return INK
    return 'FFFFFF'


DEEPEN = {'F26923': 'DB0058', 'EE6C37': 'DB0058', 'F16A1C': 'DB0058', 'DE7445': 'DB0058', 'E0531B': 'DB0058', 'F14C24': 'DB0058', 'F24C26': 'DB0058',
          'FF7826': 'DB0058', 'E9341C': 'DB0058', 'E8275A': 'C10060', 'EA0B59': 'C10060', '8A8C8F': '505152'}


def deepen_under_words(els, bg):
    """A fill that carries words on a ground people see as dark, where white words fall short of what they need (the oranges, pinks
    and reds under small type), takes the deep colour of its hue - raspberry for the oranges and reds, dark raspberry for the pinks -
    so its words can be white (the diagrams and point graphics; the infographic engine draws words on deep fills to begin with).
    The parts drawn with that fill go deep with it: a shape of the same colour touching it (a step's square foot)."""
    deep = set()
    for i, e in enumerate(els):
        if e.get('k') != 'text' or not ''.join(e.get('lines') or []).strip() or ''.join(e['lines']).strip() in DOTS: continue
        grounds, q = _grounds(els, i, e, bg, brand_fill)
        if q is not None and any(_light_better(u) and _contrast('FFFFFF', u) < text_need(e) for u in grounds): deep.add(q)
    for q in list(deep):
        f, (x0, y0, x1, y1) = els[q].get('fill'), _box(els[q])
        deep |= {j for j, o in enumerate(els) if f and o.get('fill') == f and o.get('k') in ('rect', 'ellipse', 'poly')
                 and (lambda b: b[0] <= x1 + 1 and x0 - 1 <= b[2] and b[1] <= y1 + 1 and y0 - 1 <= b[3])(_box(o))}
    for q in deep:
        sh = els[q]
        if sh.get('fill'): sh['fill'] = DEEPEN.get(brand_fill(sh['fill']), sh['fill'])
        if sh.get('grad'): sh['grad'] = [DEEPEN.get(brand_fill(g), g) for g in sh['grad']]


def _box(e):
    """(x0, y0, x1, y1) of a rect, ellipse or polygon."""
    if e['k'] == 'poly':
        xs, ys = [p[0] for p in e['pts']], [p[1] for p in e['pts']]
        return min(xs), min(ys), max(xs), max(ys)
    return e['x'], e['y'], e['x'] + e['w'], e['y'] + e['h']


def readable_text(els, bg, report=False):
    """Every text readable on what it actually sits on (WCAG AA: 4.5:1, large text 3:1) - white on the Ulta orange is 3.1:1, an orange
    title on a pale tint about 2.5:1. A text under the bar takes white, a deep template colour of its hue, plum or ink, whichever reads
    first. The template's headline orange on its own page is the template's design and stays."""
    low = []; on = {}; dark = set()
    for i, e in enumerate(els):
        if e.get('k') != 'text' or not e.get('color') or not ''.join(e.get('lines') or []).strip(): continue
        if e.get('font') == 'display' and str(e['color']).upper() == TITLE: continue
        col = str(e['color']).upper()
        if ''.join(e.get('lines') or []).strip() in DOTS: continue   # a status dot is a mark, not words
        grounds, q = _grounds(els, i, e, bg, brand_fill); need = text_need(e)
        cur = col if col in STATUS_TEXT else brand_text(col)
        new = _readable_on(cur, grounds, need)
        if e.get('dark') and new == 'FFFFFF' and all(_contrast(cur, u) >= need for u in grounds): new = cur   # v139: the light lead's one dark voice
        if q is not None: on.setdefault(q, []).append((i, grounds, need))
        if new != cur:
            low.append((e.get('name'), e.get('t'), e['color'], grounds[0], new))
            if not report: e['color'] = new
            if new == INK and cur == 'FFFFFF' and q is not None: dark.add(q)
    if not report:   # one voice per card: when its small print had to turn dark, its other white words and pictograms turn dark too
        for q in sorted(dark):
            for i, grounds, need in on.get(q, []):
                if str(els[i]['color']).upper() == 'FFFFFF' and all(_contrast(INK, u) >= need for u in grounds): els[i]['color'] = INK
        for i, e in enumerate(els):
            if e.get('k') == 'icon' and str(e.get('color') or '').upper() == 'FFFFFF':
                u, q = _under_at(els, i, e['x'] + e['s'] / 2, e['y'] + e['s'] / 2, bg)
                if q in dark: e['color'] = INK
    return low


def contrast_problems(els, bg, palette=None):
    """[(text, colour, ground, ratio, need)] for every text under the bar on what it sits on. palette(colour, text) -> the colour a
    brand pass will give it (the files are recoloured to the template's palette; text never a status colour): the check then reads
    the colours the reader will see."""
    m = palette or (lambda c, text=False: brand_text(c) if text else brand_fill(c)); out = []
    for i, e in enumerate(els):
        if e.get('k') != 'text' or not e.get('color') or not ''.join(e.get('lines') or []).strip(): continue
        if e.get('font') == 'display' and str(e['color']).upper() == TITLE: continue
        if ''.join(e.get('lines') or []).strip() in DOTS: continue   # a status dot is a mark
        col = m(str(e['color']).upper(), True); under = min(_grounds(els, i, e, bg, m)[0], key=lambda u: _contrast(col, u)); r = _contrast(col, under); need = text_need(e)
        if r < need: out.append((e.get('t') or ' '.join(e.get('lines') or []), col, under, round(r, 2), need))
    return out


def readable_report(d, bg=None):
    """(texts, [(text, colour, ground, ratio, need)] under the bar) over a design and its later pages, in the colours the brand
    pass gives the files: the evidence behind a build's "Readable text" check."""
    n, low = 0, []
    for p in [d] + list(d.get('pages') or []):
        els = p.get('els') or []
        n += sum(1 for e in els if e.get('k') == 'text' and ''.join(e.get('lines') or []).strip())
        low += contrast_problems(els, bg or p.get('bg') or 'FFFFFF')
    return n, low


def readable_icons(els, bg, report=False):
    """Every pictogram readable on what it actually sits on: under 3:1 against that colour (a dark icon on a dark card, a white icon on a
    light badge - themes, palettes and edited colours combine in ways no single rule covers), it turns white or ink, whichever reads better."""
    low = []
    for i, e in enumerate(els):
        if e.get('k') != 'icon' or not e.get('color'): continue
        under = _under(els, i, e['x'] + e['s'] / 2, e['y'] + e['s'] / 2, bg)
        new = readable_color(e['color'], under)
        if new != e['color']:
            low.append((e.get('name'), e['color'], under, new))
            if not report: e['color'] = new
    return low


def readable_color(color, under):
    """The icon colour to use on `under`: kept when it reads (3:1; white on a brand colour 2.5:1 - the template's own white-on-orange, as
    its text is); on a light ground a darker shade of the same hue (on-brand, not black); on a dark ground white."""
    color = str(color).upper()
    if _contrast(color, under) >= (2.5 if color == 'FFFFFF' else 3.0): return color
    if _contrast('FFFFFF', under) < _contrast(INK, under):   # a light ground
        base = TITLE if (_lum(color) or 0) > 0.6 else color      # a white icon on a light badge: the brand colour, darkened as needed
        for k in (0.0, 0.2, 0.3, 0.4, 0.55):
            s = shade(base, k) if k else base
            if _contrast(s, under) >= 3.0: return s
        return INK
    return 'FFFFFF' if _contrast('FFFFFF', under) >= 3.0 or _contrast('FFFFFF', under) >= _contrast(INK, under) else INK


# ------------------------------------------------------------------------------------------------------------------ renderers
def _esc(t): return html.escape(str(t), quote=True)


def _mix(a, b, f):
    x = [int(a[i:i + 2], 16) for i in (0, 2, 4)]; y = [int(b[i:i + 2], 16) for i in (0, 2, 4)]
    return ''.join(f'{int(round(p + (q - p) * f)):02X}' for p, q in zip(x, y))


def _place(vb, x, y, w, h):
    vx, vy, vw, vh = (float(v) for v in vb.replace(',', ' ').split()); s = min(w / vw, h / vh)
    return f'translate({x + (w - vw * s) / 2:.2f},{y + (h - vh * s) / 2:.2f}) scale({s:.5f}) translate({-vx:.2f},{-vy:.2f})'


def to_svg(d, chrome=True):
    """The design as SVG - gradients as gradients in every picture made from it (resvg draws them since v6.6; the bands that stood
    in for them under MuPDF are gone)."""
    W, H = d['w'], d['h']; defs = []; out = []; gid = {}; imgs = (d.get('spec') or {}).get('images') or {}
    def grad(a, b):
        key = a + b
        if key not in gid:
            gid[key] = f'g{len(gid)}'; defs.append(f'<linearGradient id="{gid[key]}" x1="0" y1="0" x2="1" y2="0.35"><stop offset="0" stop-color="#{a}"/><stop offset="1" stop-color="#{b}"/></linearGradient>')
        return f'url(#{gid[key]})'
    if chrome: out.append(f'<rect x="0" y="0" width="{W}" height="{H}" fill="#{d["bg"]}"/>')   # without the chrome (the deck twin) the slide shows through
    for idx, e in enumerate(d['els']):
        if e.get('chrome') and not chrome: continue
        k = e['k']
        if k == 'rect':
            if e['w'] <= 0 or e['h'] <= 0: continue
            stroke = f' stroke="#{e["stroke"]}" stroke-width="{e.get("sw", 1)}"' if e.get('stroke') else ''
            r = min(e.get('r') or 0, e['w'] / 2, e['h'] / 2)
            fill = grad(*e['grad']) if e.get('grad') else (f'#{e["fill"]}' if e.get('fill') else 'none')
            out.append(f'<rect x="{e["x"]}" y="{e["y"]}" width="{e["w"]}" height="{e["h"]}" rx="{r}" fill="{fill}"{stroke}/>')
        elif k == 'ellipse':
            stroke = f' stroke="#{e["stroke"]}" stroke-width="{e.get("sw", 1)}"' if e.get('stroke') else ''
            op = (' fill-opacity="' + str(e['alpha']) + '"') if e.get('alpha') else ''   # Venn circles: see-through (kept out of the f-string: Python 3.10/3.11)
            fill = grad(*e['grad']) if e.get('grad') else ('#' + e['fill']) if e.get('fill') else 'none'
            out.append(f'<ellipse cx="{e["x"] + e["w"] / 2}" cy="{e["y"] + e["h"] / 2}" rx="{e["w"] / 2}" ry="{e["h"] / 2}" fill="{fill}"{stroke}{op}/>')
        elif k == 'line':
            for end, (ax, ay, bx, by) in (('arrow', (e['x1'], e['y1'], e['x2'], e['y2'])), ('arrow_start', (e['x2'], e['y2'], e['x1'], e['y1']))):
                if e.get(end):   # an arrowhead drawn as a small triangle (renderers without marker support draw it too)
                    L = math.hypot(bx - ax, by - ay) or 1; ux, uy = (bx - ax) / L, (by - ay) / L; al, aw = 5.5 * e['sw'] + 4, 2.4 * e['sw'] + 3
                    p1 = (bx - ux * al + uy * aw, by - uy * al - ux * aw); p2 = (bx - ux * al - uy * aw, by - uy * al + ux * aw)
                    out.append(f'<path d="M{bx:.1f},{by:.1f} L{p1[0]:.1f},{p1[1]:.1f} L{p2[0]:.1f},{p2[1]:.1f} Z" fill="#{e["color"]}"/>')
            out.append(f'<line x1="{e["x1"]}" y1="{e["y1"]}" x2="{e["x2"]}" y2="{e["y2"]}" stroke="#{e["color"]}" stroke-width="{e["sw"]}" stroke-linecap="round"{" stroke-dasharray=" + chr(34) + "6 6" + chr(34) if e.get("dash") else ""}/>')
        elif k == 'poly':   # a closed shape from points (diagram chevrons)
            d_ = 'M' + ' L'.join(f'{px:.1f},{py:.1f}' for px, py in e['pts']) + ' Z'
            st_ = f' stroke="#{e["stroke"]}" stroke-width="{e.get("sw", 1)}"' if e.get('stroke') else ''
            out.append(f'<path d="{d_}" fill="{grad(*e["grad"]) if e.get("grad") else "#" + e["fill"]}"{st_}/>')
        elif k == 'arc':
            C = 2 * math.pi * e['r']; L = C * e['frac']
            out.append(f'<circle cx="{e["cx"]}" cy="{e["cy"]}" r="{e["r"]}" fill="none" stroke="#{e["track"]}" stroke-width="{e["sw"]}"/>')
            if e['frac'] >= 0.999: out.append(f'<circle cx="{e["cx"]}" cy="{e["cy"]}" r="{e["r"]}" fill="none" stroke="#{e["color"]}" stroke-width="{e["sw"]}"/>')
            elif L > 0.5:   # an arc path from twelve o'clock, clockwise - every renderer draws it (MuPDF ignores dash patterns)
                a = -math.pi / 2 + 2 * math.pi * e['frac']; x1, y1 = e['cx'], e['cy'] - e['r']; x2, y2 = e['cx'] + e['r'] * math.cos(a), e['cy'] + e['r'] * math.sin(a)
                out.append(f'<path d="M{x1:.2f},{y1:.2f} A{e["r"]},{e["r"]} 0 {1 if e["frac"] > 0.5 else 0} 1 {x2:.2f},{y2:.2f}" fill="none" stroke="#{e["color"]}" stroke-width="{e["sw"]}" stroke-linecap="round"/>')
        elif k == 'icon':
            ic = icon_svg(e['name'])
            if not ic: continue
            vb, inner = ic; inner = re.sub(r'fill="#[0-9A-Fa-f]{3,6}"', f'fill="#{e["color"]}"', inner); inner = re.sub(r'stroke="#[0-9A-Fa-f]{3,6}"', f'stroke="#{e["color"]}"', inner)
            if e.get('bold'):   # bold: an outline in the icon's own colour thickens thin line pictograms (a share of the icon's own box)
                vw = max(float(v) for v in vb.split()[2:4]); inner = re.sub(r'\s(?:stroke="none"|stroke-width="[^"]*")', '', inner)   # the UI set's own "no outline" would cancel it
                inner = f'<g stroke="#{e["color"]}" stroke-width="{vw * 0.045:.2f}" stroke-linejoin="round" stroke-linecap="round">{inner}</g>'
            out.append(f'<g transform="{_place(vb, e["x"], e["y"], e["s"], e["s"])}">{inner}</g>')
        elif k == 'logo':
            vb, inner = logo_svg(); out.append(f'<g transform="{_place(vb, e["x"], e["y"], e["w"], e["h"])}">{inner}</g>')
        elif k == 'image':
            rec = imgs.get(e.get('ref'))
            if not rec or e['w'] <= 0 or e['h'] <= 0: continue
            r = min(e.get('r') or 0, e['w'] / 2, e['h'] / 2); clip = ''
            if r:
                cid = f'c{sum(1 for x in defs if x.startswith("<clipPath"))}'
                defs.append(f'<clipPath id="{cid}"><rect x="{e["x"]}" y="{e["y"]}" width="{e["w"]}" height="{e["h"]}" rx="{r}"/></clipPath>'); clip = f' clip-path="url(#{cid})"'
            out.append(f'<image data-img="{e["ref"]}" x="{e["x"]}" y="{e["y"]}" width="{e["w"]}" height="{e["h"]}" preserveAspectRatio="xMidYMid slice"{clip} '
                       f'href="data:{rec["mime"]};base64,{rec["data"]}" role="img" aria-label="{_esc(e.get("alt") or "Picture")}"/>')
        elif k == 'text':
            fam = DISPLAY if e['font'] == 'display' else BODY; fw = 900 if e['font'] == 'display' else (700 if e['font'] == 'bold' else 400)
            anchor = {'left': 'start', 'center': 'middle', 'right': 'end'}[e.get('align', 'left')]; tx = e['x'] + (e['w'] / 2 if anchor == 'middle' else e['w'] if anchor == 'end' else 0)
            sp = f' letter-spacing="{e["spacing"]}"' if e.get('spacing') else ''
            for i, ln in enumerate(e['lines']):
                ty = e['y'] + e['fs'] * (0.86 + i * e['lh']) + (e['lh'] - 1) * e['fs'] / 2
                out.append(f'<text data-i="{idx}" x="{tx:.1f}" y="{ty:.1f}" font-family="{_esc(fam)}" font-size="{e["fs"]}" font-weight="{fw}" fill="#{e["color"]}" text-anchor="{anchor}"{sp}>{_esc(ln)}</text>')   # data-i: the page's editor finds a text's lines
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}">' + (f'<defs>{"".join(defs)}</defs>' if defs else '') + ''.join(out) + '</svg>')


def _raster():
    """SVG → PNG / PDF with permissive tools (resvg + Pillow) - v6.6 replaced PyMuPDF (AGPL-3.0)."""
    import sys as _s
    _s.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    import svgraster
    return svgraster


def to_png(svg, path, zoom=2.0):
    return _raster().to_png(svg, path, zoom)


PDF_PAGE = {'onepager': (612, 792), 'slide': (960, 540), 'square': (648, 648)}   # points: Letter portrait, 13.333 × 7.5 in, 9 × 9 in


def to_pdf_pages(svgs, path, fmt=None):
    """Several pages into one PDF (a status report on a slide is two); one page goes through to_pdf."""
    if len(svgs) == 1: return to_pdf(svgs[0], path, fmt)
    import tempfile as _tf
    from PIL import Image as _Im
    d_ = _tf.mkdtemp(prefix='ulta-pdf-'); parts = []
    try:
        for i, s in enumerate(svgs):
            p = os.path.join(d_, f'{i}.pdf')
            if not to_pdf(s, p, fmt): return False
            parts.append(p)
        R = _raster(); sw, sh = R._svg_size(svgs[0]); f_ = fmt or min(PDF_PAGE, key=lambda k: abs(PDF_PAGE[k][0] / PDF_PAGE[k][1] - sw / max(1, sh)))
        pw, ph = PDF_PAGE.get(f_, (sw * 0.75, sh * 0.75)); px = (int(round(pw / 72 * 300)), int(round(ph / 72 * 300)))
        imgs = []
        for s in svgs:
            b = R.png_bytes(s, min(px[0] / sw, px[1] / sh), background='#FFFFFF'); a = _Im.open(__import__('io').BytesIO(b)).convert('RGB')
            sheet = _Im.new('RGB', px, 'white'); sheet.paste(a, ((px[0] - a.width) // 2, (px[1] - a.height) // 2)); imgs.append(sheet)
        imgs[0].save(path, 'PDF', resolution=300.0, save_all=True, append_images=imgs[1:]); return True
    finally:
        import shutil as _sh; _sh.rmtree(d_, ignore_errors=True)


def to_pdf(svg, path, fmt=None):
    """The art on a page of the format's real size (a one-pager is Letter), scaled to fit and centred, at 300 dpi - at one point per
    pixel the page was 14 × 18 in, so printing it split onto two pages and cut the bottom (the ULTA logo) off page one."""
    R = _raster(); sw, sh = R._svg_size(svg)
    if not fmt: fmt = min(PDF_PAGE, key=lambda k: abs(PDF_PAGE[k][0] / PDF_PAGE[k][1] - sw / max(1, sh)))   # the format whose proportions match the art
    return R.to_pdf(svg, path, PDF_PAGE.get(fmt, (sw * 0.75, sh * 0.75)), 300, (sw, sh))


def fonts_css():
    """The bundled faces inside a page, as the unchanged font files (SIL Open Font License 1.1): the page draws, exports and is
    measured with the fonts the layout was fitted to, on any computer."""
    import base64
    out = ['/* Inter: Copyright 2016-2023 The Inter Project Authors. Playfair Display: Copyright 2017 The Playfair Display Project Authors, with Reserved '
           'Font Name "Playfair Display". Both licensed under the SIL Open Font License, Version 1.1 (https://openfontlicense.org). */']
    for fam, w, fn, fmt in (('Inter', 400, 'Inter-Regular.otf', 'opentype'), ('Inter', 700, 'Inter-Bold.otf', 'opentype'), ('Playfair Display Black', 900, 'PlayfairDisplay-Black.ttf', 'truetype')):
        try: b64 = base64.b64encode(open(os.path.join(FONT_DIR, fn), 'rb').read()).decode('ascii')
        except Exception: continue   # noqa: BLE001 - the page falls back to the installed fonts
        out.append("@font-face{font-family:'%s';font-weight:%d;font-style:normal;src:url(data:font/%s;base64,%s) format('%s')}" % (fam, w, 'otf' if fmt == 'opentype' else 'ttf', b64, fmt))
    return '\n'.join(out)


def page_assets(palette=None):
    """What a page's own engine needs to lay itself out again: the text widths, the pictograms (with their keywords), the logo and
    the brand's colour rules (tools/ulta_conform.page_palette: what the files get, the page applies after every edit)."""
    try: cat = json.load(open(os.path.join(KIT, 'icons', 'icons.json'), encoding='utf-8'))['icons']
    except Exception: cat = []   # noqa: BLE001
    icons = {}
    for c in cat:
        ic = icon_svg(c['name'])
        if ic: icons[c['name']] = {'vb': ic[0], 'inner': ic[1]}
    return {'metrics': json.load(open(os.path.join(HERE, 'metrics.json'), encoding='utf-8')), 'icons': icons,
            'catalog': [[c['name'], c.get('keywords', [])] for c in cat], 'logo': list(logo_svg()), 'palette': palette}


def engine_js(*names):
    """The page's own engine and editor (kit/editor/*.js), inlined: none may close its script element early."""
    parts = []
    for n in names:
        js = open(os.path.join(KIT, 'editor', n), encoding='utf-8').read()
        if re.search(r'</script|<script|<!--', js, re.I): raise ValueError(n + ' would break out of its inline script')
        parts.append(js)
    return '\n'.join(parts)


def page_json(o):
    return json.dumps(o, ensure_ascii=False).replace('</', '<\\/').replace('\u2014', '\\u2014')   # the dash glyph's metrics as an escape, not a dash


def fill(tpl, values):
    """Each __NAME__ of a page template replaced once, where it stands (inserted text is never searched again)."""
    return re.sub(r'__([A-Z]+)__', lambda m: values[m.group(1)] if m.group(1) in values else m.group(0), tpl)


def to_html(d, src=None, palette=None):
    """The page: the infographic and its own editor. Edit: click a text to change it where it is drawn, or use the panel (blocks,
    items, icons, order, format, theme); the page lays itself out again in the browser with the same engine as this file (no chat,
    no server), Undo / Redo, and Save writes the page with the new content. PNG / SVG / Print."""
    tpl = open(os.path.join(HERE, 'info-template.html'), encoding='utf-8').read()
    src_ = normalise(src) if isinstance(src, dict) else d['spec']
    imgs = d['spec'].get('images') or {}   # the content carries the pictures it shows, each once
    used = [r_ for b in src_.get('blocks') or [] for r_ in [b.get('src')] + [it.get('src') for it in (b.get('items') or []) if b.get('type') == 'gallery' and isinstance(it, dict)] if r_ in imgs]
    if used: src_ = dict(src_, images={r_: imgs[r_] for r_ in dict.fromkeys(used)})
    data = {'kind': 'infographic', 'src': src_, 'design': lean(d),
            'svg': lean_svg('<div class="pgap"></div>'.join(page_svgs(d))), 'catalogue': catalogue()}
    return fill(tpl, {'TITLE': _esc(d['spec']['title']), 'FONTS': fonts_css(), 'ASSETS': page_json(page_assets(palette)), 'DATA': page_json(data),
                      'ENGINE': engine_js('engine-core.js', 'info-engine.js', 'page-kit.js')})


def lean(d):
    """The design without its pictures' data (the page's content holds them once; the page lays itself out from it)."""
    if not (d.get('spec') or {}).get('images'): return d
    out = dict(d, spec={k: v for k, v in d['spec'].items() if k != 'images'})
    if d.get('pages'): out['pages'] = [lean(p) for p in d['pages']]
    return out


def lean_svg(svg):
    """A drawing whose pictures name their data instead of carrying it (the page's fallback drawing)."""
    return re.sub(r'href="data:[^"]*"', 'href=""', svg)


def to_markdown(d):
    s = d['spec']; L = [f'# {s["title"]}'] + ([s['subtitle']] if s.get('subtitle') else [])
    for b in s['blocks']:
        L.append(''); L.append(f'## {b.get("title") or BLOCKS[b["type"]].split(" (")[0]}')
        if b['type'] == 'compare':
            for side in ('left', 'right'): L.append(f'### {b[side]["title"]}'); L += [f'- {x}' for x in b[side]['items']]
        elif b['type'] in ('quote', 'takeaway'): L.append(b['text'] + (f' — {b["by"]}' if b.get('by') else ''))
        elif b['type'] in ('hub', 'house'):
            L += [x_ for x_ in (b.get('center'), b.get('roof')) if x_] + [f'- {it["title"]}' + (f': {it["text"]}' if it.get('text') else '') for it in b['items']] + ([b['base']] if b.get('base') else [])
        elif b['type'] == 'status': L += [f'{it["label"]}: {it["value"]}' for it in b['items']]
        elif b['type'] in ('image', 'feature'):
            nm = ((s.get('images') or {}).get(b['src']) or {}).get('name') or b['src']; L.append(f'![{b.get("caption") or b.get("alt") or ""}]({nm})')
            L += [f'- {it["title"]}' + (f': {it["text"]}' if it.get('text') else '') for it in b.get('items') or []]
        elif b['type'] == 'gallery':
            L += [f'![{it.get("caption") or it.get("alt") or ""}]({((s.get("images") or {}).get(it["src"]) or {}).get("name") or it["src"]})' for it in b['items']]
        elif b['type'] == 'band':
            L += ([f'**{b["label"]}**'] if b.get('label') else []) + [f'- {it["title"]}' for it in b['items']]
        elif b['type'] == 'flow':
            for ln in b['lanes']: L.append(f'### {ln.get("title") or ("Tomorrow" if ln.get("tone") == "after" else "Today")}'); L += [f'- {it["title"]}' for it in ln['items']]
        elif b['type'] == 'table':
            L += ['| ' + ' | '.join(b.get('cols') or []) + ' |', '|' + '---|' * len(b.get('cols') or [])] + ['| ' + ' | '.join(r) + ' |' for r in b['items']]
        elif b['type'] == 'ragcards':
            L += ['| Workstream | Owner | Status | Update |', '|---|---|---|---|'] + [f'| {it["name"]} | {it["owner"]} | {RAG[it.get("rag") or ""][1]} | {it["text"] or "—"} |' for it in b['items']]
        elif b['type'] == 'rag':
            L += ['| Workstream | Owner | Status | ' + ' | '.join(b.get('cols') or ['This week', 'Next week']) + ' |', '|---|---|---|---|---|']
            L += [f'| {it["name"]} | {it["owner"]} | {RAG[it.get("rag") or ""][1]} | {it["now"] or "—"} | {it["next"] or "—"} |' for it in b['items']]
        elif b['type'] == 'risks':
            L += ['| Risk or ask | Support needed from | Owner | Need by | Severity |', '|---|---|---|---|---|']
            L += [f'| {it["title"]} | {it["text"]} | {it["owner"]} | {it["due"]} | {RAG[it.get("rag") or ""][1]} |' for it in b['items']]
        else:
            for it in b.get('items', []): L.append('- ' + ' — '.join(str(it[k]) for k in ('when', 'value', 'title', 'label', 'text') if it.get(k)))
    if s.get('source'): L += ['', f'Source: {s["source"]}']
    return '\n'.join(L) + '\n'


def to_spec(d, template='STANDARD33', frame=False, two_col=6, cover=1, closing=32):
    """A 16:9 infographic as a deck spec: the title in the template's headline, the body drawn in native shapes (build_from_storyboard.add_info).
    One slide, or as many as the content needs at a readable size (a long status report continues on "(cont.)"); frame adds the
    template's cover and closing slides, on request only (v137: by default it made every one-pager three slides)."""
    s = d['spec']; slides = []
    if frame: slides.append({'source': cover, 'kind': 'cover', 'fills': {'title': s['title']}, 'notes': s.get('subtitle', '')})
    for pg in [d] + list(d.get('pages') or []):   # a status report on a slide: a continuation slide too
        ps = pg['spec'] if pg is not d else dict(s, title=s['title'])
        slides.append({'source': two_col, 'fills': {'title': ps['title'], 'text1': [''], 'text2': ['']}, 'hide': ['text1', 'text2'], 'info': pg, 'info_svg': to_svg(pg, chrome=False), 'sec': s['title'],
                       'notes': '\n'.join(x for x in (ps.get('subtitle'), ('Source: ' + s['source']) if s.get('source') else '') if x)})
    if frame: slides.append({'source': closing, 'kind': 'closing', 'fills': {'text1': 'Thank you!', 'text2': 'Ulta Beauty | Proprietary & Confidential'}})
    return {'template': template, 'title': s['title'], 'slides': slides, 'warnings': []}


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('text', nargs='?'); ap.add_argument('--format', default='onepager', choices=FORMAT_ORDER); ap.add_argument('--theme', default='ulta'); ap.add_argument('--out', required=True)
    a = ap.parse_args()
    sp = rules_spec(open(a.text, encoding='utf-8').read(), a.format, a.theme) if a.text else sample_spec(a.format, a.theme)
    d = layout(sp); open(a.out + '.svg', 'w', encoding='utf-8').write(to_svg(d)); to_png(to_svg(d), a.out + '.png')
    print(json.dumps({'status': 'OK', 'blocks': [b['type'] for b in d['spec']['blocks']], 'warnings': d['warnings']}))
