"""Write metrics.json: the text widths every layout measures with, in Python and in the page's own editor alike.

    python font_metrics.py            (run by the maintainer when a bundled font changes; needs Pillow and fontTools)

Per face (display = Playfair Display Black, body = Inter Regular, bold = Inter Bold): the advance of every character the
face has in the ranges below and the kerning of every pair of common characters, both as Pillow measures them at 200 px,
in 1/64 px (whole numbers, so Python and JavaScript add them up to the same width). A character the face lacks takes
`miss` (its .notdef advance). One table for both sides: an edit relaid out in the browser lands exactly where the
Python layout would put it.
"""
import json, os, sys

HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.normpath(os.path.join(HERE, '..', '..', '..', '..', '..', 'fonts'))
FACES = {'display': 'PlayfairDisplay-Black.ttf', 'body': 'Inter-Regular.otf', 'bold': 'Inter-Bold.otf'}
RANGES = [(0x20, 0x7E), (0xA0, 0x17F), (0x2010, 0x203A), (0x2044, 0x2044), (0x20AC, 0x20AC), (0x20B9, 0x20B9), (0x2122, 0x2122),
          (0x2190, 0x2199), (0x21D2, 0x21D2), (0x2212, 0x2212), (0x221E, 0x221E), (0x2248, 0x2248), (0x2260, 0x2260), (0x2264, 0x2265),
          (0x25A0, 0x25CF), (0x2605, 0x2606), (0x2713, 0x2717)]
PAIRS = [chr(c) for c in range(0x20, 0x7F)] + list('\u00a0\u2018\u2019\u201c\u201d\u2013\u2014\u2026\u2022\u00b7\u2192')


def build():
    from PIL import ImageFont
    from fontTools.ttLib import TTFont
    out = {'v': 1, 'size': 200, 'scale': 64, 'faces': {}}
    for key, fn in FACES.items():
        path = os.path.join(FONTS, fn); f = ImageFont.truetype(path, 200); cmap = TTFont(path).getBestCmap()
        u = lambda s: int(round(f.getlength(s) * 64))
        adv = {chr(c): u(chr(c)) for a, b in RANGES for c in range(a, b + 1) if c in cmap}
        kern = {}
        for a in PAIRS:
            for b in PAIRS:
                if a in adv and b in adv:
                    d = u(a + b) - adv[a] - adv[b]
                    if d: kern[a + b] = d
        out['faces'][key] = {'adv': adv, 'kern': kern, 'miss': u('')}
    return out


if __name__ == '__main__':
    m = build()
    p = os.path.join(HERE, 'metrics.json')
    with open(p, 'w', encoding='utf-8') as fh: json.dump(m, fh, ensure_ascii=True, separators=(',', ':'), sort_keys=True)   # dash glyphs as \u escapes: no dash a reader could see
    print(p, os.path.getsize(p), 'bytes |', ', '.join(f"{k}: {len(v['adv'])} characters, {len(v['kern'])} pairs" for k, v in m['faces'].items()))
    sys.exit(0)
