"""Pictures in an infographic (v7): the user's own UI screens and product photos, taken in safely and drawn the same in every file.

A picture is read from a file the user gave (PNG, JPEG, WebP, a GIF's first frame) or from one of the kit's own samples
('sample:<name>', the template pictures' sample content); never from a web or data address. It is drawn again on the way in:
turned upright as the camera meant, at most 1,800 pixels on its long side, and written fresh as PNG (a screen: crisp edges,
flat colours) or JPEG (a photo). Nothing the file carried comes along - camera, place and date details, comments, other
metadata. The spec keeps each picture once, in spec['images'][id] = {mime, data (base64), w, h, kind, name}; blocks name it
by its id (the first 12 hex digits of its SHA-256), so a picture used twice is stored once.
Limits: 15 MB a file, 40 megapixels, 12 pictures in a spec.
"""
import base64, hashlib, io, re
from pathlib import Path

HERE = Path(__file__).resolve().parent
SAMPLES = HERE / 'samples'
MAX_SIDE, MAX_BYTES, MAX_PIXELS, MAX_PICTURES = 1800, 15_000_000, 40_000_000, 12
FORMATS = {'PNG', 'JPEG', 'WEBP', 'GIF', 'MPO'}          # MPO: a phone camera's JPEG
REF = re.compile(r'^[0-9a-f]{12}$')
PICTURE_KEYS = ('src',)                                  # where a block names its picture (a gallery's items too)


class PictureError(ValueError):
    pass


def is_ref(v):
    return isinstance(v, str) and bool(REF.match(v))


def _path(src, base=None):
    s = str(src or '').strip()
    if s.lower().startswith('sample:'):
        name = re.sub(r'[^a-z0-9-]', '', s[7:].lower())
        return next((p for p in (SAMPLES / f'{name}.png', SAMPLES / f'{name}.jpg') if p.is_file()), SAMPLES / f'{name}.png')
    if re.match(r'^[a-z][a-z0-9+.-]+:', s, re.I):       # http:, https:, data:, file: ... (a drive letter is one letter)
        raise PictureError(f'{s[:40]}: a web or data address - a picture comes from a file the user uploaded')
    p = Path(s).expanduser()
    if not p.is_absolute() and base:
        p = Path(base) / p
    return p


def _screenish(im):
    """A screen (flat fills and sharp edges: text, rules, icons) or a photo (shades everywhere, even on a plain backdrop).
    From a copy at most 480 pixels across: the share of side-by-side pixels that are exactly alike (screens 0.85+, photos
    0.55 or less) and, of those that differ, the share that differ sharply (screens 0.2+, photos under 0.1)."""
    from PIL import Image, ImageChops
    g = im.convert('RGB')
    if max(g.size) > 480:
        s = 480 / max(g.size); g = g.resize((max(1, round(g.width * s)), max(1, round(g.height * s))), Image.NEAREST)
    d = ImageChops.difference(g, ImageChops.offset(g, 1, 0)); r, gr, b = d.split()
    h = ImageChops.lighter(ImageChops.lighter(r, gr), b).histogram(); n = sum(h)
    return h[0] / n >= 0.45 and sum(h[49:]) / max(1, n - h[0]) >= 0.15


def load(src, base=None):
    """(id, record) for a picture file: checked, turned upright, scaled down, written fresh without its metadata."""
    p = _path(src, base)
    if not p.is_file():
        raise PictureError(f'{p.name or src}: no such picture file')
    if p.stat().st_size > MAX_BYTES:
        raise PictureError(f'{p.name}: over 15 MB - send a smaller picture')
    return _from_bytes(p.read_bytes(), p.name)


def _from_bytes(data, name):
    """(id, record) for a picture's bytes - a file's, or a page's: read, turned upright, scaled down, written fresh."""
    from PIL import Image, ImageOps
    name = re.sub(r'[^\w .()-]+', '', str(name or 'picture'))[:80] or 'picture'
    if len(data) > MAX_BYTES:
        raise PictureError(f'{name}: over 15 MB - send a smaller picture')
    Image.MAX_IMAGE_PIXELS = MAX_PIXELS
    try:
        with Image.open(io.BytesIO(data)) as im:
            fmt = (im.format or '').upper()
            if fmt not in FORMATS:
                raise PictureError(f'{name}: {fmt or "not a picture"} - use PNG, JPEG, WebP or GIF')
            if im.width * im.height > MAX_PIXELS:         # known from the header, before anything is decoded
                raise PictureError(f'{name}: over 40 megapixels - send a smaller picture')
            im.seek(0)
            im.load()
            im = ImageOps.exif_transpose(im)
            icc = im.info.get('icc_profile')
            alpha = im.mode in ('RGBA', 'LA', 'PA') or (im.mode == 'P' and 'transparency' in im.info)
            im = im.convert('RGBA' if alpha else 'RGB')
            if icc:                                      # the colours as the camera meant them, in sRGB (the profile is not kept)
                try:
                    from PIL import ImageCms
                    im = ImageCms.profileToProfile(im, ImageCms.ImageCmsProfile(io.BytesIO(icc)), ImageCms.createProfile('sRGB'), outputMode=im.mode)
                except Exception:                        # noqa: BLE001 - a profile that cannot be read: the pixels as they are
                    pass
    except PictureError:
        raise
    except Image.DecompressionBombError:
        raise PictureError(f'{name}: over 40 megapixels - send a smaller picture')
    except Exception as e:                               # noqa: BLE001 - any file that is not a readable picture
        raise PictureError(f'{name}: not a readable picture ({type(e).__name__})')
    if alpha and im.getchannel('A').getextrema()[0] == 255:
        im, alpha = im.convert('RGB'), False             # an alpha channel with nothing see-through
    if max(im.size) > MAX_SIDE:
        im.thumbnail((MAX_SIDE, MAX_SIDE), Image.LANCZOS)
    kind = 'screen' if _screenish(im) else 'photo'
    im.info = {}                                         # nothing the file carried is written again: comments, text, XMP, EXIF, profile
    out = io.BytesIO()
    if alpha or kind == 'screen':
        im.save(out, 'PNG', optimize=True); mime = 'image/png'
    else:
        im.save(out, 'JPEG', quality=86, optimize=True, progressive=True); mime = 'image/jpeg'
    b = out.getvalue()
    if mime == 'image/png' and not alpha and len(b) > 1_500_000:   # a large, busy screen: a fine JPEG is a fraction of the size
        o2 = io.BytesIO(); im.save(o2, 'JPEG', quality=92, optimize=True, subsampling=0)
        if len(o2.getvalue()) < 0.6 * len(b):
            b, mime = o2.getvalue(), 'image/jpeg'
    rid = hashlib.sha256(b).hexdigest()[:12]
    return rid, {'mime': mime, 'data': base64.b64encode(b).decode('ascii'), 'w': im.width, 'h': im.height, 'kind': kind, 'name': name}


def _refs(b):
    """(holder, key) pairs where block b names a picture: the block itself, and a gallery's items."""
    out = [(b, 'src')] if b.get('src') is not None else []
    if b.get('type') == 'gallery':
        out += [(it, 'src') for it in b.get('items') or [] if isinstance(it, dict) and it.get('src') is not None]
    return out


def take_in(spec, base=None):
    """Load every picture a spec names by file into spec['images'] and point its blocks at their ids. Returns the problems
    (a missing or unreadable file, too many pictures): that block keeps its name and draws a 'picture missing' card."""
    if not isinstance(spec, dict):
        return []
    images = dict(spec.get('images') or {}) if isinstance(spec.get('images'), dict) else {}
    problems, cache = [], {}
    for b in spec.get('blocks') or []:
        if not isinstance(b, dict):
            continue
        for holder, key in _refs(b):
            v = holder.get(key)
            if is_ref(v) and v in images:
                continue
            if not isinstance(v, str) or not v.strip():
                continue
            if v in cache:
                holder[key] = cache[v]; continue
            try:
                rid, rec = load(v, base)
            except PictureError as e:
                problems.append(f'picture: {e}'); continue
            if rid not in images and len(images) >= MAX_PICTURES:
                problems.append(f'picture: {rec["name"]} left out - a page holds {MAX_PICTURES} pictures'); continue
            images[rid] = rec; cache[v] = rid; holder[key] = rid
    if images:
        spec['images'] = images
    return problems


def vet(spec):
    """Pictures that arrive inside content - a page the user edited and sent back - are checked and drawn again as an upload
    is; the blocks follow each picture's new id. Returns the problems: a picture that fails is dropped, and its block shows
    'picture missing'."""
    if not isinstance(spec, dict):
        return []
    imgs = spec.get('images')
    new, remap, problems = {}, {}, []
    for rid, rec in (imgs.items() if isinstance(imgs, dict) else ()):
        if not is_ref(rid) or not isinstance(rec, dict):
            continue
        name = re.sub(r'[^\w .()-]+', '', str(rec.get('name') or 'picture'))[:80] or 'picture'
        if len(new) >= MAX_PICTURES:
            problems.append(f'picture: {name} left out - a page holds {MAX_PICTURES} pictures'); continue
        try:
            nid, nrec = _from_bytes(base64.b64decode(str(rec.get('data') or ''), validate=True), name)
        except PictureError as e:
            problems.append(f'picture: {e}'); continue
        except (ValueError, TypeError):                  # not base64
            problems.append(f'picture: {name}: not readable picture data'); continue
        new[nid] = nrec; remap[rid] = nid
    for b in spec.get('blocks') or []:
        for holder, key in (_refs(b) if isinstance(b, dict) else ()):
            if holder.get(key) in remap:
                holder[key] = remap[holder[key]]
    if new:
        spec['images'] = new
    else:
        spec.pop('images', None)
    return problems


def samples(spec):
    """How many of a spec's pictures are the template's own samples ('sample:<name>'), not the user's."""
    return sum(1 for b in (spec or {}).get('blocks') or [] if isinstance(b, dict)
               for holder, key in _refs(b) if str(holder.get(key) or '').strip().lower().startswith('sample:'))


def resolve(spec, base):
    """File names relative to the content's folder, made absolute (a saved spec rebuilds from anywhere)."""
    for b in (spec or {}).get('blocks') or []:
        for holder, key in (_refs(b) if isinstance(b, dict) else ()):
            v = str(holder.get(key) or '').strip()
            if v and not is_ref(v) and not re.match(r'^[a-z][a-z0-9+.-]+:', v, re.I) and not Path(v).expanduser().is_absolute():
                holder[key] = str(Path(base) / v)
    return spec


def tally(spec):
    """(placed, screenshots, without a caption, missing) for a spec whose pictures were taken in."""
    imgs = (spec or {}).get('images') or {}
    placed = screens = bare = missing = 0
    for b in (spec or {}).get('blocks') or []:
        for holder, key in (_refs(b) if isinstance(b, dict) else ()):
            v = holder.get(key)
            if isinstance(v, str) and v in imgs:
                placed += 1; screens += imgs[v].get('kind') == 'screen'
                said = str(holder.get('alt') or holder.get('caption') or (b.get('title') if holder is b else '') or '').strip()
                bare += said.lower() in ('', 'picture')
            elif str(v or '').strip() and v != 'new':
                missing += 1
    return placed, screens, bare, missing


CHECK = 'Pictures (readable, described, nothing confidential in a screenshot)'


def check_row(placed, screens, bare, missing, sample):
    """The pictures' row in a one-pager's check record - (check, result, detail[, advisory]) - or None without pictures."""
    if not (placed or missing or sample):
        return None
    if sample:
        return (CHECK, 'FAIL', f"{sample} of the template's sample pictures: replace each with the user's own picture, or remove its line")
    if missing:
        return (CHECK, 'FAIL', f'{missing} picture(s) could not be placed: upload the file again, or remove its line')
    said = ([f'{screens} screenshot(s): check that no guest, customer or confidential data shows - text in a picture is not scanned'] if screens else []) \
        + ([f'{bare} picture(s) without a caption: a caption also describes the picture for screen readers'] if bare else [])
    if said:
        return (CHECK, 'REVIEW', '; '.join(said), True)
    return (CHECK, 'PASS', f'{placed} picture(s), each described, metadata removed')


def data_uri(rec):
    return f"data:{rec['mime']};base64,{rec['data']}"


def raw(rec):
    return base64.b64decode(rec['data'])


def placed(rec, w, h, fit='contain'):
    """(dx, dy, dw, dh): where a picture of rec's proportions is drawn in a w x h box - contain: whole, centred; cover: the
    box filled (the picture is cropped by the box)."""
    if not rec or not rec.get('w') or not rec.get('h'):
        return 0.0, 0.0, w, h
    if fit == 'cover':
        return 0.0, 0.0, w, h
    s = min(w / rec['w'], h / rec['h']); dw, dh = rec['w'] * s, rec['h'] * s
    return (w - dw) / 2, (h - dh) / 2, dw, dh


def crop(rec, w, h):
    """(left, top, right, bottom) shares of a picture cut away to fill a w x h box (PowerPoint's picture crop)."""
    if not rec or not rec.get('w') or not rec.get('h') or not w or not h:
        return 0.0, 0.0, 0.0, 0.0
    ia, ba = rec['w'] / rec['h'], w / h
    if ia > ba:
        c = (1 - ba / ia) / 2; return c, 0.0, c, 0.0
    c = (1 - ia / ba) / 2
    return 0.0, c, 0.0, c
