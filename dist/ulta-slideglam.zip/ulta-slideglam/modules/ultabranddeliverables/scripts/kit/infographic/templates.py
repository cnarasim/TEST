"""Infographic templates (v6.11): enterprise one-pagers with a fill-in content template each, read by rules (no AI).

A template is a content template (Markdown the team fills in: "Key: value" facts, then "## Section" headings with bullets, tables or a
paragraph) plus a rule per section saying which block draws it. template_spec() reads filled-in content into the template's blocks;
detect() scores content against every template (AI off: "Auto" picks a template only when the content clearly follows one);
coverage() says which sections a text is missing (AI on: unformatted text is first rewritten into the template by the model).

Two blocks are added to the engine here: `table` (any header + rows; a Status / Severity column draws a RAG pill) and `ragcards`
(a RAG card per workstream). Everything else reuses the engine's blocks: status, rag, risks, stats, list, steps, timeline, compare,
takeaway.
"""
import re

import info as IG

# ------------------------------------------------------------------------------------------------------------------ blocks
IG.BLOCKS.update({'table': 'A table: header and rows; a Status column draws RAG pills (2–6 columns)',
                  'ragcards': 'A status card per workstream: owner, RAG and the update (2–9)'})
IG.WIDE |= {'table', 'ragcards'}
RAGCOL = re.compile(r'^(status|rag|health|state)$', re.I)
SEVCOL = re.compile(r'^(severity|priority|impact)$', re.I)


def draw_table(cv, b, x, y, w, k, theme, ci):
    heads = list(b.get('cols') or []); rows = [list(r) + [''] * (len(heads) - len(r)) for r in b['items']]
    n = len(heads)
    if not n: return 0
    rag = next((j for j, h in enumerate(heads) if RAGCOL.match(h.strip())), None)
    sev = next((j for j, h in enumerate(heads) if SEVCOL.match(h.strip())), None)
    lens = [max([len(heads[j])] + [len(str(r[j] or '')) for r in rows]) for j in range(n)]   # columns sized to their content
    lens = [14 if j in (rag, sev) else min(60, max(8, L)) for j, L in enumerate(lens)]
    if sev is not None: lens[sev] = 0.001
    tot = IG._total(lens); fr = [L / tot for L in lens]
    icons = None
    if b.get('icons'): used = set(); icons = [IG.status_icon(r[0], used) for r in rows]
    return IG._table(cv, x, y, w, k, theme, ci, [h if j != sev else '' for j, h in enumerate(heads)], fr, rows, rag_col=rag, bar_col=sev, name='table',
                     head_icons=[IG.status_icon(h) if j == 0 and b.get('icons') else None for j, h in enumerate(heads)], row_icons=icons)


def draw_ragcards(cv, b, x, y, w, k, theme, ci):
    """A card per workstream: a RAG edge and pill, an icon disc, the name, the owner and the update."""
    its = b['items']; n = len(its); per = 3 if w >= 880 and n != 4 else 2 if n > 1 else 1; g = 14 * k; cw = (w - g * (per - 1)) / per; pad = 16 * k; ic = 40 * k
    used = set(); parts = []
    for it in its:
        nfs, nls = IG.fit(it.get('name', ''), cw - 2 * pad - ic - 12 * k, 52 * k, round(20 * k), round(15 * k), 'bold', 1.2, 2)
        tfs, tls = IG.fit(it.get('text', '') or '—', cw - 2 * pad, 130 * k, round(max(IG._fl() + 0.5, 15.5 * k)), IG._fl(), 'body', 1.3, 5)
        parts.append((nfs, nls, tfs, tls, IG.status_icon(it.get('name', ''), used)))
    rows = [parts[i:i + per] for i in range(0, n, per)]; yy = y
    for ri, row in enumerate(rows):
        hh = max(pad * 2 + max(ic, len(p[1]) * p[0] * 1.2 + 22 * k) + 10 * k + 30 * k + 10 * k + len(p[3]) * p[2] * 1.3 for p in row)
        for j, (nfs, nls, tfs, tls, icn) in enumerate(row):
            it = its[ri * per + j]; cx = x + j * (cw + g); r = IG.rag_of(it.get('rag')); c = IG.RAG[r][0] if r else IG.PALETTE[(ci + ri * per + j) % 5]
            cv.rect(cx, yy, cw, hh, 'FFFFFF', IG.LINE, 14 * k, 1.2, name='ragcard'); cv.rect(cx, yy + 12 * k, 5 * k, hh - 24 * k, c, None, 2.5 * k, name='ragcard accent')
            icol = IG.icon_disc(cv, cx + pad, yy + pad, ic, c, IG.shade(c, 0.15), theme, bool(r), 'ragcard icon disc'); cv.icon(icn, cx + pad + ic * 0.2, yy + pad + ic * 0.2, ic * 0.6, icol, bold=True)
            tx = cx + pad + ic + 12 * k; ty = yy + pad
            ty += cv.text(tx, ty, cw - 2 * pad - ic - 12 * k, nls, nfs, IG.INK, 'bold', lh=1.2, name='ragcard name', src=it.get('name', ''))
            if it.get('owner'): cv.text(tx, ty + 2 * k, cw - 2 * pad - ic - 12 * k, IG.wrap(it['owner'], cw - 2 * pad - ic - 12 * k, round(max(IG._fl(), 14 * k)), 'body')[:1], round(max(IG._fl(), 14 * k)), IG.MUTED, 'body', lh=1.2, name='ragcard owner', src=it['owner'])
            py = yy + pad + max(ic, len(nls) * nfs * 1.2 + 22 * k) + 10 * k
            IG._rag_pill(cv, cx + pad, py, cw - 2 * pad, 30 * k, r, k)
            cv.text(cx + pad, py + 40 * k, cw - 2 * pad, tls, tfs, IG.INK if it.get('text') else IG.MUTED, 'body', lh=1.3, name='ragcard text', src=it.get('text', '') or '—')
        yy += hh + g
    return yy - y - g


IG.DRAW.update({'table': draw_table, 'ragcards': draw_ragcards})
IG.SECTION_ICON.update({'table': 'list', 'ragcards': 'team', 'compare': 'balance', 'quote': 'chat'})


# ------------------------------------------------------------------------------------------------------------------ section readers
def _split(x):
    x = re.sub(r'^\d{1,2}[.)]\s+', '', str(x).strip())   # "1. Request: …" read back from a Word numbered list
    a, sep, b = x.partition(': ') if ': ' in x else x.partition(' — ') if ' — ' in x else x.partition(' - ')
    return (IG.clean(a, 60), IG.clean(b, 170)) if sep and len(a) <= 60 else ('', IG.clean(x, 170))


def _get(r, cm, f): return (r[cm[f]] if cm.get(f) is not None and cm[f] < len(r) else '').strip()


def to_stats(s, h):
    items = []
    if s['rows'] and len(s['rows']) > 1:
        head = s['rows'][0]; cm = IG._map_cols(head, {'label': r'kpi|measure|metric|name|what', 'value': r'actual|value|now|result|this', 'target': r'target|goal|plan'})
        for r in s['rows'][1:5]:
            lab = _get(r, cm, 'label') or r[0]; val = _get(r, cm, 'value') or (r[1] if len(r) > 1 else '')
            if val: items.append({'value': val, 'label': lab + (f" · target {_get(r, cm, 'target')}" if _get(r, cm, 'target') else ''), 'icon': IG.status_icon(lab)})
    for x in s['bullets'][:4]:
        a, b = _split(x)
        if not a: continue
        val, lab = (a, b) if IG.num(a) is not None and (IG.num(b) is None or len(a) <= len(b)) else (b, a)
        items.append({'value': val, 'label': lab, 'icon': IG.status_icon(lab)})
    return {'type': 'stats', 'title': h, 'items': items[:4]} if items else None


def to_list(s, h):
    items = []; used = set()
    for x in s['bullets'][:8]:
        a, b = _split(x); a = a or ' '.join(b.split()[:5]).rstrip('.,;:'); b = b if a != b else ''
        items.append({'title': a, 'text': b if b != a else '', 'icon': IG.status_icon(a + ' ' + b, used)})
    return {'type': 'list', 'title': h, 'items': items} if items else None


def to_steps(s, h):
    items = [dict(zip(('title', 'text'), _split(x))) for x in s['bullets'][:6]]
    items = [{'title': it['title'] or ' '.join(it['text'].split()[:4]), 'text': it['text'] if it['title'] else ''} for it in items]
    return {'type': 'steps', 'title': h, 'items': items} if items else None


DATE = re.compile(r'^(\d{1,2}/\d{1,2}(?:/\d{2,4})?|(?:Q[1-4]|H[12])(?:\s*FY)?\s*\d{0,4}|FY\d{2,4}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*\.?\s*\d{0,4}|\d{4}-\d{2}-\d{2}|\d{1,2}:\d{2}(?:\s*[ap]m)?|Week\s*\d+|Day\s*\d+|Phase\s*\d+|Wave\s*\d+)', re.I)


def to_timeline(s, h):
    items = []
    if s['rows'] and len(s['rows']) > 1:
        head = s['rows'][0]; cm = IG._map_cols(head, {'when': r'date|when|time|due|by', 'title': r'milestone|event|what|step|item'})
        for r in s['rows'][1:8]:
            w_ = _get(r, cm, 'when'); t_ = _get(r, cm, 'title') or next((c for j, c in enumerate(r) if j != cm.get('when') and c), '')
            if w_ or t_: items.append({'when': IG.clean(w_, 18), 'title': IG.clean(t_, 60)})
    for x in s['bullets'][:7]:
        m = DATE.match(x)
        if m: rest = x[m.end():].lstrip(' :—–-'); items.append({'when': m.group(1), 'title': IG.clean(rest, 60)})
        else: a, b = _split(x); items.append({'when': a[:18], 'title': IG.clean(b, 60)})
    return {'type': 'timeline', 'title': h, 'items': items[:7]} if len(items) >= 2 else None


def to_compare(s, h):
    if len(s['subs']) >= 2:
        a, b = s['subs'][:2]; return {'type': 'compare', 'title': h, 'left': {'title': a['title'], 'items': a['items']}, 'right': {'title': b['title'], 'items': b['items']}}
    if s['rows'] and len(s['rows']) > 1 and len(s['rows'][0]) >= 2:
        hd = s['rows'][0]; return {'type': 'compare', 'title': h, 'left': {'title': hd[0], 'items': [r[0] for r in s['rows'][1:] if r and r[0]]}, 'right': {'title': hd[1], 'items': [r[1] for r in s['rows'][1:] if len(r) > 1 and r[1]]}}
    return None


def to_table(s, h, icons=False):
    rows = s['rows']
    if rows and len(rows) > 1: return {'type': 'table', 'title': h, 'cols': rows[0][:6], 'items': [r[:6] for r in rows[1:11]], 'icons': icons}
    if s['bullets']:   # "Term: meaning" bullets read as a two-column table
        pairs = [_split(x) for x in s['bullets'][:10]]
        if all(a for a, _ in pairs): return {'type': 'table', 'title': h, 'cols': ['', ''], 'items': [[a, b] for a, b in pairs], 'icons': icons}
    return None


def to_ragcards(s, h):
    rows = s['rows']
    if not rows or len(rows) < 2: return None
    cm = IG._map_cols(rows[0], {'name': IG.COLS_RAG['name'], 'owner': IG.COLS_RAG['owner'], 'rag': IG.COLS_RAG['rag'], 'text': r'update|this week|comment|note|summary|progress', 'next': r'next week|next|planned|upcoming'})
    def upd(r):   # this week's update, and next week's when the table has both (v6.13: "Next week" was dropped)
        a_, b_ = _get(r, cm, 'text'), _get(r, cm, 'next'); a_ = '' if EMPTY.fullmatch(a_) else a_; b_ = '' if EMPTY.fullmatch(b_) else b_
        return (a_ + (' · Next: ' + b_ if b_ else '')) if a_ else ('Next: ' + b_ if b_ else '')
    items = [{'name': _get(r, cm, 'name'), 'owner': _get(r, cm, 'owner').rstrip(' /'), 'rag': _get(r, cm, 'rag'), 'text': upd(r)} for r in rows[1:10] if _get(r, cm, 'name')]
    return {'type': 'ragcards', 'title': h, 'items': items} if items else None


def to_rag(s, h):
    rows = s['rows']
    if not rows or len(rows) < 2: return None
    head = rows[0]; cm = IG._map_cols(head, IG.COLS_RAG); cols = ['This week', 'Next week']
    if cm['now'] is not None: cols[0] = IG._week_label(head[cm['now']], 'This week')
    if cm['next'] is not None: cols[1] = IG._week_label(head[cm['next']], 'Next week')
    items = [{'name': _get(r, cm, 'name'), 'owner': _get(r, cm, 'owner').rstrip(' /'), 'rag': _get(r, cm, 'rag'), 'now': _get(r, cm, 'now'), 'next': _get(r, cm, 'next')} for r in rows[1:] if _get(r, cm, 'name')]
    return {'type': 'rag', 'title': h, 'cols': cols, 'items': items} if items else None


def to_risks(s, h):
    items = []
    if s['rows'] and len(s['rows']) > 1:
        cm = IG._map_cols(s['rows'][0], IG.COLS_RISK)
        for r in s['rows'][1:7]:
            if _get(r, cm, 'title') or _get(r, cm, 'text'): items.append({'title': _get(r, cm, 'title') or _get(r, cm, 'text'), 'text': _get(r, cm, 'text') if _get(r, cm, 'title') else '', 'owner': _get(r, cm, 'owner'), 'due': _get(r, cm, 'due'), 'rag': _get(r, cm, 'rag')})
    for x in s['bullets'][:6]:
        a, b = _split(x); items.append({'title': b if a else x, 'text': a, 'owner': '', 'due': '', 'rag': ''})
    return {'type': 'risks', 'title': h, 'items': items} if items else None


def to_takeaway(s, h, prefix=True):
    text = ' '.join(s['paras'] + s['bullets'])
    if not text: return None
    label = h if prefix and h and re.search(r'decision|recommend|ask|bottom line|root cause|why|purpose|objective', h, re.I) else ''
    return {'type': 'takeaway', 'title': '', 'text': (label + ': ' if label else '') + text[:220], 'icon': 'target'}


def fallback(s, h):
    if s.get('pics'): return to_feature(s, h) if s['bullets'] else to_gallery(s, h)
    if s['rows'] and len(s['rows']) > 1: return to_table(s, h)
    if len(s['subs']) >= 2: return to_compare(s, h)
    if s['bullets'] and s['ordered']: return to_steps(s, h)
    if s['bullets']: return to_list(s, h)
    if s['paras']: return to_takeaway(s, h)
    return None


def to_gallery(s, h):
    p = s.get('pics') or []
    if not p: return None
    if len(p) == 1: return to_image(s, h)
    return {'type': 'gallery', 'title': h, 'items': [{'src': x['src'], 'caption': x['caption']} for x in p[:4]]}


def to_image(s, h):
    p = s.get('pics') or []
    if not p: return None
    if len(p) > 1: return to_gallery(s, h)
    return {'type': 'image', 'title': h, 'src': p[0]['src'], 'caption': p[0]['caption'] or (s['paras'][0][:160] if s['paras'] else '')}


def to_feature(s, h):
    """The picture beside its points (a UI concept and what it does); without a picture, the points alone."""
    p = s.get('pics') or []; pts = to_list(s, h)
    if p and pts: return {'type': 'feature', 'title': h, 'src': p[0]['src'], 'caption': p[0]['caption'], 'items': pts['items'][:6]}
    return to_image(s, h) if p else pts


def to_band(s, h):
    """The value in one strip: each bullet's lead ("Faster approvals: in one queue" -> "Faster approvals")."""
    its = [{'title': IG.clean(_split(x)[0] or x, 60)} for x in s['bullets'][:5]]
    return {'type': 'band', 'label': h, 'items': its} if len(its) >= 2 else (to_list(s, h) if its else None)


ARROW = re.compile(r'\s*(?:→|->|>)\s*')


def to_flow(s, h):
    """Today and tomorrow: two sub-headings with their steps ("### Today" ...), or lines such as "Today: e-mail -> manual checks"."""
    lanes = []
    for i, sub in enumerate(s['subs'][:2]):
        its = [{'title': IG.clean(x, 60)} for x in sub['items'][:6]]
        if its: lanes.append({'title': sub['title'], 'tone': ('before', 'after')[i] if len(s['subs']) > 1 else '', 'items': its})
    if not lanes:
        rows = [x for x in s['bullets'] + s['paras'] if ARROW.search(x)][:2]
        for i, x in enumerate(rows):
            a, sep, b = x.partition(': ')
            steps = [IG.clean(y, 60) for y in ARROW.split(b if sep else x) if y.strip()][:6]
            if steps: lanes.append({'title': a if sep else '', 'tone': ('before', 'after')[i] if len(rows) > 1 else '', 'items': [{'title': y} for y in steps]})
    return {'type': 'flow', 'title': h, 'lanes': lanes} if lanes else (to_compare(s, h) or to_list(s, h))


READ = {'stats': to_stats, 'list': to_list, 'steps': to_steps, 'timeline': to_timeline, 'compare': to_compare, 'table': to_table,
        'image': to_image, 'gallery': to_gallery, 'feature': to_feature, 'band': to_band, 'flow': to_flow,
        'ragcards': to_ragcards, 'rag': to_rag, 'risks': to_risks, 'takeaway': to_takeaway}


# ------------------------------------------------------------------------------------------------------------------ the catalogue
# Each: id, group, name, blurb, facts (strip labels and the words that find them), sections (heading pattern → block), md (the template).
T = []


def tpl(**kw): T.append(kw)


tpl(id='status_cards', group='Status reports', name='Weekly status - scorecard', blurb='A status card per workstream, highlights and lowlights, the asks',
    facts=[('Overall status', r'overall( status)?|status|rag', True), ('Week ending', r'week( ending| of)?|period|as of', False), ('Programme', r'programme|program|project', False), ('Lead', r'lead|owner|pm', False)],
    sections=[(r'work ?stream|status by|teams?', 'ragcards'), (r'highlight|lowlight|went well|watch', 'compare'), (r'ask|support|help|decision', 'list')],
    md="""# Store Systems Programme - Weekly Scorecard
Week ending: 10/09
Overall status: Amber
Programme: Store Systems Modernisation
Lead: Nadia Wren

## Workstreams
| Workstream | Owner | Status | Update |
|---|---|---|---|
| POS upgrade | Rowan | Green | 212 of 1,400 stores live; no P1 incidents |
| Inventory accuracy | Tess | Amber | Cycle count pilot slipped one week for training |
| Store network | Arlo | Green | SD-WAN in 3 regions; 4th starts 10/14 |
| Loyalty at till | Mila | Red | Points reversal defect blocks wave 2 |
| Training | Vance | Green | 1,850 associates trained |

## Highlights and lowlights
### Highlights
- POS wave 1 closed with no P1 incidents
- Training ahead of plan
### Lowlights
- Loyalty reversal defect blocks wave 2
- Cycle count pilot one week late

## Asks
- Loyalty vendor: a fix date for the reversal defect by 10/14
- Store Ops: release 40 trainers for the wave 2 stores
""")

tpl(id='exec', group='Status reports', name='Executive one-glance', blurb='Overall status, three numbers, wins, risks, the decisions - for a VP read in a minute',
    facts=[('Overall status', r'overall( status)?|status|rag', True), ('Period', r'period|week|month|quarter|as of', False), ('Sponsor', r'sponsor|executive|vp', False)],
    sections=[(r'number|kpi|metric|at a glance|headline', 'stats'), (r'win|achiev|done|delivered|progress', 'list'), (r'risk|issue|concern|watch', 'risks'), (r'decision|ask|need', 'takeaway')],
    md="""# Demand Planning on o9 - Executive Update
Period: October, week 2
Overall status: Amber
Sponsor: SVP Supply Chain

## Key numbers
- 78%: forecast accuracy in the pilot categories
- 4 of 6: workstreams on track
- $1.2M: inventory released in the pilot DCs

## Wins
- Data: Three years of sales history loaded and reconciled
- Pilot: Cosmetics forecast live in two DCs
- Team: Data science lead hired

## Risks
| Risk or ask | Support needed from | Owner | Need by | Severity |
|---|---|---|---|---|
| Delta Share firewall rules not yet approved | Ulta Security | Elliot | 10/14 | Red |
| Store attribute data late from Store Ops | Store Ops | Nadia | 10/21 | Amber |

## Decision needed
Approve Delta Share as the connection for the historical data load by 10/14.
""")

tpl(id='milestones', group='Status reports', name='Milestone status - steering committee', blurb='Milestones on a timeline and in a table with RAG, the critical path, decisions',
    facts=[('Overall status', r'overall( status)?|status|rag', True), ('Next steerco', r'next (steerco|steering|meeting)|meeting', False), ('Go-live', r'go[- ]live|launch|target date', False)],
    sections=[(r'milestone|plan|roadmap|dates', 'table'), (r'critical path|path|sequence|dependenc', 'steps'), (r'decision|ask|need', 'takeaway')],
    md="""# Returns Modernisation - Steering Committee
Overall status: Green
Next steerco: 10/23
Go-live: 2/2

## Milestones
| Milestone | Date | Owner | Status |
|---|---|---|---|
| Design signed off | 10/09 | Rowan | Green |
| Build complete | 11/20 | Nadia | Green |
| Store pilot (20 stores) | 12/04 | Tess | Amber |
| Holiday freeze | 12/15 | IT Ops | Green |
| Chain rollout | 2/2 | Tess | Green |

## Critical path
1. Build: POS and loyalty changes in one release
2. Test: Regression with the holiday code freeze in mind
3. Pilot: 20 stores for two weeks
4. Rollout: Region by region after the freeze

## Decision needed
Confirm the pilot can run in the two weeks before the holiday freeze.
""")

tpl(id='process', group='Process & product', name='Process one-pager', blurb='Purpose, trigger, the steps, who does what, systems, KPIs and controls',
    facts=[('Process owner', r'process owner|owner', False), ('Trigger', r'trigger|starts when|start', False), ('Frequency', r'frequency|cadence|how often|runs', False), ('Systems', r'systems?|tools?', False)],
    sections=[(r'purpose|why|objective', 'takeaway'), (r'step|how it works|flow|procedure', 'steps'), (r'role|raci|who', 'table'), (r'kpi|measure|metric', 'stats'), (r'control|check|compliance|rule', 'list')],
    md="""# Store Transfer Request - Process
Process owner: Inventory Control
Trigger: A store requests stock from another store
Frequency: Daily, before 2 pm
Systems: Inventory system, store app

## Purpose
Move stock between stores the same week, so a guest's product is on the shelf where they shop.

## Steps
1. Request: The store raises a transfer in the store app
2. Approve: The district manager approves within 4 hours
3. Pick: The sending store picks and packs the order
4. Ship: Courier collects the next morning
5. Receive: The receiving store scans it in

## Roles
| Role | Responsible for |
|---|---|
| Store manager | Raises and receives the transfer |
| District manager | Approves within 4 hours |
| Inventory Control | Monitors open transfers daily |

## KPIs
- 2 days: request to shelf
- 98%: transfers received in full
- 4 hours: approval time

## Controls
- Approval: No transfer ships without the district manager's approval
- Value limit: Transfers over $5,000 need Finance sign-off
""")

tpl(id='product', group='Process & product', name='Product one-pager', blurb='What it is, who it is for, the problem, features, benefits, roadmap, contacts',
    facts=[('Product owner', r'product owner|owner', False), ('Status', r'status|stage', False), ('Launch', r'launch|go[- ]live|release', False)],
    sections=[(r'problem|why|pain', 'takeaway'), (r'who|audience|users|for whom', 'list'), (r'feature|capabilit|what it does', 'list'), (r'benefit|value|impact|result', 'stats'), (r'roadmap|timeline|next|release', 'timeline'), (r'contact|team|who to ask', 'table')],
    md="""# Ultamate Rewards in the App - Product One-pager
Product owner: Mila Hart
Status: In pilot
Launch: Q1 FY27

## The problem
Guests can't see their points or rewards when they shop in store, so offers go unused.

## Who it's for
- Store guests: See points and offers at the till
- Associates: Apply rewards without a manager override

## Key features
- Wallet: Points and rewards in one card in the app
- Scan to apply: Associates scan the guest's code at the till
- Offers: Personal offers shown before checkout

## Benefits
- 12%: more rewards redeemed in the pilot
- 30 sec: faster checkout with rewards
- 4.7: guest app rating in the pilot

## Roadmap
- Q4: Pilot in 40 stores
- Q1: Chain-wide launch
- Q2: Personal offers in the app

## Contacts
| Name | Role |
|---|---|
| Mila Hart | Product owner |
| Rowan Pike | Engineering lead |
""")

tpl(id='change', group='Process & product', name='Release / change notice', blurb="What's changing, who is affected, when, what to do, before and after, support",
    facts=[('Go-live', r'go[- ]live|date|when|release', False), ('Audience', r'audience|for|who', False), ('Impact', r'impact|change level|size', False)],
    sections=[(r"what('s| is) changing|change|summary", 'list'), (r'who|affected|audience', 'list'), (r'what (you|to)( need to)? do|need to do|action|steps|how to', 'steps'), (r'before|after|compare', 'compare'), (r'support|help|contact|question', 'table')],
    md="""# New Returns Screen at the Till - Change Notice
Go-live: 11/4
Audience: All store associates
Impact: Medium

## What's changing
- One screen: Returns, exchanges and loyalty reversal in one place
- Receipt lookup: Find any order from the last 90 days by phone number
- Refund to card: No more cash refunds over $50

## Who is affected
- Associates: New screen at every till
- Store managers: Fewer overrides to approve

## What you need to do
1. Training: Complete the 15-minute module by 11/1
2. Try it: Practise in training mode on 11/3
3. Go live: Use the new screen from 11/4

## Before and after
### Before
- Three screens for one return
- Manager override for loyalty points
### After
- One screen for every return
- Points reversed automatically

## Support
| Contact | For | How |
|---|---|---|
| Store Help Desk | Till issues | Ext. 4357 |
| Training team | The module | #store-training |
""")

tpl(id='cheatsheet', group='Knowledge', name='Knowledge cheat sheet', blurb="Key terms, how-to steps, do's and don'ts, shortcuts, where to get help",
    facts=[('Topic', r'topic|subject|area', False), ('For', r'for|audience|role', False), ('Updated', r'updated|version|as of', False)],
    sections=[(r'term|glossary|definition|vocab', 'table'), (r'how to|steps|procedure|quick start', 'steps'), (r"do.*don|dos|rules|tips", 'compare'), (r'shortcut|t-?code|command|key', 'table'), (r'help|contact|support|where', 'list')],
    md="""# Travel & Expenses - Cheat Sheet
Topic: Business travel and expense claims
For: All employees
Updated: October 2026

## Key terms
| Term | Meaning |
|---|---|
| Per diem | Daily meal allowance by city |
| Pre-approval | Manager sign-off before booking |
| Receipt | Itemised proof of every purchase over $25 |
| Corporate card | Company card for travel and client costs |

## How to claim an expense
1. Capture: Photograph the receipt in the expense app
2. Submit: Add the cost centre and business purpose
3. Approve: Your manager approves within 5 days

## Do's and don'ts
### Do
- Book flights through the travel portal
- Submit claims within 30 days
### Don't
- Split a purchase to stay under a limit
- Pay personal costs on the corporate card

## Shortcuts
| Action | Where |
|---|---|
| Book travel | Travel portal |
| Submit a claim | Expense app |
| Check a policy | Policy hub |

## Need help?
- Travel desk: #travel-help in Teams
- Finance support: Service desk, Expenses queue
""")

tpl(id='charter', group='Plans & decisions', name='Project charter', blurb='Objective, scope in and out, timeline, team, success measures, risks',
    facts=[('Sponsor', r'sponsor', False), ('Lead', r'lead|pm|owner', False), ('Start', r'start', False), ('End', r'end|finish|go[- ]live', False), ('Budget', r'budget|cost|investment', False)],
    sections=[(r'objective|goal|purpose|why', 'takeaway'), (r'scope', 'compare'), (r'timeline|plan|milestone|roadmap', 'timeline'), (r'team|roles|who', 'table'), (r'success|measure|kpi|target', 'stats'), (r'risk|issue|assumption', 'risks')],
    md="""# Supplier Onboarding Portal - Project Charter
Sponsor: VP Merchandising
Lead: Nadia Wren
Start: 11/1
End: 4/30
Budget: $850K

## Objective
Onboard new beauty brands in 10 days instead of 6 weeks, with every item set up right the first time.

## Scope
### In scope
- Brand registration and contracts
- Item setup for the ERP and the website
### Out of scope
- Payments and invoicing
- Drop-ship brands

## Timeline
- Nov: Design and vendor selection
- Jan: Build
- Mar: Pilot with 10 brands
- Apr: Launch

## Team
| Role | Name |
|---|---|
| Sponsor | VP Merchandising |
| Lead | Nadia Wren |
| Architect | Rowan Pike |

## Success measures
- 10 days: brand onboarding time
- 95%: items set up right first time
- 200: brands onboarded in year one

## Risks
| Risk or ask | Support needed from | Owner | Need by | Severity |
|---|---|---|---|---|
| Item data standards not agreed | Merchandising | Nadia | 12/1 | Amber |
""")

tpl(id='decision', group='Plans & decisions', name='Decision brief', blurb='Context, the options compared, the recommendation, impact, next steps',
    facts=[('Decision owner', r'decision owner|owner|decider', False), ('Needed by', r'needed by|deadline|by when|due', False), ('Status', r'status', False)],
    sections=[(r'context|background|situation|problem', 'takeaway'), (r'option|alternative|choice', 'table'), (r'recommend', 'takeaway'), (r'impact|benefit|cost|value', 'stats'), (r'next|step|action', 'steps')],
    md="""# Historical Data Load - Decision Brief
Decision owner: VP Enterprise Architecture
Needed by: 10/14
Status: For decision

## Context
o9 needs three years of sales history. Security has not yet approved a connection from Databricks to o9.

## Options
| Option | Pros | Cons | Time |
|---|---|---|---|
| Delta Share | Live, no copies | Firewall change | 2 weeks |
| Nightly file drop | No new connection | Copies data, slower | 3 weeks |
| Manual extract | Fast to start | Not repeatable | 1 week |

## Recommendation
Use Delta Share: no data copies, and it is the pattern for every later o9 feed.

## Impact
- 2 weeks: to first load
- 0: data copies to maintain

## Next steps
1. Approve: Security signs off the firewall rule
2. Connect: Platform team opens the share
3. Load: First history load into o9
""")

tpl(id='kpi', group='Plans & decisions', name='KPI scorecard', blurb='Headline numbers, every KPI against target with status, commentary, actions',
    facts=[('Period', r'period|month|week|quarter|as of', False), ('Owner', r'owner|lead', False), ('Overall status', r'overall( status)?|status|rag', True)],
    sections=[(r'headline|key number|at a glance', 'stats'), (r'kpi|scorecard|measure|metric|detail', 'table'), (r'comment|insight|why|narrative', 'list'), (r'action|next|fix', 'steps')],
    md="""# Store Operations - KPI Scorecard
Period: September
Owner: VP Store Operations
Overall status: Amber

## Headline numbers
- 96.4%: on-shelf availability
- 2.1 days: replenishment lead time
- 91%: inventory accuracy

## KPI detail
| KPI | Actual | Target | Trend | Status |
|---|---|---|---|---|
| On-shelf availability | 96.4% | 97% | Up | Amber |
| Replenishment lead time | 2.1 days | 2 days | Flat | Amber |
| Inventory accuracy | 91% | 95% | Down | Red |
| Shrink | 1.2% | 1.5% | Down | Green |

## Commentary
- Accuracy: Cycle counts paused in two regions for the POS upgrade
- Availability: Holiday sets arrived early in 300 stores

## Actions
1. Restart: Cycle counts in both regions from 10/14
2. Review: Accuracy by store at the 10/21 ops meeting
""")

tpl(id='incident', group='Plans & decisions', name='Post-incident review', blurb='What happened, the impact, the timeline, the root cause, the actions',
    facts=[('Severity', r'severity|priority|sev', False), ('Date', r'date|when', False), ('Duration', r'duration|outage|downtime', False), ('Owner', r'owner|lead|commander', False)],
    sections=[(r'what happened|summary|overview', 'takeaway'), (r'impact', 'stats'), (r'timeline|sequence|chronolog', 'timeline'), (r'root cause|cause|why', 'takeaway'), (r'action|follow|fix|prevent', 'table')],
    md="""# POS Payment Outage - Post-incident Review
Severity: P1
Date: 10/3
Duration: 47 minutes
Owner: IT Operations

## What happened
Card payments failed in 312 stores after a certificate on the payment gateway expired.

## Impact
- 47 min: card payments down
- 312: stores affected
- $410K: estimated lost sales

## Timeline
- 10:02: First store reports card declines
- 10:09: P1 declared, bridge opened
- 10:31: Expired certificate found
- 10:49: Certificate renewed, payments recover

## Root cause
The gateway certificate was renewed by hand and its expiry was not monitored.

## Actions
| Action | Owner | Due | Status |
|---|---|---|---|
| Monitor every certificate's expiry | IT Ops | 10/17 | Green |
| Automate certificate renewal | Platform | 11/15 | Amber |
| Add a payment-failure alert per region | Payments | 10/24 | Green |
""")

# ------------------------------------------------------------------------------------------------------------------ v7 stories with pictures
# One-pagers that tell their story around the team's own pictures - a UI concept for a budget ask, the product for an
# introduction, what shipped for a status update. A picture is a Markdown picture line, "![caption](/mnt/data/screen.png)";
# the samples' pictures are the skill's own (its UI screens, the Ulta template's photos).
tpl(id='proposal', group='Stories with pictures', name='Budget proposal - with a UI concept', blurb='The value in a band, the UI concept beside what it does, how the work changes, the decision',
    facts=[('Budget ask', r'budget( ask)?|investment|funding|ask', False), ('Sponsor', r'sponsor|executive|owner', False), ('Go-live', r'go[- ]live|timeline|launch|delivery|when', False),
           ('Payback', r'payback|roi|return', False)],
    sections=[(r'value|benefit|why', 'band'), (r'concept|screen|\bui\b|solution|portal|app\b|how it works|what we build', 'feature'), (r'how the work changes|today|current|future|before|change', 'flow'),
              (r'decision|ask|approve', 'takeaway')],
    md="""# Vendor Price Portal
Price changes in one portal, checked at entry and approved in one queue.
Budget ask: $1.2M
Sponsor: SVP Merchandising
Go-live: Q3 FY26
Payback: 14 months

## Business value
- Less manual effort
- Faster approvals
- Fewer pricing errors
- A full audit trail

## The portal: UI concept
![Price change requests, with every check before approval](sample:price-portal)
- Request: Brand partners submit price changes online
- Validate: Margins and limits checked at entry
- Approve: Pricing reviews in one queue
- Audit: Every change and approver kept

## How the work changes
### Today: manual and disconnected
- E-mail and spreadsheets
- Manual margin checks
- Re-keyed into systems
- Errors found late
### Tomorrow: digital and streamlined
- One online request
- Checks at entry
- One approval queue
- Live the same day

## Leadership decision
Approve $1.2M for phase 1 (requests, checks, the approval queue and the audit trail); size bulk uploads and promotions separately.
""")

tpl(id='intro', group='Stories with pictures', name='Product introduction - with pictures', blurb='What it is in a line, the product in pictures, who it is for, how the work changes, the value, the next step',
    facts=[('Product owner', r'product owner|owner', False), ('Status', r'status|stage', False), ('Launch', r'launch|go[- ]live|release|available', False)],
    sections=[(r'what it is|overview|in a line|summary', 'subtitle'), (r'pictures?|look|screens?|photos?|see it', 'gallery'), (r'who|audience|users|for whom', 'list'),
              (r'how the work changes|today|current|future|before|change', 'flow'), (r'value|benefit|impact|result', 'stats'),
              (r'next|ask|decision|how to start', 'takeaway')],
    md="""# Rewards Wallet
Product owner: Mila Hart
Status: In pilot
Launch: Q1 FY27

## What it is
Points, rewards and offers in one wallet in the app, ready to scan at the till.

## In pictures
![The wallet in the app](sample:rewards-app)
![Rewards at the till](sample:guest-bag)
![Offers on beauty favorites](sample:product-swatches)

## Who it's for
- Store guests: See points and offers before they pay
- Associates: Apply rewards without a manager override

## How the work changes
### Today
- Paper coupons
- Points looked up at the till
- A manager override
### Tomorrow
- Offers in the app
- Scan the guest's code
- Applied in seconds

## Value
- 12%: more rewards redeemed in the pilot
- 30 sec: faster checkout with rewards
- 4.7: guest app rating in the pilot

## Next step
Approve the chain-wide launch for Q1, after the holiday freeze.
""")

tpl(id='status_pics', group='Stories with pictures', name='Status update - with screenshots', blurb='Overall status, what shipped in screenshots, workstreams, risks, what comes next, the decision',
    facts=[('Overall status', r'overall( status)?|status|rag', True), ('Period', r'period|week|sprint|month|as of', False), ('Lead', r'lead|owner|pm', False)],
    sections=[(r'shipped|delivered|demo|screens?|what.?s new|built', 'gallery'), (r'work ?stream|status by|teams?', 'ragcards'), (r'risk|issue|blocker', 'risks'),
              (r'next|coming|plan', 'timeline'), (r'decision|ask|need', 'takeaway')],
    md="""# Vendor Price Portal: Sprint 6
Overall status: Green
Period: Sprint 6, weeks 11-12
Lead: Nadia Wren

## What shipped
![Partners submit and track their requests](sample:price-portal)
![Pricing approves in one queue](sample:approval-queue)

## Workstreams
| Workstream | Owner | Status | Update |
|---|---|---|---|
| Partner requests | Rowan | Green | Live for 12 pilot brands |
| Approval queue | Tess | Green | Margin and limit checks on |
| Reporting | Arlo | Amber | Audit export slips one sprint |

## Risks
| Risk or ask | Support needed from | Owner | Need by | Severity |
|---|---|---|---|---|
| Item master feed late | Data platform | Arlo | 11/14 | Amber |

## Next
- 11/18: Pilot with 25 brands
- 12/02: Audit export
- 12/16: Go-live decision

## Decision needed
Confirm the 25 pilot brands so onboarding starts on 11/18.
""")

BY_ID = {t['id']: t for t in T}
GROUPS = ['Status reports', 'Process & product', 'Knowledge', 'Plans & decisions', 'Stories with pictures']


def catalogue():
    """The dropdown: Free-form and Auto, the weekly status (table), then every template by group."""
    out = [{'id': 'free', 'name': 'Free-form', 'group': '', 'blurb': 'Your content picks the blocks: numbers, steps, dates, a takeaway'},
           {'id': 'auto', 'name': 'Auto - pick the template from the content', 'group': '', 'blurb': 'AI on: the model picks the template and fits your text to it. AI off: a template is used when your content clearly follows one'},
           {'id': 'status', 'name': 'Weekly status - table', 'group': 'Status reports', 'blurb': 'Overall status, workstreams with RAG, risks & support required, milestones, the decision'}]
    return out + [{'id': t['id'], 'name': t['name'], 'group': t['group'], 'blurb': t['blurb']} for t in sorted(T, key=lambda t: GROUPS.index(t['group']))]


def content_md(tid):
    return IG.STATUS_TEMPLATE_MD if tid == 'status' else BY_ID[tid]['md'] if tid in BY_ID else ''


# ------------------------------------------------------------------------------------------------------------------ reading
EMPTY = re.compile(r'[\s—–\-.]*|n/?a|none', re.I)


def _facts(text, facts):
    got = {}; kept = []; seen_h2 = False; extra = []
    for l in text.split('\n'):
        s = re.sub(r'^[-*•]\s+', '', l.strip())   # Word read-back can turn the "Key: value" lines into bullets
        if s.startswith('## '): seen_h2 = True
        m = re.match(r'^([A-Za-z][A-Za-z /&\-]{1,30}):\s*(.*)$', s)
        if not seen_h2 and m and not s.startswith('|') and not s.startswith('#'):
            k_ = m.group(1).strip(); v_ = m.group(2).strip()
            if EMPTY.fullmatch(v_): continue   # v6.13: "Phase: - " says nothing - no tile, no subtitle, no takeaway bar
            key = next((lab for lab, pat, _ in facts if lab not in got and (re.fullmatch(pat, k_, re.I) or re.search(r'(^|\s)(' + pat + r')$', k_, re.I))), None)
            if key: got[key] = IG.clean(v_, 60); continue
            if len(extra) < 2 and len(k_) <= 24 and len(v_) <= 60: extra.append((k_[0].upper() + k_[1:], IG.clean(v_, 60))); continue   # a filled-in fact the template does not name: a tile too
        kept.append(l)
    got['_extra'] = extra
    return got, '\n'.join(kept)


def template_spec(tid, text, fmt='onepager', theme='ulta', title=''):
    """Filled-in content → the template's infographic, by rules. A section that matches no rule is read by its shape."""
    if tid == 'status': return IG.status_spec(text, fmt, theme, title)
    t = BY_ID[tid]; text = IG._detab(text)
    facts, rest = _facts(text, t['facts']); t0, subtitle, source, secs = IG._sections(rest)
    blocks = []; strip = []
    for lab, _, is_rag in t['facts']:
        if facts.get(lab): strip.append({'label': lab, 'value': facts[lab], 'rag': facts[lab] if is_rag else ''})
    for lab, val in facts.get('_extra') or []: strip.append({'label': lab, 'value': val, 'rag': val if re.search(r'status|rag|health', lab, re.I) else ''})
    if strip: blocks.append({'type': 'status', 'items': strip[:5]})
    used = set()
    for s in secs:
        h = s['title'] or ''
        if re.search(r'how to (fill|use)|instructions|ignores this', h, re.I): continue
        rule = next(((pat, kind) for pat, kind in t['sections'] if re.search(pat, h, re.I) and (pat, kind) not in used), None)
        b = None
        if rule and rule[1] == 'subtitle':   # "What it is": the line under the title
            used.add(rule)
            if (s['paras'] or s['bullets']) and not subtitle: subtitle = ' '.join(s['paras'] + s['bullets'])[:180]; continue
            rule = None
        if rule:
            used.add(rule); kind = rule[1]
            b = READ[kind](s, h) if kind != 'table' else to_table(s, h, icons=bool(re.search(r'role|team|contact|support|action', h, re.I)))
            if b is None and kind == 'takeaway' and s['paras'] and not blocks and not subtitle: subtitle = ' '.join(s['paras'])[:180]
        if b is None: b = fallback(s, h)
        if b: blocks.append(b)
    return IG.normalise({'title': title or t0 or t['name'], 'kicker': t['name'].split(' - ')[0].split(' \u2014 ')[0], 'subtitle': subtitle, 'source': source, 'format': fmt, 'theme': theme,
                         'template': tid, 'blocks': blocks})


def coverage(tid, text):
    """(found, total, missing headings): how far a text follows the template - the sections whose heading the template expects."""
    if tid not in BY_ID and tid != 'status': return 0, 0, []
    secs = BY_ID[tid]['sections'] if tid in BY_ID else [(r'work ?stream|status by', 'rag'), (r'risk|issue|support', 'risks'), (r'milestone|timeline|dates', 'timeline'), (r'decision|ask', 'takeaway')]
    heads = [s['title'] for s in IG._sections(IG._detab(text))[3] if s['title']]
    found = [pat for pat, _ in secs if any(re.search(pat, h, re.I) for h in heads)]
    names = [re.split(r'\||\\', pat)[0].strip('()^?') for pat, _ in secs if pat not in found]
    return len(found), len(secs), names


def detect(text):
    """The template the content clearly follows (rules, AI off): the best share of its sections found, at least 2 sections and over half
    of them; otherwise 'free'."""
    best = ('free', 0.0)
    for tid in ['status'] + [t['id'] for t in T]:
        f, n, _ = coverage(tid, text)
        if n and f >= 2 and f / n > 0.5 and f / n > best[1]: best = (tid, f / n)
    return best[0]


def sample_spec(tid, fmt='onepager', theme='ulta'):
    spec = template_spec(tid, content_md(tid), fmt, theme)
    import pictures                              # the sample's pictures: the skill's own
    pictures.take_in(spec)
    return spec
