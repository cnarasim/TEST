# STANDARD33 - Ulta Beauty PPT Standard.pptx (33 slides)

## Slide 1
- `title`: text (1 para) - "Title"

## Slide 2
- `table`: table 5×2 - header ['1', 'Brand Guidelines']
- `text1`: text (1 para) - "Agenda"

## Slide 3 (chart - use once)
- `title`: text (1 para) - "Formatting guidelines"
- `text1`: text (1 para) - ""
- `text2`: text (1 para) - ""
- `text3`: text (3 para) - "Fiery Sunset | R233 G52 B28 | E9341C"
- `text4`: text (3 para) - "Orange Squeeze | R222 G116 B99 | DE7445"
- `text5`: text (1 para) - "Headlines"
- `text6`: text (1 para) - "Chronicle Deck Semibold 36pt"
- `text7`: text (1 para) - "Highlighted text"
- `text8`: text (1 para) - "Chronicle Deck Semibold 24pt"
- `text9`: text (1 para) - "Color wheel"
- `text10`: text (1 para) - "Sub-headline"
- `text11`: text (1 para) - "Circular Bold 18pt"
- `text12`: text (1 para) - "Body copy"
- `text13`: text (1 para) - "Circular Regular 12pt"
- `text14`: text (3 para) - "Magenta Mood | R232 G39 B90 | E8275A"
- `text15`: text (3 para) - "Berry Bliss | R93 G15 B67 | 5D0F43"

## Slide 4
- `title`: text (1 para) - "Useful tips"
- `table`: table 10×2 - header ['1.', 'Open with a RECAP of what we s']

## Slide 5
- `text1`: text (1 para) - "2"
- `text2`: text (1 para) - "Divider slides"

## Slide 6
- `title`: text (1 para) - "Insert headline"
- `text1`: text (2 para) - "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor i"
- `text2`: text (2 para) - "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor i"

## Slide 7
- `title`: text (1 para) - "Insert headline"
- `table`: table 3×3 - header ['Headline', 'Headline', 'Headline']
- `text1`: text (1 para) - ""

## Slide 8 (chart - use once)
- `title`: text (2 para) - "Insert headline"
- `text1`: text (3 para) - "Chart detail | Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla p"
- `text2`: text (1 para) - "Chart title"
- `group1.text1`: text (3 para) - "Chart detail | Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla p"

## Slide 9
- `title`: text (2 para) - "Insert headline"
- `table`: table 2×3 - header ['Headline', 'Headline', 'Headline']

## Slide 10
- `title`: text (2 para) - "Insert headline"
- `table`: table 6×3 - header ['Hypothesis', '', 'Action']
- `text1`: text (1 para) - ""
- `text2`: text (1 para) - ""
- `text3`: text (1 para) - ""
- `text4`: text (1 para) - ""
- `text5`: text (1 para) - ""

## Slide 11
- `title`: text (2 para) - "Insert headline"
- `table`: table 6×4 - header ['', 'Results', 'Learnings', 'Action']
- `text1`: text (1 para) - "XX"
- `text2`: text (1 para) - "XX"
- `text3`: text (1 para) - "XX"
- `text4`: text (1 para) - "XX"
- `text5`: text (1 para) - "XX"
- `text6`: text (1 para) - "XX"
- `text7`: text (1 para) - "XX"
- `text8`: text (1 para) - "XX"
- `text9`: text (1 para) - "XX"
- `text10`: text (1 para) - "XX"
- `text11`: text (1 para) - "XX"
- `text12`: text (1 para) - "XX"
- `text13`: text (1 para) - "XX"
- `text14`: text (1 para) - "XX"
- `text15`: text (1 para) - "XX"

## Slide 12
- `title`: text (2 para) - "Insert headline"
- `table`: table 5×3 - header ['What', 'Description', 'When / Who']

## Slide 13
- `title`: text (2 para) - "Insert headline"
- `table`: table 2×2 - header ['$XX\nLorem ipsum', '$XX\nLorem ipsum']

## Slide 14
- `title`: text (2 para) - "Insert headline"
- `table`: table 4×6 - header ['', 'Where\nChannel/ Environment', 'What\nContent/ Sentiment', 'When\nDate/ Frequency', 'Why\nPurpose/ Performance', 'Opportunity\nSub-headline']

## Slide 15
- `title`: text (2 para) - "Insert headline"
- `table`: table 2×6 - header ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN']
- `text1`: text (1 para) - "Group 1"
- `text2`: text (1 para) - "Text here"
- `text3`: text (1 para) - "Group 2"
- `text4`: text (1 para) - "Text here"
- `text5`: text (1 para) - "Group 3"
- `text6`: text (1 para) - "Text here"

## Slide 16
- `title`: text (2 para) - "Insert headline"
- `table`: table 2×7 - header ['Month', 'Month', 'Month', 'Month', 'Month', 'Month', 'Month']
- `text1`: text (1 para) - "Section 1"
- `text2`: text (1 para) - "Event description"
- `text3`: text (1 para) - "Event description"
- `text4`: text (1 para) - "Event description"
- `text5`: text (1 para) - "Event description"
- `text6`: text (1 para) - "Section 2"
- `text7`: text (1 para) - "Event description"
- `text8`: text (1 para) - "Event description"
- `text9`: text (1 para) - "Event description"
- `text10`: text (1 para) - "Event description"
- `text11`: text (1 para) - "Section 2"
- `text12`: text (1 para) - "Event description"
- `text13`: text (1 para) - "Event description"
- `text14`: text (1 para) - "Event description"
- `text15`: text (1 para) - "Event description"
- `text16`: text (1 para) - "Section 2"
- `text17`: text (1 para) - "Event description"
- `text18`: text (1 para) - "Event description"
- `text19`: text (1 para) - "Event description"
- `text20`: text (1 para) - "Event description"

## Slide 17
- `title`: text (2 para) - "Insert headline"
- `table`: table 2×7 - header ['Month', 'Month', 'Month', 'Month', 'Month', 'Month', 'Month']
- `text1`: text (1 para) - "Event"
- `text2`: text (1 para) - "Event"
- `text3`: text (1 para) - "Event"
- `text4`: text (1 para) - "Event"
- `text5`: text (1 para) - "Event"
- `text6`: text (1 para) - "YEAR"
- `text7`: text (1 para) - "YEAR"
- `text8`: text (1 para) - ""
- `text9`: text (1 para) - ""
- `text10`: text (1 para) - ""
- `text11`: text (1 para) - ""
- `text12`: text (1 para) - ""
- `text13`: text (1 para) - ""
- `text14`: text (1 para) - ""
- `text15`: text (1 para) - ""
- `text16`: text (1 para) - ""
- `text17`: text (1 para) - "Event"
- `text18`: text (1 para) - "Event"
- `text19`: text (1 para) - "Event"
- `text20`: text (1 para) - "Event"

## Slide 18
- `title`: text (2 para) - "Insert headline"
- `text1`: text (1 para) - ""
- `text2`: text (1 para) - "2023 headline"
- `text3`: text (1 para) - ""
- `text4`: text (2 para) - "Insert your text in here Insert your text in here | Insert your text in here"
- `text5`: text (1 para) - "2022 headline"
- `text6`: text (1 para) - ""
- `text7`: text (2 para) - "Insert your text in here Insert your text in here | Insert your text in here"
- `text8`: text (1 para) - "2021 headline"
- `text9`: text (2 para) - "Insert your text in here Insert your text in here | Insert your text in here"
- `text10`: text (1 para) - ""
- `text11`: text (1 para) - ""

## Slide 19
- `title`: text (1 para) - "Insert headline"
- `table`: table 2×12 - header ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
- `text1`: text (1 para) - "Group 1"
- `text2`: text (1 para) - "Event name"
- `text3`: text (1 para) - "Group 2"
- `text4`: text (1 para) - "Event name"
- `text5`: text (1 para) - "Group 3"
- `text6`: text (1 para) - "Event name"
- `group1.text1`: text (1 para) - ""
- `group1.text2`: text (3 para) - "Event detail | Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla p"
- `group2.text1`: text (1 para) - ""
- `group2.text2`: text (3 para) - "Event detail | Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nulla p"

## Slide 20
- `title`: text (2 para) - "Insert headline"
- `table`: table 1×5 - header ['Mon\nMM/DD', 'Tue\nMM/DD', 'Wed\nMM/DD', 'Thur\nMM/DD', 'Thur\nMM/DD']
- `text1`: text (1 para) - "Text here"
- `text2`: text (1 para) - "Text here"
- `text3`: text (1 para) - "Text here"
- `text4`: text (1 para) - "Text here"
- `text5`: text (1 para) - ""
- `text6`: text (1 para) - ""
- `text7`: text (1 para) - ""
- `text8`: text (1 para) - ""
- `text9`: text (1 para) - ""

## Slide 21
- `title`: text (2 para) - "Insert headline"
- `table`: table 28×8 - header ['', '', '2023 \nMP', '', '2023 \nTarget', '', '2023\nActual', '']
- `table2`: table 5×1 - header ['Text here...']
- `table3`: table 5×1 - header ['Text here...']
- `text1`: text (1 para) - "Lowlights"
- `text2`: text (1 para) - "Highlights"

## Slide 22
- `title`: text (2 para) - "Insert headline"
- `text1`: text (1 para) - "Location"
- `text2`: text (1 para) - "Text or statistics related to this location here"
- `text3`: text (1 para) - "Location"
- `text4`: text (1 para) - "Text or statistics related to this location here"
- `text5`: text (1 para) - "Location"
- `text6`: text (1 para) - "Location"
- `text7`: text (1 para) - "Text or statistics related to this location here"
- `text8`: text (1 para) - "Text or statistics related to this location here"
- `group1.text1`: text (1 para) - ""
- `group2.text1`: text (1 para) - ""
- `group3.text1`: text (1 para) - ""
- `group4.text1`: text (1 para) - ""

## Slide 23
- `text1`: text (1 para) - "4"
- `text2`: text (1 para) - "Strategy slides"

## Slide 24
- `title`: text (1 para) - "2024 Priorities"
- `table`: table 3×6 - header ['', '', '', '', '', '']
- `text1`: text (1 para) - ""
- `text2`: text (1 para) - ""
- `text3`: text (1 para) - "Vision"
- `text4`: text (2 para) - "Expand market leadership by being the industry lovemark at the | Heart of the Be"
- `text5`: text (1 para) - ""
- `text6`: text (1 para) - ""
- `text7`: text (1 para) - "GOALS"
- `text8`: text (1 para) - "STRATEGIES"
- `text9`: text (1 para) - "KPIs"
- `group1.text1`: text (1 para) - "Goal A"
- `group1.text2`: text (1 para) - "Goal B"
- `group1.text3`: text (1 para) - "Goal C"
- `group2.text1`: text (1 para) - "KPI A"
- `group2.text2`: text (1 para) - "KPI B"
- `group2.text3`: text (1 para) - "KPI C"
- `group2.text4`: text (1 para) - "KPI D"
- `group2.text5`: text (1 para) - "KPI E"
- `group2.text6`: text (1 para) - "KPI F"
- `group2.text7`: text (1 para) - "KPI G"
- `group2.text8`: text (1 para) - "KPI H"
- `group2.text9`: text (1 para) - "KPI I"
- `group2.text10`: text (1 para) - "KPI J"
- `group2.text11`: text (1 para) - "KPI K"
- `group2.text12`: text (1 para) - "KPI L"

## Slide 25
- `title`: text (1 para) - "OGSM Template"
- `table`: table 4×2 - header ['Objective', 'Insert text here']
- `table2`: table 1×2 - header ['1', 'Insert text here']
- `table3`: table 1×2 - header ['2', 'Insert text here']
- `table4`: table 1×2 - header ['3', 'Insert text here']
- `table5`: table 1×2 - header ['Title', 'XX\nInsert text here']
- `table6`: table 1×2 - header ['Title', 'XX\nInsert text here']
- `table7`: table 1×2 - header ['Title', 'XX\nInsert text here']
- `group1.text1`: text (1 para) - "1. Title"
- `group1.text2`: text (1 para) - "2. Title"
- `group1.text3`: text (1 para) - "3. Title"
- `group1.text4`: text (5 para) - "Insert text here | Lorem ipsum dolor sit amet lorem ipsum dolor sit amet"
- `group1.text5`: text (5 para) - "Insert text here | Lorem ipsum dolor sit amet lorem ipsum dolor sit amet"
- `group1.text6`: text (5 para) - "Insert text here | Lorem ipsum dolor sit amet lorem ipsum dolor sit amet"

## Slide 26
- `title`: text (1 para) - "Funnel concept"
- `text1`: text (1 para) - "Primary text…"
- `text2`: text (1 para) - "Secondary text…"
- `text3`: text (1 para) - "Primary text…"
- `text4`: text (1 para) - "Secondary text…"
- `text5`: text (1 para) - "Primary text…"
- `text6`: text (1 para) - "Secondary text…"
- `text7`: text (4 para) - "Primary | Text | …"
- `text8`: text (1 para) - "Secondary text…"

## Slide 27
- `text1`: text (1 para) - "5"
- `text2`: text (1 para) - "Icons"

## Slide 28
- `title`: text (1 para) - "Icons"
- `table`: table 4×6 - header ['', '', '', '', '', '']

## Slide 29
- `title`: text (1 para) - "Icons"
- `table`: table 4×6 - header ['', '', '', '', '', '']

## Slide 30
- `title`: text (1 para) - "Icons"
- `table`: table 4×6 - header ['', '', '', '', '', '']

## Slide 31
- `title`: text (1 para) - "Icons"
- `table`: table 4×6 - header ['', '', '', '', '', '']

## Slide 32
- `text1`: text (1 para) - "Thank you!"
- `text2`: text (1 para) - "Ulta Beauty | Proprietary & Confidential"

## Slide 33
- `text1`: text (1 para) - "Ulta Beauty | Proprietary & Confidential"

