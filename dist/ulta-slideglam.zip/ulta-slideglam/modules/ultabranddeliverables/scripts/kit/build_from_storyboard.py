#!/usr/bin/env python3
"""Deterministic PPTX builder: content JSON + approved template binary -> deck. Rule-based, no invented styling.

  build_from_storyboard.py spec.json --templates <ultatemplatelibrary/templates> --out deck.pptx
  build_from_storyboard.py --map STANDARD33 --templates <dir>            # fillable regions per slide (JSON)
  build_from_storyboard.py --map STANDARD33 --templates <dir> --markdown # same, readable

spec.json
{
  "template": "STANDARD33" | "ARB36",
  "slides": [
    {"source": 12,                       # template slide number (1-based)
     "fills": {"title": "Headline",     # 'title' = headline placeholder
               "text1": "para 1\\npara 2" | ["para 1", "para 2"],   # text shapes in reading order
               "table": [["What","Description","When / Who"], ["...","...","..."]],  # tables: 'table', 'table2'…
               "group1.text1": "..." },  # text inside a group, reading order
     "notes": "Sources: https://…",      # speaker notes (optional)
     "keep_unfilled": ["text3"],         # text keys to leave as in the template (default: cleared)
     "trim_empty_rows": true,            # optional: delete unused trailing table rows (default: keep, cleared)
     "fit_headline": true }              # default on: a 3+ line headline pushes the content below it down
  ]
}
Rules enforced: source slides are copied whole (shape tree, media, masters, layouts, theme); text replaces runs in
place keeping the run's font/size; tables never gain rows/columns (too many rows -> error: split the slide);
unfilled sample text is cleared, never left behind; unused template slides are removed; output order = spec order.
"""
import argparse, copy, hashlib, json, os, re, sys
from pptx import Presentation
from pptx.util import Emu
from lxml import etree
etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)

NS = {'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
WARN = []
R_ATTRS = ['{%s}id' % NS['r'], '{%s}embed' % NS['r'], '{%s}link' % NS['r'], '{%s}pict' % NS['r']]


# ----------------------------------------------------------------------------- template map
def is_title_ph(sh):
    if not getattr(sh, 'is_placeholder', False):
        return False
    t = sh.placeholder_format.type
    return str(t).startswith(('TITLE', 'CENTER_TITLE', 'BODY'))


def order_key(sh):
    return ((sh.top or 0) // 200000, sh.left or 0)  # row bands of ~0.2 in, then left→right


def text_shapes(container):
    """Yield (key, shape) for text-bearing shapes in reading order; recurse into groups with 'groupN.' prefix."""
    plain, groups = [], []
    for sh in container.shapes:
        if sh.shape_type is not None and 'GROUP' in str(sh.shape_type):
            groups.append(sh)
        elif sh.has_text_frame and not is_title_ph(sh):
            plain.append(sh)
    plain.sort(key=order_key); groups.sort(key=order_key)
    for i, sh in enumerate(plain, 1):
        yield f'text{i}', sh
    for g, grp in enumerate(groups, 1):
        inner = [s for s in grp.shapes if s.has_text_frame]
        inner.sort(key=order_key)
        for i, sh in enumerate(inner, 1):
            yield f'group{g}.text{i}', sh


def slide_regions(slide):
    reg = {}
    titles = [sh for sh in slide.shapes if is_title_ph(sh)]
    if titles:
        reg['title'] = titles[0]
    tables = sorted([sh for sh in slide.shapes if sh.has_table], key=order_key)
    for i, sh in enumerate(tables, 1):
        reg['table' if i == 1 else f'table{i}'] = sh
    for k, sh in text_shapes(slide):
        reg[k] = sh
    return reg


def describe(prs):
    out = []
    for n, slide in enumerate(prs.slides, 1):
        d = {'source': n, 'regions': {}}
        for k, sh in slide_regions(slide).items():
            if sh.has_table:
                t = sh.table
                d['regions'][k] = {'kind': 'table', 'rows': len(t.rows), 'cols': len(t.columns),
                                   'sample': [[t.cell(r, c).text.strip()[:30] for c in range(len(t.columns))] for r in range(min(2, len(t.rows)))]}
            else:
                paras = [p.text.strip() for p in sh.text_frame.paragraphs if p.text.strip()]
                d['regions'][k] = {'kind': 'text', 'paragraphs': len(sh.text_frame.paragraphs), 'sample': ' | '.join(paras)[:80]}
        d['has_chart'] = any('CHART' in str(sh.shape_type) for sh in slide.shapes)
        out.append(d)
    return out


# ----------------------------------------------------------------------------- text fill
def first_run_rpr(tf):
    r0 = tf._txBody.find('a:p/a:r/a:rPr', NS)
    return copy.deepcopy(r0) if r0 is not None else None


HEAD = '## '   # paragraph marker: render this line in the box's heading style (see set_paragraphs)


HEADING_STYLE = 'bar'   # bar | underline | color | bold  (manifest "heading_style", spec "heading_style")
ACCENT = 'EE6C37'      # current slide accent (hex) used by the heading bar


BULLET_GREY = '404040'
def style_paragraph(p_el, mark, spc, airy, is_head, first):
    """The text-box look: a small accent-coloured dot (or a grey dash for a sub-point) as a real bullet with a hanging indent instead
    of a '•' character in the text, air between paragraphs that scales with how much the box holds, a breath before a sub-heading."""
    ppr = p_el.find('a:pPr', NS)
    if ppr is None: ppr = p_el.makeelement('{%s}pPr' % NS['a'], {}); p_el.insert(0, ppr)
    for c in list(ppr):
        if etree.QName(c).localname in ('lnSpc', 'spcBef', 'spcAft', 'buClrTx', 'buClr', 'buSzTx', 'buSzPct', 'buSzPts', 'buFontTx', 'buFont', 'buNone', 'buAutoNum', 'buChar', 'buBlip'): ppr.remove(c)
    A = '{%s}' % NS['a']; new = []
    if airy:
        e = etree.Element(A + 'lnSpc'); etree.SubElement(e, A + 'spcPct', val='110000'); new.append(e)
    if is_head and not first and spc:
        e = etree.Element(A + 'spcBef'); etree.SubElement(e, A + 'spcPts', val=str(min(900, spc * 100))); new.append(e)
    e = etree.Element(A + 'spcAft'); etree.SubElement(e, A + 'spcPts', val=str(spc * 100)); new.append(e)
    if mark:
        e = etree.Element(A + 'buClr'); etree.SubElement(e, A + 'srgbClr', val=ACCENT if mark == '•' else BULLET_GREY); new.append(e)
        e = etree.Element(A + 'buSzPct', val='85000' if mark == '•' else '100000'); new.append(e)
        e = etree.Element(A + 'buFont', typeface='Arial'); new.append(e)
        e = etree.Element(A + 'buChar', char=mark); new.append(e)
        ppr.set('marL', '228600' if mark == '•' else '457200'); ppr.set('indent', '-228600')
    for k, e in enumerate(new): ppr.insert(k, e)


def set_paragraphs(tf, value, fallback_rpr=None):
    paras = [value] if isinstance(value, str) else list(value)
    paras = [p for chunk in paras for p in str(chunk).split('\n')]
    txBody = tf._txBody
    existing = txBody.findall('a:p', NS)
    if not existing:
        return
    template_p = existing[-1]
    heads = set()
    if any(p.startswith(HEAD) for p in paras):
        # marked heading lines ("## text") take the template's first-paragraph (bold heading) style, everything
        # else the last-paragraph (body) style, so several sub-sections can share one box
        head_p, body_p = existing[0], existing[-1] if len(existing) > 1 else existing[0]
        for p_el in existing:
            txBody.remove(p_el)
        existing = []
        for text in paras:
            new_p = copy.deepcopy(head_p if text.startswith(HEAD) else body_p)
            txBody.append(new_p); existing.append(new_p)
        heads = {i for i, p in enumerate(paras) if p.startswith(HEAD)}
        paras = [p[len(HEAD):] if p.startswith(HEAD) else p for p in paras]
        template_p = existing[-1]
    ref_rpr = None  # first real run style in this text frame: reused for paragraphs that have no run
    for p_el in existing:
        r0 = p_el.find('a:r/a:rPr', NS)
        if r0 is not None:
            ref_rpr = copy.deepcopy(r0); break
    if ref_rpr is None and fallback_rpr is not None:
        ref_rpr = copy.deepcopy(fallback_rpr)
    # make sure we have exactly len(paras) paragraphs, cloning the last one's formatting when short
    while len(existing) < len(paras):
        new_p = copy.deepcopy(template_p); txBody.append(new_p); existing.append(new_p)
    for p_el in existing[len(paras):]:
        txBody.remove(p_el)
    existing = existing[:len(paras)]
    n_lines = len([p for p in paras if p.strip()])
    # spacing the box can afford: the wish (12 / 9 / 6 / 3 pt after a paragraph for boxes of ≤4 / ≤6 / ≤8 / more lines) is cut back
    # when the estimated wrapped text already fills the shape - a small placeholder (the ARB cover) keeps the template's tight look
    spc = 12 if n_lines <= 4 else 9 if n_lines <= 6 else 6 if n_lines <= 8 else 3; airy = n_lines <= 6
    try:
        shp = tf._parent; w_pt = shp.width / 12700 - 20; h_pt = shp.height / 12700
        sz = ref_rpr.get('sz') if ref_rpr is not None else None; size = int(sz) / 100 if sz else 14.0
        est = sum(max(1, -(-len(p) * size * 0.5 // max(1, w_pt))) for p in paras if p.strip())
        room = h_pt - est * size * 1.2 - 14
        if airy and room < est * size * 0.12: airy = False
        if n_lines and spc * n_lines > room * 0.8: spc = max(0, int(room * 0.8 / n_lines)) // 3 * 3
    except Exception:   # noqa: BLE001 - no shape geometry (a bare text frame): keep the wish
        pass
    for idx, (p_el, text) in enumerate(zip(existing, paras)):
        runs = p_el.findall('a:r', NS)
        if not runs and not text.strip():
            continue  # blank-by-design paragraph stays without a run
        for extra in p_el.findall('a:br', NS) + p_el.findall('a:fld', NS):
            p_el.remove(extra)
        if runs:
            keep = runs[0]
            for r_el in runs[1:]:
                p_el.remove(r_el)
        else:
            keep = p_el.makeelement('{%s}r' % NS['a'], {})
            rpr = p_el.find('a:endParaRPr', NS)
            if ref_rpr is not None:
                keep.append(copy.deepcopy(ref_rpr))
            elif rpr is not None:
                new_rpr = copy.deepcopy(rpr); new_rpr.tag = '{%s}rPr' % NS['a']; keep.append(new_rpr)
            endp = p_el.find('a:endParaRPr', NS)
            if endp is not None:
                endp.addprevious(keep)
            else:
                p_el.append(keep)
        mark = None
        if text[:2] in ('• ', '– ', '◦ ', '▪ '): mark, text = ('–' if text[0] in '–◦' else '•'), text[2:]   # the glyph becomes a real bullet (dot / dash)
        style_paragraph(p_el, mark, spc, airy, idx in heads, idx == 0)
        t_el = keep.find('a:t', NS)
        if t_el is None:
            t_el = keep.makeelement('{%s}t' % NS['a'], {}); keep.append(t_el)
        if text[:2] in ('✓ ', '→ '):                    # check / arrow glyphs take the section accent, as in the HTML deck
            text = '{#%s}%s{/} %s' % (ACCENT, text[0], text[2:])
        segs = parse_inline(text)
        t_el.text = segs[0][0] if segs else ''
        if len(segs) > 1 or (segs and segs[0][1]):
            base = copy.deepcopy(keep); anchor = keep
            for n, (seg, fmt) in enumerate(segs):
                r_el = keep if n == 0 else copy.deepcopy(base)
                if n: anchor.addnext(r_el); anchor = r_el
                r_el.find('a:t', NS).text = seg
                rpr = r_el.find('a:rPr', NS)
                if rpr is None:
                    rpr = r_el.makeelement('{%s}rPr' % NS['a'], {}); r_el.insert(0, rpr)
                if fmt.get('b'): rpr.set('b', '1')
                if fmt.get('i'): rpr.set('i', '1')
                if fmt.get('color'):
                    for old_fill in rpr.findall('a:solidFill', NS): rpr.remove(old_fill)
                    fill = etree.SubElement(rpr, '{%s}solidFill' % NS['a']); etree.SubElement(fill, '{%s}srgbClr' % NS['a'], val=fmt['color'])
                    ln = rpr.find('a:ln', NS)   # keep schema order: ln, fill, effects, … : move solidFill right after ln (or first)
                    rpr.remove(fill); (ln.addnext(fill) if ln is not None else rpr.insert(0, fill))
        if idx in heads:                      # heading line inside a box: bold, whatever the template paragraph was
            rpr = keep.find('a:rPr', NS)
            if rpr is None:
                rpr = keep.makeelement('{%s}rPr' % NS['a'], {}); keep.insert(0, rpr)
            rpr.set('b', '1')
            for tag in ('latin', 'cs'):           # the template's bold style = b=1 + the Medium face of the same family
                f = rpr.find(f'a:{tag}', NS)
                if f is not None and f.get('typeface', '').endswith(' Book'):
                    f.set('typeface', f.get('typeface')[:-5] + ' Medium')
            style_heading(p_el, keep, rpr)
    if not paras:
        for p_el in existing:
            for r_el in p_el.findall('a:r', NS): p_el.remove(r_el)


def headline_lines(text, width_emu, size_pt=36.0, glyph=0.55):
    """Rough wrapped-line estimate for the headline placeholder (Chronicle Deck ~0.55em average glyph width;
    pass glyph=0.64 to model the wider substitute fonts on machines without Chronicle)."""
    chars_per_line = max(8, int((width_emu / 9525) / (size_pt * 1.333 * glyph)))  # px width / avg glyph px; calibrated on Chronicle Deck Semibold renders
    lines = 0
    for para in str(text).split('\n'):
        words = para.split(); cur = 0; n = 1 if words else 0
        for w in words:
            if cur and cur + 1 + len(w) > chars_per_line:
                n += 1; cur = len(w)
            else:
                cur += (1 if cur else 0) + len(w)
        lines += n
    return lines


def layout_steps(slide, regions, fills, where, warnings):
    """Process-steps slide (template role steps4): re-grid the day-columns table to one column per used step and centre
    each step's box, connector and dot on its column; delete the boxes of unused steps."""
    tbl_sh = regions.get('table')
    boxes = [regions[k] for k in ('text1', 'text2', 'text3', 'text4') if k in regions]
    if tbl_sh is None or len(boxes) < 3: return
    used = [k for k in ('text1', 'text2', 'text3', 'text4') if k in fills and str(fills[k]).strip()]
    n = len(used)
    if n < 2: return
    tbl = tbl_sh.table; total = sum(c.width for c in tbl.columns)
    # Unused step columns are REMOVED, not squeezed: PowerPoint enforces a minimum column width, so hairline columns were widened
    # on open and pushed the used ones narrower than the boxes above them ("columns getting shrunk in the actual ppt").
    if len(tbl.columns) > n: trim_cols(tbl_sh, n)
    colw = total // n
    for c in tbl.columns: c.width = colw
    tbl.columns[n - 1].width += total - colw * n
    tbl_sh.width = total
    centers = [tbl_sh.left + colw * i + colw // 2 for i in range(n)]
    tol = 457200   # 0.5 in: shapes whose centre sits under a box belong to that step (connector line, dot)
    for i, key in enumerate(('text1', 'text2', 'text3', 'text4')):
        if key not in regions: continue
        box = regions[key]; bc = box.left + box.width // 2
        group = [sh for sh in slide.shapes if sh.shape_id != tbl_sh.shape_id and sh.width is not None and sh.width < colw
                 and abs((sh.left + sh.width // 2) - bc) < tol]
        if i < n:
            new_w = min(box.width, colw - 228600)   # leave 0.25 in of band on each side
            for sh in group:
                if sh.shape_id == box.shape_id:
                    sh.width = new_w; sh.left = centers[i] - new_w // 2
                else:
                    sh.left = centers[i] - sh.width // 2
        else:
            for sh in group: sh._element.getparent().remove(sh._element)
            regions.pop(key, None)
    title = regions.get('title')
    if title is not None and headline_lines(fills.get('title', ''), title.width or 0, glyph=0.64) >= 2:
        # this layout starts higher than the others (the step bands begin under the title): one full-width line at 28–32 pt first …
        from pptx.util import Pt
        txt = fills.get('title', ''); sw_ = slide.part.package.presentation_part.presentation.slide_width; max_w = min(Inches(11.9), sw_ - title.left - Inches(0.8))
        one = next((sz for sz in (32, 30, 28) if headline_lines(txt, int(max_w), float(sz), glyph=0.64) <= 1), None)
        if one:
            l_, t_, h_ = title.left, title.top, title.height; title.left, title.top, title.height, title.width = l_, t_, h_, int(max_w)
            for para in title.text_frame.paragraphs:
                for r in para.runs: r.font.size = Pt(one)
            warnings.append(f'{where}: headline set to one line at {one} pt so it clears the step bands')
        else:   # … else the bands move down below the two lines (measured with the line height of the display face, not the box)
            sz = next((r.font.size.pt for p in title.text_frame.paragraphs for r in p.runs if r.font.size), 36.0)
            bottom = title.top + int(2 * sz * 1.12 * 12700) + Inches(0.06)   # two display-face lines (≈ 1.1 × size each) and a hair of air: the takeaway line still fits above the bands
            if tbl_sh.top < bottom:
                dy = bottom - tbl_sh.top
                for sh in slide.shapes:
                    if sh.shape_id != title.shape_id and sh.top is not None and sh.top >= tbl_sh.top - 91440: sh.top = Emu(sh.top + dy)
    # each step's description: the whole sentence, stepped down (12 → 9 pt) until it fits between the band top and the box
    boxes_top = min((regions[k].top for k in ('text1', 'text2', 'text3', 'text4') if k in regions), default=None)
    if boxes_top is not None:
        from pptx.util import Pt
        avail = (boxes_top - tbl_sh.top) / 12700 - 10   # pt
        for c in tbl_sh.table.rows[0].cells:
            paras = c.text_frame.paragraphs
            if len(paras) < 2: continue
            desc = ' '.join(p.text for p in paras[1:]).strip(); head_pt = next((r.font.size.pt for r in paras[0].runs if r.font.size), 16.0)
            if not desc: continue
            colw_pt = (tbl_sh.table.columns[0].width / 12700) - 14
            def h_at(sz):
                cpl = max(8, int(colw_pt / (sz * 0.5))); n_, cur = 1, 0
                for w_ in desc.split():
                    if cur and cur + 1 + len(w_) > cpl: n_ += 1; cur = len(w_)
                    else: cur += (1 if cur else 0) + len(w_)
                return head_pt * 1.25 + n_ * sz * 1.2 + 8
            size = next((s for s in (12, 11) if h_at(s) <= avail), None)
            if size is None:   # the boxes have room to spare: their tops come down (bottoms stay on the connectors) so the sentence keeps 11–12 pt
                need = min(h_at(11) - avail, 0.6 * 72)
                if need > 0:
                    e = int(need * 12700)
                    for k in ('text1', 'text2', 'text3', 'text4'):
                        if k in regions and regions[k].height > e + Inches(1.2): regions[k].top = regions[k].top + e; regions[k].height = regions[k].height - e
                    avail += need
                size = next((s for s in (12, 11, 10, 9) if h_at(s) <= avail), 9)
            for p in paras[1:]:
                for r in p.runs: r.font.size = Pt(size)
    if n < 4: warnings.append(f'{where}: process slide re-gridded to {n} steps')


def fit_table(sh, slide_h, warnings, where, floor_pt=9.0, grow=False):
    """PowerPoint grows rows to fit wrapped text; when the estimated height would run past the footer band, step the
    body text down (12 → 9 pt). Estimate = wrapped lines per cell × line pitch, per row the tallest cell."""
    from pptx.util import Emu
    tbl = sh.table; limit = int(slide_h * 0.86) - sh.top          # keep clear of the logo/footer band
    def est(scale):
        total = 0
        for r_i, row in enumerate(tbl.rows):
            tallest = row.height if r_i == 0 else 0
            for c_i, cell in enumerate(row.cells):
                if cell.is_spanned: continue
                txt = cell.text.strip()
                if not txt: continue
                size = None
                for para in cell.text_frame.paragraphs:
                    for run in para.runs:
                        if run.font.size: size = run.font.size.pt; break
                    if size: break
                size = (size or 12.0) * scale
                cpl = max(6, int((tbl.columns[c_i].width - 182880) / 9525 / (size * 1.333 * 0.5)))
                lines = 0
                for para in txt.split('\n'):
                    n = 1; cur = 0
                    for w in para.split():
                        if cur and cur + 1 + len(w) > cpl: n += 1; cur = len(w)
                        else: cur += (1 if cur else 0) + len(w)
                    lines += n
                tallest = max(tallest, int(lines * size * 1.25 * 12700) + 182880)
            total += tallest
        return total
    def apply(scale):
        sizes = set()
        for r_i, row in enumerate(tbl.rows):
            if r_i == 0: continue
            for cell in row.cells:
                if cell.is_spanned: continue
                for para in cell.text_frame.paragraphs:
                    for run in para.runs:
                        base = run.font.size.pt if run.font.size else 12.0
                        new = max(floor_pt, min(16.0, round(base * scale, 1))); run.font.size = Pt(new); sizes.add(new)
        return sorted(sizes)
    if est(1.0) <= limit:
        if grow:                                   # columns were removed and the rest widened: small template text can grow into the room
            for scale in (1.5, 1.35, 1.2):
                if est(scale) <= int(limit * 0.9):
                    apply(scale); return
        return
    for scale in (11 / 12, 10 / 12, 9 / 12):
        if est(scale) <= limit or scale == 9 / 12:
            sizes = apply(scale)
            warnings.append(f'{where}: table text set to {sizes[0]:g} pt so the rows stay above the footer' + ('' if est(scale) <= limit else ' - still tight, consider splitting the table'))
            return


def _run_pt(cell, default=12.0):
    for rpr in cell._tc.iter(qn_a('rPr')):
        if rpr.get('sz'): return int(rpr.get('sz')) / 100
    return default


def _word_in(word, pt, bold=False, serif=False):
    """Estimated width of one word (inches): ~0.55 em a character, wider for bold and for the display serif."""
    return len(word) * pt / 72 * (0.62 if serif else 0.58 if bold else 0.53)


def agenda_rows_alike(sh):
    """The template's agenda highlights its first row (20 pt bold) as the section in progress; a generated agenda lists
    every section alike, so row 1 takes row 2's look."""
    import copy
    t = sh.table
    if len(t.rows) < 2: return
    for c in range(len(t.columns)):
        donor = next(iter(t.cell(1, c)._tc.iter(qn_a('rPr'))), None)
        if donor is None: continue
        for r in t.cell(0, c)._tc.iter(qn_a('r')):
            old = r.find(qn_a('rPr'))
            if old is not None: r.remove(old)
            r.insert(0, copy.deepcopy(donor))


def tidy_table(sh):
    """A header row reads as a header: its labels sit in the middle of the row and are never smaller than the body text.
    A label column is wide enough that no word breaks ("connectivi-ty"); the other columns give up the width."""
    t = sh.table; ncol = len(t.columns)
    body = [_run_pt(c, 0) for r in list(t.rows)[1:] for c in r.cells if not c.is_spanned and c.text.strip()]
    body = sorted(p for p in body if p)
    mid = body[len(body) // 2] if body else 0
    for c in range(ncol):
        cell = t.cell(0, c)
        if cell.is_spanned: continue
        tcPr = cell._tc.get_or_add_tcPr()
        if tcPr.get('anchor') is None: tcPr.set('anchor', 'ctr')
        if mid:
            for rpr in cell._tc.iter(qn_a('rPr')):
                if rpr.get('sz') and int(rpr.get('sz')) < mid * 100: rpr.set('sz', str(int(min(mid, 16) * 100)))
    if ncol < 2: return
    # card headers in the display serif (Option 1 / Option 2 / End-to-End Architecture): one size for all, small enough that each
    # stays on one line (down to 18 pt) - never one header wrapping at 24 pt beside two that do not
    hdr = [(k, t.cell(0, k)) for k in range(ncol) if not t.cell(0, k).is_spanned and t.cell(0, k).text.strip()]
    serif_ = lambda c: any('Playfair' in ((r.find(qn_a('latin')).get('typeface') or '') if r.find(qn_a('latin')) is not None else '') for r in c._tc.iter(qn_a('rPr')))
    if len(hdr) >= 2 and all(serif_(c) for _, c in hdr):
        def one_line(c, k, p):
            tp = c._tc.tcPr; ml = int(tp.get('marL') or 91440) if tp is not None else 91440; mr = int(tp.get('marR') or 91440) if tp is not None else 91440
            avail = (t.columns[k].width - ml - mr) / 914400; ws = c.text.split()
            return sum(_word_in(w, p, True, True) for w in ws) + (len(ws) - 1) * p * 0.28 / 72 <= avail
        p0 = max(_run_pt(c, 24.0) for _, c in hdr)
        if not all(one_line(c, k, p0) for k, c in hdr):
            p1 = next((p for p in range(int(p0) - 1, 17, -1) if all(one_line(c, k, p) for k, c in hdr)), None)
            if p1:
                for _, c in hdr:
                    for rpr in c._tc.iter(qn_a('rPr')): rpr.set('sz', str(p1 * 100))
    need = 0
    for r in list(t.rows)[1:]:
        cell = r.cells[0]
        if cell.is_spanned or not cell.text.strip(): continue
        pt = _run_pt(cell); rpr = next(iter(cell._tc.iter(qn_a('rPr'))), None)
        bold = rpr is not None and rpr.get('b') == '1'; latin = rpr.find(qn_a('latin')) if rpr is not None else None
        serif = latin is not None and 'Playfair' in (latin.get('typeface') or '')
        need = max(need, max(_word_in(w, pt, bold, serif) for w in cell.text.split()) + 0.25)
    w0 = t.columns[0].width / 914400; total = sum(c.width for c in t.columns) / 914400
    if need > w0:
        new = min(need, 0.3 * total)
        if new > w0:
            rest = [c.width for c in list(t.columns)[1:]]; take = int((new - w0) * 914400)
            t.columns[0].width = int(new * 914400)
            for k, c in enumerate(list(t.columns)[1:]): c.width = rest[k] - take * rest[k] // sum(rest)
        w0 = t.columns[0].width / 914400
        for r in list(t.rows)[1:]:   # still too narrow (a very long word): the label steps down until its words fit
            cell = r.cells[0]
            words = cell.text.split()
            if not words: continue
            pt = _run_pt(cell)
            while pt > 10 and max(_word_in(w, pt, True) for w in words) + 0.25 > w0: pt -= 1
            for rpr in cell._tc.iter(qn_a('rPr')): rpr.set('sz', str(int(pt * 100)))


def trim_cols(sh, keep):
    """Remove table columns beyond `keep` (XML: gridCol + each row's tc) and spread the freed width over the rest
    (first column keeps its share, the others grow)."""
    tbl = sh.table; ncol = len(tbl.columns)
    if keep >= ncol or keep < 1: return
    total = sum(c.width for c in tbl.columns)
    grid = tbl._tbl.tblGrid
    for gc in list(grid.findall(qn_a('gridCol')))[keep:]: grid.remove(gc)
    for tr in tbl._tbl.tr_lst:
        for tc in list(tr.tc_lst)[keep:]: tr.remove(tc)
    widths = [c.width for c in tbl.columns]; freed = total - sum(widths)
    if keep == 1: tbl.columns[0].width = total
    else:                                     # the label column keeps its share; the freed width is split evenly over the others
        share = freed // (keep - 1)
        for i, c in enumerate(tbl.columns):
            c.width = widths[i] + (share if i > 0 else 0)
        tbl.columns[keep - 1].width += total - sum(c.width for c in tbl.columns)
    sh.width = total


def qn_a(tag):
    return '{%s}%s' % (NS['a'], tag)


def no_orphan_heading(fills):
    """A two-column pair (text1/text2) must not end a box with a heading line: move it to the top of the next box."""
    a, b = fills.get('text1'), fills.get('text2')
    if not (isinstance(a, list) and isinstance(b, list)): return fills
    while a and str(a[-1]).strip() == '': a.pop()
    if a and str(a[-1]).startswith(HEAD):
        head = a.pop()
        while a and str(a[-1]).strip() == '': a.pop()
        b = [x for x in b if not (len(b) == 1 and str(x).strip() == '')]
        fills['text2'] = [head] + b; fills['text1'] = a or ['']
    return fills


def write_notes(slide, text):
    """Speaker notes at a readable size (the template's notes placeholder inherits a tiny size), one paragraph per
    ' - ' section (Source / section / not on slide / full text) with a bold lead-in."""
    from pptx.util import Pt
    tf = slide.notes_slide.notes_text_frame; tf.clear()
    parts = [p.strip() for p in re.split(r'\s+[\u2014-]\s+(?=(?:Source|section|not on slide|full text|table)\b)', str(text)) if p.strip()]
    if not parts: parts = [str(text)]
    for i, part in enumerate(parts):
        para = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
        m = re.match(r'^(Source|section|not on slide|full text|table):\s*(.*)$', part, re.S | re.I)
        if m:
            r = para.add_run(); r.text = m.group(1).capitalize() + ': '; r.font.bold = True; r.font.size = Pt(12)
            r2 = para.add_run(); r2.text = m.group(2); r2.font.size = Pt(12)
        else:
            r = para.add_run(); r.text = part; r.font.size = Pt(12)
        para.space_after = Pt(6)


def style_heading(p_el, run, rpr):
    """Accent for a heading line inside a box, per HEADING_STYLE: an orange vertical bar (a coloured ▍ run in front),
    an underline, berry-coloured text, or plain bold."""
    style = HEADING_STYLE
    if style == 'underline':
        rpr.set('u', 'sng')
    elif style == 'color':
        for old_fill in rpr.findall('a:solidFill', NS): rpr.remove(old_fill)
        fill = etree.Element('{%s}solidFill' % NS['a']); etree.SubElement(fill, '{%s}srgbClr' % NS['a'], val=PALETTE['berry'])
        ln = rpr.find('a:ln', NS); (ln.addnext(fill) if ln is not None else rpr.insert(0, fill))
    elif style == 'bar':
        rpr.set('cap', 'all'); rpr.set('spc', '150')            # label look: ALL CAPS with tracking, a step smaller than body
        if rpr.get('sz'): rpr.set('sz', str(max(900, int(rpr.get('sz')) - 200)))
        bar = copy.deepcopy(run); brpr = bar.find('a:rPr', NS)
        for old_fill in brpr.findall('a:solidFill', NS): brpr.remove(old_fill)
        fill = etree.Element('{%s}solidFill' % NS['a']); etree.SubElement(fill, '{%s}srgbClr' % NS['a'], val=ACCENT)
        ln = brpr.find('a:ln', NS); (ln.addnext(fill) if ln is not None else brpr.insert(0, fill))
        bar.find('a:t', NS).text = '\u258d '
        run.addprevious(bar)


def fit_cover_title(sh, text, warnings, where):
    """The cover title inherits ~54 pt from the layout and wraps at ~14 chars: long titles run into the footer.
    Step the size down (48/44/40/36) until the estimate is <= 3 lines; below that, warn."""
    from pptx.util import Pt
    if headline_lines(text, sh.width, 54.0) <= 3:
        return
    for size in (48, 44, 40, 36):
        n = headline_lines(text, sh.width, float(size))
        if n <= 3 or (n == 4 and size <= 44):   # 4 lines still clear the footer at <= 44 pt
            for para in sh.text_frame.paragraphs:
                for r in para.runs: r.font.size = Pt(size)
            return
    warnings.append(f'{where}: cover title is {len(text)} chars and needs more than 3 lines even at 36 pt - shorten it')


def fit_divider_name(sh, text, warnings, where):
    """Divider section name: the layout's ~54 pt wraps at ~24 chars in a 2-line box; step down (44/36/32) until it fits."""
    from pptx.util import Pt
    size0 = next((r.font.size.pt for p in sh.text_frame.paragraphs for r in p.runs if r.font.size), 54.0)
    if headline_lines(text, sh.width or 0, size0) <= 2:
        return
    for size in (44, 36, 32):
        if headline_lines(text, sh.width or 0, float(size)) <= 2:
            for para in sh.text_frame.paragraphs:
                for r in para.runs: r.font.size = Pt(size)
            warnings.append(f'{where}: section name is {len(text)} chars - set to {size} pt so it stays on 2 lines')
            return
    for size in (32, 28):                      # three lines: grow the box upward so the text stays centred on the slide
        n = headline_lines(text, sh.width or 0, float(size))
        if n <= 3:
            for para in sh.text_frame.paragraphs:
                for r in para.runs: r.font.size = Pt(size)
            need = int(n * size * 1.25 * 12700) + 182880
            if need > sh.height:
                sh.top = Emu(max(914400, sh.top - (need - sh.height) // 2)); sh.height = Emu(need)
            warnings.append(f'{where}: section name is {len(text)} chars - set to {size} pt on 3 lines')
            return
    warnings.append(f'{where}: section name is {len(text)} chars and needs more than 3 lines even at 28 pt - shorten it')


HEADLINE_SIZES = (34, 32, 30, 28, 26, 24, 22, 20)   # v6.12: a slide headline is one line - smaller type before a second line (20 pt floor)


def fit_headline(slide, title_shape, text, warnings, where):
    """v6.12: one line. Widen the headline box (nothing sits to its right, up to ~11.9 in), then step the type down to 20 pt - measured with
    the wider substitute face, so it holds on any machine. Only a headline too long even at 20 pt (≈ 100+ characters) takes two lines,
    with a warning to shorten it; past two lines the content below moves down, as before."""
    from pptx.util import Pt
    one = lambda w, size=36.0: headline_lines(text, w, size, glyph=0.64) <= 1
    def set_size(size):
        for para in title_shape.text_frame.paragraphs:
            for r in para.runs: r.font.size = Pt(size)
    w0 = int(title_shape.width or 0)
    if one(w0): return
    sw = slide.part.package.presentation_part.presentation.slide_width
    if not sw: return
    max_w = int(min(Inches(11.9), sw - title_shape.left - Inches(0.8)))
    def set_w(w):   # a placeholder inherits its box from the layout: writing only the width would leave height 0 - pin all four
        l, t_, hh = title_shape.left, title_shape.top, title_shape.height
        title_shape.left, title_shape.top, title_shape.height, title_shape.width = l, t_, hh, int(w)
    for w in range(w0 + int(Inches(0.5)), max_w + 1, int(Inches(0.5))):
        if one(w): set_w(w); warnings.append(f'{where}: headline box widened to {w / 914400:.1f} in so the title stays on one line'); return
    set_w(max_w)
    for size in HEADLINE_SIZES:
        if one(max_w, float(size)):
            set_size(size); warnings.append(f'{where}: headline set to {size} pt so it stays on one line'); return
    n = headline_lines(text, max_w, 24.0, glyph=0.64)
    if n <= 2:
        set_size(24); warnings.append(f'{where}: headline is {len(text)} characters - on two lines even at 24 pt; shorten it to one line'); return
    set_size(24); warnings.append(f'{where}: headline is {len(text)} characters - shorten it')
    delta = int((n - 2) * 48 * 9525)  # ~48 px per extra line at 36 pt
    bottom_limit = 618 * 9525           # keep clear of the logo/footer band (starts ~625 px)
    movable = [sh for sh in slide.shapes if sh.shape_id != title_shape.shape_id and sh.top is not None and sh.top > title_shape.top and sh.height]
    if not movable:
        return
    if max(sh.top + sh.height for sh in movable) + delta > bottom_limit:
        warnings.append(f'{where}: headline needs {n} lines; shorten it (no room to shift content down)')
        return
    for sh in movable:
        sh.top = Emu(sh.top + delta)
    warnings.append(f'{where}: headline is {n} lines - content shifted down {int(delta / 9525)} px (fit_headline)')


def clear_text(tf):
    """Empty every run but keep paragraph/run properties and geometry (the 'cleared slot' pattern)."""
    for p_el in tf._txBody.findall('a:p', NS):
        runs = p_el.findall('a:r', NS)
        for r_el in runs[1:]:
            p_el.remove(r_el)
        if runs:
            t = runs[0].find('a:t', NS)
            if t is not None: t.text = ''


def trim_rows(sh, keep):
    """Delete trailing table rows beyond `keep` (opt-in: changes table height, never the grid widths)."""
    tbl = sh.table._tbl
    trs = tbl.findall('a:tr', NS)
    removed_h = 0
    for tr in trs[keep:]:
        removed_h += int(tr.get('h', '0')); tbl.remove(tr)
    if removed_h and sh.height:
        sh.height = Emu(sh.height - removed_h)


def drop_header_icons(slide, table_shape):
    """Remove picture shapes sitting on the table's header row (slide 12 carries What/Description/When icons)."""
    top, h0 = table_shape.top, table_shape.table.rows[0].height
    for sh in list(slide.shapes):
        if sh.shape_type == 13 and sh.top is not None and top <= sh.top + sh.height // 2 <= top + h0 \
                and table_shape.left <= sh.left <= table_shape.left + table_shape.width:
            sh._element.getparent().remove(sh._element)


def grow_rows(sh, n, header=True):
    """Add rows by cloning the body rows (agenda with more than 5 sections, a longer table); the table keeps its overall height.
    A header row keeps its own height - spreading it evenly left a tall header with its labels stuck at the top."""
    import copy
    t = sh.table; tbl = t._tbl; total = sum(r.height for r in t.rows); body = list(tbl.tr_lst[1:]); h0 = t.rows[0].height
    while len(t.rows) < n:
        tbl.append(copy.deepcopy(body[(len(t.rows) - 1) % len(body)]))   # cycle the body rows so the banding / label colours continue
    if header and len(t.rows) > 1:
        each = int((total - h0) / (len(t.rows) - 1))
        for r in list(t.rows)[1:]: r.height = each
    else:
        each = int(total / len(t.rows))
        for r in t.rows: r.height = each


def fill_table(sh, rows, where):
    t = sh.table
    nr, nc = len(t.rows), len(t.columns)
    if len(rows) > nr:
        raise SystemExit(f'{where}: table has {nr} rows in the template but {len(rows)} were supplied - split into a continuation slide; rows are never added.')
    def neighbour_rpr(r, c):
        # style donor for a cell that has no run of its own: same row, then same column, then anywhere
        for rr, cc in [(r, k) for k in range(nc)] + [(k, c) for k in range(nr)] + [(i, j) for i in range(nr) for j in range(nc)]:
            cell = t.cell(rr, cc)
            if not cell.is_spanned:
                rpr = first_run_rpr(cell.text_frame)
                if rpr is not None:
                    return rpr
        return None
    for r in range(nr):
        vals = rows[r] if r < len(rows) else []
        row_donor = next((first_run_rpr(t.cell(r, k).text_frame) for k in range(nc) if not t.cell(r, k).is_spanned and first_run_rpr(t.cell(r, k).text_frame) is not None), None)   # the row's first styled cell sets the row's look
        if len(vals) > nc:
            raise SystemExit(f'{where}: table has {nc} columns but row {r} has {len(vals)} values.')
        for c in range(nc):
            cell = t.cell(r, c)
            if cell.is_spanned:
                continue
            if r < len(rows) and c >= len(vals):
                clear_text(cell.text_frame); continue
            if r < len(rows) and c < len(vals) and vals[c] is not None:
                own = first_run_rpr(cell.text_frame)
                if own is None and str(vals[c]).strip() if isinstance(vals[c], str) else own is None and any(str(x).strip() for x in vals[c]):
                    WARN.append(f'{where}: template cell r{r}c{c} is blank by design; text placed with a neighbouring cell style')
                cards_row = len(rows) == 2 and nc >= 3 and r == 1   # a cards / metrics layout: one row of headers, one row of bodies - every body cell must read the same
                set_paragraphs(cell.text_frame, vals[c], fallback_rpr=(row_donor if cards_row and row_donor is not None else (None if own is not None else neighbour_rpr(r, c))))
                if cards_row and row_donor is not None:
                    for rr in cell.text_frame._txBody.findall('.//a:r', NS):
                        old = rr.find('a:rPr', NS)
                        if old is not None: rr.remove(old)
                        rr.insert(0, copy.deepcopy(row_donor))
                    longest = max((len(str(v)) for v in vals if isinstance(v, str)), default=0)
                    if longest > 70:   # long card bodies step down so three cards read alike and fit
                        for rpr in cell.text_frame._txBody.findall('.//a:r/a:rPr', NS): rpr.set('sz', str(1400 if longest > 130 else 1600)); rpr.set('b', '0')
                    if longest <= 110 and nc == 3:   # crisp card copy (one short statement each) reads at 20 pt and fills its card - never a line at the top of an empty box
                        for rpr in cell.text_frame._txBody.findall('.//a:r/a:rPr', NS): rpr.set('sz', '2000'); rpr.set('b', '0')
                if r == 0 and len(rows) > 1 and isinstance(vals[c], str) and vals[c].strip():   # the header row reads bold, whatever weight the template's table style gives it
                    for rpr in cell.text_frame._txBody.findall('.//a:r/a:rPr', NS): rpr.set('b', '1')
            elif r >= len(rows):
                clear_text(cell.text_frame)


# ----------------------------------------------------------------------------- icons (template icon library)
ICON_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icons')
_ICON_CAT = None
STOP = set('the a an and or of for to in on with by at from is are be as & / - – — vs'.split())


def icon_catalog():
    global _ICON_CAT
    if _ICON_CAT is None:
        cat = json.load(open(os.path.join(ICON_DIR, 'icons.json'), encoding='utf-8'))['icons']
        _ICON_CAT = {c['name']: c for c in cat}
    return _ICON_CAT


def pick_icon(text):
    """Keyword match: the catalog icon whose keywords overlap the text most; None when nothing matches."""
    words = {w.strip('.,:;()"\'').lower() for w in re.split(r'[\s/&–—-]+', str(text))} - STOP
    stems = {w[:5] for w in words if len(w) >= 5}
    best, score = None, 0
    for name, c in icon_catalog().items():
        s = sum(2 for k in c['keywords'] if k in words) + sum(1 for k in c['keywords'] if len(k) >= 5 and k[:5] in stems)
        if s > score:
            best, score = name, s
    return best


def svg_part(slide, name, white=False, color=None):
    """Relate an icon SVG to the slide (one part per icon per package) and return the rId. white=True recolours
    every fill/stroke to white (for icons on the gradient dividers)."""
    from pptx.opc.package import Part
    from pptx.opc.packuri import PackURI
    from pptx.opc.constants import RELATIONSHIP_TYPE as RT
    pkg = slide.part.package
    cache = getattr(pkg, '_ulta_icons', None)
    if cache is None:
        cache = pkg._ulta_icons = {}
    col = 'FFFFFF' if white else (color or '').upper()
    key = name + ('-white' if white else ('-' + col if col else ''))
    if key not in cache:
        blob = open(os.path.join(ICON_DIR, name + '.svg'), 'rb').read()
        if col:   # one colour for every fill and stroke (white on the gradient dividers; the box's colour on a light theme)
            blob = re.sub(rb'(fill|stroke)="#(?!none)[0-9A-Fa-f]{3,6}"', rb'\1="#' + col.encode() + rb'"', blob)
            blob = re.sub(rb'(fill|stroke):#[0-9A-Fa-f]{3,6}', rb'\1:#' + col.encode(), blob)
        name = key
        taken = {p.partname for p in pkg.iter_parts()}
        n = 1
        while PackURI(f'/ppt/media/ulta-icon-{name}-{n}.svg') in taken:
            n += 1
        cache[name] = Part(PackURI(f'/ppt/media/ulta-icon-{name}-{n}.svg'), 'image/svg+xml', pkg, office_safe_svg(blob))
    return slide.part.relate_to(cache[key], RT.IMAGE)


_PIC_XML = ('<p:pic xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" '
            'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<p:nvPicPr><p:cNvPr id="{id}" name="ULTA icon {name}"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>'
            '<p:blipFill><a:blip cstate="screen"><a:extLst><a:ext uri="{{96DAC541-7B7A-43D3-8B79-37D633B846F1}}">'
            '<asvg:svgBlip xmlns:asvg="http://schemas.microsoft.com/office/drawing/2016/SVG/main" r:embed="{rid}"/></a:ext></a:extLst></a:blip>'
            '<a:stretch><a:fillRect/></a:stretch></p:blipFill>'
            '<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>')


def add_icon(slide, name, x, y, size_emu, white=False):
    """Place a catalog icon (SVG, like the template's own pictograms) at x,y with its longer side = size_emu."""
    from lxml import etree
    etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
    c = icon_catalog()[name]
    w, h = c['w_in'], c['h_in']
    cx, cy = (size_emu, int(size_emu * h / w)) if w >= h else (int(size_emu * w / h), size_emu)
    rid = svg_part(slide, name, white=white)
    max_id = max([int(e.get('id')) for e in slide._element.iter() if e.tag.endswith('}cNvPr') and e.get('id', '').isdigit()] + [1])
    el = etree.fromstring(_PIC_XML.format(id=max_id + 1, name=name, rid=rid, x=int(x), y=int(y), cx=cx, cy=cy))
    slide.shapes._spTree.append(el)
    return el


def header_pictures(slide, table_shape):
    top, h0 = table_shape.top, table_shape.table.rows[0].height
    return [sh for sh in slide.shapes if sh.shape_type == 13 and sh.top is not None
            and top <= sh.top + sh.height // 2 <= top + h0 and table_shape.left <= sh.left <= table_shape.left + table_shape.width]


def icon_header_room(tbl, names, icon):
    """Header cells that carry an icon at their left: the label moves clear of it (equal margins keep it centred),
    steps down until it fits in two lines with every word whole, and the row is as tall as the label - the icon
    then sits in the middle of the row instead of over the text. Returns the header row height."""
    pad = 91440 + icon + 73152; lines_max = 1
    sizes = []
    for c, name in enumerate(names[:len(tbl.columns)]):
        cell = tbl.cell(0, c)
        if not name or cell.is_spanned: continue
        tcPr = cell._tc.get_or_add_tcPr(); tcPr.set('marL', str(pad)); tcPr.set('marR', str(pad)); tcPr.set('anchor', 'ctr')
        rpr = next(iter(cell._tc.iter(qn_a('rPr'))), None); latin = rpr.find(qn_a('latin')) if rpr is not None else None
        serif = latin is not None and 'Playfair' in (latin.get('typeface') or ''); bold = rpr is not None and rpr.get('b') == '1'
        avail = (tbl.columns[c].width - 2 * pad) / 914400; words = cell.text.split() or ['']
        pt = _run_pt(cell, 18.0)
        def lines(p):
            n, cur = 1, 0.0; sp = p / 72 * 0.3
            for w in words:
                ww = _word_in(w, p, bold, serif)
                if cur and cur + sp + ww > avail: n += 1; cur = ww
                else: cur += (sp if cur else 0) + ww
            return n
        while pt > 14 and (lines(pt) > 2 or max(_word_in(w, pt, bold, serif) for w in words) > avail): pt -= 1
        sizes.append(pt); lines_max = max(lines_max, lines(pt))
    if sizes:
        pt = min(sizes)   # one header size across the cards
        for c, name in enumerate(names[:len(tbl.columns)]):
            if name and not tbl.cell(0, c).is_spanned:
                for rpr in tbl.cell(0, c)._tc.iter(qn_a('rPr')): rpr.set('sz', str(int(pt * 100)))
        need = int(lines_max * pt * 1.2 * 12700) + 182880
        if need > tbl.rows[0].height: tbl.rows[0].height = need
    return tbl.rows[0].height


def apply_icons(slide, regions, fills, spec_icons, where, warnings):
    """spec_icons: "auto" | list (one per table column) | {"table": [...], "text1": "name", "text2": "name"}.
    Tables: the header pictograms the template already carries are replaced (same row, same size); tables without
    them get one icon at the left of each header cell. Text boxes (slide 6): one icon in the top-right corner."""
    ICON = 342900   # 0.375 in - the size the template uses beside table headers
    chosen = spec_icons != 'auto'   # icons someone picked (the editor's Icons gallery): only labelled header columns need one
    if spec_icons == 'auto':
        spec_icons = {}
        for key, sh in regions.items():
            if sh.has_table and key in fills and fills[key]:
                spec_icons[key] = [pick_icon(h) for h in fills[key][0]]
            elif not sh.has_table and key in fills and key != 'title' and 'Rounded Rectangle' in (sh.name or ''):
                paras = fills[key] if isinstance(fills[key], list) else [fills[key]]
                first = str(paras[0]) if paras else ''
                spec_icons[key] = pick_icon(first[len(HEAD):]) if first.startswith(HEAD) else None   # no heading = no room for an icon
    elif isinstance(spec_icons, list):
        spec_icons = {'table': spec_icons}
    for key, want in spec_icons.items():
        if key not in regions or not want:
            continue
        sh = regions[key]
        if sh.has_table:
            names = list(want); tbl = sh.table
            for bad in [n for n in names if n and n not in icon_catalog()]:
                warnings.append(f'{where}: unknown icon "{bad}" (see icons/icons.json)')
            names = [n if n in icon_catalog() else None for n in names]
            if not any(names) or tbl.rows[0].height > 1097280:   # 1.2 in: a tall first row is a layout band, not a header
                continue
            ncol = len(tbl.columns)
            need = [c for c in range(ncol) if not chosen or tbl.cell(0, c).text.strip() not in ('', '#')]
            names = (names + [None] * ncol)[:ncol]
            if not need or any(names[c] is None for c in need):   # header icons are all-or-nothing: one stray icon looks like a mistake
                continue
            if chosen: names = [n if c in need else None for c, n in enumerate(names)]
            for pic in header_pictures(slide, sh):        # template pictograms belong to its own column names
                pic._element.getparent().remove(pic._element)
            h0 = icon_header_room(tbl, names, ICON)
            filled = any(tbl.cell(0, c)._tc.tcPr is not None and tbl.cell(0, c)._tc.tcPr.find(qn_a('solidFill')) is not None for c in range(len(tbl.columns)))   # coloured header cards (the last one takes its colour from the table style)
            x = sh.left
            for c, name in enumerate(names[:len(tbl.columns)]):
                if name:
                    add_icon(slide, name, x + 91440, sh.top + (h0 - ICON) // 2, ICON, white=filled)   # an orange icon on an orange header vanishes
                x += tbl.columns[c].width
        else:
            name = want if isinstance(want, str) else None
            if name and name not in icon_catalog():
                warnings.append(f'{where}: unknown icon "{name}"'); continue
            if name:
                add_icon(slide, name, sh.left + sh.width - ICON - 182880, sh.top + 182880, ICON)


# ----------------------------------------------------------------------------- visual accents (v2.5)
from pptx.util import Inches, Pt
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR, MSO_AUTO_SIZE
from pptx.enum.shapes import MSO_CONNECTOR
from pptx.dml.color import RGBColor

FONT_BODY, FONT_HEAD = 'Circular Std Book', 'Circular Std Bold'   # the template's standard faces (slide 3)


def accent_hex(name):
    return PALETTE.get(str(name or 'orange').lower(), PALETTE['orange'])


def _txt(shape, text, size, bold=False, color='000000', font=FONT_BODY, align=None, anchor=None, caps=False, spc=None):
    tf = shape.text_frame; tf.word_wrap = True
    if anchor is not None: tf.vertical_anchor = anchor
    tf.margin_left = tf.margin_right = Inches(0.15); tf.margin_top = tf.margin_bottom = Inches(0.08)
    first = True
    for line in (text if isinstance(text, list) else [text]):
        p = tf.paragraphs[0] if first else tf.add_paragraph(); first = False
        if align is not None: p.alignment = align
        for seg, fmt in parse_inline(str(line)):
            r = p.add_run(); r.text = seg; r.font.size = Pt(size); r.font.bold = bold or fmt.get('b'); r.font.italic = fmt.get('i')
            r.font.name = font; r.font.color.rgb = RGBColor.from_string(fmt.get('color') or color)
            if caps: r.font._rPr.set('cap', 'all')
            if spc: r.font._rPr.set('spc', str(spc))
    return shape


def _rect(slide, x, y, w, h, fill_hex, rounded=True):
    sh = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if rounded else MSO_SHAPE.RECTANGLE, x, y, w, h)
    sh.fill.solid(); sh.fill.fore_color.rgb = RGBColor.from_string(fill_hex); sh.line.fill.background(); sh.shadow.inherit = False
    if rounded:
        sh.adjustments[0] = 0.12
    return sh


def movable_below(slide, y, exclude_ids=()):
    return [sh for sh in slide.shapes if sh.shape_id not in exclude_ids and sh.top is not None and sh.top >= y - 45720 and sh.height]


def add_chart(slide, box, spec, accent, warnings, where):
    """Native PowerPoint chart in place of a text box: spec = {"kind": bar|column|line|pie, "title": str,
    "categories": [...], "series": {name: [numbers]}}. The box keeps its rounded background; the chart sits inside it."""
    from pptx.chart.data import CategoryChartData
    from pptx.enum.chart import XL_CHART_TYPE, XL_LEGEND_POSITION, XL_LABEL_POSITION
    kinds = {'bar': XL_CHART_TYPE.BAR_CLUSTERED, 'column': XL_CHART_TYPE.COLUMN_CLUSTERED, 'line': XL_CHART_TYPE.LINE_MARKERS, 'pie': XL_CHART_TYPE.PIE, 'doughnut': XL_CHART_TYPE.DOUGHNUT,
             'stacked': XL_CHART_TYPE.COLUMN_STACKED, 'stacked_bar': XL_CHART_TYPE.BAR_STACKED}
    kind = str(spec.get('kind', 'bar')).lower()
    if kind not in kinds:
        warnings.append(f'{where}: unknown chart kind "{kind}" (bar, column, line, pie, doughnut, stacked, stacked_bar)'); kind = 'bar'
    cats = [str(c) for c in spec.get('categories', [])]; series = spec.get('series') or {}
    if not cats or not series:
        warnings.append(f'{where}: chart has no data'); return
    cd = CategoryChartData(); cd.categories = cats
    for name, vals in series.items():
        cd.add_series(str(name), [float(v) if isinstance(v, (int, float)) else 0.0 for v in (list(vals) + [0] * len(cats))[:len(cats)]])
    m = Inches(0.15); top_pad = Inches(0.55) if spec.get('title') else m
    if box.has_text_frame: clear_text(box.text_frame)
    gf = slide.shapes.add_chart(kinds[kind], box.left + m, box.top + top_pad, box.width - 2 * m, box.height - top_pad - m, cd)
    ch = gf.chart; ch.font.size = Pt(11); ch.font.name = FONT_BODY
    ch.has_legend = len(series) > 1 or kind in ('pie', 'doughnut')
    if ch.has_legend: ch.legend.position = XL_LEGEND_POSITION.BOTTOM; ch.legend.include_in_layout = False; ch.legend.font.size = Pt(10)
    hexes = [accent_hex(accent)] + [PALETTE[k] for k in ('pink', 'magenta', 'red', 'berry')]
    plot = ch.plots[0]
    if kind in ('pie', 'doughnut'):
        for i, pt in enumerate(plot.series[0].points):
            pt.format.fill.solid(); pt.format.fill.fore_color.rgb = RGBColor.from_string((hexes + ['FF893F', 'E8275A', 'D01381', '404040', 'D9D9D9', 'D9D9D9'])[i % 11])
        plot.has_data_labels = True; plot.data_labels.number_format = '0%'; plot.data_labels.number_format_is_linked = False
        plot.data_labels.show_percentage = True; plot.data_labels.show_value = False; plot.data_labels.font.size = Pt(10)
    else:
        for i, ser in enumerate(plot.series):
            ser.format.fill.solid(); ser.format.fill.fore_color.rgb = RGBColor.from_string(hexes[i % len(hexes)])
            if kind == 'line':
                ser.format.line.color.rgb = RGBColor.from_string(hexes[i % len(hexes)]); ser.format.line.width = Pt(2.25); ser.smooth = False
                ser.marker.format.fill.solid(); ser.marker.format.fill.fore_color.rgb = RGBColor.from_string(hexes[i % len(hexes)])
        if kind in ('bar', 'column') and len(series) == 1:
            plot.gap_width = 60; plot.has_data_labels = True; plot.data_labels.font.size = Pt(9); plot.data_labels.number_format = '#,##0'; plot.data_labels.number_format_is_linked = False
            plot.data_labels.position = XL_LABEL_POSITION.OUTSIDE_END
        va = ch.value_axis; va.has_major_gridlines = True; va.major_gridlines.format.line.color.rgb = RGBColor.from_string('D9D9D9'); va.tick_labels.font.size = Pt(9); va.format.line.fill.background()
        va.tick_labels.number_format = '#,##0'; va.tick_labels.number_format_is_linked = False
        ca = ch.category_axis; ca.tick_labels.font.size = Pt(9); ca.format.line.color.rgb = RGBColor.from_string('D9D9D9')
        if kind == 'bar': ca.reverse_order = True     # top item at the top, like a ranked list
        if kind == 'bar' and len(cats) > 6: ch.font.size = Pt(9)
    ch.has_title = False
    if spec.get('title'):
        tb = slide.shapes.add_textbox(box.left + m, box.top + Inches(0.08), box.width - 2 * m, Inches(0.45))
        _txt(tb, [str(spec['title'])], 14, bold=True, color='000000', font=FONT_HEAD); tb.name = 'ULTA chart title'
    gf.name = 'ULTA chart'


def add_image(slide, box, path, warnings, where):
    """Picture fitted (aspect kept, centred) inside a text box's rounded background."""
    if not path or not os.path.isfile(path):
        warnings.append(f'{where}: image not found: {path}'); return
    try:
        from PIL import Image
        with Image.open(path) as im: iw, ih = im.size
    except Exception:
        iw, ih = 4, 3
    m = Inches(0.2); bw, bh = box.width - 2 * m, box.height - 2 * m
    scale = min(bw / iw, bh / ih); w, h = int(iw * scale), int(ih * scale)
    if box.has_text_frame: clear_text(box.text_frame)
    pic = slide.shapes.add_picture(path, box.left + m + (bw - w) // 2, box.top + m + (bh - h) // 2, w, h); pic.name = 'ULTA image'


def add_wide_image(slide, regions, fills, path, warnings, where):
    """A short text over one wide picture (restyled decks): the text box keeps the width and shrinks to its lines, the picture
    fills the space below it at full width (aspect kept, centred). No text: the picture takes the whole body."""
    if not path or not os.path.isfile(path):
        warnings.append(f'{where}: image not found: {path}'); return
    try:
        from PIL import Image
        with Image.open(path) as im: iw, ih = im.size
    except Exception:
        iw, ih = 16, 9
    box = regions['text1']; lines = [str(l) for l in (fills.get('text1') or []) if str(l).strip()]
    left, width, bottom = box.left, box.width, Inches(6.55)
    if lines:
        per = max(40, int((width / 914400 - 0.9) * 9.0))   # ~9 characters an inch at 14 pt, inside the box margins and bullet indent
        n = sum(max(1, -(-len(re.sub(r'\{[^{}]*\}|\{/\}|\*\*', '', l)) // per)) for l in lines)
        box.height = Emu(min(box.height, Inches(0.42) + Inches(0.26) * n + Inches(0.14) * (len(lines) - 1)))   # margins + lines + the space after each bullet
        top = box.top + box.height + Inches(0.15)
    else:
        top = box.top; regions.pop('text1'); box._element.getparent().remove(box._element)
    aw, ah = width, bottom - top
    if ah < Inches(1.2):
        warnings.append(f'{where}: too little room under the text for the picture; kept in the notes'); return
    scale = min(aw / iw, ah / ih); w, h = int(iw * scale), int(ih * scale)
    pic = slide.shapes.add_picture(path, left + (aw - w) // 2, top, w, h); pic.name = 'ULTA image'


def add_takeaway(slide, regions, text, accent, warnings, where):
    """One-line 'so what' under the headline (sub-headline style); the content below moves down to make room."""
    title = regions.get('title')
    if title is None or not str(text).strip(): return
    ttxt = title.text_frame.text; tsize = next((r.font.size.pt for p in title.text_frame.paragraphs for r in p.runs if r.font.size), 36.0)
    two = len(re.sub(r'\{[^{}]*\}|\{/\}|\*\*', '', str(text))) > 100   # ~100 characters fill one 16 pt line: a longer so-what gets two lines at 14 pt, not an overflow
    h = Inches(0.66 if two else 0.42); size = 14 if two else 16
    def make_room(body, delta):
        limit = Inches(6.55)
        over = [sh for sh in body if sh.top + sh.height + delta > limit]
        if any(not sh.has_table for sh in over): return False
        for sh in body: sh.top = Emu(sh.top + delta)
        for sh in over:                                    # a table's tall last row is empty space: trim it so the table ends where it did
            rows = list(sh.table.rows); cut = sh.top + sh.height - limit
            if rows and rows[-1].height > cut + Inches(0.3): rows[-1].height = Emu(rows[-1].height - cut)
        return True
    body = movable_below(slide, title.top + Inches(0.6), exclude_ids={title.shape_id})   # the steps table starts 0.1 in above the headline box's bottom
    if headline_lines(ttxt, title.width or 0, tsize, glyph=0.64) <= 1:
        y = title.top + Inches(0.56)                     # a one-line headline leaves the lower half of its box free: the takeaway sits there
        if two and not make_room(body, h - Inches(0.42)):   # its second line needs a little more: the content below moves down, else one line
            h, size = Inches(0.42), 16
    else:
        y = title.top + title.height + Inches(0.02)
        if not make_room(body, h + Inches(0.08)):
            warnings.append(f'{where}: no room for the takeaway line; kept in the notes'); return
    box = slide.shapes.add_textbox(title.left, y, Inches(12.1), h)
    _txt(box, text, size, bold=True, color=accent_hex(accent), font=FONT_HEAD, anchor=MSO_ANCHOR.MIDDLE)
    box.name = 'ULTA takeaway'


FLOW_COLORS = ['D01381', 'E8275A', 'E9341C', 'EE6C37']   # the template's own step colours, cycling


def add_graphic(slide, regions, graphic, accent, warnings, where):
    """Drawn infographics on the two-box slide: a funnel (stages that narrow), a pyramid (levels that build up) or a cycle (a loop of
    nodes on a ring), 3–6 items, with the description of each item listed beside it. Native shapes, the palette's colours, the template's
    fonts; the theme pass and the contrast pass style them like every other coloured element."""
    kind = graphic.get('kind', 'funnel'); items = [it for it in graphic.get('items', []) if isinstance(it, dict)][:8]; n = len(items)
    if n < 2: return
    top0 = Inches(1.62); tk = next((sh for sh in slide.shapes if (sh.name or '') == 'ULTA takeaway'), None)
    if tk is not None and tk.top + tk.height > top0 - Inches(0.05): top0 = tk.top + tk.height + Inches(0.12)
    bottom = Inches(6.45); avail = bottom - top0; A = '{%s}' % NS['a']
    def seg(shape_type, x, y, w, h, color, flip=False, adj=None):
        sh = slide.shapes.add_shape(shape_type, int(x), int(y), int(w), int(h)); sh.fill.solid(); sh.fill.fore_color.rgb = RGBColor.from_string(color); sh.line.fill.background(); sh.shadow.inherit = False
        if flip: sh._element.find('.//a:xfrm', NS).set('flipV', '1')
        if adj is not None:
            geom = sh._element.find('.//a:prstGeom', NS); av = geom.find('a:avLst', NS)
            if av is None: av = etree.SubElement(geom, A + 'avLst')
            for g in list(av): av.remove(g)
            etree.SubElement(av, A + 'gd', name='adj', fmla=f'val {int(adj)}')
        return sh
    def label(sh, text, size, color='FFFFFF'):
        # side margins scale with the shape: a fixed 0.2 in left a 0.5 in dot 0.1 in for its number, which PowerPoint / Keynote clip
        _txt(sh, text, size, bold=True, color=color, font=FONT_HEAD, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE); sh.text_frame.margin_left = sh.text_frame.margin_right = int(min(Inches(0.2), sh.width * 0.08))
        sh.text_frame.margin_top = sh.text_frame.margin_bottom = int(min(Inches(0.05), sh.height * 0.05))
    def overlay_label(sh, text, size, color='FFFFFF'):
        # a label drawn in its own upright text box over the shape - a flipped shape (the funnel's tiers) would turn its own text upside down
        box = slide.shapes.add_textbox(sh.left, sh.top, sh.width, sh.height); tf = box.text_frame; tf.word_wrap = True; tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        tf.margin_left = tf.margin_right = int(min(Inches(0.2), sh.width * 0.12)); p = tf.paragraphs[0]; p.alignment = PP_ALIGN.CENTER
        r = p.add_run(); r.text = str(text); r.font.size = Pt(size); r.font.bold = True; r.font.name = FONT_HEAD; r.font.color.rgb = RGBColor.from_string(color)
        box.name = sh.name.replace('ULTA graphic', 'ULTA tier') + ' label'; return box   # not "ULTA graphic …": theme passes and checks look those up as the drawn shapes
    def side_text(x, y, w, h, k, it, size, align=None, anchor=MSO_ANCHOR.MIDDLE, on_fill=False, num=False):
        box = slide.shapes.add_textbox(int(x), int(y), int(w), int(h)); tf = box.text_frame; tf.word_wrap = True; tf.vertical_anchor = anchor
        if align is not None: tf.paragraphs[0].alignment = align
        t = str(it.get('title', '')).strip(); body = str(it.get('text', '') or '').strip(); core = t.rstrip('.…')
        rep = bool(body) and bool(core) and body.lower().startswith(core.lower())   # a body that starts with its own title is written once: title in bold, then the rest
        p = tf.paragraphs[0]; r = p.add_run(); r.text = (f'{k + 1}. ' if num else '') + (body[:len(core)] if rep else t); r.font.size = Pt(size); r.font.bold = True; r.font.name = FONT_HEAD; r.font.color.rgb = RGBColor.from_string('FFFFFF' if on_fill else FLOW_COLORS[k % 4])
        if body:
            r2 = p.add_run(); r2.text = body[len(core):] if rep else ' - ' + body; r2.font.size = Pt(size - 1); r2.font.name = FONT_BODY; r2.font.color.rgb = RGBColor.from_string('FFFFFF' if on_fill else '404040')
        box.name = f'ULTA graphic text {k + 1}'; return box
    if kind in ('funnel', 'pyramid'):
        gx, gw = Inches(0.9), Inches(6.2); gap = Inches(0.06); lh = (avail - gap * (n - 1)) / n; lh = min(lh, Inches(1.15)); block = n * lh + (n - 1) * gap; y0 = top0 + (avail - block) / 2
        widths = [gw * (1 - 0.62 * k / max(1, n)) for k in range(n + 1)]     # funnel: wide to narrow; pyramid: the reverse
        if kind == 'pyramid': widths = list(reversed(widths))
        for k, it in enumerate(items):
            wt, wb = widths[k], widths[k + 1]; w = max(wt, wb); x = gx + (gw - w) / 2; y = y0 + k * (lh + gap); color = FLOW_COLORS[k % 4]
            inset = abs(wt - wb) / 2; ss = min(w, lh); adj = min(int(inset / ss * 100000), int(50000 * w / ss))   # the top level of a pyramid is a narrow trapezoid, so its label still fits
            sh = seg(MSO_SHAPE.TRAPEZOID, x, y, w, lh, color, flip=(kind == 'funnel'), adj=adj); sh.name = f'ULTA graphic {k + 1}'
            fsz = 13 if n <= 4 else 12 if n <= 6 else 11
            if kind == 'funnel':
                lab_w = min(wt, wb) * 0.92; lb = overlay_label(sh, str(it.get('title', '')), fsz); lb.left = int(x + (w - lab_w) / 2); lb.width = int(lab_w)
            else:
                label(sh, str(it.get('title', '')), fsz)
            side_text(gx + gw + Inches(0.35), y, Inches(12.7) - (gx + gw + Inches(0.35)), lh, k, it, 12 if n <= 4 else 11 if n <= 6 else 10)
    elif kind == 'timeline':   # milestones on a line: numbered dots, the caption under (alternating above / below past four)
        from pptx.enum.shapes import MSO_CONNECTOR
        # captions never overlap: each is at most the room between its neighbours on the same side (every dot below when four or
        # fewer, alternating above / below past four), and the line is inset so the first and last captions sit whole on the slide
        per_side = n if n <= 4 else -(-n // 2); bw = min(Inches(3.1), int(Inches(12.43) / max(1, per_side) * 0.94))
        left = Inches(0.45) + bw / 2; width = Inches(12.88) - bw / 2 - left; ly = top0 + avail * (0.45 if n > 4 else 0.3); d = Inches(0.5)
        ln = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, int(left), int(ly), int(left + width), int(ly)); ln.line.color.rgb = RGBColor.from_string('D9D9D9'); ln.line.width = Pt(3); ln.name = 'ULTA graphic line'
        step = width / (n - 1) if n > 1 else 0; bh = Inches(1.45)
        for k, it in enumerate(items):
            x = left + k * step; dot = seg(MSO_SHAPE.OVAL, x - d / 2, ly - d / 2, d, d, FLOW_COLORS[k % 4]); label(dot, str(k + 1), 12); dot.name = f'ULTA graphic {k + 1}'
            above = n > 4 and k % 2 == 0
            bx = x - bw / 2
            side_text(bx, (ly - d / 2 - Inches(0.08) - bh) if above else (ly + d / 2 + Inches(0.08)), bw, bh, k, it, 12 if n <= 5 else 11, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.BOTTOM if above else MSO_ANCHOR.TOP)
    elif kind == 'matrix':   # 2 × 2: four quadrants, title and text inside each
        gx, gw = Inches(0.9), Inches(11.5); gap = Inches(0.16); cw = (gw - gap) / 2; ch = (avail - gap) / 2
        for k, it in enumerate(items[:4]):
            x = gx + (k % 2) * (cw + gap); y = top0 + (k // 2) * (ch + gap)
            sh = seg(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, cw, ch, FLOW_COLORS[k % 4]); sh.name = f'ULTA graphic {k + 1}'
            geom = sh._element.find('.//a:prstGeom', NS); av = geom.find('a:avLst', NS)
            if av is None: av = etree.SubElement(geom, A + 'avLst')
            for g in list(av): av.remove(g)
            etree.SubElement(av, A + 'gd', name='adj', fmla='val 8000')
            side_text(x + Inches(0.25), y + Inches(0.15), cw - Inches(0.5), ch - Inches(0.3), k, it, 14, anchor=MSO_ANCHOR.TOP, on_fill=True)
    elif kind == 'hub':   # hub and spoke: the theme in the centre, satellites around it, the legend beside
        import math
        from pptx.enum.shapes import MSO_CONNECTOR
        cx, cy, r = Inches(3.55), top0 + avail / 2, min(avail / 2 - Inches(0.7), Inches(2.05)); d = Inches(1.1) if n <= 5 else Inches(0.9); hr = Inches(0.95)
        for k, it in enumerate(items):
            a = -math.pi / 2 + 2 * math.pi * k / n; px = cx + r * math.cos(a); py = cy + r * math.sin(a)
            ln = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, int(cx), int(cy), int(px), int(py)); ln.line.color.rgb = RGBColor.from_string('D9D9D9'); ln.line.width = Pt(2); ln.name = f'ULTA graphic spoke {k + 1}'
        for k, it in enumerate(items):
            a = -math.pi / 2 + 2 * math.pi * k / n; px = cx + r * math.cos(a); py = cy + r * math.sin(a)
            sh = seg(MSO_SHAPE.OVAL, px - d / 2, py - d / 2, d, d, FLOW_COLORS[k % 4]); label(sh, str(k + 1), 15); sh.name = f'ULTA graphic {k + 1}'
        hub = seg(MSO_SHAPE.OVAL, cx - hr, cy - hr, 2 * hr, 2 * hr, '000000'); label(hub, str(graphic.get('hub') or '')[:40], 12); hub.name = 'ULTA graphic hub'
        lx = cx + r + Inches(0.9); lw = Inches(12.7) - lx; lh = min(Inches(0.9), avail / n); y0 = top0 + (avail - n * lh) / 2
        for k, it in enumerate(items): side_text(lx, y0 + k * lh, lw, lh, k, it, 12 if n <= 4 else 11, num=True)
    elif kind == 'roadmap':   # phases as chevrons, the description under each; two rows past five
        left, width = Inches(0.65), Inches(12.05); rows = 2 if n > 5 else 1; cols = -(-n // rows); gap = Inches(0.1)
        cw = (width - gap * (cols - 1)) / cols; chh = Inches(0.95); dh = min(Inches(1.6), (avail - rows * chh - (rows - 1) * Inches(0.3)) / rows - Inches(0.08))
        y_start = top0 + max(0, (avail - rows * (chh + dh + Inches(0.08)) - (rows - 1) * Inches(0.3)) / 2)
        for k, it in enumerate(items):
            r_, c_ = divmod(k, cols); x = left + c_ * (cw + gap); y = y_start + r_ * (chh + dh + Inches(0.08) + Inches(0.3))
            sh = seg(MSO_SHAPE.CHEVRON if k else MSO_SHAPE.PENTAGON, x, y, cw, chh, FLOW_COLORS[k % 4]); label(sh, str(it.get('title', '')), 12 if n <= 5 else 11); sh.name = f'ULTA graphic {k + 1}'
            sh.text_frame.margin_left = Inches(0.35); sh.text_frame.margin_right = Inches(0.25)
            box = slide.shapes.add_textbox(int(x), int(y + chh + Inches(0.08)), int(cw), int(dh)); _txt(box, str(it.get('text', '') or ''), 11 if n <= 5 else 10, color='404040'); box.text_frame.word_wrap = True; box.text_frame.margin_left = box.text_frame.margin_right = Inches(0.08); box.name = f'ULTA graphic text {k + 1}'
    elif kind == 'hexagons':   # a honeycomb of up to seven, the title inside, the legend beside
        gx, gw = Inches(0.9), Inches(6.2); hw = Inches(1.75) if n <= 4 else Inches(1.55); hh = hw * 0.88
        rows = [items[:n]] if n <= 4 else [items[:(n + 1) // 2], items[(n + 1) // 2:]]
        inner = hw * 0.62 / 914400 * 72 / (11 * 0.56)   # characters per line inside a hexagon at 11 pt bold
        names_fit = all(len(w) <= inner for it in items for w in str(it.get('title', '')).split()) and all(len(str(it.get('title', ''))) <= inner * 2 for it in items)
        block_h = len(rows) * hh - (len(rows) - 1) * hh * 0.12; y0 = top0 + (avail - block_h) / 2; k = 0
        for ri, row in enumerate(rows):
            rw = len(row) * hw * 0.92; x0 = gx + (gw - rw) / 2 + (hw * 0.46 if ri else 0) * (1 if len(rows) > 1 and len(rows[0]) > len(row) else 0)
            for j, it in enumerate(row):
                # the name goes inside only when every name fits the hexagon on two lines of whole words; otherwise the number, the name in the legend
                sh = seg(MSO_SHAPE.HEXAGON, x0 + j * hw * 0.92, y0 + ri * (hh * 0.88), hw, hh, FLOW_COLORS[k % 4]); sh.name = f'ULTA graphic {k + 1}'
                label(sh, str(it.get('title', '')) if names_fit else str(k + 1), 11 if names_fit else 18); k += 1
        lx = gx + gw + Inches(0.35); lw = Inches(12.7) - lx; lh = min(Inches(0.9), avail / n); ly0 = top0 + (avail - n * lh) / 2
        for k, it in enumerate(items): side_text(lx, ly0 + k * lh, lw, lh, k, it, 12 if n <= 4 else 11, num=not names_fit)
    else:   # cycle: nodes on a ring, the legend beside it
        cx, cy, r = Inches(3.55), top0 + avail / 2, min(avail / 2 - Inches(0.75), Inches(2.0)); d = Inches(1.35) if n <= 4 else Inches(1.15) if n <= 6 else Inches(0.95)
        ring = slide.shapes.add_shape(MSO_SHAPE.OVAL, int(cx - r), int(cy - r), int(2 * r), int(2 * r)); ring.fill.background(); ring.line.color.rgb = RGBColor.from_string('D9D9D9'); ring.line.width = Pt(2.5); ring.shadow.inherit = False; ring.name = 'ULTA graphic ring'
        import math
        for k, it in enumerate(items):
            a = -math.pi / 2 + 2 * math.pi * k / n; x = cx + r * math.cos(a) - d / 2; y = cy + r * math.sin(a) - d / 2
            sh = seg(MSO_SHAPE.OVAL, x, y, d, d, FLOW_COLORS[k % 4]); label(sh, str(k + 1), 16); sh.name = f'ULTA graphic {k + 1}'
        lx = cx + r + Inches(0.9); lw = Inches(12.7) - lx; lh = min(Inches(0.9), avail / n); y0 = top0 + (avail - n * lh) / 2
        for k, it in enumerate(items): side_text(lx, y0 + k * lh, lw, lh, k, it, 12 if n <= 4 else 11, num=True)
    warnings.append(f'{where}: {n} items drawn as a {kind}')


BOARD_STICKY = {'yellow': 'FDE1D2', 'peach': 'FDE1D2', 'pink': 'FFE8EE', 'mint': 'F2F2F2', 'sky': 'F2F2F2', 'lavender': 'FFE8EE'}


def add_board(slide, board, warnings, where):
    """A whiteboard (whiteboard/board.py) drawn in native shapes below the headline: zones, bones and branches, lines and every sticky at the
    board's own positions, scaled uniformly into the content area - so the slide is the board people edited, not a picture of it."""
    zones, items, lines = board.get('zones') or [], board.get('items') or [], board.get('lines') or []
    xs, ys, xe, ye = [0], [0], [board.get('w', 1480)], [board.get('h', 624)]
    for o in zones + items:
        if 'x' in o: xs.append(o['x']); ys.append(o['y']); xe.append(o['x'] + o.get('w', 0)); ye.append(o['y'] + o.get('h', 0))
    for l in lines: xs += [l['x1'], l['x2']]; ys += [l['y1'], l['y2']]; xe += [l['x1'], l['x2']]; ye += [l['y1'], l['y2']]
    x0, y0, x1, y1 = min(xs), min(ys), max(xe), max(ye)
    top = Inches(1.5); tk = next((sh for sh in slide.shapes if (sh.name or '') == 'ULTA takeaway'), None)
    if tk is not None and tk.top + tk.height > top - Inches(0.05): top = tk.top + tk.height + Inches(0.1)
    left, right, bottom = Inches(0.5), Inches(12.83), Inches(6.62)
    s = min((right - left) / max(1, x1 - x0), (bottom - top) / max(1, y1 - y0))
    ox = left + ((right - left) - (x1 - x0) * s) / 2 - x0 * s; oy = top - y0 * s
    X = lambda v: int(ox + v * s); Y = lambda v: int(oy + v * s); L = lambda v: int(v * s); PT = lambda fs: max(6.0, round(fs * s / 12700, 1))
    def box(shape_type, x, y, w, h, fill, line=None, lw=1.0, name='ULTA board'):
        sh = slide.shapes.add_shape(shape_type, X(x), Y(y), max(1, L(w)), max(1, L(h))); sh.shadow.inherit = False; sh.name = name
        if fill: sh.fill.solid(); sh.fill.fore_color.rgb = RGBColor.from_string(fill)
        else: sh.fill.background()
        if line: sh.line.color.rgb = RGBColor.from_string(line); sh.line.width = Pt(lw)
        else: sh.line.fill.background()
        return sh
    def text(sh, t, fs, color='000000', bold=False, align=None, anchor=MSO_ANCHOR.TOP, pad=8, caps=False, font=None):
        tf = sh.text_frame; tf.word_wrap = True; tf.vertical_anchor = anchor; tf.auto_size = MSO_AUTO_SIZE.NONE
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = L(pad)
        p = tf.paragraphs[0]; p.line_spacing = 1.0
        if align is not None: p.alignment = align
        r = p.add_run(); r.text = str(t or ''); r.font.size = Pt(PT(fs)); r.font.bold = bold; r.font.name = font or (FONT_HEAD if bold else FONT_BODY); r.font.color.rgb = RGBColor.from_string(color)
        if caps: r.font._rPr.set('cap', 'all')
    for z in zones:
        k = z.get('kind')
        if k in ('area', 'cell', 'chain', 'root'):
            sh = box(MSO_SHAPE.ROUNDED_RECTANGLE, z['x'], z['y'], z['w'], z['h'], 'F8F5F5', 'E9341C' if k == 'root' else 'D9D9D9', 1.75 if k == 'root' else 0.75, 'ULTA board zone'); sh.adjustments[0] = min(0.5, 10 / max(1, min(z['w'], z['h'])))
            ttl = 'Root cause' if k == 'root' else (z.get('title') or '')
            if ttl: text(sh, ttl, 13, 'E9341C' if k == 'root' else 'E0531B', bold=True, pad=10, caps=True)
            if k == 'chain':
                for st in range(int(z.get('slots', 0))):
                    tb = slide.shapes.add_textbox(X(z['x'] + st * (z['slot_w'] + z['slot_gap'])), Y(z['y']), L(z['slot_w']), L(34)); tb.name = 'ULTA board label'
                    text(tb, f'Why {st + 1}', 13, 'E0531B', bold=True, pad=10, caps=True)
        elif k in ('banner', 'lane'):
            sh = box(MSO_SHAPE.ROUNDED_RECTANGLE, z['x'], z['y'], z['w'], z['h'], 'FFF5F3', 'FDE1D2', 0.75, 'ULTA board label')
            text(sh, z.get('title'), 15 if k == 'banner' else 13, 'E0531B', bold=True, align=PP_ALIGN.CENTER if k == 'banner' else None, anchor=MSO_ANCHOR.MIDDLE, pad=10)
        elif k in ('header', 'bone', 'branch'):
            sh = box(MSO_SHAPE.ROUNDED_RECTANGLE, z['x'], z['y'], z['w'], z['h'], z.get('color') or 'E0531B', name='ULTA board label'); sh.adjustments[0] = 0.2 if k == 'header' else 0.5
            text(sh, z.get('title'), 14, 'FFFFFF', bold=True, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, pad=6)
        elif k in ('head', 'center'):
            sh = box(MSO_SHAPE.OVAL if k == 'center' else MSO_SHAPE.ROUNDED_RECTANGLE, z['x'], z['y'], z['w'], z['h'], '000000', name='ULTA board focus')
            if k == 'head': sh.adjustments[0] = 0.12
            text(sh, z.get('title'), 17 if len(str(z.get('title') or '')) < 60 else 14, 'FFFFFF', bold=True, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, pad=12)
        elif k == 'axis':
            tb = slide.shapes.add_textbox(X(z['x']), Y(z['y']), max(1, L(z['w'])), max(1, L(z['h']))); tb.name = 'ULTA board axis'
            text(tb, z.get('title'), 14, '404040', bold=True, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE, pad=2)
            if z.get('rotate'): tb.text_frame._txBody.bodyPr.set('vert', 'vert270')   # vertical text in its own tall box: stays on the slide, reads bottom to top
    def connector(x1, y1, x2, y2, color, w, arrow=False):
        ln = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, X(x1), Y(y1), X(x2), Y(y2)); ln.line.color.rgb = RGBColor.from_string(color); ln.line.width = Pt(max(0.75, w * s / 12700 * 1.2)); ln.name = 'ULTA board line'
        if arrow:
            lnel = ln.line._get_or_add_ln(); tail = etree.SubElement(lnel, '{%s}tailEnd' % NS['a']); tail.set('type', 'triangle'); tail.set('w', 'med'); tail.set('len', 'med')
        return ln
    for l in lines:
        if l.get('curve'):   # a curved branch: two straight halves meeting at the midpoint's height change (clean in every renderer)
            mx = (l['x1'] + l['x2']) / 2; connector(l['x1'], l['y1'], mx, l['y1'], l.get('color', '000000'), l.get('w', 2)); connector(mx, l['y1'], mx, l['y2'], l.get('color', '000000'), l.get('w', 2)); connector(mx, l['y2'], l['x2'], l['y2'], l.get('color', '000000'), l.get('w', 2))
        else: connector(l['x1'], l['y1'], l['x2'], l['y2'], l.get('color', '000000'), l.get('w', 2), bool(l.get('arrow')))
    zmap = {z['id']: z for z in zones}
    for it in items:
        if 'x' not in it: continue
        az = zmap.get(it.get('anchor'))
        if az is not None:
            sx = az['x'] + (az['w'] if az.get('side', 1) > 0 else 0); sy = az['y'] + az['h'] / 2; tx = it['x'] if az.get('side', 1) > 0 else it['x'] + it['w']; ty = it['y'] + it['h'] / 2; mx = (sx + tx) / 2
            for a, b_, c, d in ((sx, sy, mx, sy), (mx, sy, mx, ty), (mx, ty, tx, ty)): connector(a, b_, c, d, az.get('color') or '404040', 2)
        kind = it.get('kind') or 'sticky'
        sh = box(MSO_SHAPE.ROUNDED_RECTANGLE, it['x'], it['y'], it['w'], it['h'], BOARD_STICKY.get(it.get('color'), 'FDE1D2'), 'E9341C' if kind == 'root' else 'F3EDEB', 1.25 if kind == 'root' else 0.5, 'ULTA board sticky')
        sh.adjustments[0] = 0.06
        text(sh, it.get('text'), it.get('fs', 14), '000000', anchor=MSO_ANCHOR.MIDDLE if kind in ('cause', 'leaf') else MSO_ANCHOR.TOP, pad=5 if kind in ('cause', 'leaf') else 8)
    small = sum(1 for it in items if 'x' in it and PT(it.get('fs', 14)) < 8)
    if small: warnings.append(f'{where}: {small} sticky note(s) set below 8 pt to fit the board on the slide - the .drawio and the board page keep them full size')


def add_screen(slide, sc, warnings, where):
    """A UI screen (uidesign/design.py) drawn in native shapes below the headline: the frame, the navigation and every component, scaled into the
    content area with a thin device outline - editable in PowerPoint, the same picture as the prototype."""
    W, H = sc.get('w', 1280), sc.get('h', 800)
    top, left, right, bottom = Inches(1.45), Inches(0.5), Inches(12.83), Inches(6.62)
    s = min((right - left) / W, (bottom - top) / H); ox = left + ((right - left) - W * s) / 2; oy = top
    X = lambda v: int(ox + v * s); Y = lambda v: int(oy + v * s); L = lambda v: max(1, int(v * s)); PT = lambda fs: max(5.0, round(fs * s / 12700, 1))
    frame = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if W < 500 else MSO_SHAPE.RECTANGLE, X(0), Y(0), L(W), L(H)); frame.shadow.inherit = False; frame.name = 'ULTA screen frame'
    frame.fill.solid(); frame.fill.fore_color.rgb = RGBColor.from_string(sc.get('bg') or 'FFFFFF'); frame.line.color.rgb = RGBColor.from_string('000000' if W < 500 else 'D9D9D9'); frame.line.width = Pt(2.25 if W < 500 else 0.75)
    if W < 500: frame.adjustments[0] = 0.06
    for e in sc.get('els', []):
        k = e['k']
        if k == 'rect':
            if e['w'] <= 0 or e['h'] <= 0: continue
            sh = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if e.get('r') else MSO_SHAPE.RECTANGLE, X(e['x']), Y(e['y']), L(e['w']), L(e['h'])); sh.shadow.inherit = False; sh.name = 'ULTA screen box'
            if e.get('r'): sh.adjustments[0] = min(0.5, e['r'] / max(1, min(e['w'], e['h'])))
            if e.get('fill'): sh.fill.solid(); sh.fill.fore_color.rgb = RGBColor.from_string(e['fill'])
            else: sh.fill.background()
            if e.get('stroke'): sh.line.color.rgb = RGBColor.from_string(e['stroke']); sh.line.width = Pt(max(0.5, e.get('sw', 1) * s / 12700))
            else: sh.line.fill.background()
        elif k == 'ellipse':
            sh = slide.shapes.add_shape(MSO_SHAPE.OVAL, X(e['x']), Y(e['y']), L(e['w']), L(e['h'])); sh.shadow.inherit = False; sh.name = 'ULTA screen box'
            if e.get('fill'): sh.fill.solid(); sh.fill.fore_color.rgb = RGBColor.from_string(e['fill'])
            else: sh.fill.background()
            if e.get('stroke'): sh.line.color.rgb = RGBColor.from_string(e['stroke']); sh.line.width = Pt(0.75)
            else: sh.line.fill.background()
        elif k == 'line':
            ln = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, X(e['x1']), Y(e['y1']), X(e['x2']), Y(e['y2'])); ln.line.color.rgb = RGBColor.from_string(e['color']); ln.line.width = Pt(max(0.5, e.get('sw', 1) * s / 12700)); ln.name = 'ULTA screen line'
        elif k == 'text' and e.get('t'):
            tb = slide.shapes.add_textbox(X(e['x']), Y(e['y']), L(e['w']), L(e['h'])); tb.name = 'ULTA screen text'; tf = tb.text_frame; tf.word_wrap = True; tf.auto_size = MSO_AUTO_SIZE.NONE
            tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0; tf.vertical_anchor = MSO_ANCHOR.TOP if e.get('valign') == 'top' else MSO_ANCHOR.MIDDLE
            p = tf.paragraphs[0]; p.alignment = {'left': PP_ALIGN.LEFT, 'center': PP_ALIGN.CENTER, 'right': PP_ALIGN.RIGHT}[e.get('align', 'left')]
            r = p.add_run(); r.text = e['t']; r.font.size = Pt(PT(e['fs'])); r.font.bold = e.get('fw', 400) >= 600; r.font.name = FONT_HEAD if e.get('fw', 400) >= 600 else FONT_BODY; r.font.color.rgb = RGBColor.from_string(e['color'])
    if PT(14) < 6.5: warnings.append(f'{where}: the screen is tall - body text is under 6.5 pt on the slide; the prototype and the PNG keep it full size')


def office_safe_svg(blob):
    """PowerPoint repaints any SVG element whose class starts MsftOfcThm_ in the file's theme colour (Accent 1 =
    Office blue on a one-pager), ignoring the colour we set. Renaming the class keeps the CSS but breaks the link."""
    return blob.replace(b'MsftOfcThm_', b'UltaIcon_')


def svg_blob_part(slide, key, blob):
    """Relate any SVG (a recoloured pictogram, the Ulta logo) to the slide, one part per key per package; returns the rId."""
    from pptx.opc.package import Part
    from pptx.opc.packuri import PackURI
    from pptx.opc.constants import RELATIONSHIP_TYPE as RT
    pkg = slide.part.package; cache = getattr(pkg, '_ulta_svgs', None)
    if cache is None: cache = pkg._ulta_svgs = {}
    if key not in cache:
        taken = {p.partname for p in pkg.iter_parts()}; n = 1; safe = re.sub(r'[^a-z0-9-]+', '-', key.lower())
        while PackURI(f'/ppt/media/ulta-{safe}-{n}.svg') in taken: n += 1
        cache[key] = Part(PackURI(f'/ppt/media/ulta-{safe}-{n}.svg'), 'image/svg+xml', pkg, office_safe_svg(blob))
    return slide.part.relate_to(cache[key], RT.IMAGE)


def add_svg_pic(slide, key, blob, x, y, cx, cy, name):
    from lxml import etree
    etree.set_default_parser(etree.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
    rid = svg_blob_part(slide, key, blob)
    max_id = max([int(e.get('id')) for e in slide._element.iter() if e.tag.endswith('}cNvPr') and e.get('id', '').isdigit()] + [1])
    el = etree.fromstring(_PIC_XML.format(id=max_id + 1, name=name, rid=rid, x=int(x), y=int(y), cx=int(cx), cy=int(cy)))
    slide.shapes._spTree.append(el); return el


INFO_FONTS = {'display': 'Playfair Display Black', 'body': 'Circular Std Book', 'bold': 'Circular Std Bold'}


def _gradient(sh, g):
    """A drawn shape's two-stop gradient, at the SVG's angle: 20 degrees down to the right (python-pptx counts angles anticlockwise:
    its 20 tilted the slide's gradients up, the other way from the PNG, PDF and page)."""
    sh.fill.gradient(); sh.fill.gradient_angle = 340; st = sh.fill.gradient_stops
    st[0].color.rgb = RGBColor.from_string(g[0]); st[0].position = 0; st[1].color.rgb = RGBColor.from_string(g[1]); st[1].position = 1.0


def add_info(slide, d, warnings, where, chrome=False):
    """An infographic (infographic/info.py) in native shapes at its computed geometry - 120 canvas units to the inch, so the slide and the
    SVG / PNG / HTML draw the same picture. chrome=False on a template slide: the headline, logo and footer are the template's own."""
    from pptx.enum.dml import MSO_LINE
    U = 7620; X = lambda v: int(round(v * U)); PT = lambda fs: round(fs * 0.6, 1); small = []
    for e in d.get('els', []):
        if e.get('chrome') and not chrome: continue
        k = e['k']; nm = 'ULTA info ' + str(e.get('name', k))
        if k == 'rect':
            if e['w'] <= 0 or e['h'] <= 0: continue
            sh = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if e.get('r') else MSO_SHAPE.RECTANGLE, X(e['x']), X(e['y']), X(e['w']), X(e['h'])); sh.shadow.inherit = False; sh.name = nm
            if e.get('r'): sh.adjustments[0] = min(0.5, e['r'] / max(1, min(e['w'], e['h'])))
            if e.get('grad'): _gradient(sh, e['grad'])
            elif e.get('fill'): sh.fill.solid(); sh.fill.fore_color.rgb = RGBColor.from_string(e['fill'])
            else: sh.fill.background()
            if e.get('stroke'): sh.line.color.rgb = RGBColor.from_string(e['stroke']); sh.line.width = Pt(max(0.5, e.get('sw', 1) * 0.6))
            else: sh.line.fill.background()
        elif k == 'ellipse':
            sh = slide.shapes.add_shape(MSO_SHAPE.OVAL, X(e['x']), X(e['y']), X(e['w']), X(e['h'])); sh.shadow.inherit = False; sh.name = nm
            if e.get('grad'): _gradient(sh, e['grad'])   # v130: badges, dots and icon discs in the theme's gradient
            elif e.get('fill'):
                sh.fill.solid(); sh.fill.fore_color.rgb = RGBColor.from_string(e['fill'])
                if e.get('alpha'):   # see-through (Venn circles): PowerPoint's own fill transparency
                    from lxml import etree as _et
                    _et.set_default_parser(_et.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
                    clr = sh.fill._xPr.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}srgbClr')
                    if clr is not None: _et.SubElement(clr, '{http://schemas.openxmlformats.org/drawingml/2006/main}alpha', val=str(int(float(e['alpha']) * 100000)))
            else: sh.fill.background()
            if e.get('stroke'): sh.line.color.rgb = RGBColor.from_string(e['stroke']); sh.line.width = Pt(max(0.5, e.get('sw', 1) * 0.6))
            else: sh.line.fill.background()
        elif k == 'line':
            ln = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, X(e['x1']), X(e['y1']), X(e['x2']), X(e['y2'])); ln.name = nm
            ln.line.color.rgb = RGBColor.from_string(e['color']); ln.line.width = Pt(max(0.5, e.get('sw', 1) * 0.6))
            if e.get('dash'): ln.line.dash_style = MSO_LINE.DASH
            if e.get('arrow') or e.get('arrow_start'):   # a diagram flow: PowerPoint's own arrowhead on the connector
                from lxml import etree as _et
                _et.set_default_parser(_et.XMLParser(resolve_entities=False, no_network=True))   # never expand DTD entities (XXE, entity bombs)
                lnx = ln.line._get_or_add_ln(); A_ = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
                if e.get('arrow_start'): _et.SubElement(lnx, A_ + 'headEnd', type='triangle', w='med', len='med')
                if e.get('arrow'): _et.SubElement(lnx, A_ + 'tailEnd', type='triangle', w='med', len='med')
        elif k == 'poly':   # a chevron or any closed outline: a freeform shape at the points
            pts = e['pts']; fb = slide.shapes.build_freeform(X(pts[0][0]), X(pts[0][1]), scale=1.0)
            fb.add_line_segments([(X(px), X(py)) for px, py in pts[1:]], close=True); sh = fb.convert_to_shape(); sh.name = nm; sh.shadow.inherit = False
            if e.get('grad'): _gradient(sh, e['grad'])   # v139: stairs, chevrons, pyramid layers and roofs in the theme's gradient
            else: sh.fill.solid(); sh.fill.fore_color.rgb = RGBColor.from_string(e['fill'])
            if e.get('stroke'): sh.line.color.rgb = RGBColor.from_string(e['stroke']); sh.line.width = Pt(max(0.5, e.get('sw', 1) * 0.6))
            else: sh.line.fill.background()
        elif k == 'arc':
            r, sw = e['r'], e['sw']; size = 2 * r + sw; x0, y0 = e['cx'] - size / 2, e['cy'] - size / 2
            tr = slide.shapes.add_shape(MSO_SHAPE.DONUT, X(x0), X(y0), X(size), X(size)); tr.shadow.inherit = False; tr.name = nm + ' track'
            tr.adjustments[0] = sw / size; tr.fill.solid(); tr.fill.fore_color.rgb = RGBColor.from_string(e['track']); tr.line.fill.background()
            f = e['frac']
            if f >= 0.999:
                pr = slide.shapes.add_shape(MSO_SHAPE.DONUT, X(x0), X(y0), X(size), X(size)); pr.adjustments[0] = sw / size
            elif f > 0.002:
                pr = slide.shapes.add_shape(MSO_SHAPE.BLOCK_ARC, X(x0), X(y0), X(size), X(size))
                pr.adjustments[0] = 270 * 0.6; pr.adjustments[1] = ((270 + f * 360) % 360) * 0.6; pr.adjustments[2] = sw / size   # angles in 60000ths of a degree ÷ 100000
            else: pr = None
            if pr is not None:
                pr.shadow.inherit = False; pr.name = nm; pr.fill.solid(); pr.fill.fore_color.rgb = RGBColor.from_string(e['color']); pr.line.fill.background()
        elif k == 'text' and e.get('t'):
            tb = slide.shapes.add_textbox(X(e['x']), X(e['y']), X(e['w']), X(e['h'] + e['fs'] * 0.2)); tb.name = nm; tf = tb.text_frame; tf.word_wrap = True; tf.auto_size = MSO_AUTO_SIZE.NONE
            tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0; tf.vertical_anchor = MSO_ANCHOR.TOP
            p = tf.paragraphs[0]; p.alignment = {'left': PP_ALIGN.LEFT, 'center': PP_ALIGN.CENTER, 'right': PP_ALIGN.RIGHT}[e.get('align', 'left')]; p.line_spacing = round(e.get('lh', 1.2) / 1.2, 2)
            r_ = p.add_run(); r_.text = e['t']; r_.font.size = Pt(PT(e['fs'])); r_.font.name = INFO_FONTS.get(e.get('font'), 'Circular Std Book'); r_.font.color.rgb = RGBColor.from_string(e['color'])
            if PT(e['fs']) < 8 and e.get('name') not in ('source', 'footer'): small.append(e['t'][:24])
        elif k == 'icon':
            try:
                c = icon_catalog()[e['name']]; blob = open(os.path.join(ICON_DIR, e['name'] + '.svg'), 'rb').read()
            except Exception: continue
            col = e.get('color') or 'F26923'
            blob = re.sub(rb'(fill|stroke)="#(?!none)[0-9A-Fa-f]{3,6}"', b'\\1="#' + col.encode() + b'"', blob); blob = re.sub(rb'(fill|stroke):#[0-9A-Fa-f]{3,6}', b'\\1:#' + col.encode(), blob)
            if e.get('bold'):   # the same outline as the SVG: thin line pictograms read at slide size
                vbm = re.search(rb'viewBox="([^"]+)"', blob); vw = max(float(v) for v in vbm.group(1).split()[2:4]) if vbm else 100.0
                blob = re.sub(rb'\s(?:stroke="none"|stroke-width="[^"]*")', b'', blob)
                blob = re.sub(rb'<svg\b', b'<svg stroke="#' + col.encode() + b'" stroke-width="' + f'{vw * 0.045:.2f}'.encode() + b'" stroke-linejoin="round" stroke-linecap="round"', blob, count=1)
            w, h = c['w_in'], c['h_in']; s = e['s']; cw, ch = (s, s * h / w) if w >= h else (s * w / h, s)
            add_svg_pic(slide, f"icon-{e['name']}-{col}" + ("-b" if e.get("bold") else ""), blob, X(e['x'] + (s - cw) / 2), X(e['y'] + (s - ch) / 2), X(cw), X(ch), nm)
        elif k == 'image':   # the user's picture, as drawn in the SVG: cropped to fill (cover), corners rounded, its words for screen readers
            rec = ((d.get('spec') or {}).get('images') or {}).get(e.get('ref'))
            if not rec or e['w'] <= 0 or e['h'] <= 0: continue
            import io as _io
            sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'infographic'))
            import pictures as _P
            pic = slide.shapes.add_picture(_io.BytesIO(_P.raw(rec)), X(e['x']), X(e['y']), X(e['w']), X(e['h'])); pic.name = nm
            if e.get('fit') == 'cover':
                pic.crop_left, pic.crop_top, pic.crop_right, pic.crop_bottom = _P.crop(rec, e['w'], e['h'])
            if e.get('r'):
                A_ = '{http://schemas.openxmlformats.org/drawingml/2006/main}'; geom = pic._element.spPr.find(A_ + 'prstGeom')
                if geom is not None:
                    geom.set('prst', 'roundRect'); av = geom.find(A_ + 'avLst')
                    if av is None: av = etree.SubElement(geom, A_ + 'avLst')
                    etree.SubElement(av, A_ + 'gd', name='adj', fmla=f"val {int(min(50000, 100000 * e['r'] / max(1, min(e['w'], e['h']))))}")
            pic._element.nvPicPr.cNvPr.set('descr', str(e.get('alt') or 'Picture')[:250])
        elif k == 'logo':
            blob = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'infographic', 'ulta-logo.svg'), 'rb').read(); ar = 152.02 / 61.46
            cw, ch = (e['w'], e['w'] / ar) if e['w'] / e['h'] <= ar else (e['h'] * ar, e['h'])
            add_svg_pic(slide, 'ulta-logo', blob, X(e['x'] + (e['w'] - cw) / 2), X(e['y'] + (e['h'] - ch) / 2), X(cw), X(ch), 'ULTA info logo')
    if small: warnings.append(f'{where}: {len(small)} text line(s) under 8 pt on the slide (e.g. "{small[0]}") - the one-pager gives the content more room')


def info_pptx(d, out):
    """A one-pager or square infographic as its own PowerPoint page (the page is the infographic's size; Ulta fonts, palette and logo)."""
    prs = Presentation(); prs.slide_width = Emu(int(d['w'] * 7620)); prs.slide_height = Emu(int(d['h'] * 7620))
    slide = prs.slides.add_slide(prs.slide_layouts[6]); bg = slide.background.fill; bg.solid(); bg.fore_color.rgb = RGBColor.from_string(d.get('bg') or 'FFFFFF')
    warnings = []; add_info(slide, d, warnings, 'infographic', chrome=True)
    s = d.get('spec') or {}; notes = '\n'.join(x for x in (s.get('subtitle'), ('Source: ' + s['source']) if s.get('source') else '') if x)
    if notes: slide.notes_slide.notes_text_frame.text = notes
    prs.core_properties.title = s.get('title') or 'Infographic'; prs.save(out); return warnings


def drop_empty_placeholders(slide):
    """Remove text placeholders left with no text and no field (slide number, date, footer, unused bodies). PowerPoint shows an empty
    placeholder's prompt text while editing - the template's slide-number box on the three-card layout surfaced as "Slide Number"."""
    A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
    for sh in list(slide.shapes):
        if not sh.is_placeholder or not sh.has_text_frame: continue
        if sh.text_frame.text.strip() or sh._element.find('.//' + A + 'fld') is not None: continue
        sh._element.getparent().remove(sh._element)

def add_flow(slide, regions, steps, accent, warnings, where):
    """5–8 process steps on one slide: two rows of colour cards (number badge, title, icon) with a short description under each
    and a connector line per row - the template's steps look, denser. Drawn with native shapes below the headline / takeaway."""
    from pptx.enum.shapes import MSO_CONNECTOR
    title = regions.get('title'); n = len(steps)
    top0 = Inches(1.62); tk = next((sh for sh in slide.shapes if (sh.name or '') == 'ULTA takeaway'), None)
    if tk is not None and tk.top + tk.height > top0 - Inches(0.05): top0 = tk.top + tk.height + Inches(0.12)
    left, width = Inches(0.65), Inches(12.05); rows = 2 if n > 4 else 1; cols = -(-n // rows)
    avail = Inches(6.45) - top0; gap = Inches(0.28)
    card_w = (width - gap * (cols - 1)) / cols; card_h = Inches(1.15); desc_h = Inches(1.0); row_gap = Inches(0.3)
    used = rows * (card_h + desc_h + Inches(0.06)) + (rows - 1) * row_gap
    if used > avail: card_h = Inches(0.95); desc_h = (avail - rows * (card_h + Inches(0.06)) - (rows - 1) * row_gap) / rows
    top0 = top0 + max(0, (avail - used) / 2); row_h = card_h + desc_h + Inches(0.06) + row_gap   # the block sits centred in the free area
    for r in range(rows):
        y = top0 + r * row_h
        # connector line behind the row of cards, arrow head at the end
        ln = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, left, int(y + card_h / 2), left + width, int(y + card_h / 2))
        ln.line.color.rgb = RGBColor.from_string('000000'); ln.line.width = Pt(1.5); ln.name = f'ULTA flow line {r + 1}'
        ln.line._get_or_add_ln().append(etree.fromstring('<a:tailEnd xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" type="triangle" w="med" len="med"/>'))
        for c in range(cols):
            k = r * cols + c
            if k >= n: break
            st = steps[k]; x = left + c * (card_w + gap); color = FLOW_COLORS[k % len(FLOW_COLORS)]
            card = _rect(slide, int(x), int(y), int(card_w), int(card_h), color)
            _txt(card, str(st.get('title', '')), 13 if n <= 6 else 12, bold=True, color='FFFFFF', font=FONT_HEAD, align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE)
            card.text_frame.margin_left = card.text_frame.margin_right = Inches(0.45)
            badge = slide.shapes.add_shape(MSO_SHAPE.OVAL, int(x + Inches(0.08)), int(y + Inches(0.08)), Inches(0.36), Inches(0.36))
            badge.fill.solid(); badge.fill.fore_color.rgb = RGBColor.from_string('000000'); badge.line.fill.background(); badge.shadow.inherit = False
            _txt(badge, str(k + 1), 11, bold=True, color='FFFFFF', align=PP_ALIGN.CENTER, anchor=MSO_ANCHOR.MIDDLE); badge.text_frame.margin_left = badge.text_frame.margin_right = 0; badge.name = f'ULTA flow badge {k + 1}'
            ic = pick_icon(str(st.get('title', '')) + ' ' + str(st.get('text', '')))
            if ic:
                try: add_icon(slide, ic, int(x + card_w - Inches(0.44)), int(y + Inches(0.1)), Inches(0.3), white=True)
                except Exception: pass
            box = slide.shapes.add_textbox(int(x), int(y + card_h + Inches(0.06)), int(card_w), int(desc_h))
            _txt(box, str(st.get('text', '')), 10.5 if n <= 6 else 10, color='404040', align=PP_ALIGN.CENTER)
            box.text_frame.margin_left = box.text_frame.margin_right = Inches(0.05)
            box.name = f'ULTA flow {k + 1}'; card.name = f'ULTA flow card {k + 1}'
    warnings.append(f'{where}: {n} process steps drawn as a two-row flow' if rows == 2 else f'{where}: {n} process steps drawn as a flow')


def add_callout(slide, box_shape, text, accent):
    """Tinted strip at the bottom of a box: Decision / Ask / Next step. The box text gets a bottom inset so it never runs under it."""
    h = Inches(0.78); m = Inches(0.18)
    strip = _rect(slide, box_shape.left + m, box_shape.top + box_shape.height - h - m, box_shape.width - 2 * m, h, accent_hex(accent))
    label, _, rest = str(text).partition(':')
    if not rest: label, rest = 'Key', text
    _txt(strip, [f'**{label.strip().upper()}**  {rest.strip()}'], 12, color='FFFFFF', font=FONT_BODY, anchor=MSO_ANCHOR.MIDDLE)
    strip.name = 'ULTA callout'
    box_shape.text_frame.margin_bottom = h + m + Inches(0.05)


def add_band(slide, box_shape, label, hex_fill):
    """Coloured header band on a box (Before / After, Pros / Cons …); box text starts below the band."""
    h = Inches(0.5)
    band = _rect(slide, box_shape.left, box_shape.top, box_shape.width, h, hex_fill, rounded=True)
    try:   # same corner radius as the box it sits on
        box_adj = box_shape.adjustments[0] if len(box_shape.adjustments) else 0.16
        band.adjustments[0] = min(0.5, box_adj * min(box_shape.width, box_shape.height) / min(band.width, band.height))
    except Exception: pass
    _txt(band, str(label), 14, bold=True, color='FFFFFF', font=FONT_HEAD, anchor=MSO_ANCHOR.MIDDLE, caps=True, spc=120)
    band.name = 'ULTA band'
    box_shape.text_frame.margin_top = h + Inches(0.15)
    # keep the rounded corners: clip the band under the box by sending it just above the box in z-order
    box_el = box_shape._element; box_el.addnext(band._element)


def add_divider_extras(slide, regions, agenda, current, icon, accent):
    """Divider slide: agenda list on the right with the current section highlighted, and one large section icon."""
    if agenda:
        n = len(agenda); pitch = 0.42 if n <= 8 else 0.36; box = slide.shapes.add_textbox(Inches(7.6), Inches(1.6), Inches(5.2), Inches(pitch * n + 0.3))
        tf = box.text_frame; tf.word_wrap = True; first = True
        for i, name in enumerate(agenda, 1):
            p = tf.paragraphs[0] if first else tf.add_paragraph(); first = False
            r = p.add_run(); r.text = f'{i}   {name}'; r.font.size = Pt((16 if i == current else 14) if n <= 8 else (14 if i == current else 12)); r.font.name = FONT_HEAD if i == current else FONT_BODY
            r.font.bold = (i == current); r.font.color.rgb = RGBColor.from_string('FFFFFF')
            p.space_after = Pt(6 if n <= 8 else 3)
            if i != current:
                r.font.color.rgb = RGBColor.from_string('FDE1D2')
        box.name = 'ULTA agenda'
    if icon and icon in icon_catalog():
        add_icon(slide, icon, Inches(11.55), Inches(0.55), Inches(1.0), white=True)


def status_dot(text):
    """Table-cell status words -> coloured dot + word (Done / On track / At risk / Blocked …): the template's status
    colours (slides 11 and 21) on the dot only - the word stays in the text colour."""
    s = str(text).strip(); low = s.lower()
    for words, hexv in ((('done', 'complete', 'completed', 'on track', 'green', 'closed', 'approved', 'live'), '00B050'),
                        (('at risk', 'amber', 'yellow', 'in progress', 'pending', 'delayed', 'partial'), 'FFC000'),
                        (('blocked', 'red', 'off track', 'late', 'failed', 'open issue', 'not started', 'rejected'), 'FF0000')):
        if low in words or any(low.startswith(w + ' ') for w in words):
            return f'{{#{hexv}}}●{{/}} {s}'
    return text


# ----------------------------------------------------------------------------- slide copy / order
def duplicate_slide(prs, src):
    if any('CHART' in str(sh.shape_type) for sh in src.shapes):
        raise SystemExit(f'source slide with a chart cannot be used twice (chart parts are not duplicated); use it once.')
    new = prs.slides.add_slide(src.slide_layout)
    for sh in list(new.shapes):
        sh._element.getparent().remove(sh._element)
    rid_map = {}
    skip_types = ('/slideLayout', '/notesSlide', '/oleObject', '/tags', '/vmlDrawing', '/package')
    for rel in src.part.rels.values():
        if rel.reltype.endswith(skip_types):
            continue
        if rel.is_external:
            new_rid = new.part.rels.get_or_add_ext_rel(rel.reltype, rel.target_ref)
        else:
            new_rid = new.part.rels.get_or_add(rel.reltype, rel._target)
        rid_map[rel.rId] = new_rid
    src_tree = src.shapes._spTree
    dst_tree = new.shapes._spTree
    src_grp = src_tree.find('p:grpSpPr', NS); dst_grp = dst_tree.find('p:grpSpPr', NS)
    if src_grp is not None and dst_grp is not None:
        dst_tree.replace(dst_grp, copy.deepcopy(src_grp))
    for el in src_tree:
        tag = el.tag.split('}')[-1]
        if tag in ('nvGrpSpPr', 'grpSpPr'):
            continue
        if el.find('.//p:oleObj', NS) is not None:
            continue  # hidden embedded OLE helpers (think-cell etc.) are not duplicated; they are invisible and per-slide
        clone = copy.deepcopy(el)
        for node in clone.iter():
            for attr in R_ATTRS:
                if attr in node.attrib and node.attrib[attr] in rid_map:
                    node.attrib[attr] = rid_map[node.attrib[attr]]
        dst_tree.append(clone)
    # copy slide-level extras (transitions, timing, background) except the shape tree
    src_sld = src._element; dst_sld = new._element
    src_cSld = src_sld.find('p:cSld', NS); dst_cSld = dst_sld.find('p:cSld', NS)
    bg = src_cSld.find('p:bg', NS)
    if bg is not None:
        dst_cSld.insert(0, copy.deepcopy(bg))
    return new


def reorder_and_prune(prs, keep_slides):
    sldIdLst = prs.slides._sldIdLst
    id_by_slide = {}
    for sldId in list(sldIdLst):
        id_by_slide[prs.part.related_part(sldId.rId)] = sldId
    keep_parts = [s.part for s in keep_slides]
    for sldId in list(sldIdLst):
        part = prs.part.related_part(sldId.rId)
        if part not in keep_parts:
            prs.part.drop_rel(sldId.rId)
            sldIdLst.remove(sldId)
    for s in keep_slides:
        sldId = id_by_slide[s.part]
        sldIdLst.remove(sldId); sldIdLst.append(sldId)


# ----------------------------------------------------------------------------- main
def load_templates(tdir):
    man = json.load(open(os.path.join(tdir, 'manifest.json'), encoding='utf-8'))
    return man


PALETTE = {'orange': 'EE6C37', 'red': 'E9341C', 'pink': 'E8275A', 'magenta': 'D01381', 'berry': '5D0F43', 'black': '000000', 'grey': '404040', 'white': 'FFFFFF'}
_TOK = re.compile(r'(\*\*.+?\*\*|(?<!\w)_(?=\S).+?(?<=\S)_(?!\w)|\{(?:#[0-9A-Fa-f]{6}|[a-z]+)\}.*?\{/\})', re.S)


def parse_inline(text):
    """'**bold**, _italic_, {orange}colour{/}' -> [(segment, {'b':bool,'i':bool,'color':hex|None}), …]"""
    out = []
    for part in _TOK.split(str(text)):
        if not part: continue
        if part.startswith('**') and part.endswith('**') and len(part) > 4:
            out.append((part[2:-2], {'b': True}))
        elif part.startswith('_') and part.endswith('_') and len(part) > 2:
            out.append((part[1:-1], {'i': True}))
        elif part.startswith('{') and part.endswith('{/}'):
            key, body = part[1:].split('}', 1); body = body[:-3]
            hexv = key[1:] if key.startswith('#') else PALETTE.get(key)
            for seg, fmt in parse_inline(body):                      # colour may wrap **bold** / _italic_
                out.append((seg, dict(fmt, color=hexv.upper()) if hexv else fmt))
        else:
            out.append((part, {}))
    return out


def strip_markdown(v):
    """Backticks are dropped (no code style on slides); bold/italic/colour markup is kept for set_paragraphs."""
    if isinstance(v, str):
        return re.sub(r'`(.+?)`', r'\1', v)
    if isinstance(v, list):
        return [strip_markdown(x) for x in v]
    if isinstance(v, dict):
        return {k: strip_markdown(x) for k, x in v.items()}
    return v


KIT_PART = 'ppt/ulta-kit.json'
KIT_REL = 'http://ulta.com/relationships/kit-marker'


def embed_marker(path, spec):
    """Write a small JSON part into the saved .pptx (its own content type and a relationship from the presentation, so Office keeps the package
    valid and ignores it): which section got which layout, the deck title, template and style. A deck edited in PowerPoint and uploaded again
    with 'Keep the slide structure' off is re-read from its text, and these hints put the chosen layouts back."""
    import zipfile
    hints = {}
    for s in spec.get('slides') or []:
        sec = str(s.get('sec') or '').strip(); hint = None
        if s.get('graphic'): hint = (s['graphic'] or {}).get('kind')
        elif s.get('flow'): hint = 'steps'
        elif s.get('bands'): hint = 'bands'
        elif s.get('source') in (7,): hint = 'cards'
        elif s.get('source') in (12,) and s.get('cards'): hint = 'table'
        elif s.get('source') in (20,): hint = 'steps'
        if sec and hint and sec not in hints: hints[sec] = hint
    marker = json.dumps({'builder': 'ULTA Presentation Central', 'title': spec.get('title'), 'template': spec.get('template'), 'theme': spec.get('theme'), 'hints': hints}, ensure_ascii=False)
    tmp = path + '.tmp'
    with zipfile.ZipFile(path) as zin, zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == '[Content_Types].xml' and b'ulta-kit.json' not in data:
                data = data.replace(b'</Types>', b'<Override PartName="/ppt/ulta-kit.json" ContentType="application/json"/></Types>')
            elif item.filename == 'ppt/_rels/presentation.xml.rels' and b'kit-marker' not in data:
                data = data.replace(b'</Relationships>', f'<Relationship Id="rIdUltaKit" Type="{KIT_REL}" Target="ulta-kit.json"/></Relationships>'.encode())
            if item.filename == KIT_PART: continue
            zout.writestr(item, data)
        zout.writestr(KIT_PART, marker.encode('utf-8'))
    os.replace(tmp, path)


def sha256(path):
    return hashlib.sha256(open(path, 'rb').read()).hexdigest()


INK = '000000'
def _lum(h):
    try: r, g, b = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    except Exception: return None   # noqa: BLE001
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
def _contrast(a, b):
    la, lb = _lum(a), _lum(b)
    if la is None or lb is None: return 21
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)
def _scheme_map(prs, slide=None):
    """scheme colour name → hex, from the theme of the master the slide uses (v6.10: the Ulta template has two masters with different
    colour themes - the content slides use the second, whose accent2 is magenta D01381, not the first's plum 5D0F43). No slide: the
    master most slides use."""
    out = {}
    try:
        from pptx.opc.constants import RELATIONSHIP_TYPE as RT
        if slide is not None: master = slide.slide_layout.slide_master
        else:
            from collections import Counter
            cnt = Counter(id(s.slide_layout.slide_master) for s in prs.slides); ms = {id(m): m for m in prs.slide_masters}
            master = ms.get(cnt.most_common(1)[0][0]) if cnt else prs.slide_masters[0]
        th = master.part.part_related_by(RT.THEME); root = etree.fromstring(th.blob)
        cs = root.find('.//a:clrScheme', NS)
        for el in cs:
            name = etree.QName(el).localname; c = el.find('a:srgbClr', NS); s = el.find('a:sysClr', NS)
            out[name] = (c.get('val') if c is not None else s.get('lastClr', '000000')).upper()
    except Exception:   # noqa: BLE001
        pass
    alias = {'tx1': 'dk1', 'tx2': 'dk2', 'bg1': 'lt1', 'bg2': 'lt2'}
    for k, v in alias.items():
        if v in out: out[k] = out[v]
    return out


def apply_theme(prs, theme):
    """Restyle the brand-coloured elements of the infographic slides after a design system (themes.THEMES): fills, lines, corner radius,
    shadow. The template's typography, layout and cover / dividers are untouched; the contrast pass that follows keeps text readable."""
    import themes as TH
    t = TH.THEMES[TH.resolve(theme)]
    if t['fill'] == 'keep' and not t['line'] and t['radius'] is None and not t['shadow']: return 0
    A = '{%s}' % NS['a']; scheme = dict(_scheme_map(prs)); n = 0
    def brand_hex(fill_el):
        c = fill_el.find('a:srgbClr', NS); s = fill_el.find('a:schemeClr', NS)
        if c is not None: return c.get('val').upper() if c.get('val').upper() in TH.BRAND else None
        if s is not None and (s.get('val', '').startswith('accent') or s.get('val') in ('tx2', 'dk2')): return scheme.get(s.get('val'), 'EE6C37')
        return None
    def restyle(pr, fill_el, hexv, is_cell):
        nonlocal n
        if t['fill'] in ('velvet', 'sunset'):   # a two-stop gradient in the element's own colour
            grad = etree.Element(A + 'gradFill', rotWithShape='1'); gl = etree.SubElement(grad, A + 'gsLst')
            for pos, col in (((0, TH.INK), (100000, hexv)) if t['fill'] == 'velvet' else ((0, hexv), (100000, TH.GOLD))):
                gs = etree.SubElement(gl, A + 'gs', pos=str(pos)); etree.SubElement(gs, A + 'srgbClr', val=col)
            etree.SubElement(grad, A + 'lin', ang='2700000' if t['fill'] == 'velvet' else '1800000', scaled='0')
            fill_el.addnext(grad); parent = fill_el.getparent(); parent.remove(fill_el); fill_el = grad
        else:
            new = hexv if t['fill'] == 'keep' else 'FFFFFF' if t['fill'] == 'white' else TH.tint(hexv, t.get('tint', 0.85)) if t['fill'] == 'tint' else TH.INK
            for ch in list(fill_el): fill_el.remove(ch)
            etree.SubElement(fill_el, A + 'srgbClr', val=new)
        if not is_cell:
            for old in pr.findall('a:ln', NS): pr.remove(old)
            ln = etree.Element(A + 'ln')
            if t['line']:
                col, w = t['line']; ln.set('w', str(int(w * 12700))); sf = etree.SubElement(ln, A + 'solidFill'); etree.SubElement(sf, A + 'srgbClr', val=hexv if col == 'brand' else col)
            else:
                etree.SubElement(ln, A + 'noFill')
            fill_el.addnext(ln)
            for old in pr.findall('a:effectLst', NS): pr.remove(old)
            if t['shadow']:
                glow = t['shadow'] == 'brand'
                ef = etree.Element(A + 'effectLst'); sh = etree.SubElement(ef, A + 'outerShdw', blurRad='114300' if glow else '63500', dist='38100' if glow else '25400', dir='5400000', algn='ctr', rotWithShape='0'); c = etree.SubElement(sh, A + 'srgbClr', val=hexv if glow else '000000'); etree.SubElement(c, A + 'alpha', val='38000' if glow else '22000')
                ln.addnext(ef)
            geom = pr.find('a:prstGeom', NS)
            if geom is not None and geom.get('prst') == 'roundRect' and t['radius'] is not None:
                av = geom.find('a:avLst', NS)
                if av is None: av = etree.SubElement(geom, A + 'avLst')
                for g in list(av): av.remove(g)
                etree.SubElement(av, A + 'gd', name='adj', fmla=f'val {int(t["radius"])}')
        else:
            if t['line'] and t['fill'] == 'white':
                col, w = t['line']
                for side in ('lnL', 'lnR', 'lnT', 'lnB'):
                    for old in pr.findall('a:' + side, NS): pr.remove(old)
                    ln = etree.Element(A + side); ln.set('w', str(int(w * 12700))); sf = etree.SubElement(ln, A + 'solidFill'); etree.SubElement(sf, A + 'srgbClr', val=hexv if col == 'brand' else col)
                    pr.insert(0, ln)
        n += 1
    for slide in prs.slides:
        scheme.clear(); scheme.update(_scheme_map(prs, slide))   # this slide's master's colours
        for sh in slide.shapes:
            el = sh._element
            if getattr(sh, 'has_table', False) and sh.has_table:
                tp = el.find('.//a:tblPr', NS); trs = el.findall('.//a:tr', NS)
                if tp is not None and tp.get('firstRow') == '1' and trs:   # header cells coloured by the table style (accent1): give them that fill explicitly, so the theme restyles them too
                    for tc in trs[0].findall('a:tc', NS):
                        pr = tc.find('a:tcPr', NS)
                        if pr is not None and not any(pr.find('a:' + k, NS) is not None for k in ('solidFill', 'noFill', 'gradFill', 'blipFill', 'pattFill')) and ''.join(tc.itertext()).strip():
                            sf = etree.Element(A + 'solidFill'); etree.SubElement(sf, A + 'schemeClr', val='accent1'); pr.append(sf)
                if t['fill'] in ('white', 'tint') and trs:   # header icons are white on the brand colour; on a light theme they take the cell's colour, or they vanish
                    xs = [sh.left]; [xs.append(xs[-1] + c.width) for c in sh.table.columns]
                    cols = [brand_hex(tc.find('a:tcPr/a:solidFill', NS)) if tc.find('a:tcPr/a:solidFill', NS) is not None else None for tc in trs[0].findall('a:tc', NS)]
                    for pic in header_pictures(slide, sh):
                        j = max(0, min(len(cols) - 1, next((k for k in range(len(cols)) if xs[k] <= pic.left < xs[k + 1]), 0)))
                        nm = (pic.name or '').replace('ULTA icon ', '').strip(); hexv = cols[j] if j < len(cols) else None
                        blip = pic._element.find('.//{http://schemas.microsoft.com/office/drawing/2016/SVG/main}svgBlip')
                        if hexv and nm in icon_catalog() and blip is not None:
                            blip.set('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed', svg_part(slide, nm, color=hexv))
                for tc in el.findall('.//a:tc', NS):
                    pr = tc.find('a:tcPr', NS); f = pr.find('a:solidFill', NS) if pr is not None else None
                    if f is not None:
                        hx = brand_hex(f)
                        if hx: restyle(pr, f, hx, True)
                continue
            pr = el.find('p:spPr', NS); f = pr.find('a:solidFill', NS) if pr is not None else None
            if f is None: continue
            if sh.name and sh.name.startswith(('ULTA takeaway',)): continue   # the takeaway keeps its accent
            hx = brand_hex(f)
            if hx: restyle(pr, f, hx, False)
    return n


def ensure_contrast(prs):
    """Readable text on every solid fill: a run that inherits its colour, or whose colour sits under 4.5:1 against the shape's or
    cell's fill (3:1 from 18 pt; bold earns no allowance - a viewer without the template's font draws it regular), turns white
    where white reads, else ink. When a box's words had to turn ink, its other white words follow: one box, one colour.
    Runs the template already colours readably are left alone."""
    A = '{%s}' % NS['a']; fixed = 0
    def paint(rpr, hexv):
        for old in rpr.findall('a:solidFill', NS): rpr.remove(old)
        fill_el = etree.Element(A + 'solidFill'); etree.SubElement(fill_el, A + 'srgbClr', val=hexv)
        ln = rpr.find('a:ln', NS); (ln.addnext(fill_el) if ln is not None else rpr.insert(0, fill_el))
    def fix_runs(holder, fill):
        nonlocal fixed
        seen, dark = [], False
        for r in holder.findall('.//a:r', NS):
            if (r.findtext('a:t', namespaces=NS) or '').strip() in ('\u25cf', '\u25a0', '\u25b2', '\u25bc', '\u25c6', '\u2022'): continue   # a status dot is a mark, not words
            rpr = r.find('a:rPr', NS)
            if rpr is None: rpr = r.makeelement(A + 'rPr', {}); r.insert(0, rpr)
            need = 3.0 if int(rpr.get('sz') or 0) >= 1800 else 4.5
            cur = rpr.find('a:solidFill/a:srgbClr', NS); hexv = cur.get('val').upper() if cur is not None else None
            if cur is None and rpr.find('a:solidFill/a:schemeClr', NS) is not None:   # a scheme colour: the template's choice, if it reads
                hexv = SCHEME.get(rpr.find('a:solidFill/a:schemeClr', NS).get('val'))
                if not hexv: continue
            elif cur is None and rpr.find('a:solidFill/a:prstClr', NS) is not None:   # a preset colour ("white"): checked like any other
                hexv = {'white': 'FFFFFF', 'black': '000000'}.get(rpr.find('a:solidFill/a:prstClr', NS).get('val'))
                if not hexv: continue
            elif cur is None and rpr.find('a:solidFill', NS) is not None: continue
            seen.append((rpr, need))
            if hexv and _contrast(fill, hexv) >= need: continue
            want = 'FFFFFF' if _contrast(fill, 'FFFFFF') >= need else INK if _contrast(fill, INK) >= need else \
                max(('FFFFFF', INK), key=lambda c: _contrast(fill, c))
            paint(rpr, want); fixed += 1; dark |= want == INK
        if dark:
            for rpr, need in seen:
                cur = rpr.find('a:solidFill/a:srgbClr', NS)
                if cur is not None and cur.get('val').upper() == 'FFFFFF' and _contrast(fill, INK) >= need: paint(rpr, INK); fixed += 1
    SCHEME = {}
    for slide in prs.slides:
        SCHEME.clear(); SCHEME.update(_scheme_map(prs, slide))
        for sh in slide.shapes:
            el = sh._element
            def darkest(pr):
                sf = pr.find('a:solidFill/a:srgbClr', NS) if pr is not None else None
                if sf is not None: return sf.get('val')
                sc = pr.find('a:solidFill/a:schemeClr', NS) if pr is not None else None
                if sc is not None: return None if len(sc) else SCHEME.get(sc.get('val'))   # a theme colour, as the slide's master defines it
                gs = pr.findall('a:gradFill/a:gsLst/a:gs/a:srgbClr', NS) if pr is not None else []
                return min((g.get('val') for g in gs), key=lambda h: _lum(h) or 0) if gs else None   # a gradient reads as its darker stop
            if sh.name.startswith('ULTA info '): continue   # drawn by the infographic engine: judged there, in the colours the files get
            if sh.has_text_frame and sh.text_frame.text.strip():
                hx = darkest(el.find('p:spPr', NS))
                if hx: fix_runs(el.find('p:txBody', NS), hx)
            if getattr(sh, 'has_table', False) and sh.has_table:
                for tc in el.findall('.//a:tc', NS):
                    hx = darkest(tc.find('a:tcPr', NS))
                    if hx and ''.join(tc.itertext()).strip(): fix_runs(tc.find('a:txBody', NS), hx)
    return fixed


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('spec', nargs='?')
    ap.add_argument('--templates', required=True, help='ultatemplatelibrary/templates directory (has manifest.json)')
    ap.add_argument('--out'); ap.add_argument('--map', metavar='TEMPLATE_ID'); ap.add_argument('--markdown', action='store_true')
    a = ap.parse_args()
    man = load_templates(a.templates)

    def open_template(tid):
        entry = man['templates'][tid]
        path = os.path.join(a.templates, entry['file'])
        actual = sha256(path)
        if actual != entry['sha256']:
            raise SystemExit(f'TEMPLATE BINARY UNAVAILABLE: {tid} hash {actual} != pinned {entry["sha256"]}')
        return Presentation(path), entry, actual

    if a.map:
        prs, entry, _ = open_template(a.map.upper())
        desc = describe(prs)
        if a.markdown:
            print(f'# {a.map.upper()} - {entry["file"]} ({entry["slides"]} slides)\n')
            for d in desc:
                print(f'## Slide {d["source"]}' + (' (chart - use once)' if d['has_chart'] else ''))
                for k, v in d['regions'].items():
                    if v['kind'] == 'table':
                        print(f'- `{k}`: table {v["rows"]}×{v["cols"]} - header {v["sample"][0] if v["sample"] else ""}')
                    else:
                        print(f'- `{k}`: text ({v["paragraphs"]} para) - "{v["sample"]}"')
                print()
        else:
            print(json.dumps({'template': a.map.upper(), 'slides': desc}, indent=1, ensure_ascii=False))
        return

    if not a.spec or not a.out:
        raise SystemExit('need spec.json and --out (or --map)')
    spec = json.load(open(a.spec, encoding='utf-8'))
    spec = strip_markdown(spec)  # agents sometimes emit **bold** / `code`; templates carry their own styling
    global HEADING_STYLE
    HEADING_STYLE = (spec.get('heading_style') or man.get('heading_style') or 'bar')
    tid = spec['template'].upper()
    prs, entry, thash = open_template(tid)
    src_slides = list(prs.slides)
    used = set(); out_slides = []; warnings = WARN
    # make every needed duplicate from the pristine template slide BEFORE any text is replaced
    from collections import Counter
    counts = Counter(int(sd['source']) for sd in spec['slides'])
    spare = {}
    for n, k in counts.items():
        if not 1 <= n <= len(src_slides):
            raise SystemExit(f'source {n} out of range 1..{len(src_slides)}')
        spare[n] = [duplicate_slide(prs, src_slides[n - 1]) for _ in range(k - 1)]
    for i, sd in enumerate(spec['slides'], 1):
        n = int(sd['source'])
        src = src_slides[n - 1]
        slide = src if n not in used else spare[n].pop(0)
        used.add(n)
        regions = slide_regions(slide)
        global ACCENT
        ACCENT = accent_hex(sd.get('accent'))
        fills = no_orphan_heading(dict(sd.get('fills', {})))
        keep = set(sd.get('keep_unfilled', []))
        if '*' in keep: keep = set(regions)          # form templates: untouched cells keep their prompts
        for key, val in fills.items():
            if key not in regions:
                raise SystemExit(f'slide {i} (source {n}): unknown region "{key}". Available: {sorted(regions)}')
            sh = regions[key]
            if sh.has_table:
                val = [list(r) for r in val] if val else val
                for r_i, row in enumerate(val or []):
                    if r_i: val[r_i] = [status_dot(c) if isinstance(c, str) else c for c in row]
                tpl_header = [c.text.strip().lower() for c in sh.table.rows[0].cells]
                if sd.get('grow_rows') and len(val) > len(sh.table.rows): grow_rows(sh, min(len(val), 12), header=sd.get('kind') != 'agenda')
                fill_table(sh, val, f'slide {i} (source {n}) {key}')
                if sd.get('trim_empty_rows') and len(val) < len(sh.table.rows):
                    trim_rows(sh, max(len(val), 1))
                grew = False
                if sd.get('trim_empty_cols') and val:
                    ncols_used = max((max((c for c, cell in enumerate(row) if str(cell).strip()), default=-1) for row in val), default=-1) + 1
                    if ncols_used and ncols_used < len(sh.table.columns): trim_cols(sh, ncols_used); grew = True
                    if sd.get('label_col_in') and len(sh.table.columns) >= 2:   # short labels (numbers) do not need half the slide
                        tbl_ = sh.table; total_ = sum(c.width for c in tbl_.columns); first = int(float(sd['label_col_in']) * 914400)
                        tbl_.columns[0].width = first; rest = (total_ - first) // (len(tbl_.columns) - 1)
                        for c in list(tbl_.columns)[1:]: c.width = rest
                if val and [str(c).strip().lower() for c in val[0]] != tpl_header[:len(val[0])]:
                    drop_header_icons(slide, sh)   # the template's header pictograms belong to its own column names
                if val and len(val) > 1 and sh.table.rows[0].height < 1097280: fit_table(sh, prs.slide_height, warnings, f'slide {i}', grow=grew)
                if sd.get('kind') == 'agenda': agenda_rows_alike(sh)
                elif val and len(val) > 1: tidy_table(sh)
                if sd.get('cells_left') and val and len(val) > 1:   # several points in a cell read as a left-aligned list, not a centred block
                    for r_ in list(sh.table.rows)[1:]:
                        for c_ in list(r_.cells)[1:]:
                            for p_ in c_.text_frame.paragraphs: p_.alignment = PP_ALIGN.LEFT; p_.space_after = Pt(4)
                    body_ = list(sh.table.rows)[1:]
                    if len(body_) <= 3:   # one or two topics: the rows share the slide's height instead of leaving its lower half empty
                        room_ = int(prs.slide_height * 0.80) - sh.top - sh.table.rows[0].height
                        each_ = min(int(2.2 * 914400), room_ // max(1, len(body_)))
                        for r_ in body_:
                            if r_.height < each_: r_.height = Emu(each_)
                            for c_ in list(r_.cells)[1:]: c_.vertical_anchor = MSO_ANCHOR.MIDDLE
            else:
                set_paragraphs(sh.text_frame, val)
                if key == 'title' and n != 1 and sd.get('fit_headline', True):
                    fit_headline(slide, sh, val, warnings, f'slide {i}')
                if key == 'title' and n == 1:
                    fit_cover_title(sh, str(val), warnings, f'slide {i}')
                if entry.get('roles', {}).get('divider') == n and key == 'text2':
                    if sd.get('agenda') and sh.left + sh.width > Emu(7.3 * 914400): sh.width = Emu(int(7.3 * 914400) - sh.left)   # keep clear of the agenda list
                    fit_divider_name(sh, str(val), warnings, f'slide {i}')
        for key in sd.get('hide', []):
            if key not in regions:
                raise SystemExit(f'slide {i} (source {n}): unknown region "{key}" in hide')
            gone = regions.pop(key); fills.pop(key, None)
            # a text box beside the removed one grows into its space (two-column slide -> one wide box)
            for other in regions.values():
                if other.has_text_frame and not other.has_table and abs(other.top - gone.top) < 91440 and abs(other.height - gone.height) < 91440:
                    lo, hi = min(other.left, gone.left), max(other.left + other.width, gone.left + gone.width)
                    other.left, other.width = lo, hi - lo
            gone._element.getparent().remove(gone._element)
        if entry.get('roles', {}).get('steps4') == n:
            layout_steps(slide, regions, fills, f'slide {i}', warnings)
        if sd.get('icons'):
            apply_icons(slide, regions, fills, sd['icons'], f'slide {i}', warnings)
        accent = sd.get('accent') or 'orange'
        for key, label in (sd.get('bands') or {}).items():        # contrast bands (Before / After …)
            if key in regions and not regions[key].has_table:
                add_band(slide, regions[key], label, PALETTE['grey'] if key == 'text1' else accent_hex(accent))
        for key, text in (sd.get('callouts') or {}).items():      # Decision / Ask strips inside boxes
            if key in regions and not regions[key].has_table and str(text).strip():
                add_callout(slide, regions[key], text, accent)
        if sd.get('takeaway'):
            add_takeaway(slide, regions, sd['takeaway'], accent, warnings, f'slide {i}')
        if sd.get('flow'):
            add_flow(slide, regions, sd['flow'], accent, warnings, f'slide {i}')
        if sd.get('graphic'):
            add_graphic(slide, regions, sd['graphic'], accent, warnings, f'slide {i}')
        if sd.get('board'):
            add_board(slide, sd['board'], warnings, f'slide {i}')
        if sd.get('screen'):
            add_screen(slide, sd['screen'], warnings, f'slide {i}')
        if sd.get('info'):
            add_info(slide, sd['info'], warnings, f'slide {i}')
        drop_empty_placeholders(slide)   # an empty placeholder shows its prompt ("Slide Number", "Click to add text") in PowerPoint's editor
        if sd.get('wide_image') and 'text1' in regions:
            add_wide_image(slide, regions, fills, sd['wide_image'], warnings, f'slide {i}')
        for key, ipath in (sd.get('images') or {}).items():            # pictures inside boxes (restyled decks)
            if key in regions and not regions[key].has_table: add_image(slide, regions[key], ipath, warnings, f'slide {i} {key}')
        for key, cspec in (sd.get('charts') or {}).items():            # native charts inside boxes
            if key in regions and not regions[key].has_table:
                add_chart(slide, regions[key], cspec, accent, warnings, f'slide {i} {key}')
            else:
                warnings.append(f'slide {i}: no text box "{key}" for the chart')
        if entry.get('roles', {}).get('divider') == n and (sd.get('agenda') or sd.get('icon')):
            ic = sd.get('icon'); ic = pick_icon(fills.get('text2') or fills.get('text1') or '') if ic == 'auto' else ic
            add_divider_extras(slide, regions, sd.get('agenda'), sd.get('current'), ic, accent)
        if sd.get('text_pt'):
            # the converter chose one body size for the deck (11 / 12 pt when packed tighter, 16 / 18 pt when every box has room): scale every run in text1/text2 from the template's 14 pt
            for key in ('text1', 'text2'):
                sh = regions.get(key)
                if sh is None or sh.has_table or key not in fills: continue
                for para in sh.text_frame.paragraphs:
                    for r in para.runs:
                        rpr = r._r.get_or_add_rPr(); base = int(rpr.get('sz') or 1400)
                        rpr.set('sz', str(int(round(base * float(sd['text_pt']) / 14.0 / 100)) * 100))
            if not any('the deck\'s one body size' in w for w in warnings): warnings.append(f'text slides at {sd["text_pt"]} pt - the deck\'s one body size')
        if sd.get('clean_runs') or sd.get('table_font_pt'):
            # form templates: prompts carry strike/underline/link styling that must not leak into answers; optional uniform size
            for key in fills:
                sh = regions.get(key)
                if sh is None: continue
                frames = [c.text_frame for r in list(sh.table.rows)[1:] for c in r.cells if not c.is_spanned] if sh.has_table else [sh.text_frame]   # header row keeps its size
                for tf in frames:
                    for para in tf.paragraphs:
                        ppr = para._p.find('a:pPr', NS)
                        if sd.get('clean_runs') and ppr is not None and ppr.get('lvl'): ppr.attrib.pop('lvl')   # answers all at one level
                        for r in para.runs:
                            rpr = r._r.find('a:rPr', NS)
                            if rpr is None: continue
                            if sd.get('clean_runs'):
                                for att in ('strike', 'u'): rpr.attrib.pop(att, None)
                                for h in rpr.findall('a:hlinkClick', NS): rpr.remove(h)
                            if sd.get('table_font_pt') and sh.has_table: rpr.set('sz', str(int(float(sd['table_font_pt']) * 100)))
        for key, sh in regions.items():
            if key in fills or key in keep:
                continue
            if sh.has_table:
                if 'table' not in fills and key not in fills:
                    pass  # untouched table keeps template text only if not filled at all; clear it
                fill_table(sh, [], f'slide {i} {key}')
            elif key != 'title' or 'title' not in fills:
                clear_text(sh.text_frame)
        if sd.get('talk') or sd.get('notes'):
            write_notes(slide, ((str(sd['talk']).strip() + '\n\n') if sd.get('talk') else '') + str(sd.get('notes') or ''))   # the talk track first, the source note under it
        if sd.get('hidden'): slide._element.set('show', '0')   # Hide Slide: kept in the file, skipped by the slide show (PowerPoint's own flag)
        out_slides.append(slide)
    reorder_and_prune(prs, out_slides)
    apply_theme(prs, spec.get('theme'))   # infographic theme (Settings / Output): a design-system treatment of the palette
    ensure_contrast(prs)   # readable text on every coloured box and cell, whatever the template's table style inherits
    prs.save(a.out + '.part'); os.replace(a.out + '.part', a.out)
    try: embed_marker(a.out, spec)
    except Exception as e:  # noqa: BLE001
        warnings.append(f'kit marker not embedded ({str(e)[:60]})')
    check = Presentation(a.out)
    result = {'status': 'OK', 'template': tid, 'template_sha256': thash, 'out': os.path.abspath(a.out),
              'slides': len(check.slides), 'mapping': [int(s['source']) for s in spec['slides']],
              'bytes': os.path.getsize(a.out), 'sha256': sha256(a.out), 'warnings': warnings}
    if result['slides'] != len(spec['slides']):
        result['status'] = 'FAIL'; result['error'] = 'slide count mismatch after save'
    print(json.dumps(result, indent=2))
    sys.exit(0 if result['status'] == 'OK' else 2)


if __name__ == '__main__':
    main()
