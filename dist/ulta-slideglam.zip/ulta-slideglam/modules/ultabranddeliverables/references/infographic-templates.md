# Infographic templates - which to use

Fill the content template (`references/content-templates/<id>.md`), keep its headings and columns, then `ulta.py infographic filled.md --template <id>`. Every number from the user; "-" where nothing was given.

| id | Template | Use it for |
|---|---|---|
| `free` | Free-form | Your content picks the blocks: numbers, steps, dates, a takeaway |
| `auto` | Auto - pick the template from the content | AI on: the model picks the template and fits your text to it. AI off: a template is used when your content clearly follows one |
| `status` | Weekly status - table | Overall status, workstreams with RAG, risks & support required, milestones, the decision |
| `status_cards` | Weekly status - scorecard | A status card per workstream, highlights and lowlights, the asks |
| `exec` | Executive one-glance | Overall status, three numbers, wins, risks, the decisions - for a VP read in a minute |
| `milestones` | Milestone status - steering committee | Milestones on a timeline and in a table with RAG, the critical path, decisions |
| `process` | Process one-pager | Purpose, trigger, the steps, who does what, systems, KPIs and controls |
| `product` | Product one-pager | What it is, who it is for, the problem, features, benefits, roadmap, contacts |
| `change` | Release / change notice | What's changing, who is affected, when, what to do, before and after, support |
| `cheatsheet` | Knowledge cheat sheet | Key terms, how-to steps, do's and don'ts, shortcuts, where to get help |
| `charter` | Project charter | Objective, scope in and out, timeline, team, success measures, risks |
| `decision` | Decision brief | Context, the options compared, the recommendation, impact, next steps |
| `kpi` | KPI scorecard | Headline numbers, every KPI against target with status, commentary, actions |
| `incident` | Post-incident review | What happened, the impact, the timeline, the root cause, the actions |
| `proposal` | Budget proposal - with a UI concept | The value in a band, the UI concept beside what it does, how the work changes, the decision |
| `intro` | Product introduction - with pictures | What it is in a line, the product in pictures, who it is for, how the work changes, the value, the next step |
| `status_pics` | Status update - with screenshots | Overall status, what shipped in screenshots, workstreams, risks, what comes next, the decision |

Pictures (the last three): a picture is a line `![what it shows](/mnt/data/<file>.png)` under its heading - a file the user uploaded; the caption is printed under it and describes it for screen readers. The `sample:` pictures in these content templates are for the thumbnails only.
Formats: `onepager` (Letter portrait - everything fits), `slide` (16:9 on the template; two slides when one is too dense), `square` (social).
Themes: ulta (default), glow, velvet, frost, paper, sunset, charcoal.
