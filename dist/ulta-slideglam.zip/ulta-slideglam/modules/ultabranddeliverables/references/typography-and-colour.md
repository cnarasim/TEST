# Ulta typography and colour (the design tokens)

## Type
| Use | Font | Colour | Size |
|---|---|---|---|
| Slide and page titles | Playfair Display Black | Ulta orange `#EE6C37` | slide 40–60 px (one line when it fits); one-pager 42–64 px |
| Section titles (infographics) | Playfair Display Black | Ulta orange `#EE6C37`, with an icon badge | 21–32 px |
| Kicker above a title | Circular Std Bold, caps, letter-spaced | `#C25610` | 15 px |
| Body | Circular Std Book (fallback Helvetica, Arial) | ink `#2B2320`, muted `#6B615C` | never under 8.4 pt in PowerPoint (14 px on the 120-px-per-inch canvas) |
| Emphasis | Circular Std Bold | ink |-|
| Card body text on the template | Circular Std Book | plum `#5D0F43` | 20 pt |

## Template shape colours (the content master's theme - what PowerPoint draws)
| Role | Hex | Used on |
|---|---|---|
| accent2 - magenta | `#D01381` | first card / first table label / first step |
| accent3 / tx2 - pink | `#EA0B59` | second |
| accent4 - red | `#F14C24` | third step / third table label |
| accent1 - orange | `#F16A1C` | third card and number box (table style), fourth row |
| peach banding | `#FDE1D2` | every second table row; odd step columns |
| plum | `#5D0F43` | card body text |

## Infographic palette
`#F37830` orange · `#E8275A` pink · `#C4007A` magenta · `#5D0F43` plum · `#E9341C` red. Page `#FBF8F6`, lines `#E8DED8`.
Themes: Ulta (solid), Glow, Velvet, Frost, Paper, Sunset, Charcoal - the page stays light in every theme.

## Status (RAG) - always colour **and** word
| Status | Colour | Word |
|---|---|---|
| Green | `#2E8B57` | On track |
| Amber | `#D99100` (dark ink on it) | At risk |
| Red | `#C8102E` | Off track |

## Fixed elements
- Footer on every slide: "Ulta Beauty | Proprietary & Confidential" and the ULTA logo (the template supplies them).
- Icons: only the Ulta set in `scripts/kit/icons` (line icons, recoloured to the shape they sit on).
- Never: drop shadows on text, more than one accent colour per element, text in images, stock photos, emoji in titles.
