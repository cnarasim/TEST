# Architecture diagram styles

Pick the style for the story; (ULTA SlideGlam does not ship the style pictures: draw a small sample to see one.) A style the diagram does not suit is reported and drawn as the closest that does.

| style | Look | Use it for | Needs |
|---|---|---|---|
| `bands` | brand-colour header band per system | the default: any landscape, brand-coloured | any diagram |
| `outline` | white boxes, coloured borders - minimal | a quiet, minimal look | any diagram |
| `pastel` | soft tint fills, no borders - calm | soft, for business audiences | any diagram |
| `icons` | a template pictogram for every system | non-technical audiences - a pictogram per system | any diagram |
| `midnight` | dark panel, light lines - the emphasis slide | the one emphasis slide in a deck | any diagram |
| `numbered` | numbered badges on the lines and a flow legend | walking through the flows in order | any diagram |
| `cake` | stacked tiers, top to bottom | tiers / layers (≤ 2 systems a tier) | at most two systems per tier |
| `hub` | the central system in the middle, senders left, receivers right | one central system (an ESB, an ERP) | one system linked to three or more |
| `chevron` | a process of chevrons, the detail under each | a single pipeline A → B → C | a single chain of systems |
| `bubbles` | circles with pictograms, names beneath | a light overview | any diagram |
| `sequence` | a lifeline per system, the flows as numbered messages in order | an ordered exchange between systems (who calls whom, in what order) | two or more flows |
| `matrix` | who sends to whom: systems × systems, the flow in the cell | many interfaces: who sends what to whom | three or more flows |
| `zones` | systems grouped into Channels · Integration · Core · Data | a landscape grouped Channels · Integration · Core · Data | systems in two or more zones (Channels, Integration, Core, Data) |
| `tech` | databases as cylinders, events as queues, people as people | technical reviews: databases, queues, gateways, people as what they are | two or more kinds of system (app, database, queue, gateway …) |
| `radial` | systems around a ring, flows as chords | peers around a ring (4–8 systems) | 4 to 8 systems |
| `tree` | one source on top, what it feeds below | one source feeding many | one root system |
| `cloud` | flat pastel zones, white cards with a blue icon, thin blue elbow lines - the cloud architecture-guide look | the cloud architecture-guide look (pastel zones, blue lines) | zones that keep the reading order |

## Writing the input

- One flow a line: `Store POS → Integration hub: sales` (the text after `:` labels the line).
- A chain on one line: `Web portal → API gateway → Order service → Billing`.
- JSON: `{"nodes": [{"id": "pos", "label": "Store POS", "sub": "Channel"}], "flows": [{"source": "pos", "target": "mule", "label": "sales"}]}`.
- Zones sort systems by name: stores, POS, apps, web, banks, EDI, suppliers → Channels; API, MuleSoft, Kafka, gateways → Integration; ERP, CRM, OMS, WMS, billing, core platforms → Core; reporting, analytics, lake → Data.

Point graphics (funnel, pyramid, staircase, timeline, quadrant, Venn, target, honeycomb) draw a list of points, not flows: use `ulta.py infographic` or a deck section.
