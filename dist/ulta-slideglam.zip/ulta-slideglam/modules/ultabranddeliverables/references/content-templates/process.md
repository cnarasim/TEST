# Store Transfer Request - Process
Process owner: Inventory Control
Trigger: A store requests stock from another store
Frequency: Daily, before 2 pm
Systems: Inventory system, store app

## Purpose
Move stock between stores the same week, so a guest's product is on the shelf where they shop.

## Steps
1. Request: The store raises a transfer in the store app
2. Approve: The district manager approves within 4 hours
3. Pick: The sending store picks and packs the order
4. Ship: Courier collects the next morning
5. Receive: The receiving store scans it in

## Roles
| Role | Responsible for |
|---|---|
| Store manager | Raises and receives the transfer |
| District manager | Approves within 4 hours |
| Inventory Control | Monitors open transfers daily |

## KPIs
- 2 days: request to shelf
- 98%: transfers received in full
- 4 hours: approval time

## Controls
- Approval: No transfer ships without the district manager's approval
- Value limit: Transfers over $5,000 need Finance sign-off
