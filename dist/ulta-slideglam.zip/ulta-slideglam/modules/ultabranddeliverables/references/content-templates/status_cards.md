# Store Systems Programme - Weekly Scorecard
Week ending: 10/09
Overall status: Amber
Programme: Store Systems Modernisation
Lead: Nadia Wren

## Workstreams
| Workstream | Owner | Status | Update |
|---|---|---|---|
| POS upgrade | Rowan | Green | 212 of 1,400 stores live; no P1 incidents |
| Inventory accuracy | Tess | Amber | Cycle count pilot slipped one week for training |
| Store network | Arlo | Green | SD-WAN in 3 regions; 4th starts 10/14 |
| Loyalty at till | Mila | Red | Points reversal defect blocks wave 2 |
| Training | Vance | Green | 1,850 associates trained |

## Highlights and lowlights
### Highlights
- POS wave 1 closed with no P1 incidents
- Training ahead of plan
### Lowlights
- Loyalty reversal defect blocks wave 2
- Cycle count pilot one week late

## Asks
- Loyalty vendor: a fix date for the reversal defect by 10/14
- Store Ops: release 40 trainers for the wave 2 stores
