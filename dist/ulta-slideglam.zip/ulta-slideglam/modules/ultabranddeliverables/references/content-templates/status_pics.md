# Vendor Price Portal: Sprint 6
Overall status: Green
Period: Sprint 6, weeks 11-12
Lead: Nadia Wren

## What shipped
![Partners submit and track their requests](sample:price-portal)
![Pricing approves in one queue](sample:approval-queue)

## Workstreams
| Workstream | Owner | Status | Update |
|---|---|---|---|
| Partner requests | Rowan | Green | Live for 12 pilot brands |
| Approval queue | Tess | Green | Margin and limit checks on |
| Reporting | Arlo | Amber | Audit export slips one sprint |

## Risks
| Risk or ask | Support needed from | Owner | Need by | Severity |
|---|---|---|---|---|
| Item master feed late | Data platform | Arlo | 11/14 | Amber |

## Next
- 11/18: Pilot with 25 brands
- 12/02: Audit export
- 12/16: Go-live decision

## Decision needed
Confirm the 25 pilot brands so onboarding starts on 11/18.
