# Demand Planning - Weekly Status
Week ending: 10/09
Overall status: Green
Project lead: Rowan
Phase: Build

## Workstreams
| Workstream | Owner | Status | This week (10/09) | Next week (10/16) |
|---|---|---|---|---|
| Data Requirements | Felix / Mila | Green | Paper model for inventory & promo data via Ulta Medallion | Data mapping for Item, Loc, Time, Sales, Listing |
| Integration Design | Rowan / Elliot | Amber |-| Historical data load KDD & architecture review |
| Testing | Owen / Ines / Arlo | Green |-| Testing strategy & framework deliverable |
| AI / Data Science | Vance / Elliot | Green | Definition of Done for DP Data Science inputs (draft) | Definition of Done (final) · meeting cadence & agenda |
| Reporting & BI | Theo | Green |-| DP reports inventory & new KPI |

## Risks & support required
| Risk or ask | Support needed from | Owner | Need by | Severity |
|---|---|---|---|---|
| Validate 3-year historical data availability & confirm implementation timelines | Databricks & Infosys | Rowan | 10/16 | Amber |
| Confirm firewall rules & Delta Share connectivity before data load | Ulta Security & o9 | Elliot | 10/14 | Red |

## Milestones
- 10/09: Paper model for inventory & promo data
- 10/16: Historical data load KDD & architecture review
- 10/23: Testing strategy & framework signed off
- 10/30: Data mapping complete

## Decision needed
Approve Delta Share as the connection for the historical data load by 10/14.
