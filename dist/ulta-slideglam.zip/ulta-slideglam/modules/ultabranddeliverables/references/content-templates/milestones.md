# Returns Modernisation - Steering Committee
Overall status: Green
Next steerco: 10/23
Go-live: 2/2

## Milestones
| Milestone | Date | Owner | Status |
|---|---|---|---|
| Design signed off | 10/09 | Rowan | Green |
| Build complete | 11/20 | Nadia | Green |
| Store pilot (20 stores) | 12/04 | Tess | Amber |
| Holiday freeze | 12/15 | IT Ops | Green |
| Chain rollout | 2/2 | Tess | Green |

## Critical path
1. Build: POS and loyalty changes in one release
2. Test: Regression with the holiday code freeze in mind
3. Pilot: 20 stores for two weeks
4. Rollout: Region by region after the freeze

## Decision needed
Confirm the pilot can run in the two weeks before the holiday freeze.
