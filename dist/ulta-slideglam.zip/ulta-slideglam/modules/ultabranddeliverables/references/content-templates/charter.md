# Supplier Onboarding Portal - Project Charter
Sponsor: VP Merchandising
Lead: Nadia Wren
Start: 11/1
End: 4/30
Budget: $850K

## Objective
Onboard new beauty brands in 10 days instead of 6 weeks, with every item set up right the first time.

## Scope
### In scope
- Brand registration and contracts
- Item setup for the ERP and the website
### Out of scope
- Payments and invoicing
- Drop-ship brands

## Timeline
- Nov: Design and vendor selection
- Jan: Build
- Mar: Pilot with 10 brands
- Apr: Launch

## Team
| Role | Name |
|---|---|
| Sponsor | VP Merchandising |
| Lead | Nadia Wren |
| Architect | Rowan Pike |

## Success measures
- 10 days: brand onboarding time
- 95%: items set up right first time
- 200: brands onboarded in year one

## Risks
| Risk or ask | Support needed from | Owner | Need by | Severity |
|---|---|---|---|---|
| Item data standards not agreed | Merchandising | Nadia | 12/1 | Amber |
