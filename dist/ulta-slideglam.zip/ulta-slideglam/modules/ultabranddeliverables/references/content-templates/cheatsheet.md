# Travel & Expenses - Cheat Sheet
Topic: Business travel and expense claims
For: All employees
Updated: October 2026

## Key terms
| Term | Meaning |
|---|---|
| Per diem | Daily meal allowance by city |
| Pre-approval | Manager sign-off before booking |
| Receipt | Itemised proof of every purchase over $25 |
| Corporate card | Company card for travel and client costs |

## How to claim an expense
1. Capture: Photograph the receipt in the expense app
2. Submit: Add the cost centre and business purpose
3. Approve: Your manager approves within 5 days

## Do's and don'ts
### Do
- Book flights through the travel portal
- Submit claims within 30 days
### Don't
- Split a purchase to stay under a limit
- Pay personal costs on the corporate card

## Shortcuts
| Action | Where |
|---|---|
| Book travel | Travel portal |
| Submit a claim | Expense app |
| Check a policy | Policy hub |

## Need help?
- Travel desk: #travel-help in Teams
- Finance support: Service desk, Expenses queue
