# New Returns Screen at the Till - Change Notice
Go-live: 11/4
Audience: All store associates
Impact: Medium

## What's changing
- One screen: Returns, exchanges and loyalty reversal in one place
- Receipt lookup: Find any order from the last 90 days by phone number
- Refund to card: No more cash refunds over $50

## Who is affected
- Associates: New screen at every till
- Store managers: Fewer overrides to approve

## What you need to do
1. Training: Complete the 15-minute module by 11/1
2. Try it: Practise in training mode on 11/3
3. Go live: Use the new screen from 11/4

## Before and after
### Before
- Three screens for one return
- Manager override for loyalty points
### After
- One screen for every return
- Points reversed automatically

## Support
| Contact | For | How |
|---|---|---|
| Store Help Desk | Till issues | Ext. 4357 |
| Training team | The module | #store-training |
