# Rewards Wallet
Product owner: Mila Hart
Status: In pilot
Launch: Q1 FY27

## What it is
Points, rewards and offers in one wallet in the app, ready to scan at the till.

## In pictures
![The wallet in the app](sample:rewards-app)
![Rewards at the till](sample:guest-bag)
![Offers on beauty favorites](sample:product-swatches)

## Who it's for
- Store guests: See points and offers before they pay
- Associates: Apply rewards without a manager override

## How the work changes
### Today
- Paper coupons
- Points looked up at the till
- A manager override
### Tomorrow
- Offers in the app
- Scan the guest's code
- Applied in seconds

## Value
- 12%: more rewards redeemed in the pilot
- 30 sec: faster checkout with rewards
- 4.7: guest app rating in the pilot

## Next step
Approve the chain-wide launch for Q1, after the holiday freeze.
