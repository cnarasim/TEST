# Ultamate Rewards in the App - Product One-pager
Product owner: Mila Hart
Status: In pilot
Launch: Q1 FY27

## The problem
Guests can't see their points or rewards when they shop in store, so offers go unused.

## Who it's for
- Store guests: See points and offers at the till
- Associates: Apply rewards without a manager override

## Key features
- Wallet: Points and rewards in one card in the app
- Scan to apply: Associates scan the guest's code at the till
- Offers: Personal offers shown before checkout

## Benefits
- 12%: more rewards redeemed in the pilot
- 30 sec: faster checkout with rewards
- 4.7: guest app rating in the pilot

## Roadmap
- Q4: Pilot in 40 stores
- Q1: Chain-wide launch
- Q2: Personal offers in the app

## Contacts
| Name | Role |
|---|---|
| Mila Hart | Product owner |
| Rowan Pike | Engineering lead |
