# Vendor Price Portal
Price changes in one portal, checked at entry and approved in one queue.
Budget ask: $1.2M
Sponsor: SVP Merchandising
Go-live: Q3 FY26
Payback: 14 months

## Business value
- Less manual effort
- Faster approvals
- Fewer pricing errors
- A full audit trail

## The portal: UI concept
![Price change requests, with every check before approval](sample:price-portal)
- Request: Brand partners submit price changes online
- Validate: Margins and limits checked at entry
- Approve: Pricing reviews in one queue
- Audit: Every change and approver kept

## How the work changes
### Today: manual and disconnected
- E-mail and spreadsheets
- Manual margin checks
- Re-keyed into systems
- Errors found late
### Tomorrow: digital and streamlined
- One online request
- Checks at entry
- One approval queue
- Live the same day

## Leadership decision
Approve $1.2M for phase 1 (requests, checks, the approval queue and the audit trail); size bulk uploads and promotions separately.
