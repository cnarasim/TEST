# Demand Planning on o9 - Executive Update
Period: October, week 2
Overall status: Amber
Sponsor: SVP Supply Chain

## Key numbers
- 78%: forecast accuracy in the pilot categories
- 4 of 6: workstreams on track
- $1.2M: inventory released in the pilot DCs

## Wins
- Data: Three years of sales history loaded and reconciled
- Pilot: Cosmetics forecast live in two DCs
- Team: Data science lead hired

## Risks
| Risk or ask | Support needed from | Owner | Need by | Severity |
|---|---|---|---|---|
| Delta Share firewall rules not yet approved | Ulta Security | Elliot | 10/14 | Red |
| Store attribute data late from Store Ops | Store Ops | Nadia | 10/21 | Amber |

## Decision needed
Approve Delta Share as the connection for the historical data load by 10/14.
