# Historical Data Load - Decision Brief
Decision owner: VP Enterprise Architecture
Needed by: 10/14
Status: For decision

## Context
o9 needs three years of sales history. Security has not yet approved a connection from Databricks to o9.

## Options
| Option | Pros | Cons | Time |
|---|---|---|---|
| Delta Share | Live, no copies | Firewall change | 2 weeks |
| Nightly file drop | No new connection | Copies data, slower | 3 weeks |
| Manual extract | Fast to start | Not repeatable | 1 week |

## Recommendation
Use Delta Share: no data copies, and it is the pattern for every later o9 feed.

## Impact
- 2 weeks: to first load
- 0: data copies to maintain

## Next steps
1. Approve: Security signs off the firewall rule
2. Connect: Platform team opens the share
3. Load: First history load into o9
