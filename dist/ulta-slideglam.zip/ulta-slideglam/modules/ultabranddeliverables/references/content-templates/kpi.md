# Store Operations - KPI Scorecard
Period: September
Owner: VP Store Operations
Overall status: Amber

## Headline numbers
- 96.4%: on-shelf availability
- 2.1 days: replenishment lead time
- 91%: inventory accuracy

## KPI detail
| KPI | Actual | Target | Trend | Status |
|---|---|---|---|---|
| On-shelf availability | 96.4% | 97% | Up | Amber |
| Replenishment lead time | 2.1 days | 2 days | Flat | Amber |
| Inventory accuracy | 91% | 95% | Down | Red |
| Shrink | 1.2% | 1.5% | Down | Green |

## Commentary
- Accuracy: Cycle counts paused in two regions for the POS upgrade
- Availability: Holiday sets arrived early in 300 stores

## Actions
1. Restart: Cycle counts in both regions from 10/14
2. Review: Accuracy by store at the 10/21 ops meeting
