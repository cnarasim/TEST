# POS Payment Outage - Post-incident Review
Severity: P1
Date: 10/3
Duration: 47 minutes
Owner: IT Operations

## What happened
Card payments failed in 312 stores after a certificate on the payment gateway expired.

## Impact
- 47 min: card payments down
- 312: stores affected
- $410K: estimated lost sales

## Timeline
- 10:02: First store reports card declines
- 10:09: P1 declared, bridge opened
- 10:31: Expired certificate found
- 10:49: Certificate renewed, payments recover

## Root cause
The gateway certificate was renewed by hand and its expiry was not monitored.

## Actions
| Action | Owner | Due | Status |
|---|---|---|---|
| Monitor every certificate's expiry | IT Ops | 10/17 | Green |
| Automate certificate renewal | Platform | 11/15 | Amber |
| Add a payment-failure alert per region | Payments | 10/24 | Green |
