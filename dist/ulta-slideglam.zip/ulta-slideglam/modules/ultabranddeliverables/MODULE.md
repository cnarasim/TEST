---
name: ulta-brand-deliverables
description: Make Ulta Beauty presentations and one-page infographics on the official Ulta template and typography - decks from notes or a page (Markdown → PowerPoint on the approved template), and infographics from 12 enterprise templates (weekly status, executive update, steering committee, process, product, change notice, cheat sheet, project charter, decision brief, KPI scorecard, post-incident review). Use for any Ulta deck, slide, one-pager, status report, infographic or cheat sheet, or when someone asks for the Ulta look.
---

> v12 NOTE: SKILL.md wins where this conflicts - decks are built with tools/build_deck.py, headlines are full width, autofit.py may reduce font sizes to prevent overflow, and no intake questions are required.


# Ulta brand deliverables - v6.13

You make Ulta Beauty decks and one-page infographics in Ulta's own look: the approved PowerPoint template, Playfair Display
Black titles in Ulta orange, Circular body text, the Ulta palette and icon set. **You write the content; the scripts build the files.**
Never draw slides or infographics yourself (no hand-made python-pptx layouts, no HTML mock-ups): run `scripts/ulta.py`.

## Setup (once per session)

```bash
cd <this skill folder>          # in a hosted sandbox: unzip /mnt/data/ulta-brand-deliverables.zip and cd into it
python3 scripts/ulta.py check    # python-pptx, lxml, Pillow; the template's hash; resvg (optional: PNG/PDF pictures)
```

## Decks (PowerPoint on the Ulta template)

1. Write the content as Markdown: `# Deck title`, then `## Slide headline` sections. Under each: short bullets (`- Label: point`), a table
   for actions (What / Description / When · Who), numbers as `- 98%: what it means`, numbered steps (`1. Name: what happens`).
2. `python3 scripts/ulta.py deck content.md --out Deck.pptx [--max-slides 8] [--theme ulta]`
 - the rules choose the template layouts (cards, three numbers, actions table, steps, grid, two-column text, dividers, agenda).
   Architecture and flows: write them as lines `A → B: what flows` (or a one-line chain `Web portal → API gateway → Order service → Billing`) under a
   heading such as `## Integration architecture`; add `Diagram style: zones` (or cloud, tech, bands, sequence …) to pick the look. The
   deck gets a native diagram slide and an editable `.drawio` file next to the .pptx.
3. Optional review: `python3 scripts/ulta.py spec content.md --out spec.json`, edit the JSON (see `references/deck-layouts.md` for every
   slide and region), then `python3 scripts/ulta.py build spec.json --out Deck.pptx`.
4. Give the user the .pptx. Tell them any warnings the script printed (shortened text, a section that did not fit).

## Gallery - show before you build

`references/gallery/` holds a picture of everything this skill makes, drawn by the kit from sample content (`index.html` browses it;
`gallery.json` lists each picture with its id). When the user is choosing, show the matching pictures:
`infographic-templates/<nn>-<id>-onepager.png` / `-slide.png`, `diagrams/<nn>-<style>.png` (17 architecture styles, 8 point graphics),
`deck-layouts/<nn>-<layout>.png`. Say they are samples: the user's content gives the same look with their words.

## Architecture diagrams (17 styles)

1. Write the flows, one per line: `Store POS → Integration hub: sales` (or a chain `Web portal → API gateway → Order service → Billing`, box art, or JSON).
2. Pick the style for the story (`python3 scripts/ulta.py diagram-styles`; guide and pictures: `references/diagram-styles.md`,
   style pictures are not shipped in ULTA SlideGlam: draw a small sample to see one): zones for a landscape, hub for one central system, sequence for an ordered exchange, matrix for
   who-sends-to-whom, cake for tiers, chevron for a single pipeline, cloud for the cloud-guide look.
3. `python3 scripts/ulta.py diagram flows.txt --style zones --title "Payments to fulfilment" --out Payments`
   → `.pptx` (the diagram slide on the template, native shapes), `.drawio` (editable), `.svg` (+ `.png` with resvg).
   `--all-styles` gives one slide per style that suits it, to compare; `--frame` adds cover and closing.
4. Inside a deck, put the same lines under a heading like `## Integration architecture`, optionally with `Diagram style: zones`.
   A style that cannot draw the diagram is reported ("needs one system linked to three or more - drawn as bands") - tell the user.

## Infographics (one-pagers, slides, social squares)

1. Pick the template (`python3 scripts/ulta.py templates`; when to use each: `references/infographic-templates.md`).
2. Get its content template: `python3 scripts/ulta.py content-template process` (Markdown) or `--docx Process.docx` for the team.
3. **Fill it with the user's content** - keep the `Key: value` lines, the `## ` headings in order and the table columns; replace every
   sample fact; write ` - ` where the user gave nothing. Every number must come from the user. Status / Severity: Green, Amber or Red.
4. `python3 scripts/ulta.py infographic filled.md --template process --format onepager --out Store-Transfer`
   → `.pptx` (editable shapes), `.svg`, `.html`, and `.png` / `.pdf` when resvg is installed. `--format slide` gives 16:9 (two slides
   when one is too dense); `--template auto` picks by the headings; `--template free` lets the content choose blocks.
5. If the script says sections are missing, fix the Markdown (the heading names are in the content template) and run it again.

## Ulta rules (always)

- Typography and colours: `references/typography-and-colour.md`. Titles Playfair Display Black, Ulta orange #EE6C37; body Circular;
  the template's own palette for shapes. Do not restyle the template, add fonts, gradients, emoji or clip art.
- Headlines say the point in ≤ 40 characters ("Returns cost 3 days and 2 systems"), not a topic ("Returns").
- Plain words, short bullets (≤ 2 lines), no marketing adjectives. One idea per slide.
- **Never invent, round or compute a number, date, owner or status.** Missing → "-" or "Not provided", and say so.
- RAG is always a colour and a word (On track / At risk / Off track), never colour alone.
- Every slide keeps the footer "Ulta Beauty | Proprietary & Confidential" (the template does this). No personal data beyond names and roles.
- Hand over files, not screenshots; state what was built (slides, template, format) and any warnings.

## Files

- `scripts/ulta.py` - the one command (deck · spec · build · diagram · diagram-styles · infographic · templates · content-template · check)
- `scripts/kit/` - the builders (decks, infographics, diagrams + .drawio), the approved template (`templates/`, hash-pinned in `manifest.json`), the icons (`icons/`)
- `references/typography-and-colour.md` · `references/deck-layouts.md` · `references/diagram-styles.md` · `references/gallery/` (pictures of every template, style and layout) · `references/infographic-templates.md` · `references/content-templates/*.md`
