# Ulta brand deliverables - a skill (v6.13)

Ulta Beauty decks and one-page infographics on the official template and typography. The model writes the content;
`scripts/ulta.py` builds the files, with no server needed.

**Confidential:** this contains Ulta's approved PowerPoint template and the builders' code. Use it only in Ulta-approved workspaces
with company data controls - not in a personal account.

## Install

- **As a skill**: add `ulta-brand-deliverables.zip` as a skill in your workspace (SKILL.md format), or unzip it into the
  workspace's skills folder.
- **Without skill support**: paste SKILL.md (everything after the `---` block) as the assistant's instructions, upload
  `ulta-brand-deliverables.zip` as a knowledge file and turn on code execution. The zip is unzipped in the sandbox
  (`/mnt/data`) at the start of a chat, then `python3 scripts/ulta.py check` runs.

## Try it

- "Make an Ulta deck from these notes: …" → `ulta.py deck` → a .pptx on the template.
- "Weekly status one-pager for Demand Planning: …" → `ulta.py content-template status`, filled with your facts → `ulta.py infographic`.
- "A cheat sheet for travel & expenses, 16:9" → the cheat-sheet template on two slides.

## What you get, and the limits

- PowerPoint on the hash-pinned template (editable text and shapes), SVG and an HTML page; PNG and PDF where `resvg-py` is installed
  (a laptop) - not in a hosted sandbox without it.
- The Ulta fonts are not in the sandboxes: the PowerPoint names them, so it shows them on any Ulta laptop.
