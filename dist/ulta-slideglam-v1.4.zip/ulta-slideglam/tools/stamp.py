"""Version stamp and audit trail for every delivered file.

    python tools/stamp.py stamp  Deck.pptx --action "built" [--result READY] [--owner "Name"] [--classification Internal]
    python tools/stamp.py verify Deck.pptx         # who/what/when, and whether slides changed since the last stamp

Writes into the file's own properties (visible in PowerPoint: File > Info > Properties > Advanced > Custom):
  Producer (this skill and its version: how the file was made), Version (1.0, 1.1, ...), Brand, BrandTemplateSHA256,
  SkillVersion, ValidatorResult, ContentSHA256 (hash of the
  slides), Classification, ChangeLog (last 20 actions). Core: title (first headline), revision, last modified.
  The people the template recorded (its author, last editor, comment authors, SharePoint sharing) are removed;
  author and last editor become the owner, or "Ulta Beauty" (tools/privacy.py).
A full audit log is also appended to <deck>.audit.json beside the file.
verify: recomputes the slide hash. "unchanged since stamp" means the file is exactly what passed the checks.
"""
import argparse, datetime, hashlib, json, re, sys, zipfile
from pathlib import Path

TOOLS = Path(__file__).resolve().parent
sys.path.insert(0, str(TOOLS))
import brand as B          # noqa: E402
import docprops as DP      # noqa: E402
import privacy             # noqa: E402

SKILL_VERSION = "v1.4"
PRODUCER = "ULTA SlideGlam"


def content_hash(path):
    z = zipfile.ZipFile(path)
    h = hashlib.sha256()
    for n in sorted(x for x in z.namelist() if re.match(r"ppt/(slides|charts|media|notesSlides)/", x)):
        h.update(n.encode()); h.update(z.read(n))
    return h.hexdigest()


def first_headline(path):
    from pptx import Presentation
    b = B.current()
    for s in Presentation(str(path)).slides:
        for sh in s.shapes:
            if sh.has_text_frame and sh.text_frame.text.strip() and (b.is_headline(sh._element) or sh.is_placeholder):
                return sh.text_frame.text.strip().split("\n")[0][:120]
    return Path(path).stem


def stamp(path, action, result=None, owner=None, classification=None):
    core, custom = DP.read_props(path)
    b = B.current()
    if classification:
        import compliance
        classification = compliance.LEVELS.get(classification.lower(), (classification,))[0]
    now = datetime.datetime.now(datetime.timezone.utc).replace(microsecond=0)
    ver = custom.get("Version") if custom.get("ContentSHA256") else None    # template's own props don't count
    if ver:
        major, minor = (ver.split(".") + ["0"])[:2]
        ver = f"{major}.{int(minor) + 1}"
    else:
        ver = "1.0"
    entry = f"{now:%Y-%m-%d %H:%M}Z v{ver} {action}" + (f" [{result.split(' ')[0]}]" if result else "")
    log = [l for l in (custom.get("ChangeLog") or "").split(" | ") if l] + [entry]
    props = {"Producer": f"{PRODUCER} {SKILL_VERSION}", "Version": ver, "Brand": b.name, "BrandTemplateSHA256": b.sha, "SkillVersion": SKILL_VERSION,
             "ValidatorResult": (result or custom.get("ValidatorResult") or "not validated")[:120],
             "ContentSHA256": content_hash(path), "ChangeLog": " | ".join(log[-20:]),
             "Classification": classification or custom.get("Classification") or "unset"}
    if owner:
        props["Owner"] = owner
    rev = int(core.get("revision") or 0) + 1
    DP.write_props(path, core={"title": first_headline(path), "revision": rev,
                               "lastModifiedBy": owner or core.get("lastModifiedBy") or privacy.OWNER,
                               "modified": f"{now:%Y-%m-%dT%H:%M:%SZ}"}, custom=props)
    privacy.scrub(path, owner)                     # no template author, editor, comment authors or SharePoint people
    audit = Path(str(path) + ".audit.json")
    hist = json.loads(audit.read_text()) if audit.exists() else []
    hist.append({"when": now.isoformat(), "version": ver, "action": action, "result": result, "owner": owner,
                 "brand": b.name, "content_sha256": props["ContentSHA256"], "classification": props["Classification"]})
    audit.write_text(json.dumps(hist, indent=1))
    return ver


def verify(path):
    core, custom = DP.read_props(path)
    if "ContentSHA256" not in custom:
        return False, ["no stamp: the file was not produced (or was re-saved) by this skill"]
    same = content_hash(path) == custom["ContentSHA256"]
    lines = [f"version {custom.get('Version')} | brand {custom.get('Brand')} | classification {custom.get('Classification')} "
             f"| skill {custom.get('SkillVersion')}",
             f"last check: {custom.get('ValidatorResult')}",
             f"purview label: {DP.purview_label(custom) or 'none'}",
             "slides UNCHANGED since the stamp" if same else "slides CHANGED since the stamp - re-run the checks",
             "history: " + (custom.get("ChangeLog") or "")]
    return same, lines


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["stamp", "verify"]); ap.add_argument("deck")
    ap.add_argument("--action", default="built"); ap.add_argument("--result"); ap.add_argument("--owner")
    ap.add_argument("--classification")
    a = ap.parse_args()
    if a.cmd == "stamp":
        print(f"stamped v{stamp(Path(a.deck), a.action, a.result, a.owner, a.classification)}")
    else:
        ok, lines = verify(Path(a.deck))
        print("\n".join(lines))
        sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
